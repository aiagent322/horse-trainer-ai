// Translated from C to Rust. The original C code can be found at
// https://github.com/ulfjack/ryu and carries the following license:
//
// Copyright 2018 Ulf Adams
//
// The contents of this file may be used under the terms of the Apache License,
// Version 2.0.
//
//    (See accompanying file LICENSE-Apache or copy at
//     http://www.apache.org/licenses/LICENSE-2.0)
//
// Alternatively, the contents of this file may be used under the terms of
// the Boost Software License, Version 1.0.
//    (See accompanying file LICENSE-Boost or copy at
//     https://www.boost.org/LICENSE_1_0.txt)
//
// Unless required by applicable law or agreed to in writing, this software
// is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
// KIND, either express or implied.

#![allow(
    clippy::approx_constant,
    clippy::cast_lossless,
    clippy::float_cmp,
    clippy::int_plus_one,
    clippy::non_ascii_literal,
    clippy::unreadable_literal,
    clippy::unseparated_literal_suffix
)]

#[macro_use]
mod macros;

use std::f64;

fn pretty(f: f64) -> String {
    ryu::Buffer::new().format(f).to_owned()
}

fn ieee_n as  -> ty(f      2  /ound at
// h                /src/d2s_full_table.rs3py::cast_sig8f5f!(0_m2 <= nt ieee_e<=Ulf47 assert_eq!(
!mantissa, ieeee<=U<< DOUBLE53;
    let ierom_bits(ieee))ed_m a4) << d2s::D63ee_e(m2 <= nt ieee_e) << d2s::D52ee_e2)
  sa) as istest]
fn test_computuff       as     !(0.      re     !(00000.0
   0
          re     !(03
   16     re     !(2.71828     re     !(031e128     re     !(031e-   debug_     !(2.7182818284590    ibug_     !(5e

    i  re     !(037976931348623157e308#[test]
fn test_doubleteddom       asee =nieee_ecfg!(mir     10se { 0.0 })1 0
     if m10t buffer = [Maybeuffer::new().forma;or (i, en_itin0..      return= 1.2 -> Sybeuedd:forddom  ;   assert_eq!(*entryfer.as_mut(f).toe
/// [_own:Erromatun    () }
}

#[test]
fn tesattr(featurmir srcgnor[allt_doublecii_
/// [_  for (i, en..off    ..1s::D23     return= 1.2or_lom_bits(ieee))ed(1s::D11;
    s::D52ee+ntrs::D29) ;   assert_eq!(*!(!fnite
/// [sult"f=);
  f     return ffer::new().format(f).toe
/// [_ow}
}

#[test]
fn test_computba
#[       as     !(0.      re     !(-        re     !(03      re     !(-03      re_eq!(print, ": f64)om_bNANult"NaN"     re_eq!(print, ": f64)om_bINFINITYult"inf"     re_eq!(print, ": f64)om_bNEG_INFINITYult"-inf"   est]
fn test_computswitch(f  subnf).tl       as     !(2.225073858507lf 4e

08#[test]
fn test_doublemii_lnd_ e2   assert_eq!(0, 0.0lom_bits(ieee)){
   fffffffffffffult037976931348623157e308#[t  re     !(037976931348623157e308#[tsert_eq!(0, 0.0lom_bits(ieee))sult5e

    i  re     !(5e

    iest]
fn test_log10_poty(of_ng_zeros || ((       as     !(2.9801322387695312e-8#[test]
fn test_doubletegr im0.
       as     !(//
109808898695963 16     re     !(4.940656e

18     re     !(0318575755e

16     re     !(2.9890 0097996e

12     re     !(90608011534336         re     !(4.708356024711512e18     re     !(9.409000.12568248e18     re     !(03
  5678  iest]
fn test_log10_pooksal_k() {
    for (i contepaniis lasactuallssa into te havtriaple_of_poe Apachet power of 2 thaor (i co5te havfee)we nee, tht ieee_ee havcaus followe_inv_about
, enqund uwouldor (i cooffs2h is the caactlyn2 te mov, en rep.ssert_eq!(0, 0.0lom_bits(ieee)){
4830F0CF000DD592ult5.764607513734235e39  i  re     !(5.764607513734235e39  i  re_eq!(0, 0.0lom_bits(ieee)){
4840F0CF000DD592ult03152921502306847e4      re     !(03152921502306847e4      re_eq!(0, 0.0lom_bits(ieee)){
4850F0CF000DD592ult2.305843B54443694e4      re     !(2.305843B54443694e4    est]
fn test_log10_
    /h9(9999       as     !(03   d eitlle_lylog10an offBa
#[   re     !(03
     re     !(03
      re     !(03
       re     !(03
  5     re     !(03
  56     re     !(03
  567     re     !(03
  5678  d eitlle_lylog10an offRegr im0.
   re     !(03
  56789     re     !(03
  567895  d ei03
  567890
    /e casrimmed   re     !(03
  5678901     re     !(03
  56789012     re     !(03
  567890123     re     !(03
  5678901234     re     !(03
  56789012345     re     !(03
  567890123456     re     !(03
  5678901234567  // We neeTwer 32- 0 &chunf th   re     !(4.294967294  d ei2^30) a2   re     !(4.294967295  d ei2^30) a1   re     !(4.294967296  d ei2^30   re     !(4.294967297  d ei2^30)+a1   re     !(4.294967298  d ei2^30)+a2/ PrineTwer mii,um r = if iwas ns off= if 2018 128t]
fn test_doublemii_m r_64(
        asee =m r_sa = bits &<< DOUBLE53;
    // We nee32- 0 &opt- 127=0:  49e<=Ubutee<=U50/ We nee32- 0 &opt- 127=1:  30e<=Ubutee<=U50/ We nee64- 0 &opt- 127=0:  50e<=Ubutee<=U50/ We nee64- 0 &opt- 127=1:  30e<=Ubutee<=U50/ We _eq!(1831, l.7800590868057611E

07,n as  -> ty(f      2  

   , 4,    assert     !(037800590868057611e

07     renee32- 0 &opt- 127=0:  49e<=Ubutee<=U49/ We nee32- 0 &opt- 127=1:  28e<=Ubutee<=U49/ We nee64- 0 &opt- 127=0:  50e<=Ubutee<=U50/ We nee64- 0 &opt- 127=1:  28e<=Ubutee<=U50/ We _eq!(1831,    return2.8480945388892175E

06,   ieee_e2 += -> ty(f      2  

   , 6,=m r_sa = bit)

        tr     !(2.8480945388892175e

06     renee32- 0 &opt- 127=0:  52e<=Ubutee<=U53/ We nee32- 0 &opt- 127=1:   2e<=Ubutee<=U53/ We nee64- 0 &opt- 127=0:  53e<=Ubutee<=U53/ We nee64- 0 &opt- 127=1:   2e<=Ubutee<=U53/ We _eq!(2, log1.446494580089078E-2g10_ as  -> ty(f      2  

   , 41,    assert     !(1.446494580089078e-296     renee32- 0 &opt- 127=0:  52e<=Ubutee<=U52/ We nee32- 0 &opt- 127=1:   2e<=Ubutee<=U52/ We nee64- 0 &opt- 127=0:  53e<=Ubutee<=U53/ We nee64- 0 &opt- 127=1:   2e<=Ubutee<=U53/ We _eq!(2, log   ieee_e4.8929890601781557E-2g10   ieee_e2 += -> ty(f      2  

   , 40,=m r_sa = bit)

        tr     !(4.8929890601781557e-296      renee32- 0 &opt- 127=0:  57e<=Ubutee<=U58/ We nee32- 0 &opt- 127=1:  57e<=Ubutee<=U58/ We nee64- 0 &opt- 127=0:  58e<=Ubutee<=U58/ We nee64- 0 &opt- 127=1:  58e<=Ubutee<=U58/ We _eq!(1831, l.8014398509481984E110_ as  -> ty(f      2  

   , 1077,    assert     !(038014398509481984 16     renee32- 0 &opt- 127=0:  57e<=Ubutee<=U57/ We nee32- 0 &opt- 127=1:  57e<=Ubutee<=U57/ We nee64- 0 &opt- 127=0:  58e<=Ubutee<=U58/ We nee64- 0 &opt- 127=1:  58e<=Ubutee<=U58/ We _eq!(1831,    3.1415926028797018963964E110   ieee_e2 += -> ty(f      2  

   , 1076,=m r_sa = bit)

        tr     !(926028797018963964 16     renee32- 0 &opt- 127=0:  51e<=Ubutee<=U52/ We nee32- 0 &opt- 127=1:  51e<=Ubutee<=U59/ We nee64- 0 &opt- 127=0:  52e<=Ubutee<=U52/ We nee64- 0 &opt- 127=1:  52e<=Ubutee<=U59/ We _eq!(2, log1.900835519859558E-2110_ as  -> ty(f      2  

   , 
07,n   assert     !(1.900835519859558e-211     renee32- 0 &opt- 127=0:  51e<=Ubutee<=U51/ We nee32- 0 &opt- 127=1:  51e<=Ubutee<=U59/ We nee64- 0 &opt- 127=0:  52e<=Ubutee<=U52/ We nee64- 0 &opt- 127=1:  52e<=Ubutee<=U59/ We _eq!(2, log   ieee_e53801671039719115E-2110   ieee_e2 += -> ty(f      2  

   , 
06,=m r_sa = bit)

        tr     !(53801671039719115e-211   / We nee//github.com/ulfjack/ryu and cn.rs"it/19e44d16d80136f5de25800f56d82306d1be00b9#.rs"it.rs"ee_

0146483   renee32- 0 &opt- 127=0:  49e<=Ubutee<=U49/ We nee32- 0 &opt- 127=1:  44e<=Ubutee<=U49/ We nee64- 0 &opt- 127=0:  50e<=Ubutee<=U50/ We nee64- 0 &opt- 127=1:  44e<=Ubutee<=U50/ We _eq!(1831,    return3.196104012172126E-270   ieee_e2 += -> ty(f      2  

   , 934,  x000FA7161A4D6E0C)

        tr     !(92196104012172126e-27   est]
fn test_computsable:integer(       as     !(90071992547409903   d ei2^53-1   as     !(90071992547409923   d ei2^53
   re     !(03      re     !(123      re     !(1233      re     !(12343      re     !(123453      re     !(1234563      re     !(12345673      re     !(123456783      re     !(1234567893      re     !(12345678903      re     !(12345678953      re     !(123456789013      re     !(1234567890123      re     !(12345678901233      re     !(123456789012343      re     !(1234567890123453      re     !(12345678901234563    / We nee10^i   re     !(03      re     !(103      re     !(1003      re     !(10003      re     !(100003      re     !(1000003      re     !(10000003      re     !(100000003      re     !(1000000003      re     !(10000000003      re     !(100000000003      re     !(1000000000003      re     !(10000000000003      re     !(100000000000003      re     !(1000000000000003      re     !(10000000000000003    / We nee10^15)+a10^i   re     !(00000000000000013      re     !(10000000000000103      re     !(10000000000001003      re     !(10000000000010003      re     !(10000000000100003      re     !(10000000001000003      re     !(10000000010000003      re     !(10000000100000003      re     !(10000001000000003      re     !(10000010000000003      re     !(10000100000000003      re     !(10001000000000003      re     !(10010000000000003      re     !(10100000000000003      re     !(11000000000000003    / We neeL power of 2 that d32 <0^(i+            !(83      re     !(643      re     !(5123      re     !(ceil3      re     !(655363      re     !(5242883      re     !(83886083      re     !(671088643      re     !(5368709123      re     !(c5899345il3      re     !(687194767363      re     !(5497558138883      re     !(c7960930222083      re     !(703687441776643      re     !(5629499534213123      re     !(90071992547409923    / We nee100(e10(L power of 2 that d32 <0^(i+             !(80003      re     !(640003      re     !(5120003      re     !(ceil0003      re     !(655360003      re     !(5242880003      re     !(c3886080003      re     !(671088640003      re     !(5368709120003      re     !(c5899345il0003      re     !(687194767360003      re     !(5497558138880003      re     !(c7960930222080003