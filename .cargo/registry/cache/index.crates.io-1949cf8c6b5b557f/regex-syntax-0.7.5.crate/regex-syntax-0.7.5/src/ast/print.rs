/*!
This module provides a regular expression printer for `Ast`.
*/

use core::fmt;

use crate::ast::{
    self,
    visitor::{self, Visitor},
    Ast,
};

/// A builder for constructing a printer.
///
/// Note that since a printer doesn't have any configuration knobs, this type
/// remains unexported.
#[derive(Clone, Debug)]
struct PrinterBuilder {
    _priv: (),
}

impl Default for PrinterBuilder {
    fn default() -> PrinterBuilder {
        PrinterBuilder::new()
    }
}

impl PrinterBuilder {
    fn new() -> PrinterBuilder {
        PrinterBuilder { _priv: () }
    }

    fn build(&self) -> Printer {
        Printer { _priv: () }
    }
}

/// A printer for a regular expression abstract syntax tree.
///
/// A printer converts an abstract syntax tree (AST) to a regular expression
/// pattern string. This particular printer uses constant stack space and heap
/// space proportional to the size of the AST.
///
/// This printer will not necessarily preserve the original formatting of the
/// regular expression pattern string. For example, all whitespace and comments
/// are ignored.
#[derive(Debug)]
pub struct Printer {
    _priv: (),
}

impl Printer {
    /// Create a new printer.
    pub fn new() -> Printer {
        PrinterBuilder::new().build()
    }

    /// Print the given `Ast` to the given writer. The writer must implement
    /// `fmt::Write`. Typical implementations of `fmt::Write` that can be used
    /// here are a `fmt::Formatter` (which is available in `fmt::Display`
    /// implementations) or a `&mut String`.
    pub fn print<W: fmt::Write>(&mut self, ast: &Ast, wtr: W) -> fmt::Result {
        visitor::visit(ast, Writer { wtr })
    }
}

#[derive(Debug)]
struct Writer<W> {
    wtr: W,
}

impl<W: fmt::Write> Visitor for Writer<W> {
    type Output = ();
    type Err = fmt::Error;

    fn finish(self) -> fmt::Result {
        Ok(())
    }

    fn visit_pre(&mut self, ast: &Ast) -> fmt::Result {
        match *ast {
            Ast::Group(ref x) => self.fmt_group_pre(x),
            Ast::Class(ast::Class::Bracketed(ref x)) => {
                self.fmt_class_bracketed_pre(x)
            }
            _ => Ok(()),
        }
    }

    fn visit_post(&mut self, ast: &Ast) -> fmt::Result {
        use crate::ast::Class;

        match *ast {
            Ast::Empty(_) => Ok(()),
            Ast::Flags(ref x) => self.fmt_set_flags(x),
            Ast::Literal(ref x) => self.fmt_literal(x),
            Ast::Dot(_) => self.wtr.write_str("."),
            Ast::Assertion(ref x) => self.fmt_assertion(x),
            Ast::Class(Class::Perl(ref x)) => self.fmt_class_perl(x),
            Ast::Class(Class::Unicode(ref x)) => self.fmt_class_unicode(x),
            Ast::Class(Class::Bracketed(ref x)) => {
                self.fmt_class_bracketed_post(x)
            }
            Ast::Repetition(ref x) => self.fmt_repetition(x),
            Ast::Group(ref x) => self.fmt_group_post(x),
            Ast::Alternation(_) => Ok(()),
            Ast::Concat(_) => Ok(()),
        }
    }

    fn visit_alternation_in(&mut self) -> fmt::Result {
        self.wtr.write_str("|")
    }

    fn visit_class_set_item_pre(
        &mut self,
        ast: &ast::ClassSetItem,
    ) -> Result<(), Self::Err> {
        match *ast {
            ast::ClassSetItem::Bracketed(ref x) => {
                self.fmt_class_bracketed_pre(x)
            }
            _ => Ok(()),
        }
    }

    fn visit_class_set_item_post(
        &mut self,
        ast: &ast::ClassSetItem,
    ) -> Result<(), Self::Err> {
        use crate::ast::ClassSetItem::*;

        match *ast {
            Empty(_) => Ok(()),
            Literal(ref x) => self.fmt_literal(x),
            Range(ref x) => {
                self.fmt_literal(&x.start)?;
                self.wtr.write_str("-")?;
                self.fmt_literal(&x.end)?;
                Ok(())
            }
            Ascii(ref x) => self.fmt_class_ascii(x),
            Unicode(ref x) => self.fmt_class_unicode(x),
            Perl(ref x) => self.fmt_class_perl(x),
            Bracketed(ref x) => self.fmt_class_bracketed_post(x),
            Union(_) => Ok(()),
        }
    }

    fn visit_class_set_binary_op_in(
        &mut self,
        ast: &ast::ClassSetBinaryOp,
    ) -> Result<(), Self::Err> {
        self.fmt_class_set_binary_op_kind(&ast.kind)
    }
}

impl<W: fmt::Write> Writer<W> {
    fn fmt_group_pre(&mut self, ast: &ast::Group) -> fmt::Result {
        use crate::ast::GroupKind::*;
        match ast.kind {
            CaptureIndex(_) => self.wtr.write_str("("),
            CaptureName { ref name, starts_with_p } => {
                let start = if starts_with_p { "(?P<" } else { "(?<" };
                self.wtr.write_str(start)?;
                self.wtr.write_str(&name.name)?;
                self.wtr.write_str(">")?;
                Ok(())
            }
            NonCapturing(ref flags) => {
                self.wtr.write_str("(?")?;
                self.fmt_flags(flags)?;
                self.wtr.write_str(":")?;
                Ok(())
            }
        }
    }

    fn fmt_group_post(&mut self, _ast: &ast::Group) -> fmt::Result {
        self.wtr.write_str(")")
    }

    fn fmt_repetition(&mut self, ast: &ast::Repetition) -> fmt::Result {
        use crate::ast::RepetitionKind::*;
        match ast.op.kind {
            ZeroOrOne if ast.greedy => self.wtr.write_str("?"),
            ZeroOrOne => self.wtr.write_str("??"),
            ZeroOrMore if ast.greedy => self.wtr.write_str("*"),
            ZeroOrMore => self.wtr.write_str("*?"),
            OneOrMore if ast.greedy => self.wtr.write_str("+"),
            OneOrMore => self.wtr.write_str("+?"),
            Range(ref x) => {
                self.fmt_repetition_range(x)?;
                if !ast.greedy {
                    self.wtr.write_str("?")?;
                }
                Ok(())
            }
        }
    }

    fn fmt_repetition_range(
        &mut self,
        ast: &ast::RepetitionRange,
    ) -> fmt::Result {
        use crate::ast::RepetitionRange::*;
        match *ast {
            Exactly(x) => write!(self.wtr, "{{{}}}", x),
            AtLeast(x) => write!(self.wtr, "{{{},}}", x),
            Bounded(x, y) => write!(self.wtr, "{{{},{}}}", x, y),
        }
    }

    fn fmt_literal(&mut self, ast: &ast::Literal) -> fmt::Result {
        use crate::ast::LiteralKind::*;

        match ast.kind {
            Verbatim => self.wtr.write_char(ast.c),
            Meta | Superfluous => write!(self.wtr, r"\{}", ast.c),
            Octal => write!(self.wtr, r"\{:o}", u32::from(ast.c)),
            HexFixed(ast::HexLiteralKind::X) => {
                write!(self.wtr, r"\x{:02X}", u32::from(ast.c))
            }
            HexFixed(ast::HexLiteralKind::UnicodeShort) => {
                write!(self.wtr, r"\u{:04X}", u32::from(ast.c))
            }
            HexFixed(ast::HexLiteralKind::UnicodeLong) => {
                write!(self.wtr, r"\U{:08X}", u32::from(ast.c))
            }
            HexBrace(ast::HexLiteralKind::X) => {
                write!(self.wtr, r"\x{{{:X}}}", u32::from(ast.c))
            }
            HexBrace(ast::HexLiteralKind::UnicodeShort) => {
                write!(self.wtr, r"\u{{{:X}}}", u32::from(ast.c))
            }
            HexBrace(ast::HexLiteralKind::UnicodeLong) => {
                write!(self.wtr, r"\U{{{:X}}}", u32::from(ast.c))
            }
            Special(ast::SpecialLiteralKind::Bell) => {
                self.wtr.write_str(r"\a")
            }
            Special(ast::SpecialLiteralKind::FormFeed) => {
                self.wtr.write_str(r"\f")
            }
            Special(ast::SpecialLiteralKind::Tab) => self.wtr.write_str(r"\t"),
            Special(ast::SpecialLiteralKind::LineFeed) => {
                self.wtr.write_str(r"\n")
            }
            Special(ast::SpecialLiteralKind::CarriageReturn) => {
                self.wtr.write_str(r"\r")
            }
            Special(ast::SpecialLiteralKind::VerticalTab) => {
                self.wtr.write_str(r"\v")
            }
            Special(ast::SpecialLiteralKind::Space) => {
                self.wtr.write_str(r"\ ")
            }
        }
    }

    fn fmt_assertion(&mut self, ast: &ast::Assertion) -> fmt::Result {
        use crate::ast::AssertionKind::*;
        match ast.kind {
            StartLine => self.wtr.write_str("^"),
            EndLine => self.wtr.write_str("$"),
            StartText => self.wtr.write_str(r"\A"),
            EndText => self.wtr.write_str(r"\z"),
            WordBoundary => self.wtr.write_str(r"\b"),
            NotWordBoundary => self.wtr.write_str(r"\B"),
        }
    }

    fn fmt_set_flags(&mut self, ast: &ast::SetFlags) -> fmt::Result {
        self.wtr.write_str("(?")?;
        self.fmt_flags(&ast.flags)?;
        self.wtr.write_str(")")?;
        Ok(())
    }

    fn fmt_flags(&mut self, ast: &ast::Flags) -> fmt::Result {
        use crate::ast::{Flag, FlagsItemKind};

        for item in &ast.items {
            match item.kind {
                FlagsItemKind::Negation => self.wtr.write_str("-"),
                FlagsItemKind::Flag(ref flag) => match *flag {
                    Flag::CaseInsensitive => self.wtr.write_str("i"),
                    Flag::MultiLine => self.wtr.write_str("m"),
                    Flag::DotMatchesNewLine => self.wtr.write_str("s"),
                    Flag::SwapGreed => self.wtr.write_str("U"),
                    Flag::Unicode => self.wtr.write_str("u"),
                    Flag::CRLF => self.wtr.write_str("R"),
                    Flag::IgnoreWhitespace => self.wtr.write_str("x"),
                },
            }?;
        }
        Ok(())
    }

    fn fmt_class_bracketed_pre(
        &mut self,
        ast: &ast::ClassBracketed,
    ) -> fmt::Result {
        if ast.negated {
            self.wtr.write_str("[^")
        } else {
            self.wtr.write_str("[")
        }
    }

    fn fmt_class_bracketed_post(
        &mut self,
        _ast: &ast::ClassBracketed,
    ) -> fmt::Result {
        self.wtr.write_str("]"fmt_class_bracketed_post(
ted_post(
        &mut self,
        lfstr("-"),
                FlagsItemKind::Flag(ref flag) => match *flag {
          ast::RepetitionRange::*;
        match *ast {
   h *flag {
          y(x) => write!(self.wtr, "{{{}}}", x),Iint sec     FlagsItemKind::Flag(ref&&   }
        Ok(Differen   },
            }?;
    - flag) => match *SymmetricDifferen   },
            }?;
    ~~ut self, ast: &ast::SetFlags) ->=> self.fmt{
        use crate::a  negatedepetitionRange::*;
        match *ast {
   h *flated: falstLine => self.wtr.write_str("^"),
      e,
  _str("[^")
     }

    fn fmt_set_flags(&D   }
        Ok(Di
  _}

    fn fmt_set_flags(&dind::LineFeed) =>     str("[^")
     }

    fn fmt_set_flags(&Sind::LineFeed) =>     }

    fn fmt_set_flags(&ste_str(r"\b"),
      str("[^")
     }

    fn fmt_set_flags(&Wte_str(r"\b"),
      }

    fn fmt_set_flags(&wut self, ast: &ast::SetFlags) ->=> sel.fmt_c{
        use crate::a  neg     epetitionRange::*;
        match *ast {
   h *flrue,
      tLine => self.wtr.write_str("^"),
            str("[^")
     }

    fn fmt_set_flag         Some,("^"),
            }

    fn fmt_set_flag        Some,("^"),
        pha str("[^")
     }

    fn fmt_set_flag      phaSome,("^"),
        pha }

    fn fmt_set_flag     phaSome,("^"),
            str("[^")
     }

    fn fmt_set_flag         Some,("^"),
            }

    fn fmt_set_flag        Some,("^"),
      Blank str("[^")
     }

    fn fmt_set_flag    blankSome,("^"),
      Blank }

    fn fmt_set_flag   blankSome,("^"),
      Cntrl str("[^")
     }

    fn fmt_set_flag    cntrlSome,("^"),
      Cntrl }

    fn fmt_set_flag   cntrlSome,("^"),
      e,
  _str("[^")
     }

    fn fmt_set_flag    d,
  Some,("^"),
      e,
  _}

    fn fmt_set_flag   d,
  Some,("^"),
      Graph_str("[^")
     }

    fn fmt_set_flag    graphSome,("^"),
      Graph_}

    fn fmt_set_flag   graphSome,("^"),
      Lower_str("[^")
     }

    fn fmt_set_flag    lowerSome,("^"),
      Lower_}

    fn fmt_set_flag   lowerSome,("^"),
      he wristr("[^")
     }

    fn fmt_set_flag    tr: WSome,("^"),
      he wri}

    fn fmt_set_flag   tr: WSome,("^"),
      huncristr("[^")
     }

    fn fmt_set_flag    tuncrSome,("^"),
      huncri}

    fn fmt_set_flag   tuncrSome,("^"),
      >     str("[^")
     }

    fn fmt_set_flag         Some,("^"),
      >     }

    fn fmt_set_flag        Some,("^"),
      Upper_str("[^")
     }

    fn fmt_set_flag    upperSome,("^"),
      Upper_}

    fn fmt_set_flag   upperSome,("^"),
           str("[^")
     }

    fn fmt_set_flag    w   Some,("^"),
           }

    fn fmt_set_flag   w   Some,("^"),
      Xd,
  _str("[^")
     }

    fn fmt_set_flag    xd,
  Some,("^"),
      Xd,
  _}

    fn fmt_set_flag   xd,
  Some,("^"),
  : &ast::SetFlags) ->=> selfmt_clas{
        use crate::a  neg       epetitionRange::*;
        match *ast {
   h *fl        })),
tLine => sematch *ast {
   h *fl             y(x) tr.write_str("[^")
        } else {
            self.wtr.estE&mut self, as
        }
    }

    fn fmt_class_brack    Tet_class_bracketed_prelf.wtr.write_str("^"),
                c)Meta | Superfluous => wr\{:o}", u32::fro      ion_range(tLeast(x) => write!(self.wtr, "{{{},}}", x)assUnicodeOp               let sta   l }))
s_with_p { "(?P<" } elsetLeast(x) => write!(se=self.wtet sta }))
 flags) => {
                ssUnicodeOp               let sta   l }))
s_with_p { "(?P<" } elsetLeast(x) => write!(se:self.wtet sta }))
 flags) => {
                ssUnicodeOp                  let sta   l }))
s_with_p { "(?P<" } elsetLeast(x) => write!(se!=self.wtet sta }))
 flags) => {
           }{
    wtr: Wcfg(nore)]
modracter _p { "matcalloc::ents
/::t self) tr.wrmatch *ast {
        ::Pwat
 the giv) tr.wrmatcs),
 y(x) tr.wrspac  }
ly.
(/// `craentrse().is_ok(c  }
ly.
     (|b| b, /// `trailing `-` ispac  }
ly.
     <F>(
   f: F, /// `craentrfor Wrble ().is_ok(F: FnMult {
  Pwat
 the givepeti {
  Pwat
 the giv "{{{}       [45]\d{{
  Note tha= Pwat
 the given `Ast_class_braft {
  Note tht_class_bra]\d{wtr,= Note th` to the       /// `t       (     assert_eq!({
  iginal f=/ Print en `Ast_class_braeq!({
  dtr,= Snts
/:: `Ast_class_bra   Print   Pr")?;
,i {
  dtrt       (   ").parse(),
       /// `, dtrt() {
        assert_eq!(
      Prmt::Resulrse().is_ok(c  }
ly.
("alass(), Nonec  }
ly.
(   [lass(), Nonec  }
ly.
     (|b| b.o(ast(sert)   }
141lass(), Nonec  }
ly.
(   x61lass(), Nonec  }
ly.
(   x7Flass(), Nonec  }
ly.
(   u0061lass(), Nonec  }
ly.
(   U      61lass(), Nonec  }
ly.
(   x{61}lass(), Nonec  }
ly.
(   x{7F}lass(), Nonec  }
ly.
(   u{61}lass(), Nonec  }
ly.
(   U{61}lasss(), Nonec  }
ly.
(   alass(), Nonec  }
ly.
(   flass(), Nonec  }
ly.
(   tlass(), Nonec  }
ly.
(   nlass(), Nonec  }
ly.
(   rlass(), Nonec  }
ly.
(   vlass(), Nonec  }
ly.
(    )
mt_a() {
        assert_eq!(
      Prmdotlrse().is_ok(c  }
ly.
("._a() {
        assert_eq!(
      Prmcvisit_rse().is_ok(c  }
ly.
("ablass(), Nonec  }
ly.
("abcdelass(), Nonec  }
ly.
("a(bcd)ef_a() {
        assert_eq!(
      Prm       self_rse().is_ok(c  }
ly.
("a|blass(), Nonec  }
ly.
("a|b|c|d|elass(), Nonec  }
ly.
("|a|b|c|d|elass(), Nonec  }
ly.
("|a|b|c|d|e|lass(), Nonec  }
ly.
("a(b|c|d)|e|f_a() {
        assert_eq!(
      Prm  fmt::Resrse().is_ok(c  }
ly.
(r"^lass(), Nonec  }
ly.
(  $lass(), Nonec  }
ly.
(   Alass(), Nonec  }
ly.
(   zlass(), Nonec  }
ly.
(   blass(), Nonec  }
ly.
(   B_a() {
        assert_eq!(
      Prm -> fmt::Rerse().is_ok(c  }
ly.
("a?lass(), Nonec  }
ly.
("a??lass(), Nonec  }
ly.
("a*lass(), Nonec  }
ly.
("a*?lass(), Nonec  }
ly.
("a+lass(), Nonec  }
ly.
("a+?lass(), Nonec  }
ly.
("a{5}lass(), Nonec  }
ly.
("a{5}?lass(), Nonec  }
ly.
("a{5,}lass(), Nonec  }
ly.
("a{5,}?lass(), Nonec  }
ly.
("a{5,10}lass(), Nonec  }
ly.
("a{5,10}?_a() {
        assert_eq!(
      Prmesult rse().is_ok(c  }
ly.
("(?i)lass(), Nonec  }
ly.
("(?-i)lass(), Nonec  }
ly.
("(?s-i)lass(), Nonec  }
ly.
("(?-si)lass(), Nonec  }
ly.
("(?siUmux)_a() {
        assert_eq!(
      Prmfmt:: rse().is_ok(c  }
ly.
("(?i:a)lass(), Nonec  }
ly.
("(?P<foo>a)lass(), Nonec  }
ly.
("(?<foo>a)lass(), Nonec  }
ly.
("(a)_a() {
        assert_eq!(
      Prmrser(r"\d").parse_c  }
ly.
(  [abc]lass(), Nonec  }
ly.
(  [a-z]lass(), Nonec  }
ly.
(  [^a-z]lass(), Nonec  }
ly.
(  [a-z0-9]lass(), Nonec  }
ly.
(  [-a-z0-9]lass(), Nonec  }
ly.
(  [-a-z0-9]lass(), Nonec  }
ly.
(  [a-z0-9---]lass(), Nonec  }
ly.
(  [a-z&&m-n]lass(), Nonec  }
ly.
(  [[a-z&&m-n]]lass(), Nonec  }
ly.
(  [a-z--m-n]lass(), Nonec  }
ly.
(  [a-z~~m-n]lass(), Nonec  }
ly.
(  [a-z[0-9]]lass(), Nonec  }
ly.
(  [a-z[^0-9]]lasss(), Nonec  }
ly.
(   dlass(), Nonec  }
ly.
(   Dlass(), Nonec  }
ly.
(   slass(), Nonec  }
ly.
(   Slass(), Nonec  }
ly.
(   wlass(), Nonec  }
ly.
(   Wlasss(), Nonec  }
ly.
(  [       So]lass(), Nonec  }
ly.
(  [[       So]lass(), Nonec  }
ly.
(  [[   phaSo]lass(), Nonec  }
ly.
(  [[    phaSo]lass(), Nonec  }
ly.
(  [[      So]lass(), Nonec  }
ly.
(  [[       So]lass(), Nonec  }
ly.
(  [[ blankSo]lass(), Nonec  }
ly.
(  [[  blankSo]lass(), Nonec  }
ly.
(  [[ cntrlSo]lass(), Nonec  }
ly.
(  [[  cntrlSo]lass(), Nonec  }
ly.
(  [[ d,
  So]lass(), Nonec  }
ly.
(  [[  d,
  So]lass(), Nonec  }
ly.
(  [[ graphSo]lass(), Nonec  }
ly.
(  [[  graphSo]lass(), Nonec  }
ly.
(  [[ lowerSo]lass(), Nonec  }
ly.
(  [[  lowerSo]lass(), Nonec  }
ly.
(  [[ tr: WSo]lass(), Nonec  }
ly.
(  [[  tr: WSo]lass(), Nonec  }
ly.
(  [[ tuncrSo]lass(), Nonec  }
ly.
(  [[  tuncrSo]lass(), Nonec  }
ly.
(  [[      So]lass(), Nonec  }
ly.
(  [[       So]lass(), Nonec  }
ly.
(  [[ upperSo]lass(), Nonec  }
ly.
(  [[  upperSo]lass(), Nonec  }
ly.
(  [[ w   So]lass(), Nonec  }
ly.
(  [[  w   So]lass(), Nonec  }
ly.
(  [[ xd,
  So]lass(), Nonec  }
ly.
(  [[  xd,
  So]lasss(), Nonec  }
ly.
(   pLlass(), Nonec  }
ly.
(   PLlass(), Nonec  }
ly.
(   p{L}lass(), Nonec  }
ly.
(   P{L}lass(), Nonec  }
ly.
(   p{X=Y}lass(), Nonec  }
ly.
(   P{X=Y}lass(), Nonec  }
ly.
(   p{X:Y}lass(), Nonec  }
ly.
(   P{X:Y}lass(), Nonec  }
ly.
(   p{X!=Y}