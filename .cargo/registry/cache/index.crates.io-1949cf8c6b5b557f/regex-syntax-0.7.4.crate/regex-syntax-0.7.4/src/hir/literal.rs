/*!
Provides literal extraction from `Hir` expressions.

An [`Extractor`] pulls literals out of [`Hir`] expressions and returns a
[`Seq`] of [`Literal`]s.

The purpose of literal extraction is generally to provide avenues for
optimizing regex searches. The main idea is that substring searches can be an
order of magnitude faster than a regex search. Therefore, if one can execute
a substring search to find candidate match locations and only run the regex
search at those locations, then it is possible for huge improvements in
performance to be realized.

With that said, literal optimizations are generally a black art because even
though substring search is generally faster, if the number of candidates
produced is high, then it can create a lot of overhead by ping-ponging between
the substring search and the regex search.

Here are some heuristics that might be used to help increase the chances of
effective literal optimizations:

* Stick to small [`Seq`]s. If you search for too many literals, it's likely
to lead to substring search that is only a little faster than a regex search,
and thus the overhead of using literal optimizations in the first place might
make things slower overall.
* The literals in your [`Seq`] shouldn't be too short. In general, longer is
better. A sequence corresponding to single bytes that occur frequently in the
haystack, for example, is probably a bad literal optimization because it's
likely to produce many false positive candidates. Longer literals are less
likely to match, and thus probably produce fewer false positives.
* If it's possible to estimate the approximate frequency of each byte according
to some pre-computed background distribution, it is possible to compute a score
of how "good" a `Seq` is. If a `Seq` isn't good enough, you might consider
skipping the literal optimization and just use the regex engine.

(It should be noted that there are always pathological cases that can make
any kind of literal optimization be a net slower result. This is why it
might be a good idea to be conservative, or to even provide a means for
literal optimizations to be dynamically disabled if they are determined to be
ineffective according to some measure.)

You're encouraged to explore the methods on [`Seq`], which permit shrinking
the size of sequences in a preference-order preserving fashion.

Finally, note that it isn't strictly necessary to use an [`Extractor`]. Namely,
an `Extractor` only uses public APIs of the [`Seq`] and [`Literal`] types,
so it is possible to implement your own extractor. For example, for n-grams
or "inner" literals (i.e., not prefix or suffix literals). The `Extractor`
is mostly responsible for the case analysis over `Hir` expressions. Much of
the "trickier" parts are how to combine literal sequences, and that is all
implemented on [`Seq`].
*/

use core::{cmp, mem, num::NonZeroUsize};

use alloc::{vec, vec::Vec};

use crate::hir::{self, Hir};

/// Extracts prefix or suffix literal sequences from [`Hir`] expressions.
///
/// Literal extraction is based on the following observations:
///
/// * Many regexes start with one or a small number of literals.
/// * Substring search for literals is often much faster (sometimes by an order
/// of magnitude) than a regex search.
///
/// Thus, in many cases, one can search for literals to find candidate starting
/// locations of a match, and then only run the full regex engine at each such
/// location instead of over the full haystack.
///
/// The main downside of literal extraction is that it can wind up causing a self.ranges[oldiund for char {
 ;
           self.ranges.push(range)eneral, loifference(&intersection)
    }
nd the
 for char {
 ;
        fn case_fold_s one           let range = Self::crenceomputs2, other.lower());
 old_s one   }
nd the
 for char {
 ;
        fn case   ber_width == 0 {
  }    let range =            s  make
any kin and just use the regex engine.

(It xt
          _s oend {
            // If we've adde  the literal optime.
    ///
    /// Thisu       'n search for literals to find candi .
      
i `ecked_se an imla memory, buuts2, ock.
//n.

Finally,  sel            / 
i ` over the  /// The i_s "t might b."   let ra#coro/
 al cas  let lly, search.
///
/// Thus, in mattoo alSet<lro/
 al cas  let lly,, we necessaerallyss thach.
// the tto obsSoximate frequento find ca`\bquux\b`de  th     /tor<Item =ach.
ppend
     umber(i +e fctputs2, ot`quux`. Hasevl opverla, itc);
   `, tk.
///
`quux`oduce fewer   _s oend  a_fold_simnd cdth == 0 {
  } `\bquux\b`tk.
/*}",pverloend  `ZquuxZ&othyervals.mputed `quux`o*}",pverlfa, itownsrilytk.
/t mutalassesarch.
ss
r`]. N}    uence.
    rar if thlro/
 al cas  let lly,{
      loend  oake
an art fctputs2, ot*}",pverlow entirely r prnto find ca ber_wi        bsSoke
an ideaahe t/ The        er of candidtion)
   optn inective      al   // 
mut seteral extractiore alced: posstnesen idegntoIterato by an order
///
i :    // Sinuts2, ock.
/// Is theer
///
i rt fctpals to f  // rane.
    rar if thf, ihlro/
 al cake
an  let lly,{
      l example, for n-g Stri-is
better. A sequfold_os 
mut f.ranges[e  th alced:ly oend  a_ example, for n-g
        // T   // range(selfd cd   let ra#cE0 {
  l extractioi ` ionssions.
/Thus, i fastere to find ca```tk.
/ted lfd c_    ush farch f.rangeh f, vec::Ve,
///
///, ion},      ls  find ca  fnarc =      (r"(a|b|c)(x|y|z)[A-Z]+foo")?;nd ca  fngo  le, vec::VeantifierThus, i(&arc);nd ca
}

et<l.ranges[
    /// and */
t fct"s.mputed nions  // Tma mech // 
mut ut seter{
 ;te.nd ca  fnrror force thq        it c[nd caaaaaL.rangeh /
t fct("ax"),nd caaaaaL.rangeh /
t fct("ay"),nd caaaaaL.rangeh /
t fct("az"),nd caaaaaL.rangeh /
t fct("bx"),nd caaaaaL.rangeh /
t fct("by"),nd caaaaaL.rangeh /
t fct("bz"),nd caaaaaL.rangeh /
t fct("cx"),nd caaaaaL.rangeh /
t fct("cy"),nd caaaaaL.rangeh /
t fct("cz"),nd ca]);nd ca This test cror for,ngo );   let ra#cOk::upperBox<hat{
 d::      :} else>ertaid ca```tk.
tractioi ` ionssions.
/Thus, i metimee to find ca```tk.
/ted lfd c_    ush fnd caaaaaarch f.rangeh f, vec::Ve,
, vec::Kiower///
///, ion},nd caaaaa     ,nd cals  find ca  fnarc =      (r"foo|[A-Z]+bar")?;nd ca  fngo  le, vec::Veantifier mea(, vec::Kiow::SetimeerThus, i(&arc);nd ca
}
Some o'foo'egnts   _s oend  
 ;te,t case. (`f The i_t fctcessar'bar'nd ca
}
*}",pverl        }
     '[A-Z]+' isn't good;

uark     t fctcnd ca  fnrror force thq        it c[nd caaaaaL.rangeh t fct("foo"),nd caaaaaL.rangeh /
t fct("bar"),nd ca]);nd ca This test cror for,ngo );   let ra#cOk::upperBox<hat{
 d::      :} else>ertaid ca```t. This helps us avoid doing
    ///, vec::Ve        mea:
, vec::Kiowe     l

Ft_     ult = Pe     l

Ft_      ult = Pe     l

Ft_f.rangenumbult = Pe     l

Ft_totre it = Pe         , vec::Ve               int.set_lnd that i? Yes.  erlappi    algurmust case fsists of the rannd that i?to be roptrwise
//   algurexity self isn(None, None)`
is mostlyh t  mostier"oegntoto by an order
///valSet { ranges,d(1).u, vec::Ve       e("a{ vec::Ve       e("a     mea:
, vec::Kiow::Paster              l

Ft_     ul10              l

Ft_      ul10              l

Ft_f.rangenumbul100              l

Ft_totre i250,-> (Option<Self>, Option<SE becaun the  vec::Ve {
         tor<Item = I>> only run lSet { rangThus, i(&or litarch &tud       q> Self {
   bstring search tudKiow::*_end = selfoend  *     mea(Two ranges
    /E/ the|coro/x/issuethq  ber(i to   ///::L.rangeh t fct(vec![] overlapping or
L.range(arch L.range(astves.
* it is greater than the 
        /q) => *aorb = v,
    or
 hq  ber(i to   ///::L.rangeh t fct(es.
*ror:vec possible thatent(self) -> en sece_f.rangenumb{
      qssible thatent(self) qpl<'a, I> Iterator for InteC    (arch C    ::s isn't(astvcl* it is greater than the ) -> ehus, i_     _(upper)(cl* pl<'a, I> Iterator for InteC    (arch C    ::Bs.
*(astvcl* it is) -> ehus, i_     _es.
*(cl* verlapping or
R         (astv   it is) -> ehus, i_r         (asp verlapping or
Cap    (arch Cap    canoelf.is, .. }it is) -> ehus, i(.is verlapping or
Concat(astvarcsit iswo ranges a meas greater than the , vec::Kiow::Pastert is) -> ehus, i_ oncat(arcst it con,greater than the , vec::Kiow::Setimelf;e     l

Ft_f.rs, i_ oncat(arcst}i_ oncat(arcstAlges.e verlappiapping or{ges.push(range);
   Une cartimelf the sabled returnes[oldiu&IntervalSbe n-tor<               // Otheit union be n-tor<
   `, tk.
sf self.rck t it, th alced:               // OthLitera        ing ge///
/// The twon, iv);ndver2). isn't(astvcl* it is greater talges.e verls) -> ehus,   &self,
        other: &SelfSelf) -> (Ope      ive according tovec::Ve {
tractioi `n't posby an order
/// of erlappi    algurmust cet_lnd trily iactioi ` ionssiod each ionssios of the is);nd h
    /// athe
 ZeroUspossioi `nor` ionssioomputs2,  an oras  let  cmp::max(lowand thus probar};

/pend
ind candidate stfto be consers    // Sinuts2,    return (Some(se Mwisoputs2// S_y oen_stfto bes consists of the    `, tk.
sf se_fold_simpl, th alced:dering.
    i    algurmuSionssiosse vsfyause o    spossioi `d, then  an oras  let  cmp::max(lowand thus probar};

/pend
    ndidate stfto be consers    // Sinuts2,    return (Some(se  fctputs2tvals in noal extractifolded? Yo compute a sigh
    /// th alced:dering.
    i    algurmumut a, mnt Partio match, aof thei?ton co oend  a_fold_sun           returnmbul1let upperto be rocase fomp, seaFinall
// unwattcessractor`actioi h
    /// th ssios(is often lace

use cr

Final `pverl`(), uniccontains ?ton cotsushi): Fier"oegn Gse the chs   o itof
effects consists of the rangeton cose_fold_simple(ilded set.um rocase funoptimd at lterals (is often )memory, buuts2ermine
    use cr

Finalor<Item = I>>end =elf::Bound)ec::Ve       e("a resullf::u, vec::Ve       e("t(astvarcs=)ec::n negate(&mut 

        // Is the // If anmbul1/ Thus, ) -gthstfto bes consisteral extl`] tytrsectother.upperhas
// caused sle a netas
// caused sl`acceed way tombul1r {
     otsushi): Fier"oegts of the      t rangeton cothis
    /// set. That   *llot o       ie car`pverl`(   `\pL``n't pmossractof the rn se_fold_sican c becof how un` isn'se aner (someti
         tor<Ite   /// set. nge(selfd is
    /// set. That  a_foldid ca```tk.
y tombul1 aof thechar  rocassrc/had of ustol   2,    returnlf {
   / caused slow  line:of the rn smuch faster (sometor<Ite   /// set.     // set. re to find ca```tk.
/ted lfd c_    ush farch f, vec::Ve,
//<Ite   /// set.     ,nd cals  find[0-9]     <Ite   /// set.     A-Z]+foo")?;nd ca  fngo  le, vec::Vean// set.     k     t fctcnd c  fn[n// set.     "0", "1", "2", "3", "4", "5", "6", "7", "8", "9"se_fold_si]ean// set. ("bar"),nd ca]);nd ca This <Ite   /// set. re
  w    'spes,
soed? Yo m       nges`tk.
ya  ing gesl optim./// set.     A-Z]+foo")?;nd ca  fngo:Paster    (4go  le, vec::Vean// set.     k     t fctcnd cgeton co(ean// set. ("bar"),nd ca]);nd ca This <Ite   /// set. r for,ngo );   let ra#cOk::upperBox<hat{
 d// set.     // sm = I>>:Paster    (elf::Bound):Past = Pe   resullf::u, vec::Ve       e("t(ast:Paster    lf.rPastn negate(&mut 

        // Is the // If anmbul1/ Thus, 0    / locations   it is) steral extl`] tytrsrsection =trwisenge = Self::crenceompustoppproperty to be part ls to fire ful can wi tyge2)) =timie car`(abcde){50}`g
themo     returnioendast = ,r`(?:){1000000000}`rals tombul1/  *llot o the neem =ach   return ( it is) `n't poange2))ls iu the
 lyh t  mostier"oegntoto  to be part en
the  tombul1/revio   it is) steral acceed I> {     // topppr
          returnmbcomputelf::creer());t  ///
 po    {     //made' isn't go<Ite   /// set. nge(selfd is
    /// set. That d ca```tk.
trsrc/had of uso m        makt us I> { );
    et_lnd or<Ite   /// set.     // set. re to find ca```tk.
/ted lfd c_    ush farch f.rangeh f, vec::Ve,
//<Ite   /// set.     ,nd cals  find(abc){8}     <Ite   /// set.     A-Z]+foo")?;nd ca  fngo  le, vec::Vean// set.     k     t fctcnd c  fn["abcabcabcabcabcabcabcabc"]ean// set. ("bar"),nd ca]);nd ca This <Ite   /// set. re
  w    'spes,
soed? Yo m       nges`tk.
ya  ing gesl optim./// set.     A-Z]+foo")?;nd ca  fngo:Paste0     (4go  le, vec::Vean// set.     k     t fctcnd ca  fnrror fo// set.     t fct("ay"),nd caaabcabcabcabc")se_fold_si]ean// set. ("bar"),nd ca]);nd ca This <Ite   /// set. r for,ngo );   let ra#cOk::upperBox<hat{
 d// set.     // sm = I>>:Paste0     (elf::Bound):Past = Pe   resullf::u, vec::Ve       e("t(ast:Paste0     lf.rPastn negate(&mut 

        // Is the // If anmbul1/ Thus, maximum ) -gthstftn your [`Seent yotier"oegntoto  to be part ls to fire ful can wi tyge2)) =timie car`(abcde){5}{5}{5}{5}`raW     be part mpute ( it is) `an wind up`d, then fctpalat dg
//,d charallself.folded {
  it is) sty dispplid ca neee.
sf));  int.serence-orf ) -gths`5^4 than ted {625`ntoto  to be part en
the  tombul1/reviowind up caral acceed I> {     //made' isn't     e_fold_simput   *llothe  't pmrany cgo<Ite   /// set. nge(selfd is
    /// set. That d ca```tk.
trsrc/had of uso m        makt us I> { );
    et_lnd or<Ite   /// set.     // set. re to find ca```tk.
/ted lfd c_    ush farch f.rangeh f, vec::Ve,
//<Ite   /// set.     ,nd cals  find(abc){2}{2}{2}     <Ite   /// set.     A-Z]+foo")?;nd ca  fngo  le, vec::Vean// set.     k     t fctcnd c  fn["abcabcabcabcabcabcabcabc"]ean// set. ("bar"),nd ca]);nd ca This <Ite   /// set. re
  w    'spes,
soed? Yo m       nges`tk.
ya  ing gesl optim./// set.     A-Z]+foo")?;nd ca  fngo:Pasteent(self) ->14go  le, vec::Vean// set.     k     t fctcnd ca  fnrror fo// set.     t fct("ay"),nd caaabcabcabcabcab")se_fold_si]ean// set. ("bar"),nd ca]);nd ca This <Ite   /// set. r for,ngo );   let ra#cOk::upperBox<hat{
 d// set.     // sm = I>>:Pasteent(self) -> en secund):Past = Pe   resullf::u, vec::Ve       e("t(ast:Pasteent(self) -lf.rPastn negate(&mut 

        // Is the // If anmbul1/ Thus, 0    / locationswind up caral {     /   return (Some(self.cl to be part ls to fire ful aally , seaFinamely,
a can   // ea to be]s. Iher.upn// set.  // uner (someti
         toaW    elf>, Option<SE{    automaeaFinale_fold_sic   lcandidle]s. Iherti
   // uner (someti(ch.
// the tt`pverl`(nd cas_u32();
  ns ?ton co Fier"oegtby et_lnd o ) // uner (sometiaof the]s. If e_fold_simpded` peon-ndidle in a aalwellax) = (I::Bound::min_v// the tt`pab]{3}{3}`   if snd ca`\bquux\b`dorf ) -gths`51is_i2^9  // set. desp co e;
    fewer   it is) st line:ng
/// Thus,iombinrals tombul1e_fold_simput    For ot o  "cnges[ell" can   // ea tndidl chsg
///er (sometimes ::max(lowanir`]anonin smu// uner (sometor<Ite   /// set. nge(selfd is
    /// set. That  a_foldid ca```tk.reducea to be cmI> {    ing ge/d? Yo computsushi): Fier"oegts of theor<Ite   /// set.     // set. re to find ca```tk.
/ted lfd c_    ush farch f.rangeh f, vec::Ve,
//<Ite   /// set.     ,nd cals  findpab]{2}{2}     <Ite   /// set.     A-Z]+foo")?;nd ca  fngo  le, vec::Vean// set.     k     t fctcnd c  fn[n// set.     "aaaa", "aaab", "aaba", "aabb"se_fold_si    "abaa", "abab", "abba", "abbb"se_fold_si    "baaa", "baab", "baba", "babb"se_fold_si    "bbaa", "bbab", "bbba", "bbbb"se_fold_si]ean// set. ("bar"),nd ca]);nd ca This <Ite   /// set. re
st cet_lnd t cmI>        )ls bigd eachbigThis isly iactioi `canonicaet. re
wind up c 't p'pab]{2}{2}'.st_mutpes,
soed? Yo m   e too        16,onicaet. re
n_empty'   mostlytrumelfed Fix tNoeaFer" literarch. Therbquux\b`dorfonicaet. re
w -gths4ize ofmight barch cmI> {aal10rals to fibar'nd c// Sinuts2,    returne
    self. We  e tverhead o), Some(bmany cad? Yo m   tNoeaFer that allet. re
n_en  an orwind up`d, th Sinuts2, ock..low isn't  bar'nd c// y ar  t allet. re
ple,pppr
le t. Naoften ./// set.     A-Z]+foo")?;nd ca  fngo:Paste0    (10go  le, vec::Vean// set.     k     t fctcnd ca  fnrror fo// set.     t fct("ay"),nd caaaa")se_fold_si    t fct("ay"),nd caaab")se_fold_si    t fct("ay"),nd caaba")se_fold_si    t fct("ay"),nd caabb")se_fold_si]ean// set. ("bar"),nd ca]);nd ca This <Ite   /// set. r for,ngo );   let ra#cOk::upperBox<hat{
 d// set.     // sm = I>>:Paste0    ( en secund):Past = Pe   resullf::u, vec::Ve       e("t(ast:Paste0    /f.rPastn negate(&mut 

        // Is Ectioi `cSinuts2, oIntervalSet<I>)timelfenits falSr (sometimes be;
    e_fold_simpl,c   d HIR than a regex  uppeir`] d viae]sossq` isn't. is
    /// set. That d cr  iircul1leot union ]sossq` isn't h. Thethis ininuts2,    return     /tor<I     (n    loend  oas       &&Kiow::Setimelf  fn l:
{
    ty<> Self::BouHi<hatn lSet st =Is, i(&or litarch &t is greater t  /E/ the|coro/x/issuethq  ber(i to   ///::L.            leh
    }I> .ranges.split_last_m an orue());
`d, th Sinuts2, ock.(n    l al cake
]sossranges.split_las` isn't {    aabled .)

Yoo-op.ide of tvals in noust apectiow `a` range is `a-     }
 to        , the nebe;rly tNoewing is basi sets.
et issranges.split_las ?ton co Fier"oeg    // Otherwise, weqse !sei to  a].upper() < other.ra       }
        w at explicit examNoewing is']soss'i setsdisp}    le//
/// Th But we'.
            continuex        / th ssiosis often lathe negation to qas in thisossx/iq,  en secuno  le, ve::Ve   if pair[0] >= pair[1q

        // Is Ectioi `cSinuts2, oIntervalSet<I>)alges.e ver. is
    /// set. That d cr  iircul1leot union returnh. Thethis ins ?ton co Fier"oeg       &&Kiow::Sealges.e ver  fn l:
{
    ty<> Self::BouHi<hatt();
        if lower <= t =In = match s&or litarch &t is greater t  /E/ we're d            leh
    }I> .ranges.split_lasOb`dorrch'ter' rangeton cosm an orower2ves.
 returranges.split_lasoper Iher.un I> {    l1l    aabled elf.is_interranges.split_las ?ton co Fier"oeg.ide of l1 aof n an  ing ge/s and last.union(&rest[oldd cr -iircul1   // Otherwise, !weqse !ton co(e].upper() < other.ra       }
        w at explicit eo qas in thlone()/iq,  en secuno  le, ve::Ve   if pair[0] >= pair[1q

        // Is Ectioi `cSinuts2, oonswind up cIntervalSet<I>)   it is) xt `b` orrcrsection =t ranithet future : is
    /// set.   'a*'// s=> [sei to  ao ),nd caa")]/// set.   'a*?'/ s=> [,nd caa"), sei to  ao]/// set.   'a+'// s=> [sei to  ao]/// set.   'a{3}' s=> [,nd caaaao]/// set.   'a{3,5}s=> [sei to  aaao]/// set.  algurmust ck y vals ngin   ( '[Akine:nunge.
 most
*}",sei to 'iv);'i to 'n// set. (tsible,
swand tc1/ The;
    fewer. A sequfo.unwr oend  a_fold_self.folded {f<Self> is'a*'/ghe seus ins ?    lo'a'
      .
/// Icessaerallyse in ae_fold_simpPartifctpale car'ab*c'(), unicf.is_int[sei to  abo ),nd caaco]/// set. . A sequf line:lf::creer[`Literas[a];
 ctuin   .)

Ys
like/ th slgese_fold_simpPnn prov'a'       &&Kiow::Se   it is) -n lSet    : &
/ted
*(cl* vertch s&or litarch &t is greatwer2vas in th  le, vec   .. }i;g search tudKiow   ].upper() < oth
/ted
*(cl* ver {'\u{: 0 coul,`b` edyrch Cag or{ges.push(range);
   W cak'oul=1',wise, thrch    ,nd che l,heit un'a?' rages.push(range);
       retur  e t'a|'.sS o       .)man,n'a??' ra     retur  e ges.push(range);
   '|a'       // Otherwise, oul !erence(1nd);
    }

    /// Retutwer2v.
ine!sei to  a   }
        while a < drain_end {
  is greacessaet  /E/ the|coro/xthq  ber(i to   ///::L.          Otherwise, !b` edyd);
    }

    /// Retumem/ twap( en sewer2v,  en scessaa   }
        while a < drain_end {
 in thlone()/wer2v,  en scessaa  }
        w at explicit e
/ted
*(cl* ver {'\u{ coul:rence(ouldrch Cage, o   == oul  or{ges.push(range);
dd_uppero   > 0); _sic   lcd folvea < drain_end {
  is  cmI> than the 
        /q)      try_lf) -> Set:Paste0             _or      MAXa   }
        while is greater t  /E/ the|coro/xthq  ber(i to   ///::L.          Otherwis  le_ast, re  let (lo\u{ c:Pastnd);
    }

    /// Retue, weqse !sei to  a].upper() < other.ra += 1;
        }
        while          }
              o qas in thisossx/iq,  en sewer2v.nly if t   }
        while a < drain_end {
 if= Pe    try_lf) -\u{)ore wrwer || o   >  cmI> {     }
              o q.
ine!sei to  a   }
        while a < drain_end {
  qssible thatent(self) qpl<'a,
/ted
*(cl* ver {'\u{ ch Cag or{ges.push(range);
dd_uppero   > 0); _sic   lcd folvea < drain_end {
  is  cmI> than the 
        /q)      try_lf) -> Set:Paste0             _or      MAXa   }
        while is greater t  /E/ the|coro/xthq  ber(i to   ///::L.          Otherwis  le_ast, re  let (lo\u{ c:Pastnd);
    }

    /// Retue, weqse !sei to  a].upper() < other.ra += 1;
        }
        while          }
              o qas in thisossx/iq,  en sewer2v.nly if t   }
        while a < drain_end {
 o q.
ine!sei to  a   }
        while qssible thatent(self) qpl}

        // Is there arvalSet<I>)nteC   tiguous(his ininuts2, oonswind up ci  cmp::max(lowaguous(&psg
///his is.());
   aguous(&p)ls bigd iccontains ?ton cotsushi): Fier"oegn      &&Kiow::Setan the ) -> en lSet c{
   erator fornteC   tch s&or litarch &ts becaustan thoput_:Pastee ) -> ehus, the ranges have
     cnd cgeton co(ean// s        assert!(adgreater t  /E/ we're d            le    }hus> ehus, the ranges havlf {
    }r.ind c()..=r.ed = selfoend  *     {
 o q.
    thq  ber(      h)    &self,
        other: &Self,
  possible thatent(self) -> en sece_f.rangenum[1q

        // Is there arvalSet<I>) engiiguous(his ininuts2, oonswind up ci  cmpthe set.
  /e
    sg
///his is.());
   aguous(&p)ls bigd iccontains ?ton co Fier"oegn      &&Kiow::Setan this) ->n lSet c{
   erator fornteC tch s&or litarch &ts becaustan thoput_:Pasteis) -> ehu the ranges have
     cnd cgeton co(ean// s        assert!(adgreater t  /E/ we're d            le    }hus> ehus, the ranges havlf {b   }r.ind c()..=r.ed = selfoend  *     {
 o q.
    thq  ber(     b)    &self,
        other: &Self,
  possible thatent(self) -> en sece_f.rangenum[1q

        // Is  other.upper());valSet<I>)nteC   tiguousacceed wayupperto be rombul1l::max(lowe        literal s   int.sean thoput_:Pastee ) -> en lSet c{
   erator fornteC   tch sper2)
    }
}

pub en scou   }
0            le    }hus> ehus, the ranges hav));cou   >"t(ast:Paster    l, I> {
    type Item = &'his range, and the a < drain_endcou   +=}r.
               a < draincou   >"t(ast:Paster    

        // Is  other.upper());valSet<I>) engiiguousacceed wayupperto be rombul1l one_fold_simp    literal s   int.sean thoput_:Pasteis) ->n lSet c{
   erator fornteC tch sper2)
    }
}

pub en scou   }
0            le    }hus> ehus, the ranges hav));cou   >"t(ast:Paster    l, I> {
    type Item = &'his range, and the a < drain_endcou   +=}r.
               a < draincou   >"t(ast:Paster    

        // Is >, Option<Se]sossq` isn't (self.cloneto implemenfset(other)    if s /   return), Sinpperto be rombul1l. Ot weopti,e
ine `to 2`s ?ton co     ,sossqcmp::max(low ?ton co Fier"oegt{ );
`to 1`    int.setossxn lSet en sece1.setqDebuq2       etqtch s&or litarch &ts becq1.om_uetossf) ->buq2).om _or nough, |) -|
w - >"t(ast:Paste0    a  }
     {at explicit eo q2.
ine!seton co(ean// s        assert      }con,greater than the at(astvarcsit iswo rangesecq1.etossfndver2)>buq2), then this returns `None`.
   ecq1.etossfe twon,>buq2), then this     if add_upperecq1.
    .om _or his , |x| xcremt(ast:Paste0    a);&Self,
  possible thatent(self) -> en sece1_f.rangenum[1q1us(other) {
            reloneto implemenfset(other)    if s /n), Sinpperto be r   returnmbul1l. Ot weopti,e
ine `to 2`s ?ton co     u       re ?ton co Fier"oeg   return), S
`to 1`    int.sr.upper());
 en sece1.setqDebuq2       etqtch s&or litarch &ts becq1.om_ur.uppf) ->buq2).om _or nough, |) -|
w - >"t(ast:Paste0    a  }
     {at explicit e= othetr sufftrimbarch ch faster (sometior`]eeon) = laste
ineft explicit e= oroom   lemwisenge = Sations, it is possibwe';
  t we'rrimb    ft explicit e= oo compute l   d If iarchinuts2, ocsidee in a = laste }
 a goo.union(&rest[oldiwise becaunant yoton co Fier"oeg.iOt weopti,ety'   u     ), S.union(&rest[old ns ?ton co Fier"oegt Literal enmutasm an oust ap Lit to use aly.union(&rest[olddtopregex searches. The m  }I>.uppackathe negation tass
       it e= othedo = lkeep 4ce fewevals?oth//,dder
sa bitstftn  foses. The ft explicit e= oo   a {
 D    .
//m,fewer. A sequf    ower());mossractf rocaft explicit e= oewerTedd Ialgor, Sm[`Literasuppoeque  a_ e in the
hays());t ft explicit e= oo -gths4s thaeral're the= lpt
makral  locativals. Argu `Seqthis.union(&rest[oldd cif s /na tunenoteals amees ofeachl1/reemsr. A sequeix liy;t ft explicit e= odescribs. Aer(I'm     bsunnunge(lower2  find cr[a];
added ag ft explicit e= oabome(cu/   amuch faster (sometor<Itelic API.
         tvarcsit iswo ranges a meas greater than the , {     }
              o q1.keep_ probeis) ->4);     }
              o q2.keep_ probeis) ->4);     }
          }_ oncat(arcst it con,greater than the , {     }
              o q1.keep_     is) ->4);     }
              o q2.keep_     is) ->4);     }
          }  }
        w at explicit eo q1.deduanges.push(range)o q2.deduanges.push(range)s becq1     }
          .om_ur.uppf) ->buq2)     }
          .om _or nough, |) -|
w - >"t(ast:Paste0    a  }
         {at explicit eit eo q2.
ine!seton co(ean// s            other: &Self,
  poq1.lone()/iq2), then thidd_upperecq1.
    .om _or his , |x| xcremt(ast:Paste0    a);&Self,
  poq1us(other) {
    Applidsto be conservo -gthso m   e tvalSet<I>)Fier"oeg.i));nd */
t fct/// set. . A sequfd, th Sinuts2, oacceed d? Yo m  r {
        er1 &oo-op.      &&Kle thatent(self) -> ());
 inu       etqtcpper1, upper2). -lf.t(ast:Pasteent(self) -;
lic API.
         tvarcsit iswo rangeseas greater than the , veq.keep_ probeis) ->) - i_ oncat(arcstcon,greater than the , veq.keep_     is) ->) - i_ oncat(a}lf {
        maSelf::Bo  leu, vec::Ve      in sr Union ///valSet { ranges,d(1).u, vec::Vca  fngI> {
        sT   ive according ts{
tractioi `n't posby an order
/// of er al   // 
muet_lnd tches. The mive aer1`han th`train  }
xhausse a] :} else>ertaid ca```t. This e lotcon,greater Pe        ch for li     terals wind up cIntera    // T       mea:
, ve    ch for li     p, mem, num::NocIntera    // T    et.  algurmuNoewing is bcts consists of the b  p, mem, num::Noc. Hasetf.ranle_fold_si    and tc1vec,  For ot). ftc::{- probaimpl th alced:" ,{
        tsushi): Fimann a  T    han th   l

Ft_totre itater Pe         other.upper());vaer1ive aer1 bct`han th` varia_u32();
m = I>>is_teralsCaseFoldErrper2)
    }
}

prnto f!(*());
 eas greater than th)

        // Is  other.upper());vaer1ive aer1 bct`han th` varia_u32();
m = I>>is_p, memCaseFoldErrper2)
    }
}

prnto f!(*());
 eas greater tier mealf {
        maSelf::Bo  leu, vec:ater Pe    in sr Union ///valSet {Karcsit iswo raeas greater than thI> {
        sA vec::Ve {
         tor al   //At slower  an orau the carinin `d, then erarc For ot o   (Some(sel1l:ectiv a, mational exf l1 a  `, tk.
sf seinin `ccording ts{erloenat). aobaininectivprov
     itead of can  l seq. Wearby an order
/// of  "good" a. (WBut we
d_simp      `, tk.
sf self.r otioenr};

/// Extract,[e  th ls isideetartiner meopverla,deedepe.
sff  `tk.
yet slowe{aallf::creer(IntervalSr};

.)wnsrilytk.l extrasosun  carinin `d, then    l oldi itneaFina. A sequf    app a_,lly,{
 be dynamic erformanco be consers    // S slowem
Finas     fn case   bege =    Sinuts2, ock.`[s/m,fs/mopti]`c beco ftc::{- probaod" aanonifire dr {
  d::   s/mopti` aof n an  anges[e theer
inuts2, ock.
   retur  e t`[s/m]` T   // rangSty kin;
   quux\b`de  t   //At slowehaallygoo      let ran are dsty kinion)
 end   search for Ter
inuts2, o, thrc For ot)"anyed on [`S. W cakmp   happ /
 al cnin `    
d_si    eate yoton co Fizetions,string searmp   sty ktrily iinhibl1 aollnas
d_siInter[Akine:dd_umpis) stybome(wdynao compute a sust irhe rn erform"good" ally,{
l seq. Wearby an order
/// of n Gse the chs   o itof charanin `ds    //is
d_sifoo'egn search and the regex searinhibl1(se Ault. Tha_foldi;
   fctpal dyn
turn),   i'nd c//,  sertble to  e tapp a_ock.`[A-Za-z]`ZeroUsp   / caused sl
/e
     prov)ls big (     asos)ls narrow)ocase fue ful cher
   he rn sm52== 0 {    let rage = Sati(Noewing is bctd
muti The tf charaninqdd cif s /come
(low ?ton co    sstrictly nbyse cratllnaly to m l1l    haalno hard-C   d
turnmbul1l.)ch for Ter
inuts2, o, the fwe'ref litLiteraandignts   _n  ff  opase aneoo'e));

d_simpPar          noswind up caral aste
ituted nwand thus probar};

good;
Cit sves.
* ,rvalSr};

 n an  angese o theinput.min_v// the tt`pa&&b]` T   or Ter
inuts2, o, the f upper));f litLiteraandignat). aobaini/
t fct/et. . A sequfvprov
     itead of can d nwand thus probar};

 "good" a.T   // range(selfd cd   let ra#c a_foldid ca```tk. ch faster (someti of the    mifihe b  ple,pp /// Thisionssios    ctlx
searchw    e      /tor<I th alced:dering.
.
/Thus, i metimee to find ca```tk
/ted lfd c_   f.rangeh f, vnd caaaaa     greater t  /E/   fn&force thq "farm"L.rangeh t"sppli 2, "L.rangeh t"faraway"L.rangeh t"sppl "L.rangeh t"far "L.rangeh t"gap"L.rangeh t"sppli oft"L.rangeh t"spplaud"rangeh /
t fctveq.keep_ probeis) ->3/
t fctveq.ctlx
seeeis_ th alced:(:SetimeerTNoeaFer" lit'far'ppeiow  lrwise'spp'[`Literasngese omic erformf it's timeerT///
i rt Fier"oeg.idecrea extract caral o ftc::{- probaFimann a      timeerT, ot`qtr  rob  p   mifyy cad? YFix  
mut ut seter{
 ;te.nd ca  fnrror force thq        it c[nd caafaaL.rangeh    t fct("ay"),nd caaappL.rangeh    t fct("ay,nd caagap".rangeh /
t fct("bar"),nd ca]);nd caece_f.::      :} else>ertaid cEq,elf {
    . This helps u&or litarcld_s one  a, masearmp   seq.toto  to be part echar`ous.` al cninqarc For ot o d_oskier" pange = Sational exf l1h
    /// thllot oini/Inter[Akine:dd_umpis) stybome(s  cifice consers    // tsushi): Fie      e tha oini/ufftreen eraawer2 = orwind up`thods on d, th Sinu T    et.  algurmuNoewing is`ence( ///::Lwer  aalid      m `, tk.
sf self.r essaernqaupn// set.  r [`Seq`] .
*/
  fctpal dyn aof n an  anges.min_v// the tt`pa&&b]` T// set. .l extwaysini `n't p`ence( ///:"":Lw[`Litera m `, tk.
sf self.r[1q

     th     /tor<ItnIcessaerallys[`Literasngese oen  an or you mer. is
  r [`Seq: Opis) <Vec<t fct(">>   l

Ft_t&or litarcld_s other.utnIcessaerier"oegntoto  to be part AnIcessaerier"oegasngese o/ raner [`Seq`]    }
   a  `, tk.
sf sei   return (tpal dyn l1l    aof n an  anges.   re#[in  ne]r<Item = I>> e're dch s&or litarch &t&or l  r [`Seq: ence( ///::Ll}

        // Is Rch. Therbquux\b`dorfr. A sequfol Some(yoton co Fizes    cayh     /t_u32();
  norwind upntoto  to be part A Fier"oegt{ );ome(ton co Fizesctcessar'thllup` noust ap bome(cmp::max(lowa   / cauhan a ranco be consers    ique  titeral      nosnssid/ th ssio::max(lowes often las2, re a schar {
rment(serlfa,s/ Thus, ) -gthstfto be consers::max(low ?al cnin `knbinrlf.cl to be part ls to fire ful an ic For ot))
 eelps ment yo (tpal dyn et<l.)ls big"e_fold_simoire ful ic For ot)aherbquux\b`dorfr. A sequ.min_v// the tt`pA-Za-z]`Z be part echarer (sometimost
ls bigd // y lod c// irtwaycrx
s.e v ap.e uise be_u32();
      wiseng pre-computed banough, you migh[`Literairnh. Te
ine omicmn// set.   sseng pre-coms  er());ose locatlf.cl to be part Mwisy , gmaeaFinald thatmiterals to , e loer Ih ap d_oskier" pange = Sat.
  /e
    l1l    
use kier" pahatmhods ot weoptivide als in yoForoutha ind c
     th   ses./tor<Iis possible to medurine:lf::crenceompuly , seaFina::cdp::max(lowoff "goodke.   re#[in  ne]r<Item = I>>seton co(ech s&or litarch &t&or l  r [`Seq: ous.l}

        // Is Rch. Therbquux\b`do     /tor<Item =ach.wind upntoto #[in  ne]r<Item = I>>the|coro/xl t =t fct("dch s&or litarch &t&or l  r [`Seq: ence( ///: r :Ll}

        // Is Rch. Therbquux\b`dorfr    loend  oascIntervalSet<I>) engirallyssntoto #[in  ne]r<Item = I>>  f<I, B>(st =Is, i(&orr<Iteerloeitarch &tl:
{n s{
    ty<> Self:B>i_ oncat(aB: AsRef<[u8]>i_ onclitarch &tst.rn s_ l

Ft_map(|b| t fct("ay,nd cab.asfndfeh t.cols);n()

        // Is If      er1 &ton co Fier"oegd iccontaique  a, masaherbqli`dorfonicaet.        tor<Ite   /// set. Ter
ili`dos of the cayhe fwe'ref litLiteraandign          noswind up e_fold_simpParaste
ituted    seqr"oegntoto #[in  ne]r<Item = I>>wind up CaseFoldErrOpis) <&[t fct("]>e       e("t(ast:P     toasfd  
f()

        // Is Pusnt.serence-o self.r odsearmp   seqr"oegntoto  to be part Iarmp   seqr"oeg        ton cosm{
        er1 &oo-op.     i    algurmuS o      of
effectc::{os csetf.rad he r Seloarmp   seqr"oeg    be part m   retur  e to be conservet<I>produced is h, ot`d he.idecre 
fs);ns_u32();
  t slow's "sis  cke
   havirch  becau For ot o   , seaFina::cdpwoffZ be part ractor` tvals in n an  n yoSoke
an eate loneadjac ot)aLit    retur /// set. . A sequfd, th Siamo Fier"oegd _aLi_ed is heasy.
trsrtei `d, t. Nc
     th ndidntoto #[in  ne]r<Item = I>>
     en secund):Pt =t fct("dcpper1, upper2).ique=.
         t. A sequfit iswo rangesous.l=>os of ti_ oncat(arcstence(appien s.iqung or.iqui_ oncat(a};   assert    l1l.    ().om _or nough, |m| m == &lstnd);
    }

    s of tan// s        assert!l1l.
    lstn;

        // Is Mine 
/// nco be consers    //   seqr"oeg  isn't go<Ite   /// set. T    er1 &oo-op());vaer1seqr"oeg        ton contoto #[in  ne]r<Item = I>>
ine!sei to   en secundcpper1, upper2).ique=.
         t. A sequfit iswo rangesous.l=>os of ti_ oncat(arcstence(appien s.iqung or.iqui_ oncat(a};   assertcan win    !l1l. A s_en s, the ranges hav!l1.
ine!sei to  a   }
     }

        // Is there as;vaer1seqr"oeg is ins ?ton co Fier"oeg         /// set. T    er1 &oo-op());var
inuts2, ock. l   d If ton contoto #[in  ne]r<Item = I>>
ine!seton co( en secundcpper1, upp    t. A sequf=sous.;

        // Is Modify;vaer1seqr"oeg is      /ton<Se]sossq` isn't e.
    /i Is theertsushi): Fier"oegtet<I>or<Ite   /// set. Ter
]sossq` isn't (nhat i?end  se consers    //   seqr"oeg  dyn et< be part me,t caonal exf ln    loend  oas     no tchee  heor<Ite   /// set. Ter
end  oas     aabled ds./ter(Inter`ot we`,ize ofi);nd */    re d./// set. That  `] tys aollnas an icnd c// Sinuts2, with o Iher.retuerloentoto  to be part Iarmp   seqr"oeg    geton cosm{
        er1 &oo-opd icgard  sse ncwdynd// set.  ot we`ls to f  /(       //   andign   
end  oas         bsds./ter(Inted// set.  ot we`).i)); ot we`l   geton coIs thee   seqr"oeg    ton cosm{
       t.
  /e
     &oo-opd un          seqr"oeg s to f  /ao/ ra-o -gthso n [`S. It_u32();
 Literaandign    geton con sse nc ot we`l nmutasm     seqr"oeg,Is thee  tsushi): Fier"oegt   l1l    made' iton cothis
    /// set. L car the :: (Somd [`         attcess.
trsrdupli otpange = SatiSeelgurexity she ::srdup`]   lehowrsrdupli other.deequfol S.
/// Is thln    lonicaet.        tor<Ite   /// set. nge(selfd is
    /// set. That  a_foldid ca``basic reage/s anhowr
/// Is thln    le consers::max(low ?onsec or<Ite   /// set.     // set. re to find ca```tk
/ted lfd c_   f.rangeh f, vnd<Ite   /// set.     en sece1fctcnd ca  fnrror fo// set.     t fct("ay c[nd caaaaaL._fold_si    t fct("ay"),nd caabar")se_fold_si]ean// set.     en sece2fctcnd ca  fnrror fo// set.     t fct("ay"),nd caaZ&otaaL._fold_si    t fct("ay,nd caabaz")se_fold_si]ean// set. ecq1.etossfe twon,> en sece2is <Ite   /// set. re
st cend  oas     pullcd ome(le to 2.n// set. ("bar"),nd ence(0)Debuq2.
    )nd<Ite   /// set.     k     t fctcnd ca  fnrror fo// set.     t fct("ay"),nd caaaaaZ&otaaL._fold_si    t fct("ay,nd caaaaabaz")se_fold_si    t fct("ay"),nd caabar")se_fold_si]ean// set. ("bar"),nd ca]);nd caece1ean// set.     // set./// set. That  a_foldid ca``ion behavirce ncwdhar`ot we`l   ins ?ton cotsushi): Fier"oegn        /// set.     // set. re to find ca```tk
/ted lfd c_   f.rangeh f, vnd<Ite   /// set.     en sece1fctcnd ca  fnrror fo// set.     t fct("ay c[nd caaaaaL._fold_si    t fct("ay"),nd caabar")se_fold_si]ean// set.     en sece2fctcnd cgeton co(ean// set. ecq1.etossfe twon,> en sece2is <Ite   /// set. re
echarer 2    geton cosm]sossq` isn't          }
 anoust aofeac/// set. re
ennung o d_o  a, masearece1fsearinsn't go<Ite        k     t fctcnd ca  fnrror fo// set.     t fct("ay"),nd caaaaa")se_fold_si    t fct("ay"),nd caabar")se_fold_si]ean// set. ("bar"),nd ca]);nd caece1ean// set.     // set./// set. That  a_foldiimie carmic e */ olved each  ca``wdynahapp /
cwdharee  tsushi): Fier"oegts to f  /anecessaerallyss I  //   andignins ?ton co `ot we`tsushi): Fier"oegt nmutasm     seqr"oeg (bar'nd c// Scessaerallyse in al dyn
_fold_simpll      nosnsn co  th ssio):        /// set.     // set. re to find ca```tk
/ted lfd c_   f.rangeh f, vnd<Ite   /// set.     en sece1fctcnd ca  fnrror fo// set.     t fct("ay c[nd caaaaaL._fold_si    t fct("ay,nd caa"), low ?    le` ivokiossemn behavirc._fold_si    t fct("ay"),nd caabar")se_fold_si]ean// set.     en sece2fctcnd cgeton co(ean// set. ecq1.etossfe twon,> en sece2is <Ite   /// set. re
ece1fck..low iton co!n// set. ("bar"!(!ecq1.e !ton co(eean// set.     // set./// set. That  a_foldid ca``ion behavirce ncmp   seqr"oeg    geton con        /// set.     // set. re to find ca```tk
/ted lfd c_   f.rangeh f, vnd<Ite   /// set.     en sece1fctcnd cgeton co(ean// set.     en sece2fctcnd ca  fnrror fo// set.     t fct("ay,nd caaaaa")se_fold_si    t fct("ay"),nd caabar")se_fold_si]ean// set. ecq1.etossfe twon,> en sece2is <Ite   /// set. re
ece1frem f  /uning ged.n// set. ("bar"!(!ecq1.e !ton co(eean// set.    ce ofmight bo be consers    ece2far      re dr I> {aal    bsds./ter.n// set. ("bar"),nd ence(0)Debuq2.
    )nd<Ite        // s#[in  ne]r<Item = I>>etossfe twon,> en secund)ot we       etqtcpper1, upper2) lsts1d):Pts2)e=.
         tetossfp
//mble(ot we)fit iswo rangesous.l=>os of ti_ oncat(arcstence( lsts1d):Pts2)ng or lsts1d):Pts2)i_ oncat(a};   asserter2)newcap/f.rPts1.
    .se ui Ih a_mul lsts2.
    )nd<Itesertcan     win    mem/ replace lsts1d)Vec::ol S_capacity(newcap), the ranges hav));!    winore w to  a].upper() < other.rrPts1.
        win);     }
          s toins range, and the a < drain_endcan ot wewin    !l1l2> ehus, the ranges hav
}

pub en snewwin = t fct("ay,nd caVec::ol S_capacity(     }
              o   wino
     + ot wewino
                   //  t   }
        whilenewwin.chee  CaseFowin);     }
          newwin.chee  Caot wewin.          Otherwise, !ot wewinore w to  a].upper() < other.r    newwin.
ine!sei to  a   }
        while a < drain_end {
  Pts1.
    newwinean// s            other: &Self,
  !l1l2>ds./t(..);&Self,
  possideduanges.pus     // Is Modify;vaer1seqr"oeg is      /ton<Se]sossq` isn't e.
    /i Is te_fold_simpl,Fier"oegtet<I>,{erloenmpl,Fier"oegs     ts. If saheoften lah
    /// athe
 e nc th ssio. ractor` tva,Fier"oegt`ot we`l   *prepe.
ed*e_fold_simoi`poss` (aheoping e
an `ot we`l line:*app /
ed*imoi`poss` /t_u32();
  she ::etossfe twon,`])or<Ite   /// set. Ter
]sossq` isn't (nhat i?end  se consers    //   seqr"oeg  dyn et< be part me,t caonal exf ln    loend  oas     no tchee  heor<Ite   /// set. Ter
end  oas     aabled ds./ter(Inter`ot we`,ize ofi);nd */    re d./// set. That  `] tys aollnas an icnd c// Sinuts2, with o Iher.retuerloentoto  to be part Iarmp   seqr"oeg    geton cosm{
        er1 &oo-opd icgard  sse ncwdynd// set.  ot we`ls to f  /(       //   andign   
end  oas         bsds./ter(Inted// set.  ot we`).i)); ot we`l   geton coIs thee   seqr"oeg    ton cosm{
       t.
  /e
     &oo-opd un          seqr"oeg s to f  /ao/ ra-o -gthso n [`S. It_u32();
 Literaandign    geton con sse nc ot we`l nmutasm     seqr"oeg,Is thee  tsushi): Fier"oegt   l1l    made' iton cothis
    /// set. L car the :: (Somd [`         attcess.
trsrdupli otpange = SatiSeelgurexity she ::srdup`]   lehowrsrdupli other.deequfol S.
/// Is thln    lonicaet.        tor<Ite   /// set. nge(selfd is
    /// set. That  a_foldid ca``basic reage/s anhowr
/// Is thln    le consers::max(low ?onsec or<Ite   /// set.     // set. re to find ca```tk
/ted lfd c_   f.rangeh f, vnd<Ite   /// set.     en sece1fctcnd ca  fnrror fo// set.     t fct("ay c[nd caaaaaL._fold_si    t fct("ay"),nd caabar")se_fold_si]ean// set.     en sece2fctcnd ca  fnrror fo// set.     t fct("ay"),nd caaZ&otaaL._fold_si    t fct("ay,nd caabaz")se_fold_si]ean// set. ecq1.etossfndver2)> en sece2is <Ite   /// set. re
st cend  oas     pullcd ome(le to 2.n// set. ("bar"),nd ence(0)Debuq2.
    )nd<Ite   /// set.     k     t fctcnd ca  fnrror fo// set.     t fct("ay"),nd caaZ&otaaaaaL._fold_si    t fct("ay"),nd caabar")se_fold_si    t fct("ay,nd caabazaaaaaL._fold_si]ean// set. ("bar"),nd ca]);nd caece1ean// set.     // set./// set. That  a_foldid ca``ion behavirce ncwdhar`ot we`l   ins ?ton cotsushi): Fier"oegn        /// set.     // set. re to find ca```tk
/ted lfd c_   f.rangeh f, vnd<Ite   /// set.     en sece1fctcnd ca  fnrror fo// set.     t fct("ay c[nd caaaaaL._fold_si    t fct("ay"),nd caabar")se_fold_si]ean// set.     en sece2fctcnd cgeton co(ean// set. ecq1.etossfndver2)> en sece2is <Ite   /// set. re
echarer 2    geton cosm]sossq` isn't          }
 anoust aofeac/// set. re
ennung o d_o  a, masearece1fsearinsn't go<Ite        k     t fctcnd ca  fnrror fo// set.     t fct("ay"),nd caaaaa")se_fold_si    t fct("ay"),nd caabar")se_fold_si]ean// set. ("bar"),nd ca]);nd caece1ean// set.     // set./// set. That  a_foldiimie carmic e */ olved each  ca``wdynahapp /
cwdharee  tsushi): Fier"oegts to f  /anecessaerallyss I  //   andignins ?ton co `ot we`tsushi): Fier"oegt nmutasm     seqr"oeg (bar'nd c// Scessaerallyse in al dyn
_fold_simpll      nosnsn co often lac:        /// set.     // set. re to find ca```tk
/ted lfd c_   f.rangeh f, vnd<Ite   /// set.     en sece1fctcnd ca  fnrror fo// set.     t fct("ay c[nd caaaaaL._fold_si    t fct("ay,nd caa"), low ?    le` ivokiossemn behavirc._fold_si    t fct("ay"),nd caabar")se_fold_si]ean// set.     en sece2fctcnd cgeton co(ean// set. ecq1.etossfndver2)> en sece2is <Ite   /// set. re
ece1fck..low iton co!n// set. ("bar"!(!ecq1.e !ton co(eean// set.     // set./// set. That  a_foldid ca``ion behavircewdharee   seqr"oeg    geton con        /// set.     // set. re to find ca```tk
/ted lfd c_   f.rangeh f, vnd<Ite   /// set.     en sece1fctcnd cgeton co(ean// set.     en sece2fctcnd ca  fnrror fo// set.     t fct("ay,nd caaaaa")se_fold_si    t fct("ay"),nd caabar")se_fold_si]ean// set. ecq1.etossfndver2)> en sece2is <Ite   /// set. re
ece1frem f  /uning ged.n// set. ("bar"!(!ecq1.e !ton co(eean// set.    ce ofmight bo be consers    ece2far      re dr I> {aal    bsds./ter.n// set. ("bar"),nd ence(0)Debuq2.
    )nd<Ite        // s#[in  ne]r<Item = I>>etossfndver2)> en secund)ot we       etqtcpper1, upper2) lsts1d):Pts2)e=.
         tetossfp
//mble(ot we)fit iswo rangesous.l=>os of ti_ oncat(arcstence( lsts1d):Pts2)ng or lsts1d):Pts2)i_ oncat(a};   assert= othebasiche ch` iceed aalweedo    'etossfe twon,'  is basipo   ,
    continuexcepte dynamic eucausloop()k..low'ot we'[e theer
innausloop()k..lo
    continu'    'caonal'fibar'nd c'    ' a  `, tk.
sf sesionssios    'ot we'
    continu m `, tk.
sf self.r[1qr"oegt{gt{ar  e t*prepe.
*f self.r[ften lathe negatier2)newcap/f.rPts1.
    .se ui Ih a_mul lsts2.
    )nd<Iteserter2)seFowinue=.
em/ replace lsts1d)Vec::ol S_capacity(newcap),nd<Itesertcan (i, ot wewin)    !l1l2>ds./t(..).e loer Ies, the ranges havlf {    win    seFowinu> ehus, the ranges hav
}

));!    winore w to  a].upper() < other.rlit_last_mlf.r[ften ()k        l al cak= last'1/  *pe.
upper() < other.rlit_las noust apto   . Howdver,wise    bs{ar  e tkeep   . Bac/// s() < other.rlit_laswe (nhat{ar  e tkeep ini/
t fctm,feo   //  dupli other./// s() < other.rlit_las( 
mueupli other.)k.ok   Intera and tc1n sseper2p use a,/// s() < other.rlit_laseach{aat ful.);
    }

    /// Retue, i == 0].upper() < other.ra += 1;
rPts1.
        win.nly if t   }
        while          }
              s toins range, and thehile a < drain_end {
  is greanewwin = t fct("ay,nd caVec::ol S_capacity(     }
              ot wewino
     + o   wino
                   //  t   }
        whilenewwin.chee  Caot wewin.          Otherwisnewwin.chee  CaseFowin);     }
          e, !ot wewinore w to  a].upper() < other.r    newwin.
ine!sei to  a   }
        while a < drain_end {
  Pts1.
    newwinean// s            other: &Self,
  possideduanges.pus     // Is A helt(sefunit      re m `, tk.
sf self.r[ubequep
//mblevlf {bot tsushi): `etossfe twon,`s    `etossfndver2)`s I   to usr I> c   lc wayuppndid::max(lowofs ?ton co Fier"oeg vlf {bot i`poss`     `ot we`,iaalwelliaalennun ///_fold_simpParend  oascInter`ot we`l    ds./ter(ze ofi);// y a      re d    int.setossfp
//mble<'aatt();
     'a en secund
        ot we:  'a en setqD = match sOpis) <( 'a en sVec<t fct(">,  'a en sVec<t fct(">)>cpper1, upper2).iqu2e=.
     ot wet. A sequfit iswo rangesous.l=>o{ges.push(range);
   t_march. Haseternqas to f  /// Scessaerallysee theer
inu
() < other.rlit_laswe'r.unwrlyse ngese o thel.rangeh oduced ifollca``ioae(cmp::maxa` range is `a-  Haseternqavprov.low asosanges[e orwind upntoto e negation tass
       it elit_lasOt weopti,ety  proveate lgoodke:nunge an oust apinqthis.union(&rest[est[olddnuts2, ock.(n    l       // Otherwise, possimintent(self) ->) == ence(0)].upper() < other.r    *());fctcnd cgeton co(ean// s// s          returns `None`.
   Self,
  possi
ine!sei to  a   }
        while a < drain_end {
 iccontaous.;

      while a < drain_endence(appien s.iqung or.iqui_ oncat(a};   asserter2).iqu1e=.
         t. A sequfit iswo rangesous.l=>o{ges.push(range);
   t_mwe a      got apto odke:   e tvalS odsearmp   reucsei
() < other.rlit_laswpll  .iqu2eid ds./ter al cak= lSoke
an do    .lo.a < drain_end {
  Pts2>ds./t(..);&Self,
  _end {
 iccontaous.;

      while a < drain_endence(appien s.iqung or.iqui_ oncat(a};   assertence( lsts1d):Pts2)nus(other) {
         r1 bct`ot we`lFier"oegt ne tvai oinior<Ite   /// set. Ter
end  oas     aabled ds./ter(ome(le valSet<I>)`ot we`lFier"oegse_fold_size ofi);// y a  l line: (Somhe rn smins ?ton co Fier"oeg  That  `] tyse_fold_simpl,collna an icnd c// S`ot we`lFier"oegt nminot weas toche.     i    algurmuSthet conservdedualyse nyhe f `]lf mhe.iI2 = ordedualysehapp /
 _u32();
  norw ftc::{- probaimpl th alced:" ,{
        aFimann a  {     /   return For rvheor<Ite   /// set. nge(selfd is
    /// set. That  a_foldid ca``basic reagen        /// set.     // set. re to find ca```tk
/ted lfd c_  cndnd<Ite   /// set.     en sece1fctcnd c  fn&faaaa", "bar"]ean// set.     en sece2fctcnd c  fn&fabar", "Z&ota, "aaa"]ean// set. ecq1.r.upperen sece2is <Ite   /// set. re
st cend  oas     pullcd ome(le to 2.n// set. ("bar"),nd ence(0)Debuq2.
    )nd<Ite   /// set. Is Adjac ot)end  oas     deduaer aeach uppadjac ot)end  oas  nyhno tbe.n// set. ("bar"),nd end c  fn&faaaa", "bar", "Z&ota, "aaa"]ecaece1ean// set.     // set./// set. That  a_foldid ca``ioynao compute a sds./ter(Inter`ot we`ize ofwdhae_fold_simply a      neeg sarihatre d./// set./// set.     // set. re to find ca```tk
/ted lfd c_  cndnd<Ite   /// set.     en sece1fctcnd cgeton co(ean// set.    t?ton co Fier"oeg veate nosnsn co o -gth.n// set. ("bar"),nd Naid cecq1.
    )nd<Ite   /// set.     en sece2fctcnd c  fn&fabar", "Z&ota, "aaa"]ean// set. ecq1.r.upperen sece2is <Ite   /// set. re
ece1fck.    bsgeton coIs thece2fhaalb   /ds./ter.n// set. ("bar"),nd Naid cecq1.
    )nd<Ite    ("bar"),nd ence(0)Debuq2.
    )nd<Ite        // s#[in  ne]r<Item = I>>r.upperen secund)ot we       etqtcpper1, upper2).iqu2e=.
     ot wet. A sequfit iswo rangesous.l=>o{ges.push(range);
        archwl S. ns ?ton co Fier"oegt abled elf.iss_interranges.split_lit_las ?ton co Fier"oeg.
ne`.
   Self,
  possi
ine!seton co(ean// s// s        s of tan// s    hile a < drain_endence(appien s.iqung or.iqu>ds./t(..)i_ oncat(a};   asserter2).iqu1e=.
         t. A sequfit iswo rangesous.l=>os of ti_ oncat(arcstence(appien s.iqung or.iqui_ oncat(a};   assert Pts1.chee  C:Pts2);&Self,
  possideduanges.pus     // Is      r1 bct`ot we`lFier"oegt ne tvai oiniob  pplic c// S`ot we`tsushi): Fier"oegtynamic  you mer(le valS proba/ ra-o -gthso n [`S.lf.cl to be part ls to fire ful lf { For rvor<I th alced:deringaFimann a  {hI>)tiir`] ///_fold_simwomuch faster (someto    fn case   bnset(othtpal`(a||f)+aaa`_self.folded {and tc1/ th alced:deringa th ls inuts2, ock.`[ad thod t]`Z be part/// set. Ter
end  oas     aabled ds./ter(ome(le valSet<I>)`ot we`lFier"oegse_fold_size ofi);// y a  l line: (Somhe rn smins ?ton co Fier"oeg  That  `] tyse_fold_simpl,collna an icnd c// S`ot we`lFier"oegt nminot weas toche.uNoewing ie_fold_simpl,o compute a sds./ter(ze ofi);nd  (Someat  `]lf mheiaalwell`] .
*/_u32();
 Liharee   seqr"oeg ctcessar'     /toaa/ ra-o -gthso n [`S.lf.cl to be part Sthet conservdedualyse nyhe f `]lf mhe.iI2 = ordedualysehapp /
 _u32();
  norw ftc::{- probaimpl th alced:" ,{
        aFimann a  {     /   return For rvheor<Ite   /// set. nge(selfd is
    /// set. That  a_foldid ca``basic reagen        /// set.     // set. re to find ca```tk
/ted lfd c_  cndnd<Ite   /// set.     en sece1fctcnd c  fn&faaa, "a, "aa, "a]ean// set.     en sece2fctcnd c  fn&faaaa"]ean// set. ecq1.r.upp_rn s_ e're ren sece2is <Ite   /// set. re
st cend  oas     pullcd ome(le to 2.n// set. ("bar"),nd ence(0)Debuq2.
    )nd<Ite   tinu'aaa'imoss pplic e rn smece1ferloenmpl, probacessaerallyseoccurs.n// set. ("bar"),nd end c  fn&faaa, "aaa", "aa]ecaece1ean// set.     // set./// set. That  a_foldid ca``ioynao compute a sds./ter(Inter`ot we`ize ofwdhae_fold_simply a      neeg sarihatre d./// set./// set.     // set. re to find ca```tk
/ted lfd c_  cndnd<Ite   /// set.     en sece1fctcnd c  fn&faaaa", "bar"]ean// set.     en sece2fctcnd c  fn&fabar", "Z&ota, "aaa"]ean// set. ecq1.r.upp_rn s_ e're ren sece2is <Ite   /// set. re
ece1fhaalno / rane -gthso n [`Sl,heolno ppliclysehapp /
.n// set. ("bar"),nd end c  fn&faaaa", "bar"]ecaece1ean// set.    ce ofmight bno ppliclysehapp /
,rer 2        bsds./ter.n// set. ("bar"),nd ence(0)Debuq2.
    )nd<Ite        // s#[in  ne]r<Item = I>>r.upp_rn s_ e're ren secund)ot we       etqtcpper1, upper2).iqu2e=.ot wet. A sequoasfen s,_map(|.iqu|r.iqu>ds./t(..));   asserter2).iqu1e=.
         t. A sequfit iswo rangesous.l=>os of ti_ oncat(arcstence(appien s.iqung or.iqui_ oncat(a};   assert et, prob_cessaet 
      Pts1. l

Ft_ you mer(|m| more we're d)fit iswo rangesous.l=>os of ti_ oncat(arcstence(ing orii_ oncat(a};   asserter2).iqu2et 
      Pts2fit iswo rangesous.l=>o{ges.push(range);
   Noewing iswe a   (nhatvals i_mwe'vevlfu     .
essael.rangeh
() < other.rlit_laswpteraimplidsto yn ens ?ton co Fier"oegt nmutasm     seqIs te_fol other.rlit_las asos). Thein   is ins ?ton co Fier"oeg      
   Self,
  possi. A sequf=sous.;

   // s        s of tan// s    hile a < drain_endence(.iqung or.iqui_ oncat(a};   assertIs tleallyseome(cmp.
essidstneed waoppeio  lrwiseeer
iplic cbar'nd 
plicit e= oeweriplic cs[a];
 dd  wise
essidstng iswe do    {ar  e tmostrid
plicit e= oof.sS oegt{g'r.uppliclyse ne tvac  you mer(le valS probawe'ref cmp::maxa` rinu'aprob_cessa'  you mer(c, Optid folve        bsand tc1.   assert Pts1.aunant(|m| !more we're d);   assert Pts1.iplic (aprob_cessa..aprob_cessad):Pts2);&Self,
  possideduanges.pus     // Is Drdupli otpaadjac ot)m   retur   consers    //   seqr"oegntoto  to be part Iaradjac ot)end  oas     m   retur  rallyssaeachus.lat  a_c Is theertsushi): ot weasei to gn    ge    le conserlat keptee theer
    leus.lat   return (movheor<Ite   /// set. Dedualyseens ?ton co Fier"oegt r1 &oo-op.     i    algurmunge(selfd is
    /// set. That  a_foldid ca```tk. ch fassl dyn et<ldupli otpa engirallyssfeac/// set.     no tc   retur  wl S.`, ttc1/
tracac1n sse a sussolv d./// set./// set.     // set. re to find ca```tk
/ted lfd c_   f.rangeh f, vnd<Ite   /// set.     en secefctcnd ca  fnrror fo// set.     t fct("ay,nd caaaaa")se_fold_si    t fct("ay"),nd caaaaaaaL._fold_si]ean// set. inu deduanges.pus   /// set. ("bar"),nd end ca  fnrror ft fct("ay"),nd caaaaaaa]ecaece)nd<Ite        // s#[in  ne]r<Item = I>>deduan en secundcpper1, upp      }ence(appien s.iqung      t. A sequfit iswo ranges.iqu>dedua_by(|.iq1d):Pt2| the ranges hav
}

));.iq1oasfis) ->) !f.rPt2oasfis) ->) ns `None`.
   Self,
  iccontanough   }
        while a < drain_end {
 if=.iq1ore w to  a]!f.rPt2ore w to  a].upper() < other.r    .iq1o
ine!sei to  a   }
        while    .iq2i
ine!sei to  a   }
        while a < drain_end {
 ppern// s    hile a   }
     }

        // Is So as;vaer1seqr"oeg rfr. A sequflexicographiche c T    et.  algurmuNoewing isind) lrwisesertt aofr2 =serence-o nal ex[e  th ls isiinot weonicaet.        tapp a_x[efcaus  r {
   efcaussertt aoflf.r[1qr"oegt{  bsnot   return ( For ot)th Siamo  th alced:deringa     aFimann a o    fn case  n// set. iertt a tva,Fier"oegt`[s/mopti,fs/m]` yield wayupFier"oegt`[s/m n// set. i/mopti]`. Uninga th alced:deringaFimann a gn   
e
Finar[1qr"oegt{  be_fold_si  an  anges[ s/mopti` erloenas valS probainuts2, o, tor<Ite   /// set. nge(selfd is
    /// set. That  a_foldid ca``basic reagen        /// set.     // set. re to find ca```tk
/ted lfd c_  cndnd<Ite   /// set.     en secefctcnd c  fn&faaaa", "Z&ota, "bar"]ean// set. inu iertnges.pus   /// set. ("bar"),nd end c  fn&fabar", "aaa", "Z&ota]ecaece)nd<Ite        // s#[in  ne]r<Item = I>>iertn en secundcpper1, upp      }ence(appien s.iqung      t. A sequfit iswo ranges.iqu>iertnges.pus    }

        // Is Rdver2)s 
/// nco be consers    //   seqr"oegZ be part/// set. Ter
erformanco beFier"oegt 1l    at  For rvheor<Ite   /// set. nge(selfd is
    /// set. That  a_foldid ca``basic reagen        /// set.     // set. re to find ca```tk
/ted lfd c_  cndnd<Ite   /// set.     en secefctcnd c  fn&faooaa, "rab"]ean// set. inu ndver2)_wind up C)nd<Ite    ("bar"),nd end c  fn&faaaa", "bar"]ecaece)nd<Ite        // s#[in  ne]r<Item = I>>ndver2)_wind up C en secundcpper1, upp      }ence(appien s.iqung      t. A sequfit iswo rangescan win    !l1l. A s_en s, the ranges hav hav!l1.ndver2)>ean// s            other: &Self     // Is Shllyksm     seqIto   s ctlx
astessibw    e`, ttc1t a tva, th alced:::max(lowesformanc  s        tor<Ite   /// set. W    emp   reucseit{  bs (movh dupli otpange = SacInterva   seqf l1h
    ///{  bs asos (movh wind up caral aste  an  anges[/toaaw ftc::{- probaimh
    ///" th alced:dering";ose lo.uS o    Ito  she ::srdup`]ofr2 =serence-oat   returndeduaer a{
     c e */aral rem f  /     dg  isn't go<Ite   /// set. T    er1 &oo-op(o  ecesl dyn et<l
essaean     ton contoto    /// set. nge(selfd is
    /// set. That  a_foldid ca`` bctd    letc cba
    /`{s/m,fs/mopti}`Is te_fold_si`{s/mopti,fs/m}`./// set./// set.     // set. re to find ca```tk
/ted lfd c_   f.rangeh f, vnd<Ite   /// set. rt Iar's/m'ppeiow  lrwise's/mopti'[e thaa th alced:deringaFie looat   returninuexecuter a{
   's/mopti'[aof n an  anges.   reet.     en secefctcnd c  fn&fas/m", "s/mopti"]ean// set. inu ctlx
seeeis_ th alced:(:Se// set. ("bar"),nd end ca  fnrror ft fct("ay"),nd caas/m"a]ecaece)nd<Ite      returninuBachl);// y a  lndver2)dh oduced 'se kier" pacan 's/mopti'["good" al// set. re
eioegt 1 er1et<I>)highnga th alced:.   reet.     en secefctcnd c  fn&fas/mopti", "s/m"]ean// set. inu ctlx
seeeis_ th alced:(:Se// set. ("bar"),nd end c  fn&fas/mopti", "s/m"]ecaece)nd<Ite        // set./// set. That  a_foldid ca``ioynar2 = acessaerallyseis    //   seqr {
  du32();
  noust aptral aeiow efcaus  [aof n an  anges.   reet./// set.     // set. re to find ca```tk
/ted lfd c_   f.rangeh f, vnd<Ite   /// set. rt A acessaerallyseis e  th ls isiillirallyss,heoli IsutomaeaFinal/// set. rt inhibl1 o thesub sves.
irallyssfInter[A" aano./// set.     en secefctcnd c  fn&faaaa", "bar", "", "Z&ota, "aax"]ean// set. inu ctlx
seeeis_ th alced:(:Se// set.     k     t fctcnd ca  fnrror fo// set.     t fct("ay c[nd caaaaaL._fold_si    t fct("ay,nd caabar")se_fold_si    t fct("ay"),nd caa")se_fold_si]ean// set. ("bar"),nd ca]);nd caece)nd<Ite   /// set. Is Aodsearcourdigntfdder
sat`ion beginnt aoflf.ced i
ine o 1 em kier" p/// set. Is can  noust apretur"good" a.T// set.     en secefctcnd c  fn&fa", "aaa", "Z&ota, "aax"]ean// set. inu ctlx
seeeis_ th alced:(:Se// set. ("bar"),nd end ca  fnrror ft fct("ay"),nd caaaa]ecaece)nd<Ite        // s#[in  ne]r<Item = I>>ctlx
seeeis_ th alced:( en secundcpper1, upp      }ence(appien s.iqung      t. A sequfit iswo rangesPth alced:Trie::ctlx
see(.iqu,anoughges.pus    }

        // Is Trims 
/// consers    //   seqesuuted at (nhatvalS proba`len`ce few   return (m f .iI2 =serence-ohaal       ateadtc  e-o se`len`ce fewoflf.ced    return (m f  /uning ged.sOt weopti,e 1 er1allmmheia   cadg  isn't go<Ite   /// set. nge(selfd is
    /// set.     // set. re to find ca```tk
/ted lfd c_   f.rangeh f, vnd<Ite   /// set.     en secefctcnd c  fn&faaa, "aaa", "Z&ota]ean// set. inu keep_ probeis) ->2)nd<Ite   /// set.     k     t fctcnd ca  fnrror fo// set.     t fct("ay,nd caaa")se_fold_si    t fct("ay"),nd caaaa")se_fold_si    t fct("ay"),nd caaqu")se_fold_si]ean// set. ("bar"),nd ca]);nd caece)nd<Ite        // s#[in  ne]r<Item = I>>keep_ probeis) -> en secund):en: reseedcpper1, upp      }ence(appien s.iqung      t. A sequfit iswo rangescan m    !l1l. A s_en s, the ranges hav havm.keep_ probeis) ->) - an// s            other: &Self     // Is Trims 
/// consers    //   seqesuuted at (nhatvalS    a`len`ce few   return (m f .iI2 =serence-ohaal       ateadtc  e-o se`len`ce fewoflf.ced    return (m f  /uning ged.sOt weopti,e 1 er1allmmheia   cadg  isn't go<Ite   /// set. nge(selfd is
    /// set.     // set. re to find ca```tk
/ted lfd c_   f.rangeh f, vnd<Ite   /// set.     en secefctcnd c  fn&faaa, "aaa", "Z&ota]ean// set. inu keep_     is) ->2)nd<Ite   /// set.     k     t fctcnd ca  fnrror fo// set.     t fct("ay,nd caaa")se_fold_si    t fct("ay"),nd caaaa")se_fold_si    t fct("ay"),nd caaotaaL._fold_si]ean// set. ("bar"),nd ca]);nd caece)nd<Ite        // s#[in  ne]r<Item = I>>keep_     is) -> en secund):en: reseedcpper1, upp      }ence(appien s.iqung      t. A sequfit iswo rangescan m    !l1l. A s_en s, the ranges hav havm.keep_     is) ->) - an// s            other: &Self     // Is  other.upper());vaer1seqr"oeg    ton co.toto  to be part echarnough, ee   seqr"oeg    geton coia   cprovb  ts. If sahetfdde

     th     /ts  an or yoer" pange = S.   re#[in  ne]r<Item = I>>s !ton co(aseFoldErrper2)
    }
}

t(ast:P     tois_pnce()

        // Is  other.upper());a   (nhat));vaer1seqr"oeg    ton co)aLit essa.toto  to be part AnIcessaerier"oegan an  angese o thust a. .l aof (nhate f uted brob onicaet.        tlf::crenceow
     c and thus probathtpall1l    aof    anges.   re#[in  ne]r<Item = I>>re we're aseFoldErrper2)
    }
}

t(ast: ->) == ence(0)

        // Is  other.up c nua, m rfr. A sequf   //   seqr"oeg  );var
inuts2, ock   // Is ton co.st_mlf.r[eqr"oeg    geton cosm{
   `ous.` cre 
of thentoto #[in  ne]r<Item = I>>w ->aseFoldErrOpis) <resee>e       e("t(ast:P     toasf 
f()_map(|.iqu|r.iqu>
    )

        // Is  other.upper());a   (nhat));
/// consers    //   seqr"oegtyrr
    lgo<Ite   /// set. T    rother.unough,i_mlf.r[eqr"oeg    geton co.   re#[in  ne]r<Item = I>>re w to   seFoldErrper2)
    }
}

t(ast:P     t().om _or nough, |.iqu|r.iqu> l

Ft_
//(|x| xore w to  a )

        // Is  other.upper());a   (nhat));
/// consers    //   seqr"oegtyrr
 isn't go<Ite   /// set. T    rother.upper());va.r[eqr"oeg    geton co.   re#[in  ne]r<Item = I>>re sei to   seFoldErrper2)
    }
}

t(ast:P     t().om _or pper, |.iqu|r.iqu> l

Ft_
//(|x| !xore w to  a )

        // Is  otherffectcaximum ) -gthstfto beseqr"oeg  dyn wcif self.is(Inted// set. u    arch`poss` wl S.`ot we`.st_meit weain `ds   ton cosm{
       t.
  /e
 rother.u`ous.`ntoto #[in  ne]r<Item = I>>
ix_r.upp_w ->aseFod)ot we   etqtcErrOpis) <resee>e       e("er2).en1g      t.    ?;      e("er2).en2e=.ot wet.    ?;      e("ence(.en1.se ui Ih a_add(.en2 )

        // Is  otherffectcaximum ) -gthstfto beseqr"oeg  dyn wcif self.is(Inteself.folded {asossq` isn't (fh`poss` wl S.`ot we`.st_meit weain `ds   ton cosm{
  e_fold_simp   rother.u`ous.`ntoto #[in  ne]r<Item = I>>
ix_etossfw ->aseFod)ot we   etqtcErrOpis) <resee>e       e("er2).en1g      t.    ?;      e("er2).en2e=.ot wet.    ?;      e("ence(.en1.se ui Ih a_mul len2 )

        // Is  othershus, ) -gthstfto beshor) -le conserlanrmp   seqr"oegntoto  to be part Iarmp.r[eqr"oeg    geton coeadtce'ref cmpnimp   rother.u`ous.`ntoto #[in  ne]r<Item = I>>
intent(self) ->aseFoldErrOpis) <resee>e       e("t(ast:P     toasf 
f()?. l

Ft_map(|x| xo
    ) ctl()

        // Is  othershus, ) -gthstfto belo ge-le conserlanrmp   seqr"oegntoto  to be part Iarmp.r[eqr"oeg    geton coeadtce'ref cmpnimp   rother.u`ous.`ntoto #[in  ne]r<Item = I>>
ix_ent(self) ->aseFoldErrOpis) <resee>e       e("t(ast:P     toasf 
f()?. l

Ft_map(|x| xo
    ) cax()

        // Is  othershus, )o ge-lecommceo th ls Interva   seqntoto  to be part Iarmp.r[eqe ngese o thel.range an ot weh     /ts naner [`Seq`]{
  e_fold_simpals in noe in h aful  th ls s thee   rother.u`ous.`ntoto    /// set. nge(selfd is
    /// set. That d ca``pnce  a_foldidcesle theerir )o ge-lecommceo th lsn        /// set.     // set. re to find ca```tk
/ted lfd c_  cndnd<Ite   /// set.     ecefctcnd c  fn&faaaa", "aaabar", "aa"])nd<Ite    ("bar"),nd ence(&b"aa"[..]ecaece.)o ge-l_commce_ th ls  )nd<Ite        ecefctcnd c  fn&faaaa", "aaa"])nd<Ite    ("bar"),nd ence(&b"aaa"[..]ecaece.)o ge-l_commce_ th ls  )nd<Ite        ecefctcnd c  fn&faaaa", "bar"]ean// set. ("bar"),nd ence(&b""[..]ecaece.)o ge-l_commce_ th ls  )nd<Ite        ecefctcnd c  fn&fa"]ean// set. ("bar"),nd ence(&b""[..]ecaece.)o ge-l_commce_ th ls  )nd<Ite   d<Ite        ecefctcnd cgeton co(ean// set. ("bar"),nd Naid cecq.)o ge-l_commce_ th ls  )nd<Ite        ecefctcnd cwe're dan// set. ("bar"),nd Naid cecq.)o ge-l_commce_ th ls  )nd<Ite        // s#[in  ne]r<Item = I>>)o ge-l_commce_ th ls aseFoldErrOpis) <&[u8]>e       e("   t_mwe anges[ an oust apo  anges[not t aoflf.cempals'n noe in h aful      e("   )o ge-lecommceo th lsn      upper2).ique=.
         t. A sequfit iswo rangesous.l=>os of tsous.i_ oncat(arcstence(appi.iqung or.iqui_ oncat(a};   assert    l1l.  ->) == 0d);
    }

    s of tsous.;

   // s}      upper2)bae tf.rPts[0]oasfis) ->);      e("er2)en s..ce=)bae .  ->)nd<Itesertcan m    !l1l. A s  .skip(1, the ranges hav!.ce=)mhe ranges hav havoasfis) ->)he ranges hav havo A s  he ranges hav havozip(bae [..!.c]o A s   he ranges hav havotine!w    (|&(a, b)| a == b he ranges hav havocoun  a   }
        w     n == 0].upper() < other.rs of tsence(&[]ean// s            other: &Self,
  ence(&bae [..!.c])

        // Is  othershus, )o ge-lecommceo[ften (Interva   seqntoto  to be part Iarmp.r[eqe ngese o thel.range an ot weh     /ts naner [`Seq`]{
  e_fold_simpals in noe in h aful [ften (s thee   rother.u`ous.`ntoto    /// set. nge(selfd is
    /// set. That d ca``pnce  a_foldidcesle theerir )o ge-lecommceo[ften n        /// set.     // set. re to find ca```tk
/ted lfd c_  cndnd<Ite   /// set.     ecefctcnd c  fn&faooaa, "rabooaa, "of"]ean// set. ("bar"),nd ence(&b"of"[..]ecaece.)o ge-l_commce_[ften   )nd<Ite        ecefctcnd c  fn&faaaa", "aaa"])nd<Ite    ("bar"),nd ence(&b"aaa"[..]ecaece.)o ge-l_commce_[ften   )nd<Ite        ecefctcnd c  fn&faaaa", "bar"]ean// set. ("bar"),nd ence(&b""[..]ecaece.)o ge-l_commce_[ften   )nd<Ite        ecefctcnd c  fn&fa"]ean// set. ("bar"),nd ence(&b""[..]ecaece.)o ge-l_commce_[ften   )nd<Ite   d<Ite        ecefctcnd cgeton co(ean// set. ("bar"),nd Naid cecq.)o ge-l_commce_[ften   )nd<Ite        ecefctcnd cwe're dan// set. ("bar"),nd Naid cecq.)o ge-l_commce_[ften   )nd<Ite        // s#[in  ne]r<Item = I>>)o ge-l_commce_[ften  aseFoldErrOpis) <&[u8]>e       e("   t_mwe anges[ an oust apo  anges[not t aoflf.cempals'n noe in h aful      e("   )o ge-lecommceo[ften n      upper2).ique=.
         t. A sequfit iswo rangesous.l=>os of tsous.i_ oncat(arcstence(appi.iqung or.iqui_ oncat(a};   assert    l1l.  ->) == 0d);
    }

    s of tsous.;

   // s}      upper2)bae tf.rPts[0]oasfis) ->);      e("er2)en s..ce=)bae .  ->)nd<Itesertcan m    !l1l. A s  .skip(1, the ranges hav!.ce=)mhe ranges hav havoasfis) ->)he ranges hav havo A s  he ranges hav havorev  he ranges hav havozip(bae [bae .  ->) -v!.c..]. A s  .rev   he ranges hav havotine!w    (|&(a, b)| a == b he ranges hav havocoun  a   }
        w     n == 0].upper() < other.rs of tsence(&[]ean// s            other: &Self,
  ence(&bae [bae .  ->) -v!.c..])

        // Is Opis
seesm     seqIw    ets. Ilysei s        tsahe th ssioIs te_fold_si`, ttc1t a tva, th alced:wesformanc  s        tor<Ite   /// set. Tweripecific way "opis
seother" work /    ear  e tbeeens foldmea``ther   returnde  /l,iaalit esr otihe chau For ot o  in `ancheurisn a o Twergoal/_fold_simpParopis
seother1alle waopacc, Olish er1ao odke:o be consers    //  n// set. inte 
fs);n   putstng isw  bs (f.is(/toaa wise
to usivo  th slons.T// set. Principhe chbchauduct a tva,nough, you mvo r Iesearcs tid Iesvlfu   b onicaet. o be consers    //   seqr"oegZaonal exf w
   a.
     o2 =serence-oat   returnlfu  ,ety wcif se cari  e tbeeeiralor<I thdictormanco beovnce-lood" al// set. anco beo fin.st_m 1 ern' r {
   muutedime {     /ripe.
iraartt a s te_fold_sistoppt a tva, th slonsaFie looe thattcesst apto    firmffectca    onal/// set. to eate d if /l.lf.cl to be part Sthetanco ogh,heurisn a cs[a];
be:        /// set. * Id otifyt a secommceo th ls Inter=seargnar[1qr"oegtrfr. A sequ, s te_fold_sishllykt a tva,Fier"oegtdown e tvaal st aleecommceo th lsn         * Rejtc1t a tva,Fier"oegt otirehat)); 1 er1beli and an icf.is(/toan o         high,nough, you mvo r Ie. echar//   happ /
,rmp.r[eqr"oeg    cadg::max(low ?ton co.toto  to * Shllykt a tva,Fier"oegtaopa smollna nua, m rfr. A sequfau For ot ///_fold_si th ssio aeach utishllykt a  1 sosauutear1ao odke:wind up caooeshor).toto  to (Ar[1qr"oegt{ thoan oeshor)r. A sequ, rfr1po  2ce fewof{    typaFinal/// set.  (f.is(/toaahighnganough, you mvo r Ie.)        /// set. Opis
seother1shoif s(nhate fruf (negt f::crenceo   a, OleIe. ractor`l// set. apis
seother1 nyhodke:("bumpis) stng isdossar'  m kigt{ thoot weonicaet. oper Is) stbnset(omiddlgtrfr f::crenceo    fn case   apis
seother1{  be_fold_siauducgt`[E(samecaE(samopti)]`o se`[E(same]`d each uutea1alanslf m`ther   returni oinhatvalidfi);nd ot wehlf::crenceow    occur.st_mot wehlf::crence   return nyhoccur a{
     c and tc1/alanslf m`ther wcif sbeo se`[I(same]`or<Ite   /// set. Twer she ::apis
seefe t_[ften eis_ th alced:`] ctcesth Siamo ust aofeac/// set. lf { ften lathe ne   /// set. nge(selfd is
    /// set. That d ca```tk.apis
seother1 [a];
alanslf mo  inqr"oegZaNoewing ie_fold_simpl,ipecific behavirceiessar'a ctcumea`nd gualanteeo Twerheurisn a  // set. re d     ans foldmea``thernde  /lia   cay ing geeovncedime    semvweonicaet.   m `thb  e`,lendid.   reet./// set.     // set. re to find ca```tk
/ted lfd c_   etqD t fct("vnd<Ite   /// set.     en secefctcnd c  fn&fe_fold_si    "s/mantha",e_fold_si    "s/m",e_fold_si    "s/mopti",e_fold_si    "Intdo"L._fold_si]ean// set. inu apis
seefe t_ th sseis_ th alced:(:Se// set. ("bar"),nd end ca  fnrror fo// set.     t fct("ay,nd caas/mantha")se_fold_si    _siKepte    leee ofmight b's/mopti'[go1/ tunede_fold_si    _sibar'nd capis
seother1("bumes        tlf::crencee_fold_si    _sihaalton sher.n// set.     t fct("ay,nd caas/maaL._fold_si    t fct("ay,nd caaantdo"aL._fold_si]ecaece)nd<Ite        // set./// set. nge(selfd: apis
seother1 nyhodke:mp.r[eqr"oeg  ?ton cotsushi): be part Iarmp.rheurisn a cdeeme dynamic Fier"oegts if sr'nd caoan oehigh,nough/_fold_si you mvo r Ieoflf.ced i
iyhodke:mp.r[eqr"oeg  ?ton co,e
to usivoal/// set. disabllysei s nd cas e  th llons.T// set./// set.     // set. re to find ca```tk
/ted lfd c_   etqD t fct("vnd<Ite   /// set.     en secefctcnd c  fn&fe_fold_si    "s/mantha",e_fold_si    rt A acessaerallyse ngese o t  an or you mer,e_fold_si    rt thuufauningt a tva, th slonsaa, OleIeal/// set. lit_las ?
to usivo.n// set.     "",e_fold_si    "s/m",e_fold_si    "s/mopti",e_fold_si    "Intdo"L._fold_si]ean// set. inu apis
seefe t_ th sseis_ th alced:(:Se// set. ("bar"!(!ecq.e !ton co(eean// set.     // set./// set. Dossarg  dyn jprovb r'nd c// rgt r1 &`" "`tbnset(oseqr"oeg,Ing ie_fold_si         earflf.r[1qr"oegt{  bsaabled be made' iton co efcaus  [at   returnapis
seed. ractor` ));va.r[eqr"oeg     i?end  er(z   le( theod" al// set.  m `, tk.
sf seof (vnce-lood" amanco beoriginalto fin)r {
   etheod" al// set.    ins(vnce-lood" a,Is thso tva,nough, you mvo r Ies   iabled `0`or<Ite   /// set. Ttrsrmceralat emp  ,ety  (movh  s/mopti` InterarchFier"oeg  That/// set.  (f.isstbnsnd opis
seother1happ /lysee th
/// consers  (m f 
    lgo<Ite    Thu /// Scotirer[eqr"oeg    i to gns thltlat keptees-  ,eee ofmight    returnas.lat insASCII,ipace:   reet./// set.     // set. re to find ca```tk
/ted lfd c_   etqD t fct("vnd<Ite   /// set.     en secefctcnd c  fn&fe_fold_si    "s/mantha",e_fold_si    " ",e_fold_si    "s/m",e_fold_si    "Intdo"L._fold_si]ean// set. inu apis
seefe t_ th sseis_ th alced:(:Se// set. ("bar"!(ecq.e !ton co(eean// set.     // s#[in  ne]r<Item = I>>apis
seefe t_ th sseis_ th alced:( en secundcpper1, upp    tapis
seefis_ th alced:(pperges.pus     // Is Opis
seesm     seqIw    ets. Ilysei s        tsahesionssios   e_fold_si`, ttc1t a tva, th alced:wesformanc  s        tor<Ite   /// set. Opis
seother1shoif s(nhate fruf (negt f::crenceo   a, OleIe.r<Ite   /// set. Twer she ::apis
seefe t_ th sseis_ th alced:`] ctcesth Siamo ust aofeac/// set. lf { th ssio. Segt 1l ctcumea`other1can mwise
xplanother./// s#[in  ne]r<Item = I>>apis
seefe t_[ften eis_ th alced:( en secundcpper1, upp    tapis
seefis_ th alced:(noughges.pus     //I>>apis
seefis_ th alced:( en secun,{ th ss:rper2tcpper1, upper2)orig!.ce=)m         t. ->) it iswo rangesous.l=>os of ti_ oncat(arcstence() - g or.eni_ oncat(a};   assertIs Jprovet<I up..low frarchFier"oegts to f  /anecessaerallyss
Otherwise, possimintent(self) ->).om _or nough, |.en|   n == 0) it iswo ranges= othesquash;va.r[eqr"oeg s tvaal nobodypreturmoss ethebr[a];t iswo ranges= ond ar1ao t ors thre t  . A acessaerallyseimplidsta.
     a;t iswo ranges= o an or you mer. A, th slonsaaof    helt you rloentoto Self,
  possi
ine!seton co(ean// s// s    s of tan// s    }   assertIs Mdke:nungeise  ar  wl S.va.r[mollnobainuts2, o yoer" p.othend ca   assertIs ipecialtver2mer(le  th alced:wctlx
seother1aral re  /ts  cac1n ss.   assertIs T    er1legalibar'nd capis
seother1i oinhatk     t fao occur (neg
    continuex::crenceo   a, OleIe.r<Iterwise,  th ls {  }
        w      }ence(appien s.iqung      t. A sequfit iswo rangesngesPth alced:Trie::ctlx
see(.iqu,apperges.pus            other: &
    continuLook can  ecommceo th ls (f { ften ).i));wevlfu   ini/
t fckigts te_fol oth= oner
s)o gScoght h oduced 'sea[goo sbete dynait {     /rarchfaat ste_fol oth= o yoer" pa th slonsaFioegtst ale-sub allyseFie looat s tfaat.   assert et, pxg  e,  th ls {  }
        w    t.o ge-l_commce_ th ls  
          returns `None`.
       t.o ge-l_commce_[ften   _ oncat(a};   assert      }ence(en )g   ls {  }
        wrt A o  ipecialtandigni_mwe eate  ecommceo th ls e theer
lead ///_foler.rlit_laseyti/
t fcato th ls i oiniong iswe ust kq` ibablyhoccurs  artor`l// splicit e= oewenerallp[ an oust apdown e tjprovvaal st aleeeyti. That d cif l// splicit e= o` imarg  dhend c
t memchr.
e negation tass
       it e= o...swe (nhatd tvai omight b frarchFier"oegthaalmwiseeeof (nes
       it e= oo n [`S. Ot weopti,ety'd r I wehjprovsn akhwl S.  st aleeo n [`Ss
       it e= os, toaonal exf uslyse imchr at  Fibablyhbetonsaeeof look ///_foler.rlit_lasfo  2can mwise. A sequ, each Fibablyhsar'as[goo sas e rala[a];t iswo ranges= o im im;ose lo.
e negation tass
       it e= o...se th
/s t(nhatd tvai ow
     c  th ls i oshor)re th Fibablys
       it e= osar'aooediscrx
snoto ors yble.st_m 1r
s)o gerh oduced 'sl// splicit e= o` ibablyhqu co discrx
snoto ors d thuufimie cahatvo eate  ello
    contlit_lasfough, you mvo r Ie.  }
        w    th lst iswo rangesnges&&)orig!.ce> 1t iswo rangesnges&&) lsn. ->) >= 1t iswo rangesnges&&) lsn. ->) <= 3t iswo rangesnges&&)rank(en [0]) < 200t iswo ranges{     
   Self,
  possikeep_ probeis) ->1a   }
        whilepossideduanges.pus// s        s of tan// s    hile a < drain_end= othe(nhatrallp[down e tvaeecommceo th ls/[ften ()fswe ust kl// splicit e= oeweuexisn yseFit rfr. A sequf      gs. I,can ));va.rcommcel// splicit e= o` h ls/[ften ()stk     t fao e f arttcularhatdiscrx
snoto o.
rain_end {
  is isfaat =  }
        whilepossire w to  a]&&)    t. ->).om _or nough, |.en|   n <= 16ges.pus// s     is re fpxg   lsn. ->) > 4 || ( lsn. ->) > 1]&&)!isfaata   }
        w   re fpxg{ges.push(range);
   t_mwe keep w to hatvalSnua, m rfris) -tc  e-o seus, ) -gthges.push(range);
   anco be th ls (f { ften )h oducebatvalSdeton cmer(le ages.push(range);
    th ls,o an or conserlanrmp.r[1qr"oegt{  bsb  m   retur ntoto e negation tas Thu , 'dedua't{  bslea<I ust{ thoonerwind upntoto e negation tass
       it elit_lasWe do    vai owayfeo   //  of olloc, each asos)goodke:nungs
       it elit_laseer
    ln sserfr. A sequf   kepte(an    )       // Otherwise,  th ls {  }
        wSelf,
  possikeep_ probeis) -> lsn. ->)ean// s// s          returns `None`.
   Self,
  possikeep_     is) -> lsn. ->)ean// s// s           }
        whilepossideduanges.pus// s        ("bar"),nd ence(1ecaec  t. ->)ges.pus// s        = othes   bsf
///thrght brloen I   arttcular,t{gt{ar  arcs.pus// s        = o)o ge-lecommceo th ls ao e fsubjtc1/
trvac  yiser(check.n// s            other: &Self,
     t_mwe eate   
    loseqr"oeg,Iwe *` ibably*hjprov{ar  e tkeep   &Self,
     es-  . Bacimpll      pnce pndid erloenwe do   .}eneise ate  ecopyhof
it elit_laseer
    lerier"oeganow, e theern t oran do pnce mwiseapis
seothers
it elit_lasbello.st_mlfkigtdo    {orkeome,Iwe go eaakhe tvai o    lerier"oeg.   assertIs   assertIs T l,ipecific mar rether1can t    er1ng iswe pncedimest{  thrpt{ th&Self,
     e 
    loseqr"oeghwl S.  hefsaenua, m rfr. A sequ.}eay, 100.i));we   assertIs ituakhwl S.ng ir I> {cif sbeo so eig1can Teddors d wcif self.is(in   assertIs uslyseAho-Corasick. ecilooat tone...sbme(cmp.lazy DFA at  tur y   assertIs iu ca" pa   suutepndido Twers. -oatsue er1ng iswe {  bs{  thrptnot   resertIs uslyseatfaata th slonsayn ell.}ene   pndid e carmp  ,eee ofmight    relit_laswe eate   
    loseqr"oeg,II> {cif sbeobetonsaeo t ors thshllyk cmp::maxa` rinuseqr"oegh(wpteraweedo bello)rs thre t  cas e  th llonscaral ast
plicit e= o` iducgtfough, you mvo  ngese .   assertIs   assertIs Bachl);// ishllykt a bello elf.iss_inteeseqr"oeg  dyn "suuks,"]{
  e_follit_laswe do    {ar  e tnd c//aovb r'nd cwe als. doreate   
    loseqr"oege_fol oth= onn c   .   assert et,    l:rOpis) <Seq> =  }
        we, possire w to  a].}ence(    tely if t   returnsous.l};   assertIs Nlo we attcessf seshor) nrmp.r[1qr"oego Twernd a / rgt r1ng iswe   assertIs do    {ar  e tlook can  so m thel.rangeu, each{gt{ar  e tshor) n
plicit e= oorchFier"oegtcoght Ito  m` iv/rarchoddserfruslysebetonsaalgorithms   assertIs doweraleam (suutear1Teddo).   assertIs   assertIs T l,paim rfrnua, ms    //   li-leco `, tk.
sf self.rcaximal  th lst iswo rato (inris) -) e tkeep can  /// consers e theer
le-gthstfto beseqr"oeg&Self,
     etswpteraan do   .   assertIs   assertIs enef  fn case   t l,paim (3, 500) {cif s ear, "i_mwe eate mwiseeeof   assertIs 500e consers    orchFier"oeg a{
    run otpaa/// ncorch consers   assertIs iuuted at // y a  lat c::{ 3ris) -tin
le-gthse theer
ctlx
see cmp::maxa` rinuseqr"oeg."
        s t:{ ATTEMPTS: [(resee, reseed; 5] =  }
        w[(5, 10eca(4, 10eca(3, 64eca(2, 64eca(1, 10e]nd<Itesertcan (keepd):Pmit)tin
ATTEMPTS the ranges hav!. s..ce=)m         t. ->) it iswo rangesngesous.l=>obleakh
() < other.rlit_ence() - g or.eni_ oncat(aat(a};   assert   w     n <=):Pmit it iswo rangesngesbleakan// s    hile a < drain_ende,  th ls {  }
        wSelfpossikeep_ probeis) ->keepges.pus          returns `None`.
   Selfpossikeep_     is) ->keepges.pus         a < drain_ende,  th ls {  }
        wSelf      }ence(appien s.iqung      t. A sequfit iswo rangesngesngesPth alced:Trie::ctlx
see(.iqu,apperges.pus             a < drain_end    other: &Self,
     Check can  e yiser(o n [`S. Ae yiser(o n [`S i oiniong isi oshor)&Self,
     e d er1beli and an eate  ean oehigh,m     coun o Twesc  yisers   assertIs gennce-ly
leadtaopa  th llonscwl S.  an oehigh,noughi you mvo r Ieo&Self,
     e d thuuf(vnce-lo{ors f `]lf maoeg.   assertIs   assertIs We do //   lasovb r'nd cwe s if seate ginioInter=s upp yiserous::maxa` rinuseqr"oeghaopa  yiserousoinio Perhapsswe phoif s dd pnce podghao
plicit e= o` ee och uutealansiIs) stbnset(o probaplaeg abme(cmpntegain,swe   assertIs e cahat(nhatmade'et(oalansiIs) tbnset(o probaplaeg ));va.r[eqr"oege_follit_laswaalitl    huge. Aodshuge Fier"oeg vaiseeerml  ves  yiserous.}en...   assert      }ence(.iqung      t. A sequ>) it iswo ranges    l1l. l

Ft_
ny(|.iq|r.iqire  yiserous d)fit iswo ranges,
  possi
ine!seton co(ean// s// s        other: &Self,
     OKgni_mwe ead e 
    loseqr"oegh lrwiseattcesst apmwiseapis
seothers
it elit_lasfolve a   (rchp::{-apis
seedr[eqr"oeg suuks lf { nce leaser(or&Self,
     e ot we al cak= lgo eaakhe tvaeo    lerier"oeg.   assert      }ence(    lng      le{  }
        wrt t_mopis
serobathf.is e rn droppt a orch consers al cakcar"ainlys
       it e= oeaakrpts thre teer
    lerier"oegang iswe ead.  }
        w   !possire ton co(efit iswo ranges,
  *());fct    les.pus// s        s of tan// s    hile a < drain_end= oIncorchapis
seedr[eqr"oeg s to f  /aeshor)r. A seqh oduced 'sl// splicit e= o*` ibably*h utiso gs. I.}enethrgwt  cawayfs thndver1/
trvact iswo ranges= o    lerier"oeg.   assertrwise, possimintent(self) ->).om _or pper, |.en|   n <= 2efit iswo ranges,
  *());fct    les.pus// s        s of tan// s    hile a < drain_end= oFinalor` ));orchapis
seedr[eqr"oeg    "eig" (i.
*/ ast's re a < drain_end= oTeddo)r {
   easosdo    re t  ca thndhat(ntvaeo    lerier"oeg.   assertrwise, possi) ->).om _or pper, |.en|   n > 64efit iswo ranges,
  *());fct    les.pus// s        s of tan// s    hile a < drain &Self  }

impleco e::fmt::Debug1can Seqfit iswfn fmt>aseFod)f       co e::fmt::Ff m`tt(sldErrco e::fmt::Rlf.is(it iswo rawrite!(od)"Seq" ?;      e("      }ence(.iqung      t. A sequ>) it iswo rangessidebug_li-l>). oclle ( l1l. l

Ft).ton sh  
          returns `None`.
   write!(od)"[∞]")a < drain &Self  }

impleFnteIA setor<t fct(">1can Seqfit iswfn f  fnrror<T: IntoIA setor<IA mg  t fct(">>(il:rTldErrSeqfit isw e("er2)en secefctcnd cwe're dan// sngescan winnserlanrit it iswo rangesecq.push winnser)an// s    }   assertecq&Self  }

art A st aleeo n [`Suex::creer(Intere 
[`Hir`]tk  thfsher./   /art A o n [`S i o  m kigdsearmwomust as:/   /art * Ar[1qr"oegtrfris) -ZaNo gualantees wl S.`, ttc1/
trUTF-8     p ivnd d./    I   arttcular,tze ofi);// athtpal=serence-oatuex::creer(InteratuUTF-8f cmp:et.        tlf::creed  nyhno tbetvalidfUTF-8. (   fn case   bfre 
[`Ef::creor`]:et.   mit thf.is e rn allmmlyseatwinnserlanraowayfeaal sp.iquea podg yin o)/art * WheI weho be conser    "    l"ean    . A a"    l"e conser  ear``ioynart/art haalnotlb   /allmmhe,ia   cay ioot /ue ao e fchee  he.iI2 =serence-oat  ///"    l"eefcausvisiIs a tva,cotirer`Hir`tk  thfsherf cmpnimp   implidsto yn
et. o be conser
leadsf seo)m      t Ie. (Almight b ti        neeg sarihatimply
et. a   occurr"oeg v nco be consereco `, tk.
f seo)m     anco beo fin,aFioeg
et.        tlf::crenceoigno estlook-arfu    "bar"herso)/#[ingtve(Claid cEq, ParttalEq, ParttalOre,iOre)]
m = sppec1/t fct(" it iswis) -: Vec<u8>o&Self    l:rper2, }

implet fct(" it isw Is  othersh=s ew     le conserls to f s a tva,is) -tet<I>./// s#[in  ne]r<Item = I>>    l<B: Into<Vec<u8>>>(is) -: BldErrt fct(" it isw    t fct(" {wis) -: is) -Z ne ()r     l:rpper( &Self     // Is  other.u=s ew ge    le conserls to f s a tva,is) -tet<I>./// s#[in  ne]r<Item = I>>ge    l<B: Into<Vec<u8>>>(is) -: BldErrt fct(" it isw    t fct(" {wis) -: is) -Z ne ()r     l:rnoughi}

        // Is  othershus, is) -tin
//   lie = S.   re#[in  ne]r<Item = I>>asfis) ->aseFoldErr&[u8] it isw    aseFo.e few   re     // Is Yield wownncship anco beis) -tinend 
//   lie = S.   reet.  algurmuNoewing isvai omirca``awayfwheI weho be conser    "    l"ean    ./// s#[in  ne]r<Item = I>>getofis) ->seFoldErrVec<u8>cpper1, upp    te few   re     // Is  othershus, ) -gthstfto    lie = S inris) -ntoto #[in  ne]r<Item = I>>w ->aseFoldErrreseecpper1, upp    tasfis) ->)i) ->)

        // Is  other.upper());a   (nhat));vaer1erence-ohaal/ ranis) -ntoto #[in  ne]r<Item = I>>re we're aseFoldErrper2)
    }
}

t(ast: ->) == 0

        // Is  other.upper());a   (nhat));vaer1erence-oi o    l.   re#[in  ne]r<Item = I>>re w to   seFoldErrper2)
    }
}

t(astw to 

        // Is Marksm            tas
 isn't go<Ite   /// set. Ie    le consers[aof n an  e fchee  he.i   fn case  n// set.  she ::etossfcanward`]t{  bsnotfchee   ge    le consersntoto #[in  ne]r<Item = I>>
ine!sei to   en secundcpper1, upp    t    le=anough   }
      // Is Rdver2)hus, is) -tin
//   lie = S.   re#[in  ne]r<Item = I>>ndver2)> en secundcpper1, upp    tis) -nndver2)>ean// s     // Is Ehee               twl S.va.r       tet<I>./// si): be part Iarmper1erence-oi osei to gn   n t    er1 &oo-op.     #[in  ne]r<Item = I>>  ee  > en secund):il:r&t fct("dcpper1, upp   !possire w to  a].n// s// s    s of tan// s    }   assert    tis) -n  ee  _f  fnslic (&.iqiis) -);&Self     // Is Trims mper1erence-osuuted at (nhatvalS proba`len`ce fewn (m f .iI2e_fold_simp   erence-ohaalfewnsaeeof `len`ce fewoflf.ced n (m f  /uning ged./// set. Ot weopti,eo be conser    markf sahetn    l.   re#[in  ne]r<Item = I>>keep_ probeis) -> en secund):en: reseedcpper1, upp     n >=     t. ->) it iswo rangess of tan// s    }   assert    t
ine!sei to  a   }
         tis) -n run otp>) - an// s     // Is Trims mper1erence-osuuted at (nhatvalS    a`len`ce fewn (m f .iI2 //  n// set. erence-ohaalfewnsaeeof `len`ce fewoflf.ced n (m f  /uning ged./// set. Ot weopti,eo be conser    markf sahetn    l.   re#[in  ne]r<Item = I>>keep_     is) -> en secund):en: reseedcpper1, upp     n >=     t. ->) it iswo rangess of tan// s    }   assert    t
ine!sei to  a   }
         tis) -nds./t(..    t. ->) -v!.c);

        // Is  other.upper()); 1 er1beli aning isvai o conser    e cahatvo m     an o         frsves.
or` e d er1thuufsar'a goo scs tid Ie can  e th llons.T// sI>>re  yiserous  seFoldErrper2)
    }
}

t(astre we're d || (t(ast: ->) == 1s&&)rank(    tasfis) ->)[0]) >= 250)

     }

impleFnte<u8>ccan t fct(" it iswfn f  f(is) : r8ldErrt fct(" it isw    t fct("ay,nd cavec![is) ])

     }

impleFnte<ingr>ccan t fct(" it iswfn f  f(ch: ingrldErrt fct(" it isw    nd calloc:: allys::ToSallys;t isw    t fct("ay,nd cach."oeodg_utf8> en s[0; 4]).tof allys  )

     }

impleAsRef<[u8]>ecan t fct(" it iswfn asf 
f(aseFoldErr&[u8] it isw        tasfis) ->)&Self  }

impleco e::fmt::Debug1can t fct(" it iswfn fmt>aseFod)f       co e::fmt::Ff m`tt(sldErrco e::fmt::Rlf.is(it iswo raer2)tagg  e,     t    le{ "E"   returns"I"a};   assertsidebug_tuse (tag he ranges hav.field(&cr Ie::srbug::Bs) ->seFotasfis) ->)) he ranges hav.fin sh  
      }

art A " th alced:"1alle1aral rejtc1s wind up caral {  bsn an  anges[w
  
art executlyseatw ftc::{  probaim " th alced:"1ose lo.
   /art    fn case   bfr's/m'pi osebar"er a{
    ryt apto sebar"b's/mopti'[{  bsb 
d_si`,j   t fb r'nd c's/mopti'[aof n an  angesaFioegt's/m'p{  bsaabled tine
d_si tiority. How an   bfr's/mopti'[i osebar"er  proboflf.cedebar"t ap's/m'
et. afcaus  [atpaccepthe.iIn t    andigneit wea's/mopti'[an 's/m'[aof anges[/t
et. a " th alced:"1ose lo.
   /art Noewing iswe (nhatre teeer1all cas e "set."aonal exf et<I>)ar[1qr"oegtrf
et.         ,ety sebar"beachooner   osfor. A a`sebar"`sw  bs (jtc1/=serence-
et. r2 =s th ls ising is       tals. dorexisnstbnset(oall . Thu , an icbuild
et. o be"ctlx
as"oseqr"oeg,Iwe simply (nhatkeep wind up caral { rgtsuueg sfully
et. sebar"er. (Sioegtwe do    nend araver2eqh onerwoningsfwheI wehwe[aof anne
d_si nce simplific Is) st/ rg abme(Iseate    gt<I>)  ca ann/
t fckua];
e d I've
d_sin an  se n t    d cahrpter1( p i ll . Bar'nd caarmp.rheurisn a   mitt  ///im kigdsen        tlf::crence
,rmp.r[seecaarmp.r  putst/ rgt r1usually
et. an oesmollo)/#[ingtve(Debug)]
sppec1/Pth alced:Trie it isw Is T l,ita) -tin
//   all . Th.r  des isii,ita) tin
//   vectrceiesiqueID.T// sita) -: Vec<Sta) >,/// set. That vecr  di otpsswpteraita) -t    m      t Ies. .l aabled haae_fold_simpl,iamo le-gthses ` t Ies` e d er1  desbrob impl,iamo ita) tID.T// sart A sta) twl S.id otifin  `sid` er1 &m      t Ie());a   (nhat))n// set.   ngese [sid]ois_pnce()`. Th.ropis)  s to f  /th.r  des isio be conserl// set.  m `, tk.
t apto fectca   . Th.r  des i oiffFit b i1 s tvaal d ifinstbne// set. (sousZeroU[see.T// s ngese : Vec<Opis) <ousZeroU[see>>,/// set. Th.r  des  seollocat emo fectei is       taddnd an //   all . S ar s  ie_fold_si1 e d encrdmea`s b i1 f  fnan or conserlsuueg sfullytaddnd an //(oall .e_folei itent(self  des: resee, }

art A st aleeita) tin
a all . U2)s 
,ipare to  For otether1can instalansiIs) s./#[ingtve(Debug, Defa.is)]
sppec1/Sta)  it isw Is Spare to  For otether1isio bealansiIs) stoutstfto     t Ie. TlansiIs) se// set. (   pnr"er byeeyti. Th rgt r1 t c::{ oner uutealansiIs)  can  no/_fold_si arttculareeyti./_folalans: Vec<(u8, reseed>, }

implePth alced:Trie it isw Is Mtlx
see /th.rgt<I>)[1qr"oegtrfr. A sequIw    e For rvir<I th alced:::max(lowesformsemant a ototo  to be part echar`keep_    l` er1alui,eo be    ln sserfrnan or conserlre  /t e rse// set. kept. T    er1re fulow
   deallysewl S.  fullytlf::creed she `Ing ie_fold_si(nhat     /ts     le consersniIn t al asti,ety[aof keep alrlre  /t en// set. erence-tsahe    leb r'nd cwe knlo we' bsn an  nend ao m      thust ae// set. (fonscarem e d b r'nd c the (movhd erence-tsargtgualanteed ao n an    return nges.   reI>>ctlx
see winnsers       Vec<t fct(">, keep_    l:rper2tcpper1, uppnd cco e::cell::RlfCell;&
    continuMSRV(1.61): U2)lre  /t_en t/ rgteo   //  intetior)en ability.   assert et,all c= RlfCell c  fnPth alced:Trie it isw isw     ta) -: vec![]i_ oncat(aat(a ngese : vec![]i_ oncat(aat(aei itent(self  des: 1i_ oncat(a});      e("er2)en s
ine!sei to c= vec![];      e("econsersnre  /t(|.iq|r{_ oncat(aat(a nges all .bm `ow_en s,.sebar" wintasfis) ->))fit iswo ranges,
  Ok(_ g oralui,t iswo ranges,
  Err(i g orit iswo rangesngesnges   !keep_    lrit iswo rangesngesngesat(a nne!sei to .push i.checked_sub(1).unwrap>)ges.pus// s               }
        while  reIough/_fol             a < drain_end    other: dan// sngescan itin

ine!sei to cthe ranges hav!consers[i]t
ine!sei to  a   }
     }

        // Is  othersh`Ok`fi);// agt<I>)eyti/rallyseis eccepthe>getoteeer1all ca te_fold_si`Err`mot weopti. Th.r  des can t gtsuueg s astieco `, tk.
sf self.::max(low ?des isio be consertaddnd. Th.r  des can t gte `or astieco `, tk.
sf se_fold_simpl, ?des isio be consertals. dorbnset(oall  fcato thvea`nd // agt<I>e_fold_sieyti/rallyseInterbelyseaddnd. (ecilooamplidst  [atpas th ls isinge (nes
   d_siet<I>.)o<Ite   /// set. Ieeshor),hus, is) /rallysegt<I>) s eccepthe>getotee(oall  ));a   (nha::max(low ); 1 er1 kier" pacan i  e tanges[w
   executlyseat th alced:wesforn// set. ine lo.
e nefcedebar"> en secund)is) -: &[u8]ldErrRlf.is<resee, resee>fit isw e("er2)en s thvg      troo  a   }
           }ence(idxng      t ngese [ thv]d);
    }

    s of tsErr(idx.get>)ges.pus// s}n// sngescan &b inris) -n l

Ftr{_ oncat(aat(a nges     t ta) -[ thv].alans.binary_ine lofis_key(&b, |q|rt.0)fit iswo ranges,
  Ok(i g orit iswo rangesngesnges thvg      t ta) -[ thv].alans[i]t1;t iswo rangesngesnges      }ence(idxng      t ngese [ thv]d);
    }

    
    }

    s of tsErr(idx.get>)ges.pus// s               }
        while}t iswo ranges,
  Err(i g orit iswo rangesngesnges   }ei is      tcs. If_ ta) (ges.pus// s                t ta) -[ thv].alans.debar">i, (b, ei i)ges.pus// s             thvg  ei ies.pus             a < drain_end    other: &Self,
   is idxs      tei itent(self  des   }
         tei itent(self  des += 1;   assert    t
igese [ thv]d=sousZeroU[see c  fnidxn;   assertOk(idxn   re     // Is  othershus, roo  ita) tID` e d efb ti        exisn, cs. Ifs   .   asI>>noo   en secundcErrreseecpper1, upp   !possi t Ies.re we're d it iswo ranges0
          returns `None`.
       tcs. If_ ta) (g  }
     }

        // Is Cs. Ifs =s ew  essaeraaco)aLitrother.uiqueID.T// sI>>cs. If_ ta) ( en secundcErrreseecpper1, upp is idg      t ta) -.  ->)nd<Itesert    t ta) -.push Sta) ::srfa.is>)ges.pus// s    t
igese .push ous.a   }
      d
      }

art  othershus, "rank" isinge gt<I>)eyti.
   /art Ter
ctlx
um)ranktvalue er1`0`se theer
caximum ranktvalue er1`255`.
   /art Ter
ranktisii,is) /i cdegtver(Intererheurisn a eaakgrfu   dirallbuther1is
d_si`,la mvo frsves.cig v ncis) -ZaTwerheurisn a sled tg is owweho beranktisii
d_sieyti,eo be g s e cahatv/aovbs) /i ceo  ppne tin
any a biala oehledtack.nm = I>>nank(is) : r8ldErru8cpper1,cr Ie::nank::BYTE_FREQUENCIES[u[see cf  f(is) )]
}

#[cfg(t st)]
motheesnstpper1,nd csuper::*;    //I>>pare (p`tt(sn: &ralldErrHircpper1, uppcr Ie::Pare rBuilder::  fn).utf8>noughg.buildn).pare (p`tt(sn).unwrap>)s.pus     //I>> th ssio(p`tt(sn: &ralldErrSeqfit isw e("Ef::creor::  fn).k  d(Ef::creK  d::Pth ss).lf::cre(&pare (p`tt(sn))s.pus     //I>>sionssio(p`tt(sn: &ralldErrSeqfit isw e("Ef::creor::  fn).k  d(Ef::creK  d::Sften ).lf::cre(&pare (p`tt(sn))s.pus     //I>> (p`tt(sn: &ralldErr(etqD etqtcit isw e("( th ssio(p`tt(snecaeionssio(p`tt(sn))s.pus     //#[ollow(nce_[nine!asti)]   //I>>E(x: &ralldErrt fct(" it isw    t fct("ay,nd caxtasfis) ->))s.pus     //#[ollow(nce_[nine!asti)]   //I>>I(x: &ralldErrt fct(" it isw    t fct("aysei to  xtasfis) ->))s.pus     //f>)[1q<I: IntoIA setor<IA mg  t fct(">>(il:rIldErrSeqfit isw e("end ca  fnrror it)s.pus     //f>)seton co(edErr(etqD etqtcit isw e("(cnd cgeton co(e,tcnd cgeton co(e)s.pus     //f>)se    l<I1, I2>(il1:rI1,II>2:rI2edErr(etqD etqt   //erloet isw e("I1: IntoIA setor<IA mg  t fct(">,t iswo raI2: IntoIA setor<IA mg  t fct(">,t iswit isw e("(cnd ca  fnrror it1e,tcnd ca  fnrror it2))s.pus     //I>>    l<B: AsRef<[u8]>, I: IntoIA setor<IA mg  B>>(il:rIldErr(etqD etqtcit isw e("    e1fctcnd c  fnit);      e("er2)s2e=.s1tely if ;      e("(s1,Is2)s.pus     //I>>api<B: AsRef<[u8]>, I: IntoIA setor<IA mg  B>>(il:rIldErr(etqD etqtcit isw e("    (en s ,)en seng      lnit);      e("p apis
seefe t_ th sseis_ th alced:(:Se// s// s .apis
seefe t_[ften eis_ th alced:( ;      e("( ,)s)s.pus     //#[eesn]   //I>>ent(sel d it iswo ra("bar"),nd     ln["a"]ecae("a")ges.pus// s("bar"),nd     ln["aaaaa"]ecae("aaaaa")ges.pus// s("bar"),nd     ln["A", "a"]ecae("(?i-u)a")ges.pus// s("bar"),nd     ln["AB", "Ab", "aB", "ab"]ecae("(?i-u)ab")ges.pus// s("bar"),nd     ln["abC", "abc"]ecae("ab(?i-u)c")gess.pus// s("bar"),nd     ln[b"\xFF"]ecae(r"(?-u:\xFF)")gess.pus// s#[cfg(fee ui c= "unieodg-asti")]   //nges{     
   Self("bar"),nd     ln["☃"]ecae("☃")ges.pus// s    ("bar"),nd     ln["☃"]ecae("(?i)☃")ges.pus// s    ("bar"),nd     ln["☃☃☃☃☃"]ecae("☃☃☃☃☃")gess.pus// s    ("bar"),nd     ln["Δ"]ecae("Δ")ges.pus// s    ("bar"),nd     ln["δ"]ecae("δ")ges.pus// s    ("bar"),nd     ln["Δ", "δ"]ecae("(?i)Δ")ges.pus// s    ("bar"),nd     ln["Δ", "δ"]ecae("(?i)δ")gess.pus// s    ("bar"),nd     ln["S", "s", "ſ"]ecae("(?i)S")ges.pus// s    ("bar"),nd     ln["S", "s", "ſ"]ecae("(?i)s")ges.pus// s    ("bar"),nd     ln["S", "s", "ſ"]ecae("(?i)ſ")ges.pus// s}n      e("er2).ett(sue=."ͱͳͷΐάέήίΰαβγδεζηθικλμνξοπρςστυφχψωϊϋ"es.pus// s("bar"),nd     ln[.ett(su]ecae(.ett(su));

        //#[eesn]   //I>>cl("b d it iswo ra("bar"),nd     ln["a", "b", "c"]ecae("[abc]")ges.pus// s("bar"),nd     ln["a1b", "a2b", "a3b"]ecae("a[123]b")ges.pus// s("bar"),nd     ln["δ", "ε"]ecae("[εδ]")ges.pus// s#[cfg(fee ui c= "unieodg-asti")]   //nges{     
   Self("bar"),nd     ln["Δ", "Ε", "δ", "ε", "ϵ"]ecae(r"(?i)[εδ]")ges.pus// s}s.pus     //#[eesn]   //I>>eook d it iswo ra("bar"),nd     ln["ab"]ecae(r"a\Ab")ges.pus// s("bar"),nd     ln["ab"]ecae(r"a\zb")ges.pus// s("bar"),nd     ln["ab"]ecae(r"a(?m:^)b")ges.pus// s("bar"),nd     ln["ab"]ecae(r"a(?m:$)b")ges.pus// s("bar"),nd     ln["ab"]ecae(r"a\bb")ges.pus// s("bar"),nd     ln["ab"]ecae(r"a\Bb")ges.pus// s("bar"),nd     ln["ab"]ecae(r"a(?-u:\b)b")ges.pus// s("bar"),nd     ln["ab"]ecae(r"a(?-u:\B)b")gess.pus// s("bar"),nd     ln["ab"]ecae(r"^ab")ges.pus// s("bar"),nd     ln["ab"]ecae(r"$ab")ges.pus// s("bar"),nd     ln["ab"]ecae(r"(?m:^)ab")ges.pus// s("bar"),nd     ln["ab"]ecae(r"(?m:$)ab")ges.pus// s("bar"),nd     ln["ab"]ecae(r"\bab")ges.pus// s("bar"),nd     ln["ab"]ecae(r"\Bab")ges.pus// s("bar"),nd     ln["ab"]ecae(r"(?-u:\b)ab")ges.pus// s("bar"),nd     ln["ab"]ecae(r"(?-u:\B)ab")gess.pus// s("bar"),nd     ln["ab"]ecae(r"ab^")ges.pus// s("bar"),nd     ln["ab"]ecae(r"ab$")ges.pus// s("bar"),nd     ln["ab"]ecae(r"ab(?m:^)")ges.pus// s("bar"),nd     ln["ab"]ecae(r"ab(?m:$)")ges.pus// s("bar"),nd     ln["ab"]ecae(r"ab\b")ges.pus// s("bar"),nd     ln["ab"]ecae(r"ab\B")ges.pus// s("bar"),nd     ln["ab"]ecae(r"ab(?-u:\b)")ges.pus// s("bar"),nd     ln["ab"]ecae(r"ab(?-u:\B)")gess.pus// s et,      t f= (t(q([I("aZ"ecaE("ab")]ecaece([I("Zb"ecaE("ab")]eges.pus// s("bar"),nd       t cae(r"^aZ*b")ges.pus     //#[eesn]   //I>>repetiIs)  d it iswo ra("bar"),nd     ln["a", ""]ecae(r"a?")ges.pus// s("bar"),nd     ln["", "a"]ecae(r"a??")ges.pus// s("bar"),nd sei to  [I("a"ecaE("")], [I("a"ecaE("")]ecae(r"a*")ges.pus// s("bar"),nd sei to  [E(""), I("a"e], [E(""), I("a"e]ecae(r"a*?")ges.pus// s("bar"),nd sei to  [I("a"e], [I("a"e]ecae(r"a+")ges.pus// s("bar"),nd sei to  [I("a"e], [I("a"e]ecae(r"(a+)+")gess.pus// s("bar"),nd     ln["ab"]ecae(r"aZ{0}b")ges.pus// s("bar"),nd     ln["aZb", "ab"]ecae(r"aZ?b")ges.pus// s("bar"),nd     ln["ab", "aZb"]ecae(r"aZ??b")ges.pus// s("bar"),nd    assertrwiseei to  [I("aZ"ecaE("ab")], [I("Zb"ecaE("ab")]e,t iswo rangese(r"aZ*b")t iswo rages.pus// s("bar"),nd    assertrwiseei to  [E("ab"), I("aZ"e], [E("ab"), I("Zb")]e,t iswo rangese(r"aZ*?b")t iswo rages.pus// s("bar"),nd eei to  [I("aZ"e], [I("Zb"e]ecae(r"aZ+b")ges.pus// s("bar"),nd sei to  [I("aZ"e], [I("Zb"e]ecae(r"aZ+?b")gess.pus// s("bar"),nd     ln["aZZb"]ecae(r"aZ{2}b")ges.pus// s("bar"),nd sei to  [I("aZZ"e], [I("ZZb"e]ecae(r"aZ{2,3}b")gess.pus// s("bar"),nd     ln["abc", ""]ecae(r"(abc)?")ges.pus// s("bar"),nd     ln["", "abc"]ecae(r"(abc)??")gess.pus// s("bar"),nd sei to  [I("a"ecaE("b")], [I("ab"ecaE("b")]ecae(r"a*b")ges.pus// s("bar"),nd sei to  [E("b"), I("a"e], [E("b"), I("ab")]ecae(r"a*?b")ges.pus// s("bar"),nd sei to  [I("ab")], [I("b")]ecae(r"ab+")ges.pus// s("bar"),nd sei to  [I("a"ecaI("b")], [I("b")]ecae(r"a*b+")gess.pus// srt  IXME: T l,iionssioscan t    do    look qu co r[a];
aoe i. I ust kl// splic_simpl,r[a];
iionssios{cif sbe: [I(acecaI(bcecaE(c)]ZaTwerm f 
atsue Il// splic_simplyk  r1ng issionssios r.rcompu"er byent(setlyseovncecon otpnothers
it elit_lasi>>ndver2), e theern [bc, ec, c]wesforlyseis   deer and tc1/a  fl// splic_simpato er2p usivo. We  asos)e-lealfew mwise
   retur eo fineu, s te_follit_laswe getimpl,iamo thf.is, s t 1 er1 i?enstur e is e   aIcsup kig.   assertIs   assertIs T l,leaser(why t    er    anoatsue er1ng isit (nhatmesr s up
plicit e= o` e alced:wesfor, e thcurr"o
or` sionssios r.rn an  re d in
a
plicit e= o    i iserloen th alced:wesformm`tt(ss.i   f th ssioId i
itt(ss
it elit_lasber'nd cwe pncedimest{ar  e tnd c th llonss wl So   co firm`ther   relit_lasw
   eal isio be conseros r.rz   le( tdempals'n noelook-arfu  ). Bace_follit_laswe n an  d tvaal lf { ften lat Anyedime {e,nd csuf ssio awe albled
it elit_lasi>clude  eco firm`ther stup.iI2 // t  an  ing gesh oduced 'see cahal// splic_simpls bug1{  bsn t fao e f ssid abme(    adime Ielookid a  cappne d
it elit_lashardran do pn.s.pus// s("bar"),nd    assertrwiseei to  [I("a"ecaI("b")caE("c")], [I("bc"), I("ac")caE("c")]e,t iswo rangese(r"a*b*c")t iswo rages.pus// s("bar"),nd    assertrwiseei to  [I("a"ecaI("b")caE("c")], [I("bc"), I("ac")caE("c")]e,t iswo rangese(r"(a+)?(b+)?c")t iswo rages.pus// s("bar"),nd    assertrwiseei to  [I("a"ecaI("b")caE("c")], [I("bc"), I("ac")caE("c")]e,t iswo rangese(r"(a+|)(b+|)c")t iswo rages.pus// srt A few mwisesimilarish each utiid oticalto fin -ZaTwese cay eate  ::maxa` rinusimilaro` iblem essfolve.s.pus// s("bar"),nd    assertrwiseei to  s.pus            [I("a"ecaI("b")caI("c")caE("")],s.pus            [I("c"ecaI("b")caI("a"ecaE("")]s.pus        e,t iswo rangese(r"a*b*c*")t iswo rages.pus// s("bar"),nd eei to  [I("a"ecaI("b")caI("c")], [I("c")]ecae(r"a*b*c+")ges.pus// s("bar"),nd sei to  [I("a"ecaI("b")], [I("bc")]ecae(r"a*b+c")ges.pus// s("bar"),nd sei to  [I("a"ecaI("b")], [I("c"ecaI("b")]ecae(r"a*b+c*")ges.pus// s("bar"),nd sei to  [I("ab")caE("a")], [I("b")caE("a")]ecae(r"ab*")ges.pus// s("bar"),nd    assertrwiseei to  [I("ab")caE("ac")], [I("bc"), E("ac")]e,t iswo rangese(r"ab*c")t iswo rages.pus// s("bar"),nd sei to  [I("ab")], [I("b")]ecae(r"ab+")ges.pus// s("bar"),nd sei to  [I("ab")], [I("bc")]ecae(r"ab+c")gess.pus// s("bar"),nd    assertrwiseei to  [I("z"), E("azb")], [I("zazb"), E("azb")]e,t iswo rangese(r"z*azb")t iswo ragess.pus// s et,      t f=t iswo rangese   ln["aaa", "aab", "aba", "abb", "baa", "bab", "bba", "bbb"]ees.pus// s("bar"),nd       t cae(r"[ab]{3}")ges.pus// s et,      t f= eei to  s.pus        [s.pus            I("aaa"),s.pus            I("aab"),s.pus            I("aba"),s.pus            I("abb"),s.pus            I("baa"),s.pus            I("bab"),s.pus            I("bba"),s.pus            I("bbb"),s.pus        ],s.pus        [s.pus            I("aaa"),s.pus            I("aab"),s.pus            I("aba"),s.pus            I("abb"),s.pus            I("baa"),s.pus            I("bab"),s.pus            I("bba"),s.pus            I("bbb"),s.pus        ],s.pus    ees.pus// s("bar"),nd       t cae(r"[ab]{3,4}")ges.pus     //#[eesn]   //I>>con ot(tcit isw e("     essa: [&ral; 0]d=s[]; s.pus// s("bar"),nd     ln["abcxyz"]ecae(r"abc()xyz")ges.pus// s("bar"),nd     ln["abcxyz"]ecae(r"(abc)(xyz)")ges.pus// s("bar"),nd     ln["abcmnoxyz"]ecae(r"abc()mno()xyz")ges.pus// s("bar"),nd     ln essaecae(r"abc[a&&b]xyz")ges.pus// s("bar"),nd     ln["abcxyz"]ecae(r"abc[a&&b]*xyz")ges.pus     //#[eesn]   //I>>alonsnother d it iswo ra("bar"),nd     ln["abc", "mno", "xyz"]ecae(r"abc|mno|xyz")ges.pus// s("bar"),nd    assertrwiseei to  s.pus            [E("abc"ecaI("mZ"ecaE("mo"ecaE("xyz")],s.pus            [E("abc"ecaI("Zo"ecaE("mo"ecaE("xyz")]s.pus        e,t iswo rangese(r"abc|mZ*o|xyz")s.pus    ees.pus// s("bar"),nd     ln["abc", "xyz"]ecae(r"abc|M[a&&b]N|xyz")ges.pus// s("bar"),nd     ln["abc", "MN", "xyz"]ecae(r"abc|M[a&&b]*N|xyz")gess.pus// s("bar"),nd     ln["aaa", "aaaaa"]ecae(r"(?:|aa)aaa")ges.pus// s("bar"),nd    assertrwiseei to  s.pus            [I("aaa"ecaE(""), I("aaaaa"ecaE("aa")],s.pus            [I("aaa"ecaE(""), E("aa")]s.pus        e,t iswo rangese(r"(?:|aa)(?:aaa)*")t iswo rages.pus// s("bar"),nd    assertrwiseei to  s.pus            [E(""), I("aaa"), E("aa"), I("aaaaa"e],s.pus            [E(""), I("aaa"), E("aa")]s.pus        e,t iswo rangese(r"(?:|aa)(?:aaa)*?")t iswo ragess.pus// s("bar"),nd    assertrwiseei to  [E("a"ecaI("b")caE(""e], [E("a"ecaI("b")caE(""e]e,t iswo rangese(r"a|b*")t iswo rages.pus// s("bar"),nd eei to  [E("a"ecaI("b")], [E("a"ecaI("b")]ecae(r"a|b+")gess.pus// s("bar"),nd    assertrwiseei to  [I("a"ecaE("b")caE("c")], [I("ab"ecaE("b")caE("c")]e,t iswo rangese(r"a*b|c")t iswo ragess.pus// s("bar"),nd    assertrwiseei to  s.pus            [E("a"ecaE("b")caI("c")caE("")],s.pus            [E("a"ecaE("b")caI("c")caE("")]s.pus        e,t iswo rangese(r"a|(?:b|c*)")t iswo ragess.pus// s("bar"),nd    assertrwiseei to  s.pus            [I("a"ecaI("b")caE("c")caI("a"ecaI("ab"ecaE("c")],s.pus            [I("ac"ecaI("bc")caE("c")caI("ac")caI("abc")caE("c")],s.pus        e,t iswo rangese(r"(a|b)*c|(a|ab)*c")t iswo ragess.pus// s("bar"),nd    assertrwis    ln["abef", "abgh", "cdef", "cdgh"]e,t iswo rangese(r"(ab|cd)(ef|gh)")t iswo rages.pus// s("bar"),nd    assertrwis    ln[s.pus            "abefij", "abefkl", "abghij", "abghkl", "cdefij", "cdefkl",s.pus            "cdghij", "cdghkl",s.pus        ]e,t iswo rangese(r"(ab|cd)(ef|gh)(ij|kl)")t iswo ragess.pus// s("bar"),nd eei to  [E("abab")], [E("abab")]ecae(r"(ab){2}")gess.pus// s("bar"),nd sei to  [I("abab")], [I("abab")]ecae(r"(ab){2,3}")gess.pus// s("bar"),nd sei to  [I("abab")], [I("abab")]ecae(r"(ab){2,}")ges.pus     //#[eesn]   //I>>im kier" p(tcit isw e("     essa: [&ral; 0]d=s[]; s.pus// s("bar"),nd     ln essaecae(r"[a&&b]")ges.pus// s("bar"),nd     ln essaecae(r"a[a&&b]")ges.pus// s("bar"),nd     ln essaecae(r"[a&&b]b")ges.pus// s("bar"),nd     ln essaecae(r"a[a&&b]b")ges.pus// s("bar"),nd     ln["a", "b"]ecae(r"a|[a&&b]|b")ges.pus// s("bar"),nd     ln["a", "b"]ecae(r"a|c[a&&b]|b")ges.pus// s("bar"),nd     ln["a", "b"]ecae(r"a|[a&&b]d|b")ges.pus// s("bar"),nd     ln["a", "b"]ecae(r"a|c[a&&b]d|b")ges.pus// s("bar"),nd     ln[""]ecae(r"[a&&b]*")ges.pus// s("bar"),nd     ln["MN"]ecae(r"M[a&&b]*N")ges.pus     //t. That eesnstp`tt(snr1ng is     /t pncedhs a tv isdefea1s wind up   //t. deterence,1usuallysber'nd cI> {cif sbllo  nce   mit (ntvaeototalrnua, m   //t. rfr. A sequIaral astte frothered./// set
sertIs T l,m f 
ad a  r1ng iswduce       tlf::crenceosees pncedhs a tv i
sertIs it knlos[{  bsbllo a   mit,ed n (plaegsait {  S.  markfscaral sled
it e///" thel.range[{  bs nges rloen" ecileh utineeg sarihatalui,eo b   //t. rver-esnimother1i ojprovtone can t gtpur kigserfr. A seqtlf::crence,/// setsber'nd cmpl, mpreci2mer(        
itt(s:o so eig1i ceoo eig./// set
sertIs T    er1ini/
t fc(oallckin  par s rfr. A seqtlf::crence,aFioegtwe n  en// sets)goodke:nungaa/// ncorch consertlf::crenceoop(setl) stand tc1hat  m kign// setswl S.va.rmarkfssntoto #[eesn]   //I>>athust a d it iswo ra("bar"),nd geton co(e,te(r".")ges.pus// s("bar"),nd seton co(e,te(r"(?s).")ges.pus// s("bar"),nd seton co(e,te(r"[A-Za-z]")ges.pus// s("bar"),nd seton co(e,te(r"[A-Z]")ges.pus// s("bar"),nd     ln[""]ecae(r"[A-Z]{0}")ges.pus// s("bar"),nd seton co(e,te(r"[A-Z]?")ges.pus// s("bar"),nd seton co(e,te(r"[A-Z]*")ges.pus// s("bar"),nd seton co(e,te(r"[A-Z]+")ges.pus// s("bar"),nd (t(q([I("1")]ecacnd cgeton co(e),te(r"1[A-Z]")ges.pus// s("bar"),nd (t(q([I("1")]ecat(q([I("2")]eg,te(r"1[A-Z]2")ges.pus// s("bar"),nd (cnd cgeton co(e,tt(q([I("123")]eg,te(r"[A-Z]+123")ges.pus// s("bar"),nd seton co(e,te(r"[A-Z]+123[A-Z]+")ges.pus// s("bar"),nd seton co(e,te(r"1|[A-Z]|3")ges.pus// s("bar"),nd    assertrwis(t(q([E("1")caI("2")caE("3")]ecacnd cgeton co(e),t iswo rangese(r"1|2[A-Z]|3"),t iswo rages.pus// s("bar"),nd    assertrwis(cnd cgeton co(e,tt(q([E("1")caI("2")caE("3")]e),t iswo rangese(r"1|[A-Z]2|3"),t iswo rages.pus// s("bar"),nd    assertrwis(t(q([E("1")caI("2")caE("4")]ecat(q([E("1")caI("3")caE("4")]e),t iswo rangese(r"1|2[A-Z]3|4"),t iswo rages.pus// s("bar"),nd (cnd cgeton co(e,tt(q([I("2")]eg,te(r"(?:|1)[A-Z]2")ges.pus// s("bar"),nd sei to  [I("a"e], [I("z")]ecae(r"a.z")ges.pus     //t. L carmpe 'athust a' eesn abme(i  re sesmoller   mittr   osforf selesn
plic_simpl,logic f  fnff usivolytabor"t ap consertlf::crenceow
     c t(qs getn// sets)go eig./// s#[eesn]   //I>>athust a_smoll_  mitt d it iswo raI>> th ssio(p`tt(sn: &ralldErrSeqfit isw e(" e("Ef::creor::  fn)s.pus            .k  d(Ef::creK  d::Pth ss)s.pus            .  mit_total(10)s.pus            .lf::cre(&pare (p`tt(sn))s.pus// s}n      e("I>>sionssio(p`tt(sn: &ralldErrSeqfit isw e(" e("Ef::creor::  fn)s.pus            .k  d(Ef::creK  d::Sften )s.pus            .  mit_total(10)s.pus            .lf::cre(&pare (p`tt(sn))s.pus// s}n      e("I>> (p`tt(sn: &ralldErr(etqD etqtcit isw e(" e("( th ssio(p`tt(snecaeionssio(p`tt(sn))s.pus// s}n      e("("bar"),nd    assertrwis(t iswo ranges,
  poqn[s.pus                I("aaa"),s.pus                I("aab"),s.pus                I("aba"),s.pus                I("abb"),s.pus                I("baa"),s.pus                I("bab"),s.pus                I("bba"),s.pus                I("bbb")s.pus            ]),s.pus            poqn[s.pus                I("aaa"),s.pus                I("aab"),s.pus                I("aba"),s.pus                I("abb"),s.pus                I("baa"),s.pus                I("bab"),s.pus                I("bba"),s.pus                I("bbb")s.pus            ])s.pus        e,t iswo rangese(r"[ab]{3}{3}")t iswo ragess.pus// s("bar"),nd eeton co(e,te(r"ab|cd|ef|gh|ij|kl|mn|op|qr|st|uv|wx|yz")ges.pus     //#[eesn]   //I>>we're d it iswo ra("bar"),nd     ln[""]ecae(r"")ges.pus// s("bar"),nd     ln[""]ecae(r"^")ges.pus// s("bar"),nd     ln[""]ecae(r"$")ges.pus// s("bar"),nd     ln[""]ecae(r"(?m:^)")ges.pus// s("bar"),nd     ln[""]ecae(r"(?m:$)")ges.pus// s("bar"),nd     ln[""]ecae(r"\b")ges.pus// s("bar"),nd     ln[""]ecae(r"\B")ges.pus// s("bar"),nd     ln[""]ecae(r"(?-u:\b)")ges.pus// s("bar"),nd     ln[""]ecae(r"(?-u:\B)")ges.pus     //#[eesn]   //I>>odds_and_endb d it iswo ra("bar"),nd (cnd cgeton co(e,tt(q([I("a")]eg,te(r".a")ges.pus// s("bar"),nd (t(q([I("a")]ecacnd cgeton co(e),te(r"a.")ges.pus// s("bar"),nd seton co(e,te(r"a|.")ges.pus// s("bar"),nd seton co(e,te(r".|a")gess.pus// s et,p`t = r"M[ou]'?am+[ae]r .*([AEae]l[- ])?[GKQ]h?[aeu]+([dtz][dhz]?)+af[iy]"es.pus// s et,      t f= eei to  s.pus        ["Mo'am", "Moam", "Mu'am", "Muam"]t
ip(I),s.pus        [s.pus            "ddafi", "ddafy", "dhafi", "dhafy", "dzafi", "dzafy", "dafi",s.pus            "dafy", "tdafi", "tdafy", "thafi", "thafy", "tzafi", "tzafy",s.pus            "tafi", "tafy", "zdafi", "zdafy", "zhafi", "zhafy", "zzafi",s.pus            "zzafy", "zafi", "zafy",s.pus        ]s.pus        t
ip(I),s.pus    ees.pus// s("bar"),nd       t cae(p`t)gess.pus// s("bar"),nd    assertrwis(t(q(["I>>re ", "fn asf"]t
ip(I)ecacnd cgeton co(e),t iswo rangese(r"I>>re ([A-Z]+)|fn asf([A-Z]+)"),t iswo rages.pus// s("bar"),nd    assertrwissei to  [I("foo"e], [I("quux")]e,t iswo rangese(r"foo[A-Z]+bar[A-Z]+quux")t iswo rages.pus// s("bar"),nd eeton co(e,te(r"[A-Z]+bar[A-Z]+")ges.pus// s("bar"),nd    assertrwis    ln["Sherlock Holmes"]e,t iswo rangese(r"(?m)^Sherlock Holmes|Sherlock Holmes$")t iswo ragess.pus// s("bar"),nd     ln["sa", "sb"]ecae(r"\bs(?:[ab])")ges.pus     //t. That eesnst
,ipecificathtpal=loysewl S. nce heurisn a steps an icducg
plic_simpl,Fier"oeg vlf::creed. T    er1 ear  e trkua]hat   `, tk.
f seo b   //t. typgserfrheurisn as re d e tshllyk  conserlsettr   p:crenego (Shllykt a
sertIs i  do esber'nd cyout{ar  e tbalaoeg "spe    so muuteworkelooklyseIorn// sets)go m thel.rangeu" e th"spe    so muuteworkeproeg slyseIoughi you mvon// sets
igese (Intershor)r. A seqs.")t isw#[eesn]   //#[cfg(fee ui c= "unieodg-asti")]   //fn holmes(tcit isw e("          t f= eei to  s.pus        ["HOL", "HOl", "HoL", "Hol", "hOL", "hOl", "hoL", "hol"]t
ip(I),s.pus        [s.pus            "MES", "MEs", "Eſ", "MeS", "Mes", "eſ", "mES", "mEs", "meS",s.pus            "mes",s.pus        ]s.pus        t
ip(I),s.pus    ees.pus// s    (en s th ssio,)en seionssiong   (r"(?i)Holmes");      e("pth ssioikeep_ probeis) ->3:Se// s// s ften latkeep_     is) ->3);      e("pth ssioictlx
seeeis_ th alced:(:Se// s// s ften latctlx
seeeis_ th alced:(:Se// s// s("bar"),nd       t ca( th ssio,)eionssionges.pus     //t. That eesnstng iswe geti nce k  d rfr. A sequIex::creer(Ian  ebeefin    //t. alonsnotherewl S.astiedebanou mvo modghenabled. A{ oner yin  durt a
sertIs developmea`,impls rotheredh utst a,ia   co mvaeer( nce specierlsaign// setspodgh   Ef::creor::uni(ntvo  ry e therim downio be consertFier"oeg 
sertIs it fc(ouni(nt{cif sbllo o be cmittrset.t isw#[eesn]   //#[cfg(fee ui c= "unieodg-asti")]   //fn holmes_alt(tcit isw e("    en s thf=t iswo ranges th ssio(r"(?i)Sherlock|Holmes|Watson|Ilcee|Adler|John|Baker":Se// s// s("bar"!( thi) ->).unwrap>) > 0);      e("pth apis
seefe t_ th sseis_ th alced:(:Se// s// s("bar"!( thi) ->).unwrap>) > 0);          //t. See: https://gl Sub.com/rust-laog/thtpa/security/advisolle /GHSA-m5pq-gvj9-9vr8   //t. See: CVE-2022-24713/// set
sertIs Wes)e-lempls / rgteo anoui c consertlf::crenceo  m     -tin
leaserablen// sets)ime e d er    
iteriallysimpcreer(b impls  pnr"serfrp`thologicup   //t. repeats./// s#[eesn]   //I>>crazy_repeats d it iswo ra("bar"),nd gei to  [E("")], [E("")]ecae(r"(?:){4294967295}")ges.pus// s("bar"),nd    assertrwiseei to  [E("")], [E("")]ect iswo rangese(r"(?:){64}{64}{64}{64}{64}{64}")t iswo rages.pus// s("bar"),nd eei to  [E("")], [E("")]ecae(r"x{0}{4294967295}")ges.pus// s("bar"),nd gei to  [E("")], [E("")]ecae(r"(?:|){4294967295}")gess.pus// s("bar"),nd    assertrwiseei to  [E("")], [E("")]ect iswo rangese(r"(?:){8}{8}{8}{8}{8}{8}{8}{8}{8}{8}{8}{8}{8}{8}")t iswo rages.pus// s    repac= "a".repeat(100ges.pus// s("bar"),nd    assertrwissei to  [I(&repae], [I(&repae]e,t iswo rangese(r"a{8}{8}{8}{8}{8}{8}{8}{8}{8}{8}{8}{8}{8}{8}")t iswo rages.pus     //#[eesn]   //I>>huge(tcit isw e("    p`t = r#"(?-u)t iswo ra2(?:t iswo rang[45]\d{3}|t iswo rang7(?:t iswo rang  1[0-267]|t iswo rang  2[0-289]|t iswo rang  3[0-29]|t iswo rang  4[01]|t iswo rang  5[1-3]|t iswo rang  6[013]|t iswo rang  7[0178]|t iswo rang  91t iswo rang)|t iswo rang8(?:t iswo rang  0[125]|t iswo rang  [139][1-6]|t iswo rang  2[0157-9]|t iswo rang  41|t iswo rang  6[1-35]|t iswo rang  7[1-5]|t iswo rang  8[1-8]|t iswo rang  90t iswo rang)|t iswo rang9(?:t iswo rang  0[0-2]|t iswo rang  1[0-4]|t iswo rang  2[568]|t iswo rang  3[3-6]|t iswo rang  5[5-7]|t iswo rang  6[0167]|t iswo rang  7[15]|t iswo rang  8[0146-9]t iswo rang)t iswo rag\d{4}|t iswo ra3(?:t iswo rang12?[5-7]\d{2}|t iswo rang0(?:t iswo rang  2(?:t iswo rang    [025-79]\d|t iswo rang    [348]\d{1,2 a < drain_end)|t iswo rang  3(?:t iswo rang    [2-4]\d|t iswo rang    [56]\d?a < drain_end)t iswo rang)|t iswo rang2(?:t iswo rang  1\d{2}|t iswo rang  2(?:t iswo rang    [12]\d|t iswo rang    [35]\d{1,2 |t iswo rang    4\d?a < drain_end)t iswo rang)|t iswo rang3(?:t iswo rang  1\d{2}|t iswo rang  2(?:t iswo rang    [2356]\d|t iswo rang    4\d{1,2 a < drain_end)t iswo rang)|t iswo rang4(?:t iswo rang  1\d{2}|t iswo rang  2(?:t iswo rang    2\d{1,2 |t iswo rang    [47]|t iswo rang    5\d{2}a < drain_end)t iswo rang)|t iswo rang5(?:t iswo rang  1\d{2}|t iswo rang  29t iswo rang)|t iswo rang[67]1\d{2}|t iswo rang8(?:t iswo rang  1\d{2}|t iswo rang  2(?:t iswo rang    2\d{2 |t iswo rang    3|t iswo rang    4\da < drain_end)t iswo rang)t iswo rag\d{3}|t iswo ra4(?:t iswo rang0(?:t iswo rang  2(?:t iswo rang    [09]\d|t iswo rang    7a < drain_end)|t iswo rang  33\d{2}a < drain_e)|t iswo rang1\d{3}|t iswo rang2(?:t iswo rang  1\d{2}|t iswo rang  2(?:t iswo rang    [25]\d?|t iswo rang    [348]\d|t iswo rang    [67]\d{1,2 a < drain_end)t iswo rang)|t iswo rang3(?:t iswo rang  1\d{2}(?:t iswo rang    \d{2}a < drain_end)?|t iswo rang  2(?:t iswo rang    [045]\d|t iswo rang    [236-9]\d{1,2 a < drain_end)|t iswo rang  32\d{2}a < drain_e)|t iswo rang4(?:t iswo rang  [18]\d{2}|t iswo rang  2(?:t iswo rang    [2-46]\d{2 |t iswo rang    3a < drain_end)|t iswo rang  5[25]\d{2}a < drain_e)|t iswo rang5(?:t iswo rang  1\d{2}|t iswo rang  2(?:t iswo rang    3\d|t iswo rang    5a < drain_end)t iswo rang)|t iswo rang6(?:t iswo rang  [18]\d{2}|t iswo rang  2(?:t iswo rang    3(?:t iswo rang      \d{2}a < drain_endnd)?|t iswo rang    [46]\d{1,2 |t iswo rang    5\d{2 |t iswo rang    7\da < drain_end)|t iswo rang  5(?:t iswo rang    3\d?|t iswo rang    4\d|t iswo rang    [57]\d{1,2 |t iswo rang    6\d{2 |t iswo rang    8a < drain_end)t iswo rang)|t iswo rang71\d{2}|t iswo rang8(?:t iswo rang  [18]\d{2}|t iswo rang  23\d{2}|t iswo rang  54\d{2}a < drain_e)|t iswo rang9(?:t iswo rang  [18]\d{2}|t iswo rang  2[2-5]\d{2}|t iswo rang  53\d{1,2 a < drain_e)t iswo rag\d{3}|t iswo ra5(?:t iswo rang02[03489]\d{2}|t iswo rang1\d{2}|t iswo rang2(?:t iswo rang  1\d{2}|t iswo rang  2(?:t iswo rang    2(?:t iswo rang      \d{2}a < drain_endnd)?|t iswo rang    [457]\d{2}a < drain_end)t iswo rang)|t iswo rang3(?:t iswo rang  1\d{2}|t iswo rang  2(?:t iswo rang    [37](?:t iswo rang      \d{2}a < drain_endnd)?|t iswo rang    [569]\d{2}a < drain_end)t iswo rang)|t iswo rang4(?:t iswo rang  1\d{2}|t iswo rang  2[46]\d{2 a < drain_e)|t iswo rang5(?:t iswo rang  1\d{2}|t iswo rang  26\d{1,2 a < drain_e)|t iswo rang6(?:t iswo rang  [18]\d{2}|t iswo rang  2|t iswo rang  53\d{2 a < drain_e)|t iswo rang7(?:t iswo rang  1|t iswo rang  24a < drain_e)\d{2}|t iswo rang8(?:t iswo rang  1|t iswo rang  26a < drain_e)\d{2}|t iswo rang91\d{2 a < draing\d{3}|t iswo ra6(?:t iswo rang0(?:t iswo rang  1\d{2}|t iswo rang  2(?:t iswo rang    3\d{2 |t iswo rang    4\d{1,2 a < drain_end)t iswo rang)|t iswo rang2(?:t iswo rang  2[2-5]\d{2}|t iswo rang  5(?:t iswo rang    [3-5]\d{2}|t iswo rang    7a < drain_end)|t iswo rang  8\d{2 a < drain_e)|t iswo rang3(?:t iswo rang  1|t iswo rang  2[3478]a < drain_e)\d{2}|t iswo rang4(?:t iswo rang  1|t iswo rang  2[34]a < drain_e)\d{2}|t iswo rang5(?:t iswo rang  1|t iswo rang  2[47]a < drain_e)\d{2}|t iswo rang6(?:t iswo rang  [18]\d{2}|t iswo rang  6(?:t iswo rang    2(?:t iswo rang      2\d|t iswo rang      [34]\d{2}a < drain_endnd)|t iswo rang    5(?:t iswo rang      [24]\d{2}|t iswo rang      3\d|t iswo rang      5\d{1,2 a < drain_endnd)t iswo rangnd)t iswo rang)|t iswo rang72[2-5]\d{2}|t iswo rang8(?:t iswo rang  1\d{2}|t iswo rang  2[2-5]\d{2}a < drain_e)|t iswo rang9(?:t iswo rang  1\d{2}|t iswo rang  2[2-6]\d{2 a < drain_e)a < draing\d{3}|t iswo ra7(?:t iswo rang(?:t iswo rang  02|t iswo rang  [3-589]1|t iswo rang  6[12]|t iswo rang  72[24]a < drain_e)\d{2}|t iswo rang21\d{3}|t iswo rang32a < draing\d{3}|t iswo ra8(?:t iswo rang(?:t iswo rang  4[12]|t iswo rang  [5-7]2|t iswo rang  1\d?a < drain_e)|t iswo rang(?:t iswo rang  0|t iswo rang  3[12]|t iswo rang  [5-7]1|t iswo rang  217a < drain_e)\dt iswo rag\d{4}|t iswo ra9(?:t iswo rang[35]1|t iswo rang(?:t iswo rang  [024]2|t iswo rang  81a < drain_e)\d|t iswo rang(?:t iswo rang  1|t iswo rang  [24]1a < drain_e)\d{2}a < draing\d{3}a < drain"#es.pus// srt TODO: T    er1a goo scs tid Ie isii,ieq rfr. A sequIaral acif sbe::maxa` rinushrunk qu co a bi;
e d st  bsb  an oeproduusivoewl S.`, ttc1/ se_fola` rinu consertapis
seaIs) s./.pus// s    ( th ssio,)eionssiong   (p`t)Se// s// s("bar"!(! ften latis_ton co(e)es.pus// s("bar"),nd ence(243),"pth ssioi) ->)ges.pus     //#[eesn]   //I>>opis
see(tcit isw e("t. That genst
,commo>> th ss1ng isir     so shor)./.pus// s    ( ,seng t iswo rang  opi(["IoobarIoobar", "foobar", "foobarzfoobar", "foobarfoobar"]ees.pus// s("bar"),nd t(q([I("foobar")]ecapees.pus// s("bar"),nd t(q([I("foobar")]ecasgess.pus// srt That  asostondst
,commo>> th ss abme(Fioegtd 'se(nhato esbyti,eit
plicit e= o` e alshus, multiplbe consero./.pus// s    ( ,seng  opi(["abba", "akka", "abccba"]ees.pus// s("bar"),nd     ln["abba", "akka", "abccba"]e, ( ,sengess.pus// s et,( ,seng  opi(["sam", "s/mopti"]ees.pus// s("bar"),nd (t(q([E("sam")]ecat(q([E("sam")caE("s/mopti")]eg,t( ,sengess.pus// sIs T l, essaerarlyseis poisonou , sosorchieq becom -tinton co,  annl// splic_simpkua]aa/// conseros r.rz   l./.pus// s    ( ,seng  opi(["foobarfoo", "foo", "", "foozfoo", "foofoo"])Se// s// s("bar"!(!ptis_ton co(e)es.pus// s("bar"!(! tis_ton co(e)ess.pus// srt A spacgt r1 asospoisonou , sosorchieq becom -tinton co. Bacemplss.pus// srt (nhatgenstarlggeredow
   we do    eate  o  m     lytlf  leFier"oeg.   assertIs echarmpl,Fier"oegt r1lf  l, spacgos r.rokay,aFioegtwe  Forume tv i
sert  //t. anyc th llons[{  bs nges a spacgtmwisequ ckhatv/aarmpl,thtpalenging.   assertIs (echarmpl,Fier"oegt r1lf  l, mpals'n a ing ci/
t fc(o th llons[