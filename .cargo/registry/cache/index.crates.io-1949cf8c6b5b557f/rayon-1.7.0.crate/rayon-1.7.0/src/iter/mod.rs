//! Traits for writing parallel programs using an iterator-style interface
//!
//! You will rarely need to interact with this module directly unless you have
//! need to name one of the iterator types.
//!
//! Parallel iterators make it easy to write iterator-like chains that
//! execute in parallel: typically all you have to do is convert the
//! first `.iter()` (or `iter_mut()`, `into_iter()`, etc) method into
//! `par_iter()` (or `par_iter_mut()`, `into_par_iter()`, etc). For
//! example, to compute the sum of the squares of a sequence of
//! integers, one might write:
//!
//! ```rust
//! use rayon::prelude::*;
//! fn sum_of_squares(input: &[i32]) -> i32 {
//!     input.par_iter()
//!          .map(|i| i * i)
//!          .sum()
//! }
//! ```
//!
//! Or, to increment all the integers in a slice, you could write:
//!
//! ```rust
//! use rayon::prelude::*;
//! fn increment_all(input: &mut [i32]) {
//!     input.par_iter_mut()
//!          .for_each(|p| *p += 1);
//! }
//! ```
//!
//! To use parallel iterators, first import the traits by adding
//! something like `use rayon::prelude::*` to your module. You can
//! then call `par_iter`, `par_iter_mut`, or `into_par_iter` to get a
//! parallel iterator. Like a [regular iterator][], parallel
//! iterators work by first constructing a computation and then
//! executing it.
//!
//! In addition to `par_iter()` and friends, some types offer other
//! ways to create (or consume) parallel iterators:
//!
//! - Slices (`&[T]`, `&mut [T]`) offer methods like `par_split` and
//!   `par_windows`, as well as various parallel sorting
//!   operations. See [the `ParallelSlice` trait] for the full list.
//! - Strings (`&str`) offer methods like `par_split` and `par_lines`.
//!   See [the `ParallelString` trait] for the full list.
//! - Various collections offer [`par_extend`], which grows a
//!   collection given a parallel iterator. (If you don't have a
//!   collection to extend, you can use [`collect()`] to create a new
//!   one from scratch.)
//!
//! [the `ParallelSlice` trait]: ../slice/trait.ParallelSlice.html
//! [the `ParallelString` trait]: ../str/trait.ParallelString.html
//! [`par_extend`]: trait.ParallelExtend.html
//! [`collect()`]: trait.ParallelIterator.html#method.collect
//!
//! To see the full range of methods available on parallel iterators,
//! check out the [`ParallelIterator`] and [`IndexedParallelIterator`]
//! traits.
//!
//! If you'd like to build a custom parallel iterator, or to write your own
//! combinator, then check out the [split] function and the [plumbing] module.
//!
//! [regular iterator]: https://doc.rust-lang.org/std/iter/trait.Iterator.html
//! [`ParallelIterator`]: trait.ParallelIterator.html
//! [`IndexedParallelIterator`]: trait.IndexedParallelIterator.html
//! [split]: fn.split.html
//! [plumbing]: plumbing/index.html
//!
//! Note: Several of the `ParallelIterator` methods rely on a `Try` trait which
//! has been deliberately obscured from the public API.  This trait is intended
//! to mirror the unstable `std::ops::Try` with implementations for `Option` and
//! `Result`, where `Some`/`Ok` values will let those iterators continue, but
//! `None`/`Err` values will exit early.
//!
//! A note about object safety: It is currently _not_ possible to wrap
//! a `ParallelIterator` (or any trait that depends on it) using a
//! `Box<dyn ParallelIterator>` or other kind of dynamic allocation,
//! because `ParallelIterator` is **not object-safe**.
//! (This keeps the implementation simpler and allows extra optimizations.)

use self::plumbing::*;
use self::private::Try;
pub use either::Either;
use std::cmp::{self, Ordering};
use std::iter::{Product, Sum};
use std::ops::{Fn, RangeBounds};

pub mod plumbing;

#[cfg(test)]
mod test;

// There is a method to the madness here:
//
// - These modules are private but expose certain types to the end-user
//   (e.g., `enumerate::Enumerate`) -- specifically, the types that appear in the
//   public API surface of the `ParallelIterator` traits.
// - In **this** module, those public types are always used unprefixed, which forces
//   us to add a `pub use` and helps identify if we missed anything.
// - In contrast, items that appear **only** in the body of a method,
//   e.g. `find::find()`, are always used **prefixed**, so that they
//   can be readily distinguished.

mod chain;
mod chunks;
mod cloned;
mod collect;
mod copied;
mod empty;
mod enumerate;
mod extend;
mod filter;
mod filter_map;
mod find;
mod find_first_last;
mod flat_map;
mod flat_map_iter;
mod flatten;
mod flatten_iter;
mod fold;
mod fold_chunks;
mod fold_chunks_with;
mod for_each;
mod from_par_iter;
mod inspect;
mod interleave;
mod interleave_shortest;
mod intersperse;
mod len;
mod map;
mod map_with;
mod multizip;
mod noop;
mod once;
mod panic_fuse;
mod par_bridge;
mod positions;
mod product;
mod reduce;
mod repeat;
mod rev;
mod skip;
mod skip_any;
mod skip_any_while;
mod splitter;
mod step_by;
mod sum;
mod take;
mod take_any;
mod take_any_while;
mod try_fold;
mod try_reduce;
mod try_reduce_with;
mod unzip;
mod update;
mod while_some;
mod zip;
mod zip_eq;

pub use self::{
    chain::Chain,
    chunks::Chunks,
    cloned::Cloned,
    copied::Copied,
    empty::{empty, Empty},
    enumerate::Enumerate,
    filter::Filter,
    filter_map::FilterMap,
    flat_map::FlatMap,
    flat_map_iter::FlatMapIter,
    flatten::Flatten,
    flatten_iter::FlattenIter,
    fold::{Fold, FoldWith},
    fold_chunks::FoldChunks,
    fold_chunks_with::FoldChunksWith,
    inspect::Inspect,
    interleave::Interleave,
    interleave_shortest::InterleaveShortest,
    intersperse::Intersperse,
    len::{MaxLen, MinLen},
    map::Map,
    map_with::{MapInit, MapWith},
    multizip::MultiZip,
    once::{once, Once},
    panic_fuse::PanicFuse,
    par_bridge::{IterBridge, ParallelBridge},
    positions::Positions,
    repeat::{repeat, repeatn, Repeat, RepeatN},
    rev::Rev,
    skip::Skip,
    skip_any::SkipAny,
    skip_any_while::SkipAnyWhile,
    splitter::{split, Split},
    step_by::StepBy,
    take::Take,
    take_any::TakeAny,
    take_any_while::TakeAnyWhile,
    try_fold::{TryFold, TryFoldWith},
    update::Update,
    while_some::WhileSome,
    zip::Zip,
    zip_eq::ZipEq,
};

/// `IntoParallelIterator` implements the conversion to a [`ParallelIterator`].
///
/// By implementing `IntoParallelIterator` for a type, you define how it will
/// transformed into an iterator. This is a parallel version of the standard
/// library's [`std::iter::IntoIterator`] trait.
///
/// [`ParallelIterator`]: trait.ParallelIterator.html
/// [`std::iter::IntoIterator`]: https://doc.rust-lang.org/std/iter/trait.IntoIterator.html
pub trait IntoParallelIterator {
    /// The parallel iterator type that will be created.
    type Iter: ParallelIterator<Item = Self::Item>;

    /// The type of item that the parallel iterator will produce.
    type Item: Send;

    /// Converts `self` into a parallel iterator.
    ///
    /// # Examples
    ///
    /// ```
    /// use rayon::prelude::*;
    ///
    /// println!("counting in parallel:");
    /// (0..100).into_par_iter()
    ///     .for_each(|i| println!("{}", i));
    /// ```
    ///
    /// This conversion is often implicit for arguments to methods like [`zip`].
    ///
    /// ```
    /// use rayon::prelude::*;
    ///
    /// let v: Vec<_> = (0..5).into_par_iter().zip(5..10).collect();
    /// assert_eq!(v, [(0, 5), (1, 6), (2, 7), (3, 8), (4, 9)]);
    /// ```
    ///
    /// [`zip`]: trait.IndexedParallelIterator.html#method.zip
    fn into_par_iter(self) -> Self::Iter;
}

/// `IntoParallelRefIterator` implements the conversion to a
/// [`ParallelIterator`], providing shared references to the data.
///
/// This is a parallel version of the `iter()` method
/// defined by various collections.
///
/// This trait is automatically implemented
/// `for I where &I: IntoParallelIterator`. In most cases, users
/// will want to implement [`IntoParallelIterator`] rather than implement
/// this trait directly.
///
/// [`ParallelIterator`]: trait.ParallelIterator.html
/// [`IntoParallelIterator`]: trait.IntoParallelIterator.html
pub trait IntoParallelRefIterator<'data> {
    /// The type of the parallel iterator that will be returned.
    type Iter: ParallelIterator<Item = Self::Item>;

    /// The type of item that the parallel iterator will produce.
    /// This will typically be an `&'data T` reference type.
    type Item: Send + 'data;

    /// Converts `self` into a parallel iterator.
    ///
    /// # Examples
    ///
    /// ```
    /// use rayon::prelude::*;
    ///
    /// let v: Vec<_> = (0..100).collect();
    /// assert_eq!(v.par_iter().sum::<i32>(), 100 * 99 / 2);
    ///
    /// // `v.par_iter()` is shorthand for `(&v).into_par_iter()`,
    /// // producing the exact same references.
    /// assert!(v.par_iter().zip(&v)
    ///          .all(|(a, b)| std::ptr::eq(a, b)));
    /// ```
    fn par_iter(&'data self) -> Self::Iter;
}

impl<'data, I: 'data + ?Sized> IntoParallelRefIterator<'data> for I
where
    &'data I: IntoParallelIterator,
{
    type Iter = <&'data I as IntoParallelIterator>::Iter;
    type Item = <&'data I as IntoParallelIterator>::Item;

    fn par_iter(&'data self) -> Self::Iter {
        self.into_par_iter()
    }
}

/// `IntoParallelRefMutIterator` implements the conversion to a
/// [`ParallelIterator`], providing mutable references to the data.
///
/// This is a parallel version of the `iter_mut()` method
/// defined by various collections.
///
/// This trait is automatically implemented
/// `for I where &mut I: IntoParallelIterator`. In most cases, users
/// will want to implement [`IntoParallelIterator`] rather than implement
/// this trait directly.
///
/// [`ParallelIterator`]: trait.ParallelIterator.html
/// [`IntoParallelIterator`]: trait.IntoParallelIterator.html
pub trait IntoParallelRefMutIterator<'data> {
    /// The type of iterator that will be created.
    type Iter: ParallelIterator<Item = Self::Item>;

    /// The type of item that will be produced; this is typically an
    /// `&'data mut T` reference.
    type Item: Send + 'data;

    /// Creates the parallel iterator from `self`.
    ///
    /// # Examples
    ///
    /// ```
    /// use rayon::prelude::*;
    ///
    /// let mut v = vec![0usize; 5];
    /// v.par_iter_mut().enumerate().for_each(|(i, x)| *x = i);
    /// assert_eq!(v, [0, 1, 2, 3, 4]);
    /// ```
    fn par_iter_mut(&'data mut self) -> Self::Iter;
}

impl<'data, I: 'data + ?Sized> IntoParallelRefMutIterator<'data> for I
where
    &'data mut I: IntoParallelIterator,
{
    type Iter = <&'data mut I as IntoParallelIterator>::Iter;
    type Item = <&'data mut I as IntoParallelIterator>::Item;

    fn par_iter_mut(&'data mut self) -> Self::Iter {
        self.into_par_iter()
    }
}

/// Parallel version of the standard iterator trait.
///
/// The combinators on this trait are available on **all** parallel
/// iterators.  Additional methods can be found on the
/// [`IndexedParallelIterator`] trait: those methods are only
/// available for parallel iterators where the number of items is
/// known in advance (so, e.g., after invoking `filter`, those methods
/// become unavailable).
///
/// For examples of using parallel iterators, see [the docs on the
/// `iter` module][iter].
///
/// [iter]: index.html
/// [`IndexedParallelIterator`]: trait.IndexedParallelIterator.html
pub trait ParallelIterator: Sized + Send {
    /// The type of item that this parallel iterator produces.
    /// For example, if you use the [`for_each`] method, this is the type of
    /// item that your closure will be invoked with.
    ///
    /// [`for_each`]: #method.for_each
    type Item: Send;

    /// Executes `OP` on each item produced by the iterator, in parallel.
    ///
    /// # Examples
    ///
    /// ```
    /// use rayon::prelude::*;
    ///
    /// (0..100).into_par_iter().for_each(|x| println!("{:?}", x));
    /// ```
    fn for_each<OP>(self, op: OP)
    where
        OP: Fn(Self::Item) + Sync + Send,
    {
        for_each::for_each(self, &op)
    }

    /// Executes `OP` on the given `init` value with each item produced by
    /// the iterator, in parallel.
    ///
    /// The `init` value will be cloned only as needed to be paired with
    /// the group of items in each rayon job.  It does not require the type
    /// to be `Sync`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::mpsc::channel;
    /// use rayon::prelude::*;
    ///
    /// let (sender, receiver) = channel();
    ///
    /// (0..5).into_par_iter().for_each_with(sender, |s, x| s.send(x).unwrap());
    ///
    /// let mut res: Vec<_> = receiver.iter().collect();
    ///
    /// res.sort();
    ///
    /// assert_eq!(&res[..], &[0, 1, 2, 3, 4])
    /// ```
    fn for_each_with<OP, T>(self, init: T, op: OP)
    where
        OP: Fn(&mut T, Self::Item) + Sync + Send,
        T: Send + Clone,
    {
        self.map_with(init, op).collect()
    }

    /// Executes `OP` on a value returned by `init` with each item produced by
    /// the iterator, in parallel.
    ///
    /// The `init` function will be called only as needed for a value to be
    /// paired with the group of items in each rayon job.  There is no
    /// constraint on that returned type at all!
    ///
    /// # Examples
    ///
    /// ```
    /// use rand::Rng;
    /// use rayon::prelude::*;
    ///
    /// let mut v = vec![0u8; 1_000_000];
    ///
    /// v.par_chunks_mut(1000)
    ///     .for_each_init(
    ///         || rand::thread_rng(),
    ///         |rng, chunk| rng.fill(chunk),
    ///     );
    ///
    /// // There's a remote chance that this will fail...
    /// for i in 0u8..=255 {
    ///     assert!(v.contains(&i));
    /// }
    /// ```
    fn for_each_init<OP, INIT, T>(self, init: INIT, op: OP)
    where
        OP: Fn(&mut T, Self::Item) + Sync + Send,
        INIT: Fn() -> T + Sync + Send,
    {
        self.map_init(init, op).collect()
    }

    /// Executes a fallible `OP` on each item produced by the iterator, in parallel.
    ///
    /// If the `OP` returns `Result::Err` or `Option::None`, we will attempt to
    /// stop processing the rest of the items in the iterator as soon as
    /// possible, and we will return that terminating value.  Otherwise, we will
    /// return an empty `Result::Ok(())` or `Option::Some(())`.  If there are
    /// multiple errors in parallel, it is not specified which will be returned.
    ///
    /// # Examples
    ///
    /// ```
    /// use rayon::prelude::*;
    /// use std::io::{self, Write};
    ///
    /// // This will stop iteration early if there's any write error, like
    /// // having piped output get closed on the other end.
    /// (0..100).into_par_iter()
    ///     .try_for_each(|x| writeln!(io::stdout(), "{:?}", x))
    ///     .expect("expected no write errors");
    /// ```
    fn try_for_each<OP, R>(self, op: OP) -> R
    where
        OP: Fn(Self::Item) -> R + Sync + Send,
        R: Try<Output = ()> + Send,
    {
        fn ok<R: Try<Output = ()>>(_: (), _: ()) -> R {
            R::from_output(())
        }

        self.map(op).try_reduce(<()>::default, ok)
    }

    /// Executes a fallible `OP` on the given `init` value with each item
    /// produced by the iterator, in parallel.
    ///
    /// This combines the `init` semantics of [`for_each_with()`] and the
    /// failure semantics of [`try_for_each()`].
    ///
    /// [`for_each_with()`]: #method.for_each_with
    /// [`try_for_each()`]: #method.try_for_each
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::mpsc::channel;
    /// use rayon::prelude::*;
    ///
    /// let (sender, receiver) = channel();
    ///
    /// (0..5).into_par_iter()
    ///     .try_for_each_with(sender, |s, x| s.send(x))
    ///     .expect("expected no send errors");
    ///
    /// let mut res: Vec<_> = receiver.iter().collect();
    ///
    /// res.sort();
    ///
    /// assert_eq!(&res[..], &[0, 1, 2, 3, 4])
    /// ```
    fn try_for_each_with<OP, T, R>(self, init: T, op: OP) -> R
    where
        OP: Fn(&mut T, Self::Item) -> R + Sync + Send,
        T: Send + Clone,
        R: Try<Output = ()> + Send,
    {
        fn ok<R: Try<Output = ()>>(_: (), _: ()) -> R {
            R::from_output(())
        }

        self.map_with(init, op).try_reduce(<()>::default, ok)
    }

    /// Executes a fallible `OP` on a value returned by `init` with each item
    /// produced by the iterator, in parallel.
    ///
    /// This combines the `init` semantics of [`for_each_init()`] and the
    /// failure semantics of [`try_for_each()`].
    ///
    /// [`for_each_init()`]: #method.for_each_init
    /// [`try_for_each()`]: #method.try_for_each
    ///
    /// # Examples
    ///
    /// ```
    /// use rand::Rng;
    /// use rayon::prelude::*;
    ///
    /// let mut v = vec![0u8; 1_000_000];
    ///
    /// v.par_chunks_mut(1000)
    ///     .try_for_each_init(
    ///         || rand::thread_rng(),
    ///         |rng, chunk| rng.try_fill(chunk),
    ///     )
    ///     .expect("expected no rand errors");
    ///
    /// // There's a remote chance that this will fail...
    /// for i in 0u8..=255 {
    ///     assert!(v.contains(&i));
    /// }
    /// ```
    fn try_for_each_init<OP, INIT, T, R>(self, init: INIT, op: OP) -> R
    where
        OP: Fn(&mut T, Self::Item) -> R + Sync + Send,
        INIT: Fn() -> T + Sync + Send,
        R: Try<Output = ()> + Send,
    {
        fn ok<R: Try<Output = ()>>(_: (), _: ()) -> R {
            R::from_output(())
        }

        self.map_init(init, op).try_reduce(<()>::default, ok)
    }

    /// Counts the number of items in this parallel iterator.
    ///
    /// # Examples
    ///
    /// ```
    /// use rayon::prelude::*;
    ///
    /// let count = (0..100).into_par_iter().count();
    ///
    /// assert_eq!(count, 100);
    /// ```
    fn count(self) -> usize {
        fn one<T>(_: T) -> usize {
            1
        }

        self.map(one).sum()
    }

    /// Applies `map_op` to each item of this iterator, producing a new
    /// iterator with the results.
    ///
    /// # Examples
    ///
    /// ```
    /// use rayon::prelude::*;
    ///
    /// let mut par_iter = (0..5).into_par_iter().map(|x| x * 2);
    ///
    /// let doubles: Vec<_> = par_iter.collect();
    ///
    /// assert_eq!(&doubles[..], &[0, 2, 4, 6, 8]);
    /// ```
    fn map<F, R>(self, map_op: F) -> Map<Self, F>
    where
        F: Fn(Self::Item) -> R + Sync + Send,
        R: Send,
    {
        Map::new(self, map_op)
    }

    /// Applies `map_op` to the given `init` value with each item of this
    /// iterator, producing a new iterator with the results.
    ///
    /// The `init` value will be cloned only as needed to be paired with
    /// the group of items in each rayon job.  It does not require the type
    /// to be `Sync`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::mpsc::channel;
    /// use rayon::prelude::*;
    ///
    /// let (sender, receiver) = channel();
    ///
    /// let a: Vec<_> = (0..5)
    ///                 .into_par_iter()            // iterating over i32
    ///                 .map_with(sender, |s, x| {
    ///                     s.send(x).unwrap();     // sending i32 values through the channel
    ///                     x                       // returning i32
    ///                 })
    ///                 .collect();                 // collecting the returned values into a vector
    ///
    /// let mut b: Vec<_> = receiver.iter()         // iterating over the values in the channel
    ///                             .collect();     // and collecting them
    /// b.sort();
    ///
    /// assert_eq!(a, b);
    /// ```
    fn map_with<F, T, R>(self, init: T, map_op: F) -> MapWith<Self, T, F>
    where
        F: Fn(&mut T, Self::Item) -> R + Sync + Send,
        T: Send + Clone,
        R: Send,
    {
        MapWith::new(self, init, map_op)
    }

    /// Applies `map_op` to a value returned by `init` with each item of this
    /// iterator, producing a new iterator with the results.
    ///
    /// The `init` function will be called only as needed for a value to be
    /// paired with the group of items in each rayon job.  There is no
    /// constraint on that returned type at all!
    ///
    /// # Examples
    ///
    /// ```
    /// use rand::Rng;
    /// use rayon::prelude::*;
    ///
    /// let a: Vec<_> = (1i32..1_000_000)
    ///     .into_par_iter()
    ///     .map_init(
    ///         || rand::thread_rng(),  // get the thread-local RNG
    ///         |rng, x| if rng.gen() { // randomly negate items
    ///             -x
    ///         } else {
    ///             x
    ///         },
    ///     ).collect();
    ///
    /// // There's a remote chance that this will fail...
    /// assert!(a.iter().any(|&x| x < 0));
    /// assert!(a.iter().any(|&x| x > 0));
    /// ```
    fn map_init<F, INIT, T, R>(self, init: INIT, map_op: F) -> MapInit<Self, INIT, F>
    where
        F: Fn(&mut T, Self::Item) -> R + Sync + Send,
        INIT: Fn() -> T + Sync + Send,
        R: Send,
    {
        MapInit::new(self, init, map_op)
    }

    /// Creates an iterator which clones all of its elements.  This may be
    /// useful when you have an iterator over `&T`, but you need `T`, and
    /// that type implements `Clone`. See also [`copied()`].
    ///
    /// [`copied()`]: #method.copied
    ///
    /// # Examples
    ///
    /// ```
    /// use rayon::prelude::*;
    ///
    /// let a = [1, 2, 3];
    ///
    /// let v_cloned: Vec<_> = a.par_iter().cloned().collect();
    ///
    /// // cloned is the same as .map(|&x| x), for integers
    /// let v_map: Vec<_> = a.par_iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_cloned, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    fn cloned<'a, T>(self) -> Cloned<Self>
    where
        T: 'a + Clone + Send,
        Self: ParallelIterator<Item = &'a T>,
    {
        Cloned::new(self)
    }

    /// Creates an iterator which copies all of its elements.  This may be
    /// useful when you have an iterator over `&T`, but you need `T`, and
    /// that type implements `Copy`. See also [`cloned()`].
    ///
    /// [`cloned()`]: #method.cloned
    ///
    /// # Examples
    ///
    /// ```
    /// use rayon::prelude::*;
    ///
    /// let a = [1, 2, 3];
    ///
    /// let v_copied: Vec<_> = a.par_iter().copied().collect();
    ///
    /// // copied is the same as .map(|&x| x), for integers
    /// let v_map: Vec<_> = a.par_iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_copied, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    fn copied<'a, T>(self) -> Copied<Self>
    where
        T: 'a + Copy + Send,
        Self: ParallelIterator<Item = &'a T>,
    {
        Copied::new(self)
    }

    /// Applies `inspect_op` to a reference to each item of this iterator,
    /// producing a new iterator passing through the original items.  This is
    /// often useful for debugging to see what's happening in iterator stages.
    ///
    /// # Examples
    ///
    /// ```
    /// use rayon::prelude::*;
    ///
    /// let a = [1, 4, 2, 3];
    ///
    /// // this iterator sequence is complex.
    /// let sum = a.par_iter()
    ///             .cloned()
    ///             .filter(|&x| x % 2 == 0)
    ///             .reduce(|| 0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    ///
    /// // let's add some inspect() calls to investigate what's happening
    /// let sum = a.par_iter()
    ///             .cloned()
    ///             .inspect(|x| println!("about to filter: {}", x))
    ///             .filter(|&x| x % 2 == 0)
    ///             .inspect(|x| println!("made it through filter: {}", x))
    ///             .reduce(|| 0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    /// ```
    fn inspect<OP>(self, inspect_op: OP) -> Inspect<Self, OP>
    where
        OP: Fn(&Self::Item) + Sync + Send,
    {
        Inspect::new(self, inspect_op)
    }

    /// Mutates each item of this iterator before yielding it.
    ///
    /// # Examples
    ///
    /// ```
    /// use rayon::prelude::*;
    ///
    /// let par_iter = (0..5).into_par_iter().update(|x| {*x *= 2;});
    ///
    /// let doubles: Vec<_> = par_iter.collect();
    ///
    /// assert_eq!(&doubles[..], &[0, 2, 4, 6, 8]);
    /// ```
    fn update<F>(self, update_op: F) -> Update<Self, F>
    where
        F: Fn(&mut Self::Item) + Sync + Send,
    {
        Update::new(self, update_op)
    }

    /// Applies `filter_op` to each item of this iterator, producing a new
    /// iterator with only the items that gave `true` results.
    ///
    /// # Examples
    ///
    /// ```
    /// use rayon::prelude::*;
    ///
    /// let mut par_iter = (0..10).into_par_iter().filter(|x| x % 2 == 0);
    ///
    /// let even_numbers: Vec<_> = par_iter.collect();
    ///
    /// assert_eq!(&even_numbers[..], &[0, 2, 4, 6, 8]);
    /// ```
    fn filter<P>(self, filter_op: P) -> Filter<Self, P>
    where
        P: Fn(&Self::Item) -> bool + Sync + Send,
    {
        Filter::new(self, filter_op)
    }

    /// Applies `filter_op` to each item of this iterator to get an `Option`,
    /// producing a new iterator with only the items from `Some` results.
    ///
    /// # Examples
    ///
    /// ```
    /// use rayon::prelude::*;
    ///
    /// let mut par_iter = (0..10).into_par_iter()
    ///                         .filter_map(|x| {
    ///                             if x % 2 == 0 { Some(x * 3) }
    ///                             else { None }
    ///                         });
    ///
    /// let even_numbers: Vec<_> = par_iter.collect();
    ///
    /// assert_eq!(&even_numbers[..], &[0, 6, 12, 18, 24]);
    /// ```
    fn filter_map<P, R>(self, filter_op: P) -> FilterMap<Self, P>
    where
        P: Fn(Self::Item) -> Option<R> + Sync + Send,
        R: Send,
    {
        FilterMap::new(self, filter_op)
    }

    /// Applies `map_op` to each item of this iterator to get nested parallel iterators,
    /// producing a new parallel iterator that flattens these back into one.
    ///
    /// See also [`flat_map_iter`](#method.flat_map_iter).
    ///
    /// # Examples
    ///
    /// ```
    /// use rayon::prelude::*;
    ///
    /// let a = [[1, 2], [3, 4], [5, 6], [7, 8]];
    ///
    /// let par_iter = a.par_iter().cloned().flat_map(|a| a.to_vec());
    ///
    /// let vec: Vec<_> = par_iter.collect();
    ///
    /// assert_eq!(&vec[..], &[1, 2, 3, 4, 5, 6, 7, 8]);
    /// ```
    fn flat_map<F, PI>(self, map_op: F) -> FlatMap<Self, F>
    where
        F: Fn(Self::Item) -> PI + Sync + Send,
        PI: IntoParallelIterator,
    {
        FlatMap::new(self, map_op)
    }

    /// Applies `map_op` to each item of this iterator to get nested serial iterators,
    /// producing a new parallel iterator that flattens these back into one.
    ///
    /// # `flat_map_iter` versus `flat_map`
    ///
    /// These two methods are similar but behave slightly differently. With [`flat_map`],
    /// each of the nested iterators must be a parallel iterator, and they will be further
    /// split up with nested parallelism. With `flat_map_iter`, each nested iterator is a
    /// sequential `Iterator`, and we only parallelize _between_ them, while the items
    /// produced by each nested iterator are processed sequentially.
    ///
    /// When choosing between these methods, consider whether nested parallelism suits the
    /// potential iterators at hand. If there's little computation involved, or its length
    /// is much less than the outer parallel iterator, then it may perform better to avoid
    /// the overhead of parallelism, just flattening sequentially with `flat_map_iter`.
    /// If there is a lot of computation, potentially outweighing the outer parallel
    /// iterator, then the nested parallelism of `flat_map` may be worthwhile.
    ///
    /// [`flat_map`]: #method.flat_map
    ///
    /// # Examples
    ///
    /// ```
    /// use rayon::prelude::*;
    /// use std::cell::RefCell;
    ///
    /// let a = [[1, 2], [3, 4], [5, 6], [7, 8]];
    ///
    /// let par_iter = a.par_iter().flat_map_iter(|a| {
    ///     // The serial iterator doesn't have to be thread-safe, just its items.
    ///     let cell_iter = RefCell::new(a.iter().cloned());
    ///     std::iter::from_fn(move || cell_iter.borrow_mut().next())
    /// });
    ///
    /// let vec: Vec<_> = par_iter.collect();
    ///
    /// assert_eq!(&vec[..], &[1, 2, 3, 4, 5, 6, 7, 8]);
    /// ```
    fn flat_map_iter<F, SI>(self, map_op: F) -> FlatMapIter<Self, F>
    where
        F: Fn(Self::Item) -> SI + Sync + Send,
        SI: IntoIterator,
        SI::Item: Send,
    {
        FlatMapIter::new(self, map_op)
    }

    /// An adaptor that flattens parallel-iterable `Item`s into one large iterator.
    ///
    /// See also [`flatten_iter`](#method.flatten_iter).
    ///
    /// # Examples
    ///
    /// ```
    /// use rayon::prelude::*;
    ///
    /// let x: Vec<Vec<_>> = vec![vec![1, 2], vec![3, 4]];
    /// let y: Vec<_> = x.into_par_iter().flatten().collect();
    ///
    /// assert_eq!(y, vec![1, 2, 3, 4]);
    /// ```
    fn flatten(self) -> Flatten<Self>
    where
        Self::Item: IntoParallelIterator,
    {
        Flatten::new(self)
    }

    /// An adaptor that flattens serial-iterable `Item`s into one large iterator.
    ///
    /// See also [`flatten`](#method.flatten) and the analogous comparison of
    /// [`flat_map_iter` versus `flat_map`](#flat_map_iter-versus-flat_map).
    ///
    /// # Examples
    ///
    /// ```
    /// use rayon::prelude::*;
    ///
    /// let x: Vec<Vec<_>> = vec![vec![1, 2], vec![3, 4]];
    /// let iters: Vec<_> = x.into_iter().map(Vec::into_iter).collect();
    /// let y: Vec<_> = iters.into_par_iter().flatten_iter().collect();
    ///
    /// assert_eq!(y, vec![1, 2, 3, 4]);
    /// ```
    fn flatten_iter(self) -> FlattenIter<Self>
    where
        Self::Item: IntoIterator,
        <Self::Item as IntoIterator>::Item: Send,
    {
        FlattenIter::new(self)
    }

    /// Reduces the items in the iterator into one item using `op`.
    /// The argument `identity` should be a closure that can produce
    /// "identity" value which may be inserted into the sequence as
    /// needed to create opportunities for parallel execution. So, for
    /// example, if you are doing a summation, then `identity()` ought
    /// to produce something that represents the zero for your type
    /// (but consider just calling `sum()` in that case).
    ///
    /// # Examples
    ///
    /// ```
    /// // Iterate over a sequence of pairs `(x0, y0), ..., (xN, yN)`
    /// // and use reduce to compute one pair `(x0 + ... + xN, y0 + ... + yN)`
    /// // where the first/second elements are summed separately.
    /// use rayon::prelude::*;
    /// let sums = [(0, 1), (5, 6), (16, 2), (8, 9)]
    ///            .par_iter()        // iterating over &(i32, i32)
    ///            .cloned()          // iterating over (i32, i32)
    ///            .reduce(|| (0, 0), // the "identity" is 0 in both columns
    ///                    |a, b| (a.0 + b.0, a.1 + b.1));
    /// assert_eq!(sums, (0 + 5 + 16 + 8, 1 + 6 + 2 + 9));
    /// ```
    ///
    /// **Note:** unlike a sequential `fold` operation, the order in
    /// which `op` will be applied to reduce the result is not fully
    /// specified. So `op` should be [associative] or else the results
    /// will be non-deterministic. And of course `identity()` should
    /// produce a true identity.
    ///
    /// [associative]: https://en.wikipedia.org/wiki/Associative_property
    fn reduce<OP, ID>(self, identity: ID, op: OP) -> Self::Item
    where
        OP: Fn(Self::Item, Self::Item) -> Self::Item + Sync + Send,
        ID: Fn() -> Self::Item + Sync + Send,
    {
        reduce::reduce(self, identity, op)
    }

    /// Reduces the items in the iterator into one item using `op`.
    /// If the iterator is empty, `None` is returned; otherwise,
    /// `Some` is returned.
    ///
    /// This version of `reduce` is simple but somewhat less
    /// efficient. If possible, it is better to call `reduce()`, which
    /// requires an identity element.
    ///
    /// # Examples
    ///
    /// ```
    /// use rayon::prelude::*;
    /// let sums = [(0, 1), (5, 6), (16, 2), (8, 9)]
    ///            .par_iter()        // iterating over &(i32, i32)
    ///            .cloned()          // iterating over (i32, i32)
    ///            .reduce_with(|a, b| (a.0 + b.0, a.1 + b.1))
    ///            .unwrap();
    /// assert_eq!(sums, (0 + 5 + 16 + 8, 1 + 6 + 2 + 9));
    /// ```
    ///
    /// **Note:** unlike a sequential `fold` operation, the order in
    /// which `op` will be applied to reduce the result is not fully
    /// specified. So `op` should be [associative] or else the results
    /// will be non-deterministic.
    ///
    /// [associative]: https://en.wikipedia.org/wiki/Associative_property
    fn reduce_with<OP>(self, op: OP) -> Option<Self::Item>
    where
        OP: Fn(Self::Item, Self::Item) -> Self::Item + Sync + Send,
    {
        fn opt_fold<T>(op: impl Fn(T, T) -> T) -> impl Fn(Option<T>, T) -> Option<T> {
            move |opt_a, b| match opt_a {
                Some(a) => Some(op(a, b)),
                None => Some(b),
            }
        }

        fn opt_reduce<T>(op: impl Fn(T, T) -> T) -> impl Fn(Option<T>, Option<T>) -> Option<T> {
            move |opt_a, opt_b| match (opt_a, opt_b) {
                (Some(a), Some(b)) => Some(op(a, b)),
                (Some(v), None) | (None, Some(v)) => Some(v),
                (None, None) => None,
            }
        }

        self.fold(<_>::default, opt_fold(&op))
            .reduce(<_>::default, opt_reduce(&op))
    }

    /// Reduces the items in the iterator into one item using a fallible `op`.
    /// The `identity` argument is used the same way as in [`reduce()`].
    ///
    /// [`reduce()`]: #method.reduce
    ///
    /// If a `Result::Err` or `Option::None` item is found, or if `op` reduces
    /// to one, we will attempt to stop processing the rest of the items in the
    /// iterator as soon as possible, and we will return that terminating value.
    /// Otherwise, we will return the final reduced `Result::Ok(T)` or
    /// `Option::Some(T)`.  If there are multiple errors in parallel, it is not
    /// specified which will be returned.
    ///
    /// # Examples
    ///
    /// ```
    /// use rayon::prelude::*;
    ///
    /// // Compute the sum of squares, being careful about overflow.
    /// fn sum_squares<I: IntoParallelIterator<Item = i32>>(iter: I) -> Option<i32> {
    ///     iter.into_par_iter()
    ///         .map(|i| i.checked_mul(i))            // square each item,
    ///         .try_reduce(|| 0, i32::checked_add)   // and add them up!
    /// }
    /// assert_eq!(sum_squares(0..5), Some(0 + 1 + 4 + 9 + 16));
    ///
    /// // The sum might overflow
    /// assert_eq!(sum_squares(0..10_000), None);
    ///
    /// // Or the squares might overflow before it even reaches `try_reduce`
    /// assert_eq!(sum_squares(1_000_000..1_000_001), None);
    /// ```
    fn try_reduce<T, OP, ID>(self, identity: ID, op: OP) -> Self::Item
    where
        OP: Fn(T, T) -> Self::Item + Sync + Send,
        ID: Fn() -> T + Sync + Send,
        Self::Item: Try<Output = T>,
    {
        try_reduce::try_reduce(self, identity, op)
    }

    /// Reduces the items in the iterator into one item using a fallible `op`.
    ///
    /// Like [`reduce_with()`], if the iterator is empty, `None` is returned;
    /// otherwise, `Some` is returned.  Beyond that, it behaves like
    /// [`try_reduce()`] for handling `Err`/`None`.
    ///
    /// [`reduce_with()`]: #method.reduce_with
    /// [`try_reduce()`]: #method.try_reduce
    ///
    /// For instance, with `Option` items, the return value may be:
    /// - `None`, the iterator was empty
    /// - `Some(None)`, we stopped after encountering `None`.
    /// - `Some(Some(x))`, the entire iterator reduced to `x`.
    ///
    /// With `Result` items, the nesting is more obvious:
    /// - `None`, the iterator was empty
    /// - `Some(Err(e))`, we stopped after encountering an error `e`.
    /// - `Some(Ok(x))`, the entire iterator reduced to `x`.
    ///
    /// # Examples
    ///
    /// ```
    /// use rayon::prelude::*;
    ///
    /// let files = ["/dev/null", "/does/not/exist"];
    ///
    /// // Find the biggest file
    /// files.into_par_iter()
    ///     .map(|path| std::fs::metadata(path).map(|m| (path, m.len())))
    ///     .try_reduce_with(|a, b| {
    ///         Ok(if a.1 >= b.1 { a } else { b })
    ///     })
    ///     .expect("Some value, since the iterator is not empty")
    ///     .expect_err("not found");
    /// ```
    fn try_reduce_with<T, OP>(self, op: OP) -> Option<Self::Item>
    where
        OP: Fn(T, T) -> Self::Item + Sync + Send,
        Self::Item: Try<Output = T>,
    {
        try_reduce_with::try_reduce_with(self, op)
    }

    /// Parallel fold is similar to sequential fold except that the
    /// sequence of items may be subdivided before it is
    /// folded. Consider a list of numbers like `22 3 77 89 46`. If
    /// you used sequential fold to add them (`fold(0, |a,b| a+b)`,
    /// you would wind up first adding 0 + 22, then 22 + 3, then 25 +
    /// 77, and so forth. The **parallel fold** works similarly except
    /// that it first breaks up your list into sublists, and hence
    /// instead of yielding up a single sum at the end, it yields up
    /// multiple sums. The number of results is nondeterministic, as
    /// is the point where the breaks occur.
    ///
    /// So if we did the same parallel fold (`fold(0, |a,b| a+b)`) on
    /// our example list, we might wind up with a sequence of two numbers,
    /// like so:
    ///
    /// ```notrust
    /// 22 3 77 89 46
    ///       |     |
    ///     102   135
    /// ```
    ///
    /// Or perhaps these three numbers:
    ///
    /// ```notrust
    /// 22 3 77 89 46
    ///       |  |  |
    ///     102 89 46
    /// ```
    ///
    /// In general, Rayon will attempt to find good breaking points
    /// that keep all of your cores busy.
    ///
    /// ### Fold versus reduce
    ///
    /// The `fold()` and `reduce()` methods each take an identity element
    /// and a combining function, but they operate rather differently.
    ///
    /// `reduce()` requires that the identity function has the same
    /// type as the things you are iterating over, and it fully
    /// reduces the list of items into a single item. So, for example,
    /// imagine we are iterating over a list of bytes `bytes: [128_u8,
    /// 64_u8, 64_u8]`. If we used `bytes.reduce(|| 0_u8, |a: u8, b:
    /// u8| a + b)`, we would get an overflow. This is because `0`,
    /// `a`, and `b` here are all bytes, just like the numbers in the
    /// list (I wrote the types explicitly above, but those are the
    /// only types you can use). To avoid the overflow, we would need
    /// to do something like `bytes.map(|b| b as u32).reduce(|| 0, |a,
    /// b| a + b)`, in which case our result would be `256`.
    ///
    /// In contrast, with `fold()`, the identity function does not
    /// have to have the same type as the things you are iterating
    /// over, and you potentially get back many results. So, if we
    /// continue with the `bytes` example from the previous paragraph,
    /// we could do `bytes.fold(|| 0_u32, |a, b| a + (b as u32))` to
    /// convert our bytes into `u32`. And of course we might not get
    /// back a single sum.
    ///
    /// There is a more subtle distinction as well, though it's
    /// actually implied by the above points. When you use `reduce()`,
    /// your reduction function is sometimes called with values that
    /// were never part of your original parallel iterator (for
    /// example, both the left and right might be a partial sum). With
    /// `fold()`, in contrast, the left value in the fold function is
    /// always the accumulator, and the right value is always from
    /// your original sequence.
    ///
    /// ### Fold vs Map/Reduce
    ///
    /// Fold makes sense if you have some operation where it is
    /// cheaper to create groups of elements at a time. For example,
    /// imagine collecting characters into a string. If you were going
    /// to use map/reduce, you might try this:
    ///
    /// ```
    /// use rayon::prelude::*;
    ///
    /// let s =
    ///     ['a', 'b', 'c', 'd', 'e']
    ///     .par_iter()
    ///     .map(|c: &char| format!("{}", c))
    ///     .reduce(|| String::new(),
    ///             |mut a: String, b: String| { a.push_str(&b); a });
    ///
    /// assert_eq!(s, "abcde");
    /// ```
    ///
    /// Because reduce produces the same type of element as its input,
    /// you have to first map each character into a string, and then
    /// you can reduce them. This means we create one string per
    /// element in our iterator -- not so great. Using `fold`, we can
    /// do this instead:
    ///
    /// ```
    /// use rayon::prelude::*;
    ///
    /// let s =
    ///     ['a', 'b', 'c', 'd', 'e']
    ///     .par_iter()
    ///     .fold(|| String::new(),
    ///             |mut s: String, c: &char| { s.push(*c); s })
    ///     .reduce(|| String::new(),
    ///             |mut a: String, b: String| { a.push_str(&b); a });
    ///
    /// assert_eq!(s, "abcde");
    /// ```
    ///
    /// Now `fold` will process groups of our characters at a time,
    /// and we only make one string per group. We should wind up with
    /// some small-ish number of strings roughly proportional to the
    /// number of CPUs you have (it will ultimately depend on how busy
    /// your processors are). Note that we still need to do a reduce
    /// afterwards to combine those groups of strings into a single
    /// string.
    ///
    /// You could use a similar trick to save partial results (e.g., a
    /// cache) or something similar.
    ///
    /// ### Combining fold with other operations
    ///
    /// You can combine `fold` with `reduce` if you want to produce a
    /// single value. This is then roughly equivalent to a map/reduce
    /// combination in effect:
    ///
    /// ```
    /// use rayon::prelude::*;
    ///
    /// let bytes = 0..22_u8;
    /// let sum = bytes.into_par_iter()
    ///                .fold(|| 0_u32, |a: u32, b: u8| a + (b as u32))
    ///                .sum::<u32>();
    ///
    /// assert_eq!(sum, (0..22).sum()); // compare to sequential
    /// ```
    fn fold<T, ID, F>(self, identity: ID, fold_op: F) -> Fold<Self, ID, F>
    where
        F: Fn(T, Self::Item) -> T + Sync + Send,
        ID: Fn() -> T + Sync + Send,
        T: Send,
    {
        Fold::new(self, identity, fold_op)
    }

    /// Applies `fold_op` to the given `init` value with each item of this
    /// iterator, finally producing the value for further use.
    ///
    /// This works essentially like `fold(|| init.clone(), fold_op)`, except
    /// it doesn't require the `init` type to be `Sync`, nor any other form
    /// of added synchronization.
    ///
    /// # Examples
    ///
    /// ```
    /// use rayon::prelude::*;
    ///
    /// let bytes = 0..22_u8;
    /// let sum = bytes.into_par_iter()
    ///                .fold_with(0_u32, |a: u32, b: u8| a + (b as u32))
    ///                .sum::<u32>();
    ///
    /// assert_eq!(sum, (0..22).sum()); // compare to sequential
    /// ```
    fn fold_with<F, T>(self, init: T, fold_op: F) -> FoldWith<Self, T, F>
    where
        F: Fn(T, Self::Item) -> T + Sync + Send,
        T: Send + Clone,
    {
        FoldWith::new(self, init, fold_op)
    }

    /// Performs a fallible parallel fold.
    ///
    /// This is a variation of [`fold()`] for operations which can fail with
    /// `Option::None` or `Result::Err`.  The first such failure stops
    /// processing the local set of items, without affecting other folds in the
    /// iterator's subdivisions.
    ///
    /// Often, `try_fold()` will be followed by [`try_reduce()`]
    /// for a final reduction and global short-circuiting effect.
    ///
    /// [`fold()`]: #method.fold
    /// [`try_reduce()`]: #method.try_reduce
    ///
    /// # Examples
    ///
    /// ```
    /// use rayon::prelude::*;
    ///
    /// let bytes = 0..22_u8;
    /// let sum = bytes.into_par_iter()
    ///                .try_fold(|| 0_u32, |a: u32, b: u8| a.checked_add(b as u32))
    ///                .try_reduce(|| 0, u32::checked_add);
    ///
    /// assert_eq!(sum, Some((0..22).sum())); // compare to sequential
    /// ```
    fn try_fold<T, R, ID, F>(self, identity: ID, fold_op: F) -> TryFold<Self, R, ID, F>
    where
        F: Fn(T, Self::Item) -> R + Sync + Send,
        ID: Fn() -> T + Sync + Send,
        R: Try<Output = T> + Send,
    {
        TryFold::new(self, identity, fold_op)
    }

    /// Performs a fallible parallel fold with a cloneable `init` value.
    ///
    /// This combines the `init` semantics of [`fold_with()`] and the failure
    /// semantics of [`try_fold()`].
    ///
    /// [`fold_with()`]: #method.fold_with
    /// [`try_fold()`]: #method.try_fold
    ///
    /// ```
    /// use rayon::prelude::*;
    ///
    /// let bytes = 0..22_u8;
    /// let sum = bytes.into_par_iter()
    ///                .try_fold_with(0_u32, |a: u32, b: u8| a.checked_add(b as u32))
    ///                .try_reduce(|| 0, u32::checked_add);
    ///
    /// assert_eq!(sum, Some((0..22).sum())); // compare to sequential
    /// ```
    fn try_fold_with<F, T, R>(self, init: T, fold_op: F) -> TryFoldWith<Self, R, F>
    where
        F: Fn(T, Self::Item) -> R + Sync + Send,
        R: Try<Output = T> + Send,
        T: Clone + Send,
    {
        TryFoldWith::new(self, init, fold_op)
    }

    /// Sums up the items in the iterator.
    ///
    /// Note that the order in items will be reduced is not specified,
    /// so if the `+` operator is not truly [associative] \(as is the
    /// case for floating point numbers), then the results are not
    /// fully deterministic.
    ///
    /// [associative]: https://en.wikipedia.org/wiki/Associative_property
    ///
    /// Basically equivalent to `self.reduce(|| 0, |a, b| a + b)`,
    /// except that the type of `0` and the `+` operation may vary
    /// depending on the type of value being produced.
    ///
    /// # Examples
    ///
    /// ```
    /// use rayon::prelude::*;
    ///
    /// let a = [1, 5, 7];
    ///
    /// let sum: i32 = a.par_iter().sum();
    ///
    /// assert_eq!(sum, 13);
    /// ```
    fn sum<S>(self) -> S
    where
        S: Send + Sum<Self::Item> + Sum<S>,
    {
        sum::sum(self)
    }

    /// Multiplies all the items in the iterator.
    ///
    /// Note that the order in items will be reduced is not specified,
    /// so if the `*` operator is not truly [associative] \(as is the
    /// case for floating point numbers), then the results are not
    /// fully deterministic.
    ///
    /// [associative]: https://en.wikipedia.org/wiki/Associative_property
    ///
    /// Basically equivalent to `self.reduce(|| 1, |a, b| a * b)`,
    /// except that the type of `1` and the `*` operation may vary
    /// depending on the type of value being produced.
    ///
    /// # Examples
    ///
    /// ```
    /// use rayon::prelude::*;
    ///
    /// fn factorial(n: u32) -> u32 {
    ///    (1..n+1).into_par_iter().product()
    /// }
    ///
    /// assert_eq!(factorial(0), 1);
    /// assert_eq!(factorial(1), 1);
    /// assert_eq!(factorial(5), 120);
    /// ```
    fn product<P>(self) -> P
    where
        P: Send + Product<Self::Item> + Product<P>,
    {
        product::product(self)
    }

    /// Computes the minimum of all the items in the iterator. If the
    /// iterator is empty, `None` is returned; otherwise, `Some(min)`
    /// is returned.
    ///
    /// Note that the order in which the items will be reduced is not
    /// specified, so if the `Ord` impl is not truly associative, then
    /// the results are not deterministic.
    ///
    /// Basically equivalent to `self.reduce_with(|a, b| cmp::min(a, b))`.
    ///
    /// # Examples
    ///
    /// ```
    /// use rayon::prelude::*;
    ///
    /// let a = [45, 74, 32];
    ///
    /// assert_eq!(a.par_iter().min(), Some(&32));
    ///
    /// let b: [i32; 0] = [];
    ///
    /// assert_eq!(b.par_iter().min(), None);
    /// ```
    fn min(self) -> Option<Self::Item>
    where
        Self::Item: Ord,
    {
        self.reduce_with(cmp::min)
    }

    /// Computes the minimum of all the items in the iterator with respect to
    /// the given comparison function. If the iterator is empty, `None` is
    /// returned; otherwise, `Some(min)` is returned.
    ///
    /// Note that the order in which the items will be reduced is not
    /// specified, so if the comparison function is not associative, then
    /// the results are not deterministic.
    ///
    /// # Examples
    ///
    /// ```
    /// use rayon::prelude::*;
    ///
    /// let a = [-3_i32, 77, 53, 240, -1];
    ///
    /// assert_eq!(a.par_iter().min_by(|x, y| x.cmp(y)), Some(&-3));
    /// ```
    fn min_by<F>(self, f: F) -> Option<Self::Item>
    where
        F: Sync + Send + Fn(&Self::Item, &Self::Item) -> Ordering,
    {
        fn min<T>(f: impl Fn(&T, &T) -> Ordering) -> impl Fn(T, T) -> T {
            move |a, b| match f(&a, &b) {
                Ordering::Greater => b,
                _ => a,
            }
        }

        self.reduce_with(min(f))
    }

    /// Computes the item that yields the minimum value for the given
    /// function. If the iterator is empty, `None` is returned;
    /// otherwise, `Some(item)` is returned.
    ///
    /// Note that the order in which the items will be reduced is not
    /// specified, so if the `Ord` impl is not truly associative, then
    /// the results are not deterministic.
    ///
    /// # Examples
    ///
    /// ```
    /// use rayon::prelude::*;
    ///
    /// let a = [-3_i32, 34, 2, 5, -10, -3, -23];
    ///
    /// assert_eq!(a.par_iter().min_by_key(|x| x.abs()), Some(&2));
    /// ```
    fn min_by_key<K, F>(self, f: F) -> Option<Self::Item>
    where
        K: Ord + Send,
        F: Sync + Send + Fn(&Self::Item) -> K,
    {
        fn key<T, K>(f: impl Fn(&T) -> K) -> impl Fn(T) -> (K, T) {
            move |x| (f(&x), x)
        }

        fn min_key<T, K: Ord>(a: (K, T), b: (K, T)) -> (K, T) {
            match (a.0).cmp(&b.0) {
                Ordering::Greater => b,
                _ => a,
            }
        }

        let (_, x) = self.map(key(f)).reduce_with(min_key)?;
        Some(x)
    }

    /// Computes the maximum of all the items in the iterator. If the
    /// iterator is empty, `None` is returned; otherwise, `Some(max)`
    /// is returned.
    ///
    /// Note that the order in which the items will be reduced is not
    /// specified, so if the `Ord` impl is not truly associative, then
    /// the results are not deterministic.
    ///
    /// Basically equivalent to `self.reduce_with(|a, b| cmp::max(a, b))`.
    ///
    /// # Examples
    ///
    /// ```
    /// use rayon::prelude::*;
    ///
    /// let a = [45, 74, 32];
    ///
    /// assert_eq!(a.par_iter().max(), Some(&74));
    ///
    /// let b: [i32; 0] = [];
    ///
    /// assert_eq!(b.par_iter().max(), None);
    /// ```
    fn max(self) -> Option<Self::Item>
    where
        Self::Item: Ord,
    {
        self.reduce_with(cmp::max)
    }

    /// Computes the maximum of all the items in the iterator with respect to
    /// the given comparison function. If the iterator is empty, `None` is
    /// returned; otherwise, `Some(min)` is returned.
    ///
    /// Note that the order in which the items will be reduced is not
    /// specified, so if the comparison function is not associative, then
    /// the results are not deterministic.
    ///
    /// # Examples
    ///
    /// ```
    /// use rayon::prelude::*;
    ///
    /// let a = [-3_i32, 77, 53, 240, -1];
    ///
    /// assert_eq!(a.par_iter().max_by(|x, y| x.abs().cmp(&y.abs())), Some(&240));
    /// ```
    fn max_by<F>(self, f: F) -> Option<Self::Item>
    where
        F: Sync + Send + Fn(&Self::Item, &Self::Item) -> Ordering,
    {
        fn max<T>(f: impl Fn(&T, &T) -> Ordering) -> impl Fn(T, T) -> T {
            move |a, b| match f(&a, &b) {
                Ordering::Greater => a,
                _ => b,
            }
        }

        self.reduce_with(max(f))
    }

    /// Computes the item that yields the maximum value for the given
    /// function. If the iterator is empty, `None` is returned;
    /// otherwise, `Some(item)` is returned.
    ///
    /// Note that the order in which the items will be reduced is not
    /// specified, so if the `Ord` impl is not truly associative, then
    /// the results are not deterministic.
    ///
    /// # Examples
    ///
    /// ```
    /// use rayon::prelude::*;
    ///
    /// let a = [-3_i32, 34, 2, 5, -10, -3, -23];
    ///
    /// assert_eq!(a.par_iter().max_by_key(|x| x.abs()), Some(&34));
    /// ```
    fn max_by_key<K, F>(self, f: F) -> Option<Self::Item>
    where
        K: Ord + Send,
        F: Sync + Send + Fn(&Self::Item) -> K,
    {
        fn key<T, K>(f: impl Fn(&T) -> K) -> impl Fn(T) -> (K, T) {
            move |x| (f(&x), x)
        }

        fn max_key<T, K: Ord>(a: (K, T), b: (K, T)) -> (K, T) {
            match (a.0).cmp(&b.0) {
                Ordering::Greater => a,
                _ => b,
            }
        }

        let (_, x) = self.map(key(f)).reduce_with(max_key)?;
        Some(x)
    }

    /// Takes two iterators and creates a new iterator over both.
    ///
    /// # Examples
    ///
    /// ```
    /// use rayon::prelude::*;
    ///
    /// let a = [0, 1, 2];
    /// let b = [9, 8, 7];
    ///
    /// let par_iter = a.par_iter().chain(b.par_iter());
    ///
    /// let chained: Vec<_> = par_iter.cloned().collect();
    ///
    /// assert_eq!(&chained[..], &[0, 1, 2, 9, 8, 7]);
    /// ```
    fn chain<C>(self, chain: C) -> Chain<Self, C::Iter>
    where
        C: IntoParallelIterator<Item = Self::Item>,
    {
        Chain::new(self, chain.into_par_iter())
    }

    /// Searches for **some** item in the parallel iterator that
    /// matches the given predicate and returns it. This operation
    /// is similar to [`find` on sequential iterators][find] but
    /// the item returned may not be the **first** one in the parallel
    /// sequence which matches, since we search the entire sequence in parallel.
    ///
    /// Once a match is found, we will attempt to stop processing
    /// the rest of the items in the iterator as soon as possible
    /// (just as `find` stops iterating once a match is found).
    ///
    /// [find]: https://doc.rust-lang.org/std/iter/trait.Iterator.html#method.find
    ///
    /// # Examples
    ///
    /// ```
    /// use rayon::prelude::*;
    ///
    /// let a = [1, 2, 3, 3];
    ///
    /// assert_eq!(a.par_iter().find_any(|&&x| x == 3), Some(&3));
    ///
    /// assert_eq!(a.par_iter().find_any(|&&x| x == 100), None);
    /// ```
    fn find_any<P>(self, predicate: P) -> Option<Self::Item>
    where
        P: Fn(&Self::Item) -> bool + Sync + Send,
    {
        find::find(self, predicate)
    }

    /// Searches for the sequentially **first** item in the parallel iterator
    /// that matches the given predicate and returns it.
    ///
    /// Once a match is found, all attempts to the right of the match
    /// will be stopped, while attempts to the left must continue in case
    /// an earlier match is found.
    ///
    /// Note that not all parallel iterators have a useful order, much like
    /// sequential `HashMap` iteration, so "first" may be nebulous.  If you
    /// just want the first match that discovered anywhere in the iterator,
    /// `find_any` is a better choice.
    ///
    /// # Examples
    ///
    /// ```
    /// use rayon::prelude::*;
    ///
    /// let a = [1, 2, 3, 3];
    ///
    /// assert_eq!(a.par_iter().find_first(|&&x| x == 3), Some(&3));
    ///
    /// assert_eq!(a.par_iter().find_first(|&&x| x == 100), None);
    /// ```
    fn find_first<P>(self, predicate: P) -> Option<Self::Item>
    where
        P: Fn(&Self::Item) -> bool + Sync + Send,
    {
        find_first_last::find_first(self, predicate)
    }

    /// Searches for the sequentially **last** item in the parallel iterator
    /// that matches the given predicate and returns it.
    ///
    /// Once a match is found, all attempts to the left of the match
    /// will be stopped, while attempts to the right must continue in case
    /// a later match is found.
    ///
    /// Note that not all parallel iterators have a useful order, much like
    /// sequential `HashMap` iteration, so "last" may be nebulous.  When the
    /// order doesn't actually matter to you, `find_any` is a better choice.
    ///
    /// # Examples
    ///
    /// ```
    /// use rayon::prelude::*;
    ///
    /// let a = [1, 2, 3, 3];
    ///
    /// assert_eq!(a.par_iter().find_last(|&&x| x == 3), Some(&3));
    ///
    /// assert_eq!(a.par_iter().find_last(|&&x| x == 100), None);
    /// ```
    fn find_last<P>(self, predicate: P) -> Option<Self::Item>
    where
        P: Fn(&Self::Item) -> bool + Sync + Send,
    {
        find_first_last::find_last(self, predicate)
    }

    /// Applies the given predicate to the items in the parallel iterator
    /// and returns **any** non-None result of the map operation.
    ///
    /// Once a non-None value is produced from the map operation, we will
    /// attempt to stop processing the rest of the items in the iterator
    /// as soon as possible.
    ///
    /// Note that this method only returns **some** item in the parallel
    /// iterator that is not None from the map predicate. The item returned
    /// may not be the **first** non-None value produced in the parallel
    /// sequence, since the entire sequence is mapped over in parallel.
    ///
    /// # Examples
    ///
    /// ```
    /// use rayon::prelude::*;
    ///
    /// let c = ["lol", "NaN", "5", "5"];
    ///
    /// let found_number = c.par_iter().find_map_any(|s| s.parse().ok());
    ///
    /// assert_eq!(found_number, Some(5));
    /// ```
    fn find_map_any<P, R>(self, predicate: P) -> Option<R>
    where
        P: Fn(Self::Item) -> Option<R> + Sync + Send,
        R: Send,
    {
        fn yes<T>(_: &T) -> bool {
            true
        }
        self.filter_map(predicate).find_any(yes)
    }

    /// Applies the given predicate to the items in the parallel iterator and
    /// returns the sequentially **first** non-None result of the map operation.
    ///
    /// Once a non-None value is produced from the map operation, all attempts
    /// to the right of the match will be stopped, while attempts to the left
    /// must continue in case an earlier match is found.
    ///
    /// Note that not all parallel iterators have a useful order, much like
    /// sequential `HashMap` iteration, so "first" may be nebulous. If you
    /// just want the first non-None value discovered anywhere in the iterator,
    /// `find_map_any` is a better choice.
    ///
    /// # Examples
    ///
    /// ```
    /// use rayon::prelude::*;
    ///
    /// let c = ["lol", "NaN", "2", "5"];
    ///
    /// let first_number = c.par_iter().find_map_first(|s| s.parse().ok());
    ///
    /// assert_eq!(first_number, Some(2));
    /// ```
    fn find_map_first<P, R>(self, predicate: P) -> Option<R>
    where
        P: Fn(Self::Item) -> Option<R> + Sync + Send,
        R: Send,
    {
        fn yes<T>(_: &T) -> bool {
            true
        }
        self.filter_map(predicate).find_first(yes)
    }

    /// Applies the given predicate to the items in the parallel iterator and
    /// returns the sequentially **last** non-None result of the map operation.
    ///
    /// Once a non-None value is produced from the map operation, all attempts
    /// to the left of the match will be stopped, while attempts to the right
    /// must continue in case a later match is found.
    ///
    /// Note that not all parallel iterators have a useful order, much like
    /// sequential `HashMap` iteration, so "first" may be nebulous. If you
    /// just want the first non-None value discovered anywhere in the iterator,
    /// `find_map_any` is a better choice.
    ///
    /// # Examples
    ///
    /// ```
    /// use rayon::prelude::*;
    ///
    /// let c = ["lol", "NaN", "2", "5"];
    ///
    /// let last_number = c.par_iter().find_map_last(|s| s.parse().ok());
    ///
    /// assert_eq!(last_number, Some(5));
    /// ```
    fn find_map_last<P, R>(self, predicate: P) -> Option<R>
    where
        P: Fn(Self::Item) -> Option<R> + Sync + Send,
        R: Send,
    {
        fn yes<T>(_: &T) -> bool {
            true
        }
        self.filter_map(predicate).find_last(yes)
    }

    #[doc(hidden)]
    #[deprecated(note = "parallel `find` does not search in order -- use `find_any`, \\
                         `find_first`, or `find_last`")]
    fn find<P>(self, predicate: P) -> Option<Self::Item>
    where
        P: Fn(&Self::Item) -> bool + Sync + Send,
    {
        self.find_any(predicate)
    }

    /// Searches for **some** item in the parallel iterator that
    /// matches the given predicate, and if so returns true.  Once
    /// a match is found, we'll attempt to stop process the rest
    /// of the items.  Proving that there's no match, returning false,
    /// does require visiting every item.
    ///
    /// # Examples
    ///
    /// ```
    /// use rayon::prelude::*;
    ///
    /// let a = [0, 12, 3, 4, 0, 23, 0];
    ///
    /// let is_valid = a.par_iter().any(|&x| x > 10);
    ///
    /// assert!(is_valid);
    /// ```
    fn any<P>(self, predicate: P) -> bool
    where
        P: Fn(Self::Item) -> bool + Sync + Send,
    {
        self.map(predicate).find_any(bool::clone).is_some()
    }

    /// Tests that every item in the parallel iterator matches the given
    /// predicate, and if so returns true.  If a counter-example is found,
    /// we'll attempt to stop processing more items, then return false.
    ///
    /// # Examples
    ///
    /// ```
    /// use rayon::prelude::*;
    ///
    /// let a = [0, 12, 3, 4, 0, 23, 0];
    ///
    /// let is_valid = a.par_iter().all(|&x| x > 10);
    ///
    /// assert!(!is_valid);
    /// ```
    fn all<P>(self, predicate: P) -> bool
    where
        P: Fn(Self::Item) -> bool + Sync + Send,
    {
        #[inline]
        fn is_false(x: &bool) -> bool {
            !x
        }

        self.map(predicate).find_any(is_false).is_none()
    }

    /// Creates an iterator over the `Some` items of this iterator, halting
    /// as soon as any `None` is found.
    ///
    /// # Examples
    ///
    /// ```
    /// use rayon::prelude::*;
    /// use std::sync::atomic::{AtomicUsize, Ordering};
    ///
    /// let counter = AtomicUsize::new(0);
    /// let value = (0_i32..2048)
    ///     .into_par_iter()
    ///     .map(|x| {
    ///              counter.fetch_add(1, Ordering::SeqCst);
    ///              if x < 1024 { Some(x) } else { None }
    ///          })
    ///     .while_some()
    ///     .max();
    ///
    /// assert!(value < Some(1024));
    /// assert!(counter.load(Ordering::SeqCst) < 2048); // should not have visited every single one
    /// ```
    fn while_some<T>(self) -> WhileSome<Self>
    where
        Self: ParallelIterator<Item = Option<T>>,
        T: Send,
    {
        WhileSome::new(self)
    }

    /// Wraps an iterator with a fuse in case of panics, to halt all threads
    /// as soon as possible.
    ///
    /// Panics within parallel iterators are always propagated to the caller,
    /// but they don't always halt the rest of the iterator right away, due to
    /// the internal semantics of [`join`]. This adaptor makes a greater effort
    /// to stop processing other items sooner, with the cost of additional
    /// synchronization overhead, which may also inhibit some optimizations.
    ///
    /// [`join`]: ../fn.join.html#panics
    ///
    /// # Examples
    ///
    /// If this code didn't use `panic_fuse()`, it would continue processing
    /// many more items in other threads (with long sleep delays) before the
    /// panic is finally propagated.
    ///
    /// ```should_panic
    /// use rayon::prelude::*;
    /// use std::{thread, time};
    ///
    /// (0..1_000_000)
    ///     .into_par_iter()
    ///     .panic_fuse()
    ///     .for_each(|i| {
    ///         // simulate some work
    ///         thread::sleep(time::Duration::from_secs(1));
    ///         assert!(i > 0); // oops!
    ///     });
    /// ```
    fn panic_fuse(self) -> PanicFuse<Self> {
        PanicFuse::new(self)
    }

    /// Creates a fresh collection containing all the elements produced
    /// by this parallel iterator assert_eq!(sum, (0..2ep de rayon:where
T all<P>(sel /// # Examples
   he `foc/ sem    this /
  nin.html#panIndexedion<T>>,
       y, `Nonthat pleerly/ - ` the sequons.
   this  producing t.Examples
   he `foc/ sem<T>octainiessiciuce()l
    findi //knowledgeving that thssorreadsy this pae to
    ///  producd of yi   //<T>owely deter-eu is found.
    xi/// - foc
    /    / ###tnall
    //llenm<T>octa/
    /all tfoc
   ../fn.join.html#panIndexedion<T>>,
       y,: find
  ndexedion<T>>,
       / # Ein.html#panmples
   he `foc/ se:`
    fn panifind
  ndexedion<T>>,
       / # E/ # Exammples
   he `foc
    ///
    /// ```
    /// use rayon::prelude::*;
    ///
    /// let a = [0, 12, 3, 4, 0, 23, 0]hich`foc).collect()
    /0
    //
    ///ssert_eq!(&chained[..], &[, 0];hich`foc).collect()
    /0
    //());
    ///ssert_eq!(&chained[..], &[0, 1, 2, 9,hich`foc,];hich`foc/// Now `fold` will process gro `reduce` sert_// `fir
    / element    ///[`unzip`](/ # Examunzip)ion and globa`firsequ lon:/ use rayon::prelude::*;
    ///
    /// let a = [0, 12, 3, 4, 0, 23, 0];
    ourfact/// 2act/
   act/  //)];
    ///
      /// ,s a prd): (collec,.collec)> 10)   //());
    ///ssert_eq!(&chained[..], &[0, 1, 2, 9, /// ,s/ ```
    3]rial(5), 120);
    /// a prd,/// assert_4]/// Now `fold` will process groOr   ///[`  ///mentes)
`](/ # Exam  ///mentes)
)globa`Ei   /`qu lon:/ use rayon::prelude::*;
    ///
    /// let a = [0, 12, 3, ///
    ///   //:Ei   /0, 12, 3, 4, 0, 23, 0](topp, the i): (collec,.collec)> 1
   8
    //());
    //    counter.fetch_add(e { N% 2`
  0ate some work
    /Ei   /::Lopp(x *//)`
    fn panic     })e some work
    /Ei   /::Rhe i(x */3)`
    fn panicassert_eq!///ssert_eq!(&chained[..], &[0, 1, 2, 9,topp, / ``8```6 ass]rial(5), 120);
    ///the i, /3  fn 15 as1]/// Now `fold` will process gro `reducee the isert_//nm<r //rarily-  //ed ///
    /// ads
 ior over`Ei   /`:/ use rayon::prelude::*;
    ///
    /// let a = [0, 12, 3, ///
    ///   //:Ei   /0, 12, 3, 4, 0, 23, 0]( /// ,s(topp, the i)): (collec,.(collec,.collec))`
    fn pani 1
   8
    //());
    //    counter.fetch_add(add(e { N% 2`
  0ate some work
    /).prox,/Ei   /::Lopp(x *//)ry_reduce(|| 0, u3c     })e some work
    /).pro-x,/Ei   /::Rhe i(x */3)ry_reduce(|| 0, u3c`
    fn panic_//ssert_eq!(&chained[..], &[0, 1, 2, 9, /// ,s/ ``-/ asse-  /// -5 a6 a-7]rial(5), 120);
    ///topp, / ``8```6 ass]rial(5), 120);
    ///the i, /3  fn 15 as1]/// Now `fold` will process groA///
  llel duce_uons_/ jucs of [alue.
   ///
    /// [`fhe elementsoal fold to is more oba`alue mayd the:/ use rayon::prelude::*;
    ///
    /// let a = [0, 12, 3, ///
    ///   //:Ei   /0, 12, 3, 4, 0, 23, 0].
    : is mor<(collec,.(collec,.collec)), _>`
    fn pani 1
   8
    //());
    //    counter.fetch_add(add(e { N> 5})e some work
    /).prencoxry_reduce(|| 0, u3c     }e { N% 2`
  0ate some work
    /).prOk(ox,/Ei   /::Lopp(x *//)rry_reduce(|| 0, u3c     })e some work
    /).prOk(o-x,/Ei   /::Rhe i(x */3)rry_reduce(|| 0, u3c`
    fn panic_//ssert_eq!(&chained[..], &[, 0]Ok(x))=].
    munwrap```
 load(Ordering::SeqCOk(x))== 6 || Ok(x))== 7<C>(self, chain: C) -> ssert_n<Self,    whearallelIterator<Item =F   ion<T>>,
        Chain::new(self, chain.into_      a());
    s a fresh collection Unzipsiterator anronithe given
    /// pg.
    `fir
   <r //rartype of va`ion<T>>,Exter -- producers rayon:where
T all<P>(sel /// # Et try t`unzip  he `focsessin optim<T>octaini (wipe of `1` ssiciuce()l
    findi //knowledget thssorreadsy this pae tot None from the m producd of yi   //<T>owely deter-eu i  xi/// -ot None ffoc
  s'/    / ###tnalsl
    //llenm<T>octa/
  /all tfoc
  ss
    ///
    /// ```
    /// use rayon::prelude::*;
    ///
    /// let a = [0, 12, 3, 4, 0, 23, 0];
    ourfact/// 2act/
   act/  //)];
    /// 4, 0, 23, 0](topp, the i): (collec,.collec)> 1er());
    ///    /// unzipeq!(&chained[..], &[0, 1, 2, 9,topp, / ```
    3]rial(5), 120);
    ///the i, // assert_4]/// Now `fold` will process groN //ed 
 ior duce juunzipput tho./ use rayon::prelude::*;
    ///
    /// let a = [0, 12, 3, 4, 0, 23, 0]// assd o(squarsd ocubes)): (collec,.(collec,.collec))i 1
   4)  .map(|x| {
    ///              ci| (i,.(i */i,.i */i */i)rry_reduce(|| 0 unzipeq!(&chained[..], &[0, 1, 2, 9,/ assd o/ ```
    3]rial(5), 120);
    /// quarsd o/ ```
 // 9]rial(5), 120);
    ///cubes o/ ```
 8``2in<C>(self, chain: C) ->unzip<A, B,=F   A,=F   BSelf,    wh(F   A,=F   B)rallelIterator<Item = Option<T>>,
        T: Send(A, B)       WhilF   A: Defa   / K,
    {ion<T>>,Exter <A       WhilF   B: Defa   / K,
    {ion<T>>,Exter <B       WhilA: {
        fn yBSome::new(self)
    }
unzip::unzipes a fresh collection P ///mentsiterator anronithe given
    /// pg.
    `fir
   <r //rartype of va`ion<T>>,Exter -- producers   Ior anlobauced is no`e).is_non`r-exampl other iteruredupg.
  scovered a producerways from
 way,dupg.
  scov a prd not all parallel iter:
un /// liststys arer`
       //  ///mentes no orig>owel it's
  ect:
    // elementsd the ** item artial sum). Wis no matld()`] f (witfl xibing charactethe sel .
    // ///iteratnnot    /// `the i And / ###on, so "fi()`,iven predicate |a: iterainreducucedssumn the it newap/re its inps
    ///
    /// ```
    /// use rayon::prelude::*;
    ///
    /// let a = [0, 12, 3, 4, 0, 23, 0](topp, the i): (collec,.collec)> 1
   8
    //());
    //  ///ment    //N% 2`
  0q!(&chained[..], &[0, 1, 2, 9,topp, / ``2
 // 6]rial(5), 120);
    ///the i, // a3t sum: _fuse(self) -> PanicFuse///ment<A, B,=ool
    where
        P: F(A, B)rallelIterator<ItemA: Defa   / K,
    {ion<T>>,Exter <Chain::new(self, fn yBSoDefa   / K,
    {ion<T>>,Exter <Chain::new(self, fn y+ Sync + Send,
    {
        self.find_any(predicate)
  unzip::  ///ment  /// Applies the given predicateP ///mentsil sumapsiterator anronithe given
    /// pg.
    `fir
  al(5), 120r //rarta`ion<T>>,Exter -- producers   `Ei   /::Loppalting
 dupg.
 tics of [`joiered a producerways f`Ei   /::Rhe ialting
 dupg.
  scov a prd not all parallel ```
    /// use rayon::prelude::*;
    /// use std::sync::atomic::{AtomicU    ///   //:Ei   /0, 12, 3, 4, 0, 23, 0](topp, the i): (collec,.collec)> 1
   8
    //());
    /  ///     .fold(|//mentes)
 counter.fetch_add(add(e { N% 2`
  0ate some work
    /).prEi   /::Lopp(x *//)`
    fn pani, u3c     })e some work
    /).prEi   /::Rhe i(x */3)`
    fn pani, u3c`
    fn panic_!(&chained[..], &[0, 1, 2, 9,topp, / ``8```6 ass]rial(5), 120);
    ///the i, /3  fn 15 as1]/// Now `fold` will process groN //ed `Ei   /`qenratoduce jusplit// actua./ use rayon::prelude::*;
    /// use std::sync::atomic::{AtomicU    ///   //:Ei   /= [0, 12, 3, 4, 0, 23, 0]((fizzbuzzue fzzact/buzzueeep d)): ((collec,.collec),.(collec,.collec))i 1
1ar_ir()
    ///     .panic_fuse()
    ///     .for|//mentes)
 coun        N% 3   N% 5)})e some work
    / our0)  }
Lopp(Lopp(x) a: String, b: Stri our_)  }
Lopp(Rhe i(x) a: String, b: Stri _ur0)  }
Rhe i(Lopp(x) a: String, b: Stri _ur_)  }
Rhe i(Rhe i(x) a: String, b: }q!(&chained[..], &[0, 1, 2, 9, /zzbuzzue[15]rial(5), 120);
    /// /zz, /3  6  fn 12
 18]rial(5), 120);
    ///buzzue[5 a10]rial(5), 120);
    ///eep d, // asse// 7``8```1um<Sum<4```6 a17``19 _fuse(self) -> PanicFuse///mentes)
<A, B,=o, L Option<R>
    where
       (A, B)rallelIterator<ItemA: Defa   / K,
    {ion<T>>,Exter <L(self, fn yBSoDefa   / K,
    {ion<T>>,Exter <R(self, fn y+ Sync+ Send,
    {
 Ei   /<L OptSend,
    {
        fn yL: {
        fn yes<T>(_: &T) -> bool {
unzip::  ///mentes)
  /// Applies the given predicateI`]. sp. she /    anronin not so gbetweenlting
    /// as soon as
    ///
    /// ```
    /// use rayon::prelude::*;
    ///
    /// let a = [0, 12, 3, 4, 0, 23, 0]xi 1foc!// asser];
    ///
    r).collect()x    //());
    //i`]. sp. sh(-1_//ssert_eq!(&chained[..], &[0, 1, 2, 9,d, foc!// a-/ asse-1  3]rial(5), 12 -> PanicFui`]. sp. sh( /// Anot so :Send,
        R:I`]. sp. shlf: ParallelIterator<Item = Opelf.redth::new(self, init, fI`]. sp. shiter())
    not so  iterator over the `Some` items of thue for the g`n`sy this pa atte*   /// `*atches tothehort-s soon as
    ///
    /// ld()`] fntial iterato ndexedion<T>>,
       ::take`]lds in th /// ect:
    //nsfindnut they do you
   `n`s due toothehort-s soon a\
     may tics of [`akenot specified   ///mndnoducue tir
letults \
     /// `fap predot None ffics wiatchnmples
 es duce a
 ways fntial itoT: Clss
    ///
    /// ```
    /// use rayon::prelude::*;
    ///
    /// let a = [0, 12, 3, 4, 0, 23, 0].
    : collect()
    /0
()
    ///     .panic_fuse()
    ///     .flast(y/// asse% 2`
  0q    ///     .f`ake  }

5q    ///     .f/ssert_eq!(&chained[..], &[0, 1, 2, 9,d
    mle fn m5load(Ordering::SeqCd
    mmallowe(2
    //w| w[0] < w[1]/rial(5), 12 -> PanicFu`ake  }

)
     (1.aluea, b| akeAny:new(self)
    }
 akeAnyiter())
    n iterator over the `Some` items of thue foskipsi`n`sy this pa atte*   /// `*atches tothehort-s soon as
    ///
    /// ld()`] fntial iterato ndexedion<T>>,
       ::skip`]lds in th /// ect:
    //nsfindnut they do you
   `n`s due toothehort-s soon a\
     may tics of [remduced
 t specified   ///mndnoducue tir
letults \
     /// `fap predot None ffics wiatchnmples
 es duce a
 ways fntial itoT: Clss
    ///
    /// ```
    /// use rayon::prelude::*;
    ///
    /// let a = [0, 12, 3, 4, 0, 23, 0].
    : collect()
    /0
()
    ///     .panic_fuse()
    ///     .flast(y/// asse% 2`
  0q    ///     .fskip  }

5q    ///     .f/ssert_eq!(&chained[..], &[0, 1, 2, 9,d
    mle fn m45load(Ordering::SeqCd
    mmallowe(2
    //w| w[0] < w[1]/rial(5), 12 -> PanicFuskip  }

)
     (1.aluea, b|SkipAny:new(self)
    }
SkipAnyiter())
    n iterator over the `Some` items of thue fot// toy this pa atte*   /// `*atches tothehort-s soon a::*;
    /n  /h each item e).is_non`r-exampl ` /// `s
    ///
    /// ldno`e).is_non`r /// ju    alwg    e.g.ng
 c  /// juc/ as/
    /at_//bohe res t spway
    /// ect.
   prd/ment /nletulut they door matt)
     thhread///
    ///  falsof.de didn't use `paniche given
n't  continue e).is_non`r-ac   ///h it difreduc0].
    s    /// fual(5), 12 erur`tic.
    ified   ///t// / foseuse///cul ither fold    /n compan the it` /// `tics of [re    / atte    /// `faouskip//
  / This ws no m
    ///
    /// ld()`] fntial iterato        ::take_d    `]lds in th ///  //nsfindnut they doothehortot None from the m
     may [`akenot specified   ///mndnoducue tir
letults \
     /// `fap predot None ffics wiatchnmples
 es duce a
 ways fntial itoT: Clss
    ///
    /// ```
    /// use rayon::prelude::*;
    ///
    /// let a = [0, 12, 3, 4, 0, 23, 0].
    : collect()
    /0
()
    ///     .panic_fuse()
    ///     .f`ake  }
_d     coun* Non50q    ///     .f/ssert_eq!(&chained[..], &[0, 1, 9,d
    mle fn <=n50qoad(Ordering::SeqCd
    mmallowe(2
    //w| w[0] < w[1]/rial(5), 12 -> Pani rayon::prelude::*;
    /// use std::sync::atomic::{AtomicUsize, Ordering};
  / let valueomic::{AtomicUsize, Ordering};
  // should Retuxe(item)` ismic::{Atoieldssert_//ny groupg other fhue fosum <=n /00 4, 0, 23, 0]quota /// let value = (0_ /0032..2048)
    /.
    : collect()
 _.alue   /0
()
    ///     .panic_fuse()
    ///     .f`ake  }
_d     c&ounter.fetch_add(add(quotaCst);
 updnon(Retuxe( Opetuxe( O|q| q ///     sub(x) e some work
    /).prreatrt_e: String, b: }q    ///     .f/ssert_eq!(&chained[..], &[er()
    /d
    m// assert_::<.alue> load(Ordering::SeqCredicat fn sum902..= /003rial(5), 12 -> PanicFu`ake  }
_d    bool
    where
        P: F akeAny
           PSelf::Item) -> bool + Sync + Send,
    {
        self.find_any(predicate)
   akeAny
    iter())
    pplies the given predicatee `Some` items of thue foskipsiy this pa atte*   /// `*atches tothehort-s soon a::*;
    /n  /h each item e).is_non`r-exampl ` /// `s
    ///
    /// ldno`e).is_non`r /// ju    alwg    e.g.ng
 c  /// juc/ as/
    /at_//bohe res t spway
    /// ect.
   prd/ment /nletulut they door matt)
     thhread///
    ///  falsof.de didn't use `paniche given
n't  continue e).is_non`r-ac   ///h it difreduc0].
    s    /// fual(5), 12 erur`tic.
    ified   ///skip/ foseuse///cul ither fold    /n compan the it` /// `tics of [re    / atte    /// `faouskip//
  / This ws no m
    ///
    /// ld()`] fntial iterato        ::skip d    `]lds in th ///  //nsfindnut they doothehortot None from the m
     may [remduced
 t specified   ///mndnoducue tir
letults \
     /// `fap predot None ffics wiatchnmples
 es duce a
 ways fntial itoT: Clss
    ///
    /// ```
    /// use rayon::prelude::*;
    ///
    /// let a = [0, 12, 3, 4, 0, 23, 0].
    : collect()
    /0
()
    ///     .panic_fuse()
    ///     .fskip  }
_d     coun* Non50q    ///     .f/ssert_eq!(&chained[..], &[0, 1, 9,d
    mle fn >=n50qoad(Ordering::SeqCd
    mmallowe(2
    //w| w[0] < w[1]/rial(5), 12 -> PanicFuskip  }
_d    bool
    where
        P: FSkipAny
           PSelf::Item) -> bool + Sync + Send,
    {
        self.find_any(predicate)
  SkipAny
    iter())
    pplies the given predicateI`]. This* item  |a: io defdnuey dobehavior    /// ahat is not None from the .l<P>(ry single onea: io c   ///iel irrt_lym
    ///
    /// ld()`* item causepae to
    /// p::ma`tems se//arallel// ect:
    t specys fro fea: ihvaluhey don/nsum   `n/nsum  `/ seqby/ se.predicateIe sel split/y don/nsum    finalldo/ ###o io c `Somactually mattepportunity io rallel // # Examples
    ///
    /// Seuey do[README] ** i (witdeodu  cproducen`]. This ads
 t is not None from the : ../fn.join.html#paREADME]/std/iter/gs iubf/sm/    /-rs/    //bct./mashod.srcethod.plu/
  g/README.md PanicFudr/ Baunindexedn<Self, C::/nsum  >
    whed Re    arallelIterator<Item =UnindexedC/nsum  <Chain::new(; predicateI`]. This* item  |a: io defdnuey dobehavior    /// ahat is not None from the .l<P>(ry single onea: io c   ///iel irrt_lym
    ///
    /// Rast** non-Nmap_las other fhtion, allssert_eqs soon as if/knownin.html#pst   educeter effduce juusallsse:/nsum   contitheglasimpl hisfaroving thatpaths may rfinals if/   ///_ /// Note that,ert_eqs soon ater main t::*;
    ///
on-N(indexed) `C/nsum  `/* item// `thedr/ /
    :/nsum  ,)
  while attence split_a_eq`. Cduc/
  `UnindexedC/nsum  ::split_off_toppeq`  a::*;
    eep de`UnindexedC/nsum  `/* item//   // ts require itenacc ///ually matt/ asse   sel .
    /iFuse<Sesm
    ///
    /// ld()`* item effdurruce()l |a: io /// [`jehnmples
 enlobauanoving that therureRr maimpl hi`join`];ng
  /// juremov[alu not determiimpl hi`join`]`] fnta within pcFu///_le f&
    where
     .alue>edicate)
  Ne_some<T}
n p
   <Tption<T>>,
       >= Self::Item>,
    {
nloba match fiteraI    //T;tch fiteraI     /Tn::new; predicFui`]oa());
    s a f, b| match f(&a,s a ome<T}
n p groAitems of thue fosupports "rys tteaccess" io tt) dnoa,`* aquir
predicatey`reducesplit/it//t20r //rartaindiceecys fdraw dnoa/ att
predicoseuso/ lss
///
pred**iter:** item    this /
 loba`u64es di64es du128 find<Pi128 
  ng/// fusa// [`floba`Exat_Slue        ::eat    /`temsto thabii`jed. Seuet.Iterato/t.It#35428
#[ig>ow(clippy::le _ds in t_eat    /)]
pubifind
  ndexedion<T>>,
       :tion<T>>,
       nter.fetch_dssert_sinistic.
     due to
    /// g.
  scov mpl is not None ffoc
   may [foc
  /
   iteraterund` do  finallexecu[`find` on sebeeho the fanics wi,r-eu n the itfoc
  /acrnic
n't  cducelead other items/// # Eperinamacuces mappitr-eu ise its inp/    / ##bufreds
    ///
    /// ```
    /// use rayon::prelude::*;
    ///
    /// let a = [0, 12, 3, 4, 0, 23d.
  l //ior dnoa/mpts to erund` do 4, 0, 23, 0]m thfoci 1foc!/-1  -sse- ]_000)
    ///     .int5
    //());
    /  ///     .folmples
   he `foc/&m thfocq!(&chained[..], &[0, 1, 2, 9,/oc,]/ ```
    3t_4]/// Now `fold` will -> ssert_  he `foc/lf, C:se/ge : &m thcollChain::new(g::Greater = ssert_:: ssert_  he `foc/lf, C:se/ge /// Nowcollection Unzipsiteraic.
     due to
    /// g.
  scov mpl is not None ffoc
  s may [foc
  the caller,
 erund` do  finallexecu[`find` on sebeeho the fanics wi,r-eu n the itfoc
  s/acrnic
n't  cducelead other items/// # Eperinamacuces mapprest -eu i  its inp/    / ##bufreds
    ///
    /// ```
    /// use rayon::prelude::*;
    ///
    /// let a = [0, 12, 3, 4, 0, 23d.
  l //ior dnoa/mpts to erund` do 4, 0, 23, 0]m thartia 1foc!/42;a10]; 4, 0, 23, 0]m thm). Wi 1foc!/-1;a10]; 4, 0, 2 ///     .1    5
    //());
    /  ///     .folenra   /i| {
    ///     unzip  he `focse&m tharti, &m ththe i)!(&chained[..], &[0, 1, 2, 9,topp, / ```
    3t_4]/// Now `fo0);
    ///the i, //0```1um<2um<Sum<4n<C>(self, chain: C) ->unzip  he `focs<A, BSelf, C:topp: &m thcollA>, the i: &m thcollB>)rallelIterator<Item = Opt ndexedion<T>>,
        T: Send(A, B)       WhilA: {
        fn yBSome::new(self)
    }
 ssert_::unzip  he `focself, C:topp,hthe i)!(&chan predicateI      anrs iteu  // `(A, B)sin op/re itsher fh`A`he ca att
ics of [`j_eqs soon atys f`B`he ca attue to
    /// h item ///rguhis .predicateL/// list`zip`** item in\
  enarator  the :,ruly asstwoot None from the :he ca duunequhisle gth,ey`rein thge e itsher fhrestot None fne
  ihe itmnon-None value is pr```
    /// use rayon::prelude::*;
    ///
    /// let a = [0, 12, 3, 4, 0, 23, 0].
    : collect()
1  4)()
    ///     .panic_fuse()
    ///     .fzipefoc!/'a', 'b', 'c']q    ///     .f/ssert_eq!(&chained[..], &[0, 1, 2, 9,d
    , //// 'a'act/
  'b'act/  /'c')n<C>(self, chain: C) ->zip<ZSelf, C:zip op: Zf, b|Zip<      Z: IntoParallelIterator<IteZ = Self::Item>,
    {
,rator<IteZ  Intopt ndexedion<T>>,
       new(self)
    }
Zip::er())
    zip op  /// Searches for **some** item Tits inp/nce Zipsinthe .
    /fhue fompleder, much like
  its inp/le gthn-None value is pr``Pmples
    /// Wia use    /f p::ma`tys f`zip op` ///
     its inp/le gthn-None value is pr rayon::prelude::*;
    /// use std::{thread, time};
  4, 0, 23, 0] seq ///u8]; 4, 0, 23, 0] new //2u8, 7];
    ///
     seb.par_it se.Searches f; 4, 0, 23, 0] neb.par_it ne.Searches f; 4, 0, 2 4, 0, 23d.
`j_eqwia use    4, 0, 23, 0]zipput: coll(&u8, &u8)>_it se   ///zip eq( neb.par_//ssert_eq!(&chained[..], &[ocess(ry singl`
  hge elIterator, &[0, 1, 2, 9,1,]zipputmle fn<C>(self, chain: C)#[finck_n't al]n: C) ->zip2, <ZSelf, C:zip op: Zf, b|ZipEq<      Z: IntoParallelIterator<IteZ = Self::Item>,
    {
,rator<IteZ  Intopt ndexedion<T>>,
       new(self)
    }
, 0]zip opb.par_itzip op  /// Searches f  /// Take0, 1, 2, 9,        self.y(is_le fn         self.zip opb.par_le fn         self."er, much ler maike
  its inp/le gth"        sf  /// TakeZipEq::er())
    zip opb.par_ given predicateI`]. leav toy this pa   /// as soon aays from
eep ded if so returnrom the .lAl]. Thte thr the gy this pa atte/// as soon aays on function. If thes soon as /n  /hmpledaallexhau//edthe f sequ soon a::*;
    d;
 xhau//eds finally p eep d, tem aa may this paaallph, rddo 4, 0, 23 attue toeep d not all parallel ```
    /// use rayon::prelude::*;
    /// use std::sync::atomic::{Ato, 0](), S)i 1
foc!// as], foc!/  /// 5/ 6]rial(5), 12    r).colli32ct()x    //());
    //i`]. leav (y_//ssert_eq!(&chaine[0, 1, 2, 9,d, foc!// a3 asse// 5/ 6]rial(5), 12 -> PanicFui`]. leav <ISelf, C:eep dpt    R:I`]. leav <      I: IntoParallelIterator<IteI = Self::Item>,
    {
        Chain::new(self, <IteI  Intopt ndexedion<T>>,
               Chain::new(self, chain.intoI`]. leav ::er())
    eep d  /// Searches for **some** item I`]. leav toy this pa   /// as soon aays from
eep ded if so returnrom the s /n  /h sequ;
 xhau//ed not all parallel ```
    /// use rayon::prelude::*;
    /// use std::sync::atomic::{Ato, 0](), S)i 1
foc!// as  3t_4], foc!/5/ 6]rial(5), 12    r).colli32ct()x    //());
    //i`]. leav _  ///edden_//ssert_eq!(&chaine[0, 1, 2, 9,d, foc!// a5 as  6  3]rial(5), 12 -> PanicFui`]. leav _  ///edd<ISelf, C:eep dpt    R:I`]. leav S ///edd<      I: IntoParallelIterator<IteI = Self::Item>,
    {
        Chain::new(self, <IteI  Intopt ndexedion<T>>,
               Chain::new(self, chain.intoI`]. leav S ///edd::er())
    eep d  /// Searches for **some** item Splite` items of thup g.
  fixed-alue chunksm
    ///
    /// Rast** n items of thue fo-exampl `col`   due toIf themap_las oty this p.t use `panic_feemap_las oty this p possible
    ///edicatedifics wiaby `chunk_alue`,on function. aa machunk  /// ju  ///e//llenm`chunk_alue`s
    ///
    /// Seueuons.[`  /_chunks/ sem<s f[`  /_chunks_m t/ semlobantial itbehavior  ot determiilicee,lds in thhavi theom<T>octaiui`]. meditaiu`col`  ** item chunksm
    ///
    /// [`  /_chunks/ se  ///ilice.find
 ion<T>>,Slice/ # E/ # Exam  /_chunks
    /// [`  /_chunks_m t/ se  ///ilice.find
 ion<T>>,SliceMut/ # E/ # Exam  /_chunks_m tnot all parallel ```
    /// use rayon::prelude::*;
    /// use std::sync::atomic::{Ato, 0]ai 1foc!// asserse// 5/ 6/ 7``8``9,a10]; 4, 0, 23, 0]r).collcolli32c>> 10)   //());
    ///hunks/3_//ssert_eq!(&chaine[0, 1, 2, 9,d, foc!/foc!// 2,3], foc!/4,5,6], foc!/7,8,9], foc!/10]]<C>(self, chain: C)#[finck_n't al]n: C) ->/hunks/)
    }
unk_alue(1.aluea, b|Chunks:new(self)
    }
ng::SeqCs
unk_alue != let"s
unk_alue er mane valuzero"f  /// TakeChunksiter())
    }
unk_alueor **some** item Splite` items of thg.
  fixed-alue chunks,Eperinam/
    #on, so "fi[`fold/ sem ot determi// s chunkm
    ///
    /// Rast** n items of thue fotion, aning olded[re    /  th// s chunks other fso returns on, allssert_eqs soon am
    ///
    /// ld()`::sl;
 g::esult of ///:/ use rayon::preludetextso returnrom //hunks/}
unk_alueor **s             c}
unk|e some work
    /chunkm   //
    /e some work
    /).prrfold/rddesuty,g old op/e some work
 )al(5), 12 -> Pani rayon::prelexcepng fals/edicaEper-chunks<T>octa/ inhibit som
    ///
    /// [`fold/ se:Usize,   //:
       / # Exampold
    ///
    /// **Pmplesratofm`chunk_alue`/edi0 not all parallel ```
    /// use rayon::prelude::*;
    /// use std::sync::atomic::{Ato, 0]nrato 1foc!// asserse// 5/ 6/ 7``8``9,a10]; 4, 0, 23, 0]chunk_arato 1nrat)   //());
    // old /hunks/sse|| let|a, n|ing+ n_//ssert_::<collec>eq!(&chaine[0, 1, 2, 9,chunk_arat, foc!/  /7```1um<5``19 _fuse(self) -> Pani#[finck_n't al]n: C) -> old /hunks<T  ID, F>(tch f(&a,s a self, <Ite}
unk_alue(1.alueself, <Iterddesuty: ID,ol) -> booold op: F,ol) -a, b|FoldChunks:new(  ID, F>arallelIterator<IteID Syncf, b| m K,
    {self      WhilF SyncT  + Send,
    {
  m K,
    {self      WhileSome::new(self)
    }
ng::SeqCs
unk_alue != let"s
unk_alue er mane valuzero"f  /// TakeFoldChunksiter())
    }
unk_alue, rddesuty,g old op/e somome** item Splite` items of thg.
  fixed-alue chunks,Eperinam/
    #on, so "fi[`fold/ sem ot determi// s chunkm
    ///
    /// Rast** n items of thue fotion, aning olded[re    /  th// s chunks other fso returns on, allssert_eqs soon am
    ///
    /// ld()`::sl;
 g::esult of /// ` old /hunks/}
unk_alue, || ind
 /    fn m old op/`,on functiexcepngit you, `fi.
    //list`ind
ayd thtemsto `self`, n aaysy
eep deinam
  al(5), 120dded[hich may also im
    ///
    /// [`fold/ se:Usize,   //:
       / # Exampold
    ///
    /// **Pmplesratofm`chunk_alue`/edi0 not all parallel ```
    /// use rayon::prelude::*;
    /// use std::sync::atomic::{Ato, 0]nrato 1foc!// asserse// 5/ 6/ 7``8``9,a10]; 4, 0, 23, 0]chunk_arato 1nrat)   //());
    // old /hunks_ds i/sselet|a, n|ing+ n_//ssert_::<collec>eq!(&chaine[0, 1, 2, 9,chunk_arat, foc!/  /7```1um<5``19 _fuse(self) -> Pani#[finck_n't al]n: C) -> old /hunks_ds i<T  F>(tch f(&a,s a self, <Ite}
unk_alue(1.alueself, <Iternd
: T,ol) -> booold op: F,ol) -a, b|FoldChunksWs i<new(  T, F>arallelIterator<IteeSome::g+ th::new(selWhilF SyncT  + Send,
    {
  m K,
    {self      lf)
    }
ng::SeqCs
unk_alue != let"s
unk_alue er mane valuzero"f  /// TakeFoldChunksWs iiter())
    }
unk_alue, rnd
,g old op/e somome** item Lexicograph educee itparise itsy this pa   /// a`ion<T>>,
       yl
    //ohreads found.
  eep d not all parallel ```
    /// use rayon::prelude::*;
    /// use std::sync::atomic::{AtomicUsize,cmp  // should [0, 12, 3, 4, 0, 23, 0]xi 1foc!// asser];
    ///
0, 1, 2, 9,xr());
    ///mp(&foc!// a3 a0]n mL g:);
    ///
0, 1, 2, 9,xr());
    ///mp(&foc!// a   3]r, Equhi);
    ///
0, 1, 2, 9,xr());
    ///mp(&foc!// a ]r, Gop pro/// Now `fold` will -> mp<ISelf, C:eep dpt    R:// shoularallelIterator<IteI = Self::Item>,
    {
        Chain::new(self, <IteI  Intopt ndexedion<T>>,
       ,ator<Item = Opelf.red//        fn is_false(x: &bool) -> bool o/ shoul<Tpt// >((), S): cT  T)   R:// shoul

        self.// e,cmp(&), &y)p(predicate).find_anse(x: &bool) -> bool {nequhi(&o/ : &// shoul        }

        self.o/  != // should Equhip(predicate).find_an     ep de= eep d  /// Searches f;).find_an     rd_le e= y(is_le fn//mp(&eep d le fn<C>(selelf.y(is_zipeeep d)        self.     o/ shoul)        self. /// Applies{nequhi)        self. unwrap`or( rd_le /e somome** item Lexicograph educee itparise itsy this pa   /// a`ion<T>>,
       yl
    //ohreads found.
  eep d not all parallel ```
    /// use rayon::prelude::*;
    /// use std::sync::atomic::{AtomicUsize,cmp  // should [0, 12, 3,omicUsize,f64::NAN0, 12, 3, 4, 0, 23, 0]xi 1foc!//. ``2. ``3.0];
    ///
0, 1, 2, 9,xr());
    //se///al_/mp(&foc!//. ``3.0 a0.0]n m  ///L g:));
    ///
0, 1, 2, 9,xr());
    //se///al_/mp(&foc!//. ``2. ``3.0]n m  ///Equhi));
    ///
0, 1, 2, 9,xr());
    //se///al_/mp(&foc!//. ``2. ]n m  ///Gop pro/);
    ///
0, 1, 2, 9,xr());
    //se///al_/mp(&foc!//. ``NAN]n mNe_s_fuse(self) -> PanicFuse///al_/mp<ISelf, C:eep dpt    R:/
     // shoulParallelIterator<IteI = Self::Item>,
    {
self, <IteI  Intopt ndexedion<T>>,
       ,ator<Item = Opelf.redPe///al// <In::new(self, chain.intose(x: &bool) -> bool o/ shoul<TptPe///al// <U>, U>((), S): cT  U)   R:/
     // shoulP

        self.Pe///al// ::  ///al_/mp(&), &y)p(predicate).find_anse(x: &bool) -> bool {nequhi(&o/ : &/
     // shoulP        }

        self.o/  !=   ///// should Equhi)p(predicate).find_an     ep de= eep d  /// Searches f;).find_an     rd_le e= y(is_le fn//mp(&eep d le fn<C>(selelf.y(is_zipeeep d)        self.     o/ shoul)        self. /// Applies{nequhi)        self. unwrap`or(  /// rd_le //e somome** item De]. mi  anuly assy this pa   /// a`ion<T>>,
       yal(5), 120rssyquhis
  scohread
  eep d PanicFueq<ISelf, C:eep dpt    R:n(Self::Item) -> bool +I = Self::Item>,
    {
self, <IteI  Intopt ndexedion<T>>,
       ,ator<Item = Opelf.redPe///alEq<In::new(self, chain.intose(x: &bool) -> bool eq<TedPe///alEq<U>, U>((), S): cT  U)   R:   }

        self.Pe///alEq::eq(&), &y)p(predicate).find_an     ep de= eep d  /// Searches f;).find_any(is_le fn`
  eep d le fn &&.y(is_zipeeep d)    /eq/e somome** item De]. mi  anuly assy this pa   /// a`ion<T>>,
       yal(5), 120rssunequhis
  scohread
  eep d PanicFune<ISelf, C:eep dpt    R:n(Self::Item) -> bool +I = Self::Item>,
    {
self, <IteI  Intopt ndexedion<T>>,
       ,ator<Item = Opelf.redPe///alEq<In::new(self, chain.into!y(is_eq(eep d)     ome** item De]. mi  anuly assy this pa   /// a`ion<T>>,
       yal(5), 120rsslexicograph educeel itemsan scohread
  eep dthin pcFult<ISelf, C:eep dpt    R:n(Self::Item) -> bool +I = Self::Item>,
    {
self, <IteI  Intopt ndexedion<T>>,
       ,ator<Item = Opelf.redPe///al// <In::new(self, chain.intoy(is_  ///al_/mp(eep d)`
    ///// should L g:)     ome** item De]. mi  anuly assy this pa   /// a`ion<T>>,
       yal(5), 120rssleite th/quhis
  scohread
  eep dthin pcFule<ISelf, C:eep dpt    R:n(Self::Item) -> bool +I = Self::Item>,
    {
self, <IteI  Intopt ndexedion<T>>,
       ,ator<Item = Opelf.redPe///al// <In::new(self, chain.into     rde= y(is_  ///al_/mp(eep d);).find_an rde==   ///// should Equhi) ||  rde==   ///// should L g:)     ome** item De]. mi  anuly assy this pa   /// a`ion<T>>,
       yal(5), 120rsslexicograph educeetop procmsan scohread
  eep dthin pcFugt<ISelf, C:eep dpt    R:n(Self::Item) -> bool +I = Self::Item>,
    {
self, <IteI  Intopt ndexedion<T>>,
       ,ator<Item = Opelf.redPe///al// <In::new(self, chain.intoy(is_  ///al_/mp(eep d)`
    ///// should Gop pro/     ome** item De]. mi  anuly assy this pa   /// a`ion<T>>,
       yal(5), 120rssleite th/quhis
  scohread
  eep dthin pcFuge<ISelf, C:eep dpt    R:n(Self::Item) -> bool +I = Self::Item>,
    {
self, <IteI  Intopt ndexedion<T>>,
       ,ator<Item = Opelf.redPe///al// <In::new(self, chain.into     rde= y(is_  ///al_/mp(eep d);).find_an rde==   ///// should Equhi) ||  rde==   ///// should Gop pro/     ome** item Y the g itendex ahe
  
    // s mples
    ///
    /// ```
    /// use rayon::prelude::*;
    ///
    /// let a = [0, 12, 3, 4, 0, 23, 0]charto 1foc!/'a', 'b', 'c']2..2048)
    /.
    : collect()chart()
    ///     .panic_fuse()
    ///     .fenra   /i| {
    ///     /ssert_eq!(&chained[..], &[0, 1, 2, 9,d
    , //0/ 'a'act/1  'b'act/2 /'c')n<C>(self, chain: C) ->enra   /i|s a f, b|Enra   /i:new(self)
    }
Enra   /iCreates a fresh collection containinitems of thue fostepslsserttoIf theamt) <
    ///
    /// ```
    /// use rayon::prelude::*;
   ///
    /// let a = [0, 12, 3, 4, 0, 23, 0]. ng/i 1
3   /32..2048)
    /.
    : colli32ct(). ng/{
    ///     .panic_fuse()
    ///     .step_by(3)`
    fn pan /ssert_eq!(&chained[..], &[0, 1, 2, 9,d
    , /3  6  f])al(5), 12 -> PanicFustep_by(lf, C:step(1.aluea, b|StepBy:new(self)
    }
StepByiter())
    stepe given predicatee `Some` items of thue foskipsi`joiered a`n`sy this ps
    ///
    /// ```
    /// use rayon::prelude::*;
    ///
    /// let a = [0, 12, 3, 4, 0, 23, 0].
    : collect()
    /0
()
    ///     .panic_fuse()
    ///     .fskip(95 {
    ///     /ssert_eq!(&chained[..], &[0, 1, 2, 9,d
    , /95  f6  f7  f8``99 _fuse(self) -> PanicFuskip()
     (1.aluea, b|Skip:new(self)
    }
Skipiter())
    n iterator over the `Some` items of thue for the g`joiered a`n`sy this ps
    ///
    /// ```
    /// use rayon::prelude::*;
    ///
    /// let a = [0, 12, 3, 4, 0, 23, 0].
    : collect()
    /0
()
    ///     .panic_fuse()
    ///     .f`ake(5 {
    ///     /ssert_eq!(&chained[..], &[0, 1, 2, 9,d
    , / ```
    3t_4]/// Now `fold` will ->`ake()
     (1.aluea, b| ake:new(self)
    }
 akeiter())
    n iterator over thSearicat/  th**hrearator matossiblhe given
    /// pue f other thredicaterttoIf thepplies thways f-exampl i p podex. eL///ype of va`ion<T>>,        ::/// Aany`,ssiblhe given
searicqwia u eeype of vanecessarily/
   from
**ered ratredicways focucedn      edot None fample we'a uatt    tems sooner, with theads (wis
    ///
    /// ```
    /// use rayon::prelude::*;
    ///
    /// let a = [0, 12, 3, 4, 0, 23, 0];
   `
    3t_3];
    /// 4, 0, 23, 0]i> 1er());
    //pos/mente }

// asse== 3).exompa("ample"qoad(Ordering::SeqCie== 2 || ie== 3)!(&chained[..], &[0, 1, 2, 9,er());
    //pos/mente }

// asse==  /0
 mNe_s_fuse(self) -> PanicFusos/mente }
bool
    where
        P: Fe
     .alue>elf::Item) -> bool + Sync+ Send,
    {
        self.find_any(predicate)
  se(x: &bool) -> bool c/ as(& _urp): &(.alues     )   R:   }

        self.pp(predicate).find_an    (i,._)   y(is_    pplies thefenra   /i| ./// Aany(c/ as)?;).find_an  ///i iterator over thSearicat/  thscov an, so "fly/**ered rator matossiblhe given
    /// iven predicateredicaterttoIf thepplies thways f-exampl i p podex.(&chained[..], &[L/// `ion<T>>,        ::/// Aered  fincucedn      edfample,on functiaa uatt     continuem). Wi due to      mpts to  soopedold    on functiatt     continueartiaer ma many morihe asenin narliero     ::*;
    d;
ample not all parallel iterdicatene vaa use given
    ///  like
 a ///ful o/ sh,aer   l///ype of va#on, so "fi`HashMap`
    //   ,##o  you
    /// junebulous   Ionthaype of vajr mauanog`joiered a      icatedischibied    /// ` possible
    //,on functi`sos/mente }
`/edias/// # Echoice/
    ///
    /// ```
    /// use rayon::prelude::*;
    ///
    /// let a = [0, 12, 3, 4, 0, 23, 0];
   `
    3t_3];
    /// 4, 0, 230, 1, 2, 9,er());
    //pos/mentepplies// asse== 3) m  ///2));
    /// 4, 0, 230, 1, 2, 9,er());
    //pos/mentepplies// asse==  /0
 mNe_s_fuse(self) -> PanicFusos/menteppliebool
    where
        P: Fe
     .alue>elf::Item) -> bool + Sync+ Send,
    {
        self.find_any(predicate)
  se(x: &bool) -> bool c/ as(& _urp): &(.alues     )   R:   }

        self.pp(predicate).find_an    (i,._)   y(is_    pplies thefenra   /i| ./// eppliesc/ as)?;).find_an  ///i iterator over thSearicat/  thscov an, so "fly/**aa mrator matossiblhe given
    /// iven predicateredicaterttoIf thepplies thways f-exampl i p podex.(&chained[..], &[L/// `ion<T>>,        ::/// Aaa m fincucedn      edfample,on functiaa uatt     continueartia due to      mpts to  soopedold    on functiatt     continuem). Wier ma many morihe aseni l proc     ::*;
    d;
ample not all parallel iterdicatene vaa use given
    ///  like
 a ///ful o/ sh,aer   l///ype of va#on, so "fi`HashMap`
    //   ,##o  aa m   /// junebulous   W /// fual(5), 12
     you, `fiactu"fly/ma/ # Eonttha,i`sos/mente }
`/edias/// # ect:
    /hoice/
    ///
    /// ```
    /// use rayon::prelude::*;
    ///
    /// let a = [0, 12, 3, 4, 0, 23, 0];
   `
    3t_3];
    /// 4, 0, 230, 1, 2, 9,er());
    //pos/menteaa ms// asse== 3) m  ///3));
    /// 4, 0, 230, 1, 2, 9,er());
    //pos/menteaa ms// asse==  /0
 mNe_s_fuse(self) -> PanicFusos/menteaa mbool
    where
        P: Fe
     .alue>elf::Item) -> bool + Sync+ Send,
    {
        self.find_any(predicate)
  se(x: &bool) -> bool c/ as(& _urp): &(.alues     )   R:   }

        self.pp(predicate).find_an    (i,._)   y(is_    pplies thefenra   /i| ./// eaa msc/ as)?;).find_an  ///i iterator ove#[doc(hidden)]r ove#[defind` do(tch f(&a,nterd= "se given
`sos/ment` you,ene vsearicqil o/ she   ry t`sos/mente }
`, \\        self.....`sos/mentepplie find<Psos/menteaa m`"     )] PanicFusos/mentbool
    where
        P: Fe
     .alue>elf::Item) -> bool + Sync+ Send,
    {
        self.find_any(predicate)
  y(is_ os/mente }

pplies the given predicateSearicat/  thher fhtossiblhe given
    /// pue fa      iceed if so returnpplies thways f-exampl e tir
indicee/
    ///
    /// ```
    /// use rayon::prelude::*;
    ///
    /// let a = [0, 12, 3, 4, 0, 23, 0]primeto 1foc!/2 a3t sum:```1um<Sum<7``19
  3 as9]!(&chained[..], &[oceF   from
 os/ments ads
rimeto magr, soEont1s (dulo 6 4, 0, 23, 0]p1 (d6: collect()
rimetr());
    //pos/mentss//p| p % 6e==  _//ssert_eq!(&chaine[0, 1, 2, 9,p1 (d6, /3  sum: _f urnppimeto7um<Sumys f19(&chained[..], &[oceF   from
 os/ments ads
rimeto magr, soEont5s (dulo 6 4, 0, 23, 0]p5 (d6: collect()
rimetr());
    //pos/mentss//p| p % 6e== 5_//ssert_eq!(&chaine[0, 1, 2, 9,p5 (d6, /2
 // 6``8``9 _f urnppimeto5```1um<7
  3 ays f29use(self) -> PanicFusos/mentsbool
    where
        P: FPos/mentsb      PSelf::Item) -> bool + Sync+ Send,
    {
        self.find_any(predicate)
  Pos/mentsiter())
    pplies the given predicatePion, aning ///    /// p
    //eoy this pa   /// as soon aaintics of [rev. shm
     
    ///
    /// ```
    /// use rayon::prelude::*;
    ///
    /// let a = [0, 12, 3, 4, 0, 23, 0].
    : collect()
   5
()
    ///     .panic_fuse()
    ///     .frev| {
    ///     /ssert_eq!(&chained[..], &[0, 1, 2, 9,d
    , /4 a3 asse1 a0]nfuse(self) -> PanicFurev|s a f, b|Rev:new(self)
    }
RevCreates a fresh collection Se_sinistminimum/le gths other ///  ldesira: io er, withtos// stics of [r   / job   R   / wia u eeusplit//ny sm't alcmsan sc/ ale gth,ebuoving that thcoursenin rom the m psingalread// ju m't alcmoebeehop
    
    ///
    /// Pion, a  l /// `zip`*ys f`i`]. leav ` wia u///
top procoly asstwoot None fminimump.t use `paChndnut rom the :hent rom the :hinsid/ ` l pes)
`r ///// s ///on function.ir
 wntminimum/le gth 
    ///
    /// ```
    /// use rayon::prelude::*;
    ///
    /// let a = [0, 12, 3, 4, 0, 23, 0]mint()
    _000_000
()
    ///     .panic_fuse()
    ///     .f
   _min_le f1234)()
    ///    fold/|| let|acc,._|eacc.fi1)    //usoEssorreadsa ` possi] fneghis r **s          in// unwrapeq!(&chained[..], &[0, 1, 9,mint>=  234)fuse(self) -> PanicFu
   _min_le f)
    min(1.aluea, b|MinLen:new(self)
    }
MinLeniter())
    minfresh collection Se_sinistmaximum/le gths other ///  ldesira: io er, withtos// stics of [r   / job   R   / wia utry io split//thara mabelsorsc/ ale gth,::*;
    /nl itemsat wpsingpungit belsorscp/le gth3 attu`
   _min_le f)`s
    /// F th/
    /,oIf themin=10il sumax=<5``a/le gths ot16 wia u eeub/ype of va#plit//ny / This  
    ///
    /// Pion, a  l /// `zip`*ys f`i`]. leav ` wia u///
l itrocoly asstwoot None fmaximump.t use `paChndnut rom the :hent rom the :hinsid/ ` l pes)
`r ///// s ///on function.ir
 wntmaximum/le gth 
    ///
    /// ```
    /// use rayon::prelude::*;
    ///
    /// let a = [0, 12, 3, 4, 0, 23, 0]maxt()
    _000_000
()
    ///     .panic_fuse()
    ///     .f
   _max_le f1234)()
    ///    fold/|| let|acc,._|eacc.fi1)    //usoEssorreadsa ` possi] fneghis r **s          ax// unwrapeq!(&chained[..], &[0, 1, 9,maxt<=  234)fuse(self) -> PanicFu
   _max_le f)
    max(1.aluea, b|MaxLen:new(self)
    }
MaxLeniter())
    maxe given predicatePion, aninnh/
 ct //usoEolyssorreadsher fhre/ as soon aawia so returns on, a  pplsumn thcaEpe    occ /e/
    ///
    /// ```
    /// use rayon::prelude::*;
    ///
    /// let a = [0, 12, 3, 4, 0, 23, 0]pc_fuse(t()
    /0
)   //());
    //zipefoc!/0;a10]rial(5), 120);
    ///());
   mle fn m10q!(&chained[..], &[er()foc: collect()
));
   m/ssert_eq!(&chaine[0, 1, 2, 9,focmle fn m10q!(&chaine) -> PanicFule f&
    wherualueompredicateI`]. This* item  |a: io defdnuey dobehavior    /// ahat is not None from the .l<P>(ry single onea: io c   ///iel irrt_lym
    ///
    /// ld()`* item causepae to
    /// p::ma`tems se//arallel// ect:
    t specys fro fea: ihvaluhey don/nsum   `n/nsum  `/ seqby/ se.predicateIe sel split/y don/nsum    finalldo/ ###o io c `Somactually mattepportunity io rallel // # Examples Iona split/you,ehappen, t ally mattwia uininam
y don/nsum    due to
ndex  op/re itssplit/ry sinally mattecc / (/nl/// `ion<T>>,        ::dr/ Baunindexedf)`)s
    ///
    /// Seuey do[README] ** i (witdeodu  cproducen`]. This ads
 t is not None from the : ../fn.join.html#paREADME]/std/iter/gs iubf/sm/    /-rs/    //bct./mashod.srcethod.plu/
  g/README.md PanicFudr/ B<C: C/nsum  <Chain::new(Self, C::/nsum  >
    whed Re    ompredicateI`]. This* item  |a: io defdnuey dobehavior    /// ahat is not None from the .l<P>(ry single onea: io c   ///iel irrt_lym
    ///
    /// ld()`* item conv. tsue to
    /// g.
  a rallel r Pays from so returnrnvo/ to`c       .c       eq` 
    P. iterdicate asst thtads found.
/// ahallel r edicatedefdnud/nce  //  due toAPI,es map(&chaine) c       `ier mabeedefdnud/gener educee** iaa usion, a  ter efon functiaa owsue tohallel r d thtems manducurereduc an;ng
 uons.* aqsiven predicatese given
    ///  lduceadjr maicate  thtds in thcaush thend` on seb `S / ##ch ng/s
    ///
    /// Seuey do[README] ** i (witdeodu  cproducen`]. This ads
 t is not None from the : ../fn.join.html#paREADME]/std/iter/gs iubf/sm/    /-rs/    //bct./mashod.srcethod.plu/
  g/README.md PanicFu
   _hallel r<CB: Pion, a C       <Chain::new(Self, C::       >
 B   wheB::OT: Cl;
n p gro`Fattion<T>>,
       yl    this sue toc `So/ inhf   :/sert_`fin, 23 attua [`ion<T>>,
       y]. Byl    this uir
pred`Fattion<T>>,
       yl** iaoIf the  th,ey`redefdnuessorg
 mpts to
predc `Somd3 attuanqs soon am
///
pred`Fattion<T>>,
       yl s  |a: ihrough [`ion<T>>,
       y]'s [`/ssert_eq`]`* itemm
///
pred[`ion<T>>,
       y]: find
 ion<T>>,
       / # E
pred[`/ssert_eq`]: find
 ion<T>>,
       / # E/ # Exam/ssert_
///
pred```
    //////
predI   this uird`Fattion<T>>,
       yl** iy`rr d th:
///
pred`->     ///
    /// let a = [0, 3,omicUsize,mew; ///
predstruct Bl   Holeelf        mass(1.aluese    } ///
pred
   <Tptnd_a> Fattion<T>>,
       <T>l** iBl   Holeelf         -> att/());
   <ISe());
   pt    R:Chai
e work
    / op/reI = Self::Item>,
    {
        T>
e work
 {
e work
    /, 0]pc_fuse(t()
));
   m /// Searches f;)e work
    /Bl   Holeelf                mass(1
));
   m/suso() *`* m::alue_oin:<T>fn              }         }e    } ///
pred, 0]bh:/Bl   Holee()
 i32   /00
)   //());
    ///ssert_eq!(ine[0, 1, 2, 9,bh.mass, 4/0032.pred`-> pubifind
 Fattion<T>>,
       <T>
Item) -> beSome::ne{r over the `Some` iten secuce due to:/sert_`fi3 attue tohe given
    /// p`());
   `.de didn't use `panicy`rr :/sert_`fi3edicatenaturduceehe given,ssibleasie ma(ys on functifaroe m) way io dohre/ ass adtthe o :/sert_p`());
   ` g.
  a
    /// [`LinkedListsem r  ep dei`]. meditaiudnoa/structureays from so return an, so "fly/ext
   y`rr :/sert_`fi. Howev. ``a/ (wit'nults 'iven prediechniqus/edi
  u i  its[`());
    foldsem r
    /// [`  /_
    fold_ds i`]`* items io c `Somactu :/sert_`fi.
    /// Al]. Thtts ly,rulyy`rr :/sert_`fi3edi'Thtts ly'ehe given,sthaype of vaducery t`s /_
    for_// s` io er, with// s y this  possurim
    ///
    /// [`LinkedListse/std/iter/doc.t.Iterato.org/siz/:/sert_`fis/struct.LinkedList/ # E
    /// [`  /_
    fold`]: find
 ion<T>>,
       / # E/ # Exampold
    /// [`  /_
    fold_ds i`]: find
 ion<T>>,
       / # E/ # Exampold_ds i
    /// [`  /_
    for_// s`]: find
 ion<T>>,
       / # E/ # Exampor_// s
     -> att/());
   <ISe());
   pt    R:Chai
rallelIterator<IteI = Self::Item>,
    {
        T>;
n p gro`f::Item>Ext
  `/ext
  ninnh/
ist//  //sert_`fi3
    t spec attua [`ion<T>>,
       y].
///
pred[`ion<T>>,
       y]: find
 ion<T>>,
       / # E
pre
pred```
    //////
predI   this uird`f::Item>Ext
  `/** iy`rr d th:
///
pred`->     ///
    /// let a = [0, 3,omicUsize,mew; ///
predstruct Bl   Holeelf        mass(1.aluese    } ///
pred
   <Tptnd_a> f::Item>Ext
  <T>l** iBl   Holeelf         ->());ext
  <ISe&m th)
    p));
   pt  
e work
    / op/reI = Self::Item>,
    {
        T>
e work
 {
e work
    /, 0]pc_fuse(t()
));
   m /// Searches f;)e work
    /y(is_  ith+=1
));
   m/suso() *`* m::alue_oin:<T>fn;         }e    } ///
pred, 0]m thbht()Bl   Holeel mass(10 };     bh.());ext
  
 i32   /00
!(ine[0, 1, 2, 9,bh.mass, 4/0032.predbh.());ext
  
 i64   /32.ine[0, 1, 2, 9,bh.mass, 4/8032.pred`-> pubifind
 f::Item>Ext
  <T>
Item) -> beSome::ne{r over thExt
  ninnhen secuce due to:/sert_`fi3
    //eoy this padrawn 4, 0, 23 attue tohe given
    /// p`());
   `.de didn't use `pa```
    /// use rayon::prelude::*;
    ///
    /// let a = [0, 12, 3, 4, 0, 23, 0]m thfoci 1foc!/]2..2048)
 focm());ext
  
   5
2..2048)
 focm());ext
  
.int5
    //());
    /     ci| ie* i)q!(&chaine[0, 1, 2, 9,foc, / ```
    3t_4selet1t_4se9,a16]rial(5), 12 -> PanicFu());ext
  <ISe&m th)
    p));
   pt  
rallelIterator<IteI = Self::Item>,
    {
        T>;
n p gro`f::Item>DindnFull` c `Somninghe given
    /// pue fa ov toaa uher fs, 23 attua :/sert_`fi3
    /n tduced
 es tothehort-capacity.
///
predT th// `ichsa ` podexa wi d t educee    this d[`ion<T>>,DindnR ng/`]
pred
n seadin op/rey`reducedindn fuucee
    `());dindn(..)`s
///
pred[`ion<T>>,DindnR ng/`]: find
 ion<T>>,DindnR ng// # E
pubifind
 f::Item>DindnFullnter.fetch_Titsdindned
 he given
    /// pu thtesat wpts to c `Somd.tch fiteraI   :tion<T>>,
               Chain::new(;me** item Titst thtadtor maicate asshe given
    /// pwia usion, a.
    /// ld()`] fusu"fly/tits inp/nce  Self::Item>,
    {
n::new`.tch fiteraI  mSome::;me** item Rast** n sdindned
 he given
    /// prs itnnh/s uru :/sert_`fi.
    ///
    /// W /// fule
    ///edidroopedolaa uher fsa ` remov[a, e thesfactually matt    /// pwadicatefuucee:/nsum dthe f fule
    ///edileak[a, f th/
    /::*;
    //uird`size,mew::f tgee fiit/i fun mpl is nyssorreadsher fha ` remov[a not all parallel ```
    /// use rayon::prelude::*;
    /// use std::sync::atomic::{AtomicUsize,c/sert_`fis::{BenaraHeap, HashSet}!(&chained[..], &[er()
quaris: HashSetli32ct()
    //     c asse* x)f/ssert_eq!(&chained[..], &[er()m thheap:/BenaraHeaplect()
quaris.
    ///spiedf)m/ssert_eq!(&chaine[0, 1, 2, 9,r **s        e fneapfha ` dindnut dn 0r //rarta
    r **s        neap.());dindn(/e some work
    /   compa c as0, 1, 9,
quaris. manducs(x))/e some work
    / /suso(),e some work
 
quaris.le fn      e woqoad(Ordering::SeqCneap.eat    /()qoad(Ordering::SeqCneap.capacityfn >=n
quaris.le fnrial(5), 12 -> PanicFu());dindn(
    wherChain::ner;
n p gro`f::Item>DindnR ng/` c `Somninghe given
    /// pue fa ov toa]. ng/i other fs, 23 attua :/sert_`fi3
    /n tduced
 es tothehort-capacity.
///
predT th// `ichsa ` catepodexa wi sel     this d[`ion<T>>,DindnFull`]d
n seads
///
pred[`ion<T>>,DindnFull`]: find
 ion<T>>,DindnFull/ # E
pubifind
 f::Item>DindnR ng/<Idxt().alue>edicatetch_Titsdindned
 he given
    /// pu thtesat wpts to c `Somd.tch fiteraI   :tion<T>>,
               Chain::new(;me** item Titst thtadtor maicate asshe given
    /// pwia usion, a.
    /// ld()`] fusu"fly/tits inp/nce  Self::Item>,
    {
n::new`.tch fiteraI  mSome::;me** item Rast** n sdindned
 he given
    /// prs itn]. ng/i otctu :/sert_`fi.
    ///
    /// W /// fule
    ///edidroopedolaa uher fstossibl. ng/ia ` remov[a, e thally matt  f fule
    ///wadicatefuucee:/nsum dthe f fule
    ///edileak[a, f ton functiex    / //uird`size,mew::f tgee fiit/i fun mpl is nyssorreadsher fha `tics of [remov[a not all parallel ```
    /// use rayon::prelude::*;
    /// use std::sync::atomic::{Atd[..], &[er()
quaris: colli32ct()
    //     c asse* x)f/ssert_eq!(&chained[..], &[pr   ln!("R ng/Full"); 4, 0, 23, 0]m thfoci 1
quaris.     fnoad(Ordering::SeqCfocm());dindn(..)e some work
    /).p_eq(
quaris.());
    ///spiedf))noad(Ordering::SeqCfocmeat    /()qoad(Ordering::SeqCfocmcapacityfn >=n
quaris.le fnrial(5), 1d[..], &[pr   ln!("R ng/Fatt"); 4, 0, 23, 0]m thfoci 1
quaris.     fnoad(Ordering::SeqCfocm());dindn(5..)e some work
    /).p_eq(
quaris[5..].());
    ///spiedf))noad(Ordering::Se2, 9,&foc[..], &
quaris[nt5]qoad(Ordering::SeqCfocmcapacityfn >=n
quaris.le fnrial(5), 1d[..], &[pr   ln!("R ng/To"); 4, 0, 23, 0]m thfoci 1
quaris.     fnoad(Ordering::SeqCfocm());dindn(..5)e some work
    /).p_eq(
quaris[nt5].());
    ///spiedf))noad(Ordering::Se2, 9,&foc[..], &
quaris[5..]qoad(Ordering::SeqCfocmcapacityfn >=n
quaris.le fnrial(5), 1d[..], &[pr   ln!("R ng/ToIncl//uve"); 4, 0, 23, 0]m thfoci 1
quaris.     fnoad(Ordering::SeqCfocm());dindn(..=5)e some work
    /).p_eq(
quaris[nt=5].());
    ///spiedf))noad(Ordering::Se2, 9,&foc[..], &
quaris[6..]qoad(Ordering::SeqCfocmcapacityfn >=n
quaris.le fnrial(5), 1d[..], &[pr   ln!("R ng/"); 4, 0, 23, 0]m thfoci 1
quaris.     fnoad(Ordering::SeqCfocm());dindn(3..7)e some work
    /).p_eq(
quaris[3..7].());
    ///spiedf))noad(Ordering::Se2, 9,&foc[..3], &
quaris[nt3]noad(Ordering::Se2, 9,&foc[3..], &
quaris[7..]qoad(Ordering::SeqCfocmcapacityfn >=n
quaris.le fnrial(5), 1d[..], &[pr   ln!("R ng/Incl//uve"); 4, 0, 23, 0]m thfoci 1
quaris.     fnoad(Ordering::SeqCfocm());dindn(3..=7)e some work
    /).p_eq(
quaris[3..=7].());
    ///spiedf))noad(Ordering::Se2, 9,&foc[..3], &
quaris[nt3]noad(Ordering::Se2, 9,&foc[3..], &
quaris[8..]qoad(Ordering::SeqCfocmcapacityfn >=n
quaris.le fnrial(5), 12 -> PanicFu());dindn<R: R ng/Bmples<Idx(Self, C:. ng/: R wherChain::ner;
n p groWe hid/ list`Tr/`teind
 dn 0[pr vSoma (dulhway as 'sein th* aqttemsto a
predsta wi      i otctu  secdard librart'se`Tr/`teind
way ay 0]unsta wi.
 (d[pr vSomadicatemicUsize,c/nv. tn::nfaa s wi;icatemicUsize,ops::CmanrolFlow::{lf, C:B `S , C/nny mo};icatemicUsize,task::Psse;me** item C    i ot`size,ops::Tr/`.de didn't use `pan   this uirdre/ aeind
 ddicatep. mitomd3outsid/  ot`use s`.de dipubifind
 Tr/elf)
    }
pr vSom_decl! {te).find_aniteraOT: Cl;
.find_aniteraResidu"f;
ol) -> bool  att/oT: Cl(oT: Cl:rChain:OT: Cl wherChai;
ol) -> bool  att/residu"f(residu"f:rChain:Residu"f wherChai;
ol) -> bool branch(
    wherCmanrolFlow<Chain:Residu"f,rChain:OT: Cl>!(&chan predi
   <B, C> Tr/ef thCmanrolFlow<B, C> lf)
    }
pr vSom_
   ! {te).find_aniteraOT: Cli 1C;
.find_aniteraResidu"fi 1CmanrolFlow<B, :nfaa s wi>;
ol) -> bool  att/oT: Cl(oT: Cl:rChain:OT: Cl wherChai

        self.C/nny mo(oT: Cl)p(predicate).find_anol  att/residu"f(residu"f:rChain:Residu"f wherChai

        self.      residu"f

        self.   /B `S (b) =>/B `S (b),        self.   /C/nny mo(_) =>/unr// sa wi!fn         self.}p(predicate).find_anol branch(
    wherCmanrolFlow<Chain:Residu"f,rChain:OT: Cl>

        self.      shai

        self.   /C/nny mo(c) =>/C/nny mo(c),        self.   /B `S (b) =>/B `S (B `S (b)n         self.}p(predicate&chan predi
   <T> Tr/ef the
     T> lf)
    }
pr vSom_
   ! {te).find_aniteraOT: Cli 1T;
.find_aniteraResidu"fi 1e
     :nfaa s wi>;
ol) -> bool  att/oT: Cl(oT: Cl:rChain:OT: Cl wherChai

        self.  /// T: Cl)p(predicate).find_anol  att/residu"f(residu"f:rChain:Residu"f wherChai

        self.      residu"f

        self.   /N seq >/N se,        self.   /  ///_) =>/unr// sa wi!fn         self.}p(predicate).find_anol branch(
    wherCmanrolFlow<Chain:Residu"f,rChain:OT: Cl>

        self.      shai

        self.   /  ///c) =>/C/nny mo(c),        self.   /N seq >/B `S (Ne_s_         self.}p(predicate&chan predi
   <T, E> Tr/ef thRe    <T, E> lf)
    }
pr vSom_
   ! {te).find_aniteraOT: Cli 1T;
.find_aniteraResidu"fi 1Re    <:nfaa s wi, E>;
ol) -> bool  att/oT: Cl(oT: Cl:rChain:OT: Cl wherChai

        self.Ok/ T: Cl)p(predicate).find_anol  att/residu"f(residu"f:rChain:Residu"f wherChai

        self.      residu"f

        self.   /Err(e) =>/Err(e),        self.   /Ok/_) =>/unr// sa wi!fn         self.}p(predicate).find_anol branch(
    wherCmanrolFlow<Chain:Residu"f,rChain:OT: Cl>

        self.      shai

        self.   /Ok/c) =>/C/nny mo(c),        self.   /Err(e) =>/B `S (Err(e)_         self.}p(predicate&chan predi
   <T, E> Tr/ef thPsse<Re    <T, E>> lf)
    }
pr vSom_
   ! {te).find_aniteraOT: Cli 1Psse<T>;
.find_aniteraResidu"fi 1Re    <:nfaa s wi, E>;
ol) -> bool  att/oT: Cl(oT: Cl:rChain:OT: Cl wherChai

        self.oT: Cl     Ok)p(predicate).find_anol  att/residu"f(residu"f:rChain:Residu"f wherChai

        self.      residu"f

        self.   /Err(e) =>/Pssen:Ready(Err(e)_         self.   /Ok/_) =>/unr// sa wi!fn         self.}p(predicate).find_anol branch(
    wherCmanrolFlow<Chain:Residu"f,rChain:OT: Cl>

        self.      shai

        self.   /Pssen:Penduird=>/C/nny mo(Pssen:Penduir_         self.   /Pssen:Ready(Ok/c))d=>/C/nny mo(Pssen:Ready(c)_         self.   /Pssen:Ready(Err(e)_ =>/B `S (Err(e)_         self.}p(predicate&chan predi
   <T, E> Tr/ef thPsse<e
     Re    <T, E>>> lf)
    }
pr vSom_
   ! {te).find_aniteraOT: Cli 1Psse<e
     T>>;
.find_aniteraResidu"fi 1Re    <:nfaa s wi, E>;
ol) -> bool  att/oT: Cl(oT: Cl:rChain:OT: Cl wherChai

        self.      oT: Cl

        self.   /Pssen:Ready(o) =>/Pssen:Ready(o     Ok)_         self.   /Pssen:Penduird=>/Pssen:Penduir         self.}p(predicate).find_anol  att/residu"f(residu"f:rChain:Residu"f wherChai

        self.      residu"f

        self.   /Err(e) =>/Pssen:Ready(  ///Err(e)__         self.   /Ok/_) =>/unr// sa wi!fn         self.}p(predicate).find_anol branch(
    wherCmanrolFlow<Chain:Residu"f,rChain:OT: Cl>

        self.      shai

        self.   /Pssen:Penduird=>/C/nny mo(Pssen:Penduir_         self.   /Pssen:Ready(Ne_s_d=>/C/nny mo(Pssen:Ready(Ne_s__         self.   /Pssen:Ready(  ////k/c))_d=>/C/nny mo(Pssen:Ready(  ///c)__         self.   /Pssen:Ready(  ///Err(e)__ =>/B `S (Err(e)_       