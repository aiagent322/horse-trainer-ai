//! Building blocks for deserializing basic values using the `IntoDeserializer`
//! trait.
//!
//! ```edition2021
//! use serde::de::{value, Deserialize, IntoDeserializer};
//! use serde_derive::Deserialize;
//! use std::str::FromStr;
//!
//! #[derive(Deserialize)]
//! enum Setting {
//!     On,
//!     Off,
//! }
//!
//! impl FromStr for Setting {
//!     type Err = value::Error;
//!
//!     fn from_str(s: &str) -> Result<Self, Self::Err> {
//!         Self::deserialize(s.into_deserializer())
//!     }
//! }
//! ```

use crate::lib::*;

use self::private::{First, Second};
use crate::de::{self, size_hint, Deserializer, Expected, IntoDeserializer, SeqAccess, Visitor};
use crate::ser;

////////////////////////////////////////////////////////////////////////////////

// For structs that contain a PhantomData. We do not want the trait
// bound `E: Clone` inferred by derive(Clone).
macro_rules! impl_copy_clone {
    ($ty:ident $(<$lifetime:tt>)*) => {
        impl<$($lifetime,)* E> Copy for $ty<$($lifetime,)* E> {}

        impl<$($lifetime,)* E> Clone for $ty<$($lifetime,)* E> {
            fn clone(&self) -> Self {
                *self
            }
        }
    };
}

////////////////////////////////////////////////////////////////////////////////

/// A minimal representation of all possible errors that can occur using the
/// `IntoDeserializer` trait.
#[derive(Clone, PartialEq)]
pub struct Error {
    err: ErrorImpl,
}

#[cfg(any(feature = "std", feature = "alloc"))]
type ErrorImpl = Box<str>;
#[cfg(not(any(feature = "std", feature = "alloc")))]
type ErrorImpl = ();

impl de::Error for Error {
    #[cfg(any(feature = "std", feature = "alloc"))]
    #[cold]
    fn custom<T>(msg: T) -> Self
    where
        T: Display,
    {
        Error {
            err: msg.to_string().into_boxed_str(),
        }
    }

    #[cfg(not(any(feature = "std", feature = "alloc")))]
    #[cold]
    fn custom<T>(msg: T) -> Self
    where
        T: Display,
    {
        let _ = msg;
        Error { err: () }
    }
}

impl ser::Error for Error {
    #[cold]
    fn custom<T>(msg: T) -> Self
    where
        T: Display,
    {
        de::Error::custom(msg)
    }
}

impl Display for Error {
    #[cfg(any(feature = "std", feature = "alloc"))]
    fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
        formatter.write_str(&self.err)
    }

    #[cfg(not(any(feature = "std", feature = "alloc")))]
    fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
        formatter.write_str("Serde deserialization error")
    }
}

impl Debug for Error {
    fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
        let mut debug = formatter.debug_tuple("Error");
        #[cfg(any(feature = "std", feature = "alloc"))]
        debug.field(&self.err);
        debug.finish()
    }
}

#[cfg(feature = "std")]
impl error::Error for Error {
    fn description(&self) -> &str {
        &self.err
    }
}

////////////////////////////////////////////////////////////////////////////////

impl<'de, E> IntoDeserializer<'de, E> for ()
where
    E: de::Error,
{
    type Deserializer = UnitDeserializer<E>;

    fn into_deserializer(self) -> UnitDeserializer<E> {
        UnitDeserializer::new()
    }
}

/// A deserializer holding a `()`.
pub struct UnitDeserializer<E> {
    marker: PhantomData<E>,
}

impl_copy_clone!(UnitDeserializer);

impl<E> UnitDeserializer<E> {
    #[allow(missing_docs)]
    pub fn new() -> Self {
        UnitDeserializer {
            marker: PhantomData,
        }
    }
}

impl<'de, E> de::Deserializer<'de> for UnitDeserializer<E>
where
    E: de::Error,
{
    type Error = E;

    forward_to_deserialize_any! {
        bool i8 i16 i32 i64 i128 u8 u16 u32 u64 u128 f32 f64 char str string
        bytes byte_buf unit unit_struct newtype_struct seq tuple tuple_struct
        map struct enum identifier ignored_any
    }

    fn deserialize_any<V>(self, visitor: V) -> Result<V::Value, Self::Error>
    where
        V: de::Visitor<'de>,
    {
        visitor.visit_unit()
    }

    fn deserialize_option<V>(self, visitor: V) -> Result<V::Value, Self::Error>
    where
        V: de::Visitor<'de>,
    {
        visitor.visit_none()
    }
}

impl<E> Debug for UnitDeserializer<E> {
    fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
        formatter.debug_struct("UnitDeserializer").finish()
    }
}

////////////////////////////////////////////////////////////////////////////////

/// A deserializer that cannot be instantiated.
#[cfg(feature = "unstable")]
pub struct NeverDeserializer<E> {
    never: !,
    marker: PhantomData<E>,
}

#[cfg(feature = "unstable")]
impl<'de, E> IntoDeserializer<'de, E> for !
where
    E: de::Error,
{
    type Deserializer = NeverDeserializer<E>;

    fn into_deserializer(self) -> Self::Deserializer {
        self
    }
}

#[cfg(feature = "unstable")]
impl<'de, E> de::Deserializer<'de> for NeverDeserializer<E>
where
    E: de::Error,
{
    type Error = E;

    fn deserialize_any<V>(self, _visitor: V) -> Result<V::Value, Self::Error>
    where
        V: de::Visitor<'de>,
    {
        self.never
    }

    forward_to_deserialize_any! {
        bool i8 i16 i32 i64 i128 u8 u16 u32 u64 u128 f32 f64 char str string
        bytes byte_buf option unit unit_struct newtype_struct seq tuple
        tuple_struct map struct enum identifier ignored_any
    }
}

////////////////////////////////////////////////////////////////////////////////

macro_rules! primitive_deserializer {
    ($ty:ty, $doc:tt, $name:ident, $method:ident $($cast:tt)*) => {
        #[doc = "A deserializer holding"]
        #[doc = $doc]
        pub struct $name<E> {
            value: $ty,
            marker: PhantomData<E>
        }

        impl_copy_clone!($name);

        impl<'de, E> IntoDeserializer<'de, E> for $ty
        where
            E: de::Error,
        {
            type Deserializer = $name<E>;

            fn into_deserializer(self) -> $name<E> {
                $name::new(self)
            }
        }

        impl<E> $name<E> {
            #[allow(missing_docs)]
            pub fn new(value: $ty) -> Self {
                $name {
                    value,
                    marker: PhantomData,
                }
            }
        }

        impl<'de, E> de::Deserializer<'de> for $name<E>
        where
            E: de::Error,
        {
            type Error = E;

            forward_to_deserialize_any! {
                bool i8 i16 i32 i64 i128 u8 u16 u32 u64 u128 f32 f64 char str
                string bytes byte_buf option unit unit_struct newtype_struct seq
                tuple tuple_struct map struct enum identifier ignored_any
            }

            fn deserialize_any<V>(self, visitor: V) -> Result<V::Value, Self::Error>
            where
                V: de::Visitor<'de>,
            {
                visitor.$method(self.value $($cast)*)
            }
        }

        impl<E> Debug for $name<E> {
            fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
                formatter
                    .debug_struct(stringify!($name))
                    .field("value", &self.value)
                    .finish()
            }
        }
    }
}

primitive_deserializer!(bool, "a `bool`.", BoolDeserializer, visit_bool);
primitive_deserializer!(i8, "an `i8`.", I8Deserializer, visit_i8);
primitive_deserializer!(i16, "an `i16`.", I16Deserializer, visit_i16);
primitive_deserializer!(i32, "an `i32`.", I32Deserializer, visit_i32);
primitive_deserializer!(i64, "an `i64`.", I64Deserializer, visit_i64);
primitive_deserializer!(i128, "an `i128`.", I128Deserializer, visit_i128);
primitive_deserializer!(isize, "an `isize`.", IsizeDeserializer, visit_i64 as i64);
primitive_deserializer!(u8, "a `u8`.", U8Deserializer, visit_u8);
primitive_deserializer!(u16, "a `u16`.", U16Deserializer, visit_u16);
primitive_deserializer!(u64, "a `u64`.", U64Deserializer, visit_u64);
primitive_deserializer!(u128, "a `u128`.", U128Deserializer, visit_u128);
primitive_deserializer!(usize, "a `usize`.", UsizeDeserializer, visit_u64 as u64);
primitive_deserializer!(f32, "an `f32`.", F32Deserializer, visit_f32);
primitive_deserializer!(f64, "an `f64`.", Fdeserializer!(u64, "a        /////////////////a///ure tive_desesizer!(i64, "an `i64`.", I64Deserializer, visit_i64f);izer holding a `()`.
pub struct ualizDeserializer<visit_f32);
pr  fn fmt(&elf {
 ual,ntomData<E>,
}

impl_copy_clone!(UnitDeserializer)visit_f32);
pr, T> Deserializer<'de, E> for $ty
        wherual::Error,
{
    type Deserializer = UnitDeserializer<visit_f32);
pr  feserializer(self) -> UnitDeserializer<visit_f32);
pr  fn fmt(&izer visit_f32);
pr        }
      ug for UnitDe<visit_f32);
pr  fn fmt(&docs)]
    pub fn new() -> Self {
    elf {
 ual    UnitDeserializer visit_f32);
pralue: $ty,
         ,ker: PhantomData,
        }
    }
}

impl<'de, E> de::Deserializer<'de> for UnitDeserializer<visit_f32);
pr  f::Error,
{
    type Error = E;

    forward_to_deserialize_any! {
        bool i8 i16 i32 i64 i128 u8 u16 u32 u64 u128 f32 f64 char str string
        bytes byte_buf unit unit_struct_struct newtype_struct seq tuple
        tuple_struct map struct enum identifier ed_any
    }

    fn deserialize_any<V>(self, visitor: V) -> Result<V::Value, Self::Error>
    where
        V: de::Visitor<'de>,
    {
        visitor.visit_unit()
    }

   32(                alize_any<V>(self, visignof,
        fields: &'static     &selfr: V,
    )   seltatic str],
        visitor: V,
    ) -> Result<V::Value, Self::Error>
    where
        V: Visitor<'de>;
}
,
    {
        visitor.visit_un     Err    ;.visit_un     Err)   selt;.visit_unit()
    }

  igno   }
      ug for Unirializer<'de Sized {
    //lizer<visit_f32);
pr  f::Error,
{
    type Error = E;

    forward_to_: VariantAccess<rd_ Second};").fOnly  feserializeself, seed: T) -> Result<T::Value, Self::(Tariant), Self::Error>
    where
        V: DeserializeSeT:r<'de> for UnitD
        (**self).next_en     to_deserializ
    ide( Second};ype_sonlyE> Debug for UnitDeserializer<visit_f32);
pr  fn fmt(&rmatter: &mut fmt::Formatter) -> fmt::Result {
        formatter.debug_struct("U
ug_struct(stringify!($name"<visit_f32);
pr"        }
    &self.value)
                    .finish(}

////////////////////////////////////////////////////////////////////////////////

/// A deserializer that cannot be ipub struct selfizDeserializerSt
where
    E:  T:  fn fmt(&elf {
 l<'aelfr: V,
ata<E>,
}

impl_copy_clone!(UnitDeserializerSt
where
    E:     , T> Deseriali T:  fn<'de, E> for $ty
        wherl<'aelf::Error,
{
    type Deserializer = UnitDeserializerSt
where
    E:  T:  feserializer(self) -> Self::Deserializet
where
    E:  T:  fn fmt(&alizet
where
    E:        }
      ug for Uni T:  fnet
where
    E:  T:  fn fmt(&docs)]
    pub fn new() -> Self {
    elf {
 l<'aelf    UnitDeserializeret
where
    E:alue: $ty,
         ,ker: PhantomData,
        }
    }
}

impl<'de, E> de::Deseriali T:  fn<'de> for UnitDeserializeret
where
    E:  T:  f::Error,
{
    type Error = E;

    fn deserialize_any<V>(self, _visitor: V) -> esult<V::Value, Self::Error>
    where
        V: de::Visitor<'de>,
    {
        visitor.visit_unit()
    }

  Resul               alize_any<V>(self, visignof,
        fields: &'static     &selfr: V,
    )   seltatic str],
        visitor: V,
    ) -> Result<V::Value, Self::Error>
    where
        V: Visitor<'de>;
}
,
    {
        visitor.visit_un     Err    ;.visit_un     Err)   selt;.visit_unit()
    }

  igno   }
      ugdeserialize_any! {
        bool i8 i16 i32 i64 i128 u8 u16 u32 u64 u128 f32 f64 char str string
        bytes byte_buf unit unit_struct_struct newtype_struct seq tuple
        tuple_struct map struct enum identifier ed_any
    }

    fn deserialde::Deseriali T:  fn<'de Sized {
    //lizeret
where
    E:  T:  f::Error,
{
    type Error = E;

    fn deserial: VariantAccess<rd_ Second};").fOnly  feserializeself, seed: T) -> Result<T::Value, Self::(Tariant), Self::Error>
    where
        V: DeserializeSeT:r<'de> for UnitD
        (**self).next_en     to_deserializ
    ide( Second};ype_sonlyE> Debug for Uni T:  fnserializeret
where
    E:  T:  fn fmt(&rmatter: &mut fmt::Formatter) -> fmt::Result {
        formatter.debug_struct("U
ug_struct(stringify!($name"et
where
    E:"        }
    &self.value)
                    .finish(}

////////////////////////////////////////////////////////////////////////////////

/// A deserializer that cannot be ipub struct selfialue.
   that maytiializean
/// r lifetimes] for zDeserializerB resultSt
where
    E:    :  fn fmt(&elf {
 l<deaelfr: V,
ata<E>,
}

impl_copy_clone!(UnitDeserializerB resultSt
where
    E:    >, T> DeserializerB resultSt
where
    E:    :  fn fmt(& valueseri
  eq he resultit cannot be ing `Desergivenbytes b.) -> Self {
    elf {
 l<deaelf {
  B resultSt
where
    E:    :  fn fmt(&&&&&B resultSt
where
    E:alue: $ty,
         ,ker: PhantomData,
        }
    }
}

impl<'de, E> de::Deserializer<'de> for UnitDeserializerB resultSt
where
    E:    :  f::Error,
{
    type Error = E;

    fn deserialize_any<V>(self, _visitor: V) -> esult<V::Value, Self::Error>
    where
        V: de::Visitor<'de>,
    {
        visitor.visit_unit()
    }

  e result Resul               alize_any<V>(self, visignof,
        fields: &'static     &selfr: V,
    )   seltatic str],
        visitor: V,
    ) -> Result<V::Value, Self::Error>
    where
        V: Visitor<'de>;
}
,
    {
        visitor.visit_un     Err    ;.visit_un     Err)   selt;.visit_unit()
    }

  igno   }
      ugdeserialize_any! {
        bool i8 i16 i32 i64 i128 u8 u16 u32 u64 u128 f32 f64 char str string
        bytes byte_buf unit unit_struct_struct newtype_struct seq tuple
        tuple_struct map struct enum identifier ed_any
    }

    fn deserialde::Deseriali fn<'de Sized {
    //lizerB resultSt
where
    E:    :  f::Error,
{
    type Error = E;

    fn deserial: VariantAccess<rd_ Second};").fOnly  feserializeself, seed: T) -> Result<T::Value, Self::(Tariant), Self::Error>
    where
        V: DeserializeSeT:r<'de> for UnitD
        (**self).next_en     to_deserializ
    ide( Second};ype_sonlyE> Debug for Uni iali fnserializerB resultSt
where
    E:    :  fn fmt(&rmatter: &mut fmt::Formatter) -> fmt::Result {
        formatter.debug_struct("U
ug_struct(stringify!($name"B resultSt
where
    E:"        }
    &self.value)
                    .finish(}

////////////////////////////////////////////////////////////////////////////////

/// A deserializer that cannot be ipub struct Stes b`.re = "std", feature = "alloc"))]
pub fn cautious<ElemializerSt
s bsit_f32);
pr  fn fmt(&elf {
 St
s bantomData<E>,
}

#[cfg(feature = "unstatd", feature = "alloc"))]
pub fn cautious<r UnitDe$lifetime,St
s bsit_f32);
pr  fn fmt(&-> Self {
                *self
  St
s bsit_f32);
pralue: $ty,
                     .Self {),ker: PhantomData,
        }
    }
}

impl<'de, E> de:"unstatd", feature = "alloc"))]
pub fn cautious<r Unirializer<'de, E> for $ty
        wherSt
s b::Error,
{
    type Deserializer = UnitDeserializerSt
s bsit_f32);
pr  feserializer(self) -> Self::Deserializet
s bsit_f32);
pr  fn fmt(&f
  St
s bsit_f32);
pr        }
      ug fo"unstatd", feature = "alloc"))]
pub fn cautious<r UnitDeet
s bsit_f32);
pr  fn fmt(&docs)]
    pub fn new() -> Self {
    elf {
 et
s b            *self
  St
s bsit_f32);
pralue: $ty,
         ,ker: PhantomData,
        }
    }
}

impl<'de, E> de:"unstatd", feature = "alloc"))]
pub fn cautious<r Unirializer<'de> for UnitDeserializeret
s bsit_f32);
pr  f::Error,
{
    type Error = E;

    fn deserialize_any<V>(self, _visitor: V) -> esult<V::Value, Self::Error>
    where
        V: de::Visitor<'de>,
    {
        visitor.visit_unit()
    }

  Res_strl               alize_any<V>(self, visignof,
        fields: &'static     &selfr: V,
    )   seltatic str],
        visitor: V,
    ) -> Result<V::Value, Self::Error>
    where
        V: Visitor<'de>;
}
,
    {
        visitor.visit_un     Err    ;.visit_un     Err)   selt;.visit_unit()
    }

  igno   }
      ugdeserialize_any! {
        bool i8 i16 i32 i64 i128 u8 u16 u32 u64 u128 f32 f64 char str string
        bytes byte_buf unit unit_struct_struct newtype_struct seq tuple
        tuple_struct map struct enum identifier ed_any
    }

    fn deserialde:"unstatd", feature = "alloc"))]
pub fn cautious<r Unirializer<'de Sized {
    //lizeret
s bsit_f32);
pr  f::Error,
{
    type Error = E;

    fn deserial: VariantAccess<rd_ Second};").fOnly  feserializeself, seed: T) -> Result<T::Value, Self::(Tariant), Self::Error>
    where
        V: DeserializeSeT:r<'de> for UnitD
        (**self).next_en     to_deserializ
    ide( Second};ype_sonlyE> Debug fo"unstatd", feature = "alloc"))]
pub fn cautious<r UnitDeserializeret
s bsit_f32);
pr  fn fmt(&-> tter: &mut fmt::Formatter) -> fmt::Result {
        formatter.debug_struct("U
ug_struct(stringify!($name"et
s bsit_f32);
pr"        }
    &self.value)
                    .finish(}

////////////////////////////////////////////////////////////////////////////////

/// A deserializer that cannot be ipub struct Cow(any(`.re = "std", feature = "alloc"))]
pub fn cautious<ElemializerCowSt
where
    E:  T:  fn fmt(&elf {
 Cow( T: any(antomData<E>,
}

#[cfg(feature = "unstatd", feature = "alloc"))]
pub fn cautious<r Uni T:  fn$lifetime,CowSt
where
    E:  T:  fn fmt(&-> Self {
                *self
  CowSt
where
    E:alue: $ty,
                     .Self {),ker: PhantomData,
        }
    }
}

impl<'de, E> de:"unstatd", feature = "alloc"))]
pub fn cautious<r Uniriali T:  fn<'de, E> for $ty
        wherCow( T: any(::Error,
{
    type Deserializer = UnitDeserializerCowSt
where
    E:  T:  feserializer(self) -> Self::DeserializCowSt
where
    E:  T:  fn fmt(&f
  CowSt
where
    E:        }
      ug fo"unstatd", feature = "alloc"))]
pub fn cautious<r Uni T:  fn$owSt
where
    E:  T:  fn fmt(&docs)]
    pub fn new() -> Self {
    elf {
 Cow( T: any(            *self
  CowSt
where
    E:alue: $ty,
         ,ker: PhantomData,
        }
    }
}

impl<'de, E> de:"unstatd", feature = "alloc"))]
pub fn cautious<r Uniriali T:  fn<'de> for UnitDeserializer$owSt
where
    E:  T:  f::Error,
{
    type Error = E;

    fn deserialize_any<V>(self, _visitor: V) -> esult<V::Value, Self::Error>
    where
        V: de::Visitor<'de>,
    {
        visitor.visit_un.len() {
  
     lue: $ty,
    $ow::B resulte))
   [doc it()
    }

  Resul)
   [,ue: $ty,
    $ow::Ownlte))
   [doc it()
    }

  Res_strl)
   [,ue: $ty,
}     alize_any<V>(self, visignof,
        fields: &'static     &selfr: V,
    )   seltatic str],
        visitor: V,
    ) -> Result<V::Value, Self::Error>
    where
        V: Visitor<'de>;
}
,
    {
        visitor.visit_un     Err    ;.visit_un     Err)   selt;.visit_unit()
    }

  igno   }
      ugdeserialize_any! {
        bool i8 i16 i32 i64 i128 u8 u16 u32 u64 u128 f32 f64 char str string
        bytes byte_buf unit unit_struct_struct newtype_struct seq tuple
        tuple_struct map struct enum identifier ed_any
    }

    fn deserialde:"unstatd", feature = "alloc"))]
pub fn cautious<r Uniriali T:  fn<'de Sized {
    //lizer$owSt
where
    E:  T:  f::Error,
{
    type Error = E;

    fn deserial: VariantAccess<rd_ Second};").fOnly  feserializeself, seed: T) -> Result<T::Value, Self::(Tariant), Self::Error>
    where
        V: DeserializeSeT:r<'de> for UnitD
        (**self).next_en     to_deserializ
    ide( Second};ype_sonlyE> Debug fo"unstatd", feature = "alloc"))]
pub fn cautious<r Uni T:  fnserializerCowSt
where
    E:  T:  fn fmt(&-> tter: &mut fmt::Formatter) -> fmt::Result {
        formatter.debug_struct("U
ug_struct(stringify!($name"CowSt
where
    E:"        }
    &self.value)
                    .finish(}

////////////////////////////////////////////////////////////////////////////////

/// A deserializer that cannot be ipub struct s[u8]`. Alwaysze_in_p[`  {
   :: }

  eit u`]zDeserializerBit uwhere
    E:  T:  fn fmt(&elf {
 l<'a[u8]r: V,
ata<E>,
}

impl_copy_clone!(Uni  T:  fnBit uwhere
    E:  T:  fn fmt(& valueseri
  eq ht cannot be ing `Desergivenbeit u.) -> Self {
    elf {
 l<'a[u8]            *self
  Bit uwhere
    E:alue: $ty,
         ,ker: PhantomData,
        }
    }
}

impl<'de, E> de::DestDeserializerBit uwhere
    E:  T , T> Deseriali T:  fn<'de, E> for $ty
        wherl<'a[u8]::Error,
{
    type Deserializer = UnitDeserializerBit uwhere
    E:  T:  feserializer(self) -> Self::DeserializBit uwhere
    E:  T:  fn fmt(&f
  Bit uwhere
    E:        }
      ug for Uni iali T:  fn> for UnitDeserializerBit uwhere
    E:  T:  f::Error,
{
    type Error = E;

    fn deserialize_any<V>(self, _visitor: V) -> esult<V::Value, Self::Error>
    where
        V: de::Visitor<'de>  {
        visitor.visit_unit()
    }

  eit url               alize_analize_any! {
        bool i8 i16 i32 i64 i128 u8 u16 u32 u64 u128 f32 f64 char str string
        bytes byte_buf option unit unit_struct newtype_struct seq tuple
        tuple_struct map struct enum identifier ignored_any
    }
}

////////////////r Uni T:  fnserializerBit uwhere
    E:  T:  fn fmt(&rmatter: &mut fmt::Formatter) -> fmt::Result {
        formatter.debug_struct("U
ug_struct(stringify!($name"Bit uwhere
    E:"        }
    &self.value)
                    .finish(}

///////////////////that cannot be ipub struct s[u8]`alue.
   that maytiializean
/// r lifetimes] for z Alwaysze_in_p[`  {
   :: }

  e result eit u`]zDeserializerB resultBit uwhere
    E:    :  fn fmt(&elf {
 l<dea[u8]r: V,
ata<E>,
}

impl_copy_clone!(Uni  ializerB resultBit uwhere
    E:    :  fn fmt(& valueseri
  eq he resultit cannot be ing `Desergivenbe resultieit u.) -> Self {
    elf {
 l<dea[u8]            *self
  B resultBit uwhere
    E:alue: $ty,
         ,ker: PhantomData,
        }
    }
}

impl<'de, E> de::DestDeserializerB resultBit uwhere
    E:    >, T> Deserializer> for UnitDeserializerB resultBit uwhere
    E:    :  f::Error,
{
    type Error = E;

    fn deserialize_any<V>(self, _visitor: V) -> esult<V::Value, Self::Error>
    where
        V: de::Visitor<'de>  {
        visitor.visit_unit()
    }

  e result eit url               alize_analize_any! {
        bool i8 i16 i32 i64 i128 u8 u16 u32 u64 u128 f32 f64 char str string
        bytes byte_buf option unit unit_struct newtype_struct seq tuple
        tuple_struct map struct enum identifier ignored_any
    }
}

//fn deserialde::Deseriali fnserializerB resultBit uwhere
    E:    :  fn fmt(&rmatter: &mut fmt::Formatter) -> fmt::Result {
        formatter.debug_struct("U
ug_struct(stringify!($name"B resultBit uwhere
    E:"        }
    &self.value)
                    .finish(}

////////////////////////////////////////////////////////////////////////////////

/// A deserializer that cannot be instanielper of ved ex  tueser, PartialEq)]
puus<ElemializerSeqwhere
    E: I:  fn fmt(&ion<usion<u:Fuse<I visitocou>) -`.", U: V,
ata<E>,
}

impl_copy_clone!(Uni I:  fnSeqwhere
    E: I:  ferator,
{
    helper(iter.size value ializer  eq h`Seqwhere
    E: I:  f`.) -> Self {
    ion<usI            *self
  Seqwhere
    E:alue: $ty,
    ion<usion<.fuse{),ker: PhantomDcou>) -0,ker: PhantomData,
        }
    }
}

impl<'de, E> de::DeseI:  fnSeqwhere
    E: I:  ferator,
{
    helper(ite,
{
    type Error = E;
 valuhecklizerrema
//true   )
 s afelp pa pub uct Seqwhere
    E:`liz fn struct  {
   :: }

    t`.) -> Self {
end<(), Self::Error> {
  fn fmt(&f
      rema
//tru=) {
  ion<.cou>)(.finish()
 if rema
//tru==             tri!   }
        }
 cmp::min(
      data acuse c argu )
  of datagnoblp ofue   )
 s inly contaisult::den(
      data acargu )
  of datagnoblp ofue   )
 s `a`, `b`,by datawhere
    E.de::Error,
   valid_type(unexp, &"stlength( string bytes byte{
  cou>) + rema
//tr  }
            }
&serializInSeq(e{
  cou>)),ker: PhantomD
        }
 eserialde::DeserialiI: Tlizer<'de> for UnitDeserializereeqwhere
    E: I:  ferator,
{
    helper(i<helmu=)T visitoT:n<'de, E> for $ty
       ,r,
{
    type Error = E;

    fn deserialize_any<V>(self, _visitor: er) V) -> esult<V::Value, Self::Error>
    where
        V: de::Visitor<'de>,
    {
        visitor.visit_un    vseratterit()
    }

  Req(&er) V) -    }
      atter

////nd<    }
         v      alize_analize_any! {
        bool i8 i16 i32 i64 i128 u8 u16 u32 u64 u128 f32 f64 char str string
        bytes byte_buf option unit unit_struct newtype_struct seq tuple
        tuple_struct map struct enum identifier ignored_any
    }
}

//fn deserialde::DeserialiI: Tlizer<'deor};
use serializereeqwhere
    E: I:  ferator,
{
    helper(i<helmu=)T visitoT:n<'de, E> for $ty
       ,r,
{
    type Error = E;

    fn deserialize_any<next_e   )
 eed: Tr: &er) V) -> lt<T::Value, Self::    matError>
 >   where
        V: de::Visitor<'de>,
  > for UnitD
        (**self).next_en.len() {
  ion<.next         if i > 0                 tri!(write!(forme{
  cou>) += 1; tri!(write!(forme{   to_deseriali     .r())
//!     }
//! } ide(            }
    }
}

primiiiii               [,ue: $ty,
}     alize_any<#[cfg(any(
             match bounds {
 forme[cfg(any::ter: &I) ->     deion<///////////   err: erializInSeq(ch boor for Er erializ fn deerializInSeqn fmt(&rmatter: &mut fmt::Formatter) -> fmt::Result {
        formatter.debug_if       u== 1   tri!(write!(, "`{}`", alt));
  1ue   )
 ter().tueser"        }
 cmp::min(
      data, "`{}`", alt));
  {}ue   )
 s inl).tueser"}
            mpl<'de, E> de::DeseI:  fnserializereeqwhere
    E: I:  ferator,
{
    seriaor = E;
-> tter: &mut fmt::Formatter) -> fmt::Result {
        formatter.debug_struct("U
ug_struct(stringify!($name"eeqwhere
    E:"        }
    &self.vaion<         ion<//////  }
    &self.vacou>)         cou>))     .finish(}

////////////////////////////////////////////////////////////////////////////////

/// A deserializ"unstatd", feature = "alloc"))]
pub fn cautious<r UnirialiT:  fn<'de, E> for $ty
        wherVec<Deserialize<'de><'de, E> for $ty
       ,r,
{
    type Error = E;

    nitDeserializerSeqwhere
    E: > {
/ive_<'dehelper(i>::<'dehelp:  feserializer(self) -> Self::Deserializer {
        self
    }
}

#[Seqwhere
    E:        }
.r())
() {
 )eserialde:"unstatd", feature = "alloc"))]
pub fn cautious<r UnirialiT:  fn<'de, E> for $ty
        wherBTreD
 t<Deserialize<'de><'de, E> for $ty
        + Eq + Ord,r,
{
    type Error = E;

    nitDeserializerSeqwhere
    E: > {
/ive_<'dehelper(i>::<'dehelp:  feserializer(self) -> Self::Deserializer {
        self
    }
}

#[Seqwhere
    E:        }
.r())
() {
 )eserialde:"unsta]
impl error::Error foirialiT: S:  fn<'de, E> for $ty
        wherHash
 t<D: Seserialize<'de><'de, E> for $ty
        + Eq + Hash,r,
{
S: for dHasher,r,
{
    type Error = E;

    nitDeserializerSeqwhere
    E: > {
/ive_<'dehelper(i>::<'dehelp:  feserializer(self) -> Self::Deserializer {
        self
    }
}

#[Seqwhere
    E:        }
.r())
() {
 )eserialde:////////////////////////////////////////////////////////////////

/// A deserializer that cannot be ipub struct Sr};
use `, PartialEq)]
pub seriaus<ElemializerSeq;
use where
    E: Aunds {
 ).t: Alone!(Uni A>rSeq;
use where
    E: Aunds {
  value ializer  eq h`Seq;
use where
    E: Au`.) -> Self {
    ).t: A            *self
  Seq;
use where
    E: {   tu eserialde::DeserialiAer<'de> for UnitDeserializereeq;
use where
    E: Auserialize<'A:r<'deor};
use seriaor = E;

    fn deserA     fn fize_any<V>(self, _visitor: V) -> esult<V::Value, Self::Error>
    where
        V: de::Visitor<'de>,
    {
        visitor.visit_unit()
    }

  Req(e{
  Req      alize_analize_any! {
        bool i8 i16 i32 i64 i128 u8 u16 u32 u64 u128 f32 f64 char str string
        bytes byte_buf option unit unit_struct newtype_struct seq tuple
        tuple_struct map struct enum identifier ignored_any
    }
}

//fn deserial///////////////////////////////////////////////////////////////////

/// A deserializer that cannot be instanielper of ved exidezDeserializerMap, E> for $ty
     I:  ferator,
{
    helper(ite,
{
I::<elm:_ Second};Pairor = E;
ion<usion<u:Fuse<I visitoelf {
     matte::de<I::<elm> visitocou>) -`.", U: V,
=> {
    
}

impl_copyl<dea() visito Error
}

impl_copy_clone!(Uni  ialiI:  fnMap, E> for $ty
     I:  ferator,
{
    helper(ite,
{
I::<elm:_ Second};Pairor = E;
 value ializer  eq h`Map, E> for $ty
I:  f`.) -> Self {
    ion<usI            *self
  Map, E> for $tyalue: $ty,
    ion<usion<.fuse{),ker: PhantomDelf {
           PhantomDcou>) -0,ker: PhantomD=> {
    
}

impl_cop,: msg.to_string(o        }
    }
}

impl<'de, E> de::DeserialiI:  fnMap, E> for $ty
     I:  ferator,
{
    helper(ite,
{
I::<elm:_ Second};Pairor,
{
    type Error = E;
 valuhecklizerrema
//true   )
 s afelp pa pub uct Map, E> for $ty`liz fn struct  {
   :: }

  ide`.) -> Self {
end<(), Self::Error> {
  fn fmt(&f
      rema
//tru=) {
  ion<.cou>)(.finish()
 if rema
//tru==             tri!   }
        }
 cmp::min(
      data acuse c argu )
  of datagnoblp ofue   )
 s inly contaisult::den(
      data acargu )
  of datagnoblp ofue   )
 s `a`, `b`,by datawhere
    E.de::Error,
   valid_type(unexp, &"stlength( string bytes byte{
  cou>) + rema
//tr  }
            }
&serializInMap(e{
  cou>)),ker: PhantomD
        }
 eserialde::DeserialiI:  fnMap, E> for $ty
     I:  ferator,
{
    helper(ite,
{
I::<elm:_ Second};Pairor = E;
ny<next_pair(&er) V) -         mat(use c<I::<elm>rate::de<I::<elm>)>lf).next_en.len() {
  ion<.next         if i > 0     kv       tri!(write!(forme{
  cou>) += 1; tri!(write!(form      Second};Pair::split kv         }
    }
}

primiiiii                  Phan eserialde::DeserialiI:  fn<'de> for UnitDeserializerMap, E> for $ty
     I:  ferator,
{
    helper(ite,
{
I::<elm:_ Second};Pairor,
{
use c<I::<elm>e><'de, E> for $ty
       ,r,
{
te::de<I::<elm>:n<'de, E> for $ty
       ,r,
{
    type Error = E;

    fn deserialize_any<V>(self, _visitor: er) V) -> esult<V::Value, Self::Error>
    where
        V: de::Visitor<'de>,
    {
        visitor.visit_un    v     eratterit()
    }

  ide(&er) V) -    }
      atter

////nd<    }
         v          alize_any<V>(self, vis  tor: er) V) -> esult<V::Value, Self::Error>
    where
        V: de::Visitor<'de>,
    {
        visitor.visit_un    v     eratterit()
    }

  Req(&er) V) -    }
      atter

////nd<    }
         v          alize_any<V>(self, vis struor: V) -> len -`.", U esult<V::Value, Self::Error>
    where
        V: de::Visitor<'de>,
    {
        visitor.visit_un     Errlen;ver
    }

   V>(self, vis  trit()
        alize_analize_any! {
        bool i8 i16 i32 i64 i128 u8 u16 u32 u64 u128 f32 f64 char str string
        bytes byte_buf option unit unit_struct newtype_struct seq tuple
       struct enum ide
ytes byte_bier ignored_any
    }
}

//fn deserialde::DeserialiI:  fn<'deMap;
use serializerMap, E> for $ty
     I:  ferator,
{
    helper(ite,
{
I::<elm:_ Second};Pairor,
{
use c<I::<elm>e><'de, E> for $ty
       ,r,
{
te::de<I::<elm>:n<'de, E> for $ty
       ,r,
{
    type Error = E;

    fn deserialize_any<next_keyeed: T) -&er) V) -> lt<T::Talue, Self::    matTrror>
 >   where
        V: de::Visitor<'Te>,
  > for UnitD
        (**self).next_en.len() {
  next_pair(        if i > 0     (key, v    )       tri!(write!(forme{
  v     er           ; tri!(write!(forme{   to_deserialikey.r())
//!     }
//! } ide(            }
    }
}

primiiiii               [,ue: $ty,
}     alize_any<next_     eed: T) -&er) V) -> lt<T::Talue, Self::Trror>
    where
        V: de::Visitor<'Te>,
  > for UnitD
        (**self).next_en    v     er          .take(.finish()
  acPanic beca
///this indicer ofa rialinly coprogram perhe instn aninish()
  ac`a`, `b`,failurE.de::Error    v     er     .`a`, `("Map;
use     xt_     ze_inb`,beizee<next_keyg(any(feature{   to_deseriali     .r())
//!     }
//! }     alize_any<next__anryeed: T)K, T,
        fi&er) V) ->       fiklt<T::TKr: V,
    )lt<T::Tlt<V::Value, Self::    mat(TKrror>
   TError>
 )>   where
        V: de::Visitor<'TKe>,
  > for UnitD
        (**selor<'TVe>,
  > for UnitD
        (**self).next_en.len() {
  next_pair(        if i > 0     (key, v    )       tri!(write!(form    key eratterke{   to_deserialikey.r())
//!     }
//! } ; tri!(write!(form    v     eratterie{   to_deseriali     .r())
//!     }
//! } ; tri!(write!(form        (key, v    )         }
    }
}

primiiiii               [,ue: $ty,
}     alize_any<#[cfg(any(
             match bounds {
 forme[cfg(any::ter: &I) ->     deion<///////////:DeserialiI:  fn<'deor};
use serializerMap, E> for $ty
     I:  ferator,
{
    helper(ite,
{
I::<elm:_ Second};Pairor,
{
use c<I::<elm>e><'de, E> for $ty
       ,r,
{
te::de<I::<elm>:n<'de, E> for $ty
       ,r,
{
    type Error = E;

    fn deserialize_any<next_e   )
 eed: T) -&er) V) -> lt<T::Talue, Self::    matTrror>
 >   where
        V: de::Visitor<'Te>,
  > for UnitD
        (**self).next_en.len() {
  next_pair(        if i > 0     (k, v)       tri!(write!(form    d  erPair, E> for $ty(k, v,      }
     ; tri!(write!(forme{   to_deserialide} ide(            }
    }
}

primiiiii               [,ue: $ty,
}     alize_any<#[cfg(any(
             match bounds {
 forme[cfg(any::ter: &I) ->     deion<///////////valuiated.PartialEq)]
puus beca
///ofly co inferrte::de<I::<elm>:nby der./:DeserialiI:  fn$lifetime,Map, E> for $ty
     I:  ferator,
{
    helper(i +n$lifete,
{
I::<elm:_ Second};Pairor,
{
te::de<I::<elm>:nby deor = E;
ny<Self {
                *self
  Map, E> for $tyalue: $ty,
    ion<us {
  ion<.celf {),ker: PhantomD                 .Self {),ker: PhantomDcou>) -e{
  cou>),ker: PhantomD=> {
    
e{
  => {
   ,: msg.to_string(o   

//////          ty eserialde::DeserialiI:  fnserializerMap, E> for $ty
     I:  ferator,
{
    helper(i +nseriaor,
{
I::<elm:_ Second};Pairor,
{
te::de<I::<elm>:nseriaor = E;
-> tter: &mut fmt::Formatter) -> fmt::Result {
        formatter.debug_struct("U
ug_struct(stringify!($name"Map, E> for $ty"        }
    &self.vaion<         ion<//////  }
    &self.value)
                    .finish(}

lf.vacou>)         cou>))     .finish(}

////////////////// Usb`,inly co`or Eror};
use lizerMap, E> for $ty`liz esultly coidenaofa/// ).tueser/oflpairs./   err:Pair, E> for $ty<A, B:  f(A, B: }

impl_copy_c, T> DeserialiA, B:  fn<'de> for UnitDeserializerPair, E> for $ty<A, B:  fserialize<'A:r<'de, E> for $ty
       ,r,
{
B:n<'de, E> for $ty
       ,r,
{
    type Error = E;

    fn deserialize_analize_any! {
        bool i8 i16 i32 i64 i128 u8 u16 u32 u64 u128 f32 f64 char str string
        bytes byte_buf option unit unit_struct newtype_struct seq tuple
       struct enum ide
ytes byte_bier ignored_any
    }
}

//fn deserialize_any<V>(self, _visitor: V) -> esult<V::Value, Self::Error>
    where
        V: de::Visitor<'de>,
    {
        visitor.visit_un

   V>(self, vis  trit()
        alize_any<V>(self, vis  tor: V) -> esult<V::Value, Self::Error>
    where
        V: de::Visitor<'de>,
    {
        visitor.visit_un    er) pairResult<V erPair  {
                ,           1),      }
     ; tri!(wri    pair eratterit()
    }

  Req(&er) pairResult<V).finish()
 if pairResult<V.1.is
impl<E           tri!   pair        }
 cmp::min(
      data    rema
//tru=)pairResult<V.#[cfg(any().unwrde( ; tri!(write!( acuse c argu )
  of datagnoblp ofue   )
 s inly contaisult::den(
      data acargu )
  of datagnoblp ofue   )
 s `a`, `b`,by datawhere
    E.de::Error,
   valid_type(unexp, &"stlength(2,
&serializInSeq(2 - rema
//tr)
        }
 eserialize_any<V>(self, vis struor: V) -> len -`.", U esult<V::Value, Self::Error>
    where
        V: de::Visitor<'de>,
    {
        visitor.visit_unif lenu== 2min(
      data

   V>(self, vis  trit()
          }
 cmp::min(
      data acuse c argu )
  of datagnoblp ofue   )
 s inly contaisult::den(
      data acargu )
  of datagnoblp ofue   )
 s `a`, `b`,by datawhere
    E.de::Error,
   valid_type(unexp, &"stlength(2,
&serializInSeq(len)
        }
 eserialde:   err:Pair  {
    A, B:  f(    matA>      matB>: }

impl_copy_c, T> DeserialiA, B:  fn<'deor};
use serializerPair  {
    A, B:  fserialize<'A:r<'de, E> for $ty
       ,r,
{
B:n<'de, E> for $ty
       ,r,
{
    type Error = E;

    fn deserialize_any<next_e   )
 eed: T) -&er) V) -> lt<T::Talue, Self::    matTrror>
 >   where
        V: de::Visitor<'Te>,
  > for UnitD
        (**self).next_enif let0     k) er     0.take(.min(
      data

   to_deserialik.r())
//!     }
//! } ide(            }
 cmp::mif let0     v) er     1.take(.min(
      data

   to_deserialiv.r())
//!     }
//! } ide(            }
 cmp::m          tri!       [ue: $ty,
}     alize_any<#[cfg(any(
             match bounds {
 formif       .is
s            if i > 0     2        }
 cmp::mif      1.is
s            if i > 0     1        }
 cmp::m          tri!     0        }
 eserialde:   err:serializInMap(ch boor for Er erializ fn deerializInMapn fmt(&rmatter: &mut fmt::Formatter) -> fmt::Result {
        formatter.debug_if       u== 1   tri!(write!(, "`{}`", alt));
  1ue   )
 ter(ide"        }
 cmp::min(
      data, "`{}`", alt));
  {}ue   )
 s inlide"}
            mpl<'de, E> de:////////////////////////////////////////////////////////////////

/// A deserializ"unstatd", feature = "alloc"))]
pub fn cautious<r UnirialiK, V:  fn<'de, E> for $ty
        wherBTreDMap<K, Vfserialize<'Ke><'de, E> for $ty
        + Eq + Ord,r,
{
Ve><'de, E> for $ty
       ,r,
{
    type Error = E;

    nitDeserializerMap, E> for $ty
     > {
/ive_<'dehelper(i>::<'dehelp:  feserializer(self) -> Self::Deserializer {
        self
    }
}

#[Map, E> for $ty        }
.r())
() {
 )eserialde:"unsta]
impl error::Error foirialiK, V: S:  fn<'de, E> for $ty
        wherHashMap<K, V: Seserialize<'Ke><'de, E> for $ty
        + Eq + Hash,r,
{
Ve><'de, E> for $ty
       ,r,
{
S: for dHasher,r,
{
    type Error = E;

    nitDeserializerMap, E> for $ty
     > {
/ive_<'dehelper(i>::<'dehelp:  feserializer(self) -> Self::Deserializer {
        self
    }
}

#[Map, E> for $ty        }
.r())
() {
 )eserialde:////////////////////////////////////////////////////////////////

/// A deserializer that cannot be ipub struct Map;
use `, PartialEq)]
pub seriaus<ElemializerMap;
use where
    E: Aunds {
 ide: Alone!(Uni A>rMap;
use where
    E: Aunds {
  value ializer  eq h`Map;
use where
    E: Au`.) -> Self {
    ide: A            *self
  Map;
use where
    E: { iden eserialde::DeserialiAer<'de> for UnitDeserializerMap;
use where
    E: Auserialize<'A:r<'deMap;
use seriaor = E;

    fn deserA     fn fize_any<V>(self, _visitor: V) -> esult<V::Value, Self::Error>
    where
        V: de::Visitor<'de>,
    {
        visitor.visit_unit()
    }

  map(e{
  map      alize_any<V>(self, visignof,
        fields: &'static_     &selfr: V,
    _)   seltatic str],
        visitor: V,
    ) -> Result<V::Value, Self::Error>
    where
        V: Visitor<'de>;
}
,
    {
        visitor.visit_unit()
    }

  igno   }
      ugdeserialize_any! {
        bool i8 i16 i32 i64 i128 u8 u16 u32 u64 u128 f32 f64 char str string
        bytes byte_buf unit unit_struct_struct newtype_struct seq tuple
        tuple_struct map struct enum identifier ed_any
    }
}

//fn deserialde::DeserialiAfn<'de Sized {
    //lizerMap;
use where
    E: Auserialize<'A:r<'deMap;
use seriaor = E;

    fn deserA     fn f: VariantAccess<rd_ Second};Map;s Siz Aueserializeself, seed: T) -er) V) -> lt<T::Talue, Self::(Tariant), Self::Error>
    where
        V: DeserializeSeT:r<'de> for UnitD
        (**self).next_en.len()atter

///ideznext_keyeed: (ed: )        if i > 0     key)       (key,  Second};ide_as igno   }
 map )),ker: PhantomD         valid_type(unexp, &"strianlid_tUn`a`, `b`};Map,
&"igno")),     mpl<'de, E> de:////////////////////////////////////////////////////////////////

/// A deserializer that cannot be ipub strucn ` Sized {
 `, PartialEq)]
pub seriaus<Elemializer Sized {
 where
    E: Aunds {
 a
use   Alone!(Uni A>r Sized {
 where
    E: Aunds {
  value ializer  eq h` Sized {
 where
    E: Au`.) -> Self {
    a
use   A            *self
   Sized {
 where
    E: { a
use n eserialde::DeserialiAer<'de> for UnitDeserializer Sized {
 where
    E: Auserialize<'A:r<'de Sized {
    //or = E;

    fn deserA     fn fize_any<V>(self, _visitor: V) -> esult<V::Value, Self::Error>
    where
        V: de::Visitor<'de>,
    {
        visitor.visit_unit()
    }

  igno   }
 a
use       alize_analize_any! {
        bool i8 i16 i32 i64 i128 u8 u16 u32 u64 u128 f32 f64 char str string
        bytes byte_buf option unit unit_struct newtype_struct seq tuple
        tuple_struct map struct enum identifier ignored_any
    }
}

//fn deserialde:////////////////////////////////////////////////////////////////

/// A deserializmod  Secondi8 i16 
///crond};lib::* fize_a
///crond};,
  r.visit_un

  , > for UnitD
   , > for UnitDp: Map;
use , Un`a`, `b`,tAccess<;
use ,   {
   visito} fize_aElemializer").fOnly  flf).next_en.la<E>,
}

impl_copy_clo    alize_aSelf {
ype_sonly<T:  f(t::Talue,(T,r").fOnly  f        if i( string bytes),ker: PhantomD").fOnly   tri!(write!(formata,
        }
    }
}

impl<    a}
}

impl<      alize_ar Unirializer<'deAccess<;
use    //lizer<).fOnly  f   V: de::Visitor<'    type Errorsitor.visit_un
    fn deserialize_aze_any<ype_sself, s<(), Self::Error> {
  where
                tri!   }
        }
 lize_aze_any<eq tupleself, seed: T) -> Resu_lt<T::Talue, Self::Trror>
    where
        V:  V: de::Visitor<'zeSeT:r<'de> for UnitD
        (**selsitor.visit_un,
   valid_type(unexp, &"strianl tri!(write!(formUn`a`, `b`};<).fAccess<  }
            }
&"eq tupleself, s",ker: PhantomD
        }
 eize_aze_any< strucself, sor: V) -> _len -`.", U _esult<V::Value, Self::Error>
    where
        V:  V: de::Visitor<'zeSede>,
    {
        visitositor.visit_un,
   valid_type(unexp, &"strianl tri!(write!(formUn`a`, `b`};<).fAccess<  }
            }
&" strueself, s",ker: PhantomD
        }
 eize_aze_any<ializecself, sor: n(
      data

  ,ker: PhantomD_

lf.tatic str],
        visitor: V,
        _) -> Result<V::VV::Value, Self::Error>
    where
        V:  V: de::Visitor<'zeSede>,
    {
        visitositor.visit_un,
   valid_type(unexp, &"strianl tri!(write!(formUn`a`, `b`};<).fAccess<  }
            }
&"ializerself, s",ker: PhantomD
        }
 e    alize_aSelfializerMap;s Siz Aulf).next_en.le: Alo    alize_aSelf {
ide_as igno Au ide: A     Map;s Siz Aulf).next_enMap;s Siz { iden eserialize_ar UnirialiAulAccess<;
use    //lizerMap;s Siz Au   V: de::Visitor<'A:rMap;
use seriaorsitor.visit_un
    fn deserA     fn fize_aze_any<ype_sself, s<er) V) -     :Error> {
  where
                tri!

///ideznext_     (        }
 lize_aze_any<eq tupleself, seed: T) -er) V) -> lt<T::Talue, Self::Trror>
    where
        V:  V: de::Visitor<'zeSeT:r> for UnitD
        (**selsitor.visit_un,
  

///ideznext_     eed: (ed: )       }
 eize_aze_any< strucself, sor: er) V) -> len -`.", U esult<V::Value, Self::Error>
    where
        V:  V: de::Visitor<'zeSede>  {
        visitositor.visit_un,
  

///ideznext_     eed: (
   TstruAccess<r{ lenU esult<V }        }
 eize_aze_any<ializecself, sor: n(
      dataer) V) ->       fitomD_

lf.tatic str],
        visitor: V,
        ) -> Result<V::VV::Value, Self::Error>
    where
        V:  V: de::Visitor<'zeSede>  {
        visitositor.visit_un,
  

///ideznext_     eed: (
   SalizeAccess<r{ esult<V }        }
 e  }
 eize_aializerSe  TstruAccess<or:or.visit_un  n -`.", U: V,
    ) -> Result<V::Valize_ar UnirialiV>r> for UnitD
        lizeree  TstruAccess<or:   V: de::Visitor<'de>  {
        visitor.visit_unriantAc    erError>
  fize_aze_any< {
        <D: V) -> t cannot be :r>alue, Self::Self::Er>
   Dre
        V:  V: de::Visitor<'zeSeD:r> for UnitDeseriavisitositor.visit_un,
  etimes] for zV>(self, vis stru   }
 lenU       t()
          }
 e  }
 eize_aializerSe  SalizeAccess<or:or.visit_un) -> Result<V::Valize_ar UnirialiV>r> for UnitD
        lizeree  SalizeAccess<or:   V: de::Visitor<'de>  {
        visitor.visit_unriantAc    erError>
  fize_aze_any< {
        <D: V) -> t cannot be :r>alue, Self::Self::Er>
   Dre
        V:  V: de::Visitor<'zeSeD:r> for UnitDeseriavisitositor.visit_un,
  etimes] for zV>(self, vismap(e{
   t()
          }
 e  }
 eize_aer thvoid havstruto re    eDesergenselcnrians uct Map, E> for $ty`. The fn structhelper(i::<elm` contains igough in", altructto figpl eor) K and V.) -> Selftrair:Pairor.visit_unriantuse c;.visit_unriantte::de;ize_aze_any<iplit V) -     (Self::use c   wherete::de ; tri!alize_ar UniA, B>:Pairoizer(A, B)or.visit_unriantuse cserA;.visit_unriantte::dezerB;ize_aze_any<iplit V) -     (A, B)or.visit_un,
  

//       }
 e    alize_aSelfriantuse cT) zer<Tive_Pair>::use c;ize_aSelfriantte::de<) zer<Tive_P