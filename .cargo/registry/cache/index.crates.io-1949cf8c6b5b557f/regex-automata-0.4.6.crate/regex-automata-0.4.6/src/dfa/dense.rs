/*!
Types and routines specific to dense DFAs.

This module is the home of [`dense::DFA`](DFA).

This module also contains a [`dense::Builder`](Builder) and a
[`dense::Config`](Config) for building and configuring a dense DFA.
*/

#[cfg(feature = "dfa-build")]
use core::cmp;
use core::{fmt, iter, mem::size_of, slice};

#[cfg(feature = "dfa-build")]
use alloc::{
    collections::{BTreeMap, BTreeSet},
    vec,
    vec::Vec,
};

#[cfg(feature = "dfa-build")]
use crate::{
    dfa::{
        accel::Accel, determinize, minimize::Minimizer, remapper::Remapper,
        sparse,
    },
    nfa::thompson,
    util::{look::LookMatcher, search::MatchKind},
};
use crate::{
    dfa::{
        accel::Accels,
        automaton::{fmt_state_indicator, Automaton, StartError},
        special::Special,
        start::StartKind,
        DEAD,
    },
    util::{
        alphabet::{self, ByteClasses, ByteSet},
        int::{Pointer, Usize},
        prefilter::Prefilter,
        primitives::{PatternID, StateID},
        search::Anchored,
        start::{self, Start, StartByteMap},
        wire::{self, DeserializeError, Endian, SerializeError},
    },
};

/// The label that is pre-pended to a serialized DFA.
const LABEL: &str = "rust-regex-automata-dfa-dense";

/// The format version of dense regexes. This version gets incremented when a
/// change occurs. A change may not necessarily be a breaking change, but the
/// version does permit good error messages in the case where a breaking change
/// is made.
const VERSION: u32 = 2;

/// The configuration used for compiling a dense DFA.
///
/// As a convenience, [`DFA::config`] is an alias for [`Config::new`]. The
/// advantage of the former is that it often lets you avoid importing the
/// `Config` type directly.
///
/// A dense DFA configuration is a simple data object that is typically used
/// with [`dense::Builder::configure`](self::Builder::configure).
///
/// The default configuration guarantees that a search will never return
/// a "quit" error, although it is possible for a search to fail if
/// [`Config::starts_for_each_pattern`] wasn't enabled (which it is
/// not by default) and an [`Anchored::Pattern`] mode is requested via
/// [`Input`](crate::Input).
#[cfg(feature = "dfa-build")]
#[derive(Clone, Debug, Default)]
pub struct Config {
    // As with other configuration types in this crate, we put all our knobs
    // in options so that we can distinguish between "default" and "not set."
    // This makes it possible to easily combine multiple configurations
    // without default values overwriting explicitly specified values. See the
    // 'overwrite' method.
    //
    // For docs on the fields below, see the corresponding method setters.
    accelerate: Option<bool>,
    pre: Option<Option<Prefilter>>,
    minimize: Option<bool>,
    match_kind: Option<MatchKind>,
    start_kind: Option<StartKind>,
    starts_for_each_pattern: Option<bool>,
    byte_classes: Option<bool>,
    unicode_word_boundary: Option<bool>,
    quitset: Option<ByteSet>,
    specialize_start_states: Option<bool>,
    dfa_size_limit: Option<Option<usize>>,
    determinize_size_limit: Option<Option<usize>>,
}

#[cfg(feature = "dfa-build")]
impl Config {
    /// Return a new default dense DFA compiler configuration.
    pub fn new() -> Config {
        Config::default()
    }

    /// Enable state acceleration.
    ///
    /// When enabled, DFA construction will analyze each state to determine
    /// whether it is eligible for simple acceleration. Acceleration typically
    /// occurs when most of a state's transitions loop back to itself, leaving
    /// only a select few bytes that will exit the state. When this occurs,
    /// other routines like `memchr` can be used to look for those bytes which
    /// may be much faster than traversing the DFA.
    ///
    /// Callers may elect to disable this if consistent performance is more
    /// desirable than variable performance. Namely, acceleration can sometimes
    /// make searching slower than it otherwise would be if the transitions
    /// that leave accelerated states are traversed frequently.
    ///
    /// See [`Automaton::accelerator`] for an example.
    ///
    /// This is enabled by default.
    pub fn accelerate(mut self, yes: bool) -> Config {
        self.accelerate = Some(yes);
        self
    }

    /// Set a prefilter to be used whenever a start state is entered.
    ///
    /// A [`Prefilter`] in this context is meant to accelerate searches by
    /// looking for literal prefixes that every match for the corresponding
    /// pattern (or patterns) must start with. Once a prefilter produces a
    /// match, the underlying search routine continues on to try and confirm
    /// the match.
    ///
    /// Be warned that setting a prefilter does not guarantee that the search
    /// will be faster. While it's usually a good bet, if the prefilter
    /// produces a lot of false positive candidates (i.e., positions matched
    /// by the prefilter but not by the regex), then the overall result can
    /// be slower than if you had just executed the regex engine without any
    /// prefilters.
    ///
    /// Note that unless [`Config::specialize_start_states`] has been
    /// explicitly set, then setting this will also enable (when `pre` is
    /// `Some`) or disable (when `pre` is `None`) start state specialization.
    /// This occurs because without start state specialization, a prefilter
    /// is likely to be less effective. And without a prefilter, start state
    /// specialization is usually pointless.
    ///
    /// **WARNING:** Note that prefilters are not preserved as part of
    /// serialization. Serializing a DFA will drop its prefilter.
    ///
    /// By default no prefilter is set.
    ///
    /// # Example
    ///
    /// ```
    /// use regex_automata::{
    ///     dfa::{dense::DFA, Automaton},
    ///     util::prefilter::Prefilter,
    ///     Input, HalfMatch, MatchKind,
    /// };
    ///
    /// let pre = Prefilter::new(MatchKind::LeftmostFirst, &["foo", "bar"]);
    /// let re = DFA::builder()
    ///     .configure(DFA::config().prefilter(pre))
    ///     .build(r"(foo|bar)[a-z]+")?;
    /// let input = Input::new("foo1 barfox bar");
    /// assert_eq!(
    ///     Some(HalfMatch::must(0, 11)),
    ///     re.try_search_fwd(&input)?,
    /// );
    ///
    /// # Ok::<(), Box<dyn std::error::Error>>(())
    /// ```
    ///
    /// Be warned though that an incorrect prefilter can lead to incorrect
    /// results!
    ///
    /// ```
    /// use regex_automata::{
    ///     dfa::{dense::DFA, Automaton},
    ///     util::prefilter::Prefilter,
    ///     Input, HalfMatch, MatchKind,
    /// };
    ///
    /// let pre = Prefilter::new(MatchKind::LeftmostFirst, &["foo", "car"]);
    /// let re = DFA::builder()
    ///     .configure(DFA::config().prefilter(pre))
    ///     .build(r"(foo|bar)[a-z]+")?;
    /// let input = Input::new("foo1 barfox bar");
    /// assert_eq!(
    ///     // No match reported even though there clearly is one!
    ///     None,
    ///     re.try_search_fwd(&input)?,
    /// );
    ///
    /// # Ok::<(), Box<dyn std::error::Error>>(())
    /// ```
    pub fn prefilter(mut self, pre: Option<Prefilter>) -> Config {
        self.pre = Some(pre);
        if self.specialize_start_states.is_none() {
            self.specialize_start_states =
                Some(self.get_prefilter().is_some());
        }
        self
    }

    /// Minimize the DFA.
    ///
    /// When enabled, the DFA built will be minimized such that it is as small
    /// as possible.
    ///
    /// Whether one enables minimization or not depends on the types of costs
    /// you're willing to pay and how much you care about its benefits. In
    /// particular, minimization has worst case `O(n*k*logn)` time and `O(k*n)`
    /// space, where `n` is the number of DFA states and `k` is the alphabet
    /// size. In practice, minimization can be quite costly in terms of both
    /// space and time, so it should only be done if you're willing to wait
    /// longer to produce a DFA. In general, you might want a minimal DFA in
    /// the following circumstances:
    ///
    /// 1. You would like to optimize for the size of the automaton. This can
    ///    manifest in one of two ways. Firstly, if you're converting the
    ///    DFA into Rust code (or a table embedded in the code), then a minimal
    ///    DFA will translate into a corresponding reduction in code  size, and
    ///    thus, also the final compiled binary size. Secondly, if you are
    ///    building many DFAs and putting them on the heap, you'll be able to
    ///    fit more if they are smaller. Note though that building a minimal
    ///    DFA itself requires additional space; you only realize the space
    ///    savings once the minimal DFA is constructed (at which point, the
    ///    space used for minimization is freed).
    /// 2. You've observed that a smaller DFA results in faster match
    ///    performance. Naively, this isn't guaranteed since there is no
    ///    inherent difference between matching with a bigger-than-minimal
    ///    DFA and a minimal DFA. However, a smaller DFA may make use of your
    ///    CPU's cache more efficiently.
    /// 3. You are trying to establish an equivalence between regular
    ///    languages. The standard method for this is to build a minimal DFA
    ///    for each language and then compare them. If the DFAs are equivalent
    ///    (up to state renaming), then the languages are equivalent.
    ///
    /// Typically, minimization only makes sense as an offline process. That
    /// is, one might minimize a DFA before serializing it to persistent
    /// storage. In practical terms, minimization can take around an order of
    /// magnitude more time than compiling the initial DFA via determinization.
    ///
    /// This option is disabled by default.
    pub fn minimize(mut self, yes: bool) -> Config {
        self.minimize = Some(yes);
        self
    }

    /// Set the desired match semantics.
    ///
    /// The default is [`MatchKind::LeftmostFirst`], which corresponds to the
    /// match semantics of Perl-like regex engines. That is, when multiple
    /// patterns would match at the same leftmost position, the pattern that
    /// appears first in the concrete syntax is chosen.
    ///
    /// Currently, the only other kind of match semantics supported is
    /// [`MatchKind::All`]. This corresponds to classical DFA construction
    /// where all possible matches are added to the DFA.
    ///
    /// Typically, `All` is used when one wants to execute an overlapping
    /// search and `LeftmostFirst` otherwise. In particular, it rarely makes
    /// sense to use `All` with the various "leftmost" find routines, since the
    /// leftmost routines depend on the `LeftmostFirst` automata construction
    /// strategy. Specifically, `LeftmostFirst` adds dead states to the DFA
    /// as a way to terminate the search and report a match. `LeftmostFirst`
    /// also supports non-greedy matches using this strategy where as `All`
    /// does not.
    ///
    /// # Example: overlapping search
    ///
    /// This example shows the typical use of `MatchKind::All`, which is to
    /// report overlapping matches.
    ///
    /// ```
    /// # if cfg!(miri) { return Ok(()); } // miri takes too long
    /// use regex_automata::{
    ///     dfa::{Automaton, OverlappingState, dense},
    ///     HalfMatch, Input, MatchKind,
    /// };
    ///
    /// let dfa = dense::Builder::new()
    ///     .configure(dense::Config::new().match_kind(MatchKind::All))
    ///     .build_many(&[r"\w+$", r"\S+$"])?;
    /// let input = Input::new("@foo");
    /// let mut state = OverlappingState::start();
    ///
    /// let expected = Some(HalfMatch::must(1, 4));
    /// dfa.try_search_overlapping_fwd(&input, &mut state)?;
    /// assert_eq!(expected, state.get_match());
    ///
    /// // The first pattern also matches at the same position, so re-running
    /// // the search will yield another match. Notice also that the first
    /// // pattern is returned after the second. This is because the second
    /// // pattern begins its match before the first, is therefore an earlier
    /// // match and is thus reported first.
    /// let expected = Some(HalfMatch::must(0, 4));
    /// dfa.try_search_overlapping_fwd(&input, &mut state)?;
    /// assert_eq!(expected, state.get_match());
    ///
    /// # Ok::<(), Box<dyn std::error::Error>>(())
    /// ```
    ///
    /// # Example: reverse automaton to find start of match
    ///
    /// Another example for using `MatchKind::All` is for constructing a
    /// reverse automaton to find the start of a match. `All` semantics are
    /// used for this in order to find the longest possible match, which
    /// corresponds to the leftmost starting position.
    ///
    /// Note that if you need the starting position then
    /// [`dfa::regex::Regex`](crate::dfa::regex::Regex) will handle this for
    /// you, so it's usually not necessary to do this yourself.
    ///
    /// ```
    /// use regex_automata::{
    ///     dfa::{dense, Automaton, StartKind},
    ///     nfa::thompson::NFA,
    ///     Anchored, HalfMatch, Input, MatchKind,
    /// };
    ///
    /// let haystack = "123foobar456".as_bytes();
    /// let pattern = r"[a-z]+r";
    ///
    /// let dfa_fwd = dense::DFA::new(pattern)?;
    /// let dfa_rev = dense::Builder::new()
    ///     .thompson(NFA::config().reverse(true))
    ///     .configure(dense::Config::new()
    ///         // This isn't strictly necessary since both anchored and
    ///         // unanchored searches are supported by default. But since
    ///         // finding the start-of-match only requires anchored searches,
    ///         // we can get rid of the unanchored configuration and possibly
    ///         // slim down our DFA considerably.
    ///         .start_kind(StartKind::Anchored)
    ///         .match_kind(MatchKind::All)
    ///     )
    ///     .build(pattern)?;
    /// let expected_fwd = HalfMatch::must(0, 9);
    /// let expected_rev = HalfMatch::must(0, 3);
    /// let got_fwd = dfa_fwd.try_search_fwd(&Input::new(haystack))?.unwrap();
    /// // Here we don't specify the pattern to search for since there's only
    /// // one pattern and we're doing a leftmost search. But if this were an
    /// // overlapping search, you'd need to specify the pattern that matched
    /// // in the forward direction. (Otherwise, you might wind up finding the
    /// // starting position of a match of some other pattern.) That in turn
    /// // requires building the reverse automaton with starts_for_each_pattern
    /// // enabled. Indeed, this is what Regex does internally.
    /// let input = Input::new(haystack)
    ///     .range(..got_fwd.offset())
    ///     .anchored(Anchored::Yes);
    /// let got_rev = dfa_rev.try_search_rev(&input)?.unwrap();
    /// assert_eq!(expected_fwd, got_fwd);
    /// assert_eq!(expected_rev, got_rev);
    ///
    /// # Ok::<(), Box<dyn std::error::Error>>(())
    /// ```
    pub fn match_kind(mut self, kind: MatchKind) -> Config {
        self.match_kind = Some(kind);
        self
    }

    /// The type of starting state configuration to use for a DFA.
    ///
    /// By default, the starting state configuration is [`StartKind::Both`].
    ///
    /// # Example
    ///
    /// ```
    /// use regex_automata::{
    ///     dfa::{dense::DFA, Automaton, StartKind},
    ///     Anchored, HalfMatch, Input,
    /// };
    ///
    /// let haystack = "quux foo123";
    /// let expected = HalfMatch::must(0, 11);
    ///
    /// // By default, DFAs support both anchored and unanchored searches.
    /// let dfa = DFA::new(r"[0-9]+")?;
    /// let input = Input::new(haystack);
    /// assert_eq!(Some(expected), dfa.try_search_fwd(&input)?);
    ///
    /// // But if we only need anchored searches, then we can build a DFA
    /// // that only supports anchored searches. This leads to a smaller DFA
    /// // (potentially significantly smaller in some cases), but a DFA that
    /// // will panic if you try to use it with an unanchored search.
    /// let dfa = DFA::builder()
    ///     .configure(DFA::config().start_kind(StartKind::Anchored))
    ///     .build(r"[0-9]+")?;
    /// let input = Input::new(haystack)
    ///     .range(8..)
    ///     .anchored(Anchored::Yes);
    /// assert_eq!(Some(expected), dfa.try_search_fwd(&input)?);
    ///
    /// # Ok::<(), Box<dyn std::error::Error>>(())
    /// ```
    pub fn start_kind(mut self, kind: StartKind) -> Config {
        self.start_kind = Some(kind);
        self
    }

    /// Whether to compile a separate start state for each pattern in the
    /// automaton.
    ///
    /// When enabled, a separate **anchored** start state is added for each
    /// pattern in the DFA. When this start state is used, then the DFA will
    /// only search for matches for the pattern specified, even if there are
    /// other patterns in the DFA.
    ///
    /// The main downside of this option is that it can potentially increase
    /// the size of the DFA and/or increase the time it takes to build the DFA.
    ///
    /// There are a few reasons one might want to enable this (it's disabled
    /// by default):
    ///
    /// 1. When looking for the start of an overlapping match (using a
    /// reverse DFA), doing it correctly requires starting the reverse search
    /// using the starting state of the pattern that matched in the forward
    /// direction. Indeed, when building a [`Regex`](crate::dfa::regex::Regex),
    /// it will automatically enable this option when building the reverse DFA
    /// internally.
    /// 2. When you want to use a DFA with multiple patterns to both search
    /// for matches of any pattern or to search for anchored matches of one
    /// particular pattern while using the same DFA. (Otherwise, you would need
    /// to compile a new DFA for each pattern.)
    /// 3. Since the start states added for each pattern are anchored, if you
    /// compile an unanchored DFA with one pattern while also enabling this
    /// option, then you can use the same DFA to perform anchored or unanchored
    /// searches. The latter you get with the standard search APIs. The former
    /// you get from the various `_at` search methods that allow you specify a
    /// pattern ID to search for.
    ///
    /// By default this is disabled.
    ///
    /// # Example
    ///
    /// This example shows how to use this option to permit the same DFA to
    /// run both anchored and unanchored searches for a single pattern.
    ///
    /// ```
    /// use regex_automata::{
    ///     dfa::{dense, Automaton},
    ///     Anchored, HalfMatch, PatternID, Input,
    /// };
    ///
    /// let dfa = dense::Builder::new()
    ///     .configure(dense::Config::new().starts_for_each_pattern(true))
    ///     .build(r"foo[0-9]+")?;
    /// let haystack = "quux foo123";
    ///
    /// // Here's a normal unanchored search. Notice that we use 'None' for the
    /// // pattern ID. Since the DFA was built as an unanchored machine, it
    /// // use its default unanchored starting state.
    /// let expected = HalfMatch::must(0, 11);
    /// let input = Input::new(haystack);
    /// assert_eq!(Some(expected), dfa.try_search_fwd(&input)?);
    /// // But now if we explicitly specify the pattern to search ('0' being
    /// // the only pattern in the DFA), then it will use the starting state
    /// // for that specific pattern which is always anchored. Since the
    /// // pattern doesn't have a match at the beginning of the haystack, we
    /// // find nothing.
    /// let input = Input::new(haystack)
    ///     .anchored(Anchored::Pattern(PatternID::must(0)));
    /// assert_eq!(None, dfa.try_search_fwd(&input)?);
    /// // And finally, an anchored search is not the same as putting a '^' at
    /// // beginning of the pattern. An anchored search can only match at the
    /// // beginning of the *search*, which we can change:
    /// let input = Input::new(haystack)
    ///     .anchored(Anchored::Pattern(PatternID::must(0)))
    ///     .range(5..);
    /// assert_eq!(Some(expected), dfa.try_search_fwd(&input)?);
    ///
    /// # Ok::<(), Box<dyn std::error::Error>>(())
    /// ```
    pub fn starts_for_each_pattern(mut self, yes: bool) -> Config {
        self.starts_for_each_pattern = Some(yes);
        self
    }

    /// Whether to attempt to shrink the size of the DFA's alphabet or not.
    ///
    /// This option is enabled by default and should never be disabled unless
    /// one is debugging a generated DFA.
    ///
    /// When enabled, the DFA will use a map from all possible bytes to their
    /// corresponding equivalence class. Each equivalence class represents a
    /// set of bytes that does not discriminate between a match and a non-match
    /// in the DFA. For example, the pattern `[ab]+` has at least two
    /// equivalence classes: a set containing `a` and `b` and a set containing
    /// every byte except for `a` and `b`. `a` and `b` are in the same
    /// equivalence class because they never discriminate between a match and a
    /// non-match.
    ///
    /// The advantage of this map is that the size of the transition table
    /// can be reduced drastically from `#states * 256 * sizeof(StateID)` to
    /// `#states * k * sizeof(StateID)` where `k` is the number of equivalence
    /// classes (rounded up to the nearest power of 2). As a result, total
    /// space usage can decrease substantially. Moreover, since a smaller
    /// alphabet is used, DFA compilation becomes faster as well.
    ///
    /// **WARNING:** This is only useful for debugging DFAs. Disabling this
    /// does not yield any speed advantages. Namely, even when this is
    /// disabled, a byte class map is still used while searching. The only
    /// difference is that every byte will be forced into its own distinct
    /// equivalence class. This is useful for debugging the actual generated
    /// transitions because it lets one see the transitions defined on actual
    /// bytes instead of the equivalence classes.
    pub fn byte_classes(mut self, yes: bool) -> Config {
        self.byte_classes = Some(yes);
        self
    }

    /// Heuristically enable Unicode word boundaries.
    ///
    /// When set, this will attempt to implement Unicode word boundaries as if
    /// they were ASCII word boundaries. This only works when the search input
    /// is ASCII only. If a non-ASCII byte is observed while searching, then a
    /// [`MatchError::quit`](crate::MatchError::quit) error is returned.
    ///
    /// A possible alternative to enabling this option is to simply use an
    /// ASCII word boundary, e.g., via `(?-u:\b)`. The main reason to use this
    /// option is if you absolutely need Unicode support. This option lets one
    /// use a fast search implementation (a DFA) for some potentially very
    /// common cases, while providing the option to fall back to some other
    /// regex engine to handle the general case when an error is returned.
    ///
    /// If the pattern provided has no Unicode word boundary in it, then this
    /// option has no effect. (That is, quitting on a non-ASCII byte only
    /// occurs when this option is enabled _and_ a Unicode word boundary is
    /// present in the pattern.)
    ///
    /// This is almost equivalent to setting all non-ASCII bytes to be quit
    /// bytes. The only difference is that this will cause non-ASCII bytes to
    /// be quit bytes _only_ when a Unicode word boundary is present in the
    /// pattern.
    ///
    /// When enabling this option, callers _must_ be prepared to handle
    /// a [`MatchError`](crate::MatchError) error during search.
    /// When using a [`Regex`](crate::dfa::regex::Regex), this corresponds
    /// to using the `try_` suite of methods. Alternatively, if
    /// callers can guarantee that their input is ASCII only, then a
    /// [`MatchError::quit`](crate::MatchError::quit) error will never be
    /// returned while searching.
    ///
    /// This is disabled by default.
    ///
    /// # Example
    ///
    /// This example shows how to heuristically enable Unicode word boundaries
    /// in a pattern. It also shows what happens when a search comes across a
    /// non-ASCII byte.
    ///
    /// ```
    /// use regex_automata::{
    ///     dfa::{Automaton, dense},
    ///     HalfMatch, Input, MatchError,
    /// };
    ///
    /// let dfa = dense::Builder::new()
    ///     .configure(dense::Config::new().unicode_word_boundary(true))
    ///     .build(r"\b[0-9]+\b")?;
    ///
    /// // The match occurs before the search ever observes the snowman
    /// // character, so no error occurs.
    /// let haystack = "foo 123  ☃".as_bytes();
    /// let expected = Some(HalfMatch::must(0, 7));
    /// let got = dfa.try_search_fwd(&Input::new(haystack))?;
    /// assert_eq!(expected, got);
    ///
    /// // Notice that this search fails, even though the snowman character
    /// // occurs after the ending match offset. This is because search
    /// // routines read one byte past the end of the search to account for
    /// // look-around, and indeed, this is required here to determine whether
    /// // the trailing \b matches.
    /// let haystack = "foo 123 ☃".as_bytes();
    /// let expected = MatchError::quit(0xE2, 8);
    /// let got = dfa.try_search_fwd(&Input::new(haystack));
    /// assert_eq!(Err(expected), got);
    ///
    /// // Another example is executing a search where the span of the haystack
    /// // we specify is all ASCII, but there is non-ASCII just before it. This
    /// // correctly also reports an error.
    /// let input = Input::new("β123").range(2..);
    /// let expected = MatchError::quit(0xB2, 1);
    /// let got = dfa.try_search_fwd(&input);
    /// assert_eq!(Err(expected), got);
    ///
    /// // And similarly for the trailing word boundary.
    /// let input = Input::new("123β").range(..3);
    /// let expected = MatchError::quit(0xCE, 3);
    /// let got = dfa.try_search_fwd(&input);
    /// assert_eq!(Err(expected), got);
    ///
    /// # Ok::<(), Box<dyn std::error::Error>>(())
    /// ```
    pub fn unicode_word_boundary(mut self, yes: bool) -> Config {
        // We have a separate option for this instead of just setting the
        // appropriate quit bytes here because we don't want to set quit bytes
        // for every regex. We only want to set them when the regex contains a
        // Unicode word boundary.
        self.unicode_word_boundary = Some(yes);
        self
    }

    /// Add a "quit" byte to the DFA.
    ///
    /// When a quit byte is seen during search time, then search will return
    /// a [`MatchError::quit`](crate::MatchError::quit) error indicating the
    /// offset at which the search stopped.
    ///
    /// A quit byte will always overrule any other aspects of a regex. For
    /// example, if the `x` byte is added as a quit byte and the regex `\w` is
    /// used, then observing `x` will cause the search to quit immediately
    /// despite the fact that `x` is in the `\w` class.
    ///
    /// This mechanism is primarily useful for heuristically enabling certain
    /// features like Unicode word boundaries in a DFA. Namely, if the input
    /// to search is ASCII, then a Unicode word boundary can be implemented
    /// via an ASCII word boundary with no change in semantics. Thus, a DFA
    /// can attempt to match a Unicode word boundary but give up as soon as it
    /// observes a non-ASCII byte. Indeed, if callers set all non-ASCII bytes
    /// to be quit bytes, then Unicode word boundaries will be permitted when
    /// building DFAs. Of course, callers should enable
    /// [`Config::unicode_word_boundary`] if they want this behavior instead.
    /// (The advantage being that non-ASCII quit bytes will only be added if a
    /// Unicode word boundary is in the pattern.)
    ///
    /// When enabling this option, callers _must_ be prepared to handle a
    /// [`MatchError`](crate::MatchError) error during search. When using a
    /// [`Regex`](crate::dfa::regex::Regex), this corresponds to using the
    /// `try_` suite of methods.
    ///
    /// By default, there are no quit bytes set.
    ///
    /// # Panics
    ///
    /// This panics if heuristic Unicode word boundaries are enabled and any
    /// non-ASCII byte is removed from the set of quit bytes. Namely, enabling
    /// Unicode word boundaries requires setting every non-ASCII byte to a quit
    /// byte. So if the caller attempts to undo any of that, then this will
    /// panic.
    ///
    /// # Example
    ///
    /// This example shows how to cause a search to terminate if it sees a
    /// `\n` byte. This could be useful if, for example, you wanted to prevent
    /// a user supplied pattern from matching across a line boundary.
    ///
    /// ```
    /// # if cfg!(miri) { return Ok(()); } // miri takes too long
    /// use regex_automata::{dfa::{Automaton, dense}, Input, MatchError};
    ///
    /// let dfa = dense::Builder::new()
    ///     .configure(dense::Config::new().quit(b'\n', true))
    ///     .build(r"foo\p{any}+bar")?;
    ///
    /// let haystack = "foo\nbar".as_bytes();
    /// // Normally this would produce a match, since \p{any} contains '\n'.
    /// // But since we instructed the automaton to enter a quit state if a
    /// // '\n' is observed, this produces a match error instead.
    /// let expected = MatchError::quit(b'\n', 3);
    /// let got = dfa.try_search_fwd(&Input::new(haystack)).unwrap_err();
    /// assert_eq!(expected, got);
    ///
    /// # Ok::<(), Box<dyn std::error::Error>>(())
    /// ```
    pub fn quit(mut self, byte: u8, yes: bool) -> Config {
        if self.get_unicode_word_boundary() && !byte.is_ascii() && !yes {
            panic!(
                "cannot set non-ASCII byte to be non-quit when \
                 Unicode word boundaries are enabled"
            );
        }
        if self.quitset.is_none() {
            self.quitset = Some(ByteSet::empty());
        }
        if yes {
            self.quitset.as_mut().unwrap().add(byte);
        } else {
            self.quitset.as_mut().unwrap().remove(byte);
        }
        self
    }

    /// Enable specializing start states in the DFA.
    ///
    /// When start states are specialized, an implementor of a search routine
    /// using a lazy DFA can tell when the search has entered a starting state.
    /// When start states aren't specialized, then it is impossible to know
    /// whether the search has entered a start state.
    ///
    /// Ideally, this option wouldn't need to exist and we could always
    /// specialize start states. The problem is that start states can be quite
    /// active. This in turn means that an efficient search routine is likely
    /// to ping-pong between a heavily optimized hot loop that handles most
    /// states and to a less optimized specialized handling of start states.
    /// This causes branches to get heavily mispredicted and overall can
    /// materially decrease throughput. Therefore, specializing start states
    /// should only be enabled when it is needed.
    ///
    /// Knowing whether a search is in a start state is typically useful when a
    /// prefilter is active for the search. A prefilter is typically only run
    /// when in a start state and a prefilter can greatly accelerate a search.
    /// Therefore, the possible cost of specializing start states is worth it
    /// in this case. Otherwise, if you have no prefilter, there is likely no
    /// reason to specialize start states.
    ///
    /// This is disabled by default, but note that it is automatically
    /// enabled (or disabled) if [`Config::prefilter`] is set. Namely, unless
    /// `specialize_start_states` has already been set, [`Config::prefilter`]
    /// will automatically enable or disable it based on whether a prefilter
    /// is present or not, respectively. This is done because a prefilter's
    /// effectiveness is rooted in being executed whenever the DFA is in a
    /// start state, and that's only possible to do when they are specialized.
    ///
    /// Note that it is plausibly reasonable to _disable_ this option
    /// explicitly while _enabling_ a prefilter. In that case, a prefilter
    /// will still be run at the beginning of a search, but never again. This
    /// in theory could strike a good balance if you're in a situation where a
    /// prefilter is likely to produce many false positive candidates.
    ///
    /// # Example
    ///
    /// This example shows how to enable start state specialization and then
    /// shows how to check whether a state is a start state or not.
    ///
    /// ```
    /// use regex_automata::{dfa::{Automaton, dense::DFA}, Input};
    ///
    /// let dfa = DFA::builder()
    ///     .configure(DFA::config().specialize_start_states(true))
    ///     .build(r"[a-z]+")?;
    ///
    /// let haystack = "123 foobar 4567".as_bytes();
    /// let sid = dfa.start_state_forward(&Input::new(haystack))?;
    /// // The ID returned by 'start_state_forward' will always be tagged as
    /// // a start state when start state specialization is enabled.
    /// assert!(dfa.is_special_state(sid));
    /// assert!(dfa.is_start_state(sid));
    ///
    /// # Ok::<(), Box<dyn std::error::Error>>(())
    /// ```
    ///
    /// Compare the above with the default DFA configuration where start states
    /// are _not_ specialized. In this case, the start state is not tagged at
    /// all:
    ///
    /// ```
    /// use regex_automata::{dfa::{Automaton, dense::DFA}, Input};
    ///
    /// let dfa = DFA::new(r"[a-z]+")?;
    ///
    /// let haystack = "123 foobar 4567";
    /// let sid = dfa.start_state_forward(&Input::new(haystack))?;
    /// // Start states are not special in the default configuration!
    /// assert!(!dfa.is_special_state(sid));
    /// assert!(!dfa.is_start_state(sid));
    ///
    /// # Ok::<(), Box<dyn std::error::Error>>(())
    /// ```
    pub fn specialize_start_states(mut self, yes: bool) -> Config {
        self.specialize_start_states = Some(yes);
        self
    }

    /// Set a size limit on the total heap used by a DFA.
    ///
    /// This size limit is expressed in bytes and is applied during
    /// determinization of an NFA into a DFA. If the DFA's heap usage, and only
    /// the DFA, exceeds this configured limit, then determinization is stopped
    /// and an error is returned.
    ///
    /// This limit does not apply to auxiliary storage used during
    /// determinization that isn't part of the generated DFA.
    ///
    /// This limit is only applied during determinization. Currently, there is
    /// no way to post-pone this check to after minimization if minimization
    /// was enabled.
    ///
    /// The total limit on heap used during determinization is the sum of the
    /// DFA and determinization size limits.
    ///
    /// The default is no limit.
    ///
    /// # Example
    ///
    /// This example shows a DFA that fails to build because of a configured
    /// size limit. This particular example also serves as a cautionary tale
    /// demonstrating just how big DFAs with large Unicode character classes
    /// can get.
    ///
    /// ```
    /// # if cfg!(miri) { return Ok(()); } // miri takes too long
    /// use regex_automata::{dfa::{dense, Automaton}, Input};
    ///
    /// // 6MB isn't enough!
    /// dense::Builder::new()
    ///     .configure(dense::Config::new().dfa_size_limit(Some(6_000_000)))
    ///     .build(r"\w{20}")
    ///     .unwrap_err();
    ///
    /// // ... but 7MB probably is!
    /// // (Note that DFA sizes aren't necessarily stable between releases.)
    /// let dfa = dense::Builder::new()
    ///     .configure(dense::Config::new().dfa_size_limit(Some(7_000_000)))
    ///     .build(r"\w{20}")?;
    /// let haystack = "A".repeat(20).into_bytes();
    /// assert!(dfa.try_search_fwd(&Input::new(&haystack))?.is_some());
    ///
    /// # Ok::<(), Box<dyn std::error::Error>>(())
    /// ```
    ///
    /// While one needs a little more than 6MB to represent `\w{20}`, it
    /// turns out that you only need a little more than 6KB to represent
    /// `(?-u:\w{20})`. So only use Unicode if you need it!
    ///
    /// As with [`Config::determinize_size_limit`], the size of a DFA is
    /// influenced by other factors, such as what start state configurations
    /// to support. For example, if you only need unanchored searches and not
    /// anchored searches, then configuring the DFA to only support unanchored
    /// searches can reduce its size. By default, DFAs support both unanchored
    /// and anchored searches.
    ///
    /// ```
    /// # if cfg!(miri) { return Ok(()); } // miri takes too long
    /// use regex_automata::{dfa::{dense, Automaton, StartKind}, Input};
    ///
    /// // 3MB isn't enough!
    /// dense::Builder::new()
    ///     .configure(dense::Config::new()
    ///         .dfa_size_limit(Some(3_000_000))
    ///         .start_kind(StartKind::Unanchored)
    ///     )
    ///     .build(r"\w{20}")
    ///     .unwrap_err();
    ///
    /// // ... but 4MB probably is!
    /// // (Note that DFA sizes aren't necessarily stable between releases.)
    /// let dfa = dense::Builder::new()
    ///     .configure(dense::Config::new()
    ///         .dfa_size_limit(Some(4_000_000))
    ///         .start_kind(StartKind::Unanchored)
    ///     )
    ///     .build(r"\w{20}")?;
    /// let haystack = "A".repeat(20).into_bytes();
    /// assert!(dfa.try_search_fwd(&Input::new(&haystack))?.is_some());
    ///
    /// # Ok::<(), Box<dyn std::error::Error>>(())
    /// ```
    pub fn dfa_size_limit(mut self, bytes: Option<usize>) -> Config {
        self.dfa_size_limit = Some(bytes);
        self
    }

    /// Set a size limit on the total heap used by determinization.
    ///
    /// This size limit is expressed in bytes and is applied during
    /// determinization of an NFA into a DFA. If the heap used for auxiliary
    /// storage during determinization (memory that is not in the DFA but
    /// necessary for building the DFA) exceeds this configured limit, then
    /// determinization is stopped and an error is returned.
    ///
    /// This limit does not apply to heap used by the DFA itself.
    ///
    /// The total limit on heap used during determinization is the sum of the
    /// DFA and determinization size limits.
    ///
    /// The default is no limit.
    ///
    /// # Example
    ///
    /// This example shows a DFA that fails to build because of a
    /// configured size limit on the amount of heap space used by
    /// determinization. This particular example complements the example for
    /// [`Config::dfa_size_limit`] by demonstrating that not only does Unicode
    /// potentially make DFAs themselves big, but it also results in more
    /// auxiliary storage during determinization. (Although, auxiliary storage
    /// is still not as much as the DFA itself.)
    ///
    /// ```
    /// # if cfg!(miri) { return Ok(()); } // miri takes too long
    /// # if !cfg!(target_pointer_width = "64") { return Ok(()); } // see #1039
    /// use regex_automata::{dfa::{dense, Automaton}, Input};
    ///
    /// // 700KB isn't enough!
    /// dense::Builder::new()
    ///     .configure(dense::Config::new()
    ///         .determinize_size_limit(Some(700_000))
    ///     )
    ///     .build(r"\w{20}")
    ///     .unwrap_err();
    ///
    /// // ... but 800KB probably is!
    /// // (Note that auxiliary storage sizes aren't necessarily stable between
    /// // releases.)
    /// let dfa = dense::Builder::new()
    ///     .configure(dense::Config::new()
    ///         .determinize_size_limit(Some(800_000))
    ///     )
    ///     .build(r"\w{20}")?;
    /// let haystack = "A".repeat(20).into_bytes();
    /// assert!(dfa.try_search_fwd(&Input::new(&haystack))?.is_some());
    ///
    /// # Ok::<(), Box<dyn std::error::Error>>(())
    /// ```
    ///
    /// Note that some parts of the configuration on a DFA can have a
    /// big impact on how big the DFA is, and thus, how much memory is
    /// used. For example, the default setting for [`Config::start_kind`] is
    /// [`StartKind::Both`]. But if you only need an anchored search, for
    /// example, then it can be much cheaper to build a DFA that only supports
    /// anchored searches. (Running an unanchored search with it would panic.)
    ///
    /// ```
    /// # if cfg!(miri) { return Ok(()); } // miri takes too long
    /// # if !cfg!(target_pointer_width = "64") { return Ok(()); } // see #1039
    /// use regex_automata::{
    ///     dfa::{dense, Automaton, StartKind},
    ///     Anchored, Input,
    /// };
    ///
    /// // 200KB isn't enough!
    /// dense::Builder::new()
    ///     .configure(dense::Config::new()
    ///         .determinize_size_limit(Some(200_000))
    ///         .start_kind(StartKind::Anchored)
    ///     )
    ///     .build(r"\w{20}")
    ///     .unwrap_err();
    ///
    /// // ... but 300KB probably is!
    /// // (Note that auxiliary storage sizes aren't necessarily stable between
    /// // releases.)
    /// let dfa = dense::Builder::new()
    ///     .configure(dense::Config::new()
    ///         .determinize_size_limit(Some(300_000))
    ///         .start_kind(StartKind::Anchored)
    ///     )
    ///     .build(r"\w{20}")?;
    /// let haystack = "A".repeat(20).into_bytes();
    /// let input = Input::new(&haystack).anchored(Anchored::Yes);
    /// assert!(dfa.try_search_fwd(&input)?.is_some());
    ///
    /// # Ok::<(), Box<dyn std::error::Error>>(())
    /// ```
    pub fn determinize_size_limit(mut self, bytes: Option<usize>) -> Config {
        self.determinize_size_limit = Some(bytes);
        self
    }

    /// Returns whether this configuration has enabled simple state
    /// acceleration.
    pub fn get_accelerate(&self) -> bool {
        self.accelerate.unwrap_or(true)
    }

    /// Returns the prefilter attached to this configuration, if any.
    pub fn get_prefilter(&self) -> Option<&Prefilter> {
        self.pre.as_ref().unwrap_or(&None).as_ref()
    }

    /// Returns whether this configuration has enabled the expensive process
    /// of minimizing a DFA.
    pub fn get_minimize(&self) -> bool {
        self.minimize.unwrap_or(false)
    }

    /// Returns the match semantics set in this configuration.
    pub fn get_match_kind(&self) -> MatchKind {
        self.match_kind.unwrap_or(MatchKind::LeftmostFirst)
    }

    /// Returns the starting state configuration for a DFA.
    pub fn get_starts(&self) -> StartKind {
        self.start_kind.unwrap_or(StartKind::Both)
    }

    /// Returns whether this configuration has enabled anchored starting states
    /// for every pattern in the DFA.
    pub fn get_starts_for_each_pattern(&self) -> bool {
        self.starts_for_each_pattern.unwrap_or(false)
    }

    /// Returns whether this configuration has enabled byte classes or not.
    /// This is typically a debugging oriented option, as disabling it confers
    /// no speed benefit.
    pub fn get_byte_classes(&self) -> bool {
        self.byte_classes.unwrap_or(true)
    }

    /// Returns whether this configuration has enabled heuristic Unicode word
    /// boundary support. When enabled, it is possible for a search to return
    /// an error.
    pub fn get_unicode_word_boundary(&self) -> bool {
        self.unicode_word_boundary.unwrap_or(false)
    }

    /// Returns whether this configuration will instruct the DFA to enter a
    /// quit state whenever the given byte is seen during a search. When at
    /// least one byte has this enabled, it is possible for a search to return
    /// an error.
    pub fn get_quit(&self, byte: u8) -> bool {
        self.quitset.map_or(false, |q| q.contains(byte))
    }

    /// Returns whether this configuration will instruct the DFA to
    /// "specialize" start states. When enabled, the DFA will mark start states
    /// as "special" so that search routines using the DFA can detect when
    /// it's in a start state and do some kind of optimization (like run a
    /// prefilter).
    pub fn get_specialize_start_states(&self) -> bool {
        self.specialize_start_states.unwrap_or(false)
    }

    /// Returns the DFA size limit of this configuration if one was set.
    /// The size limit is total number of bytes on the heap that a DFA is
    /// permitted to use. If the DFA exceeds this limit during construction,
    /// then construction is stopped and an error is returned.
    pub fn get_dfa_size_limit(&self) -> Option<usize> {
        self.dfa_size_limit.unwrap_or(None)
    }

    /// Returns the determinization size limit of this configuration if one
    /// was set. The size limit is total number of bytes on the heap that
    /// determinization is permitted to use. If determinization exceeds this
    /// limit during construction, then construction is stopped and an error is
    /// returned.
    ///
    /// This is different from the DFA size limit in that this only applies to
    /// the auxiliary storage used during determinization. Once determinization
    /// is complete, this memory is freed.
    ///
    /// The limit on the total heap memory used is the sum of the DFA and
    /// determinization size limits.
    pub fn get_determinize_size_limit(&self) -> Option<usize> {
        self.determinize_size_limit.unwrap_or(None)
    }

    /// Overwrite the default configuration such that the options in `o` are
    /// always used. If an option in `o` is not set, then the corresponding
    /// option in `self` is used. If it's not set in `self` either, then it
    /// remains not set.
    pub(crate) fn overwrite(&self, o: Config) -> Config {
        Config {
            accelerate: o.accelerate.or(self.accelerate),
            pre: o.pre.or_else(|| self.pre.clone()),
            minimize: o.minimize.or(self.minimize),
            match_kind: o.match_kind.or(self.match_kind),
            start_kind: o.start_kind.or(self.start_kind),
            starts_for_each_pattern: o
                .starts_for_each_pattern
                .or(self.starts_for_each_pattern),
            byte_classes: o.byte_classes.or(self.byte_classes),
            unicode_word_boundary: o
                .unicode_word_boundary
                .or(self.unicode_word_boundary),
            quitset: o.quitset.or(self.quitset),
            specialize_start_states: o
                .specialize_start_states
                .or(self.specialize_start_states),
            dfa_size_limit: o.dfa_size_limit.or(self.dfa_size_limit),
            determinize_size_limit: o
                .determinize_size_limit
                .or(self.determinize_size_limit),
        }
    }
}

/// A builder for constructing a deterministic finite automaton from regular
/// expressions.
///
/// This builder provides two main things:
///
/// 1. It provides a few different `build` routines for actually constructing
/// a DFA from different kinds of inputs. The most convenient is
/// [`Builder::build`], which builds a DFA directly from a pattern string. The
/// most flexible is [`Builder::build_from_nfa`], which builds a DFA straight
/// from an NFA.
/// 2. The builder permits configuring a number of things.
/// [`Builder::configure`] is used with [`Config`] to configure aspects of
/// the DFA and the construction process itself. [`Builder::syntax`] and
/// [`Builder::thompson`] permit configuring the regex parser and Thompson NFA
/// construction, respectively. The syntax and thompson configurations only
/// apply when building from a pattern string.
///
/// This builder always constructs a *single* DFA. As such, this builder
/// can only be used to construct regexes that either detect the presence
/// of a match or find the end location of a match. A single DFA cannot
/// produce both the start and end of a match. For that information, use a
/// [`Regex`](crate::dfa::regex::Regex), which can be similarly configured
/// using [`regex::Builder`](crate::dfa::regex::Builder). The main reason to
/// use a DFA directly is if the end location of a match is enough for your use
/// case. Namely, a `Regex` will construct two DFAs instead of one, since a
/// second reverse DFA is needed to find the start of a match.
///
/// Note that if one wants to build a sparse DFA, you must first build a dense
/// DFA and convert that to a sparse DFA. There is no way to build a sparse
/// DFA without first building a dense DFA.
///
/// # Example
///
/// This example shows how to build a minimized DFA that completely disables
/// Unicode. That is:
///
/// * Things such as `\w`, `.` and `\b` are no longer Unicode-aware. `\w`
///   and `\b` are ASCII-only while `.` matches any byte except for `\n`
///   (instead of any UTF-8 encoding of a Unicode scalar value except for
///   `\n`). Things that are Unicode only, such as `\pL`, are not allowed.
/// * The pattern itself is permitted to match invalid UTF-8. For example,
///   things like `[^a]` that match any byte except for `a` are permitted.
///
/// ```
/// use regex_automata::{
///     dfa::{Automaton, dense},
///     util::syntax,
///     HalfMatch, Input,
/// };
///
/// let dfa = dense::Builder::new()
///     .configure(dense::Config::new().minimize(false))
///     .syntax(syntax::Config::new().unicode(false).utf8(false))
///     .build(r"foo[^b]ar.*")?;
///
/// let haystack = b"\xFEfoo\xFFar\xE2\x98\xFF\n";
/// let expected = Some(HalfMatch::must(0, 10));
/// let got = dfa.try_search_fwd(&Input::new(haystack))?;
/// assert_eq!(expected, got);
///
/// # Ok::<(), Box<dyn std::error::Error>>(())
/// ```
#[cfg(feature = "dfa-build")]
#[derive(Clone, Debug)]
pub struct Builder {
    config: Config,
    #[cfg(feature = "syntax")]
    thompson: thompson::Compiler,
}

#[cfg(feature = "dfa-build")]
impl Builder {
    /// Create a new dense DFA builder with the default configuration.
    pub fn new() -> Builder {
        Builder {
            config: Config::default(),
            #[cfg(feature = "syntax")]
            thompson: thompson::Compiler::new(),
        }
    }

    /// Build a DFA from the given pattern.
    ///
    /// If there was a problem parsing or compiling the pattern, then an error
    /// is returned.
    #[cfg(feature = "syntax")]
    pub fn build(&self, pattern: &str) -> Result<OwnedDFA, BuildError> {
        self.build_many(&[pattern])
    }

    /// Build a DFA from the given patterns.
    ///
    /// When matches are returned, the pattern ID corresponds to the index of
    /// the pattern in the slice given.
    #[cfg(feature = "syntax")]
    pub fn build_many<P: AsRef<str>>(
        &self,
        patterns: &[P],
    ) -> Result<OwnedDFA, BuildError> {
        let nfa = self
            .thompson
            .clone()
            // We can always forcefully disable captures because DFAs do not
            // support them.
            .configure(
                thompson::Config::new()
                    .which_captures(thompson::WhichCaptures::None),
            )
            .build_many(patterns)
            .map_err(BuildError::nfa)?;
        self.build_from_nfa(&nfa)
    }

    /// Build a DFA from the given NFA.
    ///
    /// # Example
    ///
    /// This example shows how to build a DFA if you already have an NFA in
    /// hand.
    ///
    /// ```
    /// use regex_automata::{
    ///     dfa::{Automaton, dense},
    ///     nfa::thompson::NFA,
    ///     HalfMatch, Input,
    /// };
    ///
    /// let haystack = "foo123bar".as_bytes();
    ///
    /// // This shows how to set non-default options for building an NFA.
    /// let nfa = NFA::compiler()
    ///     .configure(NFA::config().shrink(true))
    ///     .build(r"[0-9]+")?;
    /// let dfa = dense::Builder::new().build_from_nfa(&nfa)?;
    /// let expected = Some(HalfMatch::must(0, 6));
    /// let got = dfa.try_search_fwd(&Input::new(haystack))?;
    /// assert_eq!(expected, got);
    ///
    /// # Ok::<(), Box<dyn std::error::Error>>(())
    /// ```
    pub fn build_from_nfa(
        &self,
        nfa: &thompson::NFA,
    ) -> Result<OwnedDFA, BuildError> {
        let mut quitset = self.config.quitset.unwrap_or(ByteSet::empty());
        if self.config.get_unicode_word_boundary()
            && nfa.look_set_any().contains_word_unicode()
        {
            for b in 0x80..=0xFF {
                quitset.add(b);
            }
        }
        let classes = if !self.config.get_byte_classes() {
            // DFAs will always use the equivalence class map, but enabling
            // this option is useful for debugging. Namely, this will cause all
            // transitions to be defined over their actual bytes instead of an
            // opaque equivalence class identifier. The former is much easier
            // to grok as a human.
            ByteClasses::singletons()
        } else {
            let mut set = nfa.byte_class_set().clone();
            // It is important to distinguish any "quit" bytes from all other
            // bytes. Otherwise, a non-quit byte may end up in the same
            // class as a quit byte, and thus cause the DFA to stop when it
            // shouldn't.
            //
            // Test case:
            //
            //   regex-cli find match dense --unicode-word-boundary \
            //     -p '^#' -p '\b10\.55\.182\.100\b' -y @conn.json.1000x.log
            if !quitset.is_empty() {
                set.add_set(&quitset);
            }
            set.byte_classes()
        };

        let mut dfa = DFA::initial(
            classes,
            nfa.pattern_len(),
            self.config.get_starts(),
            nfa.look_matcher(),
            self.config.get_starts_for_each_pattern(),
            self.config.get_prefilter().map(|p| p.clone()),
            quitset,
            Flags::from_nfa(&nfa),
        )?;
        determinize::Config::new()
            .match_kind(self.config.get_match_kind())
            .quit(quitset)
            .dfa_size_limit(self.config.get_dfa_size_limit())
            .determinize_size_limit(self.config.get_determinize_size_limit())
            .run(nfa, &mut dfa)?;
        if self.config.get_minimize() {
            dfa.minimize();
        }
        if self.config.get_accelerate() {
            dfa.accelerate();
        }
        // The state shuffling done before this point always assumes that start
        // states should be marked as "special," even though it isn't the
        // default configuration. State shuffling is complex enough as it is,
        // so it's simpler to just "fix" our special state ID ranges to not
        // include starting states after-the-fact.
        if !self.config.get_specialize_start_states() {
            dfa.special.set_no_special_start_states();
        }
        // Look for and set the universal starting states.
        dfa.set_universal_starts();
        Ok(dfa)
    }

    /// Apply the given dense DFA configuration options to this builder.
    pub fn configure(&mut self, config: Config) -> &mut Builder {
        self.config = self.config.overwrite(config);
        self
    }

    /// Set the syntax configuration for this builder using
    /// [`syntax::Config`](crate::util::syntax::Config).
    ///
    /// This permits setting things like case insensitivity, Unicode and multi
    /// line mode.
    ///
    /// These settings only apply when constructing a DFA directly from a
    /// pattern.
    #[cfg(feature = "syntax")]
    pub fn syntax(
        &mut self,
        config: crate::util::syntax::Config,
    ) -> &mut Builder {
        self.thompson.syntax(config);
        self
    }

    /// Set the Thompson NFA configuration for this builder using
    /// [`nfa::thompson::Config`](crate::nfa::thompson::Config).
    ///
    /// This permits setting things like whether the DFA should match the regex
    /// in reverse or if additional time should be spent shrinking the size of
    /// the NFA.
    ///
    /// These settings only apply when constructing a DFA directly from a
    /// pattern.
    #[cfg(feature = "syntax")]
    pub fn thompson(&mut self, config: thompson::Config) -> &mut Builder {
        self.thompson.configure(config);
        self
    }
}

#[cfg(feature = "dfa-build")]
impl Default for Builder {
    fn default() -> Builder {
        Builder::new()
    }
}

/// A convenience alias for an owned DFA. We use this particular instantiation
/// a lot in this crate, so it's worth giving it a name. This instantiation
/// is commonly used for mutable APIs on the DFA while building it. The main
/// reason for making DFAs generic is no_std support, and more generally,
/// making it possible to load a DFA from an arbitrary slice of bytes.
#[cfg(feature = "alloc")]
pub(crate) type OwnedDFA = DFA<alloc::vec::Vec<u32>>;

/// A dense table-based deterministic finite automaton (DFA).
///
/// All dense DFAs have one or more start states, zero or more match states
/// and a transition table that maps the current state and the current byte
/// of input to the next state. A DFA can use this information to implement
/// fast searching. In particular, the use of a dense DFA generally makes the
/// trade off that match speed is the most valuable characteristic, even if
/// building the DFA may take significant time *and* space. (More concretely,
/// building a DFA takes time and space that is exponential in the size of the
/// pattern in the worst case.) As such, the processing of every byte of input
/// is done with a small constant number of operations that does not vary with
/// the pattern, its size or the size of the alphabet. If your needs don't line
/// up with this trade off, then a dense DFA may not be an adequate solution to
/// your problem.
///
/// In contrast, a [`sparse::DFA`] makes the opposite
/// trade off: it uses less space but will execute a variable number of
/// instructions per byte at match time, which makes it slower for matching.
/// (Note that space usage is still exponential in the size of the pattern in
/// the worst case.)
///
/// A DFA can be built using the default configuration via the
/// [`DFA::new`] constructor. Otherwise, one can
/// configure various aspects via [`dense::Builder`](Builder).
///
/// A single DFA fundamentally supports the following operations:
///
/// 1. Detection of a match.
/// 2. Location of the end of a match.
/// 3. In the case of a DFA with multiple patterns, which pattern matched is
///    reported as well.
///
/// A notable absence from the above list of capabilities is the location of
/// the *start* of a match. In order to provide both the start and end of
/// a match, *two* DFAs are required. This functionality is provided by a
/// [`Regex`](crate::dfa::regex::Regex).
///
/// # Type parameters
///
/// A `DFA` has one type parameter, `T`, which is used to represent state IDs,
/// pattern IDs and accelerators. `T` is typically a `Vec<u32>` or a `&[u32]`.
///
/// # The `Automaton` trait
///
/// This type implements the [`Automaton`] trait, which means it can be used
/// for searching. For example:
///
/// ```
/// use regex_automata::{dfa::{Automaton, dense::DFA}, HalfMatch, Input};
///
/// let dfa = DFA::new("foo[0-9]+")?;
/// let expected = HalfMatch::must(0, 8);
/// assert_eq!(Some(expected), dfa.try_search_fwd(&Input::new("foo12345"))?);
/// # Ok::<(), Box<dyn std::error::Error>>(())
/// ```
#[derive(Clone)]
pub struct DFA<T> {
    /// The transition table for this DFA. This includes the transitions
    /// themselves, along with the stride, number of states and the equivalence
    /// class mapping.
    tt: TransitionTable<T>,
    /// The set of starting state identifiers for this DFA. The starting state
    /// IDs act as pointers into the transition table. The specific starting
    /// state chosen for each search is dependent on the context at which the
    /// search begins.
    st: StartTable<T>,
    /// The set of match states and the patterns that match for each
    /// corresponding match state.
    ///
    /// This structure is technically only needed because of support for
    /// multi-regexes. Namely, multi-regexes require answering not just whether
    /// a match exists, but _which_ patterns match. So we need to store the
    /// matching pattern IDs for each match state. We do this even when there
    /// is only one pattern for the sake of simplicity. In practice, this uses
    /// up very little space for the case of one pattern.
    ms: MatchStates<T>,
    /// Information about which states are "special." Special states are states
    /// that are dead, quit, matching, starting or accelerated. For more info,
    /// see the docs for `Special`.
    special: Special,
    /// The accelerators for this DFA.
    ///
    /// If a state is accelerated, then there exist only a small number of
    /// bytes that can cause the DFA to leave the state. This permits searching
    /// to use optimized routines to find those specific bytes instead of using
    /// the transition table.
    ///
    /// All accelerated states exist in a contiguous range in the DFA's
    /// transition table. See dfa/special.rs for more details on how states are
    /// arranged.
    accels: Accels<T>,
    /// Any prefilter attached to this DFA.
    ///
    /// Note that currently prefilters are not serialized. When deserializing
    /// a DFA from bytes, this is always set to `None`.
    pre: Option<Prefilter>,
    /// The set of "quit" bytes for this DFA.
    ///
    /// This is only used when computing the start state for a particular
    /// position in a haystack. Namely, in the case where there is a quit
    /// byte immediately before the start of the search, this set needs to be
    /// explicitly consulted. In all other cases, quit bytes are detected by
    /// the DFA itself, by transitioning all quit bytes to a special "quit
    /// state."
    quitset: ByteSet,
    /// Various flags describing the behavior of this DFA.
    flags: Flags,
}

#[cfg(feature = "dfa-build")]
impl OwnedDFA {
    /// Parse the given regular expression using a default configuration and
    /// return the corresponding DFA.
    ///
    /// If you want a non-default configuration, then use the
    /// [`dense::Builder`](Builder) to set your own configuration.
    ///
    /// # Example
    ///
    /// ```
    /// use regex_automata::{dfa::{Automaton, dense}, HalfMatch, Input};
    ///
    /// let dfa = dense::DFA::new("foo[0-9]+bar")?;
    /// let expected = Some(HalfMatch::must(0, 11));
    /// assert_eq!(expected, dfa.try_search_fwd(&Input::new("foo12345bar"))?);
    /// # Ok::<(), Box<dyn std::error::Error>>(())
    /// ```
    #[cfg(feature = "syntax")]
    pub fn new(pattern: &str) -> Result<OwnedDFA, BuildError> {
        Builder::new().build(pattern)
    }

    /// Parse the given regular expressions using a default configuration and
    /// return the corresponding multi-DFA.
    ///
    /// If you want a non-default configuration, then use the
    /// [`dense::Builder`](Builder) to set your own configuration.
    ///
    /// # Example
    ///
    /// ```
    /// use regex_automata::{dfa::{Automaton, dense}, HalfMatch, Input};
    ///
    /// let dfa = dense::DFA::new_many(&["[0-9]+", "[a-z]+"])?;
    /// let expected = Some(HalfMatch::must(1, 3));
    /// assert_eq!(expected, dfa.try_search_fwd(&Input::new("foo12345bar"))?);
    /// # Ok::<(), Box<dyn std::error::Error>>(())
    /// ```
    #[cfg(feature = "syntax")]
    pub fn new_many<P: AsRef<str>>(
        patterns: &[P],
    ) -> Result<OwnedDFA, BuildError> {
        Builder::new().build_many(patterns)
    }
}

#[cfg(feature = "dfa-build")]
impl OwnedDFA {
    /// Create a new DFA that matches every input.
    ///
    /// # Example
    ///
    /// ```
    /// use regex_automata::{dfa::{Automaton, dense}, HalfMatch, Input};
    ///
    /// let dfa = dense::DFA::always_match()?;
    ///
    /// let expected = Some(HalfMatch::must(0, 0));
    /// assert_eq!(expected, dfa.try_search_fwd(&Input::new(""))?);
    /// assert_eq!(expected, dfa.try_search_fwd(&Input::new("foo"))?);
    /// # Ok::<(), Box<dyn std::error::Error>>(())
    /// ```
    pub fn always_match() -> Result<OwnedDFA, BuildError> {
        let nfa = thompson::NFA::always_match();
        Builder::new().build_from_nfa(&nfa)
    }

    /// Create a new DFA that never matches any input.
    ///
    /// # Example
    ///
    /// ```
    /// use regex_automata::{dfa::{Automaton, dense}, Input};
    ///
    /// let dfa = dense::DFA::never_match()?;
    /// assert_eq!(None, dfa.try_search_fwd(&Input::new(""))?);
    /// assert_eq!(None, dfa.try_search_fwd(&Input::new("foo"))?);
    /// # Ok::<(), Box<dyn std::error::Error>>(())
    /// ```
    pub fn never_match() -> Result<OwnedDFA, BuildError> {
        let nfa = thompson::NFA::never_match();
        Builder::new().build_from_nfa(&nfa)
    }

    /// Create an initial DFA with the given equivalence classes, pattern
    /// length and whether anchored starting states are enabled for each
    /// pattern. An initial DFA can be further mutated via determinization.
    fn initial(
        classes: ByteClasses,
        pattern_len: usize,
        starts: StartKind,
        lookm: &LookMatcher,
        starts_for_each_pattern: bool,
        pre: Option<Prefilter>,
        quitset: ByteSet,
        flags: Flags,
    ) -> Result<OwnedDFA, BuildError> {
        let start_pattern_len =
            if starts_for_each_pattern { Some(pattern_len) } else { None };
        Ok(DFA {
            tt: TransitionTable::minimal(classes),
            st: StartTable::dead(starts, lookm, start_pattern_len)?,
            ms: MatchStates::empty(pattern_len),
            special: Special::new(),
            accels: Accels::empty(),
            pre,
            quitset,
            flags,
        })
    }
}

#[cfg(feature = "dfa-build")]
impl DFA<&[u32]> {
    /// Return a new default dense DFA compiler configuration.
    ///
    /// This is a convenience routine to avoid needing to import the [`Config`]
    /// type when customizing the construction of a dense DFA.
    pub fn config() -> Config {
        Config::new()
    }

    /// Create a new dense DFA builder with the default configuration.
    ///
    /// This is a convenience routine to avoid needing to import the
    /// [`Builder`] type in common cases.
    pub fn builder() -> Builder {
        Builder::new()
    }
}

impl<T: AsRef<[u32]>> DFA<T> {
    /// Cheaply return a borrowed version of this dense DFA. Specifically,
    /// the DFA returned always uses `&[u32]` for its transition table.
    pub fn as_ref(&self) -> DFA<&'_ [u32]> {
        DFA {
            tt: self.tt.as_ref(),
            st: self.st.as_ref(),
            ms: self.ms.as_ref(),
            special: self.special,
            accels: self.accels(),
            pre: self.pre.clone(),
            quitset: self.quitset,
            flags: self.flags,
        }
    }

    /// Return an owned version of this sparse DFA. Specifically, the DFA
    /// returned always uses `Vec<u32>` for its transition table.
    ///
    /// Effectively, this returns a dense DFA whose transition table lives on
    /// the heap.
    #[cfg(feature = "alloc")]
    pub fn to_owned(&self) -> OwnedDFA {
        DFA {
            tt: self.tt.to_owned(),
            st: self.st.to_owned(),
            ms: self.ms.to_owned(),
            special: self.special,
            accels: self.accels().to_owned(),
            pre: self.pre.clone(),
            quitset: self.quitset,
            flags: self.flags,
        }
    }

    /// Returns the starting state configuration for this DFA.
    ///
    /// The default is [`StartKind::Both`], which means the DFA supports both
    /// unanchored and anchored searches. However, this can generally lead to
    /// bigger DFAs. Therefore, a DFA might be compiled with support for just
    /// unanchored or anchored searches. In that case, running a search with
    /// an unsupported configuration will panic.
    pub fn start_kind(&self) -> StartKind {
        self.st.kind
    }

    /// Returns the start byte map used for computing the `Start` configuration
    /// at the beginning of a search.
    pub(crate) fn start_map(&self) -> &StartByteMap {
        &self.st.start_map
    }

    /// Returns true only if this DFA has starting states for each pattern.
    ///
    /// When a DFA has starting states for each pattern, then a search with the
    /// DFA can be configured to only look for anchored matches of a specific
    /// pattern. Specifically, APIs like [`Automaton::try_search_fwd`] can
    /// accept a non-None `pattern_id` if and only if this method returns true.
    /// Otherwise, calling `try_search_fwd` will panic.
    ///
    /// Note that if the DFA has no patterns, this always returns false.
    pub fn starts_for_each_pattern(&self) -> bool {
        self.st.pattern_len.is_some()
    }

    /// Returns the equivalence classes that make up the alphabet for this DFA.
    ///
    /// Unless [`Config::byte_classes`] was disabled, it is possible that
    /// multiple distinct bytes are grouped into the same equivalence class
    /// if it is impossible for them to discriminate between a match and a
    /// non-match. This has the effect of reducing the overall alphabet size
    /// and in turn potentially substantially reducing the size of the DFA's
    /// transition table.
    ///
    /// The downside of using equivalence classes like this is that every state
    /// transition will automatically use this map to convert an arbitrary
    /// byte to its corresponding equivalence class. In practice this has a
    /// negligible impact on performance.
    pub fn byte_classes(&self) -> &ByteClasses {
        &self.tt.classes
    }

    /// Returns the total number of elements in the alphabet for this DFA.
    ///
    /// That is, this returns the total number of transitions that each state
    /// in this DFA must have. Typically, a normal byte oriented DFA would
    /// always have an alphabet size of 256, corresponding to the number of
    /// unique values in a single byte. However, this implementation has two
    /// peculiarities that impact the alphabet length:
    ///
    /// * Every state has a special "EOI" transition that is only followed
    /// after the end of some haystack is reached. This EOI transition is
    /// necessary to account for one byte of look-ahead when implementing
    /// things like `\b` and `$`.
    /// * Bytes are grouped into equivalence classes such that no two bytes in
    /// the same class can distinguish a match from a non-match. For example,
    /// in the regex `^[a-z]+$`, the ASCII bytes `a-z` could all be in the
    /// same equivalence class. This leads to a massive space savings.
    ///
    /// Note though that the alphabet length does _not_ necessarily equal the
    /// total stride space taken up by a single DFA state in the transition
    /// table. Namely, for performance reasons, the stride is always the
    /// smallest power of two that is greater than or equal to the alphabet
    /// length. For this reason, [`DFA::stride`] or [`DFA::stride2`] are
    /// often more useful. The alphabet length is typically useful only for
    /// informational purposes.
    pub fn alphabet_len(&self) -> usize {
        self.tt.alphabet_len()
    }

    /// Returns the total stride for every state in this DFA, expressed as the
    /// exponent of a power of 2. The stride is the amount of space each state
    /// takes up in the transition table, expressed as a number of transitions.
    /// (Unused transitions map to dead states.)
    ///
    /// The stride of a DFA is always equivalent to the smallest power of 2
    /// that is greater than or equal to the DFA's alphabet length. This
    /// definition uses extra space, but permits faster translation between
    /// premultiplied state identifiers and contiguous indices (by using shifts
    /// instead of relying on integer division).
    ///
    /// For example, if the DFA's stride is 16 transitions, then its `stride2`
    /// is `4` since `2^4 = 16`.
    ///
    /// The minimum `stride2` value is `1` (corresponding to a stride of `2`)
    /// while the maximum `stride2` value is `9` (corresponding to a stride of
    /// `512`). The maximum is not `8` since the maximum alphabet size is `257`
    /// when accounting for the special EOI transition. However, an alphabet
    /// length of that size is exceptionally rare since the alphabet is shrunk
    /// into equivalence classes.
    pub fn stride2(&self) -> usize {
        self.tt.stride2
    }

    /// Returns the total stride for every state in this DFA. This corresponds
    /// to the total number of transitions used by each state in this DFA's
    /// transition table.
    ///
    /// Please see [`DFA::stride2`] for more information. In particular, this
    /// returns the stride as the number of transitions, where as `stride2`
    /// returns it as the exponent of a power of 2.
    pub fn stride(&self) -> usize {
        self.tt.stride()
    }

    /// Returns the memory usage, in bytes, of this DFA.
    ///
    /// The memory usage is computed based on the number of bytes used to
    /// represent this DFA.
    ///
    /// This does **not** include the stack size used up by this DFA. To
    /// compute that, use `std::mem::size_of::<dense::DFA>()`.
    pub fn memory_usage(&self) -> usize {
        self.tt.memory_usage()
            + self.st.memory_usage()
            + self.ms.memory_usage()
            + self.accels.memory_usage()
    }
}

/// Routines for converting a dense DFA to other representations, such as
/// sparse DFAs or raw bytes suitable for persistent storage.
impl<T: AsRef<[u32]>> DFA<T> {
    /// Convert this dense DFA to a sparse DFA.
    ///
    /// If a `StateID` is too small to represent all states in the sparse
    /// DFA, then this returns an error. In most cases, if a dense DFA is
    /// constructable with `StateID` then a sparse DFA will be as well.
    /// However, it is not guaranteed.
    ///
    /// # Example
    ///
    /// ```
    /// use regex_automata::{dfa::{Automaton, dense}, HalfMatch, Input};
    ///
    /// let dense = dense::DFA::new("foo[0-9]+")?;
    /// let sparse = dense.to_sparse()?;
    ///
    /// let expected = Some(HalfMatch::must(0, 8));
    /// assert_eq!(expected, sparse.try_search_fwd(&Input::new("foo12345"))?);
    /// # Ok::<(), Box<dyn std::error::Error>>(())
    /// ```
    #[cfg(feature = "dfa-build")]
    pub fn to_sparse(&self) -> Result<sparse::DFA<Vec<u8>>, BuildError> {
        sparse::DFA::from_dense(self)
    }

    /// Serialize this DFA as raw bytes to a `Vec<u8>` in little endian
    /// format. Upon success, the `Vec<u8>` and the initial padding length are
    /// returned.
    ///
    /// The written bytes are guaranteed to be deserialized correctly and
    /// without errors in a semver compatible release of this crate by a
    /// `DFA`'s deserialization APIs (assuming all other criteria for the
    /// deserialization APIs has been satisfied):
    ///
    /// * [`DFA::from_bytes`]
    /// * [`DFA::from_bytes_unchecked`]
    ///
    /// The padding returned is non-zero if the returned `Vec<u8>` starts at
    /// an address that does not have the same alignment as `u32`. The padding
    /// corresponds to the number of leading bytes written to the returned
    /// `Vec<u8>`.
    ///
    /// # Example
    ///
    /// This example shows how to serialize and deserialize a DFA:
    ///
    /// ```
    /// use regex_automata::{dfa::{Automaton, dense::DFA}, HalfMatch, Input};
    ///
    /// // Compile our original DFA.
    /// let original_dfa = DFA::new("foo[0-9]+")?;
    ///
    /// // N.B. We use native endianness here to make the example work, but
    /// // using to_bytes_little_endian would work on a little endian target.
    /// let (buf, _) = original_dfa.to_bytes_native_endian();
    /// // Even if buf has initial padding, DFA::from_bytes will automatically
    /// // ignore it.
    /// let dfa: DFA<&[u32]> = DFA::from_bytes(&buf)?.0;
    ///
    /// let expected = Some(HalfMatch::must(0, 8));
    /// assert_eq!(expected, dfa.try_search_fwd(&Input::new("foo12345"))?);
    /// # Ok::<(), Box<dyn std::error::Error>>(())
    /// ```
    #[cfg(feature = "dfa-build")]
    pub fn to_bytes_little_endian(&self) -> (Vec<u8>, usize) {
        self.to_bytes::<wire::LE>()
    }

    /// Serialize this DFA as raw bytes to a `Vec<u8>` in big endian
    /// format. Upon success, the `Vec<u8>` and the initial padding length are
    /// returned.
    ///
    /// The written bytes are guaranteed to be deserialized correctly and
    /// without errors in a semver compatible release of this crate by a
    /// `DFA`'s deserialization APIs (assuming all other criteria for the
    /// deserialization APIs has been satisfied):
    ///
    /// * [`DFA::from_bytes`]
    /// * [`DFA::from_bytes_unchecked`]
    ///
    /// The padding returned is non-zero if the returned `Vec<u8>` starts at
    /// an address that does not have the same alignment as `u32`. The padding
    /// corresponds to the number of leading bytes written to the returned
    /// `Vec<u8>`.
    ///
    /// # Example
    ///
    /// This example shows how to serialize and deserialize a DFA:
    ///
    /// ```
    /// use regex_automata::{dfa::{Automaton, dense::DFA}, HalfMatch, Input};
    ///
    /// // Compile our original DFA.
    /// let original_dfa = DFA::new("foo[0-9]+")?;
    ///
    /// // N.B. We use native endianness here to make the example work, but
    /// // using to_bytes_big_endian would work on a big endian target.
    /// let (buf, _) = original_dfa.to_bytes_native_endian();
    /// // Even if buf has initial padding, DFA::from_bytes will automatically
    /// // ignore it.
    /// let dfa: DFA<&[u32]> = DFA::from_bytes(&buf)?.0;
    ///
    /// let expected = Some(HalfMatch::must(0, 8));
    /// assert_eq!(expected, dfa.try_search_fwd(&Input::new("foo12345"))?);
    /// # Ok::<(), Box<dyn std::error::Error>>(())
    /// ```
    #[cfg(feature = "dfa-build")]
    pub fn to_bytes_big_endian(&self) -> (Vec<u8>, usize) {
        self.to_bytes::<wire::BE>()
    }

    /// Serialize this DFA as raw bytes to a `Vec<u8>` in native endian
    /// format. Upon success, the `Vec<u8>` and the initial padding length are
    /// returned.
    ///
    /// The written bytes are guaranteed to be deserialized correctly and
    /// without errors in a semver compatible release of this crate by a
    /// `DFA`'s deserialization APIs (assuming all other criteria for the
    /// deserialization APIs has been satisfied):
    ///
    /// * [`DFA::from_bytes`]
    /// * [`DFA::from_bytes_unchecked`]
    ///
    /// The padding returned is non-zero if the returned `Vec<u8>` starts at
    /// an address that does not have the same alignment as `u32`. The padding
    /// corresponds to the number of leading bytes written to the returned
    /// `Vec<u8>`.
    ///
    /// Generally speaking, native endian format should only be used when
    /// you know that the target you're compiling the DFA for matches the
    /// endianness of the target on which you're compiling DFA. For example,
    /// if serialization and deserialization happen in the same process or on
    /// the same machine. Otherwise, when serializing a DFA for use in a
    /// portable environment, you'll almost certainly want to serialize _both_
    /// a little endian and a big endian version and then load the correct one
    /// based on the target's configuration.
    ///
    /// # Example
    ///
    /// This example shows how to serialize and deserialize a DFA:
    ///
    /// ```
    /// use regex_automata::{dfa::{Automaton, dense::DFA}, HalfMatch, Input};
    ///
    /// // Compile our original DFA.
    /// let original_dfa = DFA::new("foo[0-9]+")?;
    ///
    /// let (buf, _) = original_dfa.to_bytes_native_endian();
    /// // Even if buf has initial padding, DFA::from_bytes will automatically
    /// // ignore it.
    /// let dfa: DFA<&[u32]> = DFA::from_bytes(&buf)?.0;
    ///
    /// let expected = Some(HalfMatch::must(0, 8));
    /// assert_eq!(expected, dfa.try_search_fwd(&Input::new("foo12345"))?);
    /// # Ok::<(), Box<dyn std::error::Error>>(())
    /// ```
    #[cfg(feature = "dfa-build")]
    pub fn to_bytes_native_endian(&self) -> (Vec<u8>, usize) {
        self.to_bytes::<wire::NE>()
    }

    /// The implementation of the public `to_bytes` serialization methods,
    /// which is generic over endianness.
    #[cfg(feature = "dfa-build")]
    fn to_bytes<E: Endian>(&self) -> (Vec<u8>, usize) {
        let len = self.write_to_len();
        let (mut buf, padding) = wire::alloc_aligned_buffer::<u32>(len);
        // This should always succeed since the only possible serialization
        // error is providing a buffer that's too small, but we've ensured that
        // `buf` is big enough here.
        self.as_ref().write_to::<E>(&mut buf[padding..]).unwrap();
        (buf, padding)
    }

    /// Serialize this DFA as raw bytes to the given slice, in little endian
    /// format. Upon success, the total number of bytes written to `dst` is
    /// returned.
    ///
    /// The written bytes are guaranteed to be deserialized correctly and
    /// without errors in a semver compatible release of this crate by a
    /// `DFA`'s deserialization APIs (assuming all other criteria for the
    /// deserialization APIs has been satisfied):
    ///
    /// * [`DFA::from_bytes`]
    /// * [`DFA::from_bytes_unchecked`]
    ///
    /// Note that unlike the various `to_byte_*` routines, this does not write
    /// any padding. Callers are responsible for handling alignment correctly.
    ///
    /// # Errors
    ///
    /// This returns an error if the given destination slice is not big enough
    /// to contain the full serialized DFA. If an error occurs, then nothing
    /// is written to `dst`.
    ///
    /// # Example
    ///
    /// This example shows how to serialize and deserialize a DFA without
    /// dynamic memory allocation.
    ///
    /// ```
    /// use regex_automata::{dfa::{Automaton, dense::DFA}, HalfMatch, Input};
    ///
    /// // Compile our original DFA.
    /// let original_dfa = DFA::new("foo[0-9]+")?;
    ///
    /// // Create a 4KB buffer on the stack to store our serialized DFA. We
    /// // need to use a special type to force the alignment of our [u8; N]
    /// // array to be aligned to a 4 byte boundary. Otherwise, deserializing
    /// // the DFA may fail because of an alignment mismatch.
    /// #[repr(C)]
    /// struct Aligned<B: ?Sized> {
    ///     _align: [u32; 0],
    ///     bytes: B,
    /// }
    /// let mut buf = Aligned { _align: [], bytes: [0u8; 4 * (1<<10)] };
    /// // N.B. We use native endianness here to make the example work, but
    /// // using write_to_little_endian would work on a little endian target.
    /// let written = original_dfa.write_to_native_endian(&mut buf.bytes)?;
    /// let dfa: DFA<&[u32]> = DFA::from_bytes(&buf.bytes[..written])?.0;
    ///
    /// let expected = Some(HalfMatch::must(0, 8));
    /// assert_eq!(expected, dfa.try_search_fwd(&Input::new("foo12345"))?);
    /// # Ok::<(), Box<dyn std::error::Error>>(())
    /// ```
    pub fn write_to_little_endian(
        &self,
        dst: &mut [u8],
    ) -> Result<usize, SerializeError> {
        self.as_ref().write_to::<wire::LE>(dst)
    }

    /// Serialize this DFA as raw bytes to the given slice, in big endian
    /// format. Upon success, the total number of bytes written to `dst` is
    /// returned.
    ///
    /// The written bytes are guaranteed to be deserialized correctly and
    /// without errors in a semver compatible release of this crate by a
    /// `DFA`'s deserialization APIs (assuming all other criteria for the
    /// deserialization APIs has been satisfied):
    ///
    /// * [`DFA::from_bytes`]
    /// * [`DFA::from_bytes_unchecked`]
    ///
    /// Note that unlike the various `to_byte_*` routines, this does not write
    /// any padding. Callers are responsible for handling alignment correctly.
    ///
    /// # Errors
    ///
    /// This returns an error if the given destination slice is not big enough
    /// to contain the full serialized DFA. If an error occurs, then nothing
    /// is written to `dst`.
    ///
    /// # Example
    ///
    /// This example shows how to serialize and deserialize a DFA without
    /// dynamic memory allocation.
    ///
    /// ```
    /// use regex_automata::{dfa::{Automaton, dense::DFA}, HalfMatch, Input};
    ///
    /// // Compile our original DFA.
    /// let original_dfa = DFA::new("foo[0-9]+")?;
    ///
    /// // Create a 4KB buffer on the stack to store our serialized DFA. We
    /// // need to use a special type to force the alignment of our [u8; N]
    /// // array to be aligned to a 4 byte boundary. Otherwise, deserializing
    /// // the DFA may fail because of an alignment mismatch.
    /// #[repr(C)]
    /// struct Aligned<B: ?Sized> {
    ///     _align: [u32; 0],
    ///     bytes: B,
    /// }
    /// let mut buf = Aligned { _align: [], bytes: [0u8; 4 * (1<<10)] };
    /// // N.B. We use native endianness here to make the example work, but
    /// // using write_to_big_endian would work on a big endian target.
    /// let written = original_dfa.write_to_native_endian(&mut buf.bytes)?;
    /// let dfa: DFA<&[u32]> = DFA::from_bytes(&buf.bytes[..written])?.0;
    ///
    /// let expected = Some(HalfMatch::must(0, 8));
    /// assert_eq!(expected, dfa.try_search_fwd(&Input::new("foo12345"))?);
    /// # Ok::<(), Box<dyn std::error::Error>>(())
    /// ```
    pub fn write_to_big_endian(
        &self,
        dst: &mut [u8],
    ) -> Result<usize, SerializeError> {
        self.as_ref().write_to::<wire::BE>(dst)
    }

    /// Serialize this DFA as raw bytes to the given slice, in native endian
    /// format. Upon success, the total number of bytes written to `dst` is
    /// returned.
    ///
    /// The written bytes are guaranteed to be deserialized correctly and
    /// without errors in a semver compatible release of this crate by a
    /// `DFA`'s deserialization APIs (assuming all other criteria for the
    /// deserialization APIs has been satisfied):
    ///
    /// * [`DFA::from_bytes`]
    /// * [`DFA::from_bytes_unchecked`]
    ///
    /// Generally speaking, native endian format should only be used when
    /// you know that the target you're compiling the DFA for matches the
    /// endianness of the target on which you're compiling DFA. For example,
    /// if serialization and deserialization happen in the same process or on
    /// the same machine. Otherwise, when serializing a DFA for use in a
    /// portable environment, you'll almost certainly want to serialize _both_
    /// a little endian and a big endian version and then load the correct one
    /// based on the target's configuration.
    ///
    /// Note that unlike the various `to_byte_*` routines, this does not write
    /// any padding. Callers are responsible for handling alignment correctly.
    ///
    /// # Errors
    ///
    /// This returns an error if the given destination slice is not big enough
    /// to contain the full serialized DFA. If an error occurs, then nothing
    /// is written to `dst`.
    ///
    /// # Example
    ///
    /// This example shows how to serialize and deserialize a DFA without
    /// dynamic memory allocation.
    ///
    /// ```
    /// use regex_automata::{dfa::{Automaton, dense::DFA}, HalfMatch, Input};
    ///
    /// // Compile our original DFA.
    /// let original_dfa = DFA::new("foo[0-9]+")?;
    ///
    /// // Create a 4KB buffer on the stack to store our serialized DFA. We
    /// // need to use a special type to force the alignment of our [u8; N]
    /// // array to be aligned to a 4 byte boundary. Otherwise, deserializing
    /// // the DFA may fail because of an alignment mismatch.
    /// #[repr(C)]
    /// struct Aligned<B: ?Sized> {
    ///     _align: [u32; 0],
    ///     bytes: B,
    /// }
    /// let mut buf = Aligned { _align: [], bytes: [0u8; 4 * (1<<10)] };
    /// let written = original_dfa.write_to_native_endian(&mut buf.bytes)?;
    /// let dfa: DFA<&[u32]> = DFA::from_bytes(&buf.bytes[..written])?.0;
    ///
    /// let expected = Some(HalfMatch::must(0, 8));
    /// assert_eq!(expected, dfa.try_search_fwd(&Input::new("foo12345"))?);
    /// # Ok::<(), Box<dyn std::error::Error>>(())
    /// ```
    pub fn write_to_native_endian(
        &self,
        dst: &mut [u8],
    ) -> Result<usize, SerializeError> {
        self.as_ref().write_to::<wire::NE>(dst)
    }

    /// Return the total number of bytes required to serialize this DFA.
    ///
    /// This is useful for determining the size of the buffer required to pass
    /// to one of the serialization routines:
    ///
    /// * [`DFA::write_to_little_endian`]
    /// * [`DFA::write_to_big_endian`]
    /// * [`DFA::write_to_native_endian`]
    ///
    /// Passing a buffer smaller than the size returned by this method will
    /// result in a serialization error. Serialization routines are guaranteed
    /// to succeed when the buffer is big enough.
    ///
    /// # Example
    ///
    /// This example shows how to dynamically allocate enough room to serialize
    /// a DFA.
    ///
    /// ```
    /// use regex_automata::{dfa::{Automaton, dense::DFA}, HalfMatch, Input};
    ///
    /// let original_dfa = DFA::new("foo[0-9]+")?;
    ///
    /// let mut buf = vec![0; original_dfa.write_to_len()];
    /// // This is guaranteed to succeed, because the only serialization error
    /// // that can occur is when the provided buffer is too small. But
    /// // write_to_len guarantees a correct size.
    /// let written = original_dfa.write_to_native_endian(&mut buf).unwrap();
    /// // But this is not guaranteed to succeed! In particular,
    /// // deserialization requires proper alignment for &[u32], but our buffer
    /// // was allocated as a &[u8] whose required alignment is smaller than
    /// // &[u32]. However, it's likely to work in practice because of how most
    /// // allocators work. So if you write code like this, make sure to either
    /// // handle the error correctly and/or run it under Miri since Miri will
    /// // likely provoke the error by returning Vec<u8> buffers with alignment
    /// // less than &[u32].
    /// let dfa: DFA<&[u32]> = match DFA::from_bytes(&buf[..written]) {
    ///     // As mentioned above, it is legal for an error to be returned
    ///     // here. It is quite difficult to get a Vec<u8> with a guaranteed
    ///     // alignment equivalent to Vec<u32>.
    ///     Err(_) => return Ok(()),
    ///     Ok((dfa, _)) => dfa,
    /// };
    ///
    /// let expected = Some(HalfMatch::must(0, 8));
    /// assert_eq!(expected, dfa.try_search_fwd(&Input::new("foo12345"))?);
    /// # Ok::<(), Box<dyn std::error::Error>>(())
    /// ```
    ///
    /// Note that this example isn't actually guaranteed to work! In
    /// particular, if `buf` is not aligned to a 4-byte boundary, then the
    /// `DFA::from_bytes` call will fail. If you need this to work, then you
    /// either need to deal with adding some initial padding yourself, or use
    /// one of the `to_bytes` methods, which will do it for you.
    pub fn write_to_len(&self) -> usize {
        wire::write_label_len(LABEL)
        + wire::write_endianness_check_len()
        + wire::write_version_len()
        + size_of::<u32>() // unused, intended for future flexibility
        + self.flags.write_to_len()
        + self.tt.write_to_len()
        + self.st.write_to_len()
        + self.ms.write_to_len()
        + self.special.write_to_len()
        + self.accels.write_to_len()
        + self.quitset.write_to_len()
    }
}

impl<'a> DFA<&'a [u32]> {
    /// Safely deserialize a DFA with a specific state identifier
    /// representation. Upon success, this returns both the deserialized DFA
    /// and the number of bytes read from the given slice. Namely, the contents
    /// of the slice beyond the DFA are not read.
    ///
    /// Deserializing a DFA using this routine will never allocate heap memory.
    /// For safety purposes, the DFA's transition table will be verified such
    /// that every transition points to a valid state. If this verification is
    /// too costly, then a [`DFA::from_bytes_unchecked`] API is provided, which
    /// will always execute in constant time.
    ///
    /// The bytes given must be generated by one of the serialization APIs
    /// of a `DFA` using a semver compatible release of this crate. Those
    /// include:
    ///
    /// * [`DFA::to_bytes_little_endian`]
    /// * [`DFA::to_bytes_big_endian`]
    /// * [`DFA::to_bytes_native_endian`]
    /// * [`DFA::write_to_little_endian`]
    /// * [`DFA::write_to_big_endian`]
    /// * [`DFA::write_to_native_endian`]
    ///
    /// The `to_bytes` methods allocate and return a `Vec<u8>` for you, along
    /// with handling alignment correctly. The `write_to` methods do not
    /// allocate and write to an existing slice (which may be on the stack).
    /// Since deserialization always uses the native endianness of the target
    /// platform, the serialization API you use should match the endianness of
    /// the target platform. (It's often a good idea to generate serialized
    /// DFAs for both forms of endianness and then load the correct one based
    /// on endianness.)
    ///
    /// # Errors
    ///
    /// Generally speaking, it's easier to state the conditions in which an
    /// error is _not_ returned. All of the following must be true:
    ///
    /// * The bytes given must be produced by one of the serialization APIs
    ///   on this DFA, as mentioned above.
    /// * The endianness of the target platform matches the endianness used to
    ///   serialized the provided DFA.
    /// * The slice given must have the same alignment as `u32`.
    ///
    /// If any of the above are not true, then an error will be returned.
    ///
    /// # Panics
    ///
    /// This routine will never panic for any input.
    ///
    /// # Example
    ///
    /// This example shows how to serialize a DFA to raw bytes, deserialize it
    /// and then use it for searching.
    ///
    /// ```
    /// use regex_automata::{dfa::{Automaton, dense::DFA}, HalfMatch, Input};
    ///
    /// let initial = DFA::new("foo[0-9]+")?;
    /// let (bytes, _) = initial.to_bytes_native_endian();
    /// let dfa: DFA<&[u32]> = DFA::from_bytes(&bytes)?.0;
    ///
    /// let expected = Some(HalfMatch::must(0, 8));
    /// assert_eq!(expected, dfa.try_search_fwd(&Input::new("foo12345"))?);
    /// # Ok::<(), Box<dyn std::error::Error>>(())
    /// ```
    ///
    /// # Example: dealing with alignment and padding
    ///
    /// In the above example, we used the `to_bytes_native_endian` method to
    /// serialize a DFA, but we ignored part of its return value corresponding
    /// to padding added to the beginning of the serialized DFA. This is OK
    /// because deserialization will skip this initial padding. What matters
    /// is that the address immediately following the padding has an alignment
    /// that matches `u32`. That is, the following is an equivalent but
    /// alternative way to write the above example://
    /// ```
    /// use regex_automata::{dfa::{Automaton, dense::DFA}, HalfMatch, Input};
    ///
    /// let initial = DFA::new("foo[0-9]+")?;
    /// let (b   /// ```
    pub fn alwautomata::{ HalfMaaute:DFA::from    ///
   elf,
    butine witarts at
    ot `8` t we ignored = init elf,
      initial.to_bytes_native_endian();
    /// let dfa: DFA<&[u32]> = DFA::from_bytes(&bytes)?.0;
    ///
    /// let expected = Some(HalfMatch::must(0, 8));
    /// assert_eq!(expected, dfa.try_search_fwd(&Input::new("foo123rn va = DFA::te towed
    ing
    RA<&    /aualld lib thas convalence cla_endiuirebe r///    ///obhe e/// letcur oThe by::write_toOk::<(valence cd::error::Etack to sto
    // li1urnow,whose requirs immecode ltipl for you, along

    /ed as a &[diannes by::write_to
    /eetheed! ding. What matterss prope> &Bying state conf` = Note s`]
  ose require. Oth seriali:from_bytes_unchecked`] Aerializget pdiuil skip this initA's
    /// t  + wire::wase of this cratec[u32].ndices (by using ll oen ses, te //d// Passing ansitio
    ais DFA.
    / Howediagramon intege'sdefaultn seriad::error: ///
  ts_uncheckezed correctlat t- this execause al striian(&e e/// DFA:o    /// trbytes lld f this crate = DFA::new("fon. Th
  tsup so
    /// bPassing ansitio
t()
 A, butecked`]
    //ut thisig enhis execause alWe/ // snever beginble.  we  al strfiraller than
 we ufor mely, the cer of by, thefi is, the following is ano_runn equivalent but
    /// altenativte the abo ///
    /// ```
    //, HalfMatch, Input};
    ///
    /// // Compile ourmata::{ HalfM /// let orig)?);
    //orrect size.
 W matches deserialhe overall  */// # E*aw bytes to a `Vec<u.alizing
   !(efs* [`DFAInput.)?)
    /. //", it elf,
      i/
    /// // Compile Dome iagainhe aboed to :frase o   /// portab. // Compile ourmata::{ HalfM /// let orig)?);
    /// #orrect size  !(efs* [`DFAInput.)?);
 
    /. //", it elf,
      i/
    ///8));
    /// assert_eq!(expected, dfa.try_search_fwd(&Input::new("foo123An. 
    / bPa)
  
 we ufore //ddhe cer of byclasses`]   / Howediagrame
    ///
   lignment of ome iatu wr :fra    irallent
    /// )
    ///alis DFA.
    / H Input
   hoosegood idea to mentation of the following is ano_runn equivalent but
    /// alteless than &[u3native way to write the aboveess than &[u3t tlivelazy::Lazy,     wi> {
 Asveess than &[u3example://
    /valent to Vec<u32>.
    ///  123rn vaeseriadiannessd theown "lazy"4KB b, d co let 's
iri will
    azy_ndiaic!FA. Foce_cellivsync::Lazyy serme i4-byeginbno- alon")?;
    ///
o-eq!   /// the s"fon. l endiusat matche/ Retf om   /l eee_endian();
  ///  ely .alizing
   iaic RE: Lazy<   + s  iaic ns, such= Lazytch, I|| less than &[u3#en a [ _: &str = "trf oify! less than &[u32].rn va[`DFgnment formaes :alloc_al(ian(icitly) via f this crate&[u32].CoerceUns * Theraitturn valuew   /// that can    /ed!his crate&[u32].total numbal_df
      /// Tness  special type to Yary, then t&[u32].*FA<&*A:o    //mpleo andn will automat + selfea toy, then t&[u32]./// to padding icult to get a  iaic ALIGNED: &> {
 As<r>>(( e::w = &> {
 As less than &[u3f an alignmenatch.
    /// # the publiizatioe use na= ")?)"rializing
         : [u32;* APIs
 et ori!Input.)?)
    /. //")tch.
    /// # the publiizatioe use na= ")?);
 "rializing
         : [u32;* APIs
 et ori!Input.)?);
 
    /. //")tch.
    /// #tes: B,
   &[u3#etes: B,
   &[u3#e  iaic ALIGNED: &> {
 As<r>>(( e::w = &> {
 As less than &[u3#3f an alignmenatch.
    /// ##     : [u32;natch.
    /// ## Vec<u32>.
    ///  ytes<E: E alignm` t we ignored = iniALIGNED[0u8; 4alizing
         .tes)?.("Passing ansitioses thebee DFA'");ess than &[u3natalent to V)tial.to_bytes_native_endian();
  Ok(  /// let dfa: DFA<&[u32]>  = DFA::from_bytes(&bytes)?.0;
 RE///
    /// let expected = Some(HalfMatc = DFA::fro(&Input::new("foo123Anlignment
    
  [`t tlivlazy::Lazy`]ed for::t tlivlazy::Lazy) This is OK
[` azy_ndiaic`]ehttps://d fors.io/d fors/ azy_ndiaic) _to_len()];[`Foce_cell`]ehttps://d fors.io/d fors/Foce_cell)ing statdiannesalizing
    one id// that can(he correctes to h, Inputfunc -> (Vfrom_bipl for you,costly,d Foce).3An. `Foce_cell`  ose`
    ///adiannessda in t()
    }

  use     APIy sermby:Lazy`ytes_naon succ vaeseria  /ed as aeral  inFA.
    ///
 . Otheircum /aucesendian version and then loadbutlldl the se  }

  es to h, Input and paalways ,ndary, then tdded tt then    /// // rrec[`> {
 As`]ed for::t tliv    wi> {
 As) correspondick `u32`.ffer on tidea to ding. Whahe aboed tofor //  DFA:o returned.
  `   /// partidded / * [`DFor handlingalwagh
  tsw onepadding yoursgnored = in_endian(
 rm m: &self.>(())
    /// ```
  (   + self.acceianness.,. Namely, tto_native_endian(
 HalAFETY:urn value //  ing
    wee DFA'ianness.t of a power of 2._unch_endian(
 Har of 2. nativdense De env
   ould &[ubelow.ed DFA.
 DFA'ianputfails,_endian(
 Harintewe / * [`DFor hand. to_bytes<E: E align from` tun //  { ransition points to a val( rm m)? Vec<u32&[u3natused DFA'ian(&nat i/
    &[u3natused DFA'ian(&nat i/
    &[u3natumsd DFA'ian(&nat i/
    &[u3natu)
      DFA'ian( i/
    &[u3 /// }
 natusate a 4 con), B  /// e/// DFA:o  to a val./// to padding ,_endian(
 Hasome iial pl froyserial DFA'iand. to_bytesample in thisnatusense (.
    #[cfg(an(
 HaIfrite_to`ria  /annv
   _to`rion intege the endiane clasemp:write_versd
    //
   ould &.rite_versd
  ingnatuis_/
   _ndiae( transidy_s
    #[cfg(an(
ytes<E:  coexlfM ////
   ould &_ coex( transidy_s;   #[cfg(an(
yteshat
coexl>=3natu)
     ial.w
    #[cfg(an(
ytesssss/ * [`D Vec Namely, tto_nat::/// The(   #[cfg(an(
ytesssssssssometyp length doeOk::<in DFA's/
   ould &t
coex",   #[cfg(an(
ytesssss_s;   #[cfg(an(
ytes}   #[cfg(an(
ytes<E: n   l t =3natu)
     n   l t(
coexs;   #[cfg(an(
yteshat!(1 <= n   l t ial.w
&& n   l t ial.w
<= 3w
    #[cfg(an(
ytesssss/ * [`D Vec Namely, tto_nat::/// The(   #[cfg(an(
ytessssssssso/
   ould &tn   l t //
    DFA's>` in ",   #[cfg(an(
ytesssss_s;   #[cfg(an(
ytes}   #[cfg(an(
}   #[cfg(}   #[cfg(  // align from
    ) -> Result<D       + self.quitset.write_to_len()
    }
}

impA<&'a [u32]> {
\b` and `$`.n a [`DFA::frd. Alm?);he cer ole will be vee overa DFA'::wae over corresponds
    /// to tDe eno
    'iaa
   iber of re::NE>(dst)
    }

    /// Reral he coer criteria for the,ting foege  // on-match. Th/ * [`
    ///
    /y.
    xhib thecode inFhebendiindling thends
    /// to tD  /// Tn between
   DFA's tranion uses ext. any of the above are not true/ Return tis not aligneo
        + self.quicre ne_endian();a spaanthat fampdness.t of a power of 
 DFA'ianputtride sned. urned.
  `   /// part with `StateID` then a sparse DFA will be as well.
    /// However, it is not guaranteed.
    ///
 t for searching.
    ///
    /// ```
    /// use regex_automata::{dfa::{Automaton, dense::DFA}, HalfMatch, Input};
    ///
    /// let initial = DFA HalAFETY:urn valueer of bytes writt //  adding) =   /// error c //ian(&mut buf)iork. Soalence en must be is useful for determirovoke the error by returning Vecun //  { ransition points to a val(, _) = ini Vec<u32>.
    ///     Err(_) => return Ok(()),
    ///     Ok((dfa, _)) => dfa,
    /// };
    ///
    /// let expected = Some(HalfMatch::must(0, 8));
    /// assert_eq!(expected, dfa.try_search_fwd(&Input:g youn //  ursgnored = is to a val(_endian(
 rm m: &self.>(())
    /// ```
  (   + self.acceianness.,. Namely, tto_native_endian(
tch, Inpnr = 0;
_endian(
nr +Vec<u8>,to t_ Input}_ `Vec<u( rm m); `to_bytes` met&self)ding. Wha   hen thi is rm m[nr    i/
    an(
nr +Vec<u8>, fro whichis rm m[nr   ,  do iti/
    an(
nr +Vec<u8>, fro ite_to_len(&selfis rm m[nr    i/
    an(
nr +Vec<u8>, fro ite_labis rm m[nr   , VERSION i/
_endian(
tch,_ndiann(Vec<u8>,//
  fro .acis rm m[nr   , "ndiann( grea" i/
    an(
nr +Ve     + wire::wri/
_endian(
tch,(()
  ign from` tF)
   ignored = ini rm m[nr    i/
    an(
nr +Ven fro/
_endian(
tch,(ttign from` tT of a powT of sition points to a val(, rm m[nr    i/
    an(
nr +Ven fro/
_endian(
tch,(stign from` tSunchT of sition points to a val(, rm m[nr    i/
    an(
nr +Ven fro/
_endian(
tch,(m ign from` t)),
 hen tssition points to a val(, rm m[nr    i/
    an(
nr +Ven fro/
_endian(
tch,(sate a ign from` tSate a  ignored = ini rm m[nr    i/
    an(
nr +Ven fro/
"dfa-builden()
  DFA'ian_ndiaecial.sedial.won nk
    // i/
_endian(
tch,()
    ign from` tA
    sition points to a val(, rm m[nr    i/
    an(
nr +Ven fro/
_endian(
tch,(      +ign from` tBoinSet ignored = ini rm m[nr    i/
    an(
nr +Ven fro/
_endian(
/ * re ignmeVec<), Bsupault is useful for, so
  eyt yod writeab[u32. to_bytes<E: p_byteNone;   #[cfg(  //.qui{ ttigstigm igsate a ig)
    igp_b,       +ig()
   }ign )n to_bytes_native_endian(&self) -> (Vec<u8>, usize)e and retu self.to_bytes::<wire::NE>()
    }

    /// The implementation of thest)
    }

    /// Rde inFheVfromranteed to /// Cturn binthas    /   / H Input
:from_byturself, or  /// which i Ok::<(), Box<dyn std::e Inprror::Error>>(())
    /// ```
    pub fn write_to_native_endian(
<E: nt matc= "dfa-build")]
    fn to_bytesingnst ial.w
< nt matc    #[cfg(an(
/ * [`D VecSmely, tto_nat:: it un")]o_ &[u3("t all sta"_s;   #[cfg(}yn std::erro = & Inprro[..nt mat]/
_endian(
tch, Inpnw = 0;
    an(
nw +Vec<u8>,hods, whichl do i, & Inprro[nw    i/
    an(
nw +Vec<u8>,hods, ite_to_len(&selft we've ensrro[nw    i/
    an(
nw +Vec<u8>,hods, ite_labt we'vVERSION, & Inprro[nw    i/
    an(
nw +Ve    #[cfg(an(
 HaCurrelfromndianness_check_len()
        + wire::write_verset a >,hods, .aci0, & Inprro[nw    ;   #[cfg(an(
     + wire::wri   #[cfg(}/
    an(
nw +Ven_len()
        + st we've ensrro[nw    i/
    an(
nw +Ve/ unused, intendt we've ensrro[nw    i/
    an(
nw +Ve/ unused, intendt we've ensrro[nw    i/
    an(
nw +Ve/ unum       + st we've ensrro[nw    i/
    an(
nw +Ve/ unu_len()
        +t we've ensrro[nw    i/
    an(
nw +Ve/ unu)
        + selt we've ensrro[nw    i/
    an(
nw +Ve/ unu      + self.spet we've ensrro[nw    i/
    an(
  /nwory_usage()
 l strfeasier to n a `Veian(&self, In of 
ize retur`write_s_chr/aliDFA<&'a [u32]> {
  ///
 retuAmut bh  ///mral  ix immedirallKB bup ofmtal y, th
padding
 ::w` addinga /// The `esentations, su`s configurpl nuf, In > {
  We
atec[ne, it /// tset.ed tot buf = vec = o_big_endre_s_chr/alze a DFAeseriaretu We
 `. Tclu    romnann(durf om  rse
   -> (Vec<u8>re::N public `to_bytes` serializatiian( OwnFh.qui{w("foo123Add// Punchs tranid by onere::NE>(d, ued for)turs  +_Punch_ndiae( Ok::<(),  ensBox<dyn std::eato _df
sento _df
dyn std::ePunch:tSunchdyn std::eid:tSun thi())
        #[cfg( => df!(/ unusedis_ DFA'(idwon"   DFA's trchs tran" ;   #[cfg(/ unused  +_Punch(ato _df
2._unchessd ;   #[ -> Result<ustuccess, thit of a poweroby onere::/ aA with `   / as ra`retu en ts> Result<mral pl froysing a:NE>(d, ued for)turs  +_t of a pow( Ok::<(),  ensBox<dyn std::e   /:tSun thi())
      : [u: plphhict iUInp())
      pettSun thi())
        #[cfg(/ unused  +(   /gn: [uon o ;   #[ -> Result<A`DFor mp:ws trani(agth doeOned {ulart of a powst iniy, thediniyth do)endian();a sp/ * [`D theon uses exal str  }
}

impA<&DFA::from_er of bytes wvalence cla_eurposh handyno
    ing alignmtranslized the provided DF/// sergth doeOs theing A::fSun thi::LIMIT` guaranteesponsible forors
    ///
 :NE>(d, ued for)tursF//_ mp:w_ndiae(  ensBox<  /// ```
  Sun thi([cfg(feature = "dfa-buil unusedF//_ mp:w_ndiae(
    ) -> Result<uwapness.twovdense Ds, thi This rt of a power of . any of the above are not true configur:o reyndn wi
   heorigod idea tof the serirified suchswapte that unmral ssiblen    /e
    dense Durposn wi
  id1;a spid2native endianupdeseriapt thralizat:NE>(d, ued for)turs wap_sense (  ensBox<d id1ttSun thi(pid2ttSun thi      #[cfg(/ unused wap(id1(pid2 ;   #[ -> Result<Remapnaking, it's tranion uses exti ThislizeErrocidedn wi
  it'smapdst)
    }unc -> (s, thturn valAPIs
 s{ulart of a powste enved tt`
  ignmtran between
 n uses ext. any , ued for)tursremap(  ensBox<d map:eian( Fn(Sun thi  ///Sun thi      #[cfg(.
 Wd id theloop implemativdense ID;a spaaed 'remap_sense'   //; 4 * (1<<an(
 Hari /// Rin tf)iork.:Reral mapn /// For safety p)iork. Sturn v (1<<an(
 Harechnis big mighur:o ro   /// pxor [u8] wadding) = plphhicts>` in  (1<<an(
 Ha  /ed as a /// // liit's t   /he aboing addrest
coeeriaverisu  we_endian(
 Hases thebeto ma] whdyn st ix it. to_bytesamplei
    / unusedr of _ en().e re_ en()e    #[cfg(an(
*ei
 ec<up(*ei
s;   #[cfg(}yn std::eamplei
    / unusedr of _ en().e re_ en()e    #[cfg(an(
*ei
 ec<up(*ei
s;   #[cfg(}yn st -> Result<Remapnis rt of a powsase of tvdense s, thiocidedn wi
  it's}unc -> valence cd, thturn vaaptli  on thtches tapn}unc -> (, te/// For safety pianteed to works, thistg
    //c/ lg  on thor safety pianplaceignment as/
   e over correspotapn}unc -> (se of   //r safety . any , ued for)tursremap_ndiae( Ok::<(),  ensBox<dyn std::eid:tSun thi())
  d::e ap:eian( Fn(Sun thi  ///Sun thi())
        #[cfg(/ unusedremap(idd map ;   #[ -> Result<Truncianness.dense D ThislizeErr self.as_ref(>` in . any of the above are not true configur:o reyndn wi
   heorigod idea tof the serirified suchtruncia {
   that unmral ssiblen    /e
    dense Durposn wi
  trunciae serializedense Delenupdeseriapt thralizat:NE>(d, ued for)turstrunciae_sense (  ensBox<d >` :
    #[cfg(feature = "dfedrrunciae self.write -> Result<Minim SerializeErrianplaceietf omHopcrofendialgoelfhm:NE>(d, ued for)tursminim Se(  ensBox<  fg(featureMinim Sered = SBox< .run(f.write -> Result<Updeses it'smaativdenseup  DFAn ID;mapni// // rrecll odianness:NE>(dst)
    }

    /// Return twintege'sd  rrefit is qumanipulnseumaati ignmtranified such(
    //irative_endian` up  DFAn IDs)ializamapte_to_native_endover correspo<&'a [u32]> {
 nann(lizehappen ine_to_napnte that sel of 
 qumIn > {
::NE>()
  s
    //n` s aligneo
be/c/ lg dn(he cod desehuffl ignmtrani)ased
 time.
    /izat  /// on eu8] wtset.edeotapn}m, tNE>(d, ued for)turs  +_p  DFAn_map( Ok::<(),  ensBox<dyn std::e ap:e&BTreeMap Sun thi([ing
P  DFAnID>>())
    /// ```
  ()([cfg(feature = "dfa-buil unums Ve/ unum   = _tset_map(map i/
    an(
  /()n to_bytes_nativeF co dense D    /ndiane  &[u3    /// letclasloop t of a powste enma] he target
  mialic[ndideses ill b
   ouldty p)urf om   ///:NE>(d, ued for)tursF
   oulde(  ensBox<  fg(feature2].//adte en     dense Dc[nen an e// n
   oulded. to_byteshe
  unuseiaecial.w
<= 2c    #[cfg(an(
/ * [`;   #[cfg(}yg(feature2].Gselfr ///
e/// Fstg
    //a tmpdnessirs/
   ould &sing :alloc_a._endian(
tch, Inp)
    ` tBTreeMaped = Sf.write_to_lenCount///
    /// letn
   ouldedumaati2._unch   //clasmaati/_unch_endian(
 Hadense . to_bytes<E: Endiacmaati2.ndiac_unchesndiacn ///lm` ti0, 0, 0f.write_to_ample in this  unuseiae (.
    #[cfg(an(
ifs<E: turn n
   ) = "transF
   oulde(  unu/ bascl => sy_s
    #[cfg(an(
ytesdebug!(   #[cfg(an(
ytessssso/
   ouldf ometurnlength doe{}: {:?}",   #[cfg(an(
ytesssss transidy_        #(),   #[cfg(an(
ytesssss/
   ,   #[cfg(an(
ytess;   #[cfg(an(
ytes)
     in> df( transidy_ig)
   s;   #[cfg(an(
yteshat  unuis_maati_ndiae( transidy_s
    #[cfg(an(
ytessssscmaati +Ve1;   #[cfg(an(
ytes}    eshat  unuis_Punch_ndiae( transidy_s
    #[cfg(an(
ytesssssc_unch +Ve1;   #[cfg(an(
ytes}    es    #[cfg(an(
ytesssss => df!(!  unuis_//ad_ndiae( transidy_ss;   #[cfg(an(
ytesssss => df!(!  unuis_    _ndiae( transidy_ss;   #[cfg(an(
ytessssscn ///l +Ve1;   #[cfg(an(
ytes}   #[cfg(an(
}   #[cfg(}   #[cfg(ided Dnovdense Dwed {uof 
 qu// n
   oulded,arintewet yodone. to_byteshe
)
     is_ mp:w(.
    #[cfg(an(
/ * [`;   #[cfg(}yto_bytes<E: too small)
    _ure = )
     ial.w/
_endian(
/ *Asremaphis keephendsoriletdense ID;c/ lg  . Odingwet yodone_endian(
 Haseuffl ig,ment asmaphis is mention ast matculart of a powstianteed to an(
 Haleng
    /// a li =  :ala powstletdenses._endian(
tch, Inpasmaphis =<Remappered = SBox< /
_endian(
/ *A Dwes waptdenses,ling alyDelen nativdense   ///aligneo
swapnessir_endian(
/ *p  DFAn ID;listuse th(rmat `
 i-oweveni)
    :o    //liz  rre
  ig_endian(
 Harin;listuse DFor  //rrecwappuof 
map,/
    ///   rre
 g
 origi_endian(
 Ha)),
 hen ts Foceewet yodone. to_bytestch, Inpn= _/// is tVe/ unum  to_map(Box< /
_endian(
/ *Tned {ieckeznerao genendiannes  //ethen
   oulded,aso
  esenative enan(
/ *er of bytes wr, itTh
 r panvarioustes_n[ubelow.   #[cfg(/ unuslen()
 minl)
   ` tSun thi::MAX;   #[cfg(/ unuslen()
 maxl)
   ` tSun thi::ZEROn to_bytes<E: updese_slen()
l)
   `    #[cfg(an(
|slen()
r::ErroSate a ig)
   _id:tSun thi|s    #[cfg(an(
ytesslen()
 minl)
   ` tcmpedmin(slen()
 minl)
   ig)
   _ids;   #[cfg(an(
ytesslen()
 maxl)
   ` tcmpedmax(slen()
 maxl)
   ig)
   _ids;   #[cfg(an(
}/
_endian(
/ *Sunch/lizehuffl ign nativdense .3Any. nativdense Des  /ative enan(
/ *n
   ouldedu, itmovlize a DFAeco letit'smaativdenseur lg . to_byteshe
cmaati > 0
&& / unuslen()
 ma/ is (.
    #[cfg(an(
 Ha/ }
 slen()
 {min,max}_/// iec<u8>`/alignupdes ig,madding) =   #[cfg(an(
 Har lg /   /// let nativdense D configurc/ lg . Ods a reclrder ig_endian(
an(
 Halet nativdense Dy. Tc/ lg .
cfg(an(
ytes<E:  Inpn=xt_i
 ec/ unuslen()
 maxl nati;
cfg(an(
ytes<E:  Inpcur_i
 ecn=xt_i
;
cfg(an(
yteswhegexcur_i
 >=(/ unuslen()
 minl nativ{   #[cfg(an(
yteshat<E: turn n
   ) = )
     asmovl(&cur_i
s
    #[cfg(an(
ytesssss)
     in> df(n=xt_i
ig)
   s;   #[cfg(an(
ytes&[u3tpdese_slen()
l)
   (  ensBox<.sate a ign=xt_i
 /
_endian(
  #[cfg(an(
 Ha/o aligneo
 handynox<dynecwappf omeicesl automat IDs._endian(
  #[cfg(an(
he
cur_i
 !ecn=xt_i

    #[cfg(an(
ytesssssan(
/ mapperd wap(Box<d cur_i
ign=xt_i
 /
_endian(
  #[cfg(an(
an(
/ *Swapnp  DFAn IDsormat shoutdenses._endian(
  #[cfg(an(
ytes<E: cur_pids ecn= _/// is  asmovl(&cur_i
s   // `buf` is big   #[cfg(an(
ytes<E: n xt_pids ecn= _/// is  asmovl(&n=xt_i
    // `buf` is big   #[cfg(an(
ytesn= _/// is  in> df(cur_i
ign=xt_pidsuf` is big   #[cfg(an(
ytesn= _/// is  in> df(n=xt_i
igcur_pidsuf` is big   #[cfg(an(
}
big   #[cfg(an(
ytesn=xt_i
 ec/ unutt.prev_ndiaecidyn=xt_i
 /
big   #[cfg(an(
}
big   #[cfg(an(
cur_i
 ec/ unutt.prev_ndiaecidycur_i
s;   #[cfg(an(
}   #[cfg(} _endian(
/ *Tn valuew ed {i //ethendicky
   ///
  b
   ouldty ,s trchs tranv (1<<an(
 Han ///lly c // righurafal y nativdense .3Babove en sen
   oulded_endian(
 Hadense 
 qu// nmaddg tD  //igue
  r lg  ( _align:i //// Ffas* (1<<an(
 Harototal numcod d
    rgth doe*is*en
   oulded)ing s tDelso
keep ig_endian(
 Ha nativand tt`
  ignmtransialic //igue
  r lg sase of tvdusedreray . any an(
/ *Soew   /w  :o ned {iecehuffls.dense Dt bh ///
  tslookstA's
    /: any an(
/  any an(
/ *****DQMMMMAAAAASSSSSSNNNNNNN any an(
/ *****an(
|*****an(
| any an(
/ *****an(
|---------| any an(
/ *****an
   ouldedu tranv (1<<an(
 H   #[cfg(.
 Wned : any an(
/ ***D -ediniyth do any an(
/ ***Q -e     dense any an(
/ ***M -emaativdenseu(y. The n
   oulded) any an(
/ ***A -en ///l ndiannes  /isen
   oulded_endian(
 Ha  S -ePunchs trani(y. The n
   oulded) any an(
/ ***N -en ///l ndiannes  /iseNOTen
   oulded_endian(
 H   #[cfg(.
 Wd ian(&self,   //lizehuffl ignmtrani,   }

    dgenery// Paquedin
an(
an(
 Haletpaie theecwap alWe/sunch/lizlook/ sertcularn ///l ndian 
 qu//ve enan(
/ *n
   ouldederiantewe f co ln   ///swapn tswset.edeoearli  t tt`
  ig_endian(
 Hadense,/
    /// swapnesatswset.edeoearli  t n ///l ndianturn v (1<<an(
 Ha'a [urves it'sc //igue
  t thisty._endian(
 H   #[cfg(.
 Odingwet yodonezlook/ seill b
   ouldedrn ///l ndian , 
   wezlook   #[cfg(.
 ill b
   ouldedrtt`
  ignmtransilizmovhe cer mze a DFA, but we 
an(
an(
 Haletess.den
  ignmtran r lg  (eral he co///movlizn
   ouldedumaati_endian(
 Hadense 
 qu DFAeco letit'smaati ignmtran r lg )._endian(
 H   #[cfg(.
 diceaRin tf)eta How/ntioerelfrpl sate
    /
    /,s e/ rrecdocv (1<<an(
 Hahisnat/slen()
 rs. to_byteshe
cn ///l > 0
    #[cfg(an(
 Haed! n=xt ava Huof 
den
  ign  //cl///l ndian 
amplewappf o.
cfg(an(
ytes<E:  Inpn=xt_Punch_i
 ec/ unuslen()
 minlPunch;
cfg(an(
ytes<E:  Inpcur_i
 ec/ unuto_ndiaecidy  unuseiaecial.w
- 1s;   #[cfg(an(
o[0-9]+")?;
    ///
    /ing amaddingcn ///l > 0.
cfg(an(
ytes<E:  Inpn=xt_n //_i
 e   #[cfg(an(
ytess unutt.n=xt_Punaecidy  unuslen()
 maxlPunch);
cfg(an(
yteswhegexcur_i
 >=(n=xt_n //_i
 {   #[cfg(an(
yteshat<E: turn n
   ) = )
     asmovl(&cur_i
s
    #[cfg(an(
ytesssss/ mapperd wap(Box<d n=xt_Punch_i
d cur_i
uf` is big   #[cfg(an(
/ mapperd wap(Box<d n=xt_n //_i
d cur_i
uf` is big   #[cfg(an(
o[0Keepeed! d
   ould &ttapnupdeseriwset. =  IDsoifg) =   #[cfg(an(
endian(
 Hadense 
///swapperiwed {ulso
n
   oulded. to_bytescfg(an(
yteshat<E: turn n
   2) = )
     asmovl(&n=xt_n //_i
)
    #[cfg(an(
ytesssssan(
)
     in> df(cur_i
ign
   2)f` is big   #[cfg(an(
}
big   #[cfg(an(
yteshat<E: turn n
   2) = )
     asmovl(&n=xt_Punch_i
)
    #[cfg(an(
ytesssssan(
)
     in> df(n=xt_n //_i
d n
   2)f` is big   #[cfg(an(
}
big   #[cfg(an(
ytes)
     in> df(n=xt_Punch_i
d )
   s;   #[cfg(an(
ytes&[u3tpdese_slen()
l)
   (  ensBox<.sate a ign=xt_Punch_i
)f` is big   #[cfg(an(
o[0Our/sunch/r lg  shiftheoneignment aighurnow.   #[cfg(cfg(an(
ytess unuslen()
 minlPunch e   #[cfg(an(
ytesan(
ytess unutt.n=xt_Punaecidy  unuslen()
 minlPunch)f` is big   #[cfg(an(
  unuslen()
 maxlPunch e   #[cfg(an(
ytesan(
ytess unutt.n=xt_Punaecidy  unuslen()
 maxlPunch);
cfg(an(
ytesan(
ytesn=xt_Punch_i
 ec/ unutt.n=xt_Punaecidyn=xt_Punch_i
)f` is big   #[cfg(an(
n=xt_n //_i
 ec/ unutt.n=xt_Punaecidyn=xt_n //_i
)/
big   #[cfg(an(
}
big   #[cfg(an(
o[0-9]+")?;'a ttyendickyhe aboinged! 'n=xt_n //_i
'Fstg
   lso
big   #[cfg(an(
o[0n whicigneo
be/n
   oulded,arinteent as/
   OK
    /A<&[u
big   #[cfg(an(
o[0
    This r:ala pow letcur_i
igso
///aligneo
  rside lit
big   #[cfg(an(
o[0againturn valoop iecet the
    ///
    /al numiannes ///,
big   #[cfg(an(
o[0ing
    whenp)
    `  /// Tntcur_i
igwet yoer of bytes wvalen  #[cfg(an(
o[0ddipe> &B
n=xt_n //_i
 e thi e
cur_i
 / ma Tnt to  lg d.   #[cfg(an(
yteshat!)
       /// Tn_key(&cur_i
s
    #[cfg(an(
ytessssscur_i
 ec/ unutt.prev_ndiaecidycur_i
s;   #[cfg(an(
ytes}   #[cfg(an(
}   #[cfg(}   #[cfg(ideJral he co///didormat shoutdenseshe above en seriam The 
   oulded_endian(
 Hadenchs tranvze a DFA, but we ignored r lg   Tntiniygnored eco. to_byteshe
cdenchs> 0
    #[cfg(an(
 Ha/ }
 slen()
 {min,max}_denchsc<u8>`/alignupdes ig,madding) =   #[cfg(an(
 Har lg /   /// letdenchs tranvz configurc/ lg  ;
    //urpos. Ods    #[cfg(an(
 Ha reclrder ig letdenchs tranvzy. Tc/ lg .
cfg(an(
ytes<E:  Inpn=xt_i
 ec/ unuslen()
 minlPunch;
cfg(an(
ytes<E:  Inpcur_i
 ecn=xt_i
;
cfg(an(
yteswhegexcur_i
 <=
  unuslen()
 maxlPunch {   #[cfg(an(
yteshat<E: turn n
   ) = )
     asmovl(&cur_i
s
    #[cfg(an(
ytesssss/ mapperd wap(Box<d cur_i
ign=xt_i
 /
  #[cfg(an(
ytesssss)
     in> df(n=xt_i
ig)
   s;   #[cfg(an(
ytes&[u3tpdese_slen()
l)
   (  ensBox<.sate a ign=xt_i
 /
big   #[cfg(an(
ytesn=xt_i
 ec/ unutt.n=xt_Punaecidyn=xt_i
 /
big   #[cfg(an(
}
big   #[cfg(an(
cur_i
 ec/ unutt.n=xt_Punaecidycur_i
s;   #[cfg(an(
}   #[cfg(} _endian(
/ *Remapnakint of a powstianed! eErro env=> dfll wil//n` s.
cfg(an(
/ mapperdremap(Box< /
cfg(an(
o[0-9]+"  // `alue c0ing
    b
   ouldty pn an ec/ lg  on th   /// le_endian(
 Ha nativ tranvzornp  DFAnstianteoseg nativdense .3ot
   b
   ouldty _endian(
 Haruwstefal yip thi DFAn mapn deserialietckeznerao gec   ////
    ///
cfg(an(
 Haed!  nativ tranvzaanthat hand. to_bytesBox<.s +_p  DFAn_map(&n= _/// is     // `buf` is big   unuslen()
 s +_max(uf` is big   unuslen()
  DFA'ian( .tes)?.("Pate a 4mtran r lg sases the DFA'ian"uf` is big   unuslen()
   #[cfg(an(
  DFA'ian_ndiaecial.  unuseiaecial.w,s  unuse   //()n to_b        .tes)?.(
big   #[cfg(an(
"Pate a 4mtran r lg sases thebe
  rsis-matiwset.mtran >` in ",   #[cfg(an(
uf` is big  => dfa,
  
  #[cfg(an(
  unuslen()
 )
   _ial.  unuse   /anteed
    #[cfg(.
 Wd a tmpdness    /// letn
   ouldedudense D Titch. Thotalcded_endian(
an(
 Haddding) = p
    `napnte 
t()
 AmIn >f
    e endiacm. (I must be p  #[cfg(ided DmIn >f
    methods ,D theof thy. Tc/ lg ,/
    /uvzaan'tu//ve enan(
an(
 Ha rralerializased!cnid byruet.ent is sndynox   ouldedudense Dw/ve enan(
an(
 Harr(_) => tned {eo
bet be p  #[cfg(too small)
    _ureeed
    #[cfg(" boundariwset.rr(_) =>    /// letn
   ouldedudense ",   #[cfg( /
_endian(
/ *A st inh. Th/ tmpdned! d
   ould & alWe/k foeed! d
   sttapnupdeserve enan(
/ *n 
///shufflsdudense Ddfa: DFso
  env
   ould &[uses the
  ve enan(
/ *tive_endiay, the  //igue
  r lg  inof tvdense ID( grea. (Wth add/ve enan(
/ *n=> df.) to_bytestch, Inpprev: Opdty  hen thi yteNone;   #[cfg(rmat(i
ig)
   s  ///
   st    #[cfg(an(
 => df!(prev.map_or(iven m|p|c/ unutt.n=xt_Punaecidyp) ==ssd s;   #[cfg(an(
prev return i
s;   #[cfg(an(
/ unu)
     add()
   s;   #[cfg(}yn st -> Result<Shuffls.ess.dense D ThislizeErrso
    /tt`
  ignmtrans,umaati_endilizedense Dendnox   ouldedudense Dad {ular  //igue
 :NE>(dst)
    }

 Seesnat/slen()
 rsormat n tf)eta Ht. any , ued for)tursshuffls( Ok::<(),  ensBox<dyn std::e u  /// is : BTreeMap Sun thi([ing
P  DFAnID>>())
    /// ```
  ()([cfg(feature = "dfa-bui
 l strotal numbznd thwritead_ende     dense;a spi /isenhwritePa)
  .   #[cfg(/ unuslen()
     _i
 ec/ unuto_ndiaecidy1 /
cfg(an(
o[0d DFlar,e/ndianer/ rrecd/adte en     dense ,arintewet yodone returnedan(
 Ha rec.quitsthen an erreturnizamat//:NE>(dyteshe
  unuseiaecial.w
<= 2c    #[cfg(an(
  unuslen()
 s +_max(uf` is big an(
/ * [`D  /()n;   #[cfg(}yg(feature2].Coll to dilaed! non-DEADtdenchs tranvz
    ad  rrefit isietcketurnedan(
 Ha  rfirm tned {te th impllapnwset. nativdense .3  /// `cl =>icltate idenan(
 Ha  rse
   -> ,s trchs tranvDc[nebey nativdense .3Babod alignmen idenan(
 Halook-aretyp  ///delag eno /// is try// : [uong statdie thts _unch_endian(
 Hadense oalenc_biplt shoutdenses._endian(
tch, Inpis_Punch: BTreeSet hen thi yteBTreeSeted = Sf.write_to_rmat(Punch_i
d _fMatchis  unuseirt (.
    #[cfg(an(
 HaIfra/tt`
  ign  rfiguuldty purposes, theDEADtdenrion intew/ve enan(
an(
 Hac<), Ben seriaehuffls.itturneeDEADtdenri/isenhwritetstrfiraller tendian(
 Hadensenwset.ID=0 Howewe/ // eral hedianit
bet be p  #[cfg(ietdench_i
 e=eDEADt    #[cfg(an(
ytes  //inue;   #[cfg(an(
}   #[cfg(an(
 => df!(   #[cfg(an(
ytes!/// is    /// Tn_key(&Punch_i
),
big   #[cfg(an(
"{:?}/ise// tha._unch   //at shoutdense,   }

    that tlowed",   #[cfg(an(
ytesPunch_i
d
cfg(an(
ytess;   #[cfg(an(
is_Punch in> df( trch_i
)f` is big }yg(feature2].Wd ian(&self,ehuffl ignry// Paquedinaletpaie theecwap tletdenses._endian(
o not
   ,e/ndiane    /// let//n` s reoerelc ignmtransivia f tir_endian(
/ *IDsoand twappf omer mzc/ lg  on tir*IDs  ///aligneo
/ tmpdne/// _endian(
 Hadwapn///mactico
    /we/ // remap IDs.urneeasmaphis  /// /serirified an(
o[0iook-keep ig_rmatus._endian(
tch, Inpasmaphis =<Remappered = SBox< /
_endian(
/ *Shuffls.maati ignmtrani:NE>(dyteshe
/// is  is_ mp:w(.
    #[cfg(an(
/ unuslen()
 minl nativ=eDEAD;
  #[cfg(an(
  unuslen()
 maxl nativ=eDEAD;
  #[cfg(}    es    #[cfg(an(

 l strotal numbznd // that can    /immedirallKwovdense Der/ rreve enan(
an(
 Hac/adte en     dense ,ae_ente
    StuWe en seed!  nativ tranvz wvalen  #[cfg(.
    / righurafal y    .
cfg(an(
ytes<E:  Inpn=xt_i
 ec/ unuto_ndiaecidy2)f` is big   #[tch, Inpn= _/// is tVeBTreeMaped = Sf.write_to_an(
/ unuslen()
 minl nativ=en=xt_i
;
cfg(an(
ytesrmat(i
igpidsu//
 .// is t    #[cfg(an(
ytes/ mapperd wap(Box<d n=xt_i
igi
 /
big   #[cfg(an(
n= _/// is  in> df(n=xt_i
igpidsuf` is big   #[cfg( HaIfr///swapperi/ Punchs tranon inteupdeseeed!   +    #[cfg(an(
yteshat
s_Punch   /// Tn(&n=xt_i
 
    #[cfg(an(
ytesssss
s_Punch asmovl(&n=xt_i
 ;   #[cfg(an(
ytesssss
s_Punch in> df(i
 /
big   #[cfg(an(
}
big   #[cfg(an(
n=xt_i
 ec/ unutt.n=xt_Punaecidyn=xt_i
 /
big   #[cfg(}
big   #[cfg(/// is tVen= _/// is ;
  #[cfg(an(
  unuslen()
 maxl nativ=ecmpedmax(
cfg(cfg(an(
ytess unuslen()
 minlmaati2   #[cfg(an(
ytess unutt.prev_ndiaecidyn=xt_i
 d
cfg(an(
ytess;   #[cfg(}
_endian(
/ *Shuffls.tt`
  ignmtrans    #[cfg({
cfg(an(
ytes<E:  Inpn=xt_i
 ec/ unuto_ndiaecidy2)f` is big   #[he
  unuslen()
 ma/ is (.
    #[cfg(an(
an(
n=xt_i
 ec/ unutt.n=xt_Punaecidy  unuslen()
 maxl nati /
big   #[cfg(}
big   #[cfg(s unuslen()
 minlPunch een=xt_i
;
cfg(an(
ytesrmati
    
s_Puncht    #[cfg(an(
ytes/ mapperd wap(Box<d n=xt_i
igi
 /
big   #[cfg(an(
n=xt_i
 ec/ unutt.n=xt_Punaecidyn=xt_i
 /
big   #[cfg(}
big   #[cfg(  unuslen()
 maxlPunch eecmpedmax(
cfg(cfg(an(
ytess unuslen()
 minlsunchdyn std::ean(
ytess unutt.prev_ndiaecidyn=xt_i
 d
cfg(an(
ytess;   #[cfg(}
_endian(
/ *Finh. Th/ mapnakint of a powstianed! eEr.
cfg(an(
/ mapperdremap(Box< /
cfg(an(
Box<.s +_p  DFAn_map(&/// is  ?f` is big   unuslen()
 s +_max(uf` is big   unuslen()
  DFA'ian( .tes)?.("Pate a 4mtran r lg sases the DFA'ian"uf` is big   unuslen()
   #[cfg(an(
  DFA'ian_ndiaecial.  unuseiaecial.w,s  unuse   //()n to_b        .tes)?.(
big   #[cfg(an(
"Pate a 4mtran r lg sases thebe
  rsis-matiwset.mtran >` in ",   #[cfg(an(
uf` is big   /()n to_bytes_nativeCheorsod d
    tned {elenuniite_als trchs tranvD(// thato _df
 returned.
  unato _df
),/
   he
 o,s  tseent aslevn sefieldvze a DFA trchs trane providedD :NE>(dst)
    }

 Uniite_als trchs tranvDoccu errte sas awinteent akinp  DFAnstianteendianness of/ndianth look-aretyp
 => dfpowstianteei errtfixom_byturss +_uniite_al_seirt (  ensBox<  fg(feature => dfa,
  6,*Sunch::ial.w,s"rr(_) => 6s trchs  rfiguuldty s"i/
_endian(
tch,Punch_i
 ec|or by  ensOwnFh.qu,   #[cfg(an(
ytesssssan(
)to _df
sento _df
dyn std::e  #[cfg(an(
ytesPunch:tSunch|s    #[cfg(an(

 l slue c0ing
    weeVfromaaed 'Punch'ecode .)
    ///

  #[cfg(an(
o[0dd   }

 ////
    tswsed tucg A:    #[cfg(an(
natusedPunch(ato _df
2._unch .tes)?.(" DFA'sxpects  rfiguuldty "i   #[cfg(}/
    an(
he
  unuseich_d co( .h    nato _df
(.
    #[cfg(an(
letckeo _d` tAto _df
s:Nof` is big   #[tch,ei
 ecPunch_i
(Box<d keo _d,*Sunch::NonWmpdBoin)f` is big   #[he
 i
 e=ePunch_i
(Box<d keo _d,*Sunch::WmpdBoin)yn std::e  #[cfg(&& /i
 e=ePunch_i
(Box<d keo _d,*Sunch::T=xt)yn std::e  #[cfg(&& /i
 e=ePunch_i
(Box<d keo _d,*Sunch::LineLF)yn std::e  #[cfg(&& /i
 e=ePunch_i
(Box<d keo _d,*Sunch::LineCR)yn std::e  #[cfg(&& /i
 e=ePunch_i
(Box<d keo _d,*Sunch::CustomLineTl numiaor)yn std::e  #[{
cfg(cfg(an(
ytess unust.uniite_al_seirt  nato _df
 return si
s;   #[cfg(an(
}   #[cfg(}     an(
he
  unuseich_d co( .h   ato _df
(.
    #[cfg(an(
letckeo _d` tAto _df
s:Ys ;
  #[cfg(an(
tch,ei
 ecPunch_i
(Box<d keo _d,*Sunch::NonWmpdBoin)f` is big   #[he
 i
 e=ePunch_i
(Box<d keo _d,*Sunch::WmpdBoin)yn std::e  #[cfg(&& /i
 e=ePunch_i
(Box<d keo _d,*Sunch::T=xt)yn std::e  #[cfg(&& /i
 e=ePunch_i
(Box<d keo _d,*Sunch::LineLF)yn std::e  #[cfg(&& /i
 e=ePunch_i
(Box<d keo _d,*Sunch::LineCR)yn std::e  #[cfg(&& /i
 e=ePunch_i
(Box<d keo _d,*Sunch::CustomLineTl numiaor)yn std::e  #[{
cfg(cfg(an(
ytess unust.uniite_al_seirt ato _df
 return si
s;   #[cfg(an(
}   #[cfg(}     age()
 lAe Drie:wae o/// The s_chr/alzo_big_enill b
  stf omf byclahr/al :Nian(<esentations, su>y retT>i{w("foo123R * [`Dite_s_foDdfaensBate a 4mtrant. any , ued for)turssate a (&Box<  ///&Sate a [{
cfg(cfg(&  unuslen()
   #[ -> Result<Re* [`Dite_s_foDdfaensBate a 4mtrantializamIn of 
borrow.   #[ public `to_bytes` serializatiany , ued for)turssate a _ en(  ensBox<  ///:ErroSate a [{
cfg(cfg(& ensBox<.sate a    #[ -> Result<Re* [`seent      dE: En. The  mp:w) nann(lizy onere::NE>(d, ued for)turs      +(&Box<  ///&BoinSet[{
cfg(cfg(&  unu      +   #[ -> Result<Re* [`seent ()
   n ine_to_re::NE>(d, ued for)turs()
  (&Box<  ///&F)
  [{
cfg(cfg(&  unu()
     #[ -> Result<Re* [`seavertould &timpleved tt`se D ThislizeEr:NE>(dst)
    }

    ///tould &tyieldvza tuplrase omativdenseal strfiral e(&self,e over corresponuplrative_endiaes, thesense'heon uses ex,/
    //bPa)
  
e(&self and `$`.n ve_endiaes, tit's traniot()
 A(   /ri   //ng thends
    //s). any , ued for)turssense ( Box<  ///hen thtou<'_, Te = "dfa-buil unusedseiae (.   #[ -> Result<Re* [`Dite_tota3    /// lettt`se D ThislizeEr: E/// F of/ndeckeznerao> Result<1s tranone thired emp:wsre::NE>(d, ued for)turs eiaecial. Box<  ///    # = "dfa-buil unusedial.w   #[ -> Result<Re* [`Davertould &timpleved p  DFAn IDsormatn thtches taativ translized the provided Dn thtches denri/isethat t shoutdense, uaranteesppanics.   #[ public `to_bytes` serializatiany , ued for)tursp  DFAn_id_ rm m. Box<,eid:tSun thi  ///&[P  DFAnID]     #[cfg( => df!(/ unuis_maati_ndiae(sd s;   #[cfg(/ unum  p  DFAn_id_ rm m./ unumaati_ndiae_ coex(iom
    ) -> Result<Re* [`Dite_tota3    /// letp  DFAn IDsormatn thtches taativ translized the provided Dn thtches denri/isethat t shoutdense, uaranteesppanics.   #[, ued for)tursmaati_p  DFAn_ial. Box<,eid:tSun thi  ///    # = "dfa-bui => df!(/ unuis_maati_ndiae(sd s;   #[cfg(/ unum  p  DFAn_ial.  unumaati_ndiae_ coex(iom
    ) -> Result<Re* [`sDite_tota3    /// letp  DFAns(/// isn(lizy onere::NE>(d, ued for)tursp  DFAn_ial. Box<  ///    # = "dfa-buil unum  p  DFAn_ial   #[ -> Result<Re* [`seaotapn}lencmaativdenseuIDs, thelist letp  DFAn IDso
    /aati_endilize Thisatv translized public `to_bytes` serializatiany , ued for)tursp  DFAn_map(&Box<  ///BTreeMap Sun thi([ing
P  DFAnID>> = "dfa-buil unum  to_map(Box<     ) -> Result<Re* [`sDite_IDsgnored      dense;n ine_to_re::NE>(d public `to_bytes` serializatiany , ued for)turs    _i
( Box<  ///hen thD = "dfa-buil unuso_ndiaecidy1  to_bytes_nativeC rre
 gn thtches denri/i }
}

impA, tit's tran'st
coexal stritran's_endilize Toexln ve_endiaes, tit's:ala pow dd   }

 hdynppeaxti Thisthor safety  correspon of .rianteehappeiseNOTepre `
 itli d,arintehesense'heon uses ex rified suchulso
 theocoexalianteehappeisepre `
 itli d,arintehesense'heon uses ex This is OK
equalze a` Toexl* plphhict_ial`.e are not trueie trscan    :NE>(d, ued for)tursto_ coex( Box<,eid:tSun thi  ///    # = "dfa-bui = "dfedro_ coex(iom to_bytes_nativeC rre
 gaverToexl, thesense ( Thisthr lg  0..  unuseiaecial.w)se DFofied suchux<dynecenri/i }
}

imp:NE>(dst)
    }

    /// Return twinteetf omadding
T>`ializn efficit istapnkeysn(liz trane provideriae  / e
    s_formldty p(t bh aliza/ mappedvdenseuID):NE>(d public `to_bytes` serializatiany , ued for)tursso_ndiaecidy Box<,eiToex:
    #[c///hen thD = "dfa-buil unustuso_ndiaecidy
coexs    ) -> Result<Re* [`Dite_t of 
letdense ID  n ine_to_re:'ss trchs tranv:NE>(d, ued for)turs eirt ( Box<  ///henrthen thtou<'_> = "dfa-buil unust.rtou(     ) -> Result<Re* [`sDite_rToexlletit'smaativdenseurmatn thtches ID.ed Dn td to works, thihD  configurcive_endiay, the shoutdense, uaranteespn. d to workpaniczornpreturnizn    method as/
  :NE>(d publ_  Dric `to_bytestrid-inltru",eiTltru(nhwrit)atiany ursmaati_ndiae_ coex( Box<,eid:tSun thi  ///    # = "dfa-buidebug_ => df!(/ unuis_maati_ndiae(sd s;   #[cfg(

    /// Rone Vec<u8>,laceuew ed {we / ly/// a lifux<o
    /aati_endian(
 Hadense oelen  //igue
   This rt of a power of . Names ,D    /imm   #[cfg(.
 iiral maativdenseuIDsnhwriten ve_endiaes, tnatusate a  minlmaati._endian(
o nFn succ //; st
   ,e//
    /'s t   /hewe/ //    /uanness.implved (1<<an(
 Hahioexlletany. nativdensess, thitt'smaativdense'ssID._endian(
tch, in ec/ unuslen()
() minlmaati.       #().write_to_lenCORRECTNESS: Wet yod loweds, tpreturnizn    method as/
  zornp nic,_endian(
 HasombaA with subndso powe
    //b to a val.hen thD   rse
   -> (rified an(
o[0OK. "dfa-buil unuso_ coex(Sun thi::n= _ to a val(id.       #() -emin)     ) -> Result<Re* [`sDite_rToexlletit'sd
   ould &tdenseurmatn thtches ID.ed Dn td to works, thihD  configurcive_endiay, thnsd
   ould &tdense, uaranteespn. d to workpaniczornpreturnizn    method as/
  :NE>(dfnsd
   ould &_ coex( Box<,eid:tSun thi  ///    # = "dfa-buitch, in ec/ unuslen()
() minld
   .       #().write_to_lenCORRECTNESS: Wet yod loweds, tpreturnizn    method as/
  zornp nic,_endian(
 HasombaA with subndso powe
    //b to a val.hen thD   rse
   -> (rified an(
o[0OK. "dfa-buil unuso_ coex(Sun thi::n= _ to a val(id.       #() -emin)     ) -> Result<Re* [`Dite_v
   ould &[un ine_to_re::NE>(dfnsd
    ( Box<  ///A
    turning V= "dfa-buil unu)
     as_ref(.   #[ -> Result<Re* [`Ditto_re:'ssnds
    /// to tDelizasrm m:NE>(dfnsnds
 (&Box<  ///&[Sun thi] = "dfa-buil unustusto t(ory_usage()ian(<esentations, su>yfmt::Debugun in retT>i{w("fours(mt( Box<,efby  ensfmt::Formldtou<'_>  ///fmt:: ```
  = "dfa-buit matln!(<,e"///
 t for(" i/
    an(
ample in this  unuseiae (.
    #[cfg(an(
fmt_ndiae_ coll bor(<,eBox<,e transidy_s?;
  #[cfg(an(
tch,i
 ecif nu)lahr/aan( [{
cfg(cfg(an(
ytesstransidy_        #()
cfg(an(
ytes}    es    #[cfg(an(
ytesl unuso_ coex( transidy_s   #[cfg(an(
}/
cfg(an(
ytesw mat!(<,e"{:06?}: "igi
 ?;
  #[cfg(an(
 trans(mt(f ?;
  #[cfg(an(
w mat!(<,e"\n" i/
    an(
} "dfa-buit matln!(<,e"" i/
    an(
ampl(i,t(Punch_i
d ato _df
2._uy)tchis  unuseirt (..e   oulde(.
    #[cfg(an(
letci
 ecif nu)lahr/aan( [{
cfg(cfg(an(
ytesstrch_i
        #()
cfg(an(
ytes}    es    #[cfg(an(
ytesl unuso_ coex( trch_i
)   #[cfg(an(
}/
cfg(an(
yteshat
 %(/ unused t   / e=e0s    #[cfg(an(
ytes nativano _df
     #[cfg(an(
ytesssssAto _df
s:No =>it matln!(<,e"START-GROUP(unato _df
)" i,   #[cfg(an(
ytesssssAto _df
s:Ys tV>it matln!(<,e"START-GROUP(ato _df
)" i,   #[cfg(an(
ytesssssAto _df
s:P  DFAn(pi
 
=>
    #[cfg(an(
ytesssssan(
t matln!(<,e"START_GROUP(p  DFAn: {:?})"igpid)?` is big   #[cfg(an(
}
big   #[cfg(an(
}
big   #[cfg(}
big   #[cfg(t matln!(<,e"  {:?}
=>
 :06?}"2._uyigi
 ?;
  #[cfg(}     an(
he
  unup  DFAn_ial.) > 1
    #[cfg(an(
t matln!(<,e"" i/
    an(
ytesrmatichis0..  unum  ial.w
    #[cfg(an(
ytesletci
 ec  unum  maati_ndiae_ 
(Box<d i /
big   #[cfg(an(
letci
 ecif nu)lahr/aan( [{
cfg(cfg(an(
ytesan(
h
        #()
cfg(an(
ytesytes}    es    #[cfg(an(
ytesssssl unuso_ coex(i
)   #[cfg(an(
an(
}/
cfg(an(
ytesan(
w mat!(<,e"MATCH( :06?}): "igi
 ?;
  #[cfg(an(
an(
ampl(i,t&pi
 
his  unum  p  DFAn_id_ rm m.i).rtou( .e   oulde(.
  #[cfg(an(
an(
{
big   #[cfg(an(
yteshatis> 0
    #[cfg(an(
an(
ytesan(
w mat!(<,e",e" ?;
  #[cfg(an(
an(
an(
}
big   #[cfg(an(
ytesw mat!(<,e"{:?}"2.pi
 ?;
  #[cfg(an(
an(
}
an(
ytesssssan(
t matln!(<,e"" ?;
  #[cfg(an(
}
    an(
} "dfa-buit matln!(<,e"mtran >` in : {:?}",
  unuseiaecial.w ?;
  #[cfg(t matln!(<,e"p  DFAn >` in : {:?}",
  unup  DFAn_ial.) ?;
  #[cfg(t matln!(<,e"()
  : {:?}",
  unu()
   ?;
  #[cfg(t matln!(<,e")" i/
    an(
  /()n to_byte()
 llAFETY:uWenv=> dfl    /eurdian(&self) -> (Vecmativo_big_// R method.
un //  ian(<esentations, su>ynteed.
  un in retT>i{w("fo publ_  Dric `to_bytestrid-inltru",eiTltru(nhwrit)atiany urs
s_Pate a _ndiae( Box<,eid:tSun thi  ///bool = "dfa-buil unusate a  
s_Pate a _ndiae(iom to_bytes_na publ_  Dric `to_bytestrid-inltru",eiTltru(nhwrit)atiany urs
s_//ad_ndiae( Box<,eid:tSun thi  ///bool = "dfa-buil unusate a  
s_//ad_ndiae(iom to_bytes_na publ_  Dric `to_bytestrid-inltru",eiTltru(nhwrit)atiany urs
s_    _ndiae( Box<,eid:tSun thi  ///bool = "dfa-buil unusate a  
s_    _ndiae(iom to_bytes_na publ_  Dric `to_bytestrid-inltru",eiTltru(nhwrit)atiany urs
s_maati_ndiae( Box<,eid:tSun thi  ///bool = "dfa-buil unusate a  
s_maati_ndiae(sd  to_bytes_na publ_  Dric `to_bytestrid-inltru",eiTltru(nhwrit)atiany urs
s_Punch_ndiae( Box<,eid:tSun thi  ///bool = "dfa-buil unusate a  
s_Punch_ndiae(sd  to_bytes_na publ_  Dric `to_bytestrid-inltru",eiTltru(nhwrit)atiany urs
s_)
   _ndiae( Box<,eid:tSun thi  ///bool = "dfa-buil unusate a  
s_)
   _ndiae(sd  to_bytes_na publ_  Dric `to_bytestrid-inltru",eiTltru(nhwrit)atiany ursn=xt_Punae( Box<,ecurrelfttSun thi(pipecte u8[c///hen thD = "dfa-builetcipectsec  unu/ bascl => sy_.get(ipect)n to_bytes<E: o eecurrelf.       #() +/    # ignor(ipect)n to_bytesl unusds
 ()[o] to_bytes_na publ_  Dric `to_bytestrid-inltru",eiTltru(nhwrit)atiany un //  ursn=xt_Punae_ to a val( Ok::<(), Box<dyn std::ecurrelfttSun thi())
      : [u: u8())
    ///hen thD = "dfa-bui2].Wd c<), B(mplees th), )/alignanb to a val. Drin sefmatn th: [u idenan(
 Ha l =>stapp ig,maddingbetyp
cheorsoses thebe
omitleriateed.
is bigfied an(
o[0iy virtue//ng the<&'a [u32]> {
.ed Dn OK
eiaesupfigur_bipltivennv=urnedan(
 Ha  rfirmsn(lizcodegen2.pneratrfileiaverisu . ---AG to_bytes<E:  l =>sec  unu/ bascl => sy_.get(boin)f` is big <E: o eecurrelf.       #() +/    # ignor(cl =>)f` is big <E: n=xt = *l unusds
 ().get_ to a val(o)f` is big n=xt to_bytes_na publ_  Dric `to_bytestrid-inltru",eiTltru(nhwrit)atiany ursn=xt_eoi_Punae( Box<,ecurrelfttSun thi[c///hen thD = "dfa-builetceoisec  unu/ bascl => sy_.eoiy_        #()f` is big <E: o eecurrelf.       #() +/eoin to_bytesl unusds
 ()[o] to_bytes_na publ_  Dric `to_bytestrid-inltru",eiTltru(nhwrit)atiany ursp  DFAn_ial. Box<  ///    # = "dfa-buil unum  p  DFAn_ial   #[ -> Res publ_  Dric `to_bytestrid-inltru",eiTltru(nhwrit)atiany ursmaati_ial. Box<,eid:tSun thi  ///    # = "dfa-bui  unumaati_p  DFAn_ial.sd  to_bytes_na publ_  Dric `to_bytestrid-inltru",eiTltru(nhwrit)atiany ursmaati_p  DFAn. Box<,eid:tSun thi,umaati_iToex:
    #[c///P  DFAnID = "dfa-bui
 l s /// Raveoptim Sa -> (se of e//// Fcomm> (cagnmeneehappewset.a
an(
an(
 Hadddg tDp  DFAn.e are )
    ///al avoidlizasemew   / n tfcosfromp  hurnedan(
 Ha rat f cosyip thi DFAn ID fn succ le in tmati ie,   }

 rsl arnv (1<<an(
 Haa bit let rm ddg/urposer-chadddg.e are optim Sa -> (teiaes, tonigfied an(
o[0mldtoutwinte/// is telenfraquedt:NE>(dyteshe
  unum  p  DFAn_ial e=e1c    #[cfg(an(
/ * [`DP  DFAnID::ZEROn to_bytes}_endian(
tch,Punae_ coex ec  unumaati_ndiae_ coex(iom;   #[cfg(/ unum  p  DFAn_id(ndiae_ coex,umaati_iToex  to_bytes_na publ_  Dric `to_bytestrid-inltru",eiTltru(nhwrit)atiany ursh    mp:w( Box<  ///bool = "dfa-buil unu()
   h    mp:w to_bytes_na publ_  Dric `to_bytestrid-inltru",eiTltru(nhwrit)atiany urs
s_utf8( Box<  ///bool = "dfa-buil unu()
   
s_utf8 to_bytes_na publ_  Dric `to_bytestrid-inltru",eiTltru(nhwrit)atiany urs
s_)hwrit_seirt ato _df
( Box<  ///bool = "dfa-buil unu()
   
s_)hwrit_seirt ato _df
 to_bytes_na publ_  Dric `to_bytestrid-inltru",eiTltru(nhwrit)atiany ursPunch_ndiae( Ok::<(), Box<dyn std::ec rfig: &Punch::C rfig())
    /// ```
  Sun thi,uhenrteature = "dfa-builetckeo _df
 rec rfig.get_ato _df
(.;_endian(
tch,Punch ec<uativc rfig.get_look_beh co( c    #[cfg(an(
None
=>
Sunch::T=xt,   #[cfg(an(
turn boin)
=>
    #[cfg(an(
yteshat!/ unu      + is_ mp:w(.
&& / unu      +   /// Tn(boin)
    #[cfg(an(
ytesssss/ * [`Deat(henrteatur::    (boin) /
big   #[cfg(an(
}
big   #[cfg(an(
/ unused tnch_maptget(boin)
  #[cfg(an(
}
    an(
};   #[cfg(/ unused unch(ato _df
2._unch  to_bytes_na publ_  Dric `to_bytestrid-inltru",eiTltru(nhwrit)atiany ursuniite_al_seirt Punae( Box<,emodesento _df
  ///Opdty  hen thi y{
an(
ytes nativmode
    #[cfg(an(
Ato _df
s:No =>is unust.uniite_al_seirt  nato _df
,
an(
ytesssssAto _df
s:Ys tV>is unust.uniite_al_seirt ato _df
,
an(
ytesssssAto _df
s:P  DFAn(_)
=>
None,   #[cfg(}yn st -> Res publ_  Dric `to_bytestrid-inltru",eiTltru(nhwrit)atiany ursv
   ould &. Box<,eid:tSun thi  ///&[u8] = "dfa-buihat!/ unu
s_)
   _ndiae(sd c    #[cfg(an(
/ * [`D&[]n to_bytes}_endian(
l unu)
     aligl syl unu)
   ould &_ coex(iom
    ) -> Res publ_  Dric `to_bytestrid-inltru",eiTltru(nhwrit)atiany ursget_rrtfilahr( Box<  ///Opdty  &Prtfilahr V= "dfa-buil unurrt as_ref(.   #[ -e()
  l strnds
    /// to tDpor -> (Vechedinse_re::Nst)

  l strnds
    /// to tDis it'sc reo_natlletit'seErrian    /A<&describs thow
videriam Thefn sugenendianne thne
    
    /// a liipectsPaquedinalb[urved.
#[der ve(Clgenati, ued for)tse
    Tds
    //Tto ttT>i{w("foo123Ae  //igue
  reg-> (Vecme n ye<&'a [u32f omer rnds
    /// to tDiofied suchrow-maj &tirder.urneeas'a [u32]> {
    dinse.urn  /is,
e/// Fstg
 fied suchndecrrte sas af tvdused   /// let/ds
    //s.urneemaximumh   /// le_endisuchtrof a powstper denri/ise257 (256ase omativ:alloc_ah: [ustes_n2.pn
  1dst)
    }e of tvdate a [EOIhtrof a pow).aIfra/ of/ndecerialirse
   eds, tus fied such: [uscl => s (rrecd/fa`
 ),arinteent    /// let/ds
    //s// Retu bigfied lizedubdenntch. Thfewmp:NE>(dst)
    }

 _to_dso pc   T OK
ei
    ding
u32>`zorn`urning`:NE>(d to t: T,w("foo123AedE: Vecml automacuscl => s,ew ed {nmaddg tDml automacuscl => correspo<&'a [u32lizasE: Vec: [uso
    n an ediscrinumiannbetwentehe/aati_endilize  //atclasmaati  This reEr: Eativml automacuscl =>ative_endiaes, thfied lizedddg tD hadso    s_Ditto_re:'ssplphhict,ew ed {tneemaximumh   /// le_endisuch hadso   s/ise257 (mativ:alloc_ahtes_n(Veche: [uspn
  f tvdate a _endisuchEOIhtrof a pow).aC rPaquedts ,D  t    /// letml automacuscl => s and `$`.n ve_endiaes, tit's   /// let/ds
    //s/se omativlength do.
Noane providers ///n    /imme* grea* nann(lizmativlength do  This rt of a power of  correspota The larger.urneetota3  grea nann(lizmativlength do  s//
  nDelin td to work t   /:NE>(dst)
    }

   eeVfromtimeD  t    /// letml automacuscl => s  s/fewmpn   ne257  ///fhe target
  _re:'ssd co nansh: [uscl => s (  }

    rrecd/fa`
 ): El automacu and `$`.nl => s ses the/// Th. ThVfromb//dis of dtwintedebugg ig,mao  ///
cfg(rget
  _/ds
    //s/er msasvs tele), Blb[co_bd. Dis off omer mzndecnotime.
    
    
// fit,madding) =vml automacuscl =>anapnte nhwritenann(wheged to work   ///ddg.e  /// `vaal majoelfwae ocagns,D  t    /// letml automacu and `$`.nl => s ieceubdenntch. Th &[u3mpn   ne257,o_native_ens awintelarge
    }

 Unicode.nl => s ele), Bnann:NE>(dnl => s: BoinCl => s,
    }

   ee t   / Vecmativlength do,.rr(e_eserializapowmp-of-Kwovrr(gendt:NE>(dst)
    }

   ee t   / Veca/ of/n ve_endiaes, tit'stota3 amount/let grea nann(li
    }

 mativlength do  This rt of a power of .e are ta The biggmpn   nen td to work   # Veca/ of'ssplphhict,eadding) =v t   / isenhwritetstr &[u3mao> Result<powmp let/wovgr `tmpn   neicesl alze aent akphhictk   #:NE>(dst)
    }

 Whegexitto_waal s sgrea,xitto_avoidlia li =edormatposegn edivisty  correspono   rre
 g
etwentepre `
 itli dtdense ID  
    //irative_endian` _endilize Topc  .3  ntinihewe/ //     sian(& bit-shifth:NE>(dst)
    }

 Seesrrecdocv }e of tv`se   //`vo_big_/rmat n tf)eta Ht. any st)
    }

   eenumbmumh`se   //`vtes_n(to_`1`A(  ve_endian` u, these   / Vec`2`)
    }

 whegexiteemaximumh`se   //`vtes_n(to_`9`A(  ve_endian` u, these   / Ve
    }

 `512`).urneemaximumhisethat`8`eadding) =vmaximumhakphhictk   #(to_`257`
    }

 whenp)
 ount ig_rmatf tvdate a [EOIhtrof a pow. Howmvex,/
 hakphhict
    }

 >` in lletitatk   #(to_excep ///al Th/elenddding) = pkphhictkiecehrunk_endilize T  /il automacuscl => s. any se   //:
    #,ge()ian(<'a> Tds
    //Tto tt&'a rning V= "dfaness  [ur a   #(arnds
    /// to tDden
  ign ta DFA, but we igno` rm m`.
    }

 Undi tucg s ,ae_* [`Dite_tota3    /// let: [usor/adtelgegswset.ede_endisuchtrof a power of .lized the provided Dn td {walizaproof m&desur a    ign  yo_natlletit'strof a power of ,
cfg(rget
  _Ditto_re* [`seave hand.
Noa ofy,ling alhtches drm m  configurndia
cfg(rget
  _duseda  gnself,ali`Sun thi`, uaranteespwsed re* [`Dave hand (amo` _endilize 
    :alloc_ah hands). any st)
    }

    /// R
    ///
    /inecudo  Th  rsen serime. any st)
    }

 # Safety any st)
    }

    //not trueisethat //  ing
    A<&dconfigurc/eorig/ `validlfwae oede_endisuchtrof a power of iot()
 .e  /_native_en,mer rnds
    /// to tDc[nebe_endisuch    e large,mao c/eor ign thevalidlfwac[nebeysemew   /tes)
  ve.3An_endilize T DFA'snds
    /// to tDis that //  ing
     
    code.ta T/ ly/// a l_endisuchtrof a power of i_biplt method (t bh alitesrm dtgbetypsrc/eorielisty ). any st)*Tned rma ,/
 e T DFA'snds
    /// to tDc[nel/adt, tund/ficignbendiiop:NE>(dst)
    }

 C[u3mpso
        teespfun  -> (mral ei
    p =>a// a lisafetye T Drin s_endilize d // that cn    /imme: [usotches   /// Tiza DFA'snds
    /// to t.
    }

    //// that cn/ Repheln(lizy me: [usot mates liz`t mat_to`.
    un //  ursfn s_: [us_ to a val( Ok::<(), ensBrm m: &'a rn8]())
    /// ```
  (Tds
    //Tto tt&'a rning ,
    #[,s  [ur a   #eature = "dfa-builetcBrm mlPunch eesrm m:as_ptry_        #()f` "dfa-builetc(seiaecial, nr) e   #[cfg(an(
wire::try_r/ad_nin_       #(srm m,e"mtran >` in " i/
    an(
drm m = &drm m[nr..]f` "dfa-builetc(se   //, nr) e
wire::try_r/ad_nin_       #(srm m,e"mt   //" i/
    an(
drm m = &drm m[nr..]f` "dfa-builetc(cl => s,enr) e
BoinCl => s ignor_: [us(srm m i/
    an(
drm m = &drm m[nr..]f` "dfa-bui

   eepkphhictk>` in l(otal numcn(lizy me: [uscl =>anap)zaanthat//ve enan(
/ *biggmpn   nen tese   / (tota3  grea nann(lizmativlength do):NE>(dyteshe
 t   // > 9c    #[cfg(an(
/ * [`Deat(  [ur a   #eatur::/// The(
big   #[cfg(an(
"dinse_re:zndec T DFA's t   // (too*big)",   #[cfg(an(
u);   #[cfg(}   #[cfg(ideIthulso
aanthat// zero,eaddinge thia/ of/
    n an e/// is teny//n` 
cfg(an(
o[0n s/atclaszero    /// lettt`se Dwset.aeznerao Kwovrl automacu and an(
 Ha l => s: geneill bed 256a: [ustes_n Dendnone
    rmatf tvEOI
an(
an(
 Hadu32f el:NE>(dyteshe
 t   // <e1c    #[cfg(an(
/ * [`Deat(  [ur a   #eatur::/// The(
big   #[cfg(an(
"dinse_re:zndec T DFA's t   // (too* &[u3)",   #[cfg(an(
u);   #[cfg(}   #[cfg(ide   /// ROKeadding1 <=
 t   // <= 9._endian(
tch,Pu   / e   #[cfg(an(
1    #.o a val_shl(nin::try_gnor( t   //    // `bu    // `buf` is big he
cl => s.plphhict_ial.) > Pu   /     #[cfg(an(
/ * [`Deat(  [ur a   #eatur::/// The(
big   #[cfg(an(
"akphhictk   #(aanthat// biggmpn   nends
    /// to tDde   /",   #[cfg(an(
u);   #[cfg(} _endian(
tch,nds
 _ial e   #[cfg(an(
wire::shl(seiaecial, se   //, "dinse_ to tDnds
    ///>` in " i/
    an(
tch,nto t_: [us_ial e
wire:: `
(
big   #[cfg(nds
 _ial,   #[cfg(an(
tun thi::SIZEeed
    #[cfg("dinse_ to tDmtran : [us>` in ",   #[cfg( ?;
  #[cfg(tire::o a v_ rm m_ial. rm m,ento t_: [us_ial, "nds
    /// to t" ?;
  #[cfg(tire::o a v_a  gnself:: hen thi (srm m i/
    an(
tch,nto t_: [us = &drm m[..nto t_: [us_ial]/
    an(
drm m = &drm m[nto t_: [us_ial..]f`endian(
/ *SAFETY:uot
   hen thD isenhwriteas'a [u32]o tDelizanin,DFlar,e/ =ed (1<<an(
 Harotoo(to_ensure
    /we/ndiane endiaper >` in lendno  gnselftuWe'vu and an(
 Ha  a val.// thafa: DFso
  encrao bel    sisafe._endian(
 H   #[cfg(.
 / }
    /// Rt eeVfromtha- //  code.s_Ditto_fun  -> .
    an(
tch,nto t rec re::srm m:ignor_raw_pirt (
big   #[cfg(nto t_: [us:as_ptry_ crao:: u32>( d
cfg(an(
ytesnds
 _ial,   #[cfg(.;_endian(
tch,th eeTds
    //Tto t {er of ,scl => s,e t   // }/
    an(
  /(tt,earm m:as_ptry_        #() -ePrm mlPunch)n to_byte() public `to_bytes` serializatiian( Tds
    //Tto tting
u32> V= "dfanessCr `tmehe/umbmalends
    /// to tDwset.eral Kwovdense :chediniyth do any lize  //at     dense.   eepkphhictk>` in land tt   / Vecisthor safety  correspon of     dial numcn(lizy metches dE: Vecml automacuscl => s:NE>(dfns/umbmal(nl => s: BoinCl => s  ///Tds
    //Tto tting
u32> V= "dfaytes<E:  Inpth eeTds
    //Tto t {
big   #[cfg(nto t: vec![]d
cfg(an(
ytescl => s,
    an(
ytesst   //:
cl => s:se   //(),
    an(
};   #[cfg(ide wovdense ,ae_gargl s tletakphhictk   #,Dc[nenhwritefi /iT  /u32.
    an(
tt add_ mp:w_ndiae(    // `buf
 Hac/adtdense any an(
tt add_ mp:w_ndiae(    // `buf
 Ha     dense any an(
t+   #[ -> Result<Set[arnds
    ///s_Ditto_r of .eBaA with `gnor`land `to`s tranvzyuao> Result<alr/ady/ing a,  
    theeteesppanics. `unit` ses thecive_endiay, ta l_endisuchtrof a poweaensgno`gnor`lriaeeseria`to`.
    urss +(  ensBox<,sfn s:tSun thi,uunit:takphhict::Unit,mto:tSun thi  = "dfa-bui => df!(/ unuis_ DFA'(fn sw,s" T DFA's'fn s'Fstg
 "uf` is big  => df!(/ unuis_ DFA'(tow,s" T DFA's'to'Fstg
 "uf` is big l unus of [fn s.       #() +/l unucl => s:get_by_unit(unit)] e   #[cfg(an(
to.    32buf` is  -> Result<Adgnanbemp:wssense (hesense w ed {nkint of a powstl/adt, thediniyth do) any lize  /// * [`D theo }
}

imp:   eeon uses ex / * [`ed// R
    ///
     any lizethaturposne thny  
    ing a ignmtran.lized the provided Daddf omadsense ws theexharal Kt's tranion uses ex sgrea,xitrantees correspo<&* [`seave hand.iany ursvdd_ mp:w_ndiae(  ensBox<  /// ```
  Sun thi,ucfg(feature = "dfa-bui
 lN ///ls ,D osgetmadfe_ehs tranion uses exhewe/ws thejush_endian(
 Hatactiite_rToexlletit'sn=xt dense;addeds, tit'str safety  corran(
 Hataof .eHowmvex,/wehux<dynromperformRaveoptim Sa -> ( ed urnedan(
 Ha rat pre `
 itli stdense ID  lizy me t   /het bh     /immgfied an(
o[0urposnimmedinserom ta DFA, but we igno //irat of a powstiaurnedan(
 Ha rect of a power of .e are avoidlizve xt o  `
 itlicldty _endian(
 Hairse
   -> (ample in tlookupm ta   ///erime. any an(
 H   #[cfg(.
 Pre `
 itli dton uses exvzyeanK
    /ATntiniygnoyed!  natin` 
cfg(an(
o[0loop look ignmoo_bi ignhe cotees: any an(
 H   #[cfg(.
 (
 tran eenatusench_endian(
 Ha(
ampl: [usirsh ysenck:_endian(
 Ha(
big n=xt eenatut of a pows[ tran * tt   / +l: [u]_endian(
 Ha(
big he
natu
s_maatiyn=xt):_endian(
 Ha(
big an(
/ * [`Diven_endian(
 Ha(
/ * [`Dfalse any an(
 H   #[cfg(.
    can/ATntiniylooknhe cotees: any an(
 H   #[cfg(.
 (
 tran eenatusench_endian(
 Ha(
ampl: [usirsh ysenck:_endian(
 Ha(
big n=xt eenatut of a pows[ tran +l: [u]_endian(
 Ha(
big he
natu
s_maatiyn=xt):_endian(
 Ha(
big an(
/ * [`Diven_endian(
 Ha(
/ * [`Dfalse any an(
 H   #[cfg(.
 In  
    words  ///sdiane  `
 itlicldty airse
   -> (ianteendianan(
 Ha ri
is bmp  h.e are * [`seaenseo
be/nedicelf,performa
   ,in. "dfa-bui

   eecosfygnoetf ompre `
 itli dtdense idliian    /immwac[n_endian(
 Harsl arnaa biggmpndense ide<&'a [u32]> {
.e(A    //yhulso
macturnedan(
 Ha reccode.a bit  n tfcoan(&x, edate a  Thour ig /umbm Sa -> (keturnedan(
 Hawhenpe_ehuffl igndense ,aa Rone  =edsono   rre
 g
ncke  //for hurnedan(
 Ha
etwentedense ID  
   th do  Topc  .) any an(
 H   #[cfg(.
 Totoo(tees  ///sian(yatactiite_rToexlletit'sth do  T, ta l_endian(
 Haruser'strof a power of , ra
    tnaniite_rToexlletit'sth do   #[cfg(.
   ()
 .ee.g.,ed Dn th t   / ise64,arinteent IDsgnored 3rdsth do   #[cfg(.
  s 19/, nhat2.` is big <E: n=xt = l unus of  ial.w;_endian(
tch,i
 e   #[cfg(an(
tun thi:: = Sn=xt).map_ ha(|_|ucfg(featur::too_manw_ndiaes.) ?;
  #[cfg(l unus of  =xtend(rtou::<&' `t(0).tact.  unuse   /antuf` is big   /iom to_bytes_nativeSwapn rectwovdense Dtches s_Ditto_rrof a power of .lized the provide   //not truedconfigurdoteny//n` ono  /eorig/ ` methodn s tlettees correspo wap. C[u3mpsomral ensure
    / 
    dense Durposn` ono id1/
   hd2 eleurned.
  updeserynpproprinsero.lized the provideBaA wid1/
   hd2 mral urposne t DFA's tnse ,a 
    theeteesppanics.
    ursswap(&/ensBox<,sid1ttSun thi(pid2:tSun thi  = "dfa-bui => df!(/ unuis_ DFA'(id1w,s" T DFA's'id1'Fstg
 : {:?}",
id1w; "dfa-bui => df!(/ unuis_ DFA'(id2w,s" T DFA's'id2'Fstg
 : {:?}",
id2).write_to_lenWeeVfromt/
    /swapn recpirt lletit'sth do     /elenuann:Howeifta l_endian(
 Ha t   / ise64,abutg) = pkphhictk>` in l/ Ronrom33on intew//sdiane lo/
cfg(an(
 Haef work.
    an(
amplbchis0..  unucl => s.plphhict_ial.)     #[cfg(an(
/ unur of .swap(id1.       #() +/b,
id2.       #() +/bs;   #[cfg(}yn st -> Result<Remapn
  _/ds
    //s/rmatf tvdensess, thi)
 oran` u, ta lifun  -> d to works, th.e are aptli stn thtches tappfun  -> (  /i/// Fnds
    ///s_Dittd to works, thidense;a spc/ lg  on thnds
    ///s_D,laceu, ta lias/
  zo oede_endisuchtappfun  -> (rmatf athtrof a pow.
    ursremap(&/ensBox<,sid:tSun thi,umap: ian( Fn(Sun thi[c///hen thD)     #[cfg(ampl: [usirs0..  unuplphhict_ial.)     #[cfg(an(
tch,i ecid.       #() +/b [u;
  #[cfg(an(
tch,n=xt = l unus of ()[i];   #[cfg(an(
/ unur of _ en()[id.       #() +/b [u] ec<upSn=xt);   #[cfg(}yn st -> Result<Trun ats.ess.dense D Thisliznds
    /// to tD, ta lis, thi>` in .lized the provide   //not truedconfigurdoteny//n` ono  /eorig/ ` methodn s tlettees correspotrun at {
.eC[u3mpsomral ensure
    / 
    dense Durposn` ono trun ated_endilizedense Delenupdeserynpproprinsero.lizedfnsndun ate(&/ensBox<,s>` :
    #[c{
  #[cfg(l unus of  ndun ate(ial <<s  unuse   //uf` is  -e()ian(<esentations, su>yTds
    //Tto ttT>i{w("foo123W matlizasEr a   #//formtletteesznds
    /// to tD, ta libuffnd /, th.e provided Dn thbuffnd esznoo* &[u3,arintehve hand to_re* [`nn:HTotoial numcfied suchnow bigDn thbuffnd mral be,     `t mat_to_ial`.lizedfnst mat_to<E: ETopan>( Ok::<(), Box<dyn std::e/ensdstby  ensrn8]())
    /// ```
      #, Sur a   #eature = "dfa-builetcnt mat = l unut mat_to_ialbuf` is big he
dst ial.w
<cnt mat     #[cfg(an(
/ * [`Deat(Sur a   #eatur::buffnd_too_ &[u3("nds
    /// to t" );   #[cfg(}   #[cfg(dst = &/ensdst[..nt mat]f` "dfa-bui

 t mat mtran >` in  "dfa-bui

 U // `// ROKeadding   /// lettt`se D  R
    ///
    /fi /iTizanin.
    an(
E::t mat_ 32bnin::try_gnor(  unuial.)    // `bu,sdst);   #[cfg(dst = &/ensdst[   #_of:: u32>( ..]f` "dfa-bui

 t mat mtran se   / (decrowmp let2) "dfa-bui

 U // `// ROKeadding t   //   R
    ///
    /be/<= 9._endian(
E::t mat_ 32bnin::try_gnor(  unu t   //    // `bu,sdst);   #[cfg(dst = &/ensdst[   #_of:: u32>( ..]f` "dfa-bui

 t mat : [uscl =>anap "dfa-builetcn = l unucl => s.t mat_to(dst)?;   #[cfg(dst = &/ensdst[n..]f` "dfa-bui

 t mat ux<dyne/ds
    //s   #[cfg(ampl&si
    l unus of ()     #[cfg(an(
tch,l e
wire::t mat_ndiae_ 
:: E> si
, &/ensdst /
big   #[cfg(dst = &/ensdst[n..]f`  #[cfg(}   #[cfg(  /nt mat     ) -> Result<Re* [`sDite_   /// let: [uso //bPar a   #//formtletteesznds
    // correspon of  wsed    .lizedfnst mat_to_ial. Box<  ///    # = "dfa-buil  #_of:: u32>( n(
 Hadensen>` in  "dfa-bui+il  #_of:: u32>( n Ha t   /2 "dfa-bui+il unucl => s.t mat_to_ial.w   #[-bui+i(l unus of () ial.w
*
tun thi::SIZE     ) -> Result<VDFA'ianan    /e/// Fstg
  IDs Thisliznds
    /// to tDihevalid.lized the provide    /is,
e/// Fstg
  IDsc[nebeynann(no   ethodly_rToexlagth do  Thises correspot of .lizedfns DFA'ian( Box<,eor by  retT>  /// ```
  ([,s  [ur a   #eature = "dfa-builetcBp = &natusate a /
    an(
ample in this  unuseiae (.
    #[cfg(an(
lenWee /eorig/ ta DFAIDs t()
 Aespweed formnn:HT   /is,
hatit'

  #[cfg(an(
o[0asBate a 4mtranarinteit  ral ux<dynrombe/ne    ,edini,sv
   ,
  #[cfg(an(
o[0maati mple irtv translizedE>(dyteshe
 p 
s_Pate a _ndiae( transidy_s
    #[cfg(an(
ytesletcis_)
<dynro_Pate a  = lp 
s_//ad_ndiae( transidy_s   #[cfg(an(








|| lp 
s_    _ndiae( transidy_s   #[cfg(an(








|| lp 
s_maati_ndiae( transidy_s   #[cfg(an(








|| lp 
s_seirt Punae( transidy_s   #[cfg(an(








|| lp 
s_)
   _ndiae( transidy_s;   #[cfg(an(
yteshat!is_)
<dynro_Pate a      #[cfg(an(
ytessssside   /// Rd co Veca/cryptice hand m s age...   #[cfg(an(
ytesssss/ * [`Deat(  [ur a   #eatur::/// The(
big   #[cfg(an(
  #[cfg("fetyp
dinse_mtranaraggerialiPate a  butg\
big   #[cfg(an(
  #[cfg({wal), Bux<dynromPate a ",   #[cfg(an(
ytesssss) /
big   #[cfg(an(
}
big   #[cfg(an(
he
 p 
s_maati_ndiae( transidy_s   #[cfg(an(








&&
natumaati_ial. transidy_s
e=e0
  #[cfg(an(
an(
{
big   #[cfg(an(
ytes/ * [`Deat(  [ur a   #eatur::/// The(
big   #[cfg(an(
  #[cfg("fetyp
 nativdenseswset.zero p  DFAn IDs",   #[cfg(an(
ytesssss) /
big   #[cfg(an(
}
big   #[cfg(}
cfg(an(
ytesrmat(_,D o 
his trans/ds
    //s( [{
cfg(cfg(an(
yteshat!/ unu
s_ DFA'(tow
{
big   #[cfg(an(
ytes/ * [`Deat(  [ur a   #eatur::/// The(
big   #[cfg(an(
  #[cfg("fetyp
 T DFA's tg
  IDs Thids
    /// to t",   #[cfg(an(
ytesssss) /
big   #[cfg(an(
}
big   #[cfg(}
cfg(an(
}` is big   /()n to_bytes_nativeC rre
 stteesznds
    /// to tD, ta
borrowal. Dlu .lizedfnsas_ref( Box<  ///Tds
    //Tto tt&'_ rning V= "dfa-buiTds
    //Tto t {
big   #[cfg(nto t: l unus of  as_ref(.d
cfg(an(
ytescl => s:il unucl => s.clgen(.d
cfg(an(
ytesst   //:
  unu t   //,   #[cfg(}yn st -> Result<C rre
 stteesznds
    /// to tD, tan ownFh. Dlu .lized public `to_bytesd loc"atiany ursto_ownFh( Box<  ///Tds
    //Tto ttd loc::vec::ing
u32> V= "dfaytesTds
    //Tto t {
big   #[cfg(nto t: l unus of  as_ref(.uso_vec(.d
cfg(an(
ytescl => s:il unucl => s.clgen(.d
cfg(an(
ytesst   //:
  unu t   //,   #[cfg(}yn st -> Result<Re* [`Dite_denseurmatn thtches ID.ed Dn tks, thihD is that DFA',arint
cfg(rget
 esppanics.
    urssdiae( Box<,eid:tSun thi  ///Sun t<'_> = "dfa-bui => df!(/ unuis_ DFA'(id))f` "dfa-builetci ecid.       #()/
big   #[Sun t {
big   #[cfg(idd
cfg(an(
ytesst   //:
  unu t   //,   #[cfg(ytesnds
    //s:(&  unus of ()[i..ii+il unuplphhict_ial.)],   #[cfg(}yn st -> Result<Re* [`seavertould &timpleved tt`se D Thislizrrof a power of .lized the provide   ///tould &tyieldvza tuplrase omativdenseal strfiral e(&self,e over corresponuplrative_endiaes, thesense'heon uses ex,/
    //bPa)
  
e(&self and `$`.n ve_endiaes, tit's traniot()
 A(   /ri   //ng thends
    //s). any urssense ( Box<  ///hen thtou<'_, Te = "dfa-buihen thtou {
big   #[cfg(nt:
  un,   #[cfg(ytesit: l unus of ().chunks.  unuse   /ant.e   oulde(.,   #[cfg(}yn st -> Result<C rre
 lagth do   }
}

impA, taverToexl, thesense ( Thisthr lg > Result<0..  unuial.)  NE>(dst)
    }

    /// Return twinteetf omadding
T>`ializn efficit istapnkeysn(liz trane provideriae  / e
    s_formldty p(t bh aliza/ mappedvdenseuID):NE>(d the provided Dn thtches hD is that DFA',arintnteespn. kpaniczornpreturnizn_endilize T method ocoexaiany ursto_ coex( Box<,eid:tSun thi  ///    # = "dfa-buiid.       #() >>
  unu t   // to_bytes_nativeC rre
 gaverToexl, thesense ( Thisthr lg  0..  unuial.w)se DFoBux<dyn_endilizedense/i }
}

imp:NE>(dst)
    }

    /// Return twinteetf omadding
T>`ializn efficit istapnkeysn(liz trane provideriae  / e
    s_formldty p(t bh aliza/ mappedvdenseuID):NE>(d the provided Dn thtches rToexlis that ThisthPate fi dtr lg ,arintnteespn. kpanic_endilize d preturnizn    method denseuIDaiany ursto_ndiaecidy Box<,eiToex:
    #[c///hen thD = "dfa-builenCORRECTNESS: d Dn thtches rToexlis that DFA',arintnitlis tha_endian(
 Harsl arndun ine_to_, tpaniczornre* [`Da  DFA's tg
  ID.
cfg(an(
tun thi:: = _ to a val(iToexl<<s  unuse   //u    ) -> Result<Re* [`sDite_ tg
  IDsrmatf tvdensesimmedinseromfo lowf omer rone /, th.e provid
    }

    //dconfigurc/eoriwin
    tne_ tg
  IDs/ * [`ed// R T DFA'.e  /fux<,
cfg(rgetif tne_ tg
  IDstches rsDite_lrao th do  Thises_re:,arinteent  tg
  ID correspo<&* [`ed// R
    ///
    mbe/ T DFA'.NE>(d public `to_bytes` serializatiany ursn=xt_Punae_idy Box<,eidttSun thi[c///hen thD = "dfa-buil unuso_ndiaecidyl unuso_ coex(i
).o a val_addy1    // `bu     ) -> Result<Re* [`sDite_ tg
  IDsrmatf tvdensesimmedinseromrrteedf omer rone /, th.e provid
    }

 d Dn thdiniyIDstches (  }

    zero), uaranteesppanics.   #[ public `to_bytes` serializatiany fteprev_Punae_idy Box<,eidttSun thi[c///hen thD = "dfa-buil unuso_ndiaecidyl unuso_ coex(i
).o a val_suby1    // `bu     ) -> Result<Re* [`sDite_ to tDelizasrm m
letdense ID aiany urst of (&Box<  ///&[Sun thi] = "dfa-buiwire::u32s_so_ndiaecids(l unus of  as_ref(.
    ) -> Result<Re* [`sDite_tota3    /// lettt`se D Thislizrrof a power of .lized the provideNoan     /e_re:znhwritendeckeznerao Kwovdense :cn thdiniy
       _endilizedense .e  /_native_en,mer rdiniyth doznhwritendechD 0/
   hs and `$`.n ve_endiaddg yenhwritetstrfiral denseal strdiniyth dozis t an ehe/aati_endilize translizedfhi>` . Box<  ///    # = "dfa-buil unus of () ial.w
>>
  unu t   // to_bytes_nativeRe* [`sDite_tota3 se   / se om/// Fstg
   ThislizeEr:  are )
ve_endiaee provideriaite_tota3    /// let/ds
    //s/nann(lizmativstg
   ThislizeEr's_endisuchtrof a power of .lizedursse   /a Box<  ///    # = "dfa-bui1l<<s  unuse   //    ) -> Result<Re* [`sDite_tota3    /// lete(&self   This rpkphhictkn ine_to_endisuchtrof a power of .l s /// Rahwritel s t   neicesl alze a`  unuse   /an`.
    }

 Itl/ Ronromsl alzwinteent pkphhictk>` in l/ Racrowmp let2. O
    the,
cfg(rgetit// Rahwritese  odly_l s .lizedfnsalphhict_ial. Box<  ///    # = "dfa-buil unucl => s.plphhict_ial.)    ) -> Result<Re* [`sDivennif/
   onromi Dn thtches denri/hD is  DFA'sn ine_to_endisuchtrof a power of .lValidlfwa Thisliz  //=xt yeanK
    /n thtches hD czn_endilizebeynann(eliza DFA'soffeesewset.`  unuse   /an`ono iToexl,eesznds
    // correspon of .iany urs
s_ DFA'( Box<,eid:tSun thi  ///bool = "dfa-builetci
 ecid.       #()/
big   #[i
 <il unus of () ial.w
&&[i
 %   unuse   /an
e=e0
  #[ -> Result<Re* [`Dite_me n yeu age,eiTt: [us,tletteesznds
    /// to t.e provid
    }

    //dconfigur   luds.ess.d  # Veca/`Tds
    //Tto t`vtes_n(t ()
 .NE>(dfns/e n y_u age. Box<  ///    # = "dfa-buil unus of () ial.w
*
tun thi::SIZE to_byte() public `to_bytes` serializatiian(<esentMutons, su>yTds
    //Tto ttT>i{w("foo123Re* [`sDite_ to tDelizasrm m
letdense ID aiany urst of _ en(  ensBox<  ///  ensrSun thi] = "dfa-buiwire::u32s_so_ndiaecids_ en(l unus of  as_ en().   #[ -e()
  l strdE: Vecved palloc_ahden
  igntt`se D Tha_re::Nst)

  l strdE: Vecden
  igntt`se Dn ve_endiaes, tit's:alloc_ahchopc  rone c[nemactulize Thierms Vecden
  ignazeEr:  a  /is,
b rma mfo lowf omer rfiral nds
    //,ulizeyourfiral t/
    /se(&cttit'sth do     /youre irtvin. st)

  lN ///ls ,Da/ of/n rre
 ndunn su[neNof/
    n s/atdddg tDden
  igntt`se

  lws theot()
 Aeral ndiangenendi
  igntt`se.eHowmvex,/ed! suppor sn inlook

  laretyp
/// Th. Thrsl arnv  n tfden
  igntt`se .   eecoethod den
  igntt`se

  lliz hoses l    /// ce
 / Tidiaperti stVec<u8>,ala pow   /w }

 wFA, but

  led! s  ///. st)

  lB rma mlg a ignthoseidiaperti s  ///iiral mral d/fici Kwovierms: st)

  l* `h ysenck` -   ee: [uso  /inecudo  //bPa ///.l strdE ///eahwriteseirt 

  l n ta DFA, but we igno`h ysenck` 
   eiaesb rma mll bta DFAeco Ve

  l n`h ysenck`.

  l* `  //=xt` -   ee(:alloc_ybemp:w)e: [usosurretypwe i`h ysenck`.i`h ysenck`

  l nmral be   /// Tnn(wi//n` `  //=xt` t bh     /`  //=xt` ieckeznerao deceig

  l n sn`h ysenck`.

  
}

    //split// Rcrue a  n indinl ignwset.look-aretyp. Ficesxaan(&,h  rs  /r
/ Ha recco//=xt `foobarbaz`, uarsh ysenck `bar`/
    //bregexl`^bar$`.e are
espo<&gexlses the_igu_
 nativuarsh ysenck adding`bar`/dconfigurnppeax bta DF
lizebebut we igno //iipect. Simi_ens ,  //bregexl`\Bbar\B` ses the nativuar
suchndysenck ing
    `bar`/is that urretypnn(lizwordgbetyparie . Bu lagtE ///
/ Ha ra<&dconfigurtactico//=xt  T, t)
 ountlws thethatul nutl`\B`ono /aati_lizeddding) = bebut we ignohny se  ig /// is tezwordgbetypary. Simi_ens , a
work   ///a ra<&dconfigurtactico//=xt  T, t)
 ountlwhes dE ///ddgl`^bar$` ut

  luarsh ysenck `bar`/ws thepreturnize nativwintnitlees th), .

  
}

   us,
htmfo lowK
    /n thden
  igntt`selliz hoses l    /// er rfo lowf o
}

  ri
ur a,edir ved fn succ l,ala pow   /w }

  //bPa ///eseirt /s_Dittd}

 `  //=xt` (  ve_endian` u, tn thden
 igno`h ysenck`): st)

  l1.ed Dn tkPa ///eseirt / ta DFA, but we igno`  //=xt`,arinteent `T=xt`

  l nle irtv tran// Retup. (ot
   `^`Dn ve_endiaes, 

  l nl`hir::Ato _d::S irt`.)

  l2.ed Dn tkPa ///eseirt / taal,ala pow immedinseromfo lowf oma ltru

  l nlal numld &,arinteent `Ltru`le irtv tran// Retup. (ot
   `(?m:^)`

  l nln ve_endiaes, t`hir::Ato _d::S irtLF`.)

  l3.ed Dn tkPa ///eseirt / taal,ala pow immedinseromfo lowf oma : [u 
  l nlnl => fi dt s/at"word"D hadso    (`[_0-9a-zA-Z]`),arinteent `WordBoin`

  l nle irtv tran// Retup. (ot
   `(?-u:\b)`ative_endiaes, thewordgbetypary.)

  l4. O
    the,tif tne_ a ///eseirt / taal,ala pow immedinseromfo lowf o

  l nlhe: [us    /Anfigurcl => fi dt s/at"word"D hadso    (`[^_0-9a-zA-Z]`),

  l nlainteent `NonWordBoin`le irtv tran// Retup. (ot
   `(?-u:\B)`

  l nln ve_endiaes, tamtha-word-betypary.)

  

  l(/ }
 Unicode.wordgbetyparie Delenthat uppor cn(lizy me of/ing
    immgf/ Harsl arna `
 i-: [us>ook-aretyp/
    / /// Rdiffic
  z  /suppor s Tha_re::)

  

  lTo fur
    comtlicldeeteengs  ///ulso
suppor s  rse
   -ign ndividdyn_lize  o _df
 e irtv trans/se omativp  DFAn  This reEr: (W }

    rsl arndu, 

  lian(&selftimpllapp igbregexes   ethodly,abutg/ Rahso
/// Th. Theturn .)

  l  us,
wintnindividdyn e irtv trans/se omativp  DFAn elenen of d,arinteent
viderita3    /// lettt`rtv trans/<&'a [u32ed// R`4i+i(4l* #p  DFAns)`,ew ed 

  luars4 comns/sn sumativgno //i4s:allocilitie Defa: al strfiral 4o<&'a [u32l

  luarsden
  igntt`se Drmatf tvruser'sre:,aw }

 suppor sdE ///ddglrma

  l `
 itl thi DFAns/sia`
 aneous Th(:alloc_ybunato _df
).

  
}

 d Dindividdyn e irtv trans/elendis of d, uaranteespwsed onromstma m4
lize trrtv transal ypis big,Dindividdyn e irtv trans/elenonromsn of dtwint
}

   rse
   -ign //breite_me of/fornregexl natin` . Bu l //yhur//ulso
eturn 
    }e oriali-ign ofK
    /c[ne a ///eill bhPate ficvp  DFAn e om//nz  /suppor 
lizeb/ tha o _df
 
   unato _df
e a ///e Dwset.
  _dusedre::Nst)

  lNoan    ///n    /whegexiteee irtv to tDehwritendecei
    d4`zord}

 `4i+i(4l* #p  DFAns)`hden
  igntt`sel*ids*,Dite_tota3    /// lettt`se 

  l ighl be   /s  /r ofyh &[u3mp:  a  /is,
mhny  fa DFAIDe ta The dutlicldt: a

  l(Ficesxaan(&,hif/
nregexldcon), Bhdiane `\b` t b-p  DFAn,arinteentre'henof/ Harsas> (  //// Thtmeheuniquthden
  igntt`selill h
  l ignwordgbetyparie .f/ HaSimi_ens 
ample irt/eyp/
 o _d .) #[der ve(Clgenati, ued for)tse
    S irtTto ttT>i{w("foo123  eeonitiyn e irtv tran ID aiany st)
    }

 _to_dso pc   T OK
ei
    ding
u32>`zorn`urning`:NE>(dst)
    }

   eefiral `2 * tt   /` ( urrelf yenhwrite8)vrusrie Dehwriten ve_endiae provideriaite_seirt /tt`se Drmatf tvruser'sre:,awset.
  _firal 4orusrie D_bipldst)
    }e ounato _df
e a ///e D
    //bPa)
  
4orusrie D_bipleill bto _df
 to_bwork   ///nsal o keepeteengs sian(&  ///ulwritenan 8orusrie Dm//nzi over correspo`S irtKind`/is thatb/ t:NE>(dst)
    }

 Aftmpn   t,Dn td {ur//`se   / * p  DFAns`v tran ID ,ew ed {`p  DFAns` correspota The zero  This rcagnmeneehappewset.nothi DFAns/or  This rcagnmw ed urnedrget
  _re:{walirialsewsetaenssn of igntt`
  igntt`se Drmatmativp  DFAn:NE>(d to t: T,w("foo123T thden
  igntt`selc rfigurldty p uppor cn. Winte'b/ t',tb/ turned.
  una o _df
 
   ato _df
e a ///e Dwork. Winte'una o _df
', bto _df
 to_bwork   ///nsppanic. Winte'a o _df
', unato _df
e a ///e Dpanic. to_bd co: S irtKind,w("foo123T thden
 ntt`selc rfigurldty pse om/// F:alloc_ah: [u. any sench_map: S irtBoinMap,w("foo123T th   /// lettt`rt igntt`selIDe p   p  DFAn:NE>(dse   /:
    #,g("foo123T thtota3    /// lethi DFAns/se ow }

 st`
  igntt`se Delenencoded.
    }

    /// R`Non/` n in res
    /wereirialsewsetaense irtv trans/se omati> Result<p  DFAn.e aus,
one c[nthat    teespfieldz  /sa Tnow m  yo_n DFAns any lize re  This reErs Thaed cagns. Itl/ RPate ficv  /now m  yo_n DFAns eleurned.
  <&'a [u32ed//anteespe irtv to t.
    p  DFAn_ial:/Opdty      #>,g("foo123T thuniite_alhden
  igntt`selill unato _df
e a ///e .l s /// Ronigfied ult<pa [u32zwinteent lengtuppor sounato _df
e a ///e D
   whenp)llhden
  ig_endilizedense/IDe ill btounato _df
e a ///Delenel automat.
    uniite_al_seirt  nato _df
:/Opdty  hen thi ,g("foo123T thuniite_alhden
  igntt`selill ato _df
e a ///e .l s /// Ronigfied ult<pa [u32zwinteent lengtuppor soato _df
e a ///e D
   whenp)llhden
  ig_endilizedense/IDe ill btoato _df
e a ///Delenel automat.
    uniite_al_seirt ato _df
:/Opdty  hen thi ,ge() public `to_bytes` serializatiian( S irtTto tting
u32> V= "dfanessCr `tmehe DFA's E: Vecden
 ntt`se Deed paposn` ono tstrdiniyth do:NE>(dst)
    }

 Whnteent   ve_endian` ueErs s   rse
   nn(wi//se irtv trans/se omati> Result<p  DFAn,arinte`p  DFAns`v es thebe
ite_   /// letp  DFAns. O
    the,
cfg(rgetit/ es thebe
zero.e provid
    }

 d Dn thtota3  to tDm  #(as theexc/
   nt pklocldto tDlimit,xitrantees correspo<&* [`seave hand. _to_dso pc    / /// Runhe c(yato
be/no tD, toc ur,fied lizedddcetit'
 he c(yat   /eklocldty pws thehdianfaif dtlgegsb rma mit/gote provideriaiti Durposaiany ursdini(
big   #[d co: S irtKind,w("fo-builookm: &LookM// isr,w("fo-buip  DFAn_ial:/Opdty      #>,g("fo  /// ```
  SunrtTto tting
u32> ,ucfg(feature = "dfa-buii oletcturn ial) e
p  DFAn_ial {
big   #[cfg( => df!(ial <=DP  DFAnID::LIMIT)n to_bytes}_endian(
tch,Pu   / e
Sunch::ialbuf` is big ideOK/ing
    2*4zis t an egon` ono implfl   eny//n` ._endian(
tch,Punchs_ial e
 t   /:o a val_ `
(2    // `buf` is big tch,p  DFAn_Punchs_ial e
big   #[cfg( nativde   /:o a val_ `
(p  DFAn_ial   // `_or(0_s
    #[cfg(an(
ytesturn x)
=>
x,   #[cfg(an(
ytesNone
=>
/ * [`Deat(cfg(featur::too_manw_ndirt Punaes.) ,   #[cfg(an(
}/
    an(
tch,nto t_ial e
 nativdenchs_ial.o a val_addyp  DFAn_Punchs_ials
    #[cfg(an(
turn x)
=>
x,   #[cfg(an(
None
=>
/ * [`Deat(cfg(featur::too_manw_ndirt Punaes.) ,   #[cfg(}; "dfa-buii oletceat(_)
=zis  # itry_gnor(nto t_ial)     #[cfg(an(
/ * [`Deat(cfg(featur::too_manw_ndirt Punaes.) n to_bytes}_endian(
tch,nto t revec![DEAD.    32buf,nto t_ial];_endian(
tch,Punch_map e
SunchBoinMap:: = Slookmuf` is big   /SunrtTto t {
big   #[cfg(nto t,   #[cfg(an(
kind,w("fo-buiany sench_mapd
cfg(an(
ytesst   /d
cfg(an(
ytesp  DFAn_iald
cfg(an(
ytesuniite_al_seirt  nato _df
:/None,   #[cfg(    uniite_al_seirt ato _df
:/None,   #[cfg(})` is  -e()ian(<'a> SunrtTto tt&'a rning V= "dfaness  [ur a   #(arnto t Vecden
 ntt`se/IDe den
  ign ta DFA, but we ign correspo` rm m`. Undi tucg s ,ae_* [`Dite_tota3    /// let: [usor/adtelgegswset
cfg(rget
  _/to t Vecden
  igntt`selIDe.lized the provided Dn td {walizaproof m&desur a    ign  yo_natlletit'sden
  ignID ,
cfg(rget
  _Ditto_re* [`seave hand.
Noa ofy,ling alhtches drm m  configurndia
cfg(rget
  _duseda  gnself,ali`Sun thi`, uaranteespwsed re* [`Dave hand (amo` _endilize 
    :alloc_ah hands). any st)
    }

    /// R
    ///
    /inecudo  Th  rsen serime. any st)
    }

 # Safety any st)
    }

    //not trueisethat //  ing
    A<&dconfigurc/eorig/ `validlfwae oede_endisuchtt`rt igntt`selIDe er msasvs .e  /_native_en,mer r   /// lettt`rt ige providedDe c[nebeylet Drino tDl` in DFso
it'
 :alloc_ah    /c/eor ign //ire providevalidlfwac[nthat// done
 Th  rsen serime. An
 T DFA's tg
  igntt`se
 providedDDis that //  ing
     
    code.ta T/ ly/// a lsden
  ignID D_bipldst)
     method (t bh alitesrm dtgbetypsrc/eorielisty ).*Tned rma ,/
 e T DFA'_endisuchtt`rt IDsc[nel/adt, tund/ficignbendiiop:NE>(dst)
    }

 C[u3mpso
        teespfun  -> (mral ei
    p =>a// a lisafetye T Drin s_endilize d // that cn    /imme: [usotches   /// Ti DFA's tg
  igntt`selIDe.lized th    //// that cn/ Repheln(lizy me: [usot mates liz`t mat_to`.
    un //  ursfn s_: [us_ to a val( Ok::<(), ensBrm m: &'a rn8]())
    /// ```
  (SunrtTto tt&'a rning ,
    #[,s  [ur a   #eature = "dfa-builetcBrm mlPunch eesrm m:as_ptry_        #()f` "dfa-builetc(kind,enr) e
S irtKind ignor_: [us(srm m i/
    an(
drm m = &drm m[nr..]f` "dfa-builetc(seich_mapdenr) e
S irtBoinMap::gnor_: [us(srm m i/
    an(
drm m = &drm m[nr..]f` "dfa-builetc(se   /henr) e   #[cfg(an(
wire::try_r/ad_nin_       #(srm m,e"mtrrtv to tDde   /" i/
    an(
drm m = &drm m[nr..]f`E>(dyteshe
 t   / !e
Sunch::ialbu     #[cfg(an(
/ * [`Deat(  [ur a   #eatur::/// The(
big   #[cfg(an(
" T DFA's tg
  ign to tDde   /",   #[cfg(an(
u);   #[cfg(} _endian(
tch,(ta be_p  DFAn_ialdenr) e   #[cfg(an(
wire::try_r/ad_nin_       #(srm m,e"mtrrtv to tDp  DFAns" i/
    an(
drm m = &drm m[nr..]f`E>(dytestch,p  DFAn_ial e
he
ta be_p  DFAn_ial.    32bu
e=enin::MAX     #[cfg(an(
None   #[cfg(}ielse
    #[cfg(an(
turn ta be_p  DFAn_ial)   #[cfg(}; "dfa-buii op  DFAn_ial.m `_or(false, |ial|Dl`  >DP  DFAnID::LIMIT)     #[cfg(an(
/ * [`Deat(  [ur a   #eatur::/// The(
big   #[cfg(an(
" T DFA's   /// letp  DFAns",   #[cfg(an(
u);   #[cfg(} _endian(
tch,(uniite_al_ nato _df
denr) e   #[cfg(an(
wire::try_r/ad_nin(srm m,e"uniite_alhunato _df
e trrt" i/
    an(
drm m = &drm m[nr..]f`E>(dytestch,uniite_al_seirt  nato _df
 e
he
uniite_al_ nato _df

e=enin::MAX     #[cfg(an(
None   #[cfg(}ielse
    #[cfg(an(
turn tun thi::try_gnor(uniite_al_ nato _df
).map_ ha(|e|
    #[cfg(an(
ytes  [ur a   #eatur::ndiaecid_ hand(
big   #[cfg(an(
  #[e,   #[cfg(an(
ytesssss"uniite_alhunato _df
e trrt",   #[cfg(an(
ytess   #[cfg(an(
})?)   #[cfg(}; _endian(
tch,(uniite_al_ato _df
denr) e   #[cfg(an(
wire::try_r/ad_nin(srm m,e"uniite_alhato _df
e trrt" i/
    an(
drm m = &drm m[nr..]f`E>(dytestch,uniite_al_seirt ato _df
 e
he
uniite_al_ato _df

e=enin::MAX     #[cfg(an(
None   #[cfg(}ielse
    #[cfg(an(
turn tun thi::try_gnor(uniite_al_ato _df
).map_ ha(|e|
    #[cfg(an(
ytes  [ur a   #eatur::ndiaecid_ hand(m,e"uniite_alhato _df
e trrt"    #[cfg(an(
})?)   #[cfg(}; _endian(
tch,p  DFAn_nto t_m  #(e
wire:: `
(
big   #[cfg(st   /d
cfg(an(
ytesp  DFAn_ial   // `_or(0_eed
    #[cfg(" T DFA'sp  DFAn >` in ",   #[cfg( ?;
  #[cfg(ideOurcden
 ntt`se DeewriteseirtDwset.a Kwovde   / Vece irtv trans/se urnedan(
 Ha recruser'sautomatonal strfiral  t   / iseill unato _df
e t`rt ige pro n(
 Hadense D
    //bPa)
  
 t   / iseill ato _df
e t`rt igv transalW///
cfg( n(
 Hafo lowK
i /elenaveopti//als E: Vecden
 ntt`se Drmatmativp  DFAn:NE>(dan(
tch,Punch_seiaecial(e
wire::addy   #[cfg(an(
wire:: `
(2,e t   /he"den
 ntt`se/ t   / too*big" id
cfg(an(
ytesp  DFAn_nto t_m  #eed
    #[cfg(" T DFA's'  y'sp  DFAn seirt /t  #",   #[cfg( ?;
  #[cfg(tch,nto t_: [us_ial e
wire:: `
(
big   #[cfg(Punch_seiaecial,   #[cfg(an(
tun thi::SIZEeed
    #[cfg("p  DFAn r of i_ [uso>` in ",   #[cfg( ?;
  #[cfg(tire::o a v_ rm m_ial. rm m,ento t_: [us_ial, "tt`rt IDs to t" ?;
  #[cfg(tire::o a v_a  gnself:: hen thi (srm m i/
    an(
tch,nto t_: [us = &drm m[..nto t_: [us_ial]/
    an(
drm m = &drm m[nto t_: [us_ial..]f`endian(
/ *SAFETY:uot
   hen thD isenhwriteas'a [u32]o tDelizanin,DFlar,e/ =ed (1<<an(
 Harotoo(to_ensure
    /we/ndiane endiaper >` in lendno  gnselftuWe'vu and an(
 Ha  a val.// thafa: DFso
  encrao bel    sisafe._endian(
 H   #[cfg(.
 / }
    /// Rt eeVfromtha- //  code.s_Ditto_fun  -> .
    an(
tch,nto t rec re::srm m:ignor_raw_pirt (
big   #[cfg(nto t_: [us:as_ptry_ crao:: u32>( d
cfg(an(
ytesPunch_seiaecial,   #[cfg();_endian(
tch,Pu e
S irtTto t {
big   #[cfg(nto t,   #[cfg(an(
kind,w("fo-buiany sench_mapd
cfg(an(
ytesst   /d
cfg(an(
ytesp  DFAn_iald
cfg(an(
ytesuniite_al_seirt  nato _df
,   #[cfg(    uniite_al_seirt ato _df
,   #[cfg(}; "dfa-bui  /(st,earm m:as_ptry_        #() -ePrm mlPunch)n to_byte()ian(<esentations, su>yS irtTto ttT>i{w("foo123W matlizasEr a   #//formtletteeszmtrrtv to tD, ta libuffnd /, th. If
cfg(rget
  _buffnd esznoo* &[u3,arintehve hand to_re* [`nn:HTotoial numc/now_endilizebigDn thbuffnd mral be,     `t mat_to_ial`.lizedfnst mat_to<E: ETopan>( Ok::<(), Box<dyn std::e/ensdstby  ensrn8]())
    /// ```
      #, Sur a   #eature = "dfa-builetcnt mat = l unut mat_to_ialbuf` is big he
dst ial.w
<cnt mat     #[cfg(an(
/ * [`Deat(Sur a   #eatur::buffnd_too_ &[u3(
big   #[cfg(an(
" tg
  ign to tDids",   #[cfg(an(
u);   #[cfg(}   #[cfg(dst = &/ensdst[..nt mat]f` "dfa-bui

 t mat mtrrtvkind "dfa-builetcnt = l unukindut mat_to:: E> dst)?;   #[cfg(dst = &/ensdst[nw..]f`endian(
/ *t mat mtrrtv: [usnap "dfa-builetcnt = l unusench_map.t mat_to(dst)?;   #[cfg(dst = &/ensdst[nw..]f`endian(
/ *t mat mt   / "dfa-bui

 U // `// ROKeaddingn th t   / isenhwrite4 ( urrelf y)._endian(
E::t mat_ 32bnin::try_gnor(  unu t   /    // `bu,sdst);   #[cfg(dst = &/ensdst[   #_of:: u32>( ..]f`endian(
/ *t mat p  DFAn >` in  "dfa-bui

 U // `// ROKeadding   /// let_n DFAns   R
    ///
    /fi /iTizanin.
    an(
E::t mat_ 32b   #[cfg(    uin::try_gnor(  unup  DFAn_ial   // `_or(0xFFFF_FFFF)    // `bu,
big   #[cfg(dst,   #[cfg();_endian(
dst = &/ensdst[   #_of:: u32>( ..]f`endian(
/ *t mat uniite_alhden
  unato _df
e t`se/i ,enin::MAX if/
bself and an(
E::t mat_ 32b   #[cfg(      unuuniite_al_seirt  nato _df

big   #[cfg(an(
.m `_or(nin::MAX, |sid|eadd.    32buu,
big   #[cfg(dst,   #[cfg();_endian(
dst = &/ensdst[   #_of:: u32>( ..]f`endian(
/ *t mat uniite_alhden
  ato _df
e t`se/i ,enin::MAX if/
bself and an(
E::t mat_ 32b   #[cfg(      unuuniite_al_seirt ato _df
.m `_or(nin::MAX, |sid|eadd.    32buu,
big   #[cfg(dst,   #[cfg();_endian(
dst = &/ensdst[   #_of:: u32>( ..]f`endian(
/ *t mat tt`rt IDs   #[cfg(ampl&si
    l unus of ()     #[cfg(an(
tch,l e
wire::t mat_ndiae_ 
:: E> si
, &/ensdst /
big   #[cfg(dst = &/ensdst[n..]f`  #[cfg(}   #[cfg(  /nt mat     ) -> Result<Re* [`sDite_   /// let: [uso //bPar a   #//formtletteesztt`rt IDs to t> Result<wsed    .lizedfnst mat_to_ial. Box<  ///    # = "dfa-buil unukindut mat_to_ial.w   #[-bui+il unusench_map.t mat_to_ial.w   #[-bui+il  #_of:: u32>( n Ha t   /   #[-bui+il  #_of:: u32>( n Ha#o_n DFAns any -bui+il  #_of:: u32>( n Hauniite_alhunato _df
e trrt any -bui+il  #_of:: u32>( n Hauniite_alhato _df
e trrt any -bui+i(l unus of () ial.w
*
tun thi::SIZE     ) -> Result<VDFA'ianan    /e/// Fstg
  IDs Thislizmtrrtv to tDis  DFA'sby/c/eor ig
cfg(rgetit/agairseg alhtches nds
    /// to tD(  }

 mral be rmatf tvdusedre:).lized the provide    /is,
e/// Fstg
  IDsc[nebeynann(no   ethodly_rToexlagth do.lizedfns DFA'ian( Box<,eor by  retT>  /// ```
  ([,s  [ur a   #eature = "dfa-builetcth ee&natuttf` is big he
!  unuuniite_al_seirt  nato _df
.m `_or(iven, |s|
tt 
s_ DFA'(s))     #[cfg(an(
/ * [`Deat(  [ur a   #eatur::/// The(
big   #[cfg(an(
"fetyp
 T DFA'suniite_alhunato _df
e trrt igntt`selID",   #[cfg(an(
u);   #[cfg(}   #[cfg(he
!  unuuniite_al_seirt ato _df
.m `_or(iven, |s|
tt 
s_ DFA'(s))     #[cfg(an(
/ * [`Deat(  [ur a   #eatur::/// The(
big   #[cfg(an(
"fetyp
 T DFA'suniite_alhato _df
e trrt igntt`selID",   #[cfg(an(
u);   #[cfg(}   #[cfg(ampl&i
    l unus of ()     #[cfg(an(
he
!tt 
s_ DFA'(ids
    #[cfg(an(
ytes/ * [`Deat(  [ur a   #eatur::/// The(
big   #[cfg(an(
  #["fetyp
 T DFA's tgrt igntt`selID",   #[cfg(an(
ssss) /
big   #[cfg(}
cfg(an(
}` is big   /()n to_bytes_nativeC rre
 stteeszmtrrtvlg aD, ta
borrowal. Dlu .lizedfnsas_ref( Box<  ///SunrtTto tt&'_ rning V= "dfa-buiS irtTto t {
big   #[cfg(nto t: l unus of  as_ref(.d
cfg(an(
ytesd co: l unukind,w("fo-buiany sench_map:il unusench_map.clgen(.d
cfg(an(
ytesst   /:
  unu t   /d
cfg(an(
ytesp  DFAn_ial:
  unup  DFAn_iald
cfg(an(
ytesuniite_al_seirt  nato _df
:/  unuuniite_al_seirt  nato _df
,   #[cfg(    uniite_al_seirt ato _df
:/  unuuniite_al_seirt ato _df
,   #[cfg(}yn st -> Result<C rre
 stteeszmtrrtvlg aD, tan ownFh. Dlu .lized public `to_bytesd loc"atiany ursto_ownFh( Box<  ///SunrtTto ttd loc::vec::ing
u32> V= "dfaytesS irtTto t {
big   #[cfg(nto t: l unus of  as_ref(.uso_vec(.d
cfg(an(
ytesd co: l unukind,w("fo-buiany sench_map:il unusench_map.clgen(.d
cfg(an(
ytesst   /:
  unu t   /d
cfg(an(
ytesp  DFAn_ial:
  unup  DFAn_iald
cfg(an(
ytesuniite_al_seirt  nato _df
:/  unuuniite_al_seirt  nato _df
,   #[cfg(    uniite_al_seirt ato _df
:/  unuuniite_al_seirt ato _df
,   #[cfg(}yn st -> Result<Re* [`Dite_den
 ntt`se/rmatn thtches ipect 
   th rt ignc rfigurldty .lized th    //re* [`seave handling alhipect c rfigurldty pis that uppor cn(li
cfg(rget
 espeEr: Ficesxaan(&,hrsl e a ignbtounato _df
e a ///Dwinteent lengwas any lizethatrialsewsethunato _df
e trrt igntt`ses. Orsaskipleill bt bto _df
 to_bworkp  DFAn sa ///Dwset.an
 T DFA'sp  DFAn IDe d oTha_re:
    /was tha_endilizebialsewsethden
 ntt`se Drmatmativp  DFAn:NE>(d publ_  Dric `to_bytesperf-inltru",
inltru(nhwrit)atiany ursden
 ( Ok::<(), Box<dyn std::eato _df
:/Ato _df
,   #[cfg(den
 : S irt,g("fo  /// ```
  Sun thi,uS irteature = "dfa-builetcBeirt rToexl=cBeirt.       #()/
big   #[letciToexl=c nativato _df
e{
big   #[cfg(Ato _df
::No
=>
{
cfg(cfg(an(
yteshat!/ unukinduh    nato _df
(w
{
big   #[cfg(an(
ytes/ * [`Deat(S irteatur::un uppor cn ato _df
(ato _df
) /
big   #[cfg(an(
}
big   #[cfg(an(
Beirt rToex
big   #[cfg(}
cfg(an(
ytesAto _df
::Yus =>
{
cfg(cfg(an(
yteshat!/ unukinduh   ato _df
(w
{
big   #[cfg(an(
ytes/ * [`Deat(S irteatur::un uppor cn ato _df
(ato _df
) /
big   #[cfg(an(
}
big   #[cfg(an(
B unu t   /i+ileirt rToex
big   #[cfg(}
cfg(an(
ytesAto _df
::P  DFAn(pids
=>
{
cfg(cfg(an(
yteslctk>`  e
 nativd unup  DFAn_ial
{
big   #[cfg(an(
ytesNone
=>
{
big   #[cfg(an(
  #[cfg(/ * [`Deat(S irteatur::un uppor cn ato _df
(ato _df
) 
big   #[cfg(an(
  #[}
big   #[cfg(an(
  #[turn ial) e> iald
cfg(an(
ytescfg(}; "dfa-bui"dfa-buii opid.       #() >= ial
{
big   #[cfg(an(
ytes/ * [`D  /DEAD /
big   #[cfg(an(
}
big   #[cfg(an(
(2 * t unu t   / 
big   #[cfg(an(
ytes+i(l unuse   / * pid.       #() 
big   #[cfg(an(
ytes+ileirt rToex
big   #[cfg(}
cfg(an(
}; "dfa-bui  /  unus of ()[iToex])yn st -> Result<Re* [`seavertould &timpleved tt`
 ntt`se/IDe  Thislizrto t.e provid
    }

 Eativrtoml/ Race  p t Ve: tt`
 ntt`se/ID,Dite_den
 ntt`se/typeD
    // to_bworkp  DFAn IDe(if/
 y). any ursrtou( Box<  ///Sunrthen thtou<'_ V= "dfaytesS irthen thtou { st: l unuas_ref(.d i: 0(}yn st -> Result<Re* [`seite_ to tDelizasrm m
letdense ID aiany urst of (&Box<  ///&[Sun thi] = "dfa-buiwire::u32s_so_ndiaecids(l unus of  as_ref(.
    ) -> Result<Re* [`Dite_me n yeu age,eiTt: [us,tletteeszmtrrtvlg a.e provid
    }

    //dconfigur   luds.ess.d  # Veca/`S irtLg a`vtes_n(t ()
 .NE>(dfns/e n y_u age. Box<  ///    # = "dfa-buil unus of () ial.w
*
tun thi::SIZE to_byte() public `to_bytes` serializatiian(<esentMutons, su>yS irtTto ttT>i{w("foo123SetDite_den
 ntt`se/rmatn thtches ipoexlandvp  DFAn:NE>(dvid
    }

 d Dn thp  DFAn IDe d stg
  IDselenthat DFA',arintnteespwsed panic. to_bursdet_seirt(&/ensBox<,sato _df
:/Ato _df
,(den
 : S irt,eid:tSun thi  = "dfa-builetcBeirt rToexl=cBeirt.       #()/
big   #[letciToexl=c nativato _df
e{
big   #[cfg(Ato _df
::No
=>
Beirt rToex,
cfg(an(
ytesAto _df
::Yus =>
B unu t   /i+ileirt rToex,
cfg(an(
ytesAto _df
::P  DFAn(pids
=>
{
cfg(cfg(an(
yteslctkpi
 ecpid.       #()/
big   #[an(
yteslctk>`  e
B un
big   #[cfg(an(
ytesup  DFAn_ial
big   #[cfg(an(
ytesuexpect("e irtv trans/se omativp  DFAn sn of d")/
big   #[an(
ytes => df!(pi
 <iial, " T DFA'sp  DFAn IDe{:?}",
pids;
big   #[cfg(an(
B unu t   /
big   #[cfg(an(
ytesuo a val_ `
(piom to_b  #[cfg(an(
ytesu  // `bu
big   #[cfg(an(
ytesuo a val_addyB unu t   /:o a val_ `
(2    // `bum to_b  #[cfg(an(
ytesu  // `bu
big   #[cfg(an(
ytesuo a val_addyBeirt rToexm to_b  #[cfg(an(
ytesu  // `bu
big   #[cfg(}
cfg(an(
}; "dfa-bui/ unur of _ en()[iToex] ecid;yn st -> Result<Re* [`seite_ to tDeliza ento tDdrm m
letdense ID aiany urst of _ en(  ensBox<  ///  ensrSun thi] = "dfa-buiwire::u32s_so_ndiaecids_ en(l unus of  as_ en().   #[ -e()
  lAvertould &timplee irtv tran ID ai
  
}

    ///tould &tyieldvza t  p t Ve tt`
 ntt`se/ID,Dite_ato _df
emode.
    // lize trrtv tran/type.ed Dasp  DFAn IDe //relevant,arinteent ato _df
emode.wsed
}

   r// Tiit. S irtv trans/wset.an
ato _df
emode.  r// Tf oma p  DFAn IDewsed
}

 Vfromoc urDwinteent lengwas comtif dtwsethden
 ntt`se Drmatmativp  DFAn

  l(  }

    dis of dsby/defa`
 ). , ued for)tse
    S irthen thtou<'a>
{
cfg(s : S irtTto tt&'a rning ,
cfg(i:
    #,ge()ian(<'a> Itould &trmatS irthen thtou<'a>
{
cfg(typeDItoml= (Sun thi,uAto _df
,(S irt)f` "dfaursn=xt(  ensBox<  ///Opdty  (Sun thi,uAto _df
,(S irt)e = "dfa-builetci = l unui;
    an(
tch,nto t reB unu tus of ()f` is big he
i >= s of  ialbu     #[cfg(an(
/ * [`DNone;   #[cfg(}   #[cfg(l unui += 1f` "dfa-bui

    //u // `// Rokayeaddingn th t   / letit'sden
  ignmtranarao t> Resan(
o[0mral uhwrite nativuars   /// lettt`rtv tran(types:NE>(dan(
tch,Punch_typeDe
Sunch::gnor_    #(i %   unuseu t   /    // `bu;
    an(
tch,ato _df
 e
he
i <   unuseu t   /e{
big   #[cfg(Ato _df
::No   #[cfg(}ielse
he
i < (2 * t unu tu t   / e{
big   #[cfg(Ato _df
::Yus   #[cfg(}ielse
    #[cfg(an(
lctkpi
 ec(i - (2 * t unu tu t   / ) / t unu tu t   /;
cfg(an(
ytesAto _df
::P  DFAn(P  DFAnID:: = Spiom   // `bum to_b  #[}; "dfa-buiturn (nto t[i],sato _df
,,Punch_type).   #[ -e()
  l slizrypeD<&'a [u32l
    /_n DFAns     / es thebe
<&'or cn(wint an ehelen)
  lu32ersize nativdenseal seszmt
   o_byexg asz  /suppor s res
    / a ///eill

  l // is trmat `
 itl tregexes.

  
}

    //st
   o_byreli stV/ er rfacttit  /ekle nativdense D Tha_re:moc ur
}

   r/iguous Th This reEr'sznds
    /// to t. (Seeeor /Pate a .rseill a  n t
}

 detaif dtbreakdown letit'sas'a [u32]dty .) Namefy,lwhenp)0maati mc urs  //
}

 kn    t /tt`se ID.eot
   we kn   ite_den
 n
   eia letit's  r/iguoustreg // }

 Vfe nativdense   ///c[ne    teat(no   mpudo  //b,ala pow   /w }

  //b/aati_lizedt`se mc urs:  a  /i//  [`D/ Retupializn offeese T, tt  //st
   o_b. #[der ve(Clgen,s  bugatise
    M// iSun tstT>i{w("foo123Slpc  r/ Racfln DFnf
e aquen m
letpair ,ew ed {mativp irDurposes, ta_endisuchtub-drm m
letp  DFAn_idsal strfiral e(&self,e overvp irDilizn offees_endilize Ttotp  DFAn_ids/
    //bPa)
  
e(&self,e overvp irDiliuars   ///_endilize f 32-bit p  DFAn IDs den
  ign ta D  /_ala pow:  a  /is,
mativp ir and `$`.n ve_endiaes, tatdddg tDre:m nativdenses
   hts   ve_endian` u/aati_endilizeID a3T th   /// letpair Dehwriten ve_endiaes, tit's   /// letdg a ics_endilizere:m nativdense aiany st)
    }

 _to_dso pc   T OK
ei
    ing
u32>e d urning:NE>(dslpc  : T,w("foo123Acfln DFnf
e aquen m
letpa DFAn IDs rmatmativre:m nativdensea3T thonigfied ult<wri(no   ethodly_r/adtt  //saquen m
/ R Tdithodly_viao` rm ms`aiany st)
    }

 _to_dso pc   T OK
ei
    ing
u32>e d urning:NE>(dp  DFAn_ids: T,w("foo123T thtota3    /// letuniquth_n DFAns <&'a [u32ed/lizy msem nativdense aiany p  DFAn_ial:
    #,ge()ian(<'a> M// iSun tst&'a rning V= "dfaun //  ursfn s_: [us_ to a val( Ok::<(), ensBrm m: &'a rn8]())
    /// ```
  (M// iSun tst&'a rning ,
    #[,s  [ur a   #eature = "dfa-builetcBrm mlPunch eesrm m:as_ptry_        #()f` "dfa-built<ReadDite_tota3    /// let nativdense aiany -builetc(seiaecial,enr) e   #[cfg(an(
wire::try_r/ad_nin_       #(srm m,e" nativdenses>` in " i/
    an(
drm m = &drm m[nr..]f` "dfa-built<ReadDite_drm m e irt/>` in lpair ._endian(
tch,p ir_ial e
wire:: `
(2,e tiaecial,e" nativdensesoffeesepair " i/
    an(
tch, rm ms_: [us_ial e
wire:: `
(
big   #[cfg(p ir_ial,
cfg(an(
ytesP  DFAnID::SIZEeed
    #[cfg(" nativdensesdrm m
lefeese: [us>` in ",   #[cfg( ?;
  #[cfg(tire::o a v_ rm m_ial. rm m,e rm ms_: [us_ial,(" nativdensesdrm ms" ?;
  #[cfg(tire::o a v_a  gnself:: P  DFAnID (srm m i/
    an(
tch, rm ms_: [us = &drm m[.. rm ms_: [us_ial]/
    an(
drm m = &drm m[ rm ms_: [us_ial..]f`endian(
/ *SAFETY:uot
   P  DFAnID isenhwriteas'a [u32]o tDelizanin,DFlar,e`endian(
/ *t/
    /oo(to_ensure
    /we/ndiane endiaper >` in lendno  gnselft
cfg(an(
lenWe'vea  a val.// thafa: DFso
  encrao bel    sisafe._endian(
 H   #[cfg(.
 / }
    /// Rone
e overvfewmtha- //  snippets.s_Ditto_fun  -> ,e pro n(
 Hado/we/marktit/tesrm dt(yato
s bitit/out.
    an(
tch, rm ms rec re::srm m:ignor_raw_pirt (
big   #[cfg( rm ms_: [us:as_ptry_ crao:: u32>( d
cfg(an(
ytesp ir_ial,
cfg(an(
)f` "dfa-built<ReadDite_tota3    /// letuniquth_n DFAn IDs (  }

    nhwrite1  n t
rnedan(
 Ha ra`Dite_maximumsp  DFAn IDe _Ditto_automaton,eadding_n DFAn IDs a t
rnedan(
 Hah
    //ct c r/iguous Thden
  ign ta0)aiany -builetc(p  DFAn_ialdenr) e   #[cfg(an(
wire::try_r/ad_nin_       #(srm m,e"p  DFAn >` in " i/
    an(
drm m = &drm m[nr..]f` "dfa-built<N   readDite_p  DFAn IDe>` in tuWe don'l t/
    /stma mtees corr-built<tesrm dt(y,abutg,e/ =edtit/  /kn   now m  yo_n DFAnlIDe eo readaiany -builetc(idialdenr) e   #[cfg(an(
wire::try_r/ad_nin_       #(srm m,e"p  DFAn IDe>` in " i/
    an(
drm m = &drm m[nr..]f` "dfa-built<ReadDite_ux<dyno_n DFAnlIDe._endian(
tch,p  DFAn_ids_ial e
big   #[cfg(wire:: `
(idialdeP  DFAnID::SIZEee"p  DFAn IDe: [us>` in " ?;
  #[cfg(tire::o a v_ rm m_ial. rm m,ep  DFAn_ids_ial,(" nativp  DFAn IDs" ?;
  #[cfg(tire::o a v_a  gnself:: P  DFAnID (srm m i/
    an(
tch,p  DFAn_ids_: [us = &drm m[..p  DFAn_ids_ial]/
    an(
drm m = &drm m[p  DFAn_ids_ial..]f`endian(
/ *SAFETY:uot
   P  DFAnID isenhwriteas'a [u32]o tDelizanin,DFlar,e`endian(
/ *t/
    /oo(to_ensure
    /we/ndiane endiaper >` in lendno  gnselft
cfg(an(
lenWe'vea  a val.// thafa: DFso
  encrao bel    sisafe._endian(
 H   #[cfg(.
 / }
    /// Rone
e overvfewmtha- //  snippets.s_Ditto_fun  -> ,e pro n(
 Hado/we/marktit/tesrm dt(yato
s bitit/out.
    an(
tch,p  DFAn_ids/rec re::srm m:ignor_raw_pirt (
big   #[cfg(p  DFAn_ids_: [us:as_ptry_ crao:: u32>( d
cfg(an(
ytesidiald
cfg(an(
)f` "dfa-buitch,ms/reM// iSun ts { srm ms,ep  DFAn_ids,,p  DFAn_ial }; "dfa-bui  /(ms,earm m:as_ptry_        #() -ePrm mlPunch)n to_byte() public `to_bytes` serializatiian( M// iSun tsting
u32> V= "dfaursemp:w(p  DFAn_ial:
    #  ///M// iSun tsting
u32> V= "dfaytes => df!(p  DFAn_ial <=DP  DFAnID::LIMIT)n to_bytesM// iSun ts { srm ms:evec![],dp  DFAn_ids: vec![],dp  DFAn_ial }yn st -> Resursn=w( Ok::<(), // is : &BTrenMap Sun thi,uing
P  DFAnID >,w("fo-buip  DFAn_ial:/    #,g("fo  /// ```
  M// iSun tsting
u32> ,ucfg(feature = "dfa-buitch,mutgm/reM// iSun ts::emp:w(p  DFAn_ial)n to_bytesrmat(_,
pids).s_D // is .rtou()     #[cfg(an(
tch,Punch eeP  DFAnID:: = Sm.p  DFAn_idsuial.w)
big   #[cfg(an(
.m `_ ha(|_| cfg(featur::too_manw_ // i_p  DFAn_ids.w)?;
cfg(an(
ytesm. rm ms.push(Beirt.    32buu;
cfg(an(
ytes

    /// Rehwriten ve_od dddingn th   /// let_n DFAns  ntatdddg t
cfg(an(
ytes

  nativdensesc[net an eexc/
  maximums   /// letd lowao t> Resan(
ytes

 p  DFAns. Why? Bng
    a p  DFAn c[neVfromnppeax on m
/nta_endian(
ytes

 p ative_en  nativdense,sby/c rse
   -ow: (A   tddinged! p  DFAn
endian(
ytes

 IDe>imit// Rone
l s t   nenin::MAX, we'_by
    ///
      /imm
endian(
ytes

 >` in lfits/iTizanin.)
cfg(an(
ytesm. rm ms.push(uin::try_gnor(pidsuial.w)   // `bum;
cfg(an(
ytesampl&pi
    pids
{
cfg(cfg(an(
ytesm.p  DFAn_idsupush(pdd.    32buu/
big   #[cfg(}
cfg(an(
}` is big m.p  DFAn_ial e
p  DFAn_ial; "dfa-bui  /m)yn st -> Resursn=w_wset_map( Ok::<(), Box<dyn std::e/// is : &BTrenMap Sun thi,uing
P  DFAnID >,w("fo  /// ```
  M// iSun tsting
u32> ,ucfg(feature = "dfa-buiM// iSun ts:: = Sm// is ,vd unup  DFAn_ialn to_byte()ian(<esentations, su>yM// iSun tstT>i{w("foo123W matlizasEr a   #//formtlettemsem nativdense D, ta libuffnd /, th. If
cfg(rget
  _buffnd esznoo* &[u3,arintehve hand to_re* [`nn:HTotoial numc/now_endilizebigDn thbuffnd mral be,     `t mat_to_ial`.lizedfnst mat_to<E: ETopan>( Ok::<(), Box<dyn std::e/ensdstby  ensrn8]())
    /// ```
      #, Sur a   #eature = "dfa-builetcnt mat = l unut mat_to_ialbuf` is big he
dst ial.w
<cnt mat     #[cfg(an(
/ * [`Deat(Sur a   #eatur::buffnd_too_ &[u3(" nativdenses" );   #[cfg(}   #[cfg(dst = &/ensdst[..nt mat]f` "dfa-bui

 t mat mtr
  IDs>` in  "dfa-bui

 U // `// ROKeadding   /// letdense D  R
    ///
    /fi /iTizanin.
    an(
E::t mat_ 32buin::try_gnor(  unuial.w)   // `bu,sdst);   #[cfg(dst = &/ensdst[   #_of:: u32>( ..]f` "dfa-bui

 t mat mrm m
lefeesepair 
an(
ytesampl&pi
    t unu rm ms()     #[cfg(an(
tch,l e
wire::t mat_p  DFAn_id:: E> pi
, &/ensdst /
big   #[cfg(dst = &/ensdst[n..]f`  #[cfg(} `endian(
/ *t mat uniquth_n DFAn ID >` in  "dfa-bui

 U // `// ROKeadding   /// let_n DFAns   R
    ///
    /fi /iTizanin.
    an(
E::t mat_ 32buin::try_gnor(  unup  DFAn_ial)   // `bu,sdst);   #[cfg(dst = &/ensdst[   #_of:: u32>( ..]f` "dfa-bui

 t mat _n DFAn ID >` in  "dfa-bui

 U // `// ROKeaddingwea  a vn tac rse
   -ow (endndesur a   ]dty )
rnedan(
 Ha ratgn th   /// let_n DFAns  teas'a [u32]o tDelizanin.
    an(
E::t mat_ 32buin::try_gnor(  unup  DFAn_ids.wuial.w)   // `bu,sdst);   #[cfg(dst = &/ensdst[   #_of:: u32>( ..]f` "dfa-bui

 t mat p  DFAn IDs
an(
ytesampl&pi
    t unup  DFAn_ids.w     #[cfg(an(
tch,l e
wire::t mat_p  DFAn_id:: E> pi
, &/ensdst /
big   #[cfg(dst = &/ensdst[n..]f`  #[cfg(} `endian(
  /nt mat     ) -> Result<Re* [`sDite_   /// let: [uso //bPar a   #//formtlettemsem nativdense > Result<wsed    .lizedfnst mat_to_ial. Box<  ///    # = "dfa-buil  #_of:: u32>( nes

  nativdenses>` in  "dfa-bui+i(l unusrm ms() ial.w
*
P  DFAnID::SIZE) any -bui+il  #_of:: u32>( n Hauniquth_n DFAn ID >` in  "dfa-bui+il  #_of:: u32>( n Ha_n DFAn ID >` in  "dfa-bui+i(  unup  DFAn_ids.wuial.w
*
P  DFAnID::SIZE) any  -> Result<VDFA'eK
    /n th nativdensesinfo(to_ot()
 Ai32ernh. Th  /s stelf,aiae provide  /s stelf,wset.
  _e_oordedh nativdensesreg //h This rtches re::Nizedfns DFA'ian( Box<,eor by  retT>  /// ```
  ([,s  [ur a   #eature = "dfa-buihe
  unuial.w !e
natuPate a . // i_ial.natuPe   /an)     #[cfg(an(
/ * [`Deat(  [ur a   #eatur::/// The(
big   #[cfg(an(
" nativdenses>` in  mis nati",   #[cfg(an(
u);   #[cfg(}   #[cfg(amplsih Th0..  unuial.w     #[cfg(an(
tch,Punch eel unusrm ms()[  
*
2].       #()/
big   #[an(
lctk>`  e
B unusrm ms()[  
*
2i+i1].       #()/
big   #[an(
iettt`rtv>=   unup  DFAn_ids.wuial.w
    #[cfg(an(
ytes/ * [`Deat(  [ur a   #eatur::/// The(
big   #[cfg(an(
  #[" T DFA'sp  DFAn IDeden
 ignfees",   #[cfg(an(
ssss) /
big   #[cfg(}
cfg(an(
an(
iettt`rtv+Dl`  >D  unup  DFAn_ids.wuial.w
    #[cfg(an(
ytes/ * [`Deat(  [ur a   #eatur::/// The(
big   #[cfg(an(
  #[" T DFA'sp  DFAn IDe>` in ",   #[cfg(an(
ssss) /
big   #[cfg(}
cfg(an(
an(
rmat ih Th0..ial
{
big   #[cfg(an(
lctkpi
 ec  unup  DFAn_id(si,t i); "dfa-bui"dfa-buii opid.       #() >= d unup  DFAn_ial
{
big   #[cfg(an(
ytes/ * [`Deat(  [ur a   #eatur::/// The(
big   #[cfg(an(
  #[  #[" T DFA'sp  DFAn ID",   #[cfg(an(
ytesssss) /
big   #[cfg(an(
}
big   #[cfg(}
cfg(an(
}` is big   /()n to_bytes_nativeC rre
 sttemsem nativdense Dbnck  T, tt ein  np/form
    /// Return 
 Result<whes dhuffl igntt`ses,Deliite_  ///lsM// iSun ts as'a [u32]dty pis tha any lize msn of    /ias Fstg
  swapp ig. Bu lwset.
 ite np,   /sw `//d1,aiae provideidn,DFlaryourt/
    /oo(to:iany st)
    }

 i oletcturn pids).=c np.removn( /d1)i{w("foo123d::e//p.in> df(idn,Dpids);w("foo123}iany st)
    }

 Odingdhuffl ign //dcne,     M// iSun ts:: = (no   rre
 Dbnck.lized public `to_bytes` serializatiany ursto_map( Box<,eor by  retT>  ///BTrenMap Sun thi,uing
P  DFAnID > = "dfa-buitch,mutgmap e
BTrenMap:: = S)n to_bytesrmatih Th0..  unuial.w     #[cfg(an(
tch,mutgpids/revec![];
cfg(an(
ytesampljh Th0..  unup  DFAn_ial(iw
    #[cfg(an(
ytespidsupush(  unup  DFAn_id(i,tj) /
big   #[cfg(}
cfg(an(
an(
//p.in> df(  unu // i_ndiaecid.nat, i),Dpids);w("foan(
}` is big map "dfaytes_nativeC rre
 sttemsem nativdense D, ta
borrowal. Dlu .lizedfnsas_ref( Box<  ///M// iSun tst&'_ rning V= "dfa-buiM// iSun ts {
big   #[cfg( rm ms:
B unusrm ms as_ref(.d
cfg(an(
ytesp  DFAn_ids:   unup  DFAn_ids as_ref(.d
cfg(an(
ytesp  DFAn_ial:
  unup  DFAn_iald
cfg(an(
} "dfaytes_nativeC rre
 sttemsem nativdense D, tan ownFh. Dlu .lized public `to_bytesd loc"atiany ursto_ownFh( Box<  ///M// iSun tstd loc::vec::ing
u32> V= "dfaytesM// iSun ts {
big   #[cfg( rm ms:
B unusrm ms as_ref(.uso_vec(.d
cfg(an(
ytesp  DFAn_ids:   unup  DFAn_ids as_ref(.uso_vec(.d
cfg(an(
ytesp  DFAn_ial:
  unup  DFAn_iald
cfg(an(
} "dfaytes_nativeRe* [`sDite_ nativdensesIDetches n th nativdensesindex: (W ere
  / to_bworkfiral  nativdensesc ve_endiaes, tiToexl0.)
cfg(vid
    }

    //panicsling alrueisethm nativdenses
ttn thtches ipoex.NE>(dfns/// i_ndiaecid. Box<,eor by  retT>, ipoex:
    #  ///hen thD = "dfaytes => df!(natuPate a . // ims(), "thm nativdensees, tiToex"uf` is big ide   /// Rone
e overvpla ms w ed {weT/ ly/// a lsfacttit  //aati_endi n(
 Hadense D
r's  r/iguoust This rnds
    /// to t. Namefy,l    /imm
endian(
orkfiral  nativdensesIDsehwriten ve_endiaes, tnatuPate a . in_Puncht
cfg(an(
lenFn su alru,eaddingweakn   ite_de   /he///c[ne  mpudo  //bIDe f/
 y
an(
ytes

  nativdensestches its/iToex.NE>(dan(
tch,Pu   /2 = uin::try_gnor(natuPe   /2.w)   // `bu/
    an(
tch,lefeese=/iToex.o a val_shl(se   /2    // `buf` is big tch,i
 ecnatuPate a . in_ nati.       #()uo a val_addylefees    // `buf` is big tch,si
 ectun thi:: = Siom   // `bu; "dfaytes => df!(natuis_/// i_ndiae si
) /
big   #[sA'_endiytes_nativeRe* [`sDite_p  DFAn IDe
ttn thtches  nativiToexlrmatn thtches /aati_endilizeth do:NE>(dst)
    }

 T th nativdensesindexDiliuarsdensesindexD inuliuarsdensesindexDe oede_endisuchfiral  nativdenses This reEr:NE>(dst)
    }

 T th nativindexDiliuarsindexDe oede_p  DFAn IDermatn thtches th do:NE>(dst)3  eeondexD ral be l s t   ne`  unup  DFAn_ial(ndiaeciToexm`:NE>(d publ_  Dric `to_bytesperf-inltru",
inltru(nhwrit)atiany ursp  DFAn_id( Box<,endiaeciToex:/    #,s/// i_ipoex:
    #  ///P  DFAnID = "dfa-buil unup  DFAn_id_ rm m(ndiaeciToexm[/// i_ipoex]    ) -> Result<Re* [`sDite_   /// let_n DFAns  ntn thtches  nativth do:NE>(dst)
    }

 T th nativdensesindexDiliuarsdensesindexD inuliuarsdensesindexDe oede_endisuchfiral  nativdenses This reEr:NE>(d publ_  Dric `to_bytesperf-inltru",
inltru(nhwrit)atiany ursp  DFAn_ial. Box<,endiaeciToex:/    #  ///    # = "dfa-buil unusrm ms()[ diaeciToex
*
2i+i1].       #()yn st -> Result<Re* [`seaed o oede_p  DFAn IDslrmatn thtches /aativdensesindex:NE>(dst)
    }

 T th nativdensesindexDiliuarsdensesindexD inuliuarsdensesindexDe oede_endisuchfiral  nativdenses This reEr:NE>(d publ_  Dric `to_bytesperf-inltru",
inltru(nhwrit)atiany ursp  DFAn_id_ rm m( Box<,endiaeciToex:/    #  ///&[P  DFAnID] = "dfa-builetcBeirt e
B unusrm ms()[ diaeciToex
*
2].       #()/
big   #[letc>`  e
B unup  DFAn_ial(ndiaeciToexm; Ok::<(), Box<up  DFAn_ids.w[Puncht.tt`rtv+Dl` ]_endiytes_nativeRe* [`sDite_p  DFAn IDelefeesedrm m
letuinDelizasrm m
letP  DFAnID:NE>(d publ_  Dric `to_bytesperf-inltru",
inltru(nhwrit)atiany ursdrm ms(&Box<  ///&[P  DFAnID] = "dfa-buiwire::u32s_so_p  DFAn_ids.B unusrm ms as_ref(.     ) -> Result<Re* [`sDite_tota3    /// let nativdense aiany  publ_  Dric `to_bytesperf-inltru",
inltru(nhwrit)atiany ursial. Box<  ///    # = "dfa-bui => df_eq!(0, l unusrm ms() ial.w
% 2); "dfa-buil unusrm ms() ial.w
/ 2_endiytes_nativeRe* [`sDite_p  DFAn IDedrm m
letuinDelizasrm m
letP  DFAnID:NE>(d publ_  Dric `to_bytesperf-inltru",
inltru(nhwrit)atiany ursp  DFAn_ids.&Box<  ///&[P  DFAnID] = "dfa-buiwire::u32s_so_p  DFAn_ids.B unup  DFAn_ids as_ref(.
    ) -> Result<Re* [`Dite_me n yeu age,eiTt: [us,tlettemsem nativpair ._endifns/e n y_u age. Box<  ///    # = "dfa-bui(l unusrm ms() ial.w
+D  unup  DFAn_ids.wuial.ww
*
P  DFAnID::SIZE   #[ -e()
  lAe  mmons E: Vecflagslrmat// thdenses
   spars reEr .l s //primarily
}

  rusra   #so //bPar a   ldty pse  natlettemsemflagsl  /e bot()t. #[der ve(Clgen,sCopy,s  bugati, ued for)tse
    Flagsl{
    }

 Whn
    ent lengc[ne nativuarsemp:w,Pu  ig. Wintnteespto_false, aed correspota/ is tre* [`nn/lizy espeErD
r's
    ///
    /ndiannon-zeroe>` in tiany p ued for)th   emp:w:t//ol,
    }

 Whn
    ent leng es theVfromproduceota/ is twsethdpanK
    /n ve_endiae provideria DFA'sUTF-8.l s //alsor   luds Romitt ign  yozero-widn  ma/ is tt///
cfg(lizetplittn thUTF-8nencodwe ign/e codeurposaiany p ued for)tis_utf8:t//ol,
    }

 Whn
    ent leng/ Rehwriteato _df
 matnot,hrsgardl s tgn/`Ipect`e provide  /figurldty .    /// Return eill avoidf oma r an semsc[neehes whese provideinecudf omunato _df
e a ///e .iany p ued for)tis_ehwrit_seirt ato _df
:///ol,
e()ian( Flagsl{
    }

 Cr `tmlizasE: Vecflagslrmata_re:mgnortan NEr:NE>(dst)
    }

 / }
    //c rse
   matwas d/ficign
ttn thrime Vect maiegsb g
    aed correspoe overvflagsl rtrdir ved dithodly_fn su al NEr: d Dn  //c  nges  ntn t_endisuchfuto_bhe///mighl be mma mteoughlrn eab/ct h   ite_`Flags`vtes_n(ts
cfg(rgetit()
 Abials.lized public `to_bytes` serializatiany ursgnor_nfa(nr by teompson::NEr  ///Flagsl{
        Flagsl{
            h   emp:w:tnr .h   emp:w( d
cfg(an(
ytesis_utf8:tnatuis_utf8( d
cfg(an(
ytesis_ehwrit_seirt ato _df
:/natuis_ehwrit_seirt ato _df
( d
cfg(an(
} "dfaytes_native  [ur a   #sovervflagslfn su al tches drm m. Oi tucg s ,ats //also correspo<&* [`seite_   /// let: [usoreadDfn su al drm m.iany p ued for)tursfn s_: [us(
    an(
drm m: urn8]())
    /// ```
  (Flags,
    #[,s  [ur a   #eature = "dfa-builetc(bot(denread) e
wire::try_r/ad_nin(srm m,e"flag bot()t" i/
    an(
tch,flagsl= Flagsl{
            h   emp:w:tbot( & (1 << 0w !e
0d
cfg(an(
ytesis_utf8:tbot( & (1 << 1w !e
0d
cfg(an(
ytesis_ehwrit_seirt ato _df
://ot( & (1 << 2w !e
0d
cfg(an(
}; "dfa-bui  /(flags,
nread)
    ) -> Result<W matlitemsemflagsl, ta litches : [usdrm m. d Dn thbuffnd esznoo* &[u3,
cfg(rget
  _Dhve hand to_re* [`nn:HTotoial numc/nowebigDn thbuffnd mral be,
cfg(rget    `t mat_to_ial`.lizedp ued for)turst mat_to<E: ETopan>( Ok::<(), Box<dyn std::edstby  ensrn8]())
    /// ```
      #, Sur a   #eature = "dfa-buiurs//ol_to_pos(b:///ol  /// inD    #[cfg(an(
he
b
    #[cfg(an(
ytes1
big   #[cfg(}ielse
    #[cfg(an(




0
big   #[cfg(}
cfg(an(
}` "dfa-builetcnt mat = l unut mat_to_ialbuf` is big he
dst ial.w
<cnt mat     #[cfg(an(
/ * [`Deat(Sur a   #eatur::buffnd_too_ &[u3("flag bot()t"  n to_bytes}_endian(
tch,/ot( =c(b/ol_to_pos(l unuh   emp:w) << 0w   #[cfg(an(
|c(b/ol_to_pos(l unuis_utf8) << 1w   #[cfg(an(
|c(b/ol_to_pos(l unuis_ehwrit_seirt ato _df
) << 2w;
    an(
E::t mat_ 32bbot(dedst /
big   #[  /nt mat     ) -> Result<Re* [`sDite_   /// let: [uso //bPar a   #//formtlettemsemflags> Result<wsed    .lizedp ued for)turst mat_to_ial. Box<  ///    # = "dfa-buil  #_of:: u32>(    #[ -e()
  lAvertould &timpleved tt`se D Tha_re:ai
  
}

    ///tould &tyieldvza tutl trmatmativdensea3T thfiral e(&self,e over
}

 tutl tn ve_endiaes, tatdense'///drusefier,/
    //bPa)
  
e(&self
`$`.n ve_endiaes, tuarsdensesit()
 A(  mpritupie oot( nds
    //s). 
  
}

 `'a`   ve_endian` u, tuarsliferime Vecorigi/alsre:, `T`.n ve_endiaes, 
rget
  _/ypeDe overvnds
    /// to tDt ()
 .N, ued for)tse
    S i thtou<'a, T>i{w("fott: &'a Tds
    //Tto ttT>,
cfg(it: /tou::E   oulde<srm m:iChunks<'a, hen thi >,ge()ian(<'a, Tsentations, su>yItould &trmatS i thtou<'a, T>i{w("fotypeDItoml= S i t<'a>f` "dfaursn=xt(  ensBox<  ///Opdty  S i t<'a>> = "dfa-buil unuit.n=xt().map(|(rToex, _)|     #[cfg(an(
tch,i
 ec  unutt.so_ndiaecid(iToexm; Ok::<(),-bui/ unurtu tiae iom to_b  #[}    #[ -e()
  lAverm ento tDas'a [u32]dty pgn/e dddg tDre:mth do:N
  
}

 `'a`   ve_endian` su, tuarsliferime VecareEr'sznds
    /// to t.N, ued for)tse
    S i t<'a>
{
cfg(id:tSun thi,
ytesst   /2:/    #,g("fonds
    //s: &'a rSun thi],ge()ian(<'a> S i t<'a>
{
cfg(ult<Re* [`Davertould &timpleved nds
    //ss Thislizmtrseal seszyieldv any lize _   /// letnds
    //ssequiteself,, tuarsalphabetc>` in  e oede_endisuch  ve_endian` ueEr:NE>(dst)
    }

 Eativnds
    ///is <&'a [u32ed/liza tutl a3T thfiral e(&self,ts
cfg(rget alhipect : [usrmatn 
ttnds
    ///
    //bPa)
  
e(&self,iliuar
cfg(rget ds
    //ss  ()
 .NE>(dp ued for)turs ds
    //s( Box<  ///SunteTds
    //htou<'_ V= "dfaytesS iteTds
    //htou     #[cfg(an(
tcl:
  unu ds
    //s ial.wd
cfg(an(
ytesit:
  unu ds
    //s rtou().e   oulde( d
cfg(an(
} "dfaytes_nativeRe* [`Davertould &timplev spars ras'a [u32]dty pgn/vervnds
    //ss T
cfg(rget
 espmtrsealOfromthn-deadDids
    //ssa_byre* [`nn:NE>(dst)
    }

 T th"spars " as'a [u32]dty piThislizcas tn ve_endiaes, tatdaquen m
le
cfg(rget ditl sal strfiral Kwove(&selfspgn/vervnditl tn mpritu.an
 Tcl   vr
cfg(rget: [usr nge/w }lo  //blaal e(&self,n ve_endiaes, tuarsnds
    /// tkese providermataed : [uso This rr nge.e provid
    }

    //espmomewt  //or's  rdenseda ra`Dite_claasicalhdpars  correspo<&'a [u32]dty p(w ed {yourndianhve (&self,rmatm/// Fthn-dead
cfg(rget ds
    //),abutgito_dso pc   c/eor ig if/
t: [usi D Tha_r nge/is  // _endisuch heap/
   udddg_r ngees,eiaes, tc rserianquises
,/ot//or'sdpa m.iany p ued for)tursdpars _ ds
    //s( Box<  ///SunteSpars Tds
    //htou<'_ V= "dfaytesS iteSpars Tds
    //htou {hdense:
  unu ds
    //s(), cur:sNone
} "dfaytes_nativeRe* [`sDite_/drusefiersrmatn espmtrseaiany p ued for)tursid( Box<  ///SunteID = "dfa-buil unuA'_endiytes_nativeA/aly #soveespmtrses, tnial numc/whn
    ot/c[nebeyacc (& ford. d Dso,
cfg(rgetit/re* [`seaveacc (& fomatn 
tt  r// Tsl  /leaal one
: [u.lized public `to_bytes` serializatiany ursacc (& for( Box<,eclaass : &B [uClaass   ///Opdty  Acc ( V= "dfayteslenWe jral tryato
addt: [uso oged! acc (& foma. Odingaddipleiails corr-built<(b g
    we'veaadd
    o m  yo: [us),arintetche up. "dfa-buitch,mutgacc (yteAcc (:: = S)n to_bytesrmat(claas,eid)    l unusds
    //s()D    #[cfg(an(
he
i

e=el unuA'.w
    #[cfg(an(
ytes  r/inue/
big   #[cfg(}
cfg(an(
an(
rmatuni /iTiclaass .e(&selfs(claas)
{
cfg(cfg(an(
yteshatletcturn : [u) e
uni .    8(w
{
big   #[cfg(an(
yteshat!acc (.addy: [u) {
big   #[cfg(an(
  #[cfg(/ * [`DNone;   #[cfg(  #[cfg(an(
}
big   #[cfg(an(
}
big   #[cfg(}
cfg(an(
}` is big if/
cc (.i  emp:w(      #[cfg(an(
None   #[cfg(}ielse
    #[cfg(an(
turn 
cc ()
cfg(an(
} "dfayte()ian(<'a> fmt::  bugtrmatS i t<'a>
{
cfg(ursfmt( Box<,efby  ensfmt::Fe  natou<'_   ///fmt:: ```
  = "dfa-buiumat(i, (Beirt, eia,eadd))    l unudpars _ ds
    //s().e   oulde(      #[cfg(an(
tch,i
 ecif/f.al2ernhde(      #[cfg(an(
  #[sA'.       #()yn st  #[cfg(}ielse
    #[cfg(an(




sid.       #() >>
B unu t   /2
an(
ytescfg(}; "dfa-bui"dfahe
i > 0
    #[cfg(an(




t mat!(<,e",e")?;
cfg(an(
ytes}
cfg(an(
an(
iettt`rtve=eeia     #[cfg(an(




t mat!(<,e"{:?}
=>
{:?}",
s irt,eid)?;
cfg(an(
ytes}ielse
    #[cfg(an(




t mat!(<,e"{:?}-{:?}
=>
{:?}",
s irt,eeia,eid)?;
cfg(an(
ytes}
cfg(an(
}` is big   /()n to_byte()
  lAvertould &timpleved nds
    //ss The dddg tDre:mth do:l seszyieldv lize _   /// letnds
    //ssequiteself,, tuarsalphabetc>` in  e oede_such  ve_endian` ueEr:N
  
}

 Eativnds
    ///is <&'a [u32ed/liza tutl a3T thfiral e(&self,tst alhipect
rget: [usrmatn 
ttnds
    ///
    //bPa)
  
e(&self,iliuarvnds
    ///i ()
 .N#[der ve(  bugati, ued for)tse
    SunteTds
    //htou<'a>
{
cfg(ial:/    #,g("foit: /tou::E   oulde<srm m:ihtou<'a, hen thi >,ge()ian(<'a>yItould &trmatS i tTds
    //htou<'a>
{
cfg(typeDItoml= (alphabet::Uni , hen thi)f` "dfaursn=xt(  ensBox<  ///Opdty  (alphabet::Uni , hen thi)> = "dfa-buil unuit.n=xt().map(|(r,l&i
)|     #[cfg(an(
tch,uni /e
he
i + 1
e=el unuial
{
big   #[cfg(an(
alphabet::Uni ::eoi(i)yn st  #[cfg(}ielse
    #[cfg(an(




tch,/ e
u8::try_gnor(i)
big   #[cfg(an(
ytesuexpect("rawt: [usalphabetciset an eexc/
  d")/
big   #[an(
ytes lphabet::Uni :: 8(b)
an(
ytescfg(}; "dfa-bui"dfa(uni , iom to_b  #[}    #[ -e()
  lAvertould &timpleved thn-DEAD nds
    //ss The dddg tDre:mth do udddg_a_lizedpars ras'a [u32]dty :N
  
}

 Eativnds
    ///is <&'a [u32ed/liza tditl al strfiral Kwove(&selfspgn/ver
rget ditl tn mpritu.an
 Tcl   vrt: [usr nge/w }lo  //blaal e(&self,n ve_endiae
videriauarsnds
    /// tkesermataed : [uso This rr nge.e
  
}

 As/e convenien m,ats //alwriteas* [`se` lphabet::Uni `vtes_nspgn/vervduse
viderype.e a  /is,
you'ed t an egch,a y: [u, EOI) mata_(EOI, : [u)alOfromy: [u,
rget: [u)/
   (EOI, EOI) tes_nspa_byyieldnn:N#[der ve(  bugati, ued for)tse
    SunteSpars Tds
    //htou<'a>
{
cfg(dense:
S i tTds
    //htou<'a>,g("focur:sOpdty  (alphabet::Uni , alphabet::Uni , hen thi)>,ge()ian(<'a>yItould &trmatS i tSpars Tds
    //htou<'a>
{
cfg(typeDItoml= (alphabet::Uni , alphabet::Uni , hen thi)f` "dfaursn=xt(  ensBox<  ///Opdty  (alphabet::Uni , alphabet::Uni , hen thi)> = "dfa-buiw }lo letcturn (uni , n=xt)) ec  unudense.n=xt()     #[cfg(an(
tch,('a v_s irt,e'a v_eia,e'a v_n=xt) e
 nativd unu urD    #[cfg(an(




turn ts
=>
t,   #[cfg(an(
ytesNone
=>
{
big   #[cfg(an(
  #[d unu urD=cturn (uni , uni , n=xt));   #[cfg(  #[cfg(an(
  r/inue/
big   #[cfg(an(
}
big   #[cfg(}; "dfa-bui"dfahe
'a v_n=xt
e=en=xt
&& !uni .i  eoi(      #[cfg(an(
  #[s unu urD=cturn ('a v_s irt,euni , 'a v_n=xt));
cfg(an(
ytes}ielse
    #[cfg(an(




d unu urD=cturn (uni , uni , n=xt));   #[cfg(  #[cfg(he
'a v_n=xt
!= DEAD {
big   #[cfg(an(
ytes/ * [`Dturn ('a v_s irt,e'a v_eia,e'a v_n=xt) /
big   #[cfg(an(
}
big   #[cfg(}
cfg(an(
}` is big hatletcturn (Beirt, eia,en=xt)) ec  unu ur. tke()D    #[cfg(an(
he
n=xt
!= DEAD {
big   #[cfg(an(
/ * [`Dturn (Beirt, eia,en=xt));
cfg(an(
ytes}
cfg(an(
}` is big None   #[ -e()
  lAve hand n 
ttmc urdf
edurn` u,t's  rse
   -ow VecareErai
  
}

    // hand dconfigurprov  /em  yointroPate -ow capabil    sal st_bya t
}

 /// Th. ThVfromKwovts ` suyourc[nedotwsethi :i
  
}

 * Ob// Tia hum  oreadto tDmes age_viaoot( `std::fmt:: isplay` ian(.
}

 * Acg s nbtounderlyn` u[`nr b:teompson::cfg(featur`](teompson::cfg(featur)
viderypeDfn suot( `source`Dmeteod_viaoite_`std::eatur::eatur`sndsit.    // hand
}

 Vfromoc urs<whes udddg_convenien m roudf s trmatrialif oma re:mdithodly
}

 gnortakp  DFAn su  ig.i
  
}

 Winteent `std` c `to_byto_en of d,ats //ian(&selfspite_`std::eatur::eatur`
rget dsit.) public `to_bytes` serializati#[der ve(Clgen,s  bugati, utse
    cfg(featur {
big d co: cfg(featurKind,we()
  l se d co Vec hand n 
ttmc urdf
edurn` u,t's  rse
   -ow VecareErai
  
}

 Not  teat(n  // hand isethn-exhaust ve. Addiple = (varialfspis tha vide  /s derign
tbreakddg_ch nge.e public `to_bytes` serializati#[der ve(Clgen,s  bugatie    cfg(featurKind
{
cfg(ult<Ave hand n 
ttmc urdf
ew }lo   rse
   -ignbtoNErD
s/e 'a  urs d step
cfg(rget:efor'sa leng/ Rcomtif d. "dfaNEr(teompson::cfg(featur),
cfg(ult<Ave hand n 
ttmc urdf
eb g
    atoun uppor cn(regex c `to_bywas etup:NE>(dst)3  eemes age_su  igndescribms w }

 un uppor cn(c `to_bywas etup:NE>(dst)NE>(dst)3  eeprimary(regex c `to_byta  /is un uppor cn(liz res
iliuarvUnicode> Result<worl.//undary(look-aretyp
 => dfty p(`\b`)
    //c[nebeyworval.aretyp
cfg(rget: 
ei
    udddg_an ASCII<worl.//undary((`(?-u:\b)`) mat: 
en of ig
cfg(rgetUnicode<worl.//undaries<whes rialif oma re::NE>(dUn uppor cn(&'th dic_su ),
cfg(ult<Ave hand n 
ttmc ursling  o m  yodense D
r'sproduce
ew }lo rialif oma_endilizere::NE>(dTooM  ySun ts,
cfg(ult<Ave hand n 
ttmc ursling  o m  yoden
 ntt`se Delent/
  dew }lo rialif o any lize _eEr:NE>(dst)
    }

 T  /// Re d co Vecoddbaed  hand n 
ttmc urslwhes rialif oma re:twset_endilizeth 
 ntt`se Den of d/se omativp  DFAn 
   eiough/_n DFAns  o
s us  correspoite_ to tDlettt`rtv transo ogean fl   `    #`:NE>(dTooM  ySunrthen ts,
    }

 T  /// Retha    oddbaed  hand n 
ttc[neVc urDing alrueelen  o m  y to_bworkp  DFAnsedpreadDoutgacroPsg  o m  yo nativdense aiany TooM  yM// iP  DFAnIDs,
cfg(ult<Ave hand n 
ttmc ursling nt lenggotg  o bigDdurn` unial num  ldty aiany lenExc/
  dS  #Limit/{e>imit:/    # },
cfg(ult<Ave hand n 
ttmc urslingauxil ary(stmaage_(igur nt len)Retupidurn` 
cfg(ult<nial num  ldty ggotg  o bigaiany lial num  eExc/
  dS  #Limit/{e>imit:/    # },
e() public `to_bytes` serializatiian( cfg(featur {
big ult<Re* [`Dite_d co Vecn  // hand._endifnsd co.&Box<  ///&cfg(featurKind
{
cfg(<(), Box<ud co_endiytes_nap ued for)tursnfa( ha: teompson::cfg(featur) ///Bfg(featur {
big     Bfg(featur { d co: cfg(featurKind::NEr( ha)
} "dfaytes_nap ued for)tursun uppor cn ` s_worl_//undary_unicode() ///Bfg(featur {
big     tch,msgytesc[nthatrialdz res
se oregexestwsethUnicode<worl.\
big   #[cfg(an(
yte//undaries; swsetivno ASCII<worl.//undarius,tlr.\
big   #[cfg(an(
yteheurnst ch. Thsn of  Unicode<worl.//undaries<matu   a \
big   #[cfg(an(
ytediffndelf,regex engtru";
big     Bfg(featur { d co: cfg(featurKind::Un uppor cn(msg)
} "dfaytes_nap ued for)turstoo_manw_dense () ///Bfg(featur {
big     Bfg(featur { d co: cfg(featurKind::TooM  ySun ts
} "dfaytes_nap ued for)turstoo_manw_denrt_dense () ///Bfg(featur {
big     Bfg(featur { d co: cfg(featurKind::TooM  ySunrthen ts
} "dfaytes_nap ued for)turstoo_manw_ // i_p  DFAn_ids.w ///Bfg(featur {
big     Bfg(featur { d co: cfg(featurKind::TooM  yM// iP  DFAnIDs
} "dfaytes_nap ued for)turs` s_exc/
  d_l  #_>imit(>imit:/    #w ///Bfg(featur {
big     Bfg(featur { d co: cfg(featurKind::lenExc/
  dS  #Limit/{e>imits}i} "dfaytes_nap ued for)turs`ial num  e_exc/
  d_l  #_>imit(>imit:/    #w ///Bfg(featur {
big     Bfg(featur {
big   #[cfg(d co: cfg(featurKind::lial num  eExc/
  dS  #Limit/{e>imit },
cfg(an(
} "dfayte() publi[u3(c `to_bytesstd", c `to_bytes` serializaatiian( std::eatur::eatur
se oBfg(featur {
big ursdource.&Box<  ///Opdty  &(dyn std::eatur::eatur
+ 'th dic)> = "dfa-bui nativd unud co.)D    #[cfg(an(
cfg(featurKind::NEr(reec has
=>
turn  has,   #[cfg(an(
_
=>
None,
cfg(an(
} "dfayte() public `to_bytes` serializatiian( c re::fmt:: isplay
se oBfg(featur {
big ursfmt( Box<,efby  ensc re::fmt::Fe  natou<'_   ///c re::fmt:: ```
  = "dfa-bui nativd unud co.)D    #[cfg(an(
cfg(featurKind::NEr(_s
=>
t mat!(<,e" hand rialif omNEr"s,   #[cfg(an(
cfg(featurKind::Un uppor cn(reecmsg)
=>
{
big   #[cfg(an(
t mat!(<,e"un uppor cn(regex c `to_byse o res: {}",
msg)
cfg(an(
ytes}
cfg(an(
an(
cfg(featurKind::TooM  ySun ts
=>
t mat!(
big   #[cfg(an(
f,   #[cfg(an(
ytes"   /// letre:mth doseexc/
 se>imit let{}",   #[cfg(an(




tun thi::LIMIT,   #[cfg(an(
u,
cfg(an(
an(
cfg(featurKind::TooM  ySunrthen ts
=>
{
cfg(cfg(an(
yteslctk t   /ee
Sunch::ialbuf` is big  is big ide  e_den
 n to tDha( `st   /`lu32ries<forsden
  ignmtrans<for` is big  is big ideuarsentiresre:, 
    //n `st   /`lu32ries<forsmativp  DFAn
 is big  is big ideifhden
 ntt`se Drmatmativp  DFAneelenen of d/(  }

    imm
endian(
ytesbig ideVfromwri(n  // hand c[neVc ur)
   us,Dite_tota3    /// le
endian(
ytesbig ide_n DFAns     /c[nefi /iTiite_ to tDi( `st   /`ll s t   n
endian(
ytesbig idew   /we/c[ned locrseaiany   #[cfg(an(
tch,maxl=c    #::try_gnor(c re::i   #::MAXm   // `bu; "dfaytesbig   #[letc>imit = (maxl-  t   / e/  t   /;
cfg(an(
ytesan(
t mat!(
big   #[cfg(an(
ytesf,   #[cfg(an(
ytesssss"comtifn` ueErtwsethden
 ntt`se Dexc/
 sep  DFAne\
big   #[cfg(an(
  #[cp  DFAn >imit let{}",   #[cfg(an(




  #[limit,   #[cfg(an(
ssss)
cfg(an(
ytes}
cfg(an(
an(
cfg(featurKind::TooM  yM// iP  DFAnIDs
=>
t mat!(
big   #[cfg(an(
f,   #[cfg(an(
ytes"comtifn` ueErtwsethtota3 _n DFAns  ntakle nativdense D\
big   #[cfg(an(
 exc/
 se>imit let{}",   #[cfg(an(




P  DFAnID::LIMIT,   #[cfg(an(
u,
cfg(an(
an(
cfg(featurKind::lenExc/
  dS  #Limit/{e>imits}i=>
t mat!(
big   #[cfg(an(
f,   #[cfg(an(
ytes"eErtexc/
  dil  #e>imit let{:?}
durn` unial num  ldty ",   #[cfg(an(




limit,   #[cfg(an(
u,
cfg(an(
an(
cfg(featurKind::lial num  eExc/
  dS  #Limit/{e>imit }
=>
{
big   #[cfg(an(
t mat!(<,e"nial num  ldty gexc/
  dil  #e>imit let{:?}",
>imit)
cfg(an(
ytes}
cfg(an(
}` is yte() publi[u3(se t, c `to_bytessyntax", c `to_bytes` serializaatimo   e asz= "dfaus tn for::{Ipect,sM// ieatur}f` "dfaus t upou::*f` "dfa#[ e atiany urs hands_wset_unicode_worl_//undary.)D    #[cfg(tch,p  DFAnyter"\b"; "dfaytes => df!(cfg(fou:: = S).riali(p  DFAn).i  errbuu/
big }` "dfa#[ e atiany ursretyp dit_t an _ // i.)D    #[cfg(tch,` syteeEr:: =an _ // i.)   // `buf` is big tch,(buf, _) ecnatuto_: [us_nat ve_eiaianbuf` is big tch,or by ret&rning VteeEr::fn s_: [us(&buf)   // `bu.0f` "dfa-bui => df_eq!(None,cnatutry_ a ///_fwd(&Ipect:: = S"foo12345"w)   // `bum;
cfg(}` "dfa#[ e atiany ursretyp dit_ehwrit_ // i.)D    #[cfg(us tn for::HalfM// if` "dfa-buitch,` syteeEr::ehwrit_ // i.)   // `buf` is big tch,(buf, _) ecnatuto_: [us_nat ve_eiaianbuf` is big tch,or by ret&rning VteeEr::fn s_: [us(&buf)   // `bu.0f` "dfa-bui => df_eq!(   #[cfg(an(
turn HalfM// i:: `st(0, 0)u,
cfg(an(
an(
natutry_ a ///_fwd(&Ipect:: = S"foo12345"w)   // `bu
cfg(an(
)f`endiytes_nati Seeeent atalogoust e a    lrc/hyb   /natur aiany  p e atiany ursheurnst c_unicode_r an se.)D    #[cfg(tch,` syteeEr::bfg(fou()yn st  #[cfg(.  /figure(eEr::  /fig.)   icode_worl_//undary.truew)
big   #[cfg(.teompson(teompson::C /fig:: = S).r an se.truew)
big   #[cfg(.riali(r"\b[0-9]+\b")
big   #[cfg(.  // `buf`` is big tch,ipect = Ipect:: = S"β123").r nge(2..uf` is big tch,expectf
 e
M// ieatur::quis(0xB2, 1uf` is big tch,gotg=
natutry_ a ///_r a(&ipectu; "dfaytes => df_eq!(eat(expectf
),,gotuf`` is big tch,ipect = Ipect:: = S"123β").r nge(..3uf` is big tch,expectf
 e
M// ieatur::quis(0xCE, 3uf` is big tch,gotg=
natutry_ a ///_r a(&ipectu; "dfaytes => df_eq!(eat(expectf
),,gotuf` is yte(                                                                                        