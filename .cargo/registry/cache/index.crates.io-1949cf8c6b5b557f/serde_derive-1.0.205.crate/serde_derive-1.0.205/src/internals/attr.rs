use crate::internals::symbol::*;
use crate::internals::{ungroup, Ctxt};
use proc_macro2::{Spacing, Span, TokenStream, TokenTree};
use quote::ToTokens;
use std::borrow::Cow;
use std::collections::BTreeSet;
use std::iter::FromIterator;
use syn::meta::ParseNestedMeta;
use syn::parse::ParseStream;
use syn::punctuated::Punctuated;
use syn::{parse_quote, token, Ident, Lifetime, Token};

// This module handles parsing of `#[serde(...)]` attributes. The entrypoints
// are `attr::Container::from_ast`, `attr::Variant::from_ast`, and
// `attr::Field::from_ast`. Each returns an instance of the corresponding
// struct. Note that none of them return a Result. Unrecognized, malformed, or
// duplicated attributes result in a span_err but otherwise are ignored. The
// user will see errors simultaneously for all bad attributes in the crate
// rather than just the first.

pub use crate::internals::case::RenameRule;

struct Attr<'c, T> {
    cx: &'c Ctxt,
    name: Symbol,
    tokens: TokenStream,
    value: Option<T>,
}

impl<'c, T> Attr<'c, T> {
    fn none(cx: &'c Ctxt, name: Symbol) -> Self {
        Attr {
            cx,
            name,
            tokens: TokenStream::new(),
            value: None,
        }
    }

    fn set<A: ToTokens>(&mut self, obj: A, value: T) {
        let tokens = obj.into_token_stream();

        if self.value.is_some() {
            let msg = format!("duplicate serde attribute `{}`", self.name);
            self.cx.error_spanned_by(tokens, msg);
        } else {
            self.tokens = tokens;
            self.value = Some(value);
        }
    }

    fn set_opt<A: ToTokens>(&mut self, obj: A, value: Option<T>) {
        if let Some(value) = value {
            self.set(obj, value);
        }
    }

    fn set_if_none(&mut self, value: T) {
        if self.value.is_none() {
            self.value = Some(value);
        }
    }

    fn get(self) -> Option<T> {
        self.value
    }

    fn get_with_tokens(self) -> Option<(TokenStream, T)> {
        match self.value {
            Some(v) => Some((self.tokens, v)),
            None => None,
        }
    }
}

struct BoolAttr<'c>(Attr<'c, ()>);

impl<'c> BoolAttr<'c> {
    fn none(cx: &'c Ctxt, name: Symbol) -> Self {
        BoolAttr(Attr::none(cx, name))
    }

    fn set_true<A: ToTokens>(&mut self, obj: A) {
        self.0.set(obj, ());
    }

    fn get(&self) -> bool {
        self.0.value.is_some()
    }
}

struct VecAttr<'c, T> {
    cx: &'c Ctxt,
    name: Symbol,
    first_dup_tokens: TokenStream,
    values: Vec<T>,
}

impl<'c, T> VecAttr<'c, T> {
    fn none(cx: &'c Ctxt, name: Symbol) -> Self {
        VecAttr {
            cx,
            name,
            first_dup_tokens: TokenStream::new(),
            values: Vec::new(),
        }
    }

    fn insert<A: ToTokens>(&mut self, obj: A, value: T) {
        if self.values.len() == 1 {
            self.first_dup_tokens = obj.into_token_stream();
        }
        self.values.push(value);
    }

    fn at_most_one(mut self) -> Option<T> {
        if self.values.len() > 1 {
            let dup_token = self.first_dup_tokens;
            let msg = format!("duplicate serde attribute `{}`", self.name);
            self.cx.error_spanned_by(dup_token, msg);
            None
        } else {
            self.values.pop()
        }
    }

    fn get(self) -> Vec<T> {
        self.values
    }
}

pub struct Name {
    serialize: String,
    serialize_renamed: bool,
    deserialize: String,
    deserialize_renamed: bool,
    deserialize_aliases: BTreeSet<String>,
}

fn unraw(ident: &Ident) -> String {
    ident.to_string().trim_start_matches("r#").to_owned()
}

impl Name {
    fn from_attrs(
        source_name: String,
        ser_name: Attr<String>,
        de_name: Attr<String>,
        de_aliases: Option<VecAttr<String>>,
    ) -> Name {
        let mut alias_set = BTreeSet::new();
        if let Some(de_aliases) = de_aliases {
            for alias_name in de_aliases.get() {
                alias_set.insert(alias_name);
            }
        }

        let ser_name = ser_name.get();
        let ser_renamed = ser_name.is_some();
        let de_name = de_name.get();
        let de_renamed = de_name.is_some();
        Name {
            serialize: ser_name.unwrap_or_else(|| source_name.clone()),
            serialize_renamed: ser_renamed,
            dt() {
      , v)),
     ame {
    sbthan just titionarialize_rennt<'  }<Container<t<'aNock(block) => block,
esult. UnTypeGenerics<'a>(&'a Parameters);
#[cfg(feature = "deserialize_in_place")]
struct InPlaceTypeGenerics<'a>(&'a Parameters);

fn de_type_generics_t UnTze_in_pliiliases.get() {
     > Name {
        enamed: sed,
-> Option<Conoriginal.span()::Block(blos Vec::new(),
&ne() {
iginal.e_generics_t UnTze_in_pliiliases.get() {
     > Name {
        en#[cfg(feature-> Option<Cond.original.span()::Block(blos Vec::new(),
&ne() d.original.   serialize_reeGenerics<'a>(&'a P)::Block(blowned()
}

impl Nec::new(),
&ne() d.original.a>(&'a PtimeParam {
le,
    /// One unnamed fenamed:tion<TAll>,
}s          Dsult. UnTyption<T>,
}uct,
    /
esult. UnTyption<T>,
}ucme: Attrtion<TAll>,
}s        UnTze_in_s a     `tion<TAll>,
}s`}

    varindividuent:,
}s , anne()  ///      UnT`her tatten(` jo   d by `tion<T>,
}s::or -> Option<Con'a Pken_ster tatten(:,
   ew(),
            vaSant.fields.iter())        dt() () {
iginal.    ter tatten( {
iginal.)ock) => block,
esult. UnTypne() d.original.    ter tatten( d.original.s putting a comma after exR syn::Idssed for Serde.
 } else {
 in      t,
    /// Attributes on .fields BTreeNfn inserttran
  rm_att).trim_start) is stable:
    tt).trim_starti, fielld {
          k_has_flatten(:rtion<TAll>,
}s        k_has_fla  Data::Stru:rtion<TAll>,
}s      t<'aericsde_aliases) <erics(paraPredone
 s {
    aceericsde_aliases) <erics(paraPredone
 s {
    tag   ag Struct,
 )]
im    de_aliase.
    Str>uct,
 )]
imtrym    de_aliase.
    Str>uct,
 )]
imn<T>de_aliase.
    Str>uct,
 remeta:e_aliase.
   e! {
 name: Strii  Dr:are `ai  Dr name:    attrs,
tt).trim_sta       Some(path) =.
   e! {
 name: s  Scking().trim_star ex    asmessagee syn::Tod    en DeImca
   be,
esult. UnTd {
            lpath) =new();
      serds::next_keg().trimfter exeld, s , a: syn::Idfor Mle,
    pub de.
  ag Strstructure, pars_serde::ructure,      UnT```json      UnT{"iant>,
1":T{"key1":T"g,
  1   "key2":T"g,
  2"}}      UnT``` /// no,
    ,rics_t UnTnd
// `attagrs:  DeI
    ucture,      UnT```json      UnT{" DeI
:T"g,nt>,
1"  "key1":T"g,
  1   "key2":T"g,
  2"}      UnT``` /// Iub ident{ tag   source},rics_t UnTnd
// `attagrs:  ", genericrs: c
    ucture,      UnT```json      UnT{" 
:T"g,nt>,
1"  "c":T{"key1":T"g,
  1   "key2":T"g,
  2"}}      UnT``` /// Adjac      tag   sourc, generic   source},rics_t UnTnd
// `at
fn struct  ucture,      UnT```json      UnT{"key1":T"g,
  1   "key2":T"g,
  2"}      UnT``` /// t, namfter ex(pat,
    is de.
 r syn::Idsst>>),
    Struct(Style, Ve aroun}
    } Styler ex,
    uple,
    /// One unnamed field.re `ai  Drstructure, Itt has_fla a parso,rics_t UnTT is de.
 r syn::Idsst>>),
    Struct(Style. Allicated aun}
    }a>(
   ics_t UnTu<synstruct_froexcept  _serdey &'c which: station.
pub strics_t UnTnd
// `atter t    ///: sta     DeIm        ics_tlds.
  ics_t UnTT is de.
 r syn::Idsst>>)un}
    } Stylx,
    Allicated aun}
    }a>(
ics_t UnTream<synstruct_f ics_t::Field,
    Attrre `ai  Drstructu{
        attrs: Vec::new(),
        life Option<Con  serialSymbol,
    first_dup_tot| variant.fields.iter())re `ai  Drctin Ctxts {
,ields.iter())re `ai  Drctne()),|)re `ai  Drct        Ctx   s,tch self {
            Frbutes on .fieldsr ex xtrale, uSymbolnd
// `attr::Field::from_aue_ty: norigin> Option<Container<'aer_default= attr::tainer::from_astew(),
            vame in de;
        l    }

    fn gRENAME'a: 'place`
       er_name.un    }

    fn gRENAME'a: 'place`
       tran
  rm_aget(j, ());}

    fn gTRANSPARENT'a: 'place`
       er) is stable:
    get(j, ());}

    fn gDENY_UNKNOWN_FIELDS'a: 'place`
       erthis_typ());}

    fn gDEFAULT'a: 'place`
         k_has_flas tatten.un    }

    fn gRENAME_ALL'a: 'place`
         k_has_flaace"ten.un    }

    fn gRENAME_ALL'a: 'place`
         k_has_fla  Data:s tatten.un    }

    fn gRENAME_ALL_FIELDS'a: 'place`
         k_has_fla  Data:ace"ten.un    }

    fn gRENAME_ALL_FIELDS'a: 'place`
       t<'aerics.un    }

    fn gBOUND'a: 'place`
       er_erics.un    }

    fn gBOUND'a: 'place`
       
fn struget(j, ());}

    fn gUNTAGGED'a: 'place`
       am,
    _tagrs:());}

    fn gTAG'a: 'place`
       genericrs:());}

    fn gCONTENT'a: 'place`
       )]
im    rs:());}

    fn gFROM'a: 'place`
       )]
imtrym    rs:());}

    fn gTRY_FROM'a: 'place`
       )]
imtem: s:());}

    fn gINTO'a: 'place`
         meta.un    }

    fn gREMOTE'a: 'place`
       n wrapse `ai  Drset(j, ());}

    fn gFIELD_IDENTIFIER'a: 'place`
           match fiei  Drset(j, ());}

    fn gVARIANT_IDENTIFIER'a: 'place`
       e! {
      s:());}

    fn gCRATE'a: 'place`
                 s:());}

    fn gEXPECTING'a: 'place`
       serds::next_keiants {
  {
           ld::.erroriginast(cxs with the #[serd0230    att != SERDEt();
        let seserds::next_kei|=        }

        iftr<Stri!      .toke,, contaiken, Iefault::Nerd     s= NON_EXHAUSTIVE
        }

       geneinu::Enum(variants)  with the #[serdis_socontaiken,Li<'atokee);
     .toke   fields,
         f tokeAttr<'c   semptye_by_rules(attrs.rename_ageneinu::Enum(variants     let mut item =  with the #[serdis_s&Varerys = 0230   e enn, Lif_toke(|toke|   fields,
         f tokeA     s= RENAMEby_rules(attrs.rename_a exd
// `at  k_hars: foo"#[allow(non_upprename_a exd
// `at  k_ha(c::new(),rs: foo"rapper_ty, unrs: bar")#[allow(non_upprename_a
     fn ude> {
  te")]
sts fn gRENAME<dynokee?       }
            }) {
      self.s(&tokeA        r.ragmentembers),
    tS);}
t dup_      for field in fieleGeneric self.s(&tokeA      de.ragmentembers),
    tS);}
t dup_      for field in  }
}

p f tokeA     s= RENAME_ALLby_rules(attrs.rename_a exd
// `at  k_has_flrs: foo"#[allow(non_upprename_a exd
// `at  k_has_fl(c::new(),rs: foo"rapper_ty, unrs: bar")#[allow(non_upprename_a
      _name.untokeAsyn::Dpeequote!(![=]      for field in fiel
     fn ude> {
  te")]
sts fn gRENAME_ALL<dynokee?       }
            }s_set.insertstys = s.generics,
      bounds.push(place_tion<T>,
}. Unrec(St)::Brng,
  ()attrs.rename_by_rules(
         Okt  k_has"ten

imp  k_has_flas tatten T> {&tokeA        k_has"ten
,rs.rename_by_rules(
         &Varerys =>he end of the enum"); fn uerys,variant
                                .attrs
}      }
            }s_set.insertde> {
deenerics,
      bounds.push(place_tion<T>,
}. Unrec(St):de.g,
  ()attrs.rename_by_rules(
         Okt  k_has"ten

imp  k_has_flaace"ten T> {&tokeA        k_has"ten
,rs.rename_by_rules(
         &Varerys =>h{          }
                }
   s_s!   _name.{          }
                }
   t the end of the enum");de uerys;          }
                }
   }
     }
                }
   }
     }
                }               .attrs
}      }
          }
}

p f tokeA     s= RENAME_ALL_FIELDSby_rules(attrs.rename_a exd
// `at  k_has_fle:
    get foo"#[allow(non_upprename_a exd
// `at  k_has_fla Punctuc::new(),rs: foo"rapper_ty, unrs: bar")#[allow(non_upprename_a
      _name.untokeAsyn::Dpeequote!(![=]      for field in fiel
     fn ude> {
  te")]
sts fn gRENAME_ALL_FIELDS<dynokee?          }

        iftr<St ))),
            syn::Da     syn::Data::Struct(data)_s =>h{          }
                }s_set.insertstys = s.generics,
      bounds.push(ds.push(place_tion<T>,
}. Unrec(St)::Brng,
  ()attrs.rename_by_rules(
                 Okt  k_has"ten

imptrs.rename_by_rules(
                       k_has_fla  Data:s tatten T> {&tokeA        k_has"ten
;rs.rename_by_rules(
                 }rs.rename_by_rules(
                 &Varerys =>he end of the enum"); fn uerys,variant
                    }
   }
     }
                }
   }
     }
                }   }s_set.insertde> {
deenerics,
      bounds.push(ds.push(place_tion<T>,
}. Unrec(St):de.g,
  ()attrs.rename_by_rules(
                 Okt  k_has"ten

imptrs.rename_by_rules(
                       k_has_fla  Data:ace"ten T> {&tokeA        k_has"ten
;rs.rename_by_rules(
                 }rs.rename_by_rules(
                 &Varerys =>htrs.rename_by_rules(
                     s_s!   _name.{          }
                }
   t th
   t the end of the enum");de uerys;          }
                }
           }rs.rename_by_rules(
                 }          }
                }
   }
     }
                }
   }
     }
                }               .attrs
e, attrs.default());
 _s =>h{          }
                }en, msg);
"d
// `at  k_has_fla Punct)]kenStonut: eam),
}olx,
  s";          }
                }e ettr_nd ofatoke.nd ofatsg));
     }
                }               .attrs
e, attrs.defaul         return None;
                   }en, msg);
"d
// `at  k_has_fla Punct)]kenStonut: eam),
}olx,
  s";          }
                }e ettr_nd ofatoke.nd ofatsg));
     }
                }               .attrs
}      }
          }
}

p f tokeA     s= TRANSPARENTby_rules(attrs.rename_a exd
// `attran
  rm_a#[allow(non_upprename_atran
  rm_a.       s(tokeA          for field in  }
}

p f tokeA     s= DENY_UNKNOWN_FIELDSby_rules(attrs.rename_a exd
// `ater) is stable:
    #[allow(non_upprename_aer) is stable:
    .       s(tokeA          for field in  }
}

p f tokeA     s= DEFAULT      }
                  tokeAsyn::Dpeequote!(![=] turn None;
                 exd
// `aterthis_typ"..."#[allow(non_upprename_a   }s_set.insertnused_e'a syn_    n<T> ttr::   atfn gDEFAULT<dynokee?turn None;
                   }efault())),
            syn::Da         .attrs
e, attrs.default());
 ttrs.defat());
 {ast_tagg .. }  rett(cx, &fields.named, at syn::Da         .attrs
e, attrs.container_defa   |, attrs, container_def_s =>htrs.rename_by_rules(
                     _serde::T> {&tokeA          attr::Default::
;rs.rename_by_rules(
                 }rs.rename_by_rules(
                 &'a Punctuated<syn::Ftrs.rename_by_rules(
                     en, msg);
"d
// `aterthis_typ\"...\")]kenStonut: eam),
}olx(Styleock(Tokhav>),
    ";          }
                }
           e ettr_nd ofatoke.nd ofatsg));
     }
                }            }          }
                }
   },      syn::Da         .attrs
e, attrs.defauldata)_s =>h{          }
                }        en, msg);
"d
// `aterthis_typ\"...\")]kenStonut: eam),
}olx(Styleo";          }
                }
       e ettr_nd ofatoke.nd ofatsg));
     }
                }        }      syn::Da         .attrs
e, attrs.defaul         return None;
                   }        en, msg);
"d
// `aterthis_typ\"...\")]kenStonut: eam),
}olx(Styleo";          }
                }
       e ettr_nd ofatoke.nd ofatsg));
     }
                }        }      syn::Da         .attrs
}
     }
                }               .attrs
}}
}

pub struct Name             exd
// `aterthis_#[allow(non_upprename_a   }efault())),
            syn::Da         .attrs
ttrs.default());
 ttrs.defat());
 {ast_tagg .. }  rett(cx, &fields.named, at syn::Da         .attrs
ttrs.container_defa   |, attrs, container_def_s =>htrs.rename_by_rules(
                 _serde::T> {tokeA          attr:D        style,
                 }        }      syn::Da         .attrs
e, attrs.unctuated<syn::Ftrs.rename_by_rules(
                 en, msg);
"d
// `aterthis_)]kenStonut: eam),
}olx(Styleock(Tokhav>),
    ";          }
                }
       e end of the enum");st_tagg ec<T> {
        se           }        }      syn::Da         .attrs
},
 syn::Da         .attrs
e, attrs.defauldata)_s =>h{          }
                }    en, msg);
"d
// `aterthis_)]kenStonut: eam),
}olx(Styleo";          }
                }
   e ettr_nd ofatoke.nd ofatsg));
     }
                }    }
 syn::Da         .attrs
e, attrs.defaul         return None;
                   }    en, msg);
"d
// `aterthis_)]kenStonut: eam),
}olx(Styleo";          }
                }
   e ettr_nd ofatoke.nd ofatsg));
     }
                }    }
 syn::Da         .attrs
               .attrs
}      }
          }
}

p f tokeA     s= BOUNDby_rules(attrs.rename_a exd
// `aterics.un"T:inser     "#[allow(non_upprename_a exd
// `atericsuc::new(),rs: ..."rapper_ty, unrs: ..."##[allow(non_upprename_a
     fn ude> {
  te      predone
 sBox<dynokee?       }
            }) {
erics  self.s(&tokeA        r      for field in fieleGeerics  self.s(&tokeA      de      for field in  }
}

p f tokeA     s= UNTAGGEDby_rules(attrs.rename_a exd
// `at
fn struct        }

        iftr<St ))),
            syn::Da     syn::Data::Struct(data)_s =>h{          }
                }
fn stru.       s(&tokeA          for field in        }               .attrs
e, attrs.default());
 _s =>h{          }
                }en, msg);
"d
// `at
fn struct_enStonut: eam),
}olx,
  s";          }
                }e ettr_nd ofatoke.nd ofatsg));
     }
                }               .attrs
e, attrs.defaul         return None;
                   }en, msg);
"d
// `at
fn struct_enStonut: eam),
}olx,
  s";          }
                }e ettr_nd ofatoke.nd ofatsg));
     }
                }               .attrs
}      }
          }
}

p f tokeA     s= TAGby_rules(attrs.rename_a exd
// `attagrs:  DeI
        }
            }s_set.inserts> {
  te    (St)fn gTAG<dynokee?turn None;
                efault())),
            syn::Da         .attrs
ttrs.defauldata)_s =>h{          }
                }    am,
    _tag:T> {&tokeA      s.g,
  ()a;
     }
                }    }
 syn::Da         .attrs
e, attrs.default());
 ttrs.defat());
 {ast_tagg .. }  rett(cx, &fields.named, at syn::Da         .attrs
ttrs.container_defa   ::Ftrs.rename_by_rules(
                 am,
    _tag:T> {&tokeA      s.g,
  ()a;
     }
                }        }      syn::Da         .attrs
e, attrs.unctuated<n_defa   |, attrs, containsyn::Ftrs.rename_by_rules(
                 en, msg);
"d
// `attagrs:\"...\")]kenStonut: eam),
}olx,
  s ///:(Styleoc

   ntainer<'a> ";          }
                }
       e ettr_nd ofatoke.nd ofatsg));
     }
                }        }      syn::Da         .attrs
},
 syn::Da         .attrs
e, attrs.defaul         return None;
                   }    en, msg);
"d
// `attagrs:\"...\")]kenStonut: eam),
}olx,
  s ///:(Styleoc

   ntainer<'a> ";          }
                }
   e ettr_nd ofatoke.nd ofatsg));
     }
                }    }
 syn::Da         .attrs
               .attrs
}      }
          }
}

p f tokeA     s= CONTENTby_rules(attrs.rename_a exd
// `atgenericrs: c
        }
            }s_set.inserts> {
  te    (St)fn gCONTENT<dynokee?turn None;
                efault())),
            syn::Da         .attrs
ttrs.defauldata)_s =>h{          }
                }    generic:T> {&tokeA      s.g,
  ()a;
     }
                }    }
 syn::Da         .attrs
e, attrs.default());
    return None;
                   }    en, msg);
"d
// `atgenericrs:\"...\")]kenStonut: eam),
}olx,
  s";          }
                }
   e ettr_nd ofatoke.nd ofatsg));
     }
                }    }
 syn::Da         .attrs
e, attrs.defaul         return None;
                   }    en, msg);
"d
// `atgenericrs:\"...\")]kenStonut: eam),
}olx,
  s";          }
                }
   e ettr_nd ofatoke.nd ofatsg));
     }
                }    }
 syn::Da         .attrs
               .attrs
}      }
          }
}

p f tokeA     s= FROMby_rules(attrs.rename_a exd
// `at    rs:"TDeI
        }
            }s_set.insertUnrectyd_e'a syn_    n<T> ty fn gFROM<dynokee?turn None;
                )]
im      self.s(&tokeA      nsertUnrectyd      for field in fields {
              }
}

p f tokeA     s= TRY_FROMby_rules(attrs.rename_a exd
// `attrym    rs:"TDeI
        }
            }s_set.inserttrym    ctyd_e'a syn_    n<T> ty fn gTRY_FROM<dynokee?turn None;
                )]
imtrym      self.s(&tokeA      nserttrym    ctyd      for field in fields {
              }
}

p f tokeA     s= INTOby_rules(attrs.rename_a exd
// `attem: s:"TDeI
        }
            }s_set.insertn<T> tyd_e'a syn_    n<T> ty fn gINTO<dynokee?turn None;
                )]
imn<T>  self.s(&tokeA      nsertn<T> tyd      for field in fields {
              }
}

p f tokeA     s= REMOTEby_rules(attrs.rename_a exd
// `at  meta.un"..."#[allow(non_upprename_as_set.insertnused_e'a syn_    n<T>    atfn gREMOTE<dynokee?turn None;
                s_s s  rimit_ke    at&      "
   "attrs.rename_by_rules(
           meta:T> {&tokeA      riginal: item,
           ;
     }
                } }
}

pub struct Name                  meta:T> {&tokeA                for field in        }               .attrs
}      }
          }
}

p f tokeA     s= FIELD_IDENTIFIERby_rules(attrs.rename_a exd
// `at  wrapse `ai  Dr#[allow(non_upprename_a  wrapse `ai  Dr.       s(&tokeA          for field in  }
}

p f tokeA     s= VARIANT_IDENTIFIERby_rules(attrs.rename_a exd
// `at    match fiei  Dr#[allow(non_upprename_a    match fiei  Dr.       s(&tokeA          for field in  }
}

p f tokeA     s= CRATEby_rules(attrs.rename_a exd
// `atg::Toket foo"#[allow(non_upprename_as_set.insertnused_e'a syn_    n<T>    atfn gCRATE<dynokee?turn None;
                e! {
     :T> {&tokeA                for field in     }      }
          }
}

p f tokeA     s= EXPECTINGby_rules(attrs.rename_a exd
// `at          s:"asmessage
        }
            }s_set.inserts> {
  te    (St)fn gEXPECTING<dynokee?turn None;
                         :T> {&tokeA      s.g,
  ()a;
     }
             }      }
          }
}

p{allow(non_upprename_a
        s:tokeA    .T> {
        if sng,
        sre     (' '  ""a;
     }
              ignore&Varrn None;
                eoke.nd ofa      _args!("s stabl       me {
     } else {
        ult::
rn None;
            
        }

        let mut item     Ok(( has_getter(&selmust be placed at the ettr_nd ofaerys;          }
 }         data,
            ges  Sckiniants {
              ld::.erroriginast(cxs with the #[serd0230    att s= REPR       Data::Struct(sty_ = 0230   e enargsf.tok(|syn::: s module ha|p{allow(non_upprename_awhileset.insertt
         n::Dp mod(e?turn None;
                s_set.ierator;
ul: &'a       },
A, valh{          }
                }ss  Sckini|=: Stri s= " Sckin";variant
                                .attrs
}      }
            }Ok(( has_getter(&se(&selm;          }
 }         data,
     : &item.generics,
       BTreeNfn . Unreco_alia  fn f&riginal: i),}) {
    ,leGenerinion(_                ran
  rm_atttran
  rm_a.else(ock) => block,
e) is stable:
    tter) is stable:
    .else(ock) => block,
ei, fiel_serde::else(cs<'a>(&'a     attr:on(_                 k_has_flatten(:rtion<TAll>,
}sh{          }
     sult. UnTyp  k_has_flas tatten else(cs<'a>(&'a tion<T>,
}. on(_               ock,
esult. UnTyp  k_has_flaace"ten else(cs<'a>(&'a tion<T>,
}. on(_               }                k_has_fla  Data::Stru:rtion<TAll>,
}sh{          }
     sult. UnTyp  k_has_fla  Data:s tatten else(cs<'a>(&'a tion<T>,
}. on(_               ock,
esult. UnTyp  k_has_fla  Data:ace"ten else(cs<'a>(&'a tion<T>,
}. on(_               }              t<'aericsde) {
erics else(ock) => block,
eaericsdeeGeerics else(ock) => block,tag  decal:_tagfrom_ast(,}
fn stru, am,
    _tag, generic                 
im    de)]
im     else(ock) => block,t]
imtrym    de)]
imtrym     else(ock) => block,t]
imn<T>de)]
imn<T> else(ock) => block,remeta:e  meta:else(ock) => block, Strii  Dr:adecal:_ Strii  Drfrom_ast(,}  wrapse `ai  Dr,a    match fiei  Dr(ock) => block,    attrs,
ttts {
,ields.iter())       Some(e! {
     :else(ock) => block, s  Sckinock) => block,          l         :else(ock) => block,serds::next_ke.is_some())
    }
}

fn enum_fpan()::Block(blo: ser_renamed,
&    self.
    }
}

fn enum_fark_has_flatten()::Block(bltion<TAll>,
}sh{             sark_has_flatten(
    }
}

fn enum_fark_has_fla  Data::Struc::Block(bltion<TAll>,
}sh{             sark_has_fla  Data::Stru
    }
}

fn enum_ftran
  rm_a: Symbol,
    first_dup_tokens:tran
  rm_a
    }
}

fn enum_fer) is stable:
    : Symbol,
    first_dup_tokens:er) is stable:
    
    }
}

fn enum_fer      ::Block(blo    attec::new(),
&ne() d.  att
    }
}

fn enum_f) {
erics ::Block(blr()
    [erics(paraPredone
 ]eserialize: Strin) {
erics ragmentembers|vec| &vec[..])
    }
}

fn enum_fer
erics ::Block(blr()
    [erics(paraPredone
 ]eserialize: StrineGeerics ragmentembers|vec| &vec[..])
    }
}

fn enum_ftagf::Block(blo ag Strstructu(),
&ne() tag
    }
}

fn enum_ft]
im     ::Block(blr()
    .
    Str>irst_dup_tokens:t]
im     ragmente
    }
}

fn enum_ft]
imtrym     ::Block(blr()
    .
    Str>irst_dup_tokens:t]
imtrym     ragmente
    }
}

fn enum_ft]
im     ::Block(blr()
    .
    Str>irst_dup_tokens:t]
imn<T> ragmente
    }
}

fn enum_f  meta ::Block(blr()
    .
   e! {
h{             sarmeta:ragmente
    }
}

fn enum_f s  Sckin: Symbol,
    first_dup_tokens: s  Sckin
    }
}

fn enum_f Strii  Drf Symbol,
 re `ai  Drstructup_tokens: e `ai  Dr
    }
}

fn enum_from_attrs,
  Symbol,
    first_dup_tokens:rom_attrs,

    }
}

fn enum_f         attrs,
 &s;
       rst_dup_tokens:rom_attrs,
             }
}

fn enum_fcextrec(! {
      ::Block(blr()
    .
   e! {
h{             se! {
     :ragmente
    }
}

fn enum_f(! {
      ::Block(blCow<.
   e! {
h{             scextrec(! {
      has_getter(&sember,
     ame {Cn::pO  de_The entrypo!(c(! {
)),}Cn::pB syn:ed)e_generics_t UnT    asmessagee syn::Tod    en DeImca
   be,
esult. UnTd.ructure, If `on(_`, erthis_tmessageerate: eam),
}

fn enum_f          ::Block(blr()
    .tr
h{             s         :ragmentembers sourc::ragmene
    }
}

fn enum_fserds::next_ke  Symbol,
    first_dup_tokens:serds::next_kes: Option<&atdecal:_tagfntainer_default: &at attr::tainer::from_astt: &at
fn stru:t(j, ());t: &at m,
    _tageeSet::new();
      generic  Set::new();
  ol,
  ag Strstructuefaultrrn None;

fn stru.0.self.tokens, v))(ock) => blam,
    _tag:self.tokens, v))(ock) => blgeneric:self.tokens, v))(ock) =  rst_dup_to(on(_) on(_) on(_  ret ag Str::no,
    ,rt_dup_to(nsert_)) on(_) on(_  ret ag Str::t, name: Symbo(on(_) l<'c> _,ftag))) on(_  ret{          }
      -> ck(Toker t just no teldsnstruct_f ics_t        s_set.ita::Struct(data) => {
 t())),
            syn::Da             cx.erros) = struct_fh{          }
         efault(= true;
                        }
       ttrs.container_defa   |, attrs, containsyn::Ft}                }
       ttrs.containeiner_default),
    {          }
                }s_sattrs, container_defa!;
    }

    fn at               }    en, msg);          }
                }
       "d
// `attagrs:\"...\")]kenSflat eam),
}

    eldsnstruct_f";          }
                }
   e end of the enum");   .iter ec<T> {
        se           }        break;
     }
                }    }
 syn::Da         .attrs
               .attrs
}      }
          as_getter(&self) -> bool {
 ag Str::Iub ident{ tagattrs: Option<&atp_to(nsertt
fn stru_ttr<'c> ta.fi l<'c> n s_ttr<'c> _))) on(_  ret{          }
 en, msg);
"de.
 enSflat eabo   
fn strug///: ub idenly n stru";          }
 e end of the enum");
fn stru_ttr<'c> ec<T> {
        se= Some(value);
       s_ttr<'c> ec<T> {
        se ag Str::no,
         has
   mtrs,r,arate:ome(vtrs: Option<&atp_to(on(_) on(_) l<'c> generic_ttr<'c> _))  ret{          }
 en, msg);
"d
// `attagrs:\"...\", genericrs:\"...\")]ka>(
    m),
}togat,
 ";          }
 e end of the enum");generic_ttr<'c> ec<T> {
        se ag Str::no,
    trs: Option<&atp_to(nsertt
fn stru_ttr<'c> ta.fi on(_) l<'c> generic_ttr<'c> _))  ret{          }
 en, msg);
"
fn strugde.
 enSflathav>)d
// `atgenericrs:\"...\")]";          }
 e end of the enum");
fn stru_ttr<'c> ec<T> {
        se= Some(value);
     generic_ttr<'c> ec<T> {
        se ag Str::no,
    trs: Option<&atp_to(on(_) l<'c> _,ftag))) l<'c> _,fgeneric )  ret ag Str::Adjac      tag, genericr},n<&atp_to(nsertt
fn stru_ttr<'c> ta.fi l<'c> n s_ttr<'c> _))) l<'c> generic_ttr<'c> _))  ret{          }
 en, msg);
"
fn strugde.
 enSflathav>)d
// `attagrs:\"...\", genericrs:\"...\")]";          }
 e end of the enum");
fn stru_ttr<'c> ec<T> {
        se= Some(value);
       s_ttr<'c> ec<T> {
        se= Some(value);
     generic_ttr<'c> ec<T> {
        se ag Str::no,
    trs: Option<&attion<&atdecal:_ Strii  Drfntainer_default: &at attr::tainer::from_astt: &at  wrapse `ai  Dr:t(j, ());t: &at    match fiei  Dr:t(j, ());t:ol,
 re `ai  Drstructuefaultrrn None;
())),
    ,n<&atp_to  wrapse `ai  Dr.0.self.tokens, v))(ock) => bl    match fiei  Dr.0:self.tokens, v))(ock) =  rst_dup_to(_) on(_) on(_  retre `ai  Drctin,st_dup_to(_) l<'c>   wrapse `ai  Dr_ttr<'c> ta.fi l<'c>     match fiei  Dr_ttr<'c> ta.f  ret{          }
 en, msg);
       }
       "d
// `at  wrapse `ai  Dr#[g///:d
// `at    match fiei  Dr#[ enSflat o   b    t";          }
 e end of the enum");  wrapse `ai  Dr_ttr<'c> ec<T> {
        se= Some(value);
         match fiei  Dr_ttr<'c> ec<T> {
        sere `ai  Drctintrs: Option<&atp_to(ttrs.defauldata)_si l<'c>_)) on(_  retre `ai  DrctF0.205/src/inte(ttrs.defauldata)_si on(_) l<'c>_)  retre `ai  DrctV  .iter()
      (ttrs.default());
 ttrs.defat());
 {aainer_df) -> V.. } i l<'c>_)) on(_  ret{          }
 en, msg);
"d
// `at  wrapse `ai  Dr#[genStonut: eam),
}olxylx,
  ";          }
 e end of the enum");ainer_df) -> Vec<T> {
        sere `ai  Drctintrs: Option<&atp_to(ttrs.defaul      ttrs.defa      {au    df) -> V.. } i l<'c>_)) on(_  ret{          }
 en, msg);
"d
// `at  wrapse `ai  Dr#[genStonut: eam),
}olxylx,
  ";          }
 e end of the enum");u    df) -> Vec<T> {
        sere `ai  Drctintrs: Option<&atp_to(ttrs.default());
 ttrs.defat());
 {aainer_df) -> V.. } i on(_) l<'c>_)  ret{          }
 en, msg);
"d
// `at    match fiei  Dr#[ enStonut: eam),
}olxylx,
  ";          }
 e end of the enum");ainer_df) -> Vec<T> {
        sere `ai  Drctintrs: Option<&atp_to(ttrs.defaul      ttrs.defa      {au    df) -> V.. } i on(_) l<'c>_)  ret{          }
 en, msg);
"d
// `at    match fiei  Dr#[ enStonut: eam),
}olxylx,
  ";          }
 e end of the enum");u    df) -> Vec<T> {
        sere `ai  Drctintrs: Option<&at after exR syn::Idss     cx.} else {
 in      t,
   /// AttriVagged() {
    BTreeNfn insert  k_has_flatten(:rtion<TAll>,
}s      t<'aericsde_aliases) <erics(paraPredone
 s {
    aceericsde_aliases) <erics(paraPredone
 s {
    skip_#[cfg(featurett).trim_sta kip_cfg(featurett).trim_stater ttt).trim_sta   new(),
.toke(path) =.
   Expre! {
 name:Vec::new(),
.toke(path) =.
   Expre! {
 name:e syn::(path) =B syn:A else {
>t: &at
fn stru:t).trimfte{
       syn:A else {
        Some(e
   e! {t: &atl::Conta(de_aliasewned()
}
),
    :Conta>       cx,iVagged() {
   ion<Container<'aer_default=     cxr::taineVagged(ew(),
            vame in de;
        l    }

    fn gRENAME'a: 'place`
       er_name.un    }

    fn gRENAME'a: 'place`
                  =alues: V}

    fn gRENAME'a: 'place`
       skip_#[cfg(featureset(j, ());}

    fn gSKIP_DESERIALIZING'a: 'place`
        kip_cfg(featureset(j, ());}

    fn gSKIP_SERIALIZING'a: 'place`
         k_has_flas tatten.un    }

    fn gRENAME_ALL'a: 'place`
         k_has_flaace"ten.un    }

    fn gRENAME_ALL'a: 'place`
       t<'aerics.un    }

    fn gBOUND'a: 'place`
       er_erics.un    }

    fn gBOUND'a: 'place`
       ter tset(j, ());}

    fn gOTHER'a: 'place`
       e! new(),
.tok.un    }

    fn gSERIALIZE_WITH'a: 'place`
       ere! new(),
.tok.un    }

    fn gDESERIALIZE_WITH'a: 'place`
       e syn:.un    }

    fn gBORROW'a: 'place`
       
fn struget(j, ());}

    fn gUNTAGGED'a:             ld::.erro= true;
ast(cxs with the #[serd0230    att != SERDEt();
        let segeneinu::Enum(variants)  with the #[serdis_socontaiken,Li<'atokee);
     .toke   fields,
         f tokeAttr<'c   semptye_by_rules(attrs.rename_ageneinu::Enum(variants     let mut item =  with the #[serdis_s&Varerys = 0230   e enn, Lif_toke(|toke|   fields,
         f tokeA     s= RENAMEby_rules(attrs.rename_a exd
// `at  k_hars: foo"#[allow(non_upprename_a exd
// `at  k_ha(c::new(),rs: foo"rapper_ty, unrs: bar")#[allow(non_upprename_a
     fn ude> {
  tease:iplee")]
sts fn gynokee?       }
            }) {
      self.s(&tokeA        r.ragmentembers),
    tS);}
t dup_      for field in fiel    er_oolAtt_name   }

    fn at            eGeneric sel   }
   er_oolAt.g,
  ()a;
     }
                }me = ser_na= ser_n&tokeA      de_oolAt.g,
  ()a;
     }
             }      }
          }
}

p f tokeA     s= ALIASby_rules(attrs.rename_a exd
// `at= serket foo"#[allow(non_upprename_as_set.inserts> {
  te    (St)fn gALIAS<dynokee?turn None;
                me = ser_na= ser_n&tokeA      s.g,
  ()a;
     }
             }      }
          }
}

p f tokeA     s= RENAME_ALLby_rules(attrs.rename_a exd
// `at  k_has_flrs: foo"#[allow(non_upprename_a exd
// `at  k_has_fl(c::new(),rs: foo"rapper_ty, unrs: bar")#[allow(non_upprename_a
      _name.untokeAsyn::Dpeequote!(![=]      for field in fiel
     fn ude> {
  te")]
sts fn gRENAME_ALL<dynokee?       }
            }s_set.insertstys = s.generics,
      bounds.push(place_tion<T>,
}. Unrec(St)::Brng,
  ()attrs.rename_by_rules(
         Okt  k_has"ten

imp  k_has_flas tatten T> {&tokeA        k_has"ten
,rs.rename_by_rules(
         &Varerys =>he end of the enum"); fn uerys,variant
                                .attrs
}      }
            }s_set.insertde> {
deenerics,
      bounds.push(place_tion<T>,
}. Unrec(St):de.g,
  ()attrs.rename_by_rules(
         Okt  k_has"ten

imp  k_has_flaace"ten T> {&tokeA        k_has"ten
,rs.rename_by_rules(
         &Varerys =>h{          }
                }
   s_s!   _name.{          }
                }
   t the end of the enum");de uerys;          }
                }
   }
     }
                }
   }
   for field in        }               .attrs
}      }
          }
}

p f tokeA     s= SKIPby_rules(attrs.rename_a exd
// `at kip#[allow(non_upprename_a kip_cfg(feature.       s(&tokeA          for field in     skip_#[cfg(feature.       s(&tokeA          for field in  }
}

p f tokeA     s= SKIP_DESERIALIZINGby_rules(attrs.rename_a exd
// `at kip_#[cfg(feature#[allow(non_upprename_a kip_#[cfg(feature.       s(&tokeA          for field in  }
}

p f tokeA     s= SKIP_SERIALIZINGby_rules(attrs.rename_a exd
// `at kip_cfg(feature#[allow(non_upprename_a kip_cfg(feature.       s(&tokeA          for field in  }
}

p f tokeA     s= OTHERby_rules(attrs.rename_a exd
// `atter t  _rules(attrs.rename_ater t.       s(&tokeA          for field in  }
}

p f tokeA     s= BOUNDby_rules(attrs.rename_a exd
// `aterics.un"T:inser     "#[allow(non_upprename_a exd
// `atericsuc::new(),rs: ..."rapper_ty, unrs: ..."##[allow(non_upprename_a
     fn ude> {
  te      predone
 sBox<dynokee?       }
            }) {
erics  self.s(&tokeA        r      for field in fieleGeerics  self.s(&tokeA      de      for field in  }
}

p f tokeA     s= WITHby_rules(attrs.rename_a exd
// `at.tok.un"..."#[allow(non_upprename_as_set.insertnused_e'a syn_    n<T> ttr::   atfn gWITH<dynokee?turn None;
                
       t<'a     s:    :em,
   ;rn None;
                e! a    
     }
                }
   .    
     }
                }
   .segm:Ids
     }
                }
   .   lere `a      "er_ty, un"raShe ::c_flasit ()a        ;
     }
                }e! new(),
.tok:T> {&tokeA      s! a     ;
     }
                }
       er_     s:    ;
     }
                }me     
     }
                }
   .    
     }
                }
   .segm:Ids
     }
                }
   .   lere `a      "pper_ty, un"raShe ::c_flasit ()a        ;
     }
                }ere! new(),
.tok:T> {&tokeA      me     a;
     }
             }      }
          }
}

p f tokeA     s= SERIALIZE_WITHby_rules(attrs.rename_a exd
// `at ! new(),
.tok.un"..."#[allow(non_upprename_as_set.insertnused_e'a syn_    n<T> ttr::   atfn gSERIALIZE_WITH<dynokee?turn None;
                e! new(),
.tok:T> {&tokeA          a;
     }
             }      }
          }
}

p f tokeA     s= DESERIALIZE_WITHby_rules(attrs.rename_a exd
// `ater ! new(),
.tok.un"..."#[allow(non_upprename_as_set.insertnused_e'a syn_    n<T> ttr::   atfn gDESERIALIZE_WITH<dynokee?turn None;
                mee! new(),
.tok:T> {&tokeA          a;
     }
             }      }
          }
}

p f tokeA     s= BORROWp{allow(non_upprename_a
   e syn:_} else {
 =    tokeAsyn::Dpeequote!(![=] turn None;
                 exd
// `ate syn:.un"'a + 'b"#[allow(non_upprename_a   }
   l::Conta(_e'a syn_    n<T> l::Conta(Box<dynokee?       }
            }}}}}  syn:A else {
                                Some(tokeA    .em,
   ,rs.rename_by_rules(
         l::Conta(densertl::Conta(s,variant
                                .attrs
}}
}

pub struct Name             exd
// `ate syn:#[allow(non_upprename_a   }  syn:A else {
                                Some(tokeA    .em,
   ,rs.rename_by_rules(
         l::Conta(det, name: Symbo                               .attrs
};          }
         efault(= true;
                        }
       ttrs.containeiner_default),
 s_sattrs, container_defa=;
  =>h{          }
                }e syn::T> {&tokeA      e syn:_} else {
);
     }
                }               .attrs
e, a_ return None;
                   }en, msg);
"d
// `ate syn:#[ efytonut: eam),
}olx    DeIm       s";          }
                }e end of the enum");   .iter ec<T> {
        se           }               .attrs
}      }
          }
}

p f tokeA     s= UNTAGGEDby_rules(attrs.rename_a
fn stru.       s(&tokeA          for field in  }
}

p{allow(non_upprename_a
        s:tokeA    .T> {
        if sng,
        sre     (' '  ""a;
     }
              ignore&Varrn None;
                eoke.nd ofa      _args!("s stabl            cx.} else {
        ult::
rn None;
            
        }

        let mut item     Ok(( has_getter(&selmust be placed at the ettr_nd ofaerys;          }
 }         data,
     Vagged() {
   ,
       BTreeNfn . Unreco_alia  fn f&= true;
al: i),}) {
    ,leGenerininsertde = ser_n)                 k_has_flatten(:rtion<TAll>,
}sh{          }
     sult. UnTyp  k_has_flas tatten else(cs<'a>(&'a tion<T>,
}. on(_               ock,
esult. UnTyp  k_has_flaace"ten else(cs<'a>(&'a tion<T>,
}. on(_               }              t<'aericsde) {
erics else(ock) => block,
eaericsdeeGeerics else(ock) => block,skip_#[cfg(featurett kip_#[cfg(feature.else(ock) => block,skip_cfg(featurett kip_cfg(feature.else(ock) => block,ter tttter t.else(ock) => block,s::new(),
.toke(e! new(),
.tok:else(ock) => block,
es::new(),
.toke(mee! new(),
.tok:else(ock) => block,e syn::(e syn::else(ock) => block,
fn stru:t
fn stru.else(ock) => bl)
    }
}

fn enum_fpan()::Block(blo: ser_renamed,
&    self.
    }
}

fn enum_f= ser_n)::Block(blowned()
}
new();
irst_dup_tokens:sericmee! new(),
= ser_n))
    }
}

fn enum_fark_hasby::Struc:s;
     , tten(:rtion<TAll>,
}smust be placs_s!kens:serice! new(),
ark_hadh{          }
 kens:serice! new(), s:tten(ce! new(),.apply {
_= true;(&kens:serice! new(),s;         }t be placs_s!kens:sericmee! new(),
ark_hadh{          }
 kens:sericpper_ty, unrs:tten(cpper_ty, un.apply {
_= true;(&kens:sericpper_ty, uns;         }t be plac    self.
       }
   .mee! new(),
= ser_n
       }
   .= ser_nkens:sericpper_ty, un.em,
   );
    }
}

fn enum_fark_has_flatten()::Block(bltion<TAll>,
}sh{             sark_has_flatten(
    }
}

fn enum_f) {
erics ::Block(blr()
    [erics(paraPredone
 ]eserialize: Strin) {
erics ragmentembers|vec| &vec[..])
    }
}

fn enum_fer
erics ::Block(blr()
    [erics(paraPredone
 ]eserialize: StrineGeerics ragmentembers|vec| &vec[..])
    }
}

fn enum_f kip_#[cfg(feature  Symbol,
    first_dup_tokens: kip_#[cfg(feature
    }
}

fn enum_f kip_cfg(feature  Symbol,
    first_dup_tokens: kip_cfg(feature
    }
}

fn enum_fter t  Symbol,
    first_dup_tokens:ter t
    }
}

fn enum_f) {new(),
.tok ::Block(blr()
    .
   Expre! {
serialize: Strin) {new(),
.tok:ragmente
    }
}

fn enum_fmee! new(),
.tok ::Block(blr()
    .
   Expre! {
serialize: Strinmee! new(),
.tok:ragmente
    }
}

fn enum_f
fn stru  Symbol,
    first_dup_tokens:
fn strun<&at after exR syn::Idssattrs.} else {
 in      t,
   /// Attriconta) {
    BTreeNfn insert kip_cfg(featurett).trim_staskip_#[cfg(featurett).trim_sta kip_cfg(feature_ife(path) =.
   Expre! {
 name:Vei, fiel    attim_sta   new(),
.toke(path) =.
   Expre! {
 name:Vec::new(),
.toke(path) =.
   Expre! {
 name:t<'aericsde_aliases) <erics(paraPredone
 s {
    aceericsde_aliases) <erics(paraPredone
 s {
    b syn:ed_l::Conta(dewned()
}
),
    :Conta>{
    elst tttpath) =.
   Expre! {
 name:attrs,
tt).trim_sta ran
  rm_att).trimfter exR syn::Idsser  erthis_ttoam),     lsattrs.   en#[cfg(feature.   //de.
     attec::newr exconta)a>(
 always b   peci  Dd b cam), it  has flathav>)al_serde::::newt, name: Sr exTr  erthis_tis giv enby `std::d   attr:D      ::d   att()`:::new    attim_star exTr  erthis_tis giv enby this functh) :::new:Defa.
   Expre! {)      cx,i    attec::new enum_f s }
    Symbol,
    first_dup_toefaults            va:new    att. on(_ ret   s,       va:new    att.     atte|     attr::Defa   retts {
,ields.iteon<&at afte cx,iconta) {
    UnT x ratriouoker  `d
// `at...)]`.} else {
sntain)al/ Attriattrs.{
   ion<Container<'ack) => blgr_default: &at> blamder_dus(),,n<&atp_to  wrar::taineF0.205/src/inteo_alittpath) =&Vagged(>ock) => blgenetem.g_Vei, fiel&    attim_staew(),
            vame in de;
        l    }

    fn gRENAME'a: 'place`
       er_name.un    }

    fn gRENAME'a: 'place`
                  =alues: V}

    fn gRENAME'a: 'place`
       skip_cfg(featureset(j, ());}

    fn gSKIP_SERIALIZING'a: 'place`
       skip_#[cfg(featureset(j, ());}

    fn gSKIP_DESERIALIZING'a: 'place`
        kip_cfg(feature_if.un    }

    fn gSKIP_SERIALIZING_IF'a: 'place`
         this_typ    }

    fn gDEFAULT'a: 'place`
       e! new(),
.tok.un    }

    fn gSERIALIZE_WITH'a: 'place`
       ere! new(),
.tok.un    }

    fn gDESERIALIZE_WITH'a: 'place`
       t<'aerics.un    }

    fn gBOUND'a: 'place`
       er_erics.un    }

    fn gBOUND'a: 'place`
       b syn:ed_l::Conta(.un    }

    fn gBORROW'a: 'place`
       elst t.un    }

    fn gGETTER'a: 'place`
       attrs,
   (j, ());}

    fn gFLATTEN'a:         
    Stri s efault(attrs. Stri         va:newnsertn    },
>   fn fal: i),       va:newon(_ retamderng,
        ,ields.iteoa:         s_set.inserte syn:_} else {
) = 0230s.and_er ns|vagged(|      cx.e syn::ragmente)xs with the #[serdet.iOkte syn:aben

i e syn:aben l::Conta(Box<dyal: i,}  wra)   fields,
         f et.insertl::Conta(s);
 e syn:_} else {
.l::Conta(.{    for field in fiel    l::Contat_nal::Conta(.{    for field in fielplacs_s!e syn:aben.genetemstl::Conta)turn None;
                   }en, msg);          }
                }
         !("attrs.      has flathav>)l::Contat{}", al: i,}l::Conta);          }
                }e end of the enum");attrsr ec<T> {
        se           }               .attrs
}      }
             b syn:ed_l::Conta(:T> {&e syn:_} else {
.      l::Conta(:em,
   );
    or field in  }
}

p{allow(non_upprename_ab syn:ed_l::Conta(:T> {&e syn:_} else {
.      e syn:aben
;      }
          as_getter(&self) -> boo}:             ld::.erroattrs.ast(cxs with the #[serd0230    att != SERDEt();
        let segeneinu::Enum(variants)  with the #[serdis_socontaiken,Li<'atokee);
     .toke   fields,
         f tokeAttr<'c   semptye_by_rules(attrs.rename_ageneinu::Enum(variants     let mut item =  with the #[serdis_s&Varerys = 0230   e enn, Lif_toke(|toke|   fields,
         f tokeA     s= RENAMEby_rules(attrs.rename_a exd
// `at  k_hars: foo"#[allow(non_upprename_a exd
// `at  k_ha(c::new(),rs: foo"rapper_ty, unrs: bar")#[allow(non_upprename_a
     fn ude> {
  tease:iplee")]
sts fn gynokee?       }
            }) {
      self.s(&tokeA        r.ragmentembers),
    tS);}
t dup_      for field in fiel    er_oolAtt_name   }

    fn at            eGeneric sel   }
   er_oolAt.g,
  ()a;
     }
                }me = ser_na= ser_n&tokeA      de_oolAt.g,
  ()a;
     }
             }      }
          }
}

p f tokeA     s= ALIASby_rules(attrs.rename_a exd
// `at= serket foo"#[allow(non_upprename_as_set.inserts> {
  te    (St)fn gALIAS<dynokee?turn None;
                me = ser_na= ser_n&tokeA      s.g,
  ()a;
     }
             }      }
          }
}

p f tokeA     s= DEFAULT      }
                  tokeAsyn::Dpeequote!(![=] turn None;
                 exd
// `aterthis_typ"..."#[allow(non_upprename_a   }s_set.insertnused_e'a syn_    n<T> ttr::   atfn gDEFAULT<dynokee?turn None;
                   }_serde::T> {&tokeA          attr::Default::
;rs.rename_by_rules(
                    .attrs
}}
}

pub struct Name             exd
// `aterthis_#[allow(non_upprename_a   }_serde::T> {&tokeA          attr:D        style,
              }    for field in  }
}

p f tokeA     s= SKIP_SERIALIZINGby_rules(attrs.rename_a exd
// `at kip_cfg(feature#[allow(non_upprename_a kip_cfg(feature.       s(&tokeA          for field in  }
}

p f tokeA     s= SKIP_DESERIALIZINGby_rules(attrs.rename_a exd
// `at kip_#[cfg(feature#[allow(non_upprename_a kip_#[cfg(feature.       s(&tokeA          for field in  }
}

p f tokeA     s= SKIPby_rules(attrs.rename_a exd
// `at kip#[allow(non_upprename_a kip_cfg(feature.       s(&tokeA          for field in     skip_#[cfg(feature.       s(&tokeA          for field in  }
}

p f tokeA     s= SKIP_SERIALIZING_IFby_rules(attrs.rename_a exd
// `at kip_cfg(feature_if.un"..."#[allow(non_upprename_as_set.insertnused_e'a syn_    n<T> ttr::   atfn gSKIP_SERIALIZING_IF<dynokee?turn None;
                ekip_cfg(feature_if:T> {&tokeA          a;
     }
             }      }
          }
}

p f tokeA     s= SERIALIZE_WITHby_rules(attrs.rename_a exd
// `at ! new(),
.tok.un"..."#[allow(non_upprename_as_set.insertnused_e'a syn_    n<T> ttr::   atfn gSERIALIZE_WITH<dynokee?turn None;
                e! new(),
.tok:T> {&tokeA          a;
     }
             }      }
          }
}

p f tokeA     s= DESERIALIZE_WITHby_rules(attrs.rename_a exd
// `ater ! new(),
.tok.un"..."#[allow(non_upprename_as_set.insertnused_e'a syn_    n<T> ttr::   atfn gDESERIALIZE_WITH<dynokee?turn None;
                mee! new(),
.tok:T> {&tokeA          a;
     }
             }      }
          }
}

p f tokeA     s= WITHby_rules(attrs.rename_a exd
// `at.tok.un"..."#[allow(non_upprename_as_set.insertnused_e'a syn_    n<T> ttr::   atfn gWITH<dynokee?turn None;
                
       t<'a     s:    :em,
   ;rn None;
                e! a    
     }
                }
   .    
     }
                }
   .segm:Ids
     }
                }
   .   lere `a      "er_ty, un"raShe ::c_flasit ()a        ;
     }
                }e! new(),
.tok:T> {&tokeA      s! a     ;
     }
                }
       er_     s:    ;
     }
                }me     
     }
                }
   .    
     }
                }
   .segm:Ids
     }
                }
   .   lere `a      "pper_ty, un"raShe ::c_flasit ()a        ;
     }
                }ere! new(),
.tok:T> {&tokeA      me     a;
     }
             }      }
          }
}

p f tokeA     s= BOUNDby_rules(attrs.rename_a exd
// `aterics.un"T:inser     "#[allow(non_upprename_a exd
// `atericsuc::new(),rs: ..."rapper_ty, unrs: ..."##[allow(non_upprename_a
     fn ude> {
  te      predone
 sBox<dynokee?       }
            }) {
erics  self.s(&tokeA        r      for field in fieleGeerics  self.s(&tokeA      de      for field in  }
}

p f tokeA     s= BORROWp{allow(non_upprename_a   tokeAsyn::Dpeequote!(![=] turn None;
                 exd
// `ate syn:.un"'a + 'b"#[allow(non_upprename_a   }
   l::Conta(_e'a syn_    n<T> l::Conta(Box<dynokee?       }
            }}}}}erdet.iOkte syn:aben

i e syn:aben l::Conta(Box<dyal: i,}  wra)   fields,
        ield in fiel    l::Contat_na&l::Conta(.{    for field in fielplacfielplacs_s!e syn:aben.genetemstl::Conta)turn None;
                   }       }en, msg);
      !(rn None;
                   }       }}}}}"attrs.      has flathav>)l::Contat{}",rn None;
                   }       }}}}}al: i,}l::Conta,rn None;
                   }       });          }
                }
   t the end of the enum");attrsr ec<T> {
        se           }       }               .attrs
e, a   }               .attrs
e, a   }b syn:ed_l::Conta(:T> {&tokeA      l::Conta(s;variant
                                .attrs
}}
}

pub struct Name             exd
// `ate syn:#[allow(non_upprename_a   }erdet.iOkte syn:aben

i e syn:aben l::Conta(Box<dyal: i,}  wra)   fields,
        ield in fielb syn:ed_l::Conta(:T> {&tokeA      e syn:aben
;      }
                }               .attrs
}      }
          }
}

p f tokeA     s= GETTERby_rules(attrs.rename_a exd
// `atelst t.un"..."#[allow(non_upprename_as_set.insertnused_e'a syn_    n<T> ttr::   atfn gGETTER<dynokee?turn None;
                elst t:T> {&tokeA          a;
     }
             }      }
          }
}

p f tokeA     s= FLATTENby_rules(attrs.rename_a exd
// `at ttrs,
#[allow(non_upprename_a ttrs,
.       s(&tokeA          for field in  }
}

p{allow(non_upprename_a
        s:tokeA    .T> {
        if sng,
        sre     (' '  ""a;
     }
              ignore&Varrn None;
                eoke.nd ofa      _args!("s stabl       attrs.} else {
        ult::
rn None;
            
        }

        let mut item     Ok(( has_getter(&selmust be placed at the ettr_nd ofaerys;          }
 }         data,
     e, Is skip_#[cfg(feature, amitty, unrer  attrs.to D      ::d   att() unless ata,
     e, differm_a erthis_tis  peci  Dd by `d
// `aterthis_typ"..."#[` onta,
     e, ousynlvas    ous me {
     (e.g.rer  / Attriw just in).         s_set.i    att. on(_ r *genetem.g_Vei, fixs with the #[serdskip_#[cfg(feature.0.g,
     sssertmust be placed at th_serde::T> l   }
       attr:D        style,
      }         data,
            gb syn:ed_l::Conta(.unb syn:ed_l::Conta(:else(cs<'a>(&'a_d   att();
fielplacs_s!e syn:ed_l::Conta(:  semptye_by_rules(attrs.    ow<.tr
h///: ow<[u8]> nev   e syn:.by Vei, fie_rules(attrs.  _rules(attrs.   placsmpl<'de u'a, T:i?SUnTd>i  er_ty, un<'de>l     ow<'a, T>_rules(attrs.  _rules(attrs.   Axd
// `ate syn:#[.} else {
 enabens e syn:uresk(Tokc syespolrename_arough/: uo        s. sby Vei, fie_rules(attrs.  _rules(attrs.   pl:csmpl'a T:i?SUnTd>i  er_ty, un<'de>l  rs. s(attrs.  _rules(attrs.   pl:csmpl'a T:i?SUnTd>i  er_ty, un<'de>l  
h///_Vei, fixs with l::cow(  ld::.ty, l::rs.)tt s= REPR       Data::
   name_a
     Some in  }
}

p{allow(non_uppadp_cfco  s l::Conta(det, name: Symbo      }
  : Pnby usage   ler>,
}. on(_            .attrs
};       the #e e_a
_ty, un"raShe ::c  .attrs
};           e!   }
       }
   .   lere entryse #e e_flasit ()a        ;
     }    e!   }
       }
   .   lere     vsagse #e e_flasit ()a        ;
     }    e!   }
       }
   .   lereryse #e e_flasit ()a        ;
     }    e!   }
  
s
     }
                }
   .   lerenta(:T>cow:rs.se #e e_flasit ()a        ;
     }the _   _a
     :Defa.
  in  }
}

p{allow(non_u5/src/iVec   ler>,
}. on(_             qp_to l::Conta(det, name: Symbo  pome(e
   n(_            .attrs
};                }ere! new()serde::T>_   tr:D        styl         l::cow(  ld::.ty, l::rlice_u8)tt s= REPR       Data::
   name_a
     Some in  }
}

p{allow(non_uppadp_cfco  s l::Conta(det, name: Symbo      }
  : Pnby usage   ler>,
}. on(_            .attrs
};       the #e e_a
_ty, un"raShe ::c  .attrs
};           e!   }
       }
   .   lere entryse #e e_flasit ()a        ;
     }    e!   }
       }
   .   lere     vsagse #e e_flasit ()a        ;
     }    e!   }
       }
   .   lereryse #e e_flasit ()a        ;
     }    e!   }
  
s
     }
                }
   .   lerenta(:T>cow:bytesse #e e_flasit ()a        ;
     }the _   _a
     :Defa.
  in  }
}

p{allow(non_u5/src/iVec   ler>,
}. on(_             qp_to l::Conta(det, name: Symbo  pome(e
   n(_            .attrs
};                }ere! new()serde::T>_   tr:D        styl
     styl         l::rs. icitly_elplacs_(  ld::.ty:  semptye_by_rules    s (blr   ow&
h// / Atonta)a>rs. icitly::Conta(..l::: ois f,arate:ome(y_rulesaattrs.   Axd
// `snstruct_f icsco lecte syn:aben   ld::.ty, &
            gb syn:edper_ty, uns; r_ty, uns afte cx,icoed() {
   ,
       BTreeNfn . Unta(Box;
al: i),}) {
    ,leGenerininsertde = ser_n)      => block,skip_cfg(featurett kip_cfg(feature.else(ock) => block,skip_#[cfg(featurett kip_#[cfg(feature.else(ock) => block,skip_cfg(fe          ekip_cfg(fble:
    .else(ock) => block,
ei, fiel_serde::else(cs<'a>(&'a     attr:on(_      => block,s::new(),
.toke(e! new(),
.tok:else(ock) => block,
es::new(),
.toke(mee! new(),
.tok:else(ock)          t<'aericsde) {
erics else(ock) => block,
eaericsdeeGeerics else(ock)         gb syn:edrics else(ock)nta>{
         eeGeerics else(ock)block,    prenamemtrym     else(ock) .trim_sta raDefa   retts {
,ields.ibl)
    }
}

fn enum_fpan()::Block(blo: ser_renamed,
&    self.
    }
}

fn enum_f= ser_n)::Block(blowned()
}
new();
irst_dup_tokens:sericmee! new(),
= ser_n))
    }
}

fn enum_fark_hasby::Struc:s;
     , tten(:rtion<TAll>,
}smust be placs_s!kens:serice! new(),
ark_hadh{          }
 kens:serice! new(), s:tten(ce! new(), ld::{
_= true;(&kens:serice! new(),s;         }t be placs_s!kens:sericmee! new(),
ark_hadh{          }
 kens:sericpper_ty, unrs:tten(cpper_ty, un ld::{
_= true;(&kens:sericpper_ty, uns;         }t be plac    self.
       }
   .mee! new(),
= ser_n
       }
   .= ser_nkens:sericpper_ty, un.em,
   );
    }
}

fn enum_f kip_cfg(feature  Symbol,
    first_dup_tokens: kip_cfg(feature
    }
}

fn enum_f kip_#[cfg(feature  Symbol,
    first_dup_tokens: kip_#[cfg(feature
    }
}

fn enum_f kip_cfg(ew(),
.tok ::Block(blr()
    .
   Expre! {
seriali         ekip_cfg(fw(),
.tok:ragmente
    }
}

fn enum_fer      ::Block(blo    attec::new(),
&ne() d.  att
    }
}

fn enum_f) {new(),
.tok ::Block(blr()
    .
   Expre! {
serialize: Strin) {new(),
.tok:ragmente
    }
}

fn enum_fmee! new(),
.tok ::Block(blr()
    .
   Expre! {
serialize: Strinmee! new(),
.tok:ragmente
    }
}

fn enum_f) {
erics ::Block(blr()
    [erics(paraPredone
 ]eserialize: Strin) {
erics ragmentembers|vec| &vec[..])
    }
}

fn enum_fer
erics ::Block(blr()
    [erics(paraPredone
 ]eserialize: StrineGeerics ragmentembers|vec| &vec[..])
    }
}
         gb syn:edm_f= ser_n)::Block(blewned()
}
),
 blo    attec::new         gb syn:ed &vec[..])
    }
}
      ew(),
.tok ::Block(blr()
    .
   Expre! {
serial       w(),
.tok:ragmente
    }
}
enum_from_attrs,
  Symbol,
    first_dokens:rom_attrs,

    }
}

fn enum_ftran
  rm_a: Symbol,
    first_dup_tokens:tran
  rm_a
    }
}

fn e
fn enum_ftra attrs,
 &s;
       rst_d
fn enum_ftom_attrs,
      rm),
}oSerAndDe<T>om_(::BlockT>, ::BlockT>n gF
}
     k_h) = de<'c, T, F, R> Strii  Drf'c => blgr_defn ._  ,
  Symbttrs,
tt    DrfPtnusN30   dis_ Expre!: F,t(j, (blr()Res&ne<(       <'c, T>,        <'c, T>)>
de> {ExpreT: Cl:Conta(deF: Fromer<'aeSymbttreSymbttrefPtnusN30   dis_(j, (blr()Res&ne<R =&VaggR: Iasi<::BlockT> =&s;
             
 e);
           =alues: V}fn ._  ,
un.em,
         }
e);
           =alues: V}fn ._  ,
un..em,
    lookahpad     _name.untlookahpad1:c  .att.   ookahpadtokeAsyn::Dpeequote!(![=] t:         s_set.insefs: V}fn ._  ,
V}fn ._  ,
V}gGETTEflasit ),
ark_hadh{     
 e);
me = ser_na= ser_n&tset. l::Conta(:em,
   );
   }
e);
me = ser_na= ser_n&tset.per_ty, uns;     l          ookahpadtokeAseA     Som_f ),
ark_hadhna= ser = 0230   e enn, Lif_toke(|toke|   fi    }
}

p f tokeA     s= i,}  wra)   fields,
         fvinsefs: V}fn ._  ,
V}eA     s=fn gGETTEflasit ),
ark_hadh{   hadh{     
 e);
me = ser_na= ser_n&tve syn:aben
;      }
          as_g          }
}

p f tokeA     s= D i,}  wra)   fields,
         fvinsefs: V}fn ._  ,
V}eA     s= Dfn gGETTEflasit ),
ark_hadh{   hadh{    }
e);
me = ser_na= ser_n&tve syn:aben
;      }
          as_g      ,
ark_hadh{   hadh                     eoke.nd ofa   
ark_hadh{   hadh{   "maloke.w(),0}ate syn:#[,

fn ene}}}}0}/ `atericsuc:...),rs: ..."rapper `d
`::Contat{}",rn None;
  fn ._  ,
VContat{}",rn None))tr:D        styl
     sty mut item     Ok(( }Box<dynog      ,
ark_hadh            ookahpadt     e un.em,
   );
  ite  
 e);
,  }
e);
m  }gF
}
    ease:iplStrii  Drfntainer_defn ._  ,
  Symbttrs,
tt    DrfPtnusN30   dis_ E(j, (blr()Res&ne<SerAndDe<mentembers)>  Expre!pprename_a
     fn u k_h) = des: V}fn ._  ,
V}e);
, nserts> {
 2Box<dyno ite  
.nd most_keA   a
 .nd most_keA  m  }gF
}
    de> {
  tease:iplStrii  Drfntainer_de    DrfPtnusN30   dis_ E(j, (blr()Res&ne<(  elst tttpambers)>,     tttpambers)>)  Expre!pprename_a
     fn u k_h) = des: V}eA    V}e);
, nserts> {
 2Box<dyno ite  
.nd most_keA   a
 .mtrymm  }gF
}
    de> {
  te      pStrii  Drfntainer_de    DrfPtnusN30   dis_ E(j, (blr()Res&ne<SerAndDe<sde_aliases) <erics(paraP  Expre!pprename_a
     fn u k_h) = des: V}eA   V}e);
, rtnused_e'a synde> {Box<dyno ite  
.nd most_keA   a
 .nd most_keA  m  }gF
}
    ts> {
  Strii  Drfntainer_defn ._  ,
  Symbttrs,
tt    DrfPtnusN30   dis_ E(j, (blr()Res&ne<  elst tttpambers)>  Expre!nserts> {
 2s: V}fn ._  ,
V}fn ._  ,
V}gGETT }gF
}
    ts> {
 2 Strii  Drfntainer_defn ._  ,
  Symbttrs,
tt    _rn N_  ,
  Symbttrs,
tt    DrfPtnusN30   dis_ E(j, (blr()Res&ne<  elst tttpambers)>  Expre!the _   :
     :Def     _naeA     ?ser = (Box<dyno        iel   = &_   x<dynowhile the #[ser:Def::Group(     iel   {ens, v))(ocl   = &_._   x<dyno}
  with the #[ser:Def::mbe:::new:Defmbeaew(),
     it:
     mbe(ttrs( itm     else(.snstru}    iel  nstruew(),
        suffix    it.suffix'a_d   att();
fisuffix_l::Conta(:  semptye_by_ru }
   t the end of ta        ;
     }tit,
   }
                }
  un
fn ene}}suffix }}}"aon   if s}titeralse #uffixm     else(ock)per_ty, uns;          it    f et l::Conta)<dynog      ,
ark_hadh }
   t the end of ta        ;
  _   rics else(ock)bn, msg);
      !(rn None"
fn ene}}s"s st{}ate syn:#[ uo bee {
sn#[cfg}}}", generic`::Contat{}",rn Nonefn ._  ,
V}gGET_rn N_  ,
    else(ock)p:Contat{}"per_ty, uns it     trs: Option<&rtnused_e'a synn<T> Strii  Drfntainer_defn ._  ,
  Symbttrs,
tt    DrfPtnusN30   dis_ E(j, (blr()Res&ne<  elst tttpa .
    Expre!the   if s}
    Strnserts> {
  te  fn ._  ,
V}gGETTE ,
ark_hadhe_as_s if snserts if s:Contat{}"    va:n        it     :Conta,ields.i itrst_dup if sser = (B ,
ark_hadh itset.ins>me_as_set.i:Contat{}"    _   &Varerys =>h{    }
   t the end of ta        ;
     }&s if s:Contat{}"             }
  failenrer er =        {:?l::Cp if sseA           else(ock)per_ty, unst{}"    r_ty, uns;     l)ption<&rtnused_e'a syn_    n<T> Strii  Drfntainer_defn ._  ,
  Symbttrs,
tt    DrfPtnusN30   dis_ E(j, (blr()Res&ne<  elst tttpa
    .
    Expre!the   if s}
    Strnserts> {
  te  fn ._  ,
V}gGETTE ,
ark_hadhe_as_s if snserts if s:Contat{}"    va:n        it     :Conta,ields.i itrst_dup if sser = (B ,
ark_hadh it_   tns>me_as__   t:Contat{}"    _   &Varerys =>h{    }
   t the end of ta        ;
     }&s if s:Contat{}"             }
  failenrer er =        {:?l::Cp if sseA           else(ock)per_ty, unst{}"    r_ty, uns;     l)ption<&rtnused_e'a synde> { Strii  Drfntainer_defn ._  ,
  Symbttrs,
tt    _rn N_  ,
  Symbttrs,
tt    DrfPtnusN30   dis_ E(j, (blr()Res&ne<sde_aliases) <erics(paraP Expre!the   if s}
    Strnserts> {
 2 te  fn ._  ,
V}gGET_rn N_  ,
V}gGETTE ,
ark_hadhe_as_s if snserts if s:Contat{}"    va:n        itVec   ler> :Conta,ields.i itl,
    first_dup if sser = ee! nePnby usage  _aliases) <erics(par, yn::Dpe,]>::er = eterminsage:  semptye_by_ru its te      nsertVec  TreeNiterts te      n     else(ock)
         &Varerys =>h{              }
 e end of the #[cfgnum");de uerys;       Vec   ler>:D        styl
     stylel&    ption<&rtnused_e'a synty Strii  Drfntainer_defn ._  ,
  Symbttrs,
tt    DrfPtnusN30   dis_ E(j, (blr()Res&ne<  elst tttpa       Expre!the   if s}
    Strnserts> {
  te  fn ._  ,
V}gGETTE ,
ark_hadhe_as_s if snserts if s:Contat{}"    va:n        it     :Conta,ields.i itrst_dup if sser = (B ,
ark_hadh itty: s>me_as_ty::Contat{}"    _   &Varerys =>h{    }
   t the end of ta        ;
     }&s if s:Contat{}"             }
  failenrer er =  ),
}: }}", {:?l::Cfn ._  ,
V}p if sseA           else(ock)per_ty, unst{}"    r_ty, uns;     l)ptio// Ptnusse {
sn#[c}titeral}tikeate syn:.syn:c"vas    o#[c}a alueonta}tist ofo// gb syn:ed_seer sage  pec+`.on<&rtnused_e'a syngb syn:edmStrii  Drfntainer_de    DrfPtnusN30   dis_ E(j, (blr()Res&ne<(de_aliasewned()
}
),
   Expre!the   if s}
    Strnserts> {
  te  eA    V}gGETTE ,
ark_hadhe_as_s if snserts if s:Contat{}"    va:n        it(de_alia   ler> :Conta,ields.iname_a   } et.insertl::p if sser = ee! ne|me.un: PtnusST> {
|aew(),
            vatom_(de_alia   ler>er_ty, unswhile !me.untl::Conta(:  semptye_by_runame_a   }
 : ()
}
),
_} ea   tor = (Box<dyno        }t be tme = ser_a   }
  l::ContaVarerys =>h{              }
 e end of tContat{}",rn None;
  &s if s:Contat{}"                 }
  du. icsag
        s flathav>} else .genetemsVContat{}",rn None)r:D        styl
     sty mut   le.untl::Conta(:  semptye_by_ruock) > {kr:D        styl
     sty mut a   tor =   _yn::Dpe+]>(Box<dyno    ;          ite t)
has_getter(&selmunamee syn:ed_l::Conta(:  semptye_by_ru       }
 e end of the #[cfg"atuppasrenams flathav>r excbg
        "per_ty, uns;                 itgb syn:edper_ty,   );
        }
 e end of tContat{}"&s if s:Contat{}"     }
  failenrer er =          s flathavs  {:?l::Cp if sseA           e)x<dyno it(de_alia   ler> ption<&l::rs. icitly_elplacs_(tytp_to  w    rm_a: Symbol,
  l::rs. icitly_elplacs_),
.   ecs_ty: || l::o elst(ty, l::rs. icitly_elplacs_),
.   ecs ption<&l::rs. icitly_elplacs_),
.   ecs_tytp_to  w    rm_a: Symbol,
  l::,
.   ecs_ty, l::rs.)t|| l::,
.   ecs_ty, l::rlice_u8)ptio// es)`
       ),
}o ooks}tikeai   ighxcbg
 giv e => blo:<'deT>` de> {   em="T".
attimisfiei   hasDefa  negati e,   owDefa  positi e,.
at
attFefa  negati e:
at
atttttti  Dgiv e => blo:<'d as Pig;
at
atttttt#[deri e(:i?SUnTd>i )]
atttttt(e.g.reS<'a T{
atttttttttt#[      exd
// `aattttttttttpig: Pige>l  rs. ,aatttttt}
at
attFefa  positi e:
at
atttttt),
}oblr = [i16];
at
atttttt#[deri e(:i?SUnTd>i )]
atttttt(e.g.reS<'a T{
atttttttttt#[      exd
// `aattttttttttcbloc<'de>l  rs. ,aatttttt}
n<&l::cow(tytp_to  w    ,   em: from_o  w    rm_a: Symrm_a: Symbol,
  pprename_a
   Strungroup(ty:  semptye_b_o  w           ty: s>m&ty.pome(e
   n(_ attrs
e, a_ return        Defa er_ty, uns;     lx<dyno    ses}
    Str    e!   }
   ln<Co) ,
ark_hadhe_as_sesnsertses:Contat{}"    va:n
e, a_ return        Defa er_ty, uns;     lx<dyno    ofa  
    Strises.ofau }
    semptye_b_o  w    Afau }
  ::AngleBracke   (bracke   : s>m&bracke   .ofas(e
   n(_ attrs
e, a_ return        Defa er_ty, uns;     lx<dynoses.      
= "<'d"Contat{}"&& ofa s, contain2Contat{}"&&    Str(&ofa [0], &ofa [1quote!(![=] turn :::newGenSUncAfau }
 ed()
}
),
 _ , ::newGenSUncAfau }
 ed    (ofa): s>m  em(ofa)VContat{}",rn _tr::Defa   retts {
,ition<&l::o elst(tytp_to  w    ,   em: from_o  w    rm_a: Symrm_a: Symbol,
  pprename_a
   Strungroup(ty:  semptye_b_o  w           ty: s>m&ty.pome(e
   n(_ attrs
e, a_ return        Defa er_ty, uns;     lx<dyno    ses}
    Str    e!   }
   ln<Co) ,
ark_hadhe_as_sesnsertses:Contat{}"    va:n
e, a_ return        Defa er_ty, uns;     lx<dyno    ofa  
    Strises.ofau }
    semptye_b_o  w    Afau }
  ::AngleBracke   (bracke   : s>m&bracke   .ofas(e
   n(_ attrs
e, a_ return        Defa er_ty, uns;     lx<dynoses.      
= "  elst"Contat{}"&& ofa s, contain1Contat{}"&&    Str&ofa [0]),
ark_hadh{    :newGenSUncAfau }
 ed    (ofa) s>m  em(ofa)VContat{}",rn _tr::Defa   retts {
,itio// es)`
       ),
}o ooks}tikeai   ighxcbg
 &T` de> {   em="T".timisfiei   hao// Defa  negati e,   owDefa  positi e,.
at
attFefa  negati e:
at
atttttt),
}oYarnl::p i;
at
atttttt#[deri e(:i?SUnTd>i )]
atttttt(e.g.reS<'a T{
attttttttttrDrf'aoYarn,aatttttt}
at
attFefa  positi e:
at
atttttt),
}oblr = [i16];
at
atttttt#[deri e(:i?SUnTd>i )]
atttttt(e.g.reS<'a T{
attttttttttrDrf'ao(e.,aatttttt}
n<&l::,
.   ecs_tytp_to  w    ,   em: from_o  w    rm_a: Symrm_a: Symbol,
     Strungroup(ty:  semptye_b_o  w      R
.   ecs_ty: att.y.   abits>y.new enum)"&&   em(&ty.  em)(e
   n(_ attrsDefa   rett,ition<&l::{
  tytp_to  w    rm_a: Symbol,
  l::primiti e_),
}_ty, "rs.s ption<&l::rlice_u8 tytp_to  w    rm_a: Symbol,
     Strungroup(ty:  semptye_b_o  w      Slice_ty: attl::primiti e_),
}_&ty.  em, "u8")(e
   n(_ attrsDefa   rett,ition<&l::primiti e_),
}_tytp_to  w    , primiti e:"&s irm_a: Symbol,
     Strungroup(ty:  semptye_b_o  w           ty: s>mty.qp_to.new enum)"&& l::primiti e_n<T> &ty.pome( primiti e)(e
   n(_ attrsDefa   rett,ition<&l::primiti e_p    attrtp_to  wPome( primiti e:"&s irm_a: Symbol,
      eppadp_cfco  s.new enum)Contat{}"&&     e!   }
   l contain1Contat{}"&&     e!   }
  [0].      
= primiti eContat{}"&&     e!   }
  [0].ofau }
  _l::Conta(:itio// All gb syn:ed_e syn giv ),
}ocouldu8]> nev else {:i?SUnTd>i r.
at
attFor exas. ee {),
}o`Se>l  'b>` couldu8]> nev`'a`   ow`'b`. On     up_to   nd
lesaa),
}o`   <'a Tfrom'ao(e.)` couldu    8]> nev`'a`  else    :i?SUnTd>i r.
at
attimisfisfytonu  lsate> { i,    _   icit ousrs. iciteci  Dd byexd
// ``
lesae syn:#[ onamitty, unrsoate> { r excbg
atuppasrenamsokeA       gb syn:e.on<&n:aben

i e syn:aben Strii  Drfntainer_de  ,
  &(e.,at{}" n<&atp_to  wrar::taten()::s&ne<(de_aliasewned()
}
),
 , ()  Expre!ppre    gb syn:ed_l:(de_alia   ler>er_ty,co lecte syn:aben   ld::.ty, &
   gb syn:edper_ty,namee syn:ed_l::Conta(:  semptye_b }       }en, msg)     }}}}}"ahas.   gb syn:ed_eo&n:aben",   ,
un.em,
     }
   t the end of the enum");attrsr ec<T    (a)<dynog      ,
ark_hadh itgb syn:edp rett,ition<&co lecte syn:aben tytp_to  w    , oun: &
   (de_aliasewned()
}
),
 )bol,
     Strty ,
ark_hadh#![cfgNfn .(all(test,

fha exi e)(    y( en_
fha exi e_omit   epens:rnsunrs: ..."##_o  w      Slice_ty: att{nstruct_f icsco lecte syn:aben  ty.  em, ounper_ty, uns;         }o  w      Array_ty: att{nstruct_f icsco lecte syn:aben  ty.  em, ounper_ty, uns;         }o  w      P
  ty: att{nstruct_f icsco lecte syn:aben  ty.  em, ounper_ty, uns;         }o  w      R
.   ecs_ty: att{nstruct_f icsoun.exten_(ty_} else {.itert) l::Codnta(:em,
   );
  co lecte syn:aben  ty.  em, ounper_ty, uns;         }o  w      Tu. e_ty: att{nstruct_f ics, un  em  l::ty.  emst != SERDEt();
       lecte syn:aben   em, ounper_ty, uns style,
      } emptye_b_o  w           ty: s>mragmente)xs with the e_as_qrs,
 &=::ty.qp_toefaults        ;
  co lecte syn:aben  qp_to.ty, ounper_ty, uns style,
       ics, unses} l::ty.    e!   }
   i,}  wra)   fields,
     _o  w    Afau }
  ::AngleBracke   (bracke   : srises.ofau }
    semptye_b,
       ics, unofa} l::bracke   .ofasR<dynokee?turn None;
         Strofa}i,}  wra)   fields,
        ie::newGenSUncAfau }
 ed()
}
),
 .genetemsttrs
e, a_ return None;
           icsoun.e = ser_a   }
  l::Conta;}       }               .attrs
e, a   }               .attr :newGenSUncAfau }
 ed    (ty: s>mragmente)xs wi   }
                o lecte syn:aben ty, ounper_ty, uns sty           .attrs
e, a   }               .attr :newGenSUncAfau }
 edAssoc    (bindf snsertragmente)xs wi   }
                o lecte syn:aben &bindf s.ty, ounper_ty, uns sty           .attrs
e, a   }               .attr :newGenSUncAfau }
 edConst(_)
e, a   }               .attr|r :newGenSUncAfau }
 edAssocConst(_)
e, a   }               .attr|r :newGenSUncAfau }
 edConstraint(_)
e, a   }               .attr|rattrs
}syn:aben
;      }
                }               .attrs
}      }
r_ty, uns style,
      } emptye_b_o  w          e ty: att{nstruct_f icsco lecte syn:aben  ty.  em, ounper_ty, uns;         }o  w      Group(ty: att{nstruct_f icsco lecte syn:aben  ty.  em, ounper_ty, uns;         }o  w      Macro(ty: att{nstruct_f icsco lecte syn:aben_TreeN   f t(ty_mac    f totokeA    ounper_ty, uns;         }o  w      B   Fn(_)
e, a   }| }o  w      Now<[(_)
e, a   }| }o  w      TraitObject(_)
e, a   }| }o  w      Is. Trait(_)
e, a   }| }o  w      Inf<[(_)
e, a   }| }o  w      Verba:ab _   &Va; r_ty, unsattrs
}syn:a,ition<&co lecte syn:aben_TreeN   f t(t  f t: yn::DST> {
, oun: &
   (de_aliasewned()
}
),
 )bol,
  ppre    i
// `a   f tok synitert)x<dynowhile the e_as_twnse i
//.next(:  semptye_b   Str&tm.g_Vei, fixs wiyn::Dde_a   nby (op_defaop w()charontain'\''"&& op he cf sng tokee cf s::Joi   
> i,}  wra)   fields,
         fyn::Dde_a  
   .},
>   nse i
//.next(:  semptye_b         icsoun.e = serewned()
}
),
tragmente)xs wi   }
       apostroph
  op he n    .em,
   ,rs.rename_by_runta(Bo        }             e syn:aben
;      }
          as_getter(&ses wiyn::Dde_a  Group(groupnsertragmente)xs wi   }       f t   froup..T> {
  ;aults        ;
