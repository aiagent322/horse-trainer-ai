// SPDX-License-Identifier: Apache-2.0 OR MIT

#[derive(Clone, Copy)]
pub(crate) struct CpuInfo(u32);

impl CpuInfo {
    const INIT: u32 = 0;

    #[inline]
    fn set(&mut self, bit: u32) {
        self.0 = set(self.0, bit);
    }
    #[inline]
    fn test(self, bit: u32) -> bool {
        test(self.0, bit)
    }
}

#[inline]
fn set(x: u32, bit: u32) -> u32 {
    x | 1 << bit
}
#[inline]
fn test(x: u32, bit: u32) -> bool {
    x & (1 << bit) != 0
}

#[inline]
pub(crate) fn detect() -> CpuInfo {
    use core::sync::atomic::{AtomicU32, Ordering};

    static CACHE: AtomicU32 = AtomicU32::new(0);
    let mut info = CpuInfo(CACHE.load(Ordering::Relaxed));
    if info.0 != 0 {
        return info;
    }
    info.set(CpuInfo::INIT);
    // Note: detect_false cfg is intended to make it easy for portable-atomic developers to
    // test cases such as has_cmpxchg16b == false, has_lse == false,
    // __kuser_helper_version < 5, etc., and is not a public API.
    if !cfg!(portable_atomic_test_outline_atomics_detect_false) {
        _detect(&mut info);
    }
    CACHE.store(info.0, Ordering::Relaxed);
    info
}

#[cfg(target_arch = "aarch64")]
impl CpuInfo {
    /// Whether FEAT_LSE is available
    const HAS_LSE: u32 = 1;
    /// Whether FEAT_LSE2 is available
    #[cfg_attr(not(test), allow(dead_code))]
    const HAS_LSE2: u32 = 2;
    /// Whether FEAT_LSE128 is available
    // This is currently only used in tests.
    #[cfg(test)]
    const HAS_LSE128: u32 = 3;
    /// Whether FEAT_LRCPC3 is available
    // This is currently only used in tests.
    #[cfg(test)]
    const HAS_RCPC3: u32 = 4;

    #[cfg(any(test, not(any(target_feature = "lse", portable_atomic_target_feature = "lse"))))]
    #[inline]
    pub(crate) fn has_lse(self) -> bool {
        self.test(CpuInfo::HAS_LSE)
    }
    #[cfg_attr(not(test), allow(dead_code))]
    #[cfg(any(test, not(any(target_feature = "lse2", portable_atomic_target_feature = "lse2"))))]
    #[inline]
    pub(crate) fn has_lse2(self) -> bool {
        self.test(CpuInfo::HAS_LSE2)
    }
    #[cfg(test)]
    #[inline]
    pub(crate) fn has_lse128(self) -> bool {
        self.test(CpuInfo::HAS_LSE128)
    }
    #[cfg(test)]
    #[inline]
    pub(crate) fn has_rcpc3(self) -> bool {
        self.test(CpuInfo::HAS_RCPC3)
    }
}

#[cfg(target_arch = "x86_64")]
impl CpuInfo {
    /// Whether CMPXCHG16B is available
    const HAS_CMPXCHG16B: u32 = 1;
    /// Whether VMOVDQA is atomic
    #[cfg(target_feature = "sse")]
    const HAS_VMOVDQA_ATOMIC: u32 = 2;

    #[cfg(any(
        test,
        not(any(target_feature = "cmpxchg16b", portable_atomic_target_feature = "cmpxchg16b")),
    ))]
    #[inline]
    pub(crate) fn has_cmpxchg16b(self) -> bool {
        self.test(CpuInfo::HAS_CMPXCHG16B)
    }
    #[cfg(target_feature = "sse")]
    #[inline]
    pub(crate) fn has_vmovdqa_atomic(self) -> bool {
        self.test(CpuInfo::HAS_VMOVDQA_ATOMIC)
    }
}

#[cfg(target_arch = "powerpc64")]
impl CpuInfo {
    /// Whether lqarx and stqcx HAS_CMPXCHnfo::HAS_Vaot len,
                    narget_osSE2)
_: t<c_int, c_int> {
                #[allable on FreeBSe32 = 4;

  fb(super) const HWCAP_ATOM:rdc devels               le_atomic_target_feature = "cmpxch_ATOM:rdc devels             ))]
    #[inline]
    pub(crate) fn has_cmpxch_ATOM:rdcs_detec -> bool {
        self.test(CpuInfo::HAS_VMOVDQRD_ATOMICS);
    
}

// Basicaffi::c_* (except c_void) requires Rust 1.64, libc will soon require Rust 1.47
    #[any(target_os = " "aarch64", target_os = " "powerpc64"))]
      not(targetwindows    nodead_code))]
  any(l_case_types)]
      sts s::*;
      seate) fn hastType) reque::mem::s_void,
    // Note: c_{,u}ffi:mic{i,u}<c_uiry(l-16-bi = [1;imut or t/ https://github.com/freebsang/stdarcang/1c41041.7s/arillrary/mem:fi.rs.
 s#L1201
  60/ https:(16-bi = [1;imut or tntly only udove tis implem level)   seate) fn hastType) ffi::ei32;   seate) fn hastType) uffi::eu32// Note: c_{,u} ffi:mic{i,u}64_uiry(l-Windows 64-bi =_os = s, oqarxwis imic{i,u}<c/ https://github.com/freebsang/stdarcang/1c41041.7s/arillrary/mem:fi.rs.
 s#L1201
  76/ https:(Windows tly only udohave tis implem level poinlem level rent(targetwindows  )[cfg(target_pointer_width = "64")]
    #[testate) fn hastType)  ffi::g         not(target_os = "r_width = "64")]
     #[testate) fn hastType)  ffi::g 32// Nottarget_pointer_width = "64")]
    #[testate) fn hastType) = ffi::gu        not(target_os = "r_width = "64")]
     #[testate) fn hastType) = ffi::gu32// Note: c_;

   rrently only ualwaye] = un/ https://github.com/freebsang/stdarcang/1c41041.7s/arillrary/mem:fi.rs.
 s#L1201
 88[testate) fn hastType) ;

   r=] = un// Note: c_    rrenu8nux.t value)uirquivay(l-Apple/y(l-Windows ARM/P64")PC/RISC-V/s390x/Hexagse pos = s/ https:(does /d 9+ in/D
     /Net   /Open   /VxWorks/F hasia/QNX Neuand o/Horizon/AIX/z/OS)/ https://github.com/freebsang/stdarcang/1c41041.7s/arillrary/mem:fi.rs.
 s#L1201
  04/ https://github.com/freebsev/2dev/20projmmonc4104ev/2org-18.1.24evdb/source/Utof ra/A[1;Spec.cpp#L71c/ https:RISC-V://github.com/freebsaiscv-y(l-isasaiscv-st(-psabi-do/9888a7HEADsaiscv-cc.ado/#cc-tTyp-)] ueson for cs/ https:Hexagse //lists.llvm.org/pipermail/llvm-dev/2019-Jot(achion sJune/0916/21516a52Jot(achion -0001.pdf/ https:AIX://www.freebsibmreebs    /en/xl-c-aix0/sy1.2?topic=descri(nosta-q    s/ https:z/OS://www.freebsibmreebs    /en/zosJu.5.0?topic=spec Apacs-    acdth-tTyps/ https:(macOS:rently only uder Fed iApple pos = FFI bihis way, b levelis notWindows tly only udohave tis implem level)
cfg(not(target_os = "freebsmacos   #[testate) fn hastType)     r=] 8// Note: c_    rreni8l cores.Apple pos = s[cfg(target_os = "freebsmacos  #[testate) fn hastType)     r=]i8;// Static assertions for FFI biCstTyped
   ifor F#[cfg(test)]
    const HAS_RC) = || {
        use test_helper::{libc, sys};
        #[cfg(en = t = 26;
  0s_cmarch:tauxrawt;
        let mut ou_:e) uffi::e0s_cmarch:tauxrawt;
 u       let mut ou_:e)  0x80000s_cmarch:tauxrawt;
         #[cfg(t ou_:e) u 0x80000s_cmarch:tauxrawt;
 u        #[cfg(t ou_:e) ;

   r=]0s_cmPPC_FE;

    d_detech:tauxrawt;
 ;

   rrenun enoug   #[cfg(t ou_:e)     r=]0s_cmarch:tauxrawt;
     ;   #[cfg(t ou_:e)     r=]0s_cmaC_FE
     ;   #[     ow(
    clippy::alloc_instead_of_core,
    clippy::std_instead_of_alloc,
    clippy::std_instead_of_core,
    clippy::undocumented_unsafe_blocks,
    clippy::wildcard_imports
)]
#[cfg(test)]
mod tests {
   n.h
    use super::*;

    #[cfg(an    fn test_freebsbi ),
   (      let hwcap2fo);xInfo(CACHE.0     #[cfg(target_arch = "aarch64")]
        {
            // sta!(
     !xCpuInfo::HAS_VM
             assert!(len >=!xCpuInfo::HAS_VME)
    }         assert!(len >=!xCpuInfo::HAS_VME)
    2}         assert!(len >=!xCpuInfo::HAS_VME)
       }         assert!(len >=!xCpuInfo::HAS_VME)
 
    }         assertxpuInfo::INIT);
    // Not  assert!(len >=xCpuInfo::HAS_VM
             assert!(len >=!xCpuInfo::HAS_VME)
    }         assert!(len >=!xCpuInfo::HAS_VME)
    2}         assert!(len >=!xCpuInfo::HAS_VME)
       }         assert!(len >=!xCpuInfo::HAS_VME)
 
    }         assertxpuInfo::INIT);E);
        }
    sert!(len >=xCpuInfo::HAS_VM
             assert!(len >=xCpuInfo::HAS_VME)
    }         assert!(len >=!xCpuInfo::HAS_VME)
    2}         assert!(len >=!xCpuInfo::HAS_VME)
       }         assert!(len >=!xCpuInfo::HAS_VME)
 
    }         assertxpuInfo::INIT);E);
   2     }
    sert!(len >=xCpuInfo::HAS_VM
             assert!(len >=xCpuInfo::HAS_VME)
    }         assert!(len >=xCpuInfo::HAS_VME)
    2}         assert!(len >=!xCpuInfo::HAS_VME)
       }         assert!(len >=!xCpuInfo::HAS_VME)
 
    }         assertxpuInfo::INIT);E);
               }
    !(len >=xCpuInfo::HAS_VM
             assert!(len >=xCpuInfo::HAS_VME)
    }         assert!(len >=xCpuInfo::HAS_VME)
    2}         assert!(len >=xCpuInfo::HAS_VME)
       }         assert!(len >=!xCpuInfo::HAS_VME)
 
    }         assertxpuInfo::INIT);E);
;
            }
    !(len >=xCpuInfo::HAS_VM
             assert!(len >=xCpuInfo::HAS_VME)
    }         assert!(len >=xCpuInfo::HAS_VME)
    2}         assert!(len >=xCpuInfo::HAS_VME)
       }         assert!(len >=xCpuInfo::HAS_VME)
 
    }         as    #[cfg(target_arch = "powerp")]
impl C  {
            // sta!(
     !xCpuInfo::HAS_VM
             assert!(len >=!xCpuInfo::HAS_VME)
 G16B)
    }         assert!(len >=!xCpuInfo::HAS_VME)
 A_ATOMIC)
    }         assertxpuInfo::INIT);
    // Not  assert!(len >=xCpuInfo::HAS_VM
             assert!(len >=!xCpuInfo::HAS_VME)
 G16B)
    }         assert!(len >=!xCpuInfo::HAS_VME)
 A_ATOMIC)
    }         assertxpuInfo::INIT);E)
 G16B)
    }        }
    !(len >=xCpuInfo::HAS_VM
             assert!(len >=xCpuInfo::HAS_VME)
 G16B)
    }         assert!(len >=!xCpuInfo::HAS_VME)
 A_ATOMIC)
    }         assertxpuInfo::INIT);E)
 A_ATOMIC)
    }        }
    !(len >=xCpuInfo::HAS_VM
             assert!(len >=xCpuInfo::HAS_VME)
 G16B)
    }         assert!(len >=xCpuInfo::HAS_VME)
 A_ATOMIC)
    }         as    #[cfg(target_arch = "powerpc64")]
        {
            // sta!(
     !xCpuInfo::HAS_VM
             assert!(len >=!xCpuInfo::HAS_VME)
 RD_ATOMICS);
             assertxpuInfo::INIT);
    // Not  assert!(len >=xCpuInfo::HAS_VM
             assert!(len >=!xCpuInfo::HAS_VME)
 RD_ATOMICS);
             assertxpuInfo::INIT);ADWORD_ATOMICS);
        }
        !(len >=xCpuInfo::HAS_VM
             assert!(len >=xCpuInfo::HAS_VME)
 RD_ATOMICS);
             as}

    #[allow(    fn test_fn!(
 re = "cms       use c_typearch::       for auxmt::Writes_cm               i_VM{bit: uWrite},       static_aRelaxeSaRela,       st          lecap2fo);e = "cmswerSaRelaxe;
           asmacro_rules!fn!(
 re = "cm         // sta($*consexpr, $ennougdsexpr $(,)?,
   {            let r: i64_werwrite    e = "cms, "   }: en);
$*con, $ennougd         }
     }        as    #[cfg(target_arch = "powerp4")]
        {
            // stae = "cms.push__aR("run-tions\n              asn!(
 re = "cm={}"ortab() -> CpCpuInfo::HAS_VME)
    }         assertn!(
 re = "cm={}"or2tab() -> CpCpuInfo::HAS_VME)
    2}         assertn!(
 re = "cm={}"or   tab() -> CpCpuInfo::HAS_VME)
       }         assertn!(
 re = "cm={}self)tab() -> CpCpuInfo::HAS_VME)
 
    }         asserte = "cms.push__aR("ibleile-tions\n              asn!(
 re = "cm={           "arch={"orta           core::srtabrget_feature = "lse", portable_atomic_target_feature = "lse"))))]
          );
            assertn!(
 re = "cm={           "arch={"or2ta           core::srtabrget_feature = "lse", porrtable_atomic_target_feature = "lse2"))))]
  ,       );
        }
    };
}
 cfg(target_arch = "powerp")]
impl C  {
            // stae = "cms.push__aR("run-tions\n              asn!(
 re = "cm={}g16b", portab() -> CpCpuInfo::HAS_VME)
 G16B)
    }         assertn!(
 re = "cm={}a_atomic develtab() -> CpCpuInfo::HAS_VME)
 A_ATOMIC)
    }         asserte = "cms.push__aR("ibleile-tions\n              asn!(
 re = "cm={           "arch={g16b", porta           core::srtabrget               return_feature = "cmpxchg16b", porta               ptr::nue_atomic_target_feature = "cmpxchg16b")),
              )?;
    ,       );
        }
    };
}
 cfg(target_arch = "powerpc64")]
        {
            // stae = "cms.push__aR("run-tions\n              asn!(
 re = "cm={}_ATOM:rdc devels  b() -> CpCpuInfo::HAS_VME)
 RD_ATOMICS);
             asserte = "cms.push__aR("ibleile-tions\n              asn!(
 re = "cm={           "arch={_ATOM:rdc devels               re::srtabrget               return_feature = "cmpxch_ATOM:rdc devels               re::    le_atomic_target_feature = "cmpxch_ATOM:rdc devels             )?;
    ,       );
        }
    };
}
 cfg( i64arctual= i_VMarc -22);       lecap2fo);arctual= arctua.
   2);       lecap2_l= arctua.write_i::AT = "cms.as()).unwra;

    #[allow(rget_arch = "powerp")]
impl C  {
w(    fn tesattr(not(tele_atomic_test_outline_atomics_detect_false) {
  , ignore)fn test_freebs() -> Cpu        //ifb() -> CpCpxchg16b(self) )         // sta!(
     () -> CpCpuInfo::HAS_VME)
 G16B)
    }         as {
                  !(len >=!() -> CpCpuInfo::HAS_VME)
 G16B)
    }         as        //ifb() -> CpCpxcha_atomic(self) )         // sta!(
     () -> CpCpuInfo::HAS_VME)
 A_ATOMIC)
    }         as {
                  !(len >=!() -> CpCpuInfo::HAS_VME)
 A_ATOMIC)
    }         as    #[}
cfg(target_arch = "powerp4")]
        {
w(    fn tesattr(not(tele_atomic_test_outline_atomics_detect_false) {
  , ignore)fn test_freebs() -> Cpu        //d = groc_cpu CpuInfelper::{libc,cpu Cpu::ProcCpu Cpu::;
           asifb() -> CpCpxchlf) )         // sta!(
     () -> CpCpuInfo::HAS_VME)
    }         assertifbd = Ok(groc_cpu Cpu {
 groc_cpu CpuI{           assert_eq!(
!(groc_cpu Cpu.
           }
        }
     {
                  !(len >=!() -> CpCpuInfo::HAS_VME)
    }         assertifbd = Ok(groc_cpu Cpu {
 groc_cpu CpuI{           assert_eq!(
!(!groc_cpu Cpu.
           }
        }
            asifb() -> CpCpxchlf)2 )         // sta!(
     () -> CpCpuInfo::HAS_VME)
    }         assert!(
     () -> CpCpuInfo::HAS_VME)
    2}         assertifbd = Ok(elper::{libc,cpu Cpu::ProcCpu Cpu { lf)2: Some(lf)2), .. } {
 groc_cpu CpuI{           assert_eq!(
!(lf)2)        }
        }
     {
                  !(len >=!() -> CpCpuInfo::HAS_VME)
    2}         assertifbd = Ok(elper::{libc,cpu Cpu::ProcCpu Cpu { lf)2: Some(lf)2), .. } {
 groc_cpu CpuI{           assert_eq!(
!(!lf)2)        }
        }
            asifb() -> CpCpxchlf)lf) )         // sta!(
     () -> CpCpuInfo::HAS_VME)
    }         assert!(
     () -> CpCpuInfo::HAS_VME)
    2}         assert!(
     () -> CpCpuInfo::HAS_VME)
       }         as {
                  !(len >=!() -> CpCpuInfo::HAS_VME)
       }         as        asifb() -> CpCpxchself) )         // sta!(
     () -> CpCpuInfo::HAS_VME)
 
    }         as {
                  !(len >=!() -> CpCpuInfo::HAS_VME)
 
    }         as    #[}
cfg(target_arch = "powerpc64")]
        {
w(    fn tesattr(not(tele_atomic_test_outline_atomics_detect_false) {
  , ignore)fn test_freebs() -> Cpu        //d = groc_cpu CpuInfelper::{libc,cpu Cpu::ProcCpu Cpu::;
           asifb() -> CpCpxch_ATOM:rdcs_detec )         // sta!(
     () -> CpCpuInfo::HAS_VME)
 RD_ATOMICS);
             assertifbd = Ok(groc_cpu Cpu {
 groc_cpu CpuI{           assert_eq!(
!(groc_cpu Cpu.c64")8)        }
        }
     {
                  !(len >=!() -> CpCpuInfo::HAS_VME)
 RD_ATOMICS);
             assertifbd = Ok(groc_cpu Cpu {
 groc_cpu CpuI{           assert_eq!(
!(!groc_cpu Cpu.c64")8)        }
        }
     
}
