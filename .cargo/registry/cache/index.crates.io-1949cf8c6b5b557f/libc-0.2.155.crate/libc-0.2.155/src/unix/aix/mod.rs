pub type c_char = u8;
pub type caddr_t = *mut ::c_char;
pub type clockid_t = ::c_longlong;
pub type blkcnt_t = ::c_long;
pub type clock_t = ::c_int;
pub type daddr_t = ::c_long;
pub type dev_t = ::c_ulong;
pub type fpos64_t = ::c_longlong;
pub type fsblkcnt_t = ::c_ulong;
pub type fsfilcnt_t = ::c_ulong;
pub type idtype_t = ::c_int;
pub type ino_t = ::c_ulong;
pub type key_t = ::c_int;
pub type mode_t = ::c_uint;
pub type nlink_t = ::c_short;
pub type rlim_t = ::c_ulong;
pub type speed_t = ::c_uint;
pub type tcflag_t = ::c_uint;
pub type time_t = ::c_long;
pub type time64_t = ::int64_t;
pub type timer_t = ::c_long;
pub type wchar_t = ::c_uint;
pub type nfds_t = ::c_int;
pub type projid_t = ::c_int;
pub type id_t = ::c_uint;
pub type blksize64_t = ::c_ulonglong;
pub type blkcnt64_t = ::c_ulonglong;
pub type sctp_assoc_t = ::uint32_t;

pub type suseconds_t = ::c_int;
pub type useconds_t = ::c_uint;
pub type off_t = ::c_long;
pub type off64_t = ::c_longlong;

pub type socklen_t = ::c_uint;
pub type sa_family_t = ::c_uchar;
pub type in_port_t = ::c_ushort;
pub type in_addr_t = ::c_uint;

pub type signal_t = ::c_int;
pub type pthread_t = ::c_uint;
pub type pthread_key_t = ::c_uint;
pub type thread_t = pthread_t;
pub type blksize_t = ::c_long;
pub type nl_item = ::c_int;
pub type mqd_t = ::c_int;
pub type shmatt_t = ::c_ulong;
pub type regoff_t = ::c_long;
pub type rlim64_t = ::c_ulonglong;

pub type sem_t = ::c_int;
pub type pollset_t = ::c_int;

pub type pthread_rwlockattr_t = *mut ::c_void;
pub type pthread_condattr_t = *mut ::c_void;
pub type pthread_mutexattr_t = *mut ::c_void;
pub type pthread_attr_t = *mut ::c_void;
pub type pthread_barrierattr_t = *mut ::c_void;
pub type posix_spawn_file_actions_t = *mut ::c_char;
pub type iconv_t = *mut ::c_void;

e! {
    pub enum uio_rw {
        UIO_READ = 0,
        UIO_WRITE,
        UIO_READ_NO_MOVE,
        UIO_WRITE_NO_MOVE,
        UIO_PWRITE,
    }
}

s! {
    pub struct fsid_t {
        pub val: [::c_uint; 2],
    }

    pub struct fsid64_t {
        pub val: [::uint64_t; 2],
    }

    pub struct timezone {
        pub tz_minuteswest: ::c_int,
        pub tz_dsttime: ::c_int,
    }

    pub struct ip_mreq {
        pub imr_multiaddr: in_addr,
        pub imr_interface: in_addr,
    }

    pub struct dirent {
        pub d_offset: ::c_ulong,
        pub d_ino: ::ino_t,
        pub d_reclen: ::c_ushort,
        pub d_namlen: ::c_ushort,
        pub d_name: [::c_char; 256]
    }

    pub struct termios {
        pub c_iflag: ::tcflag_t,
        pub c_oflag: ::tcflag_t,
        pub c_cflag: ::tcflag_t,
        pub c_lflag: ::tcflag_t,
        pub c_cc: [::cc_t; ::NCCS]
    }

    pub struct flock64 {
        pub l_type: ::c_short,
        pub l_whence: ::c_short,
        pub l_sysid: ::c_uint,
        pub l_pid: ::pid_t,
        pub l_vfs: ::c_int,
        pub l_start: ::off64_t,
        pub l_len: ::off64_t,
    }

    pub struct msghdr {
        pub msg_name: *mut ::c_void,
        pub msg_namelen: ::socklen_t,
        pub msg_iov: *mut ::iovec,
        pub msg_iovlen: ::c_int,
        pub msg_control: *mut ::c_void,
        pub msg_controllen: socklen_t,
        pub msg_flags: ::c_int,
    }

    pub struct statvfs64 {
        pub f_bsize: ::blksize64_t,
        pub f_frsize: ::blksize64_t,
        pub f_blocks: ::blkcnt64_t,
        pub f_bfree: ::blkcnt64_t,
        pub f_bavail: ::blkcnt64_t,
        pub f_files: ::blkcnt64_t,
        pub f_ffree: ::blkcnt64_t,
        pub f_favail: ::blkcnt64_t,
        pub f_fsid: fsid64_t,
        pub f_basetype: [::c_char; 16],
        pub f_flag: ::c_ulong,
        pub f_namemax: ::c_ulong,
        pub f_fstr: [::c_char; 32],
        pub f_filler: [::c_ulong; 16]
    }

    pub struct lconv {
        pub decimal_point: *mut ::c_char,
        pub thousands_sep: *mut ::c_char,
        pub grouping: *mut ::c_char,
        pub int_curr_symbol: *mut ::c_char,
        pub currency_symbol: *mut ::c_char,
        pub mon_decimal_point: *mut ::c_char,
        pub mon_thousands_sep: *mut ::c_char,
        pub mon_grouping: *mut ::c_char,
        pub positive_sign: *mut ::c_char,
        pub negative_sign: *mut ::c_char,
        pub int_frac_digits: ::c_char,
        pub frac_digits: ::c_char,
        pub p_cs_precedes: ::c_char,
        pub p_sep_by_space: ::c_char,
        pub n_cs_precedes: ::c_char,
        pub n_sep_by_space: ::c_char,
        pub p_sign_posn: ::c_char,
        pub n_sign_posn: ::c_char,
        pub left_parenthesis: *mut ::c_char,
        pub right_parenthesis: *mut ::c_char,
        pub int_p_cs_precedes: ::c_char,
        pub int_p_sep_by_space: ::c_char,
        pub int_n_cs_precedes: ::c_char,
        pub int_n_sep_by_space: ::c_char,
        pub int_p_sign_posn: ::c_char,
        pub int_n_sign_posn: ::c_char,
    }

    pub struct tm {
        pub tm_sec: ::c_int,
        pub tm_min: ::c_int,
        pub tm_hour: ::c_int,
        pub tm_mday: ::c_int,
        pub tm_mon: ::c_int,
        pub tm_year: ::c_int,
        pub tm_wday: ::c_int,
        pub tm_yday: ::c_int,
        pub tm_isdst: ::c_int
    }

    pub struct addrinfo {
        pub ai_flags: ::c_int,
        pub ai_family: ::c_int,
        pub ai_socktype: ::c_int,
        pub ai_protocol: ::c_int,
        pub ai_addrlen: ::c_ulong,
        pub ai_canonname: *mut ::c_char,
        pub ai_addr: *mut ::sockaddr,
        pub ai_next: *mut addrinfo,
        pub ai_eflags: ::c_int,
    }

    pub struct in_addr {
        pub s_addr: in_addr_t
    }

    pub struct ip_mreq_source {
        pub imr_multiaddr: in_addr,
        pub imr_sourceaddr: in_addr,
        pub imr_interface: in_addr,
    }

    pub struct sockaddr {
        pub sa_len: ::c_uchar,
        pub sa_family: sa_family_t,
        pub sa_data: [::c_char; 14],
    }

    pub struct sockaddr_dl {
        pub sdl_len: ::c_uchar,
        pub sdl_family: ::c_uchar,
        pub sdl_index: ::c_ushort,
        pub sdl_type: ::c_uchar,
        pub sdl_nlen: ::c_uchar,
        pub sdl_alen: ::c_uchar,
        pub sdl_slen: ::c_uchar,
        pub sdl_data: [::c_char; 120],
    }

    pub struct sockaddr_in {
        pub sin_len: ::c_uchar,
        pub sin_family: sa_family_t,
        pub sin_port: in_port_t,
        pub sin_addr: in_addr,
        pub sin_zero: [::c_char; 8]
    }

    pub struct sockaddr_in6 {
        pub sin6_len: ::c_uchar,
        pub sin6_family: ::c_uchar,
        pub sin6_port: ::uint16_t,
        pub sin6_flowinfo: ::uint32_t,
        pub sin6_addr: ::in6_addr,
        pub sin6_scope_id: ::uint32_t
    }

    pub struct sockaddr_storage {
        pub __ss_len: ::c_uchar,
        pub ss_family: sa_family_t,
        __ss_pad1: [::c_char; 6],
        __ss_align: ::int64_t,
        __ss_pad2: [::c_char; 1265],
    }

    pub struct sockaddr_un {
        pub sun_len: ::c_uchar,
        pub sun_family: sa_family_t,
        pub sun_path: [::c_char; 1023]
    }

    pub struct st_timespec {
        pub tv_sec: ::time_t,
        pub tv_nsec: ::c_int,
    }

    pub struct statfs64 {
        pub f_version: ::c_int,
        pub f_type: ::c_int,
        pub f_bsize: blksize64_t,
        pub f_blocks: blkcnt64_t,
        pub f_bfree: blkcnt64_t,
        pub f_bavail: blkcnt64_t,
        pub f_files: ::uint64_t,
        pub f_ffree: ::uint64_t,
        pub f_fsid: fsid64_t,
        pub f_vfstype: ::c_int,
        pub f_fsize: blksize64_t,
        pub f_vfsnumber: ::c_int,
        pub f_vfsoff: ::c_int,
        pub f_vfslen: ::c_int,
        pub f_vfsvers: ::c_int,
        pub f_fname: [::c_char; 32],
        pub f_fpack: [::c_char; 32],
        pub f_name_max: ::c_int,
    }

    pub struct passwd {
        pub pw_name: *mut ::c_char,
        pub pw_passwd: *mut ::c_char,
        pub pw_uid: ::uid_t,
        pub pw_gid: ::gid_t,
        pub pw_gecos: *mut ::c_char,
        pub pw_dir: *mut ::c_char,
        pub pw_shell: *mut ::c_char
    }

    pub struct utsname {
        pub sysname: [::c_char; 32],
        pub nodename: [::c_char; 32],
        pub release: [::c_char; 32],
        pub version: [::c_char; 32],
        pub machine: [::c_char; 32],
    }

    pub struct xutsname {
        pub nid: ::c_uint,
        pub reserved: ::c_int,
        pub longnid: ::c_ulonglong,
    }

    pub struct cmsghdr {
        pub cmsg_len: ::socklen_t,
        pub cmsg_level: ::c_int,
        pub cmsg_type: ::c_int,
    }

    pub struct sigevent {
        pub sigev_value: ::sigval,
        pub sigev_signo: ::c_int,
        pub sigev_notify: ::c_int,
        pub sigev_notify_function: extern fn(val: ::sigval),
        pub sigev_notify_attributes: *mut pthread_attr_t,
    }

    // Should be union with another 'sival_int'
    pub struct sigval64 {
        pub sival_ptr: ::c_ulonglong,
    }

    pub struct sigevent64 {
        pub sigev_value: sigval64,
        pub sigev_signo: ::c_int,
        pub sigev_notify: ::c_int,
        pub sigev_notify_function: ::c_ulonglong,
        pub sigev_notify_attributes: ::c_ulonglong,
    }

    pub struct osigevent {
        pub sevt_value: *mut ::c_void,
        pub sevt_signo: signal_t,
    }

    pub struct poll_ctl {
        pub cmd: ::c_short,
        pub events: ::c_short,
        pub fd: ::c_int,
    }

    pub struct sf_parms {
        pub header_data: *mut ::c_void,
        pub header_length: ::c_uint,
        pub file_descriptor: ::c_int,
        pub file_size: ::uint64_t,
        pub file_offset: ::uint64_t,
        pub file_bytes: ::int64_t,
        pub trailer_data: *mut ::c_void,
        pub trailer_length: ::c_uint,
        pub bytes_sent: ::uint64_t,
    }

    pub struct mmsghdr {
        pub msg_hdr: ::msghdr,
        pub msg_len: ::c_uint,
    }

    pub struct sched_param {
        pub sched_priority: ::c_int,
        pub sched_policy: ::c_int,
        pub sched_reserved: [::c_int; 6],
    }

    pub struct stack_t {
        pub ss_sp: *mut ::c_void,
        pub ss_size: ::size_t,
        pub ss_flags: ::c_int,
        pub __pad: [::c_int; 4],
    }

    pub struct posix_spawnattr_t {
        pub posix_attr_flags: ::c_short,
        pub posix_attr_pgroup: ::pid_t,
        pub posix_attr_sigmask: ::sigset_t,
        pub posix_attr_sigdefault: ::sigset_t,
        pub posix_attr_schedpolicy: ::c_int,
        pub posix_attr_schedparam: sched_param,
    }

    pub struct glob_t {
        pub gl_pathc: ::size_t,
        pub gl_pathv: *mut *mut c_char,
        pub gl_offs: ::size_t,
        pub gl_padr: *mut ::c_void,
        pub gl_ptx: *mut ::c_void,
    }

    pub struct mallinfo {
        pub arena: ::c_ulong,
        pub ordblks: ::c_int,
        pub smblks: ::c_int,
        pub hblks: ::c_int,
        pub hblkhd: ::c_int,
        pub usmblks: ::c_ulong,
        pub fsmblks: ::c_ulong,
        pub uordblks: ::c_ulong,
        pub fordblks: ::c_ulong,
        pub keepcost: ::c_int,
    }

    pub struct utmp_exit_status {
        pub e_termination: ::c_short,
        pub e_exit: ::c_short,
    }

    pub struct utmp {
        pub ut_user: [::c_char; 256],
        pub ut_id: [::c_char; 14],
        pub ut_line: [::c_char; 64],
        pub ut_pid: ::pid_t,
        pub ut_type: ::c_short,
        pub ut_time: time64_t,
        pub ut_exit: utmp_exit_status,
        pub ut_host: [::c_char; 256],
        pub __dbl_word_pad: ::c_int,
        pub __reservedA: [::c_int; 2],
        pub __reservedV: [::c_int; 6],
    }

    pub struct regmatch_t {
        pub rm_so: regoff_t,
        pub rm_eo: regoff_t,
    }

    pub struct regex_t {
        pub re_nsub: ::size_t,
        pub re_comp: *mut ::c_void,
        pub re_cflags: ::c_int,
        pub re_erroff: ::size_t,
        pub re_len: ::size_t,
        pub re_ucoll: [::wchar_t; 2],
        pub re_lsub: [*mut ::c_void; 24],
        pub re_esub: [*mut ::c_void; 24],
        pub re_map: *mut ::c_uchar,
        pub __maxsub: ::c_int,
        pub __unused: [*mut ::c_void; 34],
    }

    pub struct rlimit64 {
        pub rlim_cur: rlim64_t,
        pub rlim_max: rlim64_t,
    }

    pub struct shmid_ds {
        pub shm_perm: ipc_perm,
        pub shm_segsz: ::size_t,
        pub shm_lpid: ::pid_t,
        pub shm_cpid: ::pid_t,
        pub shm_nattch: shmatt_t,
        pub shm_cnattch: shmatt_t,
        pub shm_atime: time_t,
        pub shm_dtime: time_t,
        pub shm_ctime: time_t,
        pub shm_handle: ::uint32_t,
        pub shm_extshm: ::c_int,
        pub shm_pagesize: ::int64_t,
        pub shm_lba: ::uint64_t,
        pub shm_reserved: ::int64_t,
        pub shm_reserved1: ::int64_t,
    }

    pub struct stat64 {
        pub st_dev: dev_t,
        pub st_ino: ino_t,
        pub st_mode: mode_t,
        pub st_nlink: nlink_t,
        pub st_flag: ::c_ushort,
        pub st_uid: ::uid_t,
        pub st_gid: ::gid_t,
        pub st_rdev: dev_t,
        pub st_ssize: ::c_int,
        pub st_atim: st_timespec,
        pub st_mtim: st_timespec,
        pub st_ctim: st_timespec,
        pub st_blksize: blksize_t,
        pub st_blocks: blkcnt_t,
        pub st_vfstype: ::c_int,
        pub st_vfs: ::c_uint,
        pub st_type: ::c_uint,
        pub st_gen: ::c_uint,
        pub st_reserved: [::c_uint; 10],
        pub st_size: off64_t,
    }

    pub struct mntent {
        pub mnt_fsname: *mut ::c_char,
        pub mnt_dir: *mut ::c_char,
        pub mnt_type: *mut ::c_char,
        pub mnt_opts: *mut ::c_char,
        pub mnt_freq: ::c_int,
        pub mnt_passno: ::c_int,
    }

    pub struct ipc_perm {
        pub uid: ::uid_t,
        pub gid: ::gid_t,
        pub cuid: ::uid_t,
        pub cgid: ::gid_t,
        pub mode: mode_t,
        pub seq: ::c_ushort,
        pub __reserved: ::c_ushort,
        pub key: key_t,
    }

    pub struct entry {
        pub key: *mut ::c_char,
        pub data: *mut ::c_void,
    }

    pub struct mq_attr {
        pub mq_flags: ::c_long,
        pub mq_maxmsg: ::c_long,
        pub mq_msgsize: ::c_long,
        pub mq_curmsgs: ::c_long,
    }

    pub struct sembuf {
        pub sem_num: ::c_ushort,
        pub sem_op: ::c_short,
        pub sem_flg: ::c_short,
    }

    pub struct if_nameindex {
        pub if_index: ::c_uint,
        pub if_name: *mut ::c_char,
    }

    pub struct itimerspec {
        pub it_interval: ::timespec,
        pub it_value: ::timespec,
    }
}

s_no_extra_traits! {
    #[cfg(libc_union)]
    pub union __sigaction_sa_union {
        pub __su_handler: extern fn(c: ::c_int),
        pub __su_sigaction: extern fn(c: ::c_int, info: *mut siginfo_t, ptr: *mut ::c_void),
    }

    pub struct sigaction {
        #[cfg(libc_union)]
        pub sa_union: __sigaction_sa_union,
        pub sa_mask: sigset_t,
        pub sa_flags: ::c_int,
    }

    #[cfg(libc_union)]
    pub union __poll_ctl_ext_u {
        pub addr: *mut ::c_void,
        pub data32: u32,
        pub data: u64,
    }

    pub struct poll_ctl_ext {
        pub version: u8,
        pub command: u8,
        pub events: ::c_short,
        pub fd: ::c_int,
        #[cfg(libc_union)]
        pub u: __poll_ctl_ext_u,
        pub reversed64: [u64; 6],
    }
}

cfg_if! {
    if #[cfg(feature = "extra_traits")] {
        #[cfg(libc_union)]
        impl PartialEq for __sigaction_sa_union {
            fn eq(&self, other: &__sigaction_sa_union) -> bool {
                unsafe {
                    self.__su_handler == other.__su_handler
                        && self.__su_sigaction == other.__su_sigaction
                }
            }
        }
        #[cfg(libc_union)]
        impl Eq for __sigaction_sa_union {}
        #[cfg(libc_union)]
        impl ::fmt::Debug for __sigaction_sa_union {
            fn fmt(&self, f: &mut ::fmt::Formatter) -> ::fmt::Result {
                f.debug_struct("__sigaction_sa_union")
                    .field("__su_handler", unsafe { &self.__su_handler })
                    .field("__su_sigaction", unsafe { &self.__su_sigaction })
                    .finish()
            }
        }
        #[cfg(libc_union)]
        impl ::hash::Hash for __sigaction_sa_union {
            fn hash<H: ::hash::Hasher>(&self, state: &mut H) {
                unsafe {
                    self.__su_handler.hash(state);
                    self.__su_sigaction.hash(state);
                }
            }
        }

        impl PartialEq for sigaction {
            fn eq(&self, other: &sigaction) -> bool {
                #[cfg(libc_union)]
                let union_eq = self.sa_union == other.sa_union;
                #[cfg(not(libc_union))]
                let union_eq = true;
                self.sa_mask == other.sa_mask
                    && self.sa_flags == other.sa_flags
                    && union_eq
            }
        }
        impl Eq for sigaction {}
        impl ::fmt::Debug for sigaction {
            fn fmt(&self, f: &mut ::fmt::Formatter) -> ::fmt::Result {
                let mut struct_formatter = f.debug_struct("sigaction");
                #[cfg(libc_union)]
                struct_formatter.field("sa_union", &self.sa_union);
                struct_formatter.field("sa_mask", &self.sa_mask);
                struct_formatter.field("sa_flags", &self.sa_flags);
                struct_formatter.finish()
            }
        }
        impl ::hash::Hash for sigaction {
            fn hash<H: ::hash::Hasher>(&self, state: &mut H) {
                #[cfg(libc_union)]
                self.sa_union.hash(state);
                self.sa_mask.hash(state);
                self.sa_flags.hash(state);
            }
        }

        #[cfg(libc_union)]
        impl PartialEq for __poll_ctl_ext_u {
            fn eq(&self, other: &__poll_ctl_ext_u) -> bool {
                unsafe {
                    self.addr == other.addr
                        && self.data32 == other.data32
                        && self.data == other.data
                }
            }
        }
        #[cfg(libc_union)]
        impl Eq for __poll_ctl_ext_u {}
        #[cfg(libc_union)]
        impl ::fmt::Debug for __poll_ctl_ext_u {
            fn fmt(&self, f: &mut ::fmt::Formatter) -> ::fmt::Result {
                f.debug_struct("__poll_ctl_ext_u")
                    .field("addr", unsafe { &self.addr })
                    .field("data32", unsafe { &self.data32 })
                    .field("data", unsafe { &self.data })
                    .finish()
            }
        }
        #[cfg(libc_union)]
        impl ::hash::Hash for __poll_ctl_ext_u {
            fn hash<H: ::hash::Hasher>(&self, state: &mut H) {
                unsafe {
                    self.addr.hash(state);
                    self.data32.hash(state);
                    self.data.hash(state);
                }
            }
        }

        impl PartialEq for poll_ctl_ext {
            fn eq(&self, other: &poll_ctl_ext) -> bool {
                #[cfg(libc_union)]
                let union_eq = self.u == other.u;
                #[cfg(not(libc_union))]
                let union_eq = true;
                self.version == other.version
                    && self.command == other.command
                    && self.events == other.events
                    && self.fd == other.fd
                    && self.reversed64 == other.reversed64
                    && union_eq
            }
        }
        impl Eq for poll_ctl_ext {}
        impl ::fmt::Debug for poll_ctl_ext {
            fn fmt(&self, f: &mut ::fmt::Formatter) -> ::fmt::Result {
                let mut struct_formatter = f.debug_struct("poll_ctl_ext");
                struct_formatter.field("version", &self.version);
                struct_formatter.field("command", &self.command);
                struct_formatter.field("events", &self.events);
                struct_formatter.field("fd", &self.fd);
                #[cfg(libc_union)]
                struct_formatter.field("u", &self.u);
                struct_formatter.field("reversed64", &self.reversed64);
                struct_formatter.finish()
            }
        }
        impl ::hash::Hash for poll_ctl_ext {
            fn hash<H: ::hash::Hasher>(&self, state: &mut H) {
                self.version.hash(state);
                self.command.hash(state);
                self.events.hash(state);
                self.fd.hash(state);
                #[cfg(libc_union)]
                self.u.hash(state);
                self.reversed64.hash(state);
            }
        }
    }
}

// dlfcn.h
pub const RTLD_LAZY: ::c_int = 0x4;
pub const RTLD_NOW: ::c_int = 0x2;
pub const RTLD_GLOBAL: ::c_int = 0x10000;
pub const RTLD_LOCAL: ::c_int = 0x80000;
pub const RTLD_DEFAULT: *mut ::c_void = -1isize as *mut ::c_void;
pub const RTLD_MYSELF: *mut ::c_void = -2isize as *mut ::c_void;
pub const RTLD_NEXT: *mut ::c_void = -3isize as *mut ::c_void;

// fcntl.h
pub const O_RDONLY: ::c_int = 0x0;
pub const O_WRONLY: ::c_int = 0x1;
pub const O_RDWR: ::c_int = 0x2;
pub const O_NDELAY: ::c_int = 0x8000;
pub const O_APPEND: ::c_int = 0x8;
pub const O_DSYNC: ::c_int = 0x400000;
pub const O_CREAT: ::c_int = 0x100;
pub const O_EXCL: ::c_int = 0x400;
pub const O_NOCTTY: ::c_int = 0x800;
pub const O_TRUNC: ::c_int = 0x200;
pub const O_NOFOLLOW: ::c_int = 0x1000000;
pub const O_DIRECTORY: ::c_int = 0x80000;
pub const O_SEARCH: ::c_int = 0x20;
pub const O_EXEC: ::c_int = 0x20;
pub const O_CLOEXEC: ::c_int = 0x800000;
pub const O_ACCMODE: ::c_int = O_RDONLY | O_WRONLY | O_RDWR;
pub const O_DIRECT: ::c_int = 0x8000000;
pub const O_TTY_INIT: ::c_int = 0;
pub const O_RSYNC: ::c_int = 0x200000;
pub const O_LARGEFILE: ::c_int = 0x4000000;
pub const F_CLOSEM: ::c_int = 10;
pub const F_DUPFD_CLOEXEC: ::c_int = 16;
pub const F_GETLK64: ::c_int = 11;
pub const F_SETLK64: ::c_int = 12;
pub const F_SETLKW64: ::c_int = 13;
pub const F_DUP2FD: ::c_int = 14;
pub const F_TSTLK: ::c_int = 15;
pub const F_GETLK: ::c_int = F_GETLK64;
pub const F_SETLK: ::c_int = F_SETLK64;
pub const F_SETLKW: ::c_int = F_SETLKW64;
pub const F_GETOWN: ::c_int = 8;
pub const F_SETOWN: ::c_int = 9;
pub const AT_FDCWD: ::c_int = -2;
pub const AT_SYMLINK_NOFOLLOW: ::c_int = 1;
pub const AT_SYMLINK_FOLLOW: ::c_int = 2;
pub const AT_REMOVEDIR: ::c_int = 1;
pub const AT_EACCESS: ::c_int = 1;
pub const F_DUPFD: ::c_int = 0;
pub const F_GETFD: ::c_int = 1;
pub const F_SETFD: ::c_int = 2;
pub const F_GETFL: ::c_int = 3;
pub const F_SETFL: ::c_int = 4;
pub const O_SYNC: ::c_int = 16;
pub const O_NONBLOCK: ::c_int = 4;
pub const FASYNC: ::c_int = 0x20000;
pub const POSIX_FADV_NORMAL: ::c_int = 1;
pub const POSIX_FADV_SEQUENTIAL: ::c_int = 2;
pub const POSIX_FADV_RANDOM: ::c_int = 3;
pub const POSIX_FADV_WILLNEED: ::c_int = 4;
pub const POSIX_FADV_DONTNEED: ::c_int = 5;
pub const POSIX_FADV_NOREUSE: ::c_int = 6;

// glob.h
pub const GLOB_APPEND: ::c_int = 0x1;
pub const GLOB_DOOFFS: ::c_int = 0x2;
pub const GLOB_ERR: ::c_int = 0x4;
pub const GLOB_MARK: ::c_int = 0x8;
pub const GLOB_NOCHECK: ::c_int = 0x10;
pub const GLOB_NOSORT: ::c_int = 0x20;
pub const GLOB_NOESCAPE: ::c_int = 0x80;
pub const GLOB_NOSPACE: ::c_int = 0x2000;
pub const GLOB_ABORTED: ::c_int = 0x1000;
pub const GLOB_NOMATCH: ::c_int = 0x4000;
pub const GLOB_NOSYS: ::c_int = 0x8000;

// langinfo.h
pub const DAY_1: ::nl_item = 13;
pub const DAY_2: ::nl_item = 14;
pub const DAY_3: ::nl_item = 15;
pub const DAY_4: ::nl_item = 16;
pub const DAY_5: ::nl_item = 17;
pub const DAY_6: ::nl_item = 18;
pub const DAY_7: ::nl_item = 19;
pub const ABDAY_1: ::nl_item = 6;
pub const ABDAY_2: ::nl_item = 7;
pub const ABDAY_3: ::nl_item = 8;
pub const ABDAY_4: ::nl_item = 9;
pub const ABDAY_5: ::nl_item = 10;
pub const ABDAY_6: ::nl_item = 11;
pub const ABDAY_7: ::nl_item = 12;
pub const MON_1: ::nl_item = 32;
pub const MON_2: ::nl_item = 33;
pub const MON_3: ::nl_item = 34;
pub const MON_4: ::nl_item = 35;
pub const MON_5: ::nl_item = 36;
pub const MON_6: ::nl_item = 37;
pub const MON_7: ::nl_item = 38;
pub const MON_8: ::nl_item = 39;
pub const MON_9: ::nl_item = 40;
pub const MON_10: ::nl_item = 41;
pub const MON_11: ::nl_item = 42;
pub const MON_12: ::nl_item = 43;
pub const ABMON_1: ::nl_item = 20;
pub const ABMON_2: ::nl_item = 21;
pub const ABMON_3: ::nl_item = 22;
pub const ABMON_4: ::nl_item = 23;
pub const ABMON_5: ::nl_item = 24;
pub const ABMON_6: ::nl_item = 25;
pub const ABMON_7: ::nl_item = 26;
pub const ABMON_8: ::nl_item = 27;
pub const ABMON_9: ::nl_item = 28;
pub const ABMON_10: ::nl_item = 29;
pub const ABMON_11: ::nl_item = 30;
pub const ABMON_12: ::nl_item = 31;
pub const RADIXCHAR: ::nl_item = 44;
pub const THOUSEP: ::nl_item = 45;
pub const YESSTR: ::nl_item = 46;
pub const NOSTR: ::nl_item = 47;
pub const CRNCYSTR: ::nl_item = 48;
pub const D_T_FMT: ::nl_item = 1;
pub const D_FMT: ::nl_item = 2;
pub const T_FMT: ::nl_item = 3;
pub const AM_STR: ::nl_item = 4;
pub const PM_STR: ::nl_item = 5;
pub const CODESET: ::nl_item = 49;
pub const T_FMT_AMPM: ::nl_item = 55;
pub const ERA: ::nl_item = 56;
pub const ERA_D_FMT: ::nl_item = 57;
pub const ERA_D_T_FMT: ::nl_item = 58;
pub const ERA_T_FMT: ::nl_item = 59;
pub const ALT_DIGITS: ::nl_item = 60;
pub const YESEXPR: ::nl_item = 61;
pub const NOEXPR: ::nl_item = 62;

// locale.h
pub const LC_GLOBAL_LOCALE: ::locale_t = -1isize as ::locale_t;
pub const LC_CTYPE: ::c_int = 1;
pub const LC_NUMERIC: ::c_int = 3;
pub const LC_TIME: ::c_int = 4;
pub const LC_COLLATE: ::c_int = 0;
pub const LC_MONETARY: ::c_int = 2;
pub const LC_MESSAGES: ::c_int = 4;
pub const LC_ALL: ::c_int = -1;
pub const LC_CTYPE_MASK: ::c_int = 2;
pub const LC_NUMERIC_MASK: ::c_int = 16;
pub const LC_TIME_MASK: ::c_int = 32;
pub const LC_COLLATE_MASK: ::c_int = 1;
pub const LC_MONETARY_MASK: ::c_int = 8;
pub const LC_MESSAGES_MASK: ::c_int = 4;
pub const LC_ALL_MASK: ::c_int = LC_CTYPE_MASK
    | LC_NUMERIC_MASK
    | LC_TIME_MASK
    | LC_COLLATE_MASK
    | LC_MONETARY_MASK
    | LC_MESSAGES_MASK;

// netdb.h
pub const NI_MAXHOST: ::socklen_t = 1025;
pub const NI_MAXSERV: ::socklen_t = 32;
pub const NI_NOFQDN: ::socklen_t = 0x1;
pub const NI_NUMERICHOST: ::socklen_t = 0x2;
pub const NI_NAMEREQD: ::socklen_t = 0x4;
pub const NI_NUMERICSERV: ::socklen_t = 0x8;
pub const NI_DGRAM: ::socklen_t = 0x10;
pub const NI_NUMERICSCOPE: ::socklen_t = 0x40;
pub const EAI_AGAIN: ::c_int = 2;
pub const EAI_BADFLAGS: ::c_int = 3;
pub const EAI_FAIL: ::c_int = 4;
pub const EAI_FAMILY: ::c_int = 5;
pub const EAI_MEMORY: ::c_int = 6;
pub const EAI_NODATA: ::c_int = 7;
pub const EAI_NONAME: ::c_int = 8;
pub const EAI_SERVICE: ::c_int = 9;
pub const EAI_SOCKTYPE: ::c_int = 10;
pub const EAI_SYSTEM: ::c_int = 11;
pub const EAI_OVERFLOW: ::c_int = 13;
pub const AI_CANONNAME: ::c_int = 0x01;
pub const AI_PASSIVE: ::c_int = 0x02;
pub const AI_NUMERICHOST: ::c_int = 0x04;
pub const AI_ADDRCONFIG: ::c_int = 0x08;
pub const AI_V4MAPPED: ::c_int = 0x10;
pub const AI_ALL: ::c_int = 0x20;
pub const AI_NUMERICSERV: ::c_int = 0x40;
pub const AI_EXTFLAGS: ::c_int = 0x80;
pub const AI_DEFAULT: ::c_int = AI_V4MAPPED | AI_ADDRCONFIG;
pub const IPV6_ADDRFORM: ::c_int = 22;
pub const IPV6_ADDR_PREFERENCES: ::c_int = 74;
pub const IPV6_CHECKSUM: ::c_int = 39;
pub const IPV6_DONTFRAG: ::c_int = 45;
pub const IPV6_DSTOPTS: ::c_int = 54;
pub const IPV6_FLOWINFO_FLOWLABEL: ::c_int = 16777215;
pub const IPV6_FLOWINFO_PRIORITY: ::c_int = 251658240;
pub const IPV6_HOPLIMIT: ::c_int = 40;
pub const IPV6_HOPOPTS: ::c_int = 52;
pub const IPV6_NEXTHOP: ::c_int = 48;
pub const IPV6_PATHMTU: ::c_int = 46;
pub const IPV6_PKTINFO: ::c_int = 33;
pub const IPV6_PREFER_SRC_CGA: ::c_int = 16;
pub const IPV6_PREFER_SRC_COA: ::c_int = 2;
pub const IPV6_PREFER_SRC_HOME: ::c_int = 1;
pub const IPV6_PREFER_SRC_NONCGA: ::c_int = 32;
pub const IPV6_PREFER_SRC_PUBLIC: ::c_int = 4;
pub const IPV6_PREFER_SRC_TMP: ::c_int = 8;
pub const IPV6_RECVDSTOPTS: ::c_int = 56;
pub const IPV6_RECVHOPLIMIT: ::c_int = 41;
pub const IPV6_RECVHOPOPTS: ::c_int = 53;
pub const IPV6_RECVPATHMTU: ::c_int = 47;
pub const IPV6_RECVRTHDR: ::c_int = 51;
pub const IPV6_RECVTCLASS: ::c_int = 42;
pub const IPV6_RTHDR: ::c_int = 50;
pub const IPV6_RTHDRDSTOPTS: ::c_int = 55;
pub const IPV6_TCLASS: ::c_int = 43;

// net/bpf.h
pub const DLT_NULL: ::c_int = 0x18;
pub const DLT_EN10MB: ::c_int = 0x6;
pub const DLT_EN3MB: ::c_int = 0x1a;
pub const DLT_AX25: ::c_int = 0x5;
pub const DLT_PRONET: ::c_int = 0xd;
pub const DLT_IEEE802: ::c_int = 0x7;
pub const DLT_ARCNET: ::c_int = 0x23;
pub const DLT_SLIP: ::c_int = 0x1c;
pub const DLT_PPP: ::c_int = 0x17;
pub const DLT_FDDI: ::c_int = 0xf;
pub const DLT_ATM: ::c_int = 0x25;
pub const DLT_IPOIB: ::c_int = 0xc7;
pub const BIOCSETF: ::c_ulong = 0x80104267;
pub const BIOCGRTIMEOUT: ::c_ulong = 0x4010426e;
pub const BIOCGBLEN: ::c_int = 0x40044266;
pub const BIOCSBLEN: ::c_int = 0xc0044266;
pub const BIOCFLUSH: ::c_int = 0x20004268;
pub const BIOCPROMISC: ::c_int = 0x20004269;
pub const BIOCGDLT: ::c_int = 0x4004426a;
pub const BIOCSRTIMEOUT: ::c_int = 0x8010426d;
pub const BIOCGSTATS: ::c_int = 0x4008426f;
pub const BIOCIMMEDIATE: ::c_int = 0x80044270;
pub const BIOCVERSION: ::c_int = 0x40044271;
pub const BIOCSDEVNO: ::c_int = 0x20004272;
pub const BIOCGETIF: ::c_ulong = 0x4020426b;
pub const BIOCSETIF: ::c_ulong = 0xffffffff8020426c;
pub const BPF_ABS: ::c_int = 32;
pub const BPF_ADD: ::c_int = 0;
pub const BPF_ALIGNMENT: ::c_ulong = 4;
pub const BPF_ALU: ::c_int = 4;
pub const BPF_AND: ::c_int = 80;
pub const BPF_B: ::c_int = 16;
pub const BPF_DIV: ::c_int = 48;
pub const BPF_H: ::c_int = 8;
pub const BPF_IMM: ::c_int = 0;
pub const BPF_IND: ::c_int = 64;
pub const BPF_JA: ::c_int = 0;
pub const BPF_JEQ: ::c_int = 16;
pub const BPF_JGE: ::c_int = 48;
pub const BPF_JGT: ::c_int = 32;
pub const BPF_JMP: ::c_int = 5;
pub const BPF_JSET: ::c_int = 64;
pub const BPF_K: ::c_int = 0;
pub const BPF_LD: ::c_int = 0;
pub const BPF_LDX: ::c_int = 1;
pub const BPF_LEN: ::c_int = 128;
pub const BPF_LSH: ::c_int = 96;
pub const BPF_MAXINSNS: ::c_int = 512;
pub const BPF_MEM: ::c_int = 96;
pub const BPF_MEMWORDS: ::c_int = 16;
pub const BPF_MISC: ::c_int = 7;
pub const BPF_MSH: ::c_int = 160;
pub const BPF_MUL: ::c_int = 32;
pub const BPF_NEG: ::c_int = 128;
pub const BPF_OR: ::c_int = 64;
pub const BPF_RET: ::c_int = 6;
pub const BPF_RSH: ::c_int = 112;
pub const BPF_ST: ::c_int = 2;
pub const BPF_STX: ::c_int = 3;
pub const BPF_SUB: ::c_int = 16;
pub const BPF_W: ::c_int = 0;
pub const BPF_X: ::c_int = 8;

// net/if.h
pub const IFNET_SLOWHZ: ::c_int = 1;
pub const IFQ_MAXLEN: ::c_int = 50;
pub const IF_NAMESIZE: ::c_int = 16;
pub const IFNAMSIZ: ::c_int = 16;
pub const IFF_UP: ::c_int = 0x1;
pub const IFF_BROADCAST: ::c_int = 0x2;
pub const IFF_DEBUG: ::c_int = 0x4;
pub const IFF_LOOPBACK: ::c_int = 0x8;
pub const IFF_POINTOPOINT: ::c_int = 0x10;
pub const IFF_NOTRAILERS: ::c_int = 0x20;
pub const IFF_RUNNING: ::c_int = 0x40;
pub const IFF_NOARP: ::c_int = 0x80;
pub const IFF_PROMISC: ::c_int = 0x100;
pub const IFF_ALLMULTI: ::c_int = 0x200;
pub const IFF_MULTICAST: ::c_int = 0x80000;
pub const IFF_LINK0: ::c_int = 0x100000;
pub const IFF_LINK1: ::c_int = 0x200000;
pub const IFF_LINK2: ::c_int = 0x400000;
pub const IFF_OACTIVE: ::c_int = 0x400;
pub const IFF_SIMPLEX: ::c_int = 0x800;

// net/if_arp.h
pub const ARPHRD_ETHER: ::c_int = 1;
pub const ARPHRD_802_5: ::c_int = 6;
pub const ARPHRD_802_3: ::c_int = 6;
pub const ARPHRD_FDDI: ::c_int = 1;
pub const ARPOP_REQUEST: ::c_int = 1;
pub const ARPOP_REPLY: ::c_int = 2;

// net/route.h
pub const RTM_ADD: ::c_int = 0x1;
pub const RTM_DELETE: ::c_int = 0x2;
pub const RTM_CHANGE: ::c_int = 0x3;
pub const RTM_GET: ::c_int = 0x4;
pub const RTM_LOSING: ::c_int = 0x5;
pub const RTM_REDIRECT: ::c_int = 0x6;
pub const RTM_MISS: ::c_int = 0x7;
pub const RTM_LOCK: ::c_int = 0x8;
pub const RTM_OLDADD: ::c_int = 0x9;
pub const RTM_OLDDEL: ::c_int = 0xa;
pub const RTM_RESOLVE: ::c_int = 0xb;
pub const RTM_NEWADDR: ::c_int = 0xc;
pub const RTM_DELADDR: ::c_int = 0xd;
pub const RTM_IFINFO: ::c_int = 0xe;
pub const RTM_EXPIRE: ::c_int = 0xf;
pub const RTM_RTLOST: ::c_int = 0x10;
pub const RTM_GETNEXT: ::c_int = 0x11;
pub const RTM_SAMEADDR: ::c_int = 0x12;
pub const RTM_SET: ::c_int = 0x13;
pub const RTV_MTU: ::c_int = 0x1;
pub const RTV_HOPCOUNT: ::c_int = 0x2;
pub const RTV_EXPIRE: ::c_int = 0x4;
pub const RTV_RPIPE: ::c_int = 0x8;
pub const RTV_SPIPE: ::c_int = 0x10;
pub const RTV_SSTHRESH: ::c_int = 0x20;
pub const RTV_RTT: ::c_int = 0x40;
pub const RTV_RTTVAR: ::c_int = 0x80;
pub const RTA_DST: ::c_int = 0x1;
pub const RTA_GATEWAY: ::c_int = 0x2;
pub const RTA_NETMASK: ::c_int = 0x4;
pub const RTA_GENMASK: ::c_int = 0x8;
pub const RTA_IFP: ::c_int = 0x10;
pub const RTA_IFA: ::c_int = 0x20;
pub const RTA_AUTHOR: ::c_int = 0x40;
pub const RTA_BRD: ::c_int = 0x80;
pub const RTA_DOWNSTREAM: ::c_int = 0x100;
pub const RTAX_DST: ::c_int = 0;
pub const RTAX_GATEWAY: ::c_int = 1;
pub const RTAX_NETMASK: ::c_int = 2;
pub const RTAX_GENMASK: ::c_int = 3;
pub const RTAX_IFP: ::c_int = 4;
pub const RTAX_IFA: ::c_int = 5;
pub const RTAX_AUTHOR: ::c_int = 6;
pub const RTAX_BRD: ::c_int = 7;
pub const RTAX_MAX: ::c_int = 8;
pub const RTF_UP: ::c_int = 0x1;
pub const RTF_GATEWAY: ::c_int = 0x2;
pub const RTF_HOST: ::c_int = 0x4;
pub const RTF_REJECT: ::c_int = 0x8;
pub const RTF_DYNAMIC: ::c_int = 0x10;
pub const RTF_MODIFIED: ::c_int = 0x20;
pub const RTF_DONE: ::c_int = 0x40;
pub const RTF_MASK: ::c_int = 0x80;
pub const RTF_CLONING: ::c_int = 0x100;
pub const RTF_XRESOLVE: ::c_int = 0x200;
pub const RTF_LLINFO: ::c_int = 0x400;
pub const RTF_STATIC: ::c_int = 0x800;
pub const RTF_BLACKHOLE: ::c_int = 0x1000;
pub const RTF_BUL: ::c_int = 0x2000;
pub const RTF_PROTO2: ::c_int = 0x4000;
pub const RTF_PROTO1: ::c_int = 0x8000;
pub const RTF_CLONE: ::c_int = 0x10000;
pub const RTF_CLONED: ::c_int = 0x20000;
pub const RTF_PROTO3: ::c_int = 0x40000;
pub const RTF_BCE: ::c_int = 0x80000;
pub const RTF_PINNED: ::c_int = 0x100000;
pub const RTF_LOCAL: ::c_int = 0x200000;
pub const RTF_BROADCAST: ::c_int = 0x400000;
pub const RTF_MULTICAST: ::c_int = 0x800000;
pub const RTF_ACTIVE_DGD: ::c_int = 0x1000000;
pub const RTF_STOPSRCH: ::c_int = 0x2000000;
pub const RTF_FREE_IN_PROG: ::c_int = 0x4000000;
pub const RTF_PERMANENT6: ::c_int = 0x8000000;
pub const RTF_UNREACHABLE: ::c_int = 0x10000000;
pub const RTF_CACHED: ::c_int = 0x20000000;
pub const RTF_SMALLMTU: ::c_int = 0x40000;

// netinet/in.h
pub const IPPROTO_HOPOPTS: ::c_int = 0;
pub const IPPROTO_IGMP: ::c_int = 2;
pub const IPPROTO_GGP: ::c_int = 3;
pub const IPPROTO_IPIP: ::c_int = 4;
pub const IPPROTO_EGP: ::c_int = 8;
pub const IPPROTO_PUP: ::c_int = 12;
pub const IPPROTO_IDP: ::c_int = 22;
pub const IPPROTO_TP: ::c_int = 29;
pub const IPPROTO_ROUTING: ::c_int = 43;
pub const IPPROTO_FRAGMENT: ::c_int = 44;
pub const IPPROTO_QOS: ::c_int = 45;
pub const IPPROTO_RSVP: ::c_int = 46;
pub const IPPROTO_GRE: ::c_int = 47;
pub const IPPROTO_ESP: ::c_int = 50;
pub const IPPROTO_AH: ::c_int = 51;
pub const IPPROTO_NONE: ::c_int = 59;
pub const IPPROTO_DSTOPTS: ::c_int = 60;
pub const IPPROTO_LOCAL: ::c_int = 63;
pub const IPPROTO_EON: ::c_int = 80;
pub const IPPROTO_BIP: ::c_int = 0x53;
pub const IPPROTO_SCTP: ::c_int = 132;
pub const IPPROTO_MH: ::c_int = 135;
pub const IPPROTO_GIF: ::c_int = 140;
pub const IPPROTO_RAW: ::c_int = 255;
pub const IPPROTO_MAX: ::c_int = 256;
pub const IP_OPTIONS: ::c_int = 1;
pub const IP_HDRINCL: ::c_int = 2;
pub const IP_TOS: ::c_int = 3;
pub const IP_TTL: ::c_int = 4;
pub const IP_UNICAST_HOPS: ::c_int = 4;
pub const IP_RECVOPTS: ::c_int = 5;
pub const IP_RECVRETOPTS: ::c_int = 6;
pub const IP_RECVDSTADDR: ::c_int = 7;
pub const IP_RETOPTS: ::c_int = 8;
pub const IP_MULTICAST_IF: ::c_int = 9;
pub const IP_MULTICAST_TTL: ::c_int = 10;
pub const IP_MULTICAST_HOPS: ::c_int = 10;
pub const IP_MULTICAST_LOOP: ::c_int = 11;
pub const IP_ADD_MEMBERSHIP: ::c_int = 12;
pub const IP_DROP_MEMBERSHIP: ::c_int = 13;
pub const IP_RECVMACHDR: ::c_int = 14;
pub const IP_RECVIFINFO: ::c_int = 15;
pub const IP_BROADCAST_IF: ::c_int = 16;
pub const IP_DHCPMODE: ::c_int = 17;
pub const IP_RECVIF: ::c_int = 20;
pub const IP_ADDRFORM: ::c_int = 22;
pub const IP_DONTFRAG: ::c_int = 25;
pub const IP_FINDPMTU: ::c_int = 26;
pub const IP_PMTUAGE: ::c_int = 27;
pub const IP_RECVINTERFACE: ::c_int = 32;
pub const IP_RECVTTL: ::c_int = 34;
pub const IP_BLOCK_SOURCE: ::c_int = 58;
pub const IP_UNBLOCK_SOURCE: ::c_int = 59;
pub const IP_ADD_SOURCE_MEMBERSHIP: ::c_int = 60;
pub const IP_DROP_SOURCE_MEMBERSHIP: ::c_int = 61;
pub const IP_DEFAULT_MULTICAST_TTL: ::c_int = 1;
pub const IP_DEFAULT_MULTICAST_LOOP: ::c_int = 1;
pub const IP_INC_MEMBERSHIPS: ::c_int = 20;
pub const IP_INIT_MEMBERSHIP: ::c_int = 20;
pub const IPV6_UNICAST_HOPS: ::c_int = IP_TTL;
pub const IPV6_MULTICAST_IF: ::c_int = IP_MULTICAST_IF;
pub const IPV6_MULTICAST_HOPS: ::c_int = IP_MULTICAST_TTL;
pub const IPV6_MULTICAST_LOOP: ::c_int = IP_MULTICAST_LOOP;
pub const IPV6_RECVPKTINFO: ::c_int = 35;
pub const IPV6_V6ONLY: ::c_int = 37;
pub const IPV6_ADD_MEMBERSHIP: ::c_int = IP_ADD_MEMBERSHIP;
pub const IPV6_DROP_MEMBERSHIP: ::c_int = IP_DROP_MEMBERSHIP;
pub const IPV6_JOIN_GROUP: ::c_int = IP_ADD_MEMBERSHIP;
pub const IPV6_LEAVE_GROUP: ::c_int = IP_DROP_MEMBERSHIP;
pub const MCAST_BLOCK_SOURCE: ::c_int = 64;
pub const MCAST_EXCLUDE: ::c_int = 2;
pub const MCAST_INCLUDE: ::c_int = 1;
pub const MCAST_JOIN_GROUP: ::c_int = 62;
pub const MCAST_JOIN_SOURCE_GROUP: ::c_int = 66;
pub const MCAST_LEAVE_GROUP: ::c_int = 63;
pub const MCAST_LEAVE_SOURCE_GROUP: ::c_int = 67;
pub const MCAST_UNBLOCK_SOURCE: ::c_int = 65;

// netinet/ip.h
pub const MAXTTL: ::c_int = 255;
pub const IPDEFTTL: ::c_int = 64;
pub const IPOPT_CONTROL: ::c_int = 0;
pub const IPOPT_EOL: ::c_int = 0;
pub const IPOPT_LSRR: ::c_int = 131;
pub const IPOPT_MINOFF: ::c_int = 4;
pub const IPOPT_NOP: ::c_int = 1;
pub const IPOPT_OFFSET: ::c_int = 2;
pub const IPOPT_OLEN: ::c_int = 1;
pub const IPOPT_OPTVAL: ::c_int = 0;
pub const IPOPT_RESERVED1: ::c_int = 0x20;
pub const IPOPT_RESERVED2: ::c_int = 0x60;
pub const IPOPT_RR: ::c_int = 7;
pub const IPOPT_SSRR: ::c_int = 137;
pub const IPOPT_TS: ::c_int = 68;
pub const IPOPT_TS_PRESPEC: ::c_int = 3;
pub const IPOPT_TS_TSANDADDR: ::c_int = 1;
pub const IPOPT_TS_TSONLY: ::c_int = 0;
pub const IPTOS_LOWDELAY: ::c_int = 16;
pub const IPTOS_PREC_CRITIC_ECP: ::c_int = 160;
pub const IPTOS_PREC_FLASH: ::c_int = 96;
pub const IPTOS_PREC_FLASHOVERRIDE: ::c_int = 128;
pub const IPTOS_PREC_IMMEDIATE: ::c_int = 64;
pub const IPTOS_PREC_INTERNETCONTROL: ::c_int = 192;
pub const IPTOS_PREC_NETCONTROL: ::c_int = 224;
pub const IPTOS_PREC_PRIORITY: ::c_int = 32;
pub const IPTOS_PREC_ROUTINE: ::c_int = 16;
pub const IPTOS_RELIABILITY: ::c_int = 4;
pub const IPTOS_THROUGHPUT: ::c_int = 8;
pub const IPVERSION: ::c_int = 4;

// netinet/tcp.h
pub const TCP_NODELAY: ::c_int = 0x1;
pub const TCP_MAXSEG: ::c_int = 0x2;
pub const TCP_RFC1323: ::c_int = 0x4;
pub const TCP_KEEPALIVE: ::c_int = 0x8;
pub const TCP_KEEPIDLE: ::c_int = 0x11;
pub const TCP_KEEPINTVL: ::c_int = 0x12;
pub const TCP_KEEPCNT: ::c_int = 0x13;
pub const TCP_NODELAYACK: ::c_int = 0x14;

// pthread.h
pub const PTHREAD_CREATE_JOINABLE: ::c_int = 0;
pub const PTHREAD_CREATE_DETACHED: ::c_int = 1;
pub const PTHREAD_PROCESS_SHARED: ::c_int = 0;
pub const PTHREAD_PROCESS_PRIVATE: ::c_ushort = 1;
pub const PTHREAD_STACK_MIN: ::size_t = PAGESIZE as ::size_t * 4;
pub const PTHREAD_MUTEX_NORMAL: ::c_int = 5;
pub const PTHREAD_MUTEX_ERRORCHECK: ::c_int = 3;
pub const PTHREAD_MUTEX_RECURSIVE: ::c_int = 4;
pub const PTHREAD_MUTEX_DEFAULT: ::c_int = PTHREAD_MUTEX_NORMAL;
pub const PTHREAD_MUTEX_ROBUST: ::c_int = 1;
pub const PTHREAD_MUTEX_STALLED: ::c_int = 0;
pub const PTHREAD_PRIO_INHERIT: ::c_int = 3;
pub const PTHREAD_PRIO_NONE: ::c_int = 1;
pub const PTHREAD_PRIO_PROTECT: ::c_int = 2;

// regex.h
pub const REG_EXTENDED: ::c_int = 1;
pub const REG_ICASE: ::c_int = 2;
pub const REG_NEWLINE: ::c_int = 4;
pub const REG_NOSUB: ::c_int = 8;
pub const REG_NOTBOL: ::c_int = 0x100;
pub const REG_NOTEOL: ::c_int = 0x200;
pub const REG_NOMATCH: ::c_int = 1;
pub const REG_BADPAT: ::c_int = 2;
pub const REG_ECOLLATE: ::c_int = 3;
pub const REG_ECTYPE: ::c_int = 4;
pub const REG_EESCAPE: ::c_int = 5;
pub const REG_ESUBREG: ::c_int = 6;
pub const REG_EBRACK: ::c_int = 7;
pub const REG_EPAREN: ::c_int = 8;
pub const REG_EBRACE: ::c_int = 9;
pub const REG_BADBR: ::c_int = 10;
pub const REG_ERANGE: ::c_int = 11;
pub const REG_ESPACE: ::c_int = 12;
pub const REG_BADRPT: ::c_int = 13;
pub const REG_ECHAR: ::c_int = 14;
pub const REG_EBOL: ::c_int = 15;
pub const REG_EEOL: ::c_int = 16;
pub const REG_ENOSYS: ::c_int = 17;

// rpcsvc/mount.h
pub const NFSMNT_ACDIRMAX: ::c_int = 2048;
pub const NFSMNT_ACDIRMIN: ::c_int = 1024;
pub const NFSMNT_ACREGMAX: ::c_int = 512;
pub const NFSMNT_ACREGMIN: ::c_int = 256;
pub const NFSMNT_INT: ::c_int = 64;
pub const NFSMNT_NOAC: ::c_int = 128;
pub const NFSMNT_RETRANS: ::c_int = 16;
pub const NFSMNT_RSIZE: ::c_int = 4;
pub const NFSMNT_SOFT: ::c_int = 1;
pub const NFSMNT_TIMEO: ::c_int = 8;
pub const NFSMNT_WSIZE: ::c_int = 2;

// rpcsvc/rstat.h
pub const CPUSTATES: ::c_int = 4;

// search.h
pub const FIND: ::c_int = 0;
pub const ENTER: ::c_int = 1;

// semaphore.h
pub const SEM_FAILED: *mut sem_t = -1isize as *mut ::sem_t;

// spawn.h
pub const POSIX_SPAWN_SETPGROUP: ::c_int = 0x1;
pub const POSIX_SPAWN_SETSIGMASK: ::c_int = 0x2;
pub const POSIX_SPAWN_SETSIGDEF: ::c_int = 0x4;
pub const POSIX_SPAWN_SETSCHEDULER: ::c_int = 0x8;
pub const POSIX_SPAWN_SETSCHEDPARAM: ::c_int = 0x10;
pub const POSIX_SPAWN_RESETIDS: ::c_int = 0x20;
pub const POSIX_SPAWN_FORK_HANDLERS: ::c_int = 0x1000;

// stdio.h
pub const EOF: ::c_int = -1;
pub const SEEK_SET: ::c_int = 0;
pub const SEEK_CUR: ::c_int = 1;
pub const SEEK_END: ::c_int = 2;
pub const _IOFBF: ::c_int = 0o000;
pub const _IONBF: ::c_int = 0o004;
pub const _IOLBF: ::c_int = 0o100;
pub const BUFSIZ: ::c_uint = 4096;
pub const FOPEN_MAX: ::c_uint = 32767;
pub const FILENAME_MAX: ::c_uint = 255;
pub const L_tmpnam: ::c_uint = 21;
pub const TMP_MAX: ::c_uint = 16384;

// stdlib.h
pub const EXIT_FAILURE: ::c_int = 1;
pub const EXIT_SUCCESS: ::c_int = 0;
pub const RAND_MAX: ::c_int = 32767;

// sys/access.h
pub const F_OK: ::c_int = 0;
pub const R_OK: ::c_int = 4;
pub const W_OK: ::c_int = 2;
pub const X_OK: ::c_int = 1;

// sys/aio.h
pub const LIO_NOP: ::c_int = 0;
pub const LIO_READ: ::c_int = 1;
pub const LIO_WRITE: ::c_int = 2;
pub const LIO_NOWAIT: ::c_int = 0;
pub const LIO_WAIT: ::c_int = 1;
pub const AIO_ALLDONE: ::c_int = 2;
pub const AIO_CANCELED: ::c_int = 0;
pub const AIO_NOTCANCELED: ::c_int = 1;

// sys/errno.h
pub const EPERM: ::c_int = 1;
pub const ENOENT: ::c_int = 2;
pub const ESRCH: ::c_int = 3;
pub const EINTR: ::c_int = 4;
pub const EIO: ::c_int = 5;
pub const ENXIO: ::c_int = 6;
pub const E2BIG: ::c_int = 7;
pub const ENOEXEC: ::c_int = 8;
pub const EBADF: ::c_int = 9;
pub const ECHILD: ::c_int = 10;
pub const EAGAIN: ::c_int = 11;
pub const ENOMEM: ::c_int = 12;
pub const EACCES: ::c_int = 13;
pub const EFAULT: ::c_int = 14;
pub const ENOTBLK: ::c_int = 15;
pub const EBUSY: ::c_int = 16;
pub const EEXIST: ::c_int = 17;
pub const EXDEV: ::c_int = 18;
pub const ENODEV: ::c_int = 19;
pub const ENOTDIR: ::c_int = 20;
pub const EISDIR: ::c_int = 21;
pub const EINVAL: ::c_int = 22;
pub const ENFILE: ::c_int = 23;
pub const EMFILE: ::c_int = 24;
pub const ENOTTY: ::c_int = 25;
pub const ETXTBSY: ::c_int = 26;
pub const EFBIG: ::c_int = 27;
pub const ENOSPC: ::c_int = 28;
pub const ESPIPE: ::c_int = 29;
pub const EROFS: ::c_int = 30;
pub const EMLINK: ::c_int = 31;
pub const EPIPE: ::c_int = 32;
pub const EDOM: ::c_int = 33;
pub const ERANGE: ::c_int = 34;
pub const ENOMSG: ::c_int = 35;
pub const EIDRM: ::c_int = 36;
pub const ECHRNG: ::c_int = 37;
pub const EL2NSYNC: ::c_int = 38;
pub const EL3HLT: ::c_int = 39;
pub const EL3RST: ::c_int = 40;
pub const ELNRNG: ::c_int = 41;
pub const EUNATCH: ::c_int = 42;
pub const ENOCSI: ::c_int = 43;
pub const EL2HLT: ::c_int = 44;
pub const EDEADLK: ::c_int = 45;
pub const ENOLCK: ::c_int = 49;
pub const ECANCELED: ::c_int = 117;
pub const ENOTSUP: ::c_int = 124;
pub const EPROCLIM: ::c_int = 83;
pub const EDQUOT: ::c_int = 88;
pub const EOWNERDEAD: ::c_int = 95;
pub const ENOTRECOVERABLE: ::c_int = 94;
pub const ENOSTR: ::c_int = 123;
pub const ENODATA: ::c_int = 122;
pub const ETIME: ::c_int = 119;
pub const ENOSR: ::c_int = 118;
pub const EREMOTE: ::c_int = 93;
pub const ENOATTR: ::c_int = 112;
pub const ESAD: ::c_int = 113;
pub const ENOTRUST: ::c_int = 114;
pub const ENOLINK: ::c_int = 126;
pub const EPROTO: ::c_int = 121;
pub const EMULTIHOP: ::c_int = 125;
pub const EBADMSG: ::c_int = 120;
pub const ENAMETOOLONG: ::c_int = 86;
pub const EOVERFLOW: ::c_int = 127;
pub const EILSEQ: ::c_int = 116;
pub const ENOSYS: ::c_int = 109;
pub const ELOOP: ::c_int = 85;
pub const ERESTART: ::c_int = 82;
pub const ENOTEMPTY: ::c_int = 87;
pub const EUSERS: ::c_int = 84;
pub const ENOTSOCK: ::c_int = 57;
pub const EDESTADDRREQ: ::c_int = 58;
pub const EMSGSIZE: ::c_int = 59;
pub const EPROTOTYPE: ::c_int = 60;
pub const ENOPROTOOPT: ::c_int = 61;
pub const EPROTONOSUPPORT: ::c_int = 62;
pub const ESOCKTNOSUPPORT: ::c_int = 63;
pub const EOPNOTSUPP: ::c_int = 64;
pub const EPFNOSUPPORT: ::c_int = 65;
pub const EAFNOSUPPORT: ::c_int = 66;
pub const EADDRINUSE: ::c_int = 67;
pub const EADDRNOTAVAIL: ::c_int = 68;
pub const ENETDOWN: ::c_int = 69;
pub const ENETUNREACH: ::c_int = 70;
pub const ENETRESET: ::c_int = 71;
pub const ECONNABORTED: ::c_int = 72;
pub const ECONNRESET: ::c_int = 73;
pub const ENOBUFS: ::c_int = 74;
pub const EISCONN: ::c_int = 75;
pub const ENOTCONN: ::c_int = 76;
pub const ESHUTDOWN: ::c_int = 77;
pub const ETOOMANYREFS: ::c_int = 115;
pub const ETIMEDOUT: ::c_int = 78;
pub const ECONNREFUSED: ::c_int = 79;
pub const EHOSTDOWN: ::c_int = 80;
pub const EHOSTUNREACH: ::c_int = 81;
pub const EWOULDBLOCK: ::c_int = EAGAIN;
pub const EALREADY: ::c_int = 56;
pub const EINPROGRESS: ::c_int = 55;
pub const ESTALE: ::c_int = 52;

// sys/dr.h
pub const LPAR_INFO_FORMAT1: ::c_int = 1;
pub const LPAR_INFO_FORMAT2: ::c_int = 2;
pub const WPAR_INFO_FORMAT: ::c_int = 3;
pub const PROC_MODULE_INFO: ::c_int = 4;
pub const NUM_PROC_MODULE_TYPES: ::c_int = 5;
pub const LPAR_INFO_VRME_NUM_POOLS: ::c_int = 6;
pub const LPAR_INFO_VRME_POOLS: ::c_int = 7;
pub const LPAR_INFO_VRME_LPAR: ::c_int = 8;
pub const LPAR_INFO_VRME_RESET_HWMARKS: ::c_int = 9;
pub const LPAR_INFO_VRME_ALLOW_DESIRED: ::c_int = 10;
pub const EMTP_INFO_FORMAT: ::c_int = 11;
pub const LPAR_INFO_LPM_CAPABILITY: ::c_int = 12;
pub const ENERGYSCALE_INFO: ::c_int = 13;

// sys/file.h
pub const LOCK_SH: ::c_int = 1;
pub const LOCK_EX: ::c_int = 2;
pub const LOCK_NB: ::c_int = 4;
pub const LOCK_UN: ::c_int = 8;

// sys/flock.h
pub const F_RDLCK: ::c_short = 0o01;
pub const F_WRLCK: ::c_short = 0o02;
pub const F_UNLCK: ::c_short = 0o03;

// sys/fs/quota_common.h
pub const Q_QUOTAON: ::c_int = 0x100;
pub const Q_QUOTAOFF: ::c_int = 0x200;
pub const Q_SETUSE: ::c_int = 0x500;
pub const Q_SYNC: ::c_int = 0x600;
pub const Q_GETQUOTA: ::c_int = 0x300;
pub const Q_SETQLIM: ::c_int = 0x400;
pub const Q_SETQUOTA: ::c_int = 0x400;

// sys/ioctl.h
pub const IOCPARM_MASK: ::c_int = 0x7f;
pub const IOC_VOID: ::c_int = 0x20000000;
pub const IOC_OUT: ::c_int = 0x40000000;
pub const IOC_IN: ::c_int = 0x40000000 << 1;
pub const IOC_INOUT: ::c_int = IOC_IN | IOC_OUT;
pub const FIOCLEX: ::c_int = 536897025;
pub const FIONCLEX: ::c_int = 536897026;
pub const FIONREAD: ::c_int = 1074030207;
pub const FIONBIO: ::c_int = -2147195266;
pub const FIOASYNC: ::c_int = -2147195267;
pub const FIOSETOWN: ::c_int = -2147195268;
pub const FIOGETOWN: ::c_int = 1074030203;
pub const TIOCGETD: ::c_int = 0x40047400;
pub const TIOCSETD: ::c_int = 0x80047401;
pub const TIOCHPCL: ::c_int = 0x20007402;
pub const TIOCMODG: ::c_int = 0x40047403;
pub const TIOCMODS: ::c_int = 0x80047404;
pub const TIOCM_LE: ::c_int = 0x1;
pub const TIOCM_DTR: ::c_int = 0x2;
pub const TIOCM_RTS: ::c_int = 0x4;
pub const TIOCM_ST: ::c_int = 0x8;
pub const TIOCM_SR: ::c_int = 0x10;
pub const TIOCM_CTS: ::c_int = 0x20;
pub const TIOCM_CAR: ::c_int = 0x40;
pub const TIOCM_CD: ::c_int = 0x40;
pub const TIOCM_RNG: ::c_int = 0x80;
pub const TIOCM_RI: ::c_int = 0x80;
pub const TIOCM_DSR: ::c_int = 0x100;
pub const TIOCGETP: ::c_int = 0x40067408;
pub const TIOCSETP: ::c_int = 0x80067409;
pub const TIOCSETN: ::c_int = 0x8006740a;
pub const TIOCEXCL: ::c_int = 0x2000740d;
pub const TIOCNXCL: ::c_int = 0x2000740e;
pub const TIOCFLUSH: ::c_int = 0x80047410;
pub const TIOCSETC: ::c_int = 0x80067411;
pub const TIOCGETC: ::c_int = 0x40067412;
pub const TANDEM: ::c_int = 0x1;
pub const CBREAK: ::c_int = 0x2;
pub const LCASE: ::c_int = 0x4;
pub const MDMBUF: ::c_int = 0x800000;
pub const XTABS: ::c_int = 0xc00;
pub const SIOCADDMULTI: ::c_int = -2145359567;
pub const SIOCADDRT: ::c_int = -2143784438;
pub const SIOCDARP: ::c_int = -2142476000;
pub const SIOCDELMULTI: ::c_int = -2145359566;
pub const SIOCDELRT: ::c_int = -2143784437;
pub const SIOCDIFADDR: ::c_int = -2144835303;
pub const SIOCGARP: ::c_int = -1068734170;
pub const SIOCGIFADDR: ::c_int = -1071093471;
pub const SIOCGIFBRDADDR: ::c_int = -1071093469;
pub const SIOCGIFCONF: ::c_int = -1072666299;
pub const SIOCGIFDSTADDR: ::c_int = -1071093470;
pub const SIOCGIFFLAGS: ::c_int = -1071093487;
pub const SIOCGIFHWADDR: ::c_int = -1068209771;
pub const SIOCGIFMETRIC: ::c_int = -1071093481;
pub const SIOCGIFMTU: ::c_int = -1071093418;
pub const SIOCGIFNETMASK: ::c_int = -1071093467;
pub const SIOCSARP: ::c_int = -2142476002;
pub const SIOCSIFADDR: ::c_int = -2144835316;
pub const SIOCSIFBRDADDR: ::c_int = -2144835309;
pub const SIOCSIFDSTADDR: ::c_int = -2144835314;
pub const SIOCSIFFLAGS: ::c_int = -2144835312;
pub const SIOCSIFMETRIC: ::c_int = -2144835304;
pub const SIOCSIFMTU: ::c_int = -2144835240;
pub const SIOCSIFNETMASK: ::c_int = -2144835306;
pub const TIOCUCNTL: ::c_int = -2147191706;
pub const TIOCCONS: ::c_int = -2147191710;
pub const TIOCPKT: ::c_int = -2147191696;
pub const TIOCPKT_DATA: ::c_int = 0;
pub const TIOCPKT_FLUSHREAD: ::c_int = 1;
pub const TIOCPKT_FLUSHWRITE: ::c_int = 2;
pub const TIOCPKT_NOSTOP: ::c_int = 0x10;
pub const TIOCPKT_DOSTOP: ::c_int = 0x20;
pub const TIOCPKT_START: ::c_int = 8;
pub const TIOCPKT_STOP: ::c_int = 4;

// sys/ipc.h
pub const IPC_ALLOC: ::c_int = 0o100000;
pub const IPC_CREAT: ::c_int = 0o020000;
pub const IPC_EXCL: ::c_int = 0o002000;
pub const IPC_NOWAIT: ::c_int = 0o004000;
pub const IPC_RMID: ::c_int = 0;
pub const IPC_SET: ::c_int = 101;
pub const IPC_R: ::c_int = 0o0400;
pub const IPC_W: ::c_int = 0o0200;
pub const IPC_O: ::c_int = 0o1000;
pub const IPC_NOERROR: ::c_int = 0o10000;
pub const IPC_STAT: ::c_int = 102;
pub const IPC_PRIVATE: ::key_t = -1;
pub const SHM_LOCK: ::c_int = 201;
pub const SHM_UNLOCK: ::c_int = 202;

// sys/ldr.h
pub const L_GETINFO: ::c_int = 2;
pub const L_GETMESSAGE: ::c_int = 1;
pub const L_GETLIBPATH: ::c_int = 3;
pub const L_GETXINFO: ::c_int = 8;

// sys/limits.h
pub const PATH_MAX: ::c_int = 1023;
pub const PAGESIZE: ::c_int = 4096;
pub const IOV_MAX: ::c_int = 16;
pub const AIO_LISTIO_MAX: ::c_int = 4096;
pub const PIPE_BUF: usize = 32768;
pub const OPEN_MAX: ::c_int = 65534;
pub const MAX_INPUT: ::c_int = 512;
pub const MAX_CANON: ::c_int = 256;
pub const ARG_MAX: ::c_int = 1048576;
pub const BC_BASE_MAX: ::c_int = 99;
pub const BC_DIM_MAX: ::c_int = 0x800;
pub const BC_SCALE_MAX: ::c_int = 99;
pub const BC_STRING_MAX: ::c_int = 0x800;
pub const CHARCLASS_NAME_MAX: ::c_int = 14;
pub const CHILD_MAX: ::c_int = 128;
pub const COLL_WEIGHTS_MAX: ::c_int = 4;
pub const EXPR_NEST_MAX: ::c_int = 32;
pub const NZERO: ::c_int = 20;

// sys/lockf.h
pub const F_LOCK: ::c_int = 1;
pub const F_TEST: ::c_int = 3;
pub const F_TLOCK: ::c_int = 2;
pub const F_ULOCK: ::c_int = 0;

// sys/machine.h
pub const BIG_ENDIAN: ::c_int = 4321;
pub const LITTLE_ENDIAN: ::c_int = 1234;
pub const PDP_ENDIAN: ::c_int = 3412;

// sys/mman.h
pub const PROT_NONE: ::c_int = 0;
pub const PROT_READ: ::c_int = 1;
pub const PROT_WRITE: ::c_int = 2;
pub const PROT_EXEC: ::c_int = 4;
pub const MAP_FILE: ::c_int = 0;
pub const MAP_SHARED: ::c_int = 1;
pub const MAP_PRIVATE: ::c_int = 2;
pub const MAP_FIXED: ::c_int = 0x100;
pub const MAP_ANON: ::c_int = 0x10;
pub const MAP_ANONYMOUS: ::c_int = 0x10;
pub const MAP_FAILED: *mut ::c_void = !0 as *mut ::c_void;
pub const MAP_TYPE: ::c_int = 0xf0;
pub const MCL_CURRENT: ::c_int = 0x100;
pub const MCL_FUTURE: ::c_int = 0x200;
pub const MS_SYNC: ::c_int = 0x20;
pub const MS_ASYNC: ::c_int = 0x10;
pub const MS_INVALIDATE: ::c_int = 0x40;
pub const POSIX_MADV_NORMAL: ::c_int = 1;
pub const POSIX_MADV_RANDOM: ::c_int = 3;
pub const POSIX_MADV_SEQUENTIAL: ::c_int = 2;
pub const POSIX_MADV_WILLNEED: ::c_int = 4;
pub const POSIX_MADV_DONTNEED: ::c_int = 5;
pub const MADV_NORMAL: ::c_int = 0;
pub const MADV_RANDOM: ::c_int = 1;
pub const MADV_SEQUENTIAL: ::c_int = 2;
pub const MADV_WILLNEED: ::c_int = 3;
pub const MADV_DONTNEED: ::c_int = 4;

// sys/mode.h
pub const S_IFMT: mode_t = 0o170000;
pub const S_IFREG: mode_t = 0o100000;
pub const S_IFDIR: mode_t = 0o40000;
pub const S_IFBLK: mode_t = 0o60000;
pub const S_IFCHR: mode_t = 0o20000;
pub const S_IFIFO: mode_t = 0o10000;
pub const S_IRWXU: mode_t = 0o700;
pub const S_IRUSR: mode_t = 0o400;
pub const S_IWUSR: mode_t = 0o200;
pub const S_IXUSR: mode_t = 0o100;
pub const S_IRWXG: mode_t = 0o70;
pub const S_IRGRP: mode_t = 0o40;
pub const S_IWGRP: mode_t = 0o20;
pub const S_IXGRP: mode_t = 0o10;
pub const S_IRWXO: mode_t = 7;
pub const S_IROTH: mode_t = 4;
pub const S_IWOTH: mode_t = 2;
pub const S_IXOTH: mode_t = 1;
pub const S_IFLNK: mode_t = 0o120000;
pub const S_IFSOCK: mode_t = 0o140000;
pub const S_IEXEC: mode_t = 0o100;
pub const S_IWRITE: mode_t = 0o200;
pub const S_IREAD: mode_t = 0o400;

// sys/msg.h
pub const MSG_NOERROR: ::c_int = 0o10000;

// sys/m_signal.h
pub const SIGSTKSZ: ::size_t = 4096;
pub const MINSIGSTKSZ: ::size_t = 1200;

// sys/params.h
pub const MAXPATHLEN: ::c_int = PATH_MAX + 1;
pub const MAXSYMLINKS: ::c_int = 20;
pub const MAXHOSTNAMELEN: ::c_int = 256;
pub const MAXUPRC: ::c_int = 128;
pub const NGROUPS_MAX: ::c_ulong = 2048;
pub const NGROUPS: ::c_ulong = NGROUPS_MAX;
pub const NOFILE: ::c_int = OPEN_MAX;

// sys/poll.h
pub const POLLIN: ::c_short = 0x0001;
pub const POLLPRI: ::c_short = 0x0004;
pub const POLLOUT: ::c_short = 0x0002;
pub const POLLERR: ::c_short = 0x4000;
pub const POLLHUP: ::c_short = 0x2000;
pub const POLLMSG: ::c_short = 0x0080;
pub const POLLSYNC: ::c_short = 0x8000;
pub const POLLNVAL: ::c_short = POLLSYNC;
pub const POLLNORM: ::c_short = POLLIN;
pub const POLLRDNORM: ::c_short = 0x0010;
pub const POLLWRNORM: ::c_short = POLLOUT;
pub const POLLRDBAND: ::c_short = 0x0020;
pub const POLLWRBAND: ::c_short = 0x0040;

// sys/pollset.h
pub const PS_ADD: ::c_uchar = 0;
pub const PS_MOD: ::c_uchar = 1;
pub const PS_DELETE: ::c_uchar = 2;
pub const PS_REPLACE: ::c_uchar = 3;

// sys/ptrace.h
pub const PT_TRACE_ME: ::c_int = 0;
pub const PT_READ_I: ::c_int = 1;
pub const PT_READ_D: ::c_int = 2;
pub const PT_WRITE_I: ::c_int = 4;
pub const PT_WRITE_D: ::c_int = 5;
pub const PT_CONTINUE: ::c_int = 7;
pub const PT_KILL: ::c_int = 8;
pub const PT_STEP: ::c_int = 9;
pub const PT_READ_GPR: ::c_int = 11;
pub const PT_READ_FPR: ::c_int = 12;
pub const PT_WRITE_GPR: ::c_int = 14;
pub const PT_WRITE_FPR: ::c_int = 15;
pub const PT_READ_BLOCK: ::c_int = 17;
pub const PT_WRITE_BLOCK: ::c_int = 19;
pub const PT_ATTACH: ::c_int = 30;
pub const PT_DETACH: ::c_int = 31;
pub const PT_REGSET: ::c_int = 32;
pub const PT_REATT: ::c_int = 33;
pub const PT_LDINFO: ::c_int = 34;
pub const PT_MULTI: ::c_int = 35;
pub const PT_NEXT: ::c_int = 36;
pub const PT_SET: ::c_int = 37;
pub const PT_CLEAR: ::c_int = 38;
pub const PT_LDXINFO: ::c_int = 39;
pub const PT_QUERY: ::c_int = 40;
pub const PT_WATCH: ::c_int = 41;
pub const PTT_CONTINUE: ::c_int = 50;
pub const PTT_STEP: ::c_int = 51;
pub const PTT_READ_SPRS: ::c_int = 52;
pub const PTT_WRITE_SPRS: ::c_int = 53;
pub const PTT_READ_GPRS: ::c_int = 54;
pub const PTT_WRITE_GPRS: ::c_int = 55;
pub const PTT_READ_FPRS: ::c_int = 56;
pub const PTT_WRITE_FPRS: ::c_int = 57;
pub const PTT_READ_VEC: ::c_int = 58;
pub const PTT_WRITE_VEC: ::c_int = 59;
pub const PTT_WATCH: ::c_int = 60;
pub const PTT_SET_TRAP: ::c_int = 61;
pub const PTT_CLEAR_TRAP: ::c_int = 62;
pub const PTT_READ_UKEYSET: ::c_int = 63;
pub const PT_GET_UKEY: ::c_int = 64;
pub const PTT_READ_FPSCR_HI: ::c_int = 65;
pub const PTT_WRITE_FPSCR_HI: ::c_int = 66;
pub const PTT_READ_VSX: ::c_int = 67;
pub const PTT_WRITE_VSX: ::c_int = 68;
pub const PTT_READ_TM: ::c_int = 69;
pub const PTRACE_ATTACH: ::c_int = 14;
pub const PTRACE_CONT: ::c_int = 7;
pub const PTRACE_DETACH: ::c_int = 15;
pub const PTRACE_GETFPREGS: ::c_int = 12;
pub const PTRACE_GETREGS: ::c_int = 10;
pub const PTRACE_KILL: ::c_int = 8;
pub const PTRACE_PEEKDATA: ::c_int = 2;
pub const PTRACE_PEEKTEXT: ::c_int = 1;
pub const PTRACE_PEEKUSER: ::c_int = 3;
pub const PTRACE_POKEDATA: ::c_int = 5;
pub const PTRACE_POKETEXT: ::c_int = 4;
pub const PTRACE_POKEUSER: ::c_int = 6;
pub const PTRACE_SETFPREGS: ::c_int = 13;
pub const PTRACE_SETREGS: ::c_int = 11;
pub const PTRACE_SINGLESTEP: ::c_int = 9;
pub const PTRACE_SYSCALL: ::c_int = 16;
pub const PTRACE_TRACEME: ::c_int = 0;

// sys/resource.h
pub const RLIMIT_CPU: ::c_int = 0;
pub const RLIMIT_FSIZE: ::c_int = 1;
pub const RLIMIT_DATA: ::c_int = 2;
pub const RLIMIT_STACK: ::c_int = 3;
pub const RLIMIT_CORE: ::c_int = 4;
pub const RLIMIT_RSS: ::c_int = 5;
pub const RLIMIT_AS: ::c_int = 6;
pub const RLIMIT_NOFILE: ::c_int = 7;
pub const RLIMIT_THREADS: ::c_int = 8;
pub const RLIMIT_NPROC: ::c_int = 9;
pub const RUSAGE_SELF: ::c_int = 0;
pub const RUSAGE_CHILDREN: ::c_int = -1;
pub const PRIO_PROCESS: ::c_int = 0;
pub const PRIO_PGRP: ::c_int = 1;
pub const PRIO_USER: ::c_int = 2;
pub const RUSAGE_THREAD: ::c_int = 1;
pub const RLIM_SAVED_MAX: ::c_ulong = RLIM_INFINITY - 1;
pub const RLIM_SAVED_CUR: ::c_ulong = RLIM_INFINITY - 2;
#[deprecated(since = "0.2.64", note = "Not stable across OS versions")]
pub const RLIM_NLIMITS: ::c_int = 10;

// sys/sched.h
pub const SCHED_OTHER: ::c_int = 0;
pub const SCHED_FIFO: ::c_int = 1;
pub const SCHED_RR: ::c_int = 2;
pub const SCHED_LOCAL: ::c_int = 3;
pub const SCHED_GLOBAL: ::c_int = 4;
pub const SCHED_FIFO2: ::c_int = 5;
pub const SCHED_FIFO3: ::c_int = 6;
pub const SCHED_FIFO4: ::c_int = 7;

// sys/sem.h
pub const SEM_UNDO: ::c_int = 0o10000;
pub const GETNCNT: ::c_int = 3;
pub const GETPID: ::c_int = 4;
pub const GETVAL: ::c_int = 5;
pub const GETALL: ::c_int = 6;
pub const GETZCNT: ::c_int = 7;
pub const SETVAL: ::c_int = 8;
pub const SETALL: ::c_int = 9;

// sys/shm.h
pub const SHMLBA: ::c_int = 0x10000000;
pub const SHMLBA_EXTSHM: ::c_int = 0x1000;
pub const SHM_SHMAT: ::c_int = 0x80000000;
pub const SHM_RDONLY: ::c_int = 0o10000;
pub const SHM_RND: ::c_int = 0o20000;
pub const SHM_PIN: ::c_int = 0o4000;
pub const SHM_LGPAGE: ::c_int = 0o20000000000;
pub const SHM_MAP: ::c_int = 0o4000;
pub const SHM_FMAP: ::c_int = 0o2000;
pub const SHM_COPY: ::c_int = 0o40000;
pub const SHM_CLEAR: ::c_int = 0;
pub const SHM_HGSEG: ::c_int = 0o10000000000;
pub const SHM_R: ::c_int = IPC_R;
pub const SHM_W: ::c_int = IPC_W;
pub const SHM_DEST: ::c_int = 0o2000;

// sys/signal.h
pub const SA_ONSTACK: ::c_int = 0x00000001;
pub const SA_RESETHAND: ::c_int = 0x00000002;
pub const SA_RESTART: ::c_int = 0x00000008;
pub const SA_SIGINFO: ::c_int = 0x00000100;
pub const SA_NODEFER: ::c_int = 0x00000200;
pub const SA_NOCLDWAIT: ::c_int = 0x00000400;
pub const SA_NOCLDSTOP: ::c_int = 0x00000004;
pub const SS_ONSTACK: ::c_int = 0x00000001;
pub const SS_DISABLE: ::c_int = 0x00000002;
pub const SIGCHLD: ::c_int = 20;
pub const SIGBUS: ::c_int = 10;
pub const SIG_BLOCK: ::c_int = 0;
pub const SIG_UNBLOCK: ::c_int = 1;
pub const SIG_SETMASK: ::c_int = 2;
pub const SIGEV_NONE: ::c_int = 1;
pub const SIGEV_SIGNAL: ::c_int = 2;
pub const SIGEV_THREAD: ::c_int = 3;
pub const SIGHUP: ::c_int = 1;
pub const SIGINT: ::c_int = 2;
pub const SIGQUIT: ::c_int = 3;
pub const SIGILL: ::c_int = 4;
pub const SIGABRT: ::c_int = 6;
pub const SIGEMT: ::c_int = 7;
pub const SIGFPE: ::c_int = 8;
pub const SIGKILL: ::c_int = 9;
pub const SIGSEGV: ::c_int = 11;
pub const SIGSYS: ::c_int = 12;
pub const SIGPIPE: ::c_int = 13;
pub const SIGALRM: ::c_int = 14;
pub const SIGTERM: ::c_int = 15;
pub const SIGUSR1: ::c_int = 30;
pub const SIGUSR2: ::c_int = 31;
pub const SIGPWR: ::c_int = 29;
pub const SIGWINCH: ::c_int = 28;
pub const SIGURG: ::c_int = 16;
pub const SIGPOLL: ::c_int = SIGIO;
pub const SIGIO: ::c_int = 23;
pub const SIGSTOP: ::c_int = 17;
pub const SIGTSTP: ::c_int = 18;
pub const SIGCONT: ::c_int = 19;
pub const SIGTTIN: ::c_int = 21;
pub const SIGTTOU: ::c_int = 22;
pub const SIGVTALRM: ::c_int = 34;
pub const SIGPROF: ::c_int = 32;
pub const SIGXCPU: ::c_int = 24;
pub const SIGXFSZ: ::c_int = 25;
pub const SIGTRAP: ::c_int = 5;
pub const SIGCLD: ::c_int = 20;
pub const SIGRTMAX: ::c_int = 57;
pub const SIGRTMIN: ::c_int = 50;
pub const SI_USER: ::c_int = 0;
pub const SI_UNDEFINED: ::c_int = 8;
pub const SI_EMPTY: ::c_int = 9;
pub const BUS_ADRALN: ::c_int = 1;
pub const BUS_ADRERR: ::c_int = 2;
pub const BUS_OBJERR: ::c_int = 3;
pub const BUS_UEGARD: ::c_int = 4;
pub const CLD_EXITED: ::c_int = 10;
pub const CLD_KILLED: ::c_int = 11;
pub const CLD_DUMPED: ::c_int = 12;
pub const CLD_TRAPPED: ::c_int = 13;
pub const CLD_STOPPED: ::c_int = 14;
pub const CLD_CONTINUED: ::c_int = 15;
pub const FPE_INTDIV: ::c_int = 20;
pub const FPE_INTOVF: ::c_int = 21;
pub const FPE_FLTDIV: ::c_int = 22;
pub const FPE_FLTOVF: ::c_int = 23;
pub const FPE_FLTUND: ::c_int = 24;
pub const FPE_FLTRES: ::c_int = 25;
pub const FPE_FLTINV: ::c_int = 26;
pub const FPE_FLTSUB: ::c_int = 27;
pub const ILL_ILLOPC: ::c_int = 30;
pub const ILL_ILLOPN: ::c_int = 31;
pub const ILL_ILLADR: ::c_int = 32;
pub const ILL_ILLTRP: ::c_int = 33;
pub const ILL_PRVOPC: ::c_int = 34;
pub const ILL_PRVREG: ::c_int = 35;
pub const ILL_COPROC: ::c_int = 36;
pub const ILL_BADSTK: ::c_int = 37;
pub const ILL_TMBADTHING: ::c_int = 38;
pub const POLL_IN: ::c_int = 40;
pub const POLL_OUT: ::c_int = 41;
pub const POLL_MSG: ::c_int = -3;
pub const POLL_ERR: ::c_int = 43;
pub const POLL_PRI: ::c_int = 44;
pub const POLL_HUP: ::c_int = 45;
pub const SEGV_MAPERR: ::c_int = 50;
pub const SEGV_ACCERR: ::c_int = 51;
pub const SEGV_KEYERR: ::c_int = 52;
pub const TRAP_BRKPT: ::c_int = 60;
pub const TRAP_TRACE: ::c_int = 61;
pub const SI_QUEUE: ::c_int = 71;
pub const SI_TIMER: ::c_int = 72;
pub const SI_ASYNCIO: ::c_int = 73;
pub const SI_MESGQ: ::c_int = 74;

// sys/socket.h
pub const AF_UNSPEC: ::c_int = 0;
pub const AF_UNIX: ::c_int = 1;
pub const AF_INET: ::c_int = 2;
pub const AF_IMPLINK: ::c_int = 3;
pub const AF_PUP: ::c_int = 4;
pub const AF_CHAOS: ::c_int = 5;
pub const AF_NS: ::c_int = 6;
pub const AF_ECMA: ::c_int = 8;
pub const AF_DATAKIT: ::c_int = 9;
pub const AF_CCITT: ::c_int = 10;
pub const AF_SNA: ::c_int = 11;
pub const AF_DECnet: ::c_int = 12;
pub const AF_DLI: ::c_int = 13;
pub const AF_LAT: ::c_int = 14;
pub const SO_TIMESTAMPNS: ::c_int = 0x100a;
pub const SOMAXCONN: ::c_int = 1024;
pub const AF_LOCAL: ::c_int = AF_UNIX;
pub const UIO_MAXIOV: ::c_int = 1024;
pub const pseudo_AF_XTP: ::c_int = 19;
pub const AF_HYLINK: ::c_int = 15;
pub const AF_APPLETALK: ::c_int = 16;
pub const AF_ISO: ::c_int = 7;
pub const AF_OSI: ::c_int = AF_ISO;
pub const AF_ROUTE: ::c_int = 17;
pub const AF_LINK: ::c_int = 18;
pub const AF_INET6: ::c_int = 24;
pub const AF_INTF: ::c_int = 20;
pub const AF_RIF: ::c_int = 21;
pub const AF_NDD: ::c_int = 23;
pub const AF_MAX: ::c_int = 30;
pub const PF_UNSPEC: ::c_int = AF_UNSPEC;
pub const PF_UNIX: ::c_int = AF_UNIX;
pub const PF_INET: ::c_int = AF_INET;
pub const PF_IMPLINK: ::c_int = AF_IMPLINK;
pub const PF_PUP: ::c_int = AF_PUP;
pub const PF_CHAOS: ::c_int = AF_CHAOS;
pub const PF_NS: ::c_int = AF_NS;
pub const PF_ISO: ::c_int = AF_ISO;
pub const PF_OSI: ::c_int = AF_ISO;
pub const PF_ECMA: ::c_int = AF_ECMA;
pub const PF_DATAKIT: ::c_int = AF_DATAKIT;
pub const PF_CCITT: ::c_int = AF_CCITT;
pub const PF_SNA: ::c_int = AF_SNA;
pub const PF_DECnet: ::c_int = AF_DECnet;
pub const PF_DLI: ::c_int = AF_DLI;
pub const PF_LAT: ::c_int = AF_LAT;
pub const PF_HYLINK: ::c_int = AF_HYLINK;
pub const PF_APPLETALK: ::c_int = AF_APPLETALK;
pub const PF_ROUTE: ::c_int = AF_ROUTE;
pub const PF_LINK: ::c_int = AF_LINK;
pub const PF_XTP: ::c_int = 19;
pub const PF_RIF: ::c_int = AF_RIF;
pub const PF_INTF: ::c_int = AF_INTF;
pub const PF_NDD: ::c_int = AF_NDD;
pub const PF_INET6: ::c_int = AF_INET6;
pub const PF_MAX: ::c_int = AF_MAX;
pub const SF_CLOSE: ::c_int = 1;
pub const SF_REUSE: ::c_int = 2;
pub const SF_DONT_CACHE: ::c_int = 4;
pub const SF_SYNC_CACHE: ::c_int = 8;
pub const SOCK_DGRAM: ::c_int = 2;
pub const SOCK_STREAM: ::c_int = 1;
pub const SOCK_RAW: ::c_int = 3;
pub const SOCK_RDM: ::c_int = 4;
pub const SOCK_SEQPACKET: ::c_int = 5;
pub const SOL_SOCKET: ::c_int = 0xffff;
pub const SO_DEBUG: ::c_int = 0x0001;
pub const SO_ACCEPTCONN: ::c_int = 0x0002;
pub const SO_REUSEADDR: ::c_int = 0x0004;
pub const SO_KEEPALIVE: ::c_int = 0x0008;
pub const SO_DONTROUTE: ::c_int = 0x0010;
pub const SO_BROADCAST: ::c_int = 0x0020;
pub const SO_USELOOPBACK: ::c_int = 0x0040;
pub const SO_LINGER: ::c_int = 0x0080;
pub const SO_OOBINLINE: ::c_int = 0x0100;
pub const SO_REUSEPORT: ::c_int = 0x0200;
pub const SO_USE_IFBUFS: ::c_int = 0x0400;
pub const SO_CKSUMRECV: ::c_int = 0x0800;
pub const SO_NOREUSEADDR: ::c_int = 0x1000;
pub const SO_KERNACCEPT: ::c_int = 0x2000;
pub const SO_NOMULTIPATH: ::c_int = 0x4000;
pub const SO_AUDIT: ::c_int = 0x8000;
pub const SO_SNDBUF: ::c_int = 0x1001;
pub const SO_RCVBUF: ::c_int = 0x1002;
pub const SO_SNDLOWAT: ::c_int = 0x1003;
pub const SO_RCVLOWAT: ::c_int = 0x1004;
pub const SO_SNDTIMEO: ::c_int = 0x1005;
pub const SO_RCVTIMEO: ::c_int = 0x1006;
pub const SO_ERROR: ::c_int = 0x1007;
pub const SO_TYPE: ::c_int = 0x1008;
pub const SCM_RIGHTS: ::c_int = 0x01;
pub const MSG_OOB: ::c_int = 0x1;
pub const MSG_PEEK: ::c_int = 0x2;
pub const MSG_DONTROUTE: ::c_int = 0x4;
pub const MSG_EOR: ::c_int = 0x8;
pub const MSG_TRUNC: ::c_int = 0x10;
pub const MSG_CTRUNC: ::c_int = 0x20;
pub const MSG_WAITALL: ::c_int = 0x40;
pub const MSG_MPEG2: ::c_int = 0x80;
pub const MSG_NOSIGNAL: ::c_int = 0x100;
pub const MSG_WAITFORONE: ::c_int = 0x200;
pub const MSG_ARGEXT: ::c_int = 0x400;
pub const MSG_NONBLOCK: ::c_int = 0x4000;
pub const MSG_COMPAT: ::c_int = 0x8000;
pub const MSG_MAXIOVLEN: ::c_int = 16;
pub const SHUT_RD: ::c_int = 0;
pub const SHUT_WR: ::c_int = 1;
pub const SHUT_RDWR: ::c_int = 2;

// sys/stat.h
pub const UTIME_NOW: ::c_int = -2;
pub const UTIME_OMIT: ::c_int = -3;

// sys/statvfs.h
pub const ST_RDONLY: ::c_ulong = 0x0001;
pub const ST_NOSUID: ::c_ulong = 0x0040;
pub const ST_NODEV: ::c_ulong = 0x0080;

// sys/stropts.h
pub const I_NREAD: ::c_int = 0x20005301;
pub const I_PUSH: ::c_int = 0x20005302;
pub const I_POP: ::c_int = 0x20005303;
pub const I_LOOK: ::c_int = 0x20005304;
pub const I_FLUSH: ::c_int = 0x20005305;
pub const I_SRDOPT: ::c_int = 0x20005306;
pub const I_GRDOPT: ::c_int = 0x20005307;
pub const I_STR: ::c_int = 0x20005308;
pub const I_SETSIG: ::c_int = 0x20005309;
pub const I_GETSIG: ::c_int = 0x2000530a;
pub const I_FIND: ::c_int = 0x2000530b;
pub const I_LINK: ::c_int = 0x2000530c;
pub const I_UNLINK: ::c_int = 0x2000530d;
pub const I_PEEK: ::c_int = 0x2000530f;
pub const I_FDINSERT: ::c_int = 0x20005310;
pub const I_SENDFD: ::c_int = 0x20005311;
pub const I_RECVFD: ::c_int = 0x20005312;
pub const I_SWROPT: ::c_int = 0x20005314;
pub const I_GWROPT: ::c_int = 0x20005315;
pub const I_LIST: ::c_int = 0x20005316;
pub const I_PLINK: ::c_int = 0x2000531d;
pub const I_PUNLINK: ::c_int = 0x2000531e;
pub const I_FLUSHBAND: ::c_int = 0x20005313;
pub const I_CKBAND: ::c_int = 0x20005318;
pub const I_GETBAND: ::c_int = 0x20005319;
pub const I_ATMARK: ::c_int = 0x20005317;
pub const I_SETCLTIME: ::c_int = 0x2000531b;
pub const I_GETCLTIME: ::c_int = 0x2000531c;
pub const I_CANPUT: ::c_int = 0x2000531a;

// sys/syslog.h
pub const LOG_CRON: ::c_int = 9 << 3;
pub const LOG_AUTHPRIV: ::c_int = 10 << 3;
pub const LOG_NFACILITIES: ::c_int = 24;
pub const LOG_PERROR: ::c_int = 0x20;

// sys/systemcfg.h
pub const SC_ARCH: ::c_int = 1;
pub const SC_IMPL: ::c_int = 2;
pub const SC_VERS: ::c_int = 3;
pub const SC_WIDTH: ::c_int = 4;
pub const SC_NCPUS: ::c_int = 5;
pub const SC_L1C_ATTR: ::c_int = 6;
pub const SC_L1C_ISZ: ::c_int = 7;
pub const SC_L1C_DSZ: ::c_int = 8;
pub const SC_L1C_ICA: ::c_int = 9;
pub const SC_L1C_DCA: ::c_int = 10;
pub const SC_L1C_IBS: ::c_int = 11;
pub const SC_L1C_DBS: ::c_int = 12;
pub const SC_L1C_ILS: ::c_int = 13;
pub const SC_L1C_DLS: ::c_int = 14;
pub const SC_L2C_SZ: ::c_int = 15;
pub const SC_L2C_AS: ::c_int = 16;
pub const SC_TLB_ATTR: ::c_int = 17;
pub const SC_ITLB_SZ: ::c_int = 18;
pub const SC_DTLB_SZ: ::c_int = 19;
pub const SC_ITLB_ATT: ::c_int = 20;
pub const SC_DTLB_ATT: ::c_int = 21;
pub const SC_RESRV_SZ: ::c_int = 22;
pub const SC_PRI_LC: ::c_int = 23;
pub const SC_PRO_LC: ::c_int = 24;
pub const SC_RTC_TYPE: ::c_int = 25;
pub const SC_VIRT_AL: ::c_int = 26;
pub const SC_CAC_CONG: ::c_int = 27;
pub const SC_MOD_ARCH: ::c_int = 28;
pub const SC_MOD_IMPL: ::c_int = 29;
pub const SC_XINT: ::c_int = 30;
pub const SC_XFRAC: ::c_int = 31;
pub const SC_KRN_ATTR: ::c_int = 32;
pub const SC_PHYSMEM: ::c_int = 33;
pub const SC_SLB_ATTR: ::c_int = 34;
pub const SC_SLB_SZ: ::c_int = 35;
pub const SC_MAX_NCPUS: ::c_int = 37;
pub const SC_MAX_REALADDR: ::c_int = 38;
pub const SC_ORIG_ENT_CAP: ::c_int = 39;
pub const SC_ENT_CAP: ::c_int = 40;
pub const SC_DISP_WHE: ::c_int = 41;
pub const SC_CAPINC: ::c_int = 42;
pub const SC_VCAPW: ::c_int = 43;
pub const SC_SPLP_STAT: ::c_int = 44;
pub const SC_SMT_STAT: ::c_int = 45;
pub const SC_SMT_TC: ::c_int = 46;
pub const SC_VMX_VER: ::c_int = 47;
pub const SC_LMB_SZ: ::c_int = 48;
pub const SC_MAX_XCPU: ::c_int = 49;
pub const SC_EC_LVL: ::c_int = 50;
pub const SC_AME_STAT: ::c_int = 51;
pub const SC_ECO_STAT: ::c_int = 52;
pub const SC_DFP_VER: ::c_int = 53;
pub const SC_VRM_STAT: ::c_int = 54;
pub const SC_PHYS_IMP: ::c_int = 55;
pub const SC_PHYS_VER: ::c_int = 56;
pub const SC_SPCM_STATUS: ::c_int = 57;
pub const SC_SPCM_MAX: ::c_int = 58;
pub const SC_TM_VER: ::c_int = 59;
pub const SC_NX_CAP: ::c_int = 60;
pub const SC_PKS_STATE: ::c_int = 61;
pub const SC_MMA_VER: ::c_int = 62;
pub const POWER_RS: ::c_int = 1;
pub const POWER_PC: ::c_int = 2;
pub const IA64: ::c_int = 3;
pub const POWER_RS1: ::c_int = 0x1;
pub const POWER_RSC: ::c_int = 0x2;
pub const POWER_RS2: ::c_int = 0x4;
pub const POWER_601: ::c_int = 0x8;
pub const POWER_604: ::c_int = 0x10;
pub const POWER_603: ::c_int = 0x20;
pub const POWER_620: ::c_int = 0x40;
pub const POWER_630: ::c_int = 0x80;
pub const POWER_A35: ::c_int = 0x100;
pub const POWER_RS64II: ::c_int = 0x200;
pub const POWER_RS64III: ::c_int = 0x400;
pub const POWER_4: ::c_int = 0x800;
pub const POWER_RS64IV: ::c_int = POWER_4;
pub const POWER_MPC7450: ::c_int = 0x1000;
pub const POWER_5: ::c_int = 0x2000;
pub const POWER_6: ::c_int = 0x4000;
pub const POWER_7: ::c_int = 0x8000;
pub const POWER_8: ::c_int = 0x10000;
pub const POWER_9: ::c_int = 0x20000;

// sys/time.h
pub const FD_SETSIZE: usize = 65534;
pub const TIMEOFDAY: ::c_int = 9;
pub const CLOCK_REALTIME: ::clockid_t = TIMEOFDAY as clockid_t;
pub const CLOCK_MONOTONIC: ::clockid_t = 10;
pub const TIMER_ABSTIME: ::c_int = 999;
pub const ITIMER_REAL: ::c_int = 0;
pub const ITIMER_VIRTUAL: ::c_int = 1;
pub const ITIMER_PROF: ::c_int = 2;
pub const ITIMER_VIRT: ::c_int = 3;
pub const ITIMER_REAL1: ::c_int = 20;
pub const ITIMER_REAL_TH: ::c_int = ITIMER_REAL1;
pub const DST_AUST: ::c_int = 2;
pub const DST_CAN: ::c_int = 6;
pub const DST_EET: ::c_int = 5;
pub const DST_MET: ::c_int = 4;
pub const DST_NONE: ::c_int = 0;
pub const DST_USA: ::c_int = 1;
pub const DST_WET: ::c_int = 3;

// sys/termio.h
pub const CSTART: ::tcflag_t = 0o21;
pub const CSTOP: ::tcflag_t = 0o23;
pub const TCGETA: ::c_int = TIOC | 5;
pub const TCSETA: ::c_int = TIOC | 6;
pub const TCSETAW: ::c_int = TIOC | 7;
pub const TCSETAF: ::c_int = TIOC | 8;
pub const TCSBRK: ::c_int = TIOC | 9;
pub const TCXONC: ::c_int = TIOC | 11;
pub const TCFLSH: ::c_int = TIOC | 12;
pub const TCGETS: ::c_int = TIOC | 1;
pub const TCSETS: ::c_int = TIOC | 2;
pub const TCSANOW: ::c_int = 0;
pub const TCSETSW: ::c_int = TIOC | 3;
pub const TCSADRAIN: ::c_int = 1;
pub const TCSETSF: ::c_int = TIOC | 4;
pub const TCSAFLUSH: ::c_int = 2;
pub const TCIFLUSH: ::c_int = 0;
pub const TCOFLUSH: ::c_int = 1;
pub const TCIOFLUSH: ::c_int = 2;
pub const TCOOFF: ::c_int = 0;
pub const TCOON: ::c_int = 1;
pub const TCIOFF: ::c_int = 2;
pub const TCION: ::c_int = 3;
pub const TIOC: ::c_int = 0x5400;
pub const TIOCGWINSZ: ::c_int = 0x40087468;
pub const TIOCSWINSZ: ::c_int = 0x80087467;
pub const TIOCLBIS: ::c_int = 0x8004747f;
pub const TIOCLBIC: ::c_int = 0x8004747e;
pub const TIOCLSET: ::c_int = 0x8004747d;
pub const TIOCLGET: ::c_int = 0x4004747c;
pub const TIOCSBRK: ::c_int = 0x2000747b;
pub const TIOCCBRK: ::c_int = 0x2000747a;
pub const TIOCSDTR: ::c_int = 0x20007479;
pub const TIOCCDTR: ::c_int = 0x20007478;
pub const TIOCSLTC: ::c_int = 0x80067475;
pub const TIOCGLTC: ::c_int = 0x40067474;
pub const TIOCOUTQ: ::c_int = 0x40047473;
pub const TIOCNOTTY: ::c_int = 0x20007471;
pub const TIOCSTOP: ::c_int = 0x2000746f;
pub const TIOCSTART: ::c_int = 0x2000746e;
pub const TIOCGPGRP: ::c_int = 0x40047477;
pub const TIOCSPGRP: ::c_int = 0x80047476;
pub const TIOCGSID: ::c_int = 0x40047448;
pub const TIOCSTI: ::c_int = 0x80017472;
pub const TIOCMSET: ::c_int = 0x8004746d;
pub const TIOCMBIS: ::c_int = 0x8004746c;
pub const TIOCMBIC: ::c_int = 0x8004746b;
pub const TIOCMGET: ::c_int = 0x4004746a;
pub const TIOCREMOTE: ::c_int = 0x80047469;

// sys/user.h
pub const MAXCOMLEN: ::c_int = 32;
pub const UF_SYSTEM: ::c_int = 0x1000;

// sys/vattr.h
pub const AT_FLAGS: ::c_int = 0x80;
pub const AT_GID: ::c_int = 8;
pub const AT_UID: ::c_int = 4;

// sys/wait.h
pub const P_ALL: ::c_int = 0;
pub const P_PID: ::c_int = 1;
pub const P_PGID: ::c_int = 2;
pub const WNOHANG: ::c_int = 0x1;
pub const WUNTRACED: ::c_int = 0x2;
pub const WEXITED: ::c_int = 0x04;
pub const WCONTINUED: ::c_int = 0x01000000;
pub const WNOWAIT: ::c_int = 0x10;
pub const WSTOPPED: ::c_int = _W_STOPPED;
pub const _W_STOPPED: ::c_int = 0x00000040;
pub const _W_SLWTED: ::c_int = 0x0000007c;
pub const _W_SEWTED: ::c_int = 0x0000007d;
pub const _W_SFWTED: ::c_int = 0x0000007e;
pub const _W_STRC: ::c_int = 0x0000007f;

// termios.h
pub const NCCS: usize = 16;
pub const OLCUC: ::tcflag_t = 2;
pub const CSIZE: ::tcflag_t = 0x00000030;
pub const CS5: ::tcflag_t = 0x00000000;
pub const CS6: ::tcflag_t = 0x00000010;
pub const CS7: ::tcflag_t = 0x00000020;
pub const CS8: ::tcflag_t = 0x00000030;
pub const CSTOPB: ::tcflag_t = 0x00000040;
pub const ECHO: ::tcflag_t = 0x20000;
pub const ECHOE: ::tcflag_t = 0x00000010;
pub const ECHOK: ::tcflag_t = 0x00000020;
pub const ECHONL: ::tcflag_t = 0x00000040;
pub const ECHOCTL: ::tcflag_t = 0x00020000;
pub const ECHOPRT: ::tcflag_t = 0x00040000;
pub const ECHOKE: ::tcflag_t = 0x00080000;
pub const IGNBRK: ::tcflag_t = 0x00000001;
pub const BRKINT: ::tcflag_t = 0x00000002;
pub const IGNPAR: ::tcflag_t = 0x00000004;
pub const PARMRK: ::tcflag_t = 0x00000008;
pub const INPCK: ::tcflag_t = 0x00000010;
pub const ISTRIP: ::tcflag_t = 0x00000020;
pub const INLCR: ::tcflag_t = 0x00000040;
pub const IGNCR: ::tcflag_t = 0x00000080;
pub const ICRNL: ::tcflag_t = 0x00000100;
pub const IXON: ::tcflag_t = 0x0001;
pub const IXOFF: ::tcflag_t = 0x00000400;
pub const IXANY: ::tcflag_t = 0x00001000;
pub const IMAXBEL: ::tcflag_t = 0x00010000;
pub const OPOST: ::tcflag_t = 0x00000001;
pub const ONLCR: ::tcflag_t = 0x00000004;
pub const OCRNL: ::tcflag_t = 0x00000008;
pub const ONOCR: ::tcflag_t = 0x00000010;
pub const ONLRET: ::tcflag_t = 0x00000020;
pub const CREAD: ::tcflag_t = 0x00000080;
pub const IEXTEN: ::tcflag_t = 0x00200000;
pub const TOSTOP: ::tcflag_t = 0x00010000;
pub const FLUSHO: ::tcflag_t = 0x00100000;
pub const PENDIN: ::tcflag_t = 0x20000000;
pub const NOFLSH: ::tcflag_t = 0x00000080;
pub const VINTR: usize = 0;
pub const VQUIT: usize = 1;
pub const VERASE: usize = 2;
pub const VKILL: usize = 3;
pub const VEOF: usize = 4;
pub const VEOL: usize = 5;
pub const VSTART: usize = 7;
pub const VSTOP: usize = 8;
pub const VSUSP: usize = 9;
pub const VMIN: usize = 4;
pub const VTIME: usize = 5;
pub const VEOL2: usize = 6;
pub const VDSUSP: usize = 10;
pub const VREPRINT: usize = 11;
pub const VDISCRD: usize = 12;
pub const VWERSE: usize = 13;
pub const VLNEXT: usize = 14;
pub const B0: ::speed_t = 0x0;
pub const B50: ::speed_t = 0x1;
pub const B75: ::speed_t = 0x2;
pub const B110: ::speed_t = 0x3;
pub const B134: ::speed_t = 0x4;
pub const B150: ::speed_t = 0x5;
pub const B200: ::speed_t = 0x6;
pub const B300: ::speed_t = 0x7;
pub const B600: ::speed_t = 0x8;
pub const B1200: ::speed_t = 0x9;
pub const B1800: ::speed_t = 0xa;
pub const B2400: ::speed_t = 0xb;
pub const B4800: ::speed_t = 0xc;
pub const B9600: ::speed_t = 0xd;
pub const B19200: ::speed_t = 0xe;
pub const B38400: ::speed_t = 0xf;
pub const EXTA: ::speed_t = B19200;
pub const EXTB: ::speed_t = B38400;
pub const IUCLC: ::tcflag_t = 0x00000800;
pub const OFILL: ::tcflag_t = 0x00000040;
pub const OFDEL: ::tcflag_t = 0x00000080;
pub const CRDLY: ::tcflag_t = 0x00000300;
pub const CR0: ::tcflag_t = 0x00000000;
pub const CR1: ::tcflag_t = 0x00000100;
pub const CR2: ::tcflag_t = 0x00000200;
pub const CR3: ::tcflag_t = 0x00000300;
pub const TABDLY: ::tcflag_t = 0x00000c00;
pub const TAB0: ::tcflag_t = 0x00000000;
pub const TAB1: ::tcflag_t = 0x00000400;
pub const TAB2: ::tcflag_t = 0x00000800;
pub const TAB3: ::tcflag_t = 0x00000c00;
pub const BSDLY: ::tcflag_t = 0x00001000;
pub const BS0: ::tcflag_t = 0x00000000;
pub const BS1: ::tcflag_t = 0x00001000;
pub const FFDLY: ::tcflag_t = 0x00002000;
pub const FF0: ::tcflag_t = 0x00000000;
pub const FF1: ::tcflag_t = 0x00002000;
pub const NLDLY: ::tcflag_t = 0x00004000;
pub const NL0: ::tcflag_t = 0x00000000;
pub const NL1: ::tcflag_t = 0x00004000;
pub const VTDLY: ::tcflag_t = 0x00008000;
pub const VT0: ::tcflag_t = 0x00000000;
pub const VT1: ::tcflag_t = 0x00008000;
pub const OXTABS: ::tcflag_t = 0x00040000;
pub const ONOEOT: ::tcflag_t = 0x00080000;
pub const CBAUD: ::tcflag_t = 0x0000000f;
pub const PARENB: ::tcflag_t = 0x00000100;
pub const PARODD: ::tcflag_t = 0x00000200;
pub const HUPCL: ::tcflag_t = 0x00000400;
pub const CLOCAL: ::tcflag_t = 0x00000800;
pub const CIBAUD: ::tcflag_t = 0x000f0000;
pub const IBSHIFT: ::tcflag_t = 16;
pub const PAREXT: ::tcflag_t = 0x00100000;
pub const ISIG: ::tcflag_t = 0x00000001;
pub const ICANON: ::tcflag_t = 0x00000002;
pub const XCASE: ::tcflag_t = 0x00000004;
pub const ALTWERASE: ::tcflag_t = 0x00400000;

// time.h
pub const CLOCK_PROCESS_CPUTIME_ID: ::clockid_t = 11;
pub const CLOCK_THREAD_CPUTIME_ID: ::clockid_t = 12;

// unistd.h
pub const STDIN_FILENO: ::c_int = 0;
pub const STDOUT_FILENO: ::c_int = 1;
pub const STDERR_FILENO: ::c_int = 2;
pub const _POSIX_VDISABLE: ::c_int = 0xff;
pub const _PC_LINK_MAX: ::c_int = 11;
pub const _PC_MAX_CANON: ::c_int = 12;
pub const _PC_MAX_INPUT: ::c_int = 13;
pub const _PC_NAME_MAX: ::c_int = 14;
pub const _PC_PATH_MAX: ::c_int = 16;
pub const _PC_PIPE_BUF: ::c_int = 17;
pub const _PC_NO_TRUNC: ::c_int = 15;
pub const _PC_VDISABLE: ::c_int = 18;
pub const _PC_CHOWN_RESTRICTED: ::c_int = 10;
pub const _PC_ASYNC_IO: ::c_int = 19;
pub const _PC_PRIO_IO: ::c_int = 21;
pub const _PC_SYNC_IO: ::c_int = 20;
pub const _PC_ALLOC_SIZE_MIN: ::c_int = 26;
pub const _PC_REC_INCR_XFER_SIZE: ::c_int = 27;
pub const _PC_REC_MAX_XFER_SIZE: ::c_int = 28;
pub const _PC_REC_MIN_XFER_SIZE: ::c_int = 29;
pub const _PC_REC_XFER_ALIGN: ::c_int = 30;
pub const _PC_SYMLINK_MAX: ::c_int = 25;
pub const _PC_2_SYMLINKS: ::c_int = 31;
pub const _PC_TIMESTAMP_RESOLUTION: ::c_int = 32;
pub const _PC_FILESIZEBITS: ::c_int = 22;
pub const _SC_ARG_MAX: ::c_int = 0;
pub const _SC_CHILD_MAX: ::c_int = 1;
pub const _SC_CLK_TCK: ::c_int = 2;
pub const _SC_NGROUPS_MAX: ::c_int = 3;
pub const _SC_OPEN_MAX: ::c_int = 4;
pub const _SC_JOB_CONTROL: ::c_int = 7;
pub const _SC_SAVED_IDS: ::c_int = 8;
pub const _SC_VERSION: ::c_int = 9;
pub const _SC_PASS_MAX: ::c_int = 45;
pub const _SC_PAGESIZE: ::c_int = _SC_PAGE_SIZE;
pub const _SC_PAGE_SIZE: ::c_int = 48;
pub const _SC_XOPEN_VERSION: ::c_int = 46;
pub const _SC_NPROCESSORS_CONF: ::c_int = 71;
pub const _SC_NPROCESSORS_ONLN: ::c_int = 72;
pub const _SC_STREAM_MAX: ::c_int = 5;
pub const _SC_TZNAME_MAX: ::c_int = 6;
pub const _SC_AIO_LISTIO_MAX: ::c_int = 7IZE: ::c_int b const SIGUSR1: ::cg_tTA:c_int = 7IZE: ::st _SC_JOB_CONTRO: ::cHRlagUSc_int = 21;
pub7nst _SC_PAGE_SIZEg_tAYst ITIc_int = 7IZE: :: const _SC_VERSIOF::c_int = 0x20;
8 const _SC_ARG_MAM::c_iN: ::cint = 0x20;
8const _SC_OPEN_MAMEMnt = 0x400;
pub 85onst _SC_OPEN_MAMEMnt =L: :t = 0o4000;
pu86onst _SC_OPEN_MAMEMORY00;
TECpub const _PC_TI87onst _SC_OPEN_MAME::c_iON: :nt = 37;
pub co8nst _SC_PAGE_SIZEMQAX: ::c_int = 3;
pub 89st _SC_PAGE_SIZEMQA: ::ct = 0x800;
pub c const _SC_ARG_MA: ::RITAGEDc_int = 21;
pub91const _SC_ARG_MA: ::RITY_FIFO3ULnt = 37;
pub co9_NPROCESSORS_ONLN ::c_int: ::c_icint = 0x20;
9st _SC_NGROUPS_MARt = ct = 0x800;
pub cconst _SC_OPEN_MASEM::HO:c_int = 24;
pu95onst _SC_OPEN_MASEM_NSEM::c_int = 9;
pub 96onst _SC_OPEN_MASEM_VALUint = 0x800;
pub cst _SC_JOB_CONTROL: ::cAMEMORY0R: :C= 32;
pub cons9nst _SC_PAGE_SIZEIGINTEUint = 0x800;
pub const BC_SCALESIZEI::cHRlaAGEDc_int = 21;
pubt PARENB: ::tcfM_MAXt ITS = 0o10000;
pub const IPC_SM_MAXt IT: ::c_int = 256;
pst _SC_NGROUPS_MA2_C_Bnt = 0x2000530a51t _SC_NGROUPS_MA2_C_long = 0x_PC_TIMESTAMP_RESOLUT_MA2_C_int = 48;
pub const5ESTAMP_RESOLUT_MA2_FORT_long = 0x_PC_TIM3STAMP_RESOLUT_MA2_FORT_c_int = 33;
pub const SC_SLB_T_MA2_ag_t EDEF_int = 34;
pub const SC_SLT_MA2_SW_long = 0x_PC_TIM6 const SC_SLT_MA2_U_int = 24;
pub53STAMP_RESOLUT_MA2_int = 48;
pub const31t _SC_NGROUPS_MA ::c_int = 1048576;
pub23t _SC_NGROUPS_MA ::X: ::c_int = 99;
pu24t _SC_NGROUPS_MA ::::c_int = 0x800;
pub 25t _SC_NGROUPS_MA :::: ::c_int = 99;
pub c26 const SC_SLT_MAMAX: ::c_int = 128;
pub cons5PARENB: ::tcfM_MAS_MAX: ::c_int = 4;
pub c2nst _SC_PAGE_SIZEt = c_int = 4;
pub c29NPROCESSORS_ONLN :_DUPDD: ::c_int = 23;
pub const AFSIZE: ::c_CRY= 0x20005314;
56pub const AFSIZE: ::c_ENH_I18N= 56;
pub const SC_SPCM_STSIZE: ::c_10000000;
pub c5b const SC_SLT_MA2_X: :_M: ::c_int = 14;54t SC_SPCM_STSIZE: ::c_XCU_int = 48;
pub const109NPROCESSORS_ONLNATED: :c_int = 9;
pub cst SC_SPCM_STSIZEZE: ::c_int = 4096;5nst _SC_PAGE_SIZE: ::c_int = AF_UNSPEC;73t _SC_NGROUPS_MATEZE: ::c_int = 4096; const _SC_ARG_MA:: ::: ::c= 0xff;
pub co3t _SC_NGROUPS_MAAV:: ::: ::c= 0xff;
pub co4t SC_SPCM_STSIZEockid_t:c_iRUCTOR_IM: Apub S = 0o10000;
pu1t _SC_NGROUPS_MAGETGR_R_int = _int = 3;
pub 81t _SC_NGROUPS_MAGETPW_R_int = _int = 3;
pub 8ESTAMP_RESOLUT_MALOG_in ::c_int = 5;
pub co83t SC_SPCM_STSIZEockid_tint _int = 5;
pub con8t SC_SPCM_STSIZEockid_t = 0x= 20;
pub const 69t SC_SPCM_STSIZEockid_t::c_intIc_int = 7IZE: ::PARENB: ::tcfM_MAXTY_: ::c_int = 13;
pub c04t SC_SPCM_STSIZEockid_S_int = 59;
pub const SC_NXSIZEockid_t:c_it = 0xnt = 37;
pub con61 const SC_NXSIZEockid_t:c_it = 0xPAGE_SIZE;
pub c62 const SC_NXSIZEockid_t: ::RITY_FIFO3ULnt = 37;
pub co64 const SC_NXSIZEockid_t: :::c_HER = 0x01000000;65 const SC_NXSIZEockid_t: :::0;
TECp;
pub const PTT_WRITE_FPSCSIZEockid_t: 

// tE: ::c_int = 0;
pu67t SC_SPCM_STSIZEockid_t AFE_FUNCpub S = 0o10000;
59st _SC_PAGE_SIZE: ::c_LEGACY= 0xff;
pub co2st _SC_PAGE_SIZE: ::c_ ::c_int = 9;f;
pub co0st _SC_PAGE_SIZE: ::c_ ::c_intEockid_S_int = 59;
p111 const SC_NXSIZEXBS5_ILP32_OFF32t = 13;
pub c05 const SC_NXSIZEXBS5_ILP32_OFFB= 0x20005309;
106 const SC_NXSIZEXBS5_LP64_OFF_PC: ::c_int =107 const SC_NXSIZEXBS5_LP;

/OFFB= 0x20005309;
108 const SC_SLT_MA2_Pc_int = 11;
pubMESTAMP_RESOLUT_MA2_Pc_::c_OU ::c 0x20005309;
1M3STAMP_RESOLUT_MA2_Pc_:IFOCKPO: ::c_int = 29;1 const SC_SLB_T_MA2_Pc_:ag_tint = AF_ISO;
pub const SC_SLT_MA2_Pc_:ME::c_it = AF_ISO;
pu6 const SC_SLT_MA2_Pc_:: ::::c_int = 17;
3st _SC_JOB_CONTRO:DVISORY0= 0x00000008;
pu1;
pub const AFSIZEBARRIITS = 0o10000;
p38nst _SC_CHILD_MAX:_RDM: LECpub const _PC_TI139st _SC_PAGE_SIZE = 11;
t = 13;
pub co
pub const AFSIZES: :_: ::c_int = 13;
pub c26 const SC_SLT_MAas clockiAX:_RDt = 13;
pub co1NPROCESSORS_ONLN ::DIT:: ::cR:ag_K_int = 13;
pub _NPROCESSORS_ONLN :GS_Mt = 13;
pub c2st _SC_JOB_CONTROL:Ent = 9;
pub con2nst _SC_PAGE_SIZESPAW const _PC_TI143st _SC_PAGE_SIZESP_inag_K_int = 13;
pub const _SC_OPEN_MASPORADIMASER:c_int = 61;
pu1const _SC_PASS_MAXSTE: ::c_int = 13;
pub c56pub const AFSIZE::c_OOPc_int = 13;
pub c29t SC_SPCM_STSIZEockid_t = 11;
t = 13;
pub coTT_WRITE_FPSCSIZEockid_tSPORADIMASER:c_int = 61;
pu1c7 const IPC_SM_MAXt IOUrsions")]
pub const _SC_PAGE_SIZE ::c_int = 60;
pu149st _SC_PAGE_SIZE ::c__EVP: :: :Tc_int = 61;
pu15PARENB: ::tcfM_MA ::c__EVP: :: ::c_int = 13;
pub cnst SC_SPCM_STSIZE ::c__c_HER = 0x01000000;151t _SC_NGROUPS_MA ::c__LOG 0x01000000;152t _SC_NGROUPS_MA ::c__: ::c_int = 13;
pub cnnst _SC_PAGE_SIZE ::c_EN: c_int = 13;
pub cn9st _SC_PAGE_SIZE ::c__N: :_EVP: :_int = 14;
pub coPARENB: ::tcfM_MA YP:cAMEMORY0R: :C= 32;
pub cons153STAMP_RESOLUT_MAV6_ILP32_OFF32t = 13;
pub c21STAMP_RESOLUT_MAV6_ILP32_OFFB= 0x20005309;
1t _PC_FILESIZEBITSV6_LP64_OFF_PC: ::c_int =123_PC_FILESIZEBITSV6_LP;

/OFFB= 0x20005309;
124t SC_SPCM_STSIZE: ::c_: ::c__int = 11;
pub onst _SC_PASS_MAXIPV632;
pub cons154t SC_SPCM_STSIZERAWET: ::c 32;
pub cons155D_CPUTItmp: ::clockid_tED: ::c_int20;
pub st RUSAGE_CHILc_i ::c_int =20;
pub 
pub const B50OOT_11;
t = 1320;
pub 2s.h
pub const D_11;
t = 1320;
pub 3_PC_FILESIZENEW_11;
t = 1320;
pub  I_SWROPT: ::cN: : ::c_int = -120;
pub 5 LOG_NFACILITIE_in ::c_int = -120;
pub TT_WRITE_FPSCN: :_ ::c_int = -120;
pub st SC_SPCM_STDid_t: 

// t = -120;
pub ;
pub const ATc_OU ::c 0x200020;
pub IOCRf! {
    ub cfn C: ::FIRSTHDR(mhdr: *onst Amsghdr) -> *mut cmsghdr {
        if (*mhdr).msg_onstrollenLTIMusize >=x20mem::size_of::<cmsghdr>() {
            (*mhdr).msg_onstrolLTIM*mut cmsghdr
        } else {
            0LTIM*mut cmsghdr
        }
    }

    ub cfn C: ::NXTHDR(mhdr: *onst Amsghdr, cmsg: *onst Acmsghdr) -> *mut cmsghdr {
        if cmsg.is_null() {
            C: ::FIRSTHDR(mhdr)
        } else {
            if (cmsgLTIMusize + (*cmsg).cmsg_lenLTIMusize +x20mem::size_of::<200msghdr>()) >
                ((*mhdr).msg_onstrolLTIMusize + (*mhdr).msg_onstrollenLTIMusize) {
                0LTIM*mut 200msghdr
            } else {
                PUTAIX does#[de have any alignment/padding for ancillary data, so we don't need _C: :: = 29 here.
                (cmsgLTIMusize + (*cmsg).cmsg_lenLTIMusize)LTIM*mut cmsghdr
            }
        }
    }

    ub cfn C: ::onst(cmsg: *onst A200msghdr) -> *mut ar = 2;
pu{
        (cmsgLTIM*mut ar = 2;
p).offset(20mem::size_of::<200msghdr>()LTIMisize)
    }

    ub c{onst }cfn C: ::LEN(lengthg = 0x0b c) -> = 0x0b cu{
        20mem::size_of::<200msghdr>()LTIM= 0x0b cu+ length
    }

    ub c{onst }cfn C: ::SPACE(lengthg = 0x0b c) -> = 0x0b cu{
        20mem::size_of::<200msghdr>()LTIM= 0x0b cu+ length
    }

    ub cfn FD_ZERO(snt =*mut fd_snt) -> () {
        for slde in (*snt).fds_bits.iter_mut() {
            *slde 6; co        }
    }

    ub cfn 000;

(fd32;
pub c, snt =*mut fd_snt) -> () {
        let bits = 20mem::size_of::<200_040;>()L* ;
p        let fd = fd TIMusize
p        (*snt).fds_bits[fd / bits] |b 
nst (fd % bits)
p        return
    }

    ub cfn 000CLR(fd32;
pub c, snt =*mut fd_snt) -> () {
        let bits = 20mem::size_of::<200_040;>()L* ;
p        let fd = fd TIMusize
p        (*snt).fds_bits[fd / bits] &= !(
nst (fd % bits))
p        return
    }

    ub cfn 000IS;

(fd32;
pub c, snt =*onst Afd_snt) -> boolL{
        let bits = 20mem::size_of::<200_040;>()L* ;
p        let fd = fd TIMusize
p        return ((*snt).fds_bits[fd / bits] & (
nst (fd % bits))) !6; 
    }

    ub cfn major(dev32;
dev_c) -> = 0x0b cu{
        let x = dev >> cons        xLTIM= 0x0b c
    }

    ub cfn minor(dev32;
dev_c) -> = 0x0b cu{
        let y = dev & 0xFFFFns        yLTIM= 0x0b c
    }

    ub cfn makedev(majorg = 0x0b c, minorg = 0x0b c) -> = dev_cu{
        let major = major TIM= dev_c
p        let minor = minor TIM= dev_c
p        let mut dev 6; co        dev |= major st cons        dev |= minorns        dev
    }
}

safe_f! {
    ub c{onst }cfn WIFnt = _W(E_OMus32;
pub c) -> boolL{
        (E_OMus & c_int = _W) !6; 
    }

    ub c{onst }cfn Wnt =SIG(E_OMus32;
pub c) -> ;
pub co{
        if WIFnt = _W(E_OMus) {
            (((E_OMus TIM= 0x0b c) >> 8) & 0xff)LTIM= 0xb c
        } else {
            -1o        }
    }

    ub c{onst }cfn WIFED: ::(E_OMus32;
pub c) -> boolL{
        (E_OMus & 0xFF) =6; 
    }

    ub c{onst }cfn WED: c_int (E_OMus32;
pub c) -> ;
pub co{
        if WIFED: ::(E_OMus) {
            (((E_OMus TIM= 0x0b c) >> 8) & 0xff)LTIM= 0xb c
        } else {
            -1o        }
    }

    ub c{onst }cfn WIF ::c_i::(E_OMus32;
pub c) -> boolL{
        !WIFED: ::(E_OMus) && !WIFnt = _W(E_OMus)
    }

    ub c{onst }cfn WM: :SIG(E_OMus32;
pub c) -> ;
pub co{
        if WIFn::c_i::(E_OMus) {
            (((E_OMus TIM= 0x0b c) >> 16) & 0xff)LTIM= 0xb c
        } else {
            -1o        }
    }

    ub c{onst }cfn WIFD: ::c_in(E_OMus32;
pub c) -> boolL{
        (E_OMus & ED: ::c_in) !6; 
    }

    PUTAIX doesn't have native W::c_: ::.
    ub c{onst }cfn W::c_: ::(_E_OMus32;
pub c) -> boolL{
        false
    }
}

#[link(namprecathread"Notextern "C" {
    ub cfn thr_kill(id32thread_c, sig32;
pub c) -> ;
pub c;
    ub cfn thr_self() -> thread_c;
}

#[link(namprecapthread"Notextern "C" {
    ub cfn pthread_atfork(
        prepare32;
Option<unsafe extern "C" fn()>,
        parent32;
Option<unsafe extern "C" fn()>,
        child32;
Option<unsafe extern "C" fn()>,
    ) -> ;
pub c;
    ub cfn pthread_attr_getguardsize(
        attr: *onst A20pthread_attr_t,
        guardsize:M*mut arsize_t,
    ) -> ;
pub c;
    ub cfn pthread_attr_setguardsize(attr: *mut arpthread_attr_t, guardsize:Marsize_t) -> ;
pub c;
    ub cfn pthread_attr_getLIMITparam(
        attr: *onst A20pthread_attr_t,
        param: *mut LIMIT_param,
    ) -> ;
pub c;
    ub cfn pthread_attr_getE_Ock(
        attr: *onst A20pthread_attr_t,
        E_Ockaddr: *mut *mut ar =void,
        E_Ocksize:M*mut arsize_t,
    ) -> ;
pub c;
    ub cfn pthread_attr_setLIMITparam(
        attr: *mut arpthread_attr_t,
        param: *onst ALIMIT_param,
    ) -> ;
pub c;
    ub cfn pthread_barrier_de: ::y(barrier: *mut pthread_barrier_t) -> ;
pub c;
    ub cfn pthread_barrier_init(
        barrier: *mut pthread_barrier_t,
        attr: *onst A20pthread_barrierattr_t,
        countg = 0x0b c,
    ) -> ;
pub c;
    ub cfn pthread_barrier_ AT_(barrier: *mut pthread_barrier_t) -> ;
pub c;
    ub cfn pthread_barrierattr_de: ::y(attr: *mut arpthread_barrierattr_t) -> ;
pub c;
    ub cfn pthread_barrierattr_getpshared(
        attr: *onst A20pthread_barrierattr_t,
        shared: *mut ar =b c,
    ) -> ;
pub c;
    ub cfn pthread_barrierattr_init(attr: *mut arpthread_barrierattr_t) -> ;
pub c;
    ub cfn pthread_barrierattr_setpshared(
        attr: *mut arpthread_barrierattr_t,
        shared: ar =b c,
    ) -> ;
pub c;
    ub cfn pthread_cancel(thread: arpthread_t) -> ;
pub c;
    ub cfn pthread_onsdattr_getst CL(
        attr: *onst Apthread_onsdattr_t,
        ct CL_id: *mut st CLOCK_,
    ) -> ;
pub c;
    ub cfn pthread_cnsdattr_getpshared(
        attr: *onst Apthread_onsdattr_t,
        pshared: *mut ar =b c,
    ) -> ;
pub c;
    ub cfn pthread_onsdattr_setst CL(
        attr: *mut pthread_onsdattr_t,
        ct CL_id: onst CLOCK_,
    ) -> ;
pub c;
    ub cfn pthread_onsdattr_setpshared(attr: *mut pthread_onsdattr_t, pshared: ;
pub c) -> ;
pub c;
    ub cfn pthread_oreate(
        native: *mut arpthread_t,
        attr: *onst A20pthread_attr_t,
        f: extern "C" fn(*mut ar =void) -> *mut ar =void,
        value: *mut ar =void,
    ) -> ;
pub c;
    ub cfn pthread_getattr_np(native: arpthread_t, attr: *mut arpthread_attr_t) -> ;
pub c;
    ub cfn pthread_getcpust CLOC(thread: arpthread_t, ctL_id: *mut onst CLOCK_) -> ;
pub c;
    ub cfn pthread_getLIMITparam(
        thread: arpthread_t,
        policy: *mut ar =b c,
        param: *mut LIMIT_param,
    ) -> ;
pub c;
    ub cfn pthread_kill(thread: arpthread_t, signal: ;
pub c) -> ;
pub c;
    ub cfn pthread_mutex_onssistent(mutex: *mut arpthread_mutex_c) -> ;
pub c;
    ub cfn pthread_mutex_ ::tdt CL(
        t CL: *mut pthread_mutex_ ,
        abs ::t: *onst A20 ::tspec,
    ) -> ;
pub c;
    ub cfn pthread_mutexattr_getprotocol(
        attr: *onst Apthread_mutexattr_c,
        protocol: *mut ar =b c,
    ) -> ;
pub c;
    ub cfn pthread_mutexattr_getpshared(
        attr: *onst Apthread_mutexattr_c,
        pshared: *mut ar =b c,
    ) -> ;
pub c;
    ub cfn pthread_mutexattr_getrobust(
        attr: *mut arpthread_mutexattr_c,
        robust: *mut ar =b c,
    ) -> ;
pub c;
    ub cfn pthread_mutexattr_setprotocol(
        attr: *mut pthread_mutexattr_c,
        protocol: ar =b c,
    ) -> ;
pub c;
    ub cfn pthread_mutexattr_setpshared(
        attr: *mut pthread_mutexattr_c,
        pshared: ar =b c,
    ) -> ;
pub c;
    ub cfn pthread_mutexattr_setrobust(
        attr: *mut arpthread_mutexattr_c,
        robust: ar =b c,
    ) -> ;
pub c;
    ub cfn pthread_rwt CLattr_getpshared(
        attr: *onst Apthread_rwt CLattr_t,
        val: *mut ar =b c,
    ) -> ;
pub c;
    ub cfn pthread_rwt CLattr_setpshared(attr: *mut pthread_rwt CLattr_t, val: ;
pub c) -> ;
pub c;
    ub cfn pthread_setLIMITparam(
        thread: arpthread_t,
        policy: ar =b c,
        param: *onst ALIMIT_param,
    ) -> ;
pub c;
    ub cfn pthread_setLIMITprio(native: arpthread_t, priority: ;
pub c) -> ;
pub c;
    ub cfn pthread_sigmask(how32;
pub c, snt =*onst Asigsnt_t, oldsnt =*mut sigsnt_t) -> ;
pub c;
    ub cfn pthread_spin_de: ::y(t CL: *mut pthread_spint CL_t) -> ;
pub c;
    ub cfn pthread_spin_init(t CL: *mut pthread_spint CL_t, pshared: ;
pub c) -> ;
pub c;
    ub cfn pthread_spin_t CL(t CL: *mut pthread_spint CL_t) -> ;
pub c;
    ub cfn pthread_spin_tryt CL(t CL: *mut pthread_spint CL_t) -> ;
pub c;
    ub cfn pthread_spin_unt CL(t CL: *mut pthread_spint CL_t) -> ;
pub c;
}

#[link(namprecaionsv"Notextern "C" {
    ub cfn ionsv(
        cd: ionsv_t,
        inbuf: *mut *mut ar =2;
p,
        inbytesleft:M*mut arsize_t,
        outbuf: *mut *mut ar =2;
p,
        outbytesleft:M*mut arsize_t,
    ) -> ;
size_t;
    ub cfn ionsv_st se(cd: ionsv_t) -> ;
pub c;
    ub cfn ionsv_open(tocodt: *onst A20 =2;
p, fromcodt: *onst A20 =2;
p) -> ionsv_t;
}

extern "C" {
    ub cfn acct(filenamp: *onst A20 =2;
p) -> ;
pub c;
    ub cfn aio_cancel(filde:32;
pub c, aiocbp:M*mut araiocb) -> ;
pub c;
    ub cfn aio_error(aiocbp:M*mut araiocb) -> ;
pub c;
    #[link_nampreca_posix_aio_fsync"]
    ub cfn aio_fsync(op32;
pub c, aiocbp:M*mut araiocb) -> ;
pub c;
    ub cfn aio_read(aiocbp:M*mut araiocb) -> ;
pub c;
    // ub cfn aio_suspend
    // ub cfn aio_write
    ub cfn basenamp(pathg *mut ar =2;
p) -> *mut ar =2;
p;
    ub cfn bind(s CLnt = AF_SNA, address: *onst A20s CLaddr, address_len:A20s CLlen_t) -> ;
pub c;
    ub cfn brk(addr: *mut ar =void) -> ;
pub c;
    ub cfn clearenv() -> ;
pub c;
    ub cfn cl CL_getcpust CLOC(pid: onpid_t, ctL_id: *mut onst CLOCK_) -> ;
pub c;
    ub cfn cl CL_getres(ctL_id: onst CLOCK_, tp:M*mut ar ::tspec) -> ;
pub c;
    ub cfn cl CL_get ::t(ctL_id: onst CLOCK_, tp:M*mut ar ::tspec) -> ;
pub c;
    ub cfn cl CL_nanosleep(
        clL_id: onst CLOCK_,
        flags: ar =b c,
        rqtp:M*onst A20 ::tspec,
        rmtp:M*mut ar ::tspec,
    ) -> ;
pub c;
    ub cfn cl CL_set ::t(ct CL_id: onst CLOCK_, tp:M*onst A20 ::tspec) -> ;
pub c;
    ub cfn creat64(pathg *onst Ac=2;
p, modt: modtK_) -> ;
pub c;
    ub cfn cRC: :d(sg *mut ar =2;
p) -> *mut ar =2;
p;
    ub cfn dirfd(dirp:M*mut arDIR) -> ;
pub c;
    ub cfn dirnamp(pathg *mut ar =2;
p) -> *mut ar =2;
p;
    ub cfn drand48() -> ;
pudouble;
    ub cfn dupt Cale(argg_t =t CaleK_) -> ;
t CaleK_;
    ub cfn endgrent();
    ub cfn endmntent(: :eamp:M*mut ar: ::) -> ;
pub c;
    ub cfn endpwent();
    ub cfn endutent();
    ub cfn endutxent();
    ub cfn erand48(xseed: *mut ar =u20;
p) -> ;
pudouble;
    ub cfn faccessat(
        dirfd: ar =b c,
        pathnamp: *onst A20 =2;
p,
        modt: ar =b c,
        flags: ar =b c,
    ) -> ;
pub c;
    ub cfn fattach(filde:32;
pub c, pathg *onst A20 =2;
p) -> ;
pub c;
    ub cfn fdatasync(fd: ;
pub c) -> ;
pub c;
    ub cfn fexecve(
        fd: ar =b c,
        argvg *onst A*onst A20 =2;
p,
        envpg *onst A*onst A20 =2;
p,
    ) -> ;
pub c;
    ub cfn ffs(value: ;
pub c) -> ;
pub c;
    ub cfn ffsl(value: ;
pu040;) -> ;
pub c;
    ub cfn ffsll(value: ;
pu040;040;) -> ;
pub c;
    ub cfn fgetgrent(file:M*mut ar: ::) -> *mut argroup;
    ub cfn fgetpos64(: :eam:M*mut ar: ::, ptr: *mut fpos64K_) -> ;
pub c;
    ub cfn fgetpwent(file:M*mut ar: ::) -> *mut arpasswd;
    ub cfn fopen64(filenamp: *onst Ac=2;
p, modt: *onst Ac=2;
p) -> *mut ar: ::;
    ub cfn freet Cale(t C_t =t CaleK_);
    ub cfn freopen64(
        filenamp: *onst Ac=2;
p,
        modt: *onst Ac=2;
p,
        file:M*mut ar: ::,
    ) -> *mut ar: ::;
    ub cfn fseeko64(: :eam:M*mut ar: ::, offset_t =off64K_, whence: ;
pub c) -> ;
pub c;
    ub cfn fsetpos64(: :eam:M*mut ar: ::, ptr: *onst Afpos64K_) -> ;
pub c;
    ub cfn fE_OM64(filde:32;
pub c, buf: *mut E_OM64) -> ;
pub c;
    ub cfn fE_OMfs(fd32;
pub c, buf: *mut E_OMfs) -> ;
pub c;
    ub cfn fE_OMfs64(fd32;
pub c, buf: *mut E_OMfs64) -> ;
pub c;
    ub cfn fE_OMvfs64(fd32;
pub c, buf: *mut E_OMvfs64) -> ;
pub c;
    ub cfn ftello64(: :eam:M*mut ar: ::) -> ;
off64K_;
    ub cfn ftok(pathg *onst A20 =2;
p, id: ;
pub c) -> ;
keyK_;
    ub cfn ftruncate64(fd32;
pub c, lengthg off64K_) -> ;
pub c;
    ub cfn fu ::tns(fd32;
pub c,  ::ts:M*onst A20 ::tspec) -> ;
pub c;
    ub cfn getcontext(ucp:M*mut ucontextK_) -> ;
pub c;
    ub cfn getdomainnamp(namp: *mut ar =2;
p, len:A20pub c) -> ;
pub c;
    ub cfn getdtablesize() -> ;
pub c;
    ub cfn getgrent() -> *mut argroup;
    ub cfn getgrg:d(gid: ;
gOCK_) -> *mut argroup;
    ub cfn getgrg:d_r(
        gid: ;
gOCK_,
        grp:M*mut argroup,
        buf: *mut 20 =2;
p,
        buflen:A20size_t,
        result: *mut *mut argroup,
    ) -> ;
pub c;
    ub cfn getgrnam(namp: *onst A20 =2;
p) -> *mut argroup;
    ub cfn getgrnam_r(
        namp: *onst A20 =2;
p,
        grp:M*mut argroup,
        buf: *mut 20 =2;
p,
        buflen:A20size_t,
        result: *mut *mut argroup,
    ) -> ;
pub c;
    ub cfn getgrset(::c_g *mut ar =2;
p) -> *mut ar =2;
p;
    ub cfn gethost:d() -> ;
pu040;;
    ub cfn getmntent(: :eam:M*mut ar: ::) -> *mut armntent;
    ub cfn getnampinfo(
        sa: *onst A20s CLaddr,
        salen:A20size_t,
        host: *mut 20 =2;
p,
        hostlen:A20size_t,
        :c_v: *mut 20 =2;
p,
        :c_vlen:A20size_t,
        flags: ar =b c,
    ) -> ;
pub c;
    ub cfn getpagesize() -> ;
pub c;
    ub cfn getpeereid(s CLnt = AF_SNA, euid: *mut onuOCK_, egid: *mut ongOCK_) -> ;
pub c;
    ub cfn getpriority(which = AF_SNA, who = AOCK_) -> ;
pub c;
    ub cfn getpwent() -> *mut arpasswd;
    ub cfn getpwnam_r(
        namp: *onst A20 =2;
p,
        pwd: *mut passwd,
        buf: *mut 20 =2;
p,
        buflen:A20size_t,
        result: *mut *mut passwd,
    ) -> ;
pub c;
    ub cfn getpwu:d_r(
        uid: ;
uOCK_,
        pwd: *mut passwd,
        buf: *mut 20 =2;
p,
        buflen:A20size_t,
        result: *mut *mut passwd,
    ) -> ;
pub c;
    ub cfn getrlimit(resource: ;
pub c, rlim: *mut 20rlimit) -> ;
pub c;
    ub cfn getrlimit64(resource: ;
pub c, rlim: *mut rlimit64) -> ;
pub c;
    ub cfn get ::tofday(tp:M*mut ar ::tval,  z: *mut ar =void) -> ;
pub c;
    ub cfn geti ::tr(which = AF_SNA, curr_value: *mut ari ::trval) -> ;
pub c;
    ub cfn getutent() -> *mut Itmp;
    ub cfn getutid(u: *onst AItmp) -> *mut Itmp;
    ub cfn getutline(u: *onst AItmp) -> *mut Itmp;
    ub cfn getutxent() -> *mut Itmpx;
    ub cfn getutxid(ut: *onst AItmpx) -> *mut Itmpx;
    ub cfn getutxline(ut: *onst AItmpx) -> *mut Itmpx;
    ub cfn glob(
        pattern: *onst A20 =2;
p,
        flags: ar =b c,
        errfunc32;
Option<extern "C" fn(epathg *onst A20 =2;
p, errno:A20pub c) -> ;
pub c>,
        pglob: *mut onglobK_,
    ) -> ;
pub c;
    ub cfn globfree(pglob: *mut onglobK_);
    ub cfn hasmntopt(mntg *onst A20mntent, opt: *onst A20 =2;
p) -> *mut ar =2;
p;
    ub cfn horeate(nelt:Marsize_t) -> ;
pub c;
    ub cfn hde: ::y();
    ub cfn hsearch(entry: entry, action:A20pub c) -> *mut entry;
    ub cfn if_freenampindex(ptr: *mut if_nampindex);
    ub cfn if_nampindex() -> *mut if_nampindex;
    ub cfn initgroups(namp: *onst A20 =2;
p, basegid: ;
gOCK_) -> ;
pub c;
    ub cfn ioctl(filde:32;
pub c, request: ar =b c, ...) -> ;
pub c;
    ub cfn jrand48(xseed: *mut ar =u20;
p) -> ;
pu040;;
    ub cfn lonsg48(p: *mut ar =u20;
p);
    ub cfn lfind(
        key: *onst A20 =void,
        base: *onst A20 =void,
        nelp:M*mut arsize_t,
        widthg = size_t,
        compar32;
Option<unsafe extern "C" fn(*onst A20 =void, *onst A20 =void) -> ;
pub c>,
    ) -> *mut ar =void;
    ub cfn lio_list:o(
        modt: ar =b c,
        aiocb_listg *onst A*mut aiocb,
        nitems: ar =b c,
        sevp =*mut sigeve c,
    ) -> ;
pub c;
    ub cfn loadquery(flags: ar =b c, buf: *mut 20 =2;
p, buflen:A200x0b c) -> = 0xb c;
    ub cfn lpar_get_info(command: ar =b c, buf: *mut 20 =void, bufsize:Marsize_t) -> ;
pub c;
    ub cfn lpar_snt_resources(id32;
pub c, resource: *mut ar =void) -> ;
pub c;
    ub cfn lrand48() -> pu040;;
    ub cfn lsearch(
        key: *onst A20 =void,
        base: *mut ar =void,
        nelp:M*mut arsize_t,
        widthg = size_t,
        compar32;
Option<unsafe extern "C" fn(*onst A20 =void, *onst A20 =void) -> ;
pub c>,
    ) -> *mut ar =void;
    ub cfn lseekc;
    ub cfn fgc*mut *mut p_NXSIZEockid_oid, *onst A20 =void) -> ;
purLcfn f    ub cfn lseekcop316 pwut araiost A20 =void) -> ;
pub c>cfn lsearch(
st A20 =void,
  KOtFAArTh9RCn lsearch(1T1OPPED;
pub const _W_STOPh;
uOCK_,
   O:arch7EoTc-> ;
pub c;
   
  KOtFAArTh9RCllp, but A20 =RCllp, b
  KOtFAArTh9RCllcfn hread:  ;
pub c;t A*onst A20 =2;
p,
    ) -> ;
pub c;
 memmemc;
    ub haytr_t, lrand48() -> pu040;;
    uhaytr_t, *mut passwd,
        bny al cfn lfind(
        key: *onst al  *mut passwd,
     n(*onst A20 =void, *onst A20 =vmemvoidsAc=2;
p, modtA20 =vsmax) -> ;
pub cc-> ;
pub c;net_info(command: ar =b c, buf: *mutmincor316 pwut ze_t,
        cooid) -> ;
pub cvect argroup,
    ) -> : ar =b c, buf: *mutmkfifoat(u20;
p) -> ;
pu    ub cfn faccessat(
        ) -> *pub c;
    ub cfn creat64(pathgmknodd: *mut ar =u20;
p) -> ;
pudouble;
    ub cfn faccessat(
        dirfd: ar =b cpub c;,; co        : r = m
        nitems: ar =b c,
     m     >> n lsefaccessat(
      s: ar =b c,
        errmut sigeve c,
   nitems: ar =b c,
     mcol(ect16 pwut araiost A20 =void) -> ;
pub ccol(igeve c,
   nitems: ar =b c,
     mqt:M*mutmq
p) -mq
_
   nitems: ar =b c,
     mqt *mut atmq
p) -mq
_
 c;
    ub cfn mqt;
     nitems: ar =b c,
     mqtnotifytmq
p) -mq
_
 cnotificab cfn > *mut arm aiocb,   nitems: ar =b c,
     mqtonsv_b cfn faccessat(
      omut -> ;
pub c;
    ub cfmq
_
r =b c,
     mqtrecein fdatasync(mq
p) -mq
_
 datasync(msg_ptr  uid: ;
uOCK_,
        p= 29 heut passwd,
        bmsg_priod: *mut ar ==2;
p,
        :s;
p,
        outbytmqtse   ub cfn lomq
p) -mq
_
 datasync(msg_ptr  uaccessat(
        dirfd:  29 heut passwd,
        bmsg_priod:attr: *onst A20pthread_barrierattr_t,
 mqtsemut atmq
p) -mq
_
 cnewad_oreate(
    mqt;
  fn pt;
    ub cfn mqt;
     nitems: ar =b c,
     mqtthrearecein fdatasync(mq
p) -mq
_
 datasync(msg_ptr  uid: ;
uOCK_,
        p= 29 heut passwd,
        bmsg_priod: *mut ar ==2;
p,
  x_ ::tdtthreout(
        t CL: *mut pthread_muts;
p,
        outbytmqtthrease   ub cfn lomq
p) -mq
_
 datasync(msg_ptr  uaccessat(
        dirfd:  29 heut passwd,
        bmsg_priod:attr: *onst A2x_ ::tdtthreout(
        t CL: *mut pthread_mutms: ar =b c,
     mqtunt CL(t CL -> ;
pub c;
    ub cfn fattach(filde:32;
m c, resource: *mut ar =void) ->msg20 =msqMarsize_t) ->cm200x0b c) -> = 0xb c;
msqMa_dub c;
    ub cfn fE_OMfs(fmsg *m(cfn l  ub cf,fmsgfl"Notextern "C" {
    ub cfn thr_kilmsgrc
#[link(nammsqMarsize_t) -        bmsgpn lsearch(
        key: *msgszut passwd,
        bmsgtypl(value: ;
        bmsgfl"Notexternt pthread_muts;
p,
        outbytmsgs   ub cfn lomsqMarsize_t) -        bmsgpn l lfind(
        key: *onmsgszut passwd,
        bmsgfl"Notexternt pthread_mut    ub cfn thr_kilms pat6 pwut araiost A20 =void) -> ;
pub cmut sigeve c,
   nitems: ar =b c,
     new modt: priop, id: ;
pubmodt:ex() -> *mut if_nampindfn drand48() -> ;
pudouble;
    ub cfn dnl_langp, bub c,fn dnl_b c, hasmntopt(mntg *onst A20mntentnl_langp, b_lub c,fn dnl_b c,pubmofn drand48() -> ;ntopt(mntg *onst A20mntentnub c, request: ar =b c, ...) -> ;
pub c;
    ub cfn jra   ub c_NXSIZEockid_oid, *onomut -> ;
pub c;
    ub cfead_spin_tryt CL(t ollvoid opt: *maxhg *onst A20 =2; ollvoidspin_tryt CL(t ollvoid t) -> ;
pub psig ollvoidsfn pthread_sel t)_arraIMITpara_seld t)) -> ;
pub craI_0x0b cu+ len: *onst Apthread_rwt CLattr_t,
    ollvoid cfn horpsig ollvoidspthread_rwt CLattr_t,
    ollvoid oll -> ;
pub psig ollvoidsfn pthread_selub c_arraIMITpara::_selfd) -> ;
pub craI_0x0b cu+ len: *onst Ac) ->hreout(
 len: *onst Apthread_rwt CLattr_t,
    ollvoidevp =*psig ollvoidsf _selfddevp =MITpara::_selfdpthread_rwt CLattr_t,
    onsv_flen:A200: ::) -> *mut arpasswd;
    ub cfn fopen64(filenamp: *onst Ac=2iocbp:fekcop31;
pub c>,
    ) -> *m;
pub_t=void) ->pub_t=vekcop3read_spin_init(t CL: *mut pthread_socbp:fekcop3b cfn freet Carsize_t) -        bmut ar: ::;
    ubjor TIM= den: ::;
    ubjor TIM= ekcop3read_spinonst Apthread_rwt CLattr_t,
    ocbp:felrandt31;
pub c>,
    ) -> *m;
pub_t=void) ->pub_tpthread_rwt CLattr_t,
    ocbp:felrandt3-> ;
pub c>,
    ) -> *m::;
    ub den: ::;
    upthread_rwt CLattr_t,
    ocbp:eekcop316 pwut araiost A20 =void) -> ;
pub c>cfn lsearch(
st A20 =void,
  KOtFAArTh9 ocbp:spawn -> ;
pub pfn getpeerep) -> ;
pub c;
 : ar =b c,
        erfilenamp: *on_ ub cfK_) -> ;
pub ocbp:spawn_ *on_ ub cfKub cfn pthread_op_) -> ;
pub ocbp:spawnLattr_getpshared c;
    ub cfnid: ;
uOCK_,
        p =b c,
       id: ;
uOCK_,
     t A20 =void,
  KOtFAArTh9 ocbp:spawn_ *on_ ub cfKu6 p:M*mutetpshared ub cfK_) para_scbp:spawn_ *on_ ub cfKub cfn pthrefdread_spinonst Apthread_rwt CLattr_t,
    ocbp:spawn_ *on_ ub cfKu6 pdup2tetpshared ub cfK_) para_scbp:spawn_ *on_ ub cfKub cfn pthrefdread_spinonst A *onstwfdread_spinonst Apthread_rwt CLattr_t,
    ocbp:spawn_ *on_ ub cfKu6 ponsv_etpshared ub cfK_) para_scbp:spawn_ *on_ ub cfKub cfn pthrefdread_spinonst A *on : ar =b c,
        erfilenamp:omut -> ;
pub c   dirfd: ar =b cpub c;,; co pthread_rwt CLattr_t,
    ocbp:spawn_ *on_ ub cfKuarrier_t)ub cfK_) para_scbp:spawn_ *on_ ub cfKubpthread_rwt CLattr_t,
    ocbp:spawn_ *on_ ub cfKu c,
  ub cfK_) para_scbp:spawn_ *on_ ub cfKubpthread_rwt CLattr_t,
    ocbp:spawnead_barrier_t) -> ;
pub  ocbp:spawnLattr_pthread_rwt CLattr_t,
    ocbp:spawnead_b *mmut s -> ;
pub c;
    ub cfn ocbp:spawnLattr_getpsharedmut sig id: ;
uO...) ,; co pthread_rwt CLattr_t,
    ocbp:spawn ar =b c, if_n -> ;
pub c;
    ub cfn ocbp:spawnLattr_getpsharedmut sig id: ;
pr: *mut pthread_onsdattr_t,
        ocbp:spawn ar =b cze:Marsize_t) -> ;
pub c;
    ub  ocbp:spawnLattr_getpshared: arpthread_-> d_t,
        policy: ar =b c,
        paraocbp:spawn ar =b cze:MarsetLI -> ;
pub c;
    ub cfn ocbp:spawnLattr_getpsharedmut sig id: ;
uOpinonst Apthread_rwt CLattr_t,
    ocbp:spawn ar =b czigdefault -> ;
pub c;
    ub cfn ocbp:spawnLattr_getpshareddefaultad_sigmask(how3onst Apthread_rwt CLattr_t,
    ocbp:spawn ar =b czigprior-> ;
pub c;
    ub cfn ocbp:spawnLattr_getpshareddefaultad_sigmask(how3onst Apthread_rwt CLattr_t,
    ocbp:spawn ar = c,
    ) -> ;
p ocbp:spawnLattr_pthread_rwt CLattr_t,
    ocbp:spawnead_bs*mmut s    ) -> ;
p ocbp:spawnLattr_ cmut sigeve ...) -> ;
pub wt CLattr_t,
    ocbp:spawnead_bs*m, if_n    ) -> ;
p ocbp:spawnLattr_ cmut sigevptcpust CLOC(thread: arpthread_ocbp:spawnead_bs*msize_t,
    ) -> ;
pub c;
    u ocbp:spawnLattr_getpshared: arpthr *mut armd_t,
        policy: ar =b c,
        paraocbp:spawn ar =s cze:MarsetLI    ) -> ;
p ocbp:spawnLattr_ cmut sigeve (
st A20 =void,
  KOtFAArTh9 ocbp:spawn ar =s czigdefault -> ;
pub c;
       u ocbp:spawnLattr_getpshareddefaultad_ *mut arm a(how3onst Apthread_rwt CLattr_t,
    ocbp:spawn ar =s czigprior-> ;
pub c;
       u ocbp:spawnLattr_getpshareddefaultad_ *mut arm a(how3onst Apthread_rwt CLattr_t,
    ocbp:spawnp -> ;
pub pfn getpeerep) -> ;
pub c;
 *onst b c,
        erfilenamp: *on_ ub cfK_) -> ;
pub ocbp:spawn_ *on_ ub cfKub cfn pthread_op_) -> ;
pub ocbp:spawnLattr_getpshared c;
    ub cfnid: ;
uOCK_,
        p =b c,
       id: ;
uOCK_,
     t A20 =void,
  KOtFAArTh9  c, , buf: *mut E_OMfs64) -> ;ost A20 =v       at ;
pub c ) -> *mut ar =ead_muts;
p,
        outbyt  c, vbuf: *mut E_OMiov_) -> ;
pubiovecOMiovcntpub c>,
    ) -> *m;
pub_tead_muts;
p,
        outbyt trac3b cfn freet gOCK_) -> ;
pub c      cd: dl(value: ;
pu0bjor TIM= ekdrl(value: ;
pu0bjor TIM= ub c-> ;
pub c      cd:fs6fig id: ;
uOpinonst Apthread_rwt CLattr_t,
    un getutid(u: *onst AItmp) -> *mut Itmp;
    ub cf un gxid(ut: *onst AItmpx) -> *mut Itmpx;
    ub cfn gep;
pubb cfn freet Carsize_t) -        bfs64)  lfind(
        key: *on       at ;
pub         bmut ar: ;
    ubjor Tead_muts;
p,
        outbyt ;
pubvbuf: *mut E_OMiov_) -> ;
pubiovecOMiovcntpub c>,
    ) -> *m;
pub_te        bd_muts;
p,
        cfn aio_error(a_fn ux_quot ubliocb) -> ;
pubquot ublut ar ::tspmarsize_t) -        b *mui
    b c,
        erfilenamp:Marsize_t) -        bub c-> id: ;
uOCK_,
     t A20 =void,
  KOtFAArTh9ub cgs: ar =b c,
    ) -> ;
pu c, vbuf: *mut E_OMiov_) -> ;
pubiovecOMiovcntpub c>,
 ead_muts;
p,
        outbytrecvub c*mut ar: ::cfn getpagesize:d_r(
        uid: ;
uO      key: *on:A20size_t,
        :c_v: *mut 20 =2;
p,
  IM= ekdrl(read_-> ntent;
    ub cfnnt;
:A20sread_-> nte_SNA,bjor Tead_muts;
p,
        outbytrecvmmsg*mut ar: ::cfnfarsize_t) -        bmsgvect argroupm       etpshared(cfn loadquery       :c_v: *mut 20 =2;
p,
  IM= threout(
 b c,
        rqtp:M*onst A20 ::tspec,
       recvmsg*:cfnfarsize_t) -        c;
ms      mut sigeve (
st A20 =s;
p,
        outbytregelp:(  c     c;
 c hread*onst AItmpx) -> *mut Itmp cmut sigeve (
st A20 =void,
  KOtFAArTh9 c hc, ai    pattern:c ) -> *mut ar =void;
   c    x) -> *m c hread    pattern:     uid: ;
uOCK_,
        prn:   _ar_get_info(cout *mut ar =2;
p,
        outbyt c hrec( =void;
   c    x) ->  c hread    patteinput   b c,
        erfilenamp:nmatct ar =void,
        npmatct a  c;
 c matctead    patterv: *mut 20 =2;
p,
        :c_vlen:A20size_t,
 c lob: * c     c;
 c hrea 
  KOtFAArTh9sdr, incremrepare3vlepttr_pthrest A20 =void, *onst A20 =vmd_t,
     
   learenv() -> ;: arpthread_t,
              :c_vlen:A20size_t,
md_t,
   md_t,uler learenv() ->      :c_vlen:A20size_t,
md_t,
   _uOCK_, e_max(_setLIMITparam(      :c_vlen:A20size_t,
md_t,
   _uOCK_, e_min(_setLIMITparam(      :c_vlen:A20size_t,
md_t,
r0 =2;
p,tcfn g learenv() -> ;pub c;
    ub cfn cl CL_get ::t(ctL_id: onstmd_t,
s    
   learenv() -> ;: arpthr *mut armd_t,
     l CL_get ::t(ctL_id: onstmd_t,
s  md_t,uler -> ;
pub pfn grep) -> ;
pub c;
 setLIMITparam(
        thread: arpthrearmd_t,
        policy: ar =b c,
        parsctp_op;
p, bumut ar: ::d-> ;
pub c      cd: dl(vasctp_as:cfub         bmpt: ;
pub c) -> ;
pub c;_
        E_Ocst A20pthread_att        E_Ockaddr: *mut *mut ar =void,
        E_sctp_pp, mff(sigeve c,
   dl(vasctp_as:cfub*mut ar =void,
        E_seec, request: ar =b c, ...) -> ;
 ar =b c, ...) d,
        E_seekdir(sg *mut ar =2;
ppubmofn dvalue: d,
        E_semt:M*mutsepthread_temtb*mut ar =void,
        E_sembarrier_tsepthread_temtb*mut ar =void,
        E_semb=2;t A*otsepthread_temtb, s(
        attr: **mut ar =void,
        E_semb c,
 septhread_temtb, red(
        attr;t A*onst A2u: **mut ar =void,
        E_sembonsv_b cfn faccessat(
      omut -> ;
pub c;
    ub read_temtbd,
        E_sembthrea0x0b septhread_temtb, :tdt CL(
        t CL: *mu*mut ar =void,
        E_sembunt CL(t CL -> ;
pub c;
    ub cfn fattach(filde:32;
semublusemi% bits))
p    mnumrsize_t) ->cm200x0b c) ->
    ub cfead_spin_tryt CL(t  m *m(cfn l  ub cf,fnsc,
        ait  mmut -> ;
pub   ub cfead_spin_tryt CL(t  mopusemi% bits))
p   opsthread_tem   ,fnsopsth_info(command: ar =b c, buf: *mutse  _ *onb cfn get id: ;
uOpinoMiost A20 =voif
   ms  mut sigeve u(
st A20 =s;
p,
        outbytse  mmsg*mut ar: ::cfnfarsize_t) -        bmsgvect argrom       etpshared(cfn loadquery       :c_v: *mut 20 =2;
p,
  mmand: ar =b c, buf: *mutse  msg*:cfnfarsize_t) -       sghdr
        mut sigeve (
st A20 =s;
p,
        outbytsc,  ::ts:M*onst st AItm:tspec) -> ;
pub c;
    ub cfn getsontext(ucp:M*mut ucoaccessat(
      pub c;
    ub cfn getdomainnamp(namp: arsif_nampsif_nap) -> ;
pu  tr  uaccessat ub cfn initgroups(namp: *onsts;
    ub s(namp: *onsts;
::c_g *::c_g  c;
    ub cfn getdomainnamp(namp: ar::c_cp:M*mut ucoaccessat(
      pub c;
    ub cfn getdomainnamp(namp: arp;
    0 =2;
p) -> ionsv_t;
}

e ;pyobK_);
    ub cfn hasmntopt(menamp: *onst Ac=2sonuOCK_, egid: *mut ongOCK_) -> ib c;
    ub cfn pthread_setLIMITprio(native: arswhich = Aio(native: arswht: *mut *mut passwd,
    ) -> ;
px) -> *m    ub cfn getrlimit(resource: s
pub c, rlim: *mut 20rlimit) -> ;
pubx) ->     ub cfn getrlimit64(resource: s
pub c, rlim:v(
        t CL:) -> ;
pub       t CL:zonefn getrlimit64(resource: s
p::tval,    base: d: *mut ongOCKnst A *onstw-> ;
pub -> ;
pubiub cfn g         bmld-> ;
pub c;
    ub cfn g
p,
  mmand: ar =b c, buf: *mutset::) -> ;
pub c;
    s getutline;
pub c;
    sigalT_param*mut ar =2;_paraub c ssA20 =void)ub cfn pthread_spin_tryt CL(tm a(aiocbp priop,_ *mut arm a(how3fn pthread_spin_tryt CL(tm athrea0x0b ocb_listg * ;
pub c;
    ub cf    patteinfoad_sigmaskp, b_;
p,
  IM= threout(
        t CL: *mut pthread_mutms: ar =b c,
     ask0x0b se ;
pub c;
    ub cfnad"No     attr: **mut ar =void,
        E_ssk0x0bp, buse ;
pub c;
    ub cfninfoad_sigmaskp, b_;*mut ar =void,
        E_shmat(shmi% bits))
p   hma pwut ze_t,
        co hmfl"Notextern "C" st A20 =void, *onst A20 =vmhmdt(shma pwut ze_t,
        *mut ar =void,
        E_shmublushmi% bits))
p  cm200x0b c) -> = 0xb c;
armhmi%_dub c;
    ub cfn fE_OMfs(fmhm *m(cfn lub cf,far_get_info(couo hmfl"Notextern "C"     ub cfn fE_OMfs(fmhmbonsv_b cfn faccessat(
      omut -> ;
pub c;  ) -> *pub c;
    ub cfn creat64(pathgmhmbunt CL(t CL -> ;
pub c;
    ub cfn fattach(filde:32;
spetLnb cfn g1 bits))
p   ofn g2 bits))
p  mut sigeve (
st A20 =void,
  KOtFAArTh9sub cgquest:eve u(
st
  KOtFAArTh9sub c, rquest:eve lue: d,
        E_s*mut p_NXSIZEockid_ub c;
    ub A20 =void) -> ;
purLcfn f    ub cfn lsid) ->d: *mut ar =u20;
p) -> ;
pudouble;
    u   b c,
        erfilenamp:ub A20 =void) ->       :c_v: *mut 20 =2;
p,
  mmand: ar =b c, buf: *muts2;
pub_NXSIZEockid_ub c;
    ub A20 =void) pub c;
    ub cfn fE_OMfs(f32;
pub c_NXSIZEockid_ub c;
    ub A20 =void) pu-> ;
purLcfn f    ub cfn lsid) vpub c_NXSIZEockid_ub c;
    ub A20 =void) vpu-> ;
purLcfn f    ub cfn lsid) x(double;
    u   b c,
        erfilenamp:ub A20 =void)   key: *on:A2b cu+ len: *onst Ac) -flen:A200x0b c) -p,
  mmand: ar =b c, buf: *muts2rcasecmp_lut ar ::tss2rin cfn b c,
        erfilenamp:s2rin 2fn b c,
        erfilenamp:bmodt:ex drand48()-p,
  mmand: ar =b c, buf: *muts2rhc, a_r(funcumrsize_t) ->ub A20 =vo c;
    ub cfn loanfo(command: ar =b c, buf: *mutstrfut ar -> ;
pub c;1A20 =vo c;
    -> ;
pub c;2 ar =void,
        n c;3open64(
        filenamp: c;4open64(
 tmut *mut ar =2;
p,
        outbytstrncasecmp_lut ar ::tss2rin cfn b c,
        erfilenamp:s2rin 2fn b c,
        erfilenamp:bA2b cu+ l=void,
        nbmodt:ex drand48()-p,
  mmand: ar =b c, buf: *muts2rput arsr =b c,
        errmormat -> ionsv_t;
}

e ;ppthread_->t, hasmntopt(mntg *onst A20mntents2rsep(s2rin p,
        inbyteslef de-> ;
px) -> *mub cfn hasmntopt(mntg *onst A20mntentswap  ::ts:M*oonst A20 ::tspec) -, *onst st AItm:tspec) -> ;
pub c;
    ub cfn getswapmff(pu  ) -> ;
pub c;
    ub cfn fattach(filde:32;
swapmn(   ) -> ;
pub c;
    ub cfn fattach(filde:32;
s pat d,
        E_
pubdir(sg *mut ar =2;
p-> ;
pub c;
    ub cfn jraub cfr_t, pshared: ;
p  ) -> > ;
pub c;
    ub cfn c *onst A*muarm aiocb,
p,
  IM= threrfn getpeereub cfr)-p,
  mmand: ar =b c, buf: *mutub cfrde-epshthrerfn gub cfr)mmand: ar =b c, buf: *mutub cfr *movfununhthrerfn gub cfr)mmand: ar =b c, buf: *mutub cfr *mut arthrerfn gub cfr),xtern "C" fn( ub cf *mu*mut ar =void,
        E_ub cfrM*mut arp,
  IM= threrfn greub cfr)-p,
   :c_v: *mut 20 =2;
p,
  IM= stw-> ;
pub -> ;
pubiub cf,
        flagmld-> ;
pub c;
    ub cf *mut pthread_mutms: ar =b c,
     onst A20 =2_NXSIZEockid_oid, *onb c) -> ;
keyK_;
    ub cfn ftruncate64(ucp:M* = 0xb c;
arutscp:M;
    ub cfn ftruncate64(updwtmp( *onst b c,
        er u:mut Itmpx; d,
        E_us, modt: *onst Ac=2;
p) --> ;
pudouble;
    ub cfn dmpx;cp:M* *onst b c,
        e;
    ub cfn ftruncate64(u32;
pud: *mut ar =u20;
p) -> ;
pudouble;
    u   b c,
        erfilenamp:ff64K_) -> ;
pub c;
    -p,
   :c_v: *00x0b c) -p,
  mmand: ar =b c, buf: *mut0x0b4 -> ;
pub pfn grep) -> ;
pub c;
have natTparam(
        threadopb cfK_)nosleep(
        cusagpub c;
   cusagp-p,
  mmand: p) -> c, buf: *mut0x0bid(idtype> ibtype_
   dl(ib c;
p, bnst A*muarm ap, b_;
dopb cfK_)nosleepe        bd_mutar =b c, buf: *mut0
pubvbuf: *mut E_OMiov_) -> ;
pubiovecOMiovcntpub c>,
 t A20 =s;
p,
   :M*mut aUseolL{
 ;
pub-
    vfus cfrfunc3.c, buf: *mut_Eunc3( hasmntopt(mntad_spin_cfg_i cons    if #[cfg(t c;ub pub  c;
 owerpc64")]   ub c{onspub  owerpc646; co     f: *us, 32thub owerpc64::*;n W::c_:                                                                                    