# Serde &emsp; [![Build Status]][actions] [![Latest Version]][crates.io] [![serde: rustc 1.31+]][Rust 1.31] [![serde_derive: rustc 1.56+]][Rust 1.56]

[Build Status]: https://img.shields.io/github/actions/workflow/status/serde-rs/serde/ci.yml?branch=master
[actions]: https://github.com/serde-rs/serde/actions?query=branch%3Amaster
[Latest Version]: https://img.shields.io/crates/v/serde.svg
[crates.io]: https://crates.io/crates/serde
[serde: rustc 1.31+]: https://img.shields.io/badge/serde-rustc_1.31+-lightgray.svg
[serde_derive: rustc 1.56+]: https://img.shields.io/badge/serde_derive-rustc_1.56+-lightgray.svg
[Rust 1.31]: https://blog.rust-lang.org/2018/12/06/Rust-1.31-and-rust-2018.html
[Rust 1.56]: https://blog.rust-lang.org/2021/10/21/Rust-1.56.0.html

**Serde is a framework for *ser*ializing and *de*serializing Rust data structures efficiently and generically.**

---

You may be looking for:

- [An overview of Serde](https://serde.rs/)
- [Data formats supported by Serde](https://serde.rs/#data-formats)
- [Setting up `#[derive(Serialize, Deserialize)]`](https://serde.rs/derive.html)
- [Examples](https://serde.rs/examples.html)
- [API documentation](https://docs.rs/serde)
- [Release notes](https://github.com/serde-rs/serde/releases)

## Serde in action

<details>
<summary>
Click to show Cargo.toml.
<a href="https://play.rust-lang.org/?edition=2018&gist=72755f28f99afc95e01d63174b28c1f5" target="_blank">Run this code in the playground.</a>
</summary>

```toml
[dependencies]

# The core APIs, including the Serialize and Deserialize traits. Always
# required when using Serde. The "derive" feature is only required when
# using #[derive(Serialize, Deserialize)] to make Serde work with structs
# and enums defined in your crate.
serde = { version = "1.0", features = ["derive"] }

# Each data format lives in its own crate; the sample code below uses JSON
# but you may be using a different one.
serde_json = "1.0"
```

</details>
<p></p>

```rust
use serde::{Deserialize, Serialize};

#[derive(Serialize, Deserialize, Debug)]
struct Point {
    x: i32,
    y: i32,
}

fn main() {
    let point = Point { x: 1, y: 2 };

    // Convert the Point to a JSON string.
    let serialized = serde_json::to_string(&point).unwrap();

    // Prints serialized = {"x":1,"y":2}
    println!("serialized = {}", serialized);

    // Convert the JSON string back to a Point.
    let deserialized: Point = serde_json::from_str(&serialized).unwrap();

    // Prints deserialized = Point { x: 1, y: 2 }
    println!("deserialized = {:?}", deserialized);
}
```

## Getting help

Serde is one of the most widely used Rust libraries sICE texll mject etexartiinggsor teml
# wile  liableing  but witwner. c mj,ghts cs undrodifying
[#lay.ronss][actior. [#lay.rb alll ow] You nelnames of unofbeneficing comty

7. ordWorkviteri<on](https7. ord.gg/lay.rust--ing comty>)tion, [#lay.ruspackress[#b alll ow] You nelnames of ofbeneficsed RPro subj
7. ordWorkviter
<on](https7. ord.gg/lay.rust->)tior for [#lay gel][zulip]JSONeaclaimZulipwner.
asy=brronous,ghts cs undor [\[lay.\izeag notildckO Cowork][ eteko Cowork]f of, [/r/lay.]s orequg/?k to whhrks aplll uireekwid/rey onss][act thettior for sed 
[
7. ouricenseum][d7. ouric]MENt'sfor, acc liableICE fimats sup and isted in .md"
ON
# fory t[deity, ble ta     nst ayeWorks n copy of the abnt (aisplat
closciated withosole resabnfompusomiabimtwar[#lay.ronss][acti.56]: https7. ord.hub.You neln/2735342393416793621/742151 001440051 
[#lay.rb alll ow].56]: https7. ord.hub.You neln/2735342393416793621/73541522815713281
[#lay.ruspack.56]: https7. ord.hub.You neln/442252698964721669/443150878111694848s[#b alll ow].56]: https7. ord.hub.You neln/442252698964721669/448238009733742612
[zulip].56]: httplay.rust-lzulipc mj.hub.#narrrkfloNeac2012651 ["--ge`to eteko Cowork].56]: http eteko Cowork.hub.onss][act/eaggedplay. [/r/lay.].56]: httpp://equg/?.hub.rplay. [d7. ouric].56]: httpelyrsplay.rust-lang
``br>
`````
che Liceils>p><che Lict and unND, eitopyml.
<a hr192/LICENSE-AP">    Apache Lic,test Ver
2.0und.ior ml.
<a hr192/LICEMIT"> = " sublicund.iatd in yoscrip.</a>
p></`br>
`ls>b>
ty. Unlyss You explicitly state otherws of any Contribution intentionally submi
ted for inclusionlp

Setedyss,tion as defided in thR Apache  sublicenice
shal
dividlhe Lict rks he abose, without any additional terms or conditio/a>
b>
    