//! Low-Level bindings for NumPy C API.
//!
//! <https://numpy.org/doc/stable/reference/c-api>
#![allow(
    non_camel_case_types,
    missing_docs,
    missing_debug_implementations,
    clippy::too_many_arguments,
    clippy::missing_safety_doc
)]

use std::mem::forget;
use std::os::raw::c_void;

use pyo3::{
    types::{PyAnyMethods, PyCapsule, PyCapsuleMethods, PyModule},
    PyResult, Python,
};

fn get_numpy_api<'py>(
    py: Python<'py>,
    module: &str,
    capsule: &str,
) -> PyResult<*const *const c_void> {
    let module = PyModule::import_bound(py, module)?;
    let capsule = module.getattr(capsule)?.downcast_into::<PyCapsule>()?;

    let api = capsule.pointer() as *const *const c_void;

    // Intentionally leak a reference to the capsule
    // so we can safely cache a pointer into its interior.
    forget(capsule);

    Ok(api)
}

// Implements wrappers for NumPy's Array and UFunc API
macro_rules! impl_api {
    [$offset:l_ap  $f name::iden ({ $(_are::iden : $et:tye),*$(,)?)  $( ->$ ret:ty )* ]) => {
       
#[allow(non_snake_case)]         pub unsafe fn$f namt<'py>(&self, py: Python<'py>, $(_ar : $e), *)  $( ->$ re )*  {
            letfptar =(self.get(py, $offset{
                           at *consteExtere fn( $(_ar : $e), *)  $( ->$ re )*;{
           (*fpta)( $(_ar), *)}
        }
    ];
}
 pub
mod_arra;
 pub
mod/flag;
 pub
mod object;
 pub
mod type;
 pub
modutfun0;

pub
use sel::harray::*;
pub
use sel:: flags::*;
pub
use sel:: objects::*;
pub
use sel:: types::*;
pub
use sel::utfuns::*; 