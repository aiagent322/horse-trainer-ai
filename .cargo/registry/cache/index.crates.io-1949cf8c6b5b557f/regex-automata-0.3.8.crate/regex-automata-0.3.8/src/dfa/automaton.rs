#[cfg(feature = "alloc")]
use crate::util::search::PatternSet;
use crate::{
    dfa::search,
    util::{
        empty,
        prefilter::Prefilter,
        primitives::{PatternID, StateID},
        search::{Anchored, HalfMatch, Input, MatchError},
    },
};

/// A trait describing the interface of a deterministic finite automaton (DFA).
///
/// The complexity of this trait probably means that it's unlikely for others
/// to implement it. The primary purpose of the trait is to provide for a way
/// of abstracting over different types of DFAs. In this crate, that means
/// dense DFAs and sparse DFAs. (Dense DFAs are fast but memory hungry, where
/// as sparse DFAs are slower but come with a smaller memory footprint. But
/// they otherwise provide exactly equivalent expressive power.) For example, a
/// [`dfa::regex::Regex`](crate::dfa::regex::Regex) is generic over this trait.
///
/// Normally, a DFA's execution model is very simple. You might have a single
/// start state, zero or more final or "match" states and a function that
/// transitions from one state to the next given the next byte of input.
/// Unfortunately, the interface described by this trait is significantly
/// more complicated than this. The complexity has a number of different
/// reasons, mostly motivated by performance, functionality or space savings:
///
/// * A DFA can search for multiple patterns simultaneously. This
/// means extra information is returned when a match occurs. Namely,
/// a match is not just an offset, but an offset plus a pattern ID.
/// [`Automaton::pattern_len`] returns the number of patterns compiled into
/// the DFA, [`Automaton::match_len`] returns the total number of patterns
/// that match in a particular state and [`Automaton::match_pattern`] permits
/// iterating over the patterns that match in a particular state.
/// * A DFA can have multiple start states, and the choice of which start
/// state to use depends on the content of the string being searched and
/// position of the search, as well as whether the search is an anchored
/// search for a specific pattern in the DFA. Moreover, computing the start
/// state also depends on whether you're doing a forward or a reverse search.
/// [`Automaton::start_state_forward`] and [`Automaton::start_state_reverse`]
/// are used to compute the start state for forward and reverse searches,
/// respectively.
/// * All matches are delayed by one byte to support things like `$` and `\b`
/// at the end of a pattern. Therefore, every use of a DFA is required to use
/// [`Automaton::next_eoi_state`]
/// at the end of the search to compute the final transition.
/// * For optimization reasons, some states are treated specially. Every
/// state is either special or not, which can be determined via the
/// [`Automaton::is_special_state`] method. If it's special, then the state
/// must be at least one of a few possible types of states. (Note that some
/// types can overlap, for example, a match state can also be an accel state.
/// But some types can't. If a state is a dead state, then it can never be any
/// other type of state.) Those types are:
///     * A dead state. A dead state means the DFA will never enter a match
///     state. This can be queried via the [`Automaton::is_dead_state`] method.
///     * A quit state. A quit state occurs if the DFA had to stop the search
///     prematurely for some reason. This can be queried via the
///     [`Automaton::is_quit_state`] method.
///     * A match state. A match state occurs when a match is found. When a DFA
///     enters a match state, the search may stop immediately (when looking
///     for the earliest match), or it may continue to find the leftmost-first
///     match. This can be queried via the [`Automaton::is_match_state`]
///     method.
///     * A start state. A start state is where a search begins. For every
///     search, there is exactly one start state that is used, however, a
///     DFA may contain many start states. When the search is in a start
///     state, it may use a prefilter to quickly skip to candidate matches
///     without executing the DFA on every byte. This can be queried via the
///     [`Automaton::is_start_state`] method.
///     * An accel state. An accel state is a state that is accelerated.
///     That is, it is a state where _most_ of its transitions loop back to
///     itself and only a small number of transitions lead to other states.
///     This kind of state is said to be accelerated because a search routine
///     can quickly look for the bytes leading out of the state instead of
///     continuing to execute the DFA on each byte. This can be queried via the
///     [`Automaton::is_accel_state`] method. And the bytes that lead out of
///     the state can be queried via the [`Automaton::accelerator`] method.
///
/// There are a number of provided methods on this trait that implement
/// efficient searching (for forwards and backwards) with a DFA using
/// all of the above features of this trait. In particular, given the
/// complexity of all these features, implementing a search routine in
/// this trait can be a little subtle. With that said, it is possible to
/// somewhat simplify the search routine. For example, handling accelerated
/// states is strictly optional, since it is always correct to assume that
/// `Automaton::is_accel_state` returns false. However, one complex part of
/// writing a search routine using this trait is handling the 1-byte delay of a
/// match. That is not optional.
///
/// # Safety
///
/// This trait is not safe to implement so that code may rely on the
/// correctness of implementations of this trait to avoid undefined behavior.
/// The primary correctness guarantees are:
///
/// * `Automaton::start_state` always returns a valid state ID or an error or
/// panics.
/// * `Automaton::next_state`, when given a valid state ID, always returns
/// a valid state ID for all values of `anchored` and `byte`, or otherwise
/// panics.
///
/// In general, the rest of the methods on `Automaton` need to uphold their
/// contracts as well. For example, `Automaton::is_dead` should only returns
/// true if the given state ID is actually a dead state.
pub unsafe trait Automaton {
    /// Transitions from the current state to the next state, given the next
    /// byte of input.
    ///
    /// Implementations must guarantee that the returned ID is always a valid
    /// ID when `current` refers to a valid ID. Moreover, the transition
    /// function must be defined for all possible values of `input`.
    ///
    /// # Panics
    ///
    /// If the given ID does not refer to a valid state, then this routine
    /// may panic but it also may not panic and instead return an invalid ID.
    /// However, if the caller provides an invalid ID then this must never
    /// sacrifice memory safety.
    ///
    /// # Example
    ///
    /// This shows a simplistic example for walking a DFA for a given haystack
    /// by using the `next_state` method.
    ///
    /// ```
    /// use regex_automata::{dfa::{Automaton, dense}, Input};
    ///
    /// let dfa = dense::DFA::new(r"[a-z]+r")?;
    /// let haystack = "bar".as_bytes();
    ///
    /// // The start state is determined by inspecting the position and the
    /// // initial bytes of the haystack.
    /// let mut state = dfa.start_state_forward(&Input::new(haystack))?;
    /// // Walk all the bytes in the haystack.
    /// for &b in haystack {
    ///     state = dfa.next_state(state, b);
    /// }
    /// // Matches are always delayed by 1 byte, so we must explicitly walk the
    /// // special "EOI" transition at the end of the search.
    /// state = dfa.next_eoi_state(state);
    /// assert!(dfa.is_match_state(state));
    ///
    /// # Ok::<(), Box<dyn std::error::Error>>(())
    /// ```
    fn next_state(&self, current: StateID, input: u8) -> StateID;

    /// Transitions from the current state to the next state, given the next
    /// byte of input.
    ///
    /// Unlike [`Automaton::next_state`], implementations may implement this
    /// more efficiently by assuming that the `current` state ID is valid.
    /// Typically, this manifests by eliding bounds checks.
    ///
    /// # Safety
    ///
    /// Callers of this method must guarantee that `current` refers to a valid
    /// state ID. If `current` is not a valid state ID for this automaton, then
    /// calling this routine may result in undefined behavior.
    ///
    /// If `current` is valid, then implementations must guarantee that the ID
    /// returned is valid for all possible values of `input`.
    unsafe fn next_state_unchecked(
        &self,
        current: StateID,
        input: u8,
    ) -> StateID;

    /// Transitions from the current state to the next state for the special
    /// EOI symbol.
    ///
    /// Implementations must guarantee that the returned ID is always a valid
    /// ID when `current` refers to a valid ID.
    ///
    /// This routine must be called at the end of every search in a correct
    /// implementation of search. Namely, DFAs in this crate delay matches
    /// by one byte in order to support look-around operators. Thus, after
    /// reaching the end of a haystack, a search implementation must follow one
    /// last EOI transition.
    ///
    /// It is best to think of EOI as an additional symbol in the alphabet of
    /// a DFA that is distinct from every other symbol. That is, the alphabet
    /// of DFAs in this crate has a logical size of 257 instead of 256, where
    /// 256 corresponds to every possible inhabitant of `u8`. (In practice, the
    /// physical alphabet size may be smaller because of alphabet compression
    /// via equivalence classes, but EOI is always represented somehow in the
    /// alphabet.)
    ///
    /// # Panics
    ///
    /// If the given ID does not refer to a valid state, then this routine
    /// may panic but it also may not panic and instead return an invalid ID.
    /// However, if the caller provides an invalid ID then this must never
    /// sacrifice memory safety.
    ///
    /// # Example
    ///
    /// This shows a simplistic example for walking a DFA for a given haystack,
    /// and then finishing the search with the final EOI transition.
    ///
    /// ```
    /// use regex_automata::{dfa::{Automaton, dense}, Input};
    ///
    /// let dfa = dense::DFA::new(r"[a-z]+r")?;
    /// let haystack = "bar".as_bytes();
    ///
    /// // The start state is determined by inspecting the position and the
    /// // initial bytes of the haystack.
    /// //
    /// // The unwrap is OK because we aren't requesting a start state for a
    /// // specific pattern.
    /// let mut state = dfa.start_state_forward(&Input::new(haystack))?;
    /// // Walk all the bytes in the haystack.
    /// for &b in haystack {
    ///     state = dfa.next_state(state, b);
    /// }
    /// // Matches are always delayed by 1 byte, so we must explicitly walk
    /// // the special "EOI" transition at the end of the search. Without this
    /// // final transition, the assert below will fail since the DFA will not
    /// // have entered a match state yet!
    /// state = dfa.next_eoi_state(state);
    /// assert!(dfa.is_match_state(state));
    ///
    /// # Ok::<(), Box<dyn std::error::Error>>(())
    /// ```
    fn next_eoi_state(&self, current: StateID) -> StateID;

    /// Return the ID of the start state for this lazy DFA when executing a
    /// forward search.
    ///
    /// Unlike typical DFA implementations, the start state for DFAs in this
    /// crate is dependent on a few different factors:
    ///
    /// * The [`Anchored`] mode of the search. Unanchored, anchored and
    /// anchored searches for a specific [`PatternID`] all use different start
    /// states.
    /// * The position at which the search begins, via [`Input::start`]. This
    /// and the byte immediately preceding the start of the search (if one
    /// exists) influence which look-behind assertions are true at the start
    /// of the search. This in turn influences which start state is selected.
    /// * Whether the search is a forward or reverse search. This routine can
    /// only be used for forward searches.
    ///
    /// # Errors
    ///
    /// This may return a [`MatchError`] if the search needs to give up
    /// when determining the start state (for example, if it sees a "quit"
    /// byte). This can also return an error if the given `Input` contains an
    /// unsupported [`Anchored`] configuration.
    fn start_state_forward(
        &self,
        input: &Input<'_>,
    ) -> Result<StateID, MatchError>;

    /// Return the ID of the start state for this lazy DFA when executing a
    /// reverse search.
    ///
    /// Unlike typical DFA implementations, the start state for DFAs in this
    /// crate is dependent on a few different factors:
    ///
    /// * The [`Anchored`] mode of the search. Unanchored, anchored and
    /// anchored searches for a specific [`PatternID`] all use different start
    /// states.
    /// * The position at which the search begins, via [`Input::start`]. This
    /// and the byte immediately preceding the start of the search (if one
    /// exists) influence which look-behind assertions are true at the start
    /// of the search. This in turn influences which start state is selected.
    /// * Whether the search is a forward or reverse search. This routine can
    /// only be used for reverse searches.
    ///
    /// # Errors
    ///
    /// This may return a [`MatchError`] if the search needs to give up
    /// when determining the start state (for example, if it sees a "quit"
    /// byte). This can also return an error if the given `Input` contains an
    /// unsupported [`Anchored`] configuration.
    fn start_state_reverse(
        &self,
        input: &Input<'_>,
    ) -> Result<StateID, MatchError>;

    /// If this DFA has a universal starting state for the given anchor mode
    /// and the DFA supports universal starting states, then this returns that
    /// state's identifier.
    ///
    /// A DFA is said to have a universal starting state when the starting
    /// state is invariant with respect to the haystack. Usually, the starting
    /// state is chosen depending on the bytes immediately surrounding the
    /// starting position of a search. However, the starting state only differs
    /// when one or more of the patterns in the DFA have look-around assertions
    /// in its prefix.
    ///
    /// Stated differently, if none of the patterns in a DFA have look-around
    /// assertions in their prefix, then the DFA has a universal starting state
    /// and _may_ be returned by this method.
    ///
    /// It is always correct for implementations to return `None`, and indeed,
    /// this is what the default implementation does. When this returns `None`,
    /// callers must use either `start_state_forward` or `start_state_reverse`
    /// to get the starting state.
    ///
    /// # Use case
    ///
    /// There are a few reasons why one might want to use this:
    ///
    /// * If you know your regex patterns have no look-around assertions in
    /// their prefix, then calling this routine is likely cheaper and perhaps
    /// more semantically meaningful.
    /// * When implementing prefilter support in a DFA regex implementation,
    /// it is necessary to re-compute the start state after a candidate
    /// is returned from the prefilter. However, this is only needed when
    /// there isn't a universal start state. When one exists, one can avoid
    /// re-computing the start state.
    ///
    /// # Example
    ///
    /// ```
    /// use regex_automata::{
    ///     dfa::{Automaton, dense::DFA},
    ///     Anchored,
    /// };
    ///
    /// // There are no look-around assertions in the prefixes of any of the
    /// // patterns, so we get a universal start state.
    /// let dfa = DFA::new_many(&["[0-9]+", "[a-z]+$", "[A-Z]+"])?;
    /// assert!(dfa.universal_start_state(Anchored::No).is_some());
    /// assert!(dfa.universal_start_state(Anchored::Yes).is_some());
    ///
    /// // One of the patterns has a look-around assertion in its prefix,
    /// // so this means there is no longer a universal start state.
    /// let dfa = DFA::new_many(&["[0-9]+", "^[a-z]+$", "[A-Z]+"])?;
    /// assert!(!dfa.universal_start_state(Anchored::No).is_some());
    /// assert!(!dfa.universal_start_state(Anchored::Yes).is_some());
    /// # Ok::<(), Box<dyn std::error::Error>>(())
    /// ```
    #[inline]
    fn universal_start_state(&self, _mode: Anchored) -> Option<StateID> {
        None
    }

    /// Returns true if and only if the given identifier corresponds to a
    /// "special" state. A special state is one or more of the following:
    /// a dead state, a quit state, a match state, a start state or an
    /// accelerated state.
    ///
    /// A correct implementation _may_ always return false for states that
    /// are either start states or accelerated states, since that information
    /// is only intended to be used for optimization purposes. Correct
    /// implementations must return true if the state is a dead, quit or match
    /// state. This is because search routines using this trait must be able
    /// to rely on `is_special_state` as an indicator that a state may need
    /// special treatment. (For example, when a search routine sees a dead
    /// state, it must terminate.)
    ///
    /// This routine permits search implementations to use a single branch to
    /// check whether a state needs special attention before executing the next
    /// transition. The example below shows how to do this.
    ///
    /// # Example
    ///
    /// This example shows how `is_special_state` can be used to implement a
    /// correct search routine with minimal branching. In particular, this
    /// search routine implements "leftmost" matching, which means that it
    /// doesn't immediately stop once a match is found. Instead, it continues
    /// until it reaches a dead state.
    ///
    /// ```
    /// use regex_automata::{
    ///     dfa::{Automaton, dense},
    ///     HalfMatch, MatchError, Input,
    /// };
    ///
    /// fn find<A: Automaton>(
    ///     dfa: &A,
    ///     haystack: &[u8],
    /// ) -> Result<Option<HalfMatch>, MatchError> {
    ///     // The start state is determined by inspecting the position and the
    ///     // initial bytes of the haystack. Note that start states can never
    ///     // be match states (since DFAs in this crate delay matches by 1
    ///     // byte), so we don't need to check if the start state is a match.
    ///     let mut state = dfa.start_state_forward(&Input::new(haystack))?;
    ///     let mut last_match = None;
    ///     // Walk all the bytes in the haystack. We can quit early if we see
    ///     // a dead or a quit state. The former means the automaton will
    ///     // never transition to any other state. The latter means that the
    ///     // automaton entered a condition in which its search failed.
    ///     for (i, &b) in haystack.iter().enumerate() {
    ///         state = dfa.next_state(state, b);
    ///         if dfa.is_special_state(state) {
    ///             if dfa.is_match_state(state) {
    ///                 last_match = Some(HalfMatch::new(
    ///                     dfa.match_pattern(state, 0),
    ///                     i,
    ///                 ));
    ///             } else if dfa.is_dead_state(state) {
    ///                 return Ok(last_match);
    ///             } else if dfa.is_quit_state(state) {
    ///                 // It is possible to enter into a quit state after
    ///                 // observing a match has occurred. In that case, we
    ///                 // should return the match instead of an error.
    ///                 if last_match.is_some() {
    ///                     return Ok(last_match);
    ///                 }
    ///                 return Err(MatchError::quit(b, i));
    ///             }
    ///             // Implementors may also want to check for start or accel
    ///             // states and handle them differently for performance
    ///             // reasons. But it is not necessary for correctness.
    ///         }
    ///     }
    ///     // Matches are always delayed by 1 byte, so we must explicitly walk
    ///     // the special "EOI" transition at the end of the search.
    ///     state = dfa.next_eoi_state(state);
    ///     if dfa.is_match_state(state) {
    ///         last_match = Some(HalfMatch::new(
    ///             dfa.match_pattern(state, 0),
    ///             haystack.len(),
    ///         ));
    ///     }
    ///     Ok(last_match)
    /// }
    ///
    /// // We use a greedy '+' operator to show how the search doesn't just
    /// // stop once a match is detected. It continues extending the match.
    /// // Using '[a-z]+?' would also work as expected and stop the search
    /// // early. Greediness is built into the automaton.
    /// let dfa = dense::DFA::new(r"[a-z]+")?;
    /// let haystack = "123 foobar 4567".as_bytes();
    /// let mat = find(&dfa, haystack)?.unwrap();
    /// assert_eq!(mat.pattern().as_usize(), 0);
    /// assert_eq!(mat.offset(), 10);
    ///
    /// // Here's another example that tests our handling of the special EOI
    /// // transition. This will fail to find a match if we don't call
    /// // 'next_eoi_state' at the end of the search since the match isn't
    /// // found until the final byte in the haystack.
    /// let dfa = dense::DFA::new(r"[0-9]{4}")?;
    /// let haystack = "123 foobar 4567".as_bytes();
    /// let mat = find(&dfa, haystack)?.unwrap();
    /// assert_eq!(mat.pattern().as_usize(), 0);
    /// assert_eq!(mat.offset(), 15);
    ///
    /// // And note that our search implementation above automatically works
    /// // with multi-DFAs. Namely, `dfa.match_pattern(match_state, 0)` selects
    /// // the appropriate pattern ID for us.
    /// let dfa = dense::DFA::new_many(&[r"[a-z]+", r"[0-9]+"])?;
    /// let haystack = "123 foobar 4567".as_bytes();
    /// let mat = find(&dfa, haystack)?.unwrap();
    /// assert_eq!(mat.pattern().as_usize(), 1);
    /// assert_eq!(mat.offset(), 3);
    /// let mat = find(&dfa, &haystack[3..])?.unwrap();
    /// assert_eq!(mat.pattern().as_usize(), 0);
    /// assert_eq!(mat.offset(), 7);
    /// let mat = find(&dfa, &haystack[10..])?.unwrap();
    /// assert_eq!(mat.pattern().as_usize(), 1);
    /// assert_eq!(mat.offset(), 5);
    ///
    /// # Ok::<(), Box<dyn std::error::Error>>(())
    /// ```
    fn is_special_state(&self, id: StateID) -> bool;

    /// Returns true if and only if the given identifier corresponds to a dead
    /// state. When a DFA enters a dead state, it is impossible to leave. That
    /// is, every transition on a dead state by definition leads back to the
    /// same dead state.
    ///
    /// In practice, the dead state always corresponds to the identifier `0`.
    /// Moreover, in practice, there is only one dead state.
    ///
    /// The existence of a dead state is not strictly required in the classical
    /// model of finite state machines, where one generally only cares about
    /// the question of whether an input sequence matches or not. Dead states
    /// are not needed to answer that question, since one can immediately quit
    /// as soon as one enters a final or "match" state. However, we don't just
    /// care about matches but also care about the location of matches, and
    /// more specifically, care about semantics like "greedy" matching.
    ///
    /// For example, given the pattern `a+` and the input `aaaz`, the dead
    /// state won't be entered until the state machine reaches `z` in the
    /// input, at which point, the search routine can quit. But without the
    /// dead state, the search routine wouldn't know when to quit. In a
    /// classical representation, the search routine would stop after seeing
    /// the first `a` (which is when the search would enter a match state). But
    /// this wouldn't implement "greedy" matching where `a+` matches as many
    /// `a`'s as possible.
    ///
    /// # Example
    ///
    /// See the example for [`Automaton::is_special_state`] for how to use this
    /// method correctly.
    fn is_dead_state(&self, id: StateID) -> bool;

    /// Returns true if and only if the given identifier corresponds to a quit
    /// state. A quit state is like a dead state (it has no transitions other
    /// than to itself), except it indicates that the DFA failed to complete
    /// the search. When this occurs, callers can neither accept or reject that
    /// a match occurred.
    ///
    /// In practice, the quit state always corresponds to the state immediately
    /// following the dead state. (Which is not usually represented by `1`,
    /// since state identifiers are pre-multiplied by the state machine's
    /// alphabet stride, and the alphabet stride varies between DFAs.)
    ///
    /// The typical way in which a quit state can occur is when heuristic
    /// support for Unicode word boundaries is enabled via the
    /// [`dense::Config::unicode_word_boundary`](crate::dfa::dense::Config::unicode_word_boundary)
    /// option. But other options, like the lower level
    /// [`dense::Config::quit`](crate::dfa::dense::Config::quit)
    /// configuration, can also result in a quit state being entered. The
    /// purpose of the quit state is to provide a way to execute a fast DFA
    /// in common cases while delegating to slower routines when the DFA quits.
    ///
    /// The default search implementations provided by this crate will return a
    /// [`MatchError::quit`] error when a quit state is entered.
    ///
    /// # Example
    ///
    /// See the example for [`Automaton::is_special_state`] for how to use this
    /// method correctly.
    fn is_quit_state(&self, id: StateID) -> bool;

    /// Returns true if and only if the given identifier corresponds to a
    /// match state. A match state is also referred to as a "final" state and
    /// indicates that a match has been found.
    ///
    /// If all you care about is whether a particular pattern matches in the
    /// input sequence, then a search routine can quit early as soon as the
    /// machine enters a match state. However, if you're looking for the
    /// standard "leftmost-first" match location, then search _must_ continue
    /// until either the end of the input or until the machine enters a dead
    /// state. (Since either condition implies that no other useful work can
    /// be done.) Namely, when looking for the location of a match, then
    /// search implementations should record the most recent location in
    /// which a match state was entered, but otherwise continue executing the
    /// search as normal. (The search may even leave the match state.) Once
    /// the termination condition is reached, the most recently recorded match
    /// location should be returned.
    ///
    /// Finally, one additional power given to match states in this crate
    /// is that they are always associated with a specific pattern in order
    /// to support multi-DFAs. See [`Automaton::match_pattern`] for more
    /// details and an example for how to query the pattern associated with a
    /// particular match state.
    ///
    /// # Example
    ///
    /// See the example for [`Automaton::is_special_state`] for how to use this
    /// method correctly.
    fn is_match_state(&self, id: StateID) -> bool;

    /// Returns true only if the given identifier corresponds to a start
    /// state
    ///
    /// A start state is a state in which a DFA begins a search.
    /// All searches begin in a start state. Moreover, since all matches are
    /// delayed by one byte, a start state can never be a match state.
    ///
    /// The main role of a start state is, as mentioned, to be a starting
    /// point for a DFA. This starting point is determined via one of
    /// [`Automaton::start_state_forward`] or
    /// [`Automaton::start_state_reverse`], depending on whether one is doing
    /// a forward or a reverse search, respectively.
    ///
    /// A secondary use of start states is for prefix acceleration. Namely,
    /// while executing a search, if one detects that you're in a start state,
    /// then it may be faster to look for the next match of a prefix of the
    /// pattern, if one exists. If a prefix exists and since all matches must
    /// begin with that prefix, then skipping ahead to occurrences of that
    /// prefix may be much faster than executing the DFA.
    ///
    /// As mentioned in the documentation for
    /// [`is_special_state`](Automaton::is_special_state) implementations
    /// _may_ always return false, even if the given identifier is a start
    /// state. This is because knowing whether a state is a start state or not
    /// is not necessary for correctness and is only treated as a potential
    /// performance optimization. (For example, the implementations of this
    /// trait in this crate will only return true when the given identifier
    /// corresponds to a start state and when [specialization of start
    /// states](crate::dfa::dense::Config::specialize_start_states) was enabled
    /// during DFA construction. If start state specialization is disabled
    /// (which is the default), then this method will always return false.)
    ///
    /// # Example
    ///
    /// This example shows how to implement your own search routine that does
    /// a prefix search whenever the search enters a start state.
    ///
    /// Note that you do not need to implement your own search routine
    /// to make use of prefilters like this. The search routines
    /// provided by this crate already implement prefilter support via
    /// the [`Prefilter`](crate::util::prefilter::Prefilter) trait.
    /// A prefilter can be added to your search configuration with
    /// [`dense::Config::prefilter`](crate::dfa::dense::Config::prefilter) for
    /// dense and sparse DFAs in this crate.
    ///
    /// This example is meant to show how you might deal with prefilters in a
    /// simplified case if you are implementing your own search routine.
    ///
    /// ```
    /// use regex_automata::{
    ///     dfa::{Automaton, dense},
    ///     HalfMatch, MatchError, Input,
    /// };
    ///
    /// fn find_byte(slice: &[u8], at: usize, byte: u8) -> Option<usize> {
    ///     // Would be faster to use the memchr crate, but this is still
    ///     // faster than running through the DFA.
    ///     slice[at..].iter().position(|&b| b == byte).map(|i| at + i)
    /// }
    ///
    /// fn find<A: Automaton>(
    ///     dfa: &A,
    ///     haystack: &[u8],
    ///     prefix_byte: Option<u8>,
    /// ) -> Result<Option<HalfMatch>, MatchError> {
    ///     // See the Automaton::is_special_state example for similar code
    ///     // with more comments.
    ///
    ///     let mut state = dfa.start_state_forward(&Input::new(haystack))?;
    ///     let mut last_match = None;
    ///     let mut pos = 0;
    ///     while pos < haystack.len() {
    ///         let b = haystack[pos];
    ///         state = dfa.next_state(state, b);
    ///         pos += 1;
    ///         if dfa.is_special_state(state) {
    ///             if dfa.is_match_state(state) {
    ///                 last_match = Some(HalfMatch::new(
    ///                     dfa.match_pattern(state, 0),
    ///                     pos - 1,
    ///                 ));
    ///             } else if dfa.is_dead_state(state) {
    ///                 return Ok(last_match);
    ///             } else if dfa.is_quit_state(state) {
    ///                 // It is possible to enter into a quit state after
    ///                 // observing a match has occurred. In that case, we
    ///                 // should return the match instead of an error.
    ///                 if last_match.is_some() {
    ///                     return Ok(last_match);
    ///                 }
    ///                 return Err(MatchError::quit(b, pos - 1));
    ///             } else if dfa.is_start_state(state) {
    ///                 // If we're in a start state and know all matches begin
    ///                 // with a particular byte, then we can quickly skip to
    ///                 // candidate matches without running the DFA through
    ///                 // every byte inbetween.
    ///                 if let Some(prefix_byte) = prefix_byte {
    ///                     pos = match find_byte(haystack, pos, prefix_byte) {
    ///                         Some(pos) => pos,
    ///                         None => break,
    ///                     };
    ///                 }
    ///             }
    ///         }
    ///     }
    ///     // Matches are always delayed by 1 byte, so we must explicitly walk
    ///     // the special "EOI" transition at the end of the search.
    ///     state = dfa.next_eoi_state(state);
    ///     if dfa.is_match_state(state) {
    ///         last_match = Some(HalfMatch::new(
    ///             dfa.match_pattern(state, 0),
    ///             haystack.len(),
    ///         ));
    ///     }
    ///     Ok(last_match)
    /// }
    ///
    /// // In this example, it's obvious that all occurrences of our pattern
    /// // begin with 'Z', so we pass in 'Z'. Note also that we need to
    /// // enable start state specialization, or else it won't be possible to
    /// // detect start states during a search. ('is_start_state' would always
    /// // return false.)
    /// let dfa = dense::DFA::builder()
    ///     .configure(dense::DFA::config().specialize_start_states(true))
    ///     .build(r"Z[a-z]+")?;
    /// let haystack = "123 foobar Zbaz quux".as_bytes();
    /// let mat = find(&dfa, haystack, Some(b'Z'))?.unwrap();
    /// assert_eq!(mat.pattern().as_usize(), 0);
    /// assert_eq!(mat.offset(), 15);
    ///
    /// // But note that we don't need to pass in a prefix byte. If we don't,
    /// // then the search routine does no acceleration.
    /// let mat = find(&dfa, haystack, None)?.unwrap();
    /// assert_eq!(mat.pattern().as_usize(), 0);
    /// assert_eq!(mat.offset(), 15);
    ///
    /// // However, if we pass an incorrect byte, then the prefix search will
    /// // result in incorrect results.
    /// assert_eq!(find(&dfa, haystack, Some(b'X'))?, None);
    ///
    /// # Ok::<(), Box<dyn std::error::Error>>(())
    /// ```
    fn is_start_state(&self, id: StateID) -> bool;

    /// Returns true if and only if the given identifier corresponds to an
    /// accelerated state.
    ///
    /// An accelerated state is a special optimization
    /// trick implemented by this crate. Namely, if
    /// [`dense::Config::accelerate`](crate::dfa::dense::Config::accelerate) is
    /// enabled (and it is by default), then DFAs generated by this crate will
    /// tag states meeting certain characteristics as accelerated. States meet
    /// this criteria whenever most of their transitions are self-transitions.
    /// That is, transitions that loop back to the same state. When a small
    /// number of transitions aren't self-transitions, then it follows that
    /// there are only a small number of bytes that can cause the DFA to leave
    /// that state. Thus, there is an opportunity to look for those bytes
    /// using more optimized routines rather than continuing to run through
    /// the DFA. This trick is similar to the prefilter idea described in
    /// the documentation of [`Automaton::is_start_state`] with two main
    /// differences:
    ///
    /// 1. It is more limited since acceleration only applies to single bytes.
    /// This means states are rarely accelerated when Unicode mode is enabled
    /// (which is enabled by default).
    /// 2. It can occur anywhere in the DFA, which increases optimization
    /// opportunities.
    ///
    /// Like the prefilter idea, the main downside (and a possible reason to
    /// disable it) is that it can lead to worse performance in some cases.
    /// Namely, if a state is accelerated for very common bytes, then the
    /// overhead of checking for acceleration and using the more optimized
    /// routines to look for those bytes can cause overall performance to be
    /// worse than if acceleration wasn't enabled at all.
    ///
    /// A simple example of a regex that has an accelerated state is
    /// `(?-u)[^a]+a`. Namely, the `[^a]+` sub-expression gets compiled down
    /// into a single state where all transitions except for `a` loop back to
    /// itself, and where `a` is the only transition (other than the special
    /// EOI transition) that goes to some other state. Thus, this state can
    /// be accelerated and implemented more efficiently by calling an
    /// optimized routine like `memchr` with `a` as the needle. Notice that
    /// the `(?-u)` to disable Unicode is necessary here, as without it,
    /// `[^a]` will match any UTF-8 encoding of any Unicode scalar value other
    /// than `a`. This more complicated expression compiles down to many DFA
    /// states and the simple acceleration optimization is no longer available.
    ///
    /// Typically, this routine is used to guard calls to
    /// [`Automaton::accelerator`], which returns the accelerated bytes for
    /// the specified state.
    fn is_accel_state(&self, id: StateID) -> bool;

    /// Returns the total number of patterns compiled into this DFA.
    ///
    /// In the case of a DFA that contains no patterns, this must return `0`.
    ///
    /// # Example
    ///
    /// This example shows the pattern length for a DFA that never matches:
    ///
    /// ```
    /// use regex_automata::dfa::{Automaton, dense::DFA};
    ///
    /// let dfa: DFA<Vec<u32>> = DFA::never_match()?;
    /// assert_eq!(dfa.pattern_len(), 0);
    /// # Ok::<(), Box<dyn std::error::Error>>(())
    /// ```
    ///
    /// And another example for a DFA that matches at every position:
    ///
    /// ```
    /// use regex_automata::dfa::{Automaton, dense::DFA};
    ///
    /// let dfa: DFA<Vec<u32>> = DFA::always_match()?;
    /// assert_eq!(dfa.pattern_len(), 1);
    /// # Ok::<(), Box<dyn std::error::Error>>(())
    /// ```
    ///
    /// And finally, a DFA that was constructed from multiple patterns:
    ///
    /// ```
    /// use regex_automata::dfa::{Automaton, dense::DFA};
    ///
    /// let dfa = DFA::new_many(&["[0-9]+", "[a-z]+", "[A-Z]+"])?;
    /// assert_eq!(dfa.pattern_len(), 3);
    /// # Ok::<(), Box<dyn std::error::Error>>(())
    /// ```
    fn pattern_len(&self) -> usize;

    /// Returns the total number of patterns that match in this state.
    ///
    /// If the given state is not a match state, then implementations may
    /// panic.
    ///
    /// If the DFA was compiled with one pattern, then this must necessarily
    /// always return `1` for all match states.
    ///
    /// Implementations must guarantee that [`Automaton::match_pattern`] can be
    /// called with indices up to (but not including) the length returned by
    /// this routine without panicking.
    ///
    /// # Panics
    ///
    /// Implementations are permitted to panic if the provided state ID does
    /// not correspond to a match state.
    ///
    /// # Example
    ///
    /// This example shows a simple instance of implementing overlapping
    /// matches. In particular, it shows not only how to determine how many
    /// patterns have matched in a particular state, but also how to access
    /// which specific patterns have matched.
    ///
    /// Notice that we must use
    /// [`MatchKind::All`](crate::MatchKind::All)
    /// when building the DFA. If we used
    /// [`MatchKind::LeftmostFirst`](crate::MatchKind::LeftmostFirst)
    /// instead, then the DFA would not be constructed in a way that
    /// supports overlapping matches. (It would only report a single pattern
    /// that matches at any particular point in time.)
    ///
    /// Another thing to take note of is the patterns used and the order in
    /// which the pattern IDs are reported. In the example below, pattern `3`
    /// is yielded first. Why? Because it corresponds to the match that
    /// appears first. Namely, the `@` symbol is part of `\S+` but not part
    /// of any of the other patterns. Since the `\S+` pattern has a match that
    /// starts to the left of any other pattern, its ID is returned before any
    /// other.
    ///
    /// ```
    /// # if cfg!(miri) { return Ok(()); } // miri takes too long
    /// use regex_automata::{dfa::{Automaton, dense}, Input, MatchKind};
    ///
    /// let dfa = dense::Builder::new()
    ///     .configure(dense::Config::new().match_kind(MatchKind::All))
    ///     .build_many(&[
    ///         r"[[:word:]]+", r"[a-z]+", r"[A-Z]+", r"[[:^space:]]+",
    ///     ])?;
    /// let haystack = "@bar".as_bytes();
    ///
    /// // The start state is determined by inspecting the position and the
    /// // initial bytes of the haystack.
    /// let mut state = dfa.start_state_forward(&Input::new(haystack))?;
    /// // Walk all the bytes in the haystack.
    /// for &b in haystack {
    ///     state = dfa.next_state(state, b);
    /// }
    /// state = dfa.next_eoi_state(state);
    ///
    /// assert!(dfa.is_match_state(state));
    /// assert_eq!(dfa.match_len(state), 3);
    /// // The following calls are guaranteed to not panic since `match_len`
    /// // returned `3` above.
    /// assert_eq!(dfa.match_pattern(state, 0).as_usize(), 3);
    /// assert_eq!(dfa.match_pattern(state, 1).as_usize(), 0);
    /// assert_eq!(dfa.match_pattern(state, 2).as_usize(), 1);
    ///
    /// # Ok::<(), Box<dyn std::error::Error>>(())
    /// ```
    fn match_len(&self, id: StateID) -> usize;

    /// Returns the pattern ID corresponding to the given match index in the
    /// given state.
    ///
    /// See [`Automaton::match_len`] for an example of how to use this
    /// method correctly. Note that if you know your DFA is compiled with a
    /// single pattern, then this routine is never necessary since it will
    /// always return a pattern ID of `0` for an index of `0` when `id`
    /// corresponds to a match state.
    ///
    /// Typically, this routine is used when implementing an overlapping
    /// search, as the example for `Automaton::match_len` does.
    ///
    /// # Panics
    ///
    /// If the state ID is not a match state or if the match index is out
    /// of bounds for the given state, then this routine may either panic
    /// or produce an incorrect result. If the state ID is correct and the
    /// match index is correct, then this routine must always produce a valid
    /// `PatternID`.
    fn match_pattern(&self, id: StateID, index: usize) -> PatternID;

    /// Returns true if and only if this automaton can match the empty string.
    /// When it returns false, all possible matches are guaranteed to have a
    /// non-zero length.
    ///
    /// This is useful as cheap way to know whether code needs to handle the
    /// case of a zero length match. This is particularly important when UTF-8
    /// modes are enabled, as when UTF-8 mode is enabled, empty matches that
    /// split a codepoint must never be reported. This extra handling can
    /// sometimes be costly, and since regexes matching an empty string are
    /// somewhat rare, it can be beneficial to treat such regexes specially.
    ///
    /// # Example
    ///
    /// This example shows a few different DFAs and whether they match the
    /// empty string or not. Notice the empty string isn't merely a matter
    /// of a string of length literally `0`, but rather, whether a match can
    /// occur between specific pairs of bytes.
    ///
    /// ```
    /// use regex_automata::{dfa::{dense::DFA, Automaton}, util::syntax};
    ///
    /// // The empty regex matches the empty string.
    /// let dfa = DFA::new("")?;
    /// assert!(dfa.has_empty(), "empty matches empty");
    /// // The '+' repetition operator requires at least one match, and so
    /// // does not match the empty string.
    /// let dfa = DFA::new("a+")?;
    /// assert!(!dfa.has_empty(), "+ does not match empty");
    /// // But the '*' repetition operator does.
    /// let dfa = DFA::new("a*")?;
    /// assert!(dfa.has_empty(), "* does match empty");
    /// // And wrapping '+' in an operator that can match an empty string also
    /// // causes it to match the empty string too.
    /// let dfa = DFA::new("(a+)*")?;
    /// assert!(dfa.has_empty(), "+ inside of * matches empty");
    ///
    /// // If a regex is just made of a look-around assertion, even if the
    /// // assertion requires some kind of non-empty string around it (such as
    /// // \b), then it is still treated as if it matches the empty string.
    /// // Namely, if a match occurs of just a look-around assertion, then the
    /// // match returned is empty.
    /// let dfa = DFA::builder()
    ///     .configure(DFA::config().unicode_word_boundary(true))
    ///     .syntax(syntax::Config::new().utf8(false))
    ///     .build(r"^$\A\z\b\B(?-u:\b\B)")?;
    /// assert!(dfa.has_empty(), "assertions match empty");
    /// // Even when an assertion is wrapped in a '+', it still matches the
    /// // empty string.
    /// let dfa = DFA::new(r"^+")?;
    /// assert!(dfa.has_empty(), "+ of an assertion matches empty");
    ///
    /// // An alternation with even one branch that can match the empty string
    /// // is also said to match the empty string overall.
    /// let dfa = DFA::new("foo|(bar)?|quux")?;
    /// assert!(dfa.has_empty(), "alternations can match empty");
    ///
    /// // An NFA that matches nothing does not match the empty string.
    /// let dfa = DFA::new("[a&&b]")?;
    /// assert!(!dfa.has_empty(), "never matching means not matching empty");
    /// // But if it's wrapped in something that doesn't require a match at
    /// // all, then it can match the empty string!
    /// let dfa = DFA::new("[a&&b]*")?;
    /// assert!(dfa.has_empty(), "* on never-match still matches empty");
    /// // Since a '+' requires a match, using it on something that can never
    /// // match will itself produce a regex that can never match anything,
    /// // and thus does not match the empty string.
    /// let dfa = DFA::new("[a&&b]+")?;
    /// assert!(!dfa.has_empty(), "+ on never-match still matches nothing");
    ///
    /// # Ok::<(), Box<dyn std::error::Error>>(())
    /// ```
    fn has_empty(&self) -> bool;

    /// Whether UTF-8 mode is enabled for this DFA or not.
    ///
    /// When UTF-8 mode is enabled, all matches reported by a DFA are
    /// guaranteed to correspond to spans of valid UTF-8. This includes
    /// zero-width matches. For example, the DFA must guarantee that the empty
    /// regex will not match at the positions between code units in the UTF-8
    /// encoding of a single codepoint.
    ///
    /// See [`thompson::Config::utf8`](crate::nfa::thompson::Config::utf8) for
    /// more information.
    ///
    /// # Example
    ///
    /// This example shows how UTF-8 mode can impact the match spans that may
    /// be reported in certain cases.
    ///
    /// ```
    /// use regex_automata::{
    ///     dfa::{dense::DFA, Automaton},
    ///     nfa::thompson,
    ///     HalfMatch, Input,
    /// };
    ///
    /// // UTF-8 mode is enabled by default.
    /// let re = DFA::new("")?;
    /// assert!(re.is_utf8());
    /// let mut input = Input::new("☃");
    /// let got = re.try_search_fwd(&input)?;
    /// assert_eq!(Some(HalfMatch::must(0, 0)), got);
    ///
    /// // Even though an empty regex matches at 1..1, our next match is
    /// // 3..3 because 1..1 and 2..2 split the snowman codepoint (which is
    /// // three bytes long).
    /// input.set_start(1);
    /// let got = re.try_search_fwd(&input)?;
    /// assert_eq!(Some(HalfMatch::must(0, 3)), got);
    ///
    /// // But if we disable UTF-8, then we'll get matches at 1..1 and 2..2:
    /// let re = DFA::builder()
    ///     .thompson(thompson::Config::new().utf8(false))
    ///     .build("")?;
    /// assert!(!re.is_utf8());
    /// let got = re.try_search_fwd(&input)?;
    /// assert_eq!(Some(HalfMatch::must(0, 1)), got);
    ///
    /// input.set_start(2);
    /// let got = re.try_search_fwd(&input)?;
    /// assert_eq!(Some(HalfMatch::must(0, 2)), got);
    ///
    /// input.set_start(3);
    /// let got = re.try_search_fwd(&input)?;
    /// assert_eq!(Some(HalfMatch::must(0, 3)), got);
    ///
    /// input.set_start(4);
    /// let got = re.try_search_fwd(&input)?;
    /// assert_eq!(None, got);
    ///
    /// # Ok::<(), Box<dyn std::error::Error>>(())
    /// ```
    fn is_utf8(&self) -> bool;

    /// Returns true if and only if this DFA is limited to returning matches
    /// whose start position is `0`.
    ///
    /// Note that if you're using DFAs provided by
    /// this crate, then this is _orthogonal_ to
    /// [`Config::start_kind`](crate::dfa::dense::Config::start_kind).
    ///
    /// This is useful in some cases because if a DFA is limited to producing
    /// matches that start at offset `0`, then a reverse search is never
    /// required for finding the start of a match.
    ///
    /// # Example
    ///
    /// ```
    /// use regex_automata::dfa::{dense::DFA, Automaton};
    ///
    /// // The empty regex matches anywhere
    /// let dfa = DFA::new("")?;
    /// assert!(!dfa.is_always_start_anchored(), "empty matches anywhere");
    /// // 'a' matches anywhere.
    /// let dfa = DFA::new("a")?;
    /// assert!(!dfa.is_always_start_anchored(), "'a' matches anywhere");
    /// // '^' only matches at offset 0!
    /// let dfa = DFA::new("^a")?;
    /// assert!(dfa.is_always_start_anchored(), "'^a' matches only at 0");
    /// // But '(?m:^)' matches at 0 but at other offsets too.
    /// let dfa = DFA::new("(?m:^)a")?;
    /// assert!(!dfa.is_always_start_anchored(), "'(?m:^)a' matches anywhere");
    ///
    /// # Ok::<(), Box<dyn std::error::Error>>(())
    /// ```
    fn is_always_start_anchored(&self) -> bool;

    /// Return a slice of bytes to accelerate for the given state, if possible.
    ///
    /// If the given state has no accelerator, then an empty slice must be
    /// returned. If `Automaton::is_accel_state` returns true for the given ID,
    /// then this routine _must_ return a non-empty slice. But note that it is
    /// not required for an implementation of this trait to ever return `true`
    /// for `is_accel_state`, even if the state _could_ be accelerated. That
    /// is, acceleration is an optional optimization. But the return values of
    /// `is_accel_state` and `accelerator` must be in sync.
    ///
    /// If the given ID is not a valid state ID for this automaton, then
    /// implementations may panic or produce incorrect results.
    ///
    /// See [`Automaton::is_accel_state`] for more details on state
    /// acceleration.
    ///
    /// By default, this method will always return an empty slice.
    ///
    /// # Example
    ///
    /// This example shows a contrived case in which we build a regex that we
    /// know is accelerated and extract the accelerator from a state.
    ///
    /// ```
    /// use regex_automata::{
    ///     dfa::{Automaton, dense},
    ///     util::{primitives::StateID, syntax},
    /// };
    ///
    /// let dfa = dense::Builder::new()
    ///     // We disable Unicode everywhere and permit the regex to match
    ///     // invalid UTF-8. e.g., [^abc] matches \xFF, which is not valid
    ///     // UTF-8. If we left Unicode enabled, [^abc] would match any UTF-8
    ///     // encoding of any Unicode scalar value except for 'a', 'b' or 'c'.
    ///     // That translates to a much more complicated DFA, and also
    ///     // inhibits the 'accelerator' optimization that we are trying to
    ///     // demonstrate in this example.
    ///     .syntax(syntax::Config::new().unicode(false).utf8(false))
    ///     .build("[^abc]+a")?;
    ///
    /// // Here we just pluck out the state that we know is accelerated.
    /// // While the stride calculations are something that can be relied
    /// // on by callers, the specific position of the accelerated state is
    /// // implementation defined.
    /// //
    /// // N.B. We get '3' by inspecting the state machine using 'regex-cli'.
    /// // e.g., try `regex-cli debug dfa dense '[^abc]+a' -BbUC`.
    /// let id = StateID::new(3 * dfa.stride()).unwrap();
    /// let accelerator = dfa.accelerator(id);
    /// // The `[^abc]+` sub-expression permits [a, b, c] to be accelerated.
    /// assert_eq!(accelerator, &[b'a', b'b', b'c']);
    /// # Ok::<(), Box<dyn std::error::Error>>(())
    /// ```
    #[inline]
    fn accelerator(&self, _id: StateID) -> &[u8] {
        &[]
    }

    /// Returns the prefilter associated with a DFA, if one exists.
    ///
    /// The default implementation of this trait always returns `None`. And
    /// indeed, it is always correct to return `None`.
    ///
    /// For DFAs in this crate, a prefilter can be attached to a DFA via
    /// [`dense::Config::prefilter`](crate::dfa::dense::Config::prefilter).
    ///
    /// Do note that prefilters are not serialized by DFAs in this crate.
    /// So if you deserialize a DFA that had a prefilter attached to it
    /// at serialization time, then it will not have a prefilter after
    /// deserialization.
    #[inline]
    fn get_prefilter(&self) -> Option<&Prefilter> {
        None
    }

    /// Executes a forward search and returns the end position of the leftmost
    /// match that is found. If no match exists, then `None` is returned.
    ///
    /// In particular, this method continues searching even after it enters
    /// a match state. The search only terminates once it has reached the
    /// end of the input or when it has entered a dead or quit state. Upon
    /// termination, the position of the last byte seen while still in a match
    /// state is returned.
    ///
    /// # Errors
    ///
    /// This routine errors if the search could not complete. This can occur
    /// in a number of circumstances:
    ///
    /// * The configuration of the DFA may permit it to "quit" the search.
    /// For example, setting quit bytes or enabling heuristic support for
    /// Unicode word boundaries. The default configuration does not enable any
    /// option that could result in the DFA quitting.
    /// * When the provided `Input` configuration is not supported. For
    /// example, by providing an unsupported anchor mode.
    ///
    /// When a search returns an error, callers cannot know whether a match
    /// exists or not.
    ///
    /// # Notes for implementors
    ///
    /// Implementors of this trait are not required to implement any particular
    /// match semantics (such as leftmost-first), which are instead manifest in
    /// the DFA's transitions. But this search routine should behave as a
    /// general "leftmost" search.
    ///
    /// In particular, this method must continue searching even after it enters
    /// a match state. The search should only terminate once it has reached
    /// the end of the input or when it has entered a dead or quit state. Upon
    /// termination, the position of the last byte seen while still in a match
    /// state is returned.
    ///
    /// Since this trait provides an implementation for this method by default,
    /// it's unlikely that one will need to implement this.
    ///
    /// # Example
    ///
    /// This example shows how to use this method with a
    /// [`dense::DFA`](crate::dfa::dense::DFA).
    ///
    /// ```
    /// use regex_automata::{dfa::{Automaton, dense}, HalfMatch, Input};
    ///
    /// let dfa = dense::DFA::new("foo[0-9]+")?;
    /// let expected = Some(HalfMatch::must(0, 8));
    /// assert_eq!(expected, dfa.try_search_fwd(&Input::new(b"foo12345"))?);
    ///
    /// // Even though a match is found after reading the first byte (`a`),
    /// // the leftmost first match semantics demand that we find the earliest
    /// // match that prefers earlier parts of the pattern over latter parts.
    /// let dfa = dense::DFA::new("abc|a")?;
    /// let expected = Some(HalfMatch::must(0, 3));
    /// assert_eq!(expected, dfa.try_search_fwd(&Input::new(b"abc"))?);
    ///
    /// # Ok::<(), Box<dyn std::error::Error>>(())
    /// ```
    ///
    /// # Example: specific pattern search
    ///
    /// This example shows how to build a multi-DFA that permits searching for
    /// specific patterns.
    ///
    /// ```
    /// # if cfg!(miri) { return Ok(()); } // miri takes too long
    /// use regex_automata::{
    ///     dfa::{Automaton, dense},
    ///     Anchored, HalfMatch, PatternID, Input,
    /// };
    ///
    /// let dfa = dense::Builder::new()
    ///     .configure(dense::Config::new().starts_for_each_pattern(true))
    ///     .build_many(&["[a-z0-9]{6}", "[a-z][a-z0-9]{5}"])?;
    /// let haystack = "foo123".as_bytes();
    ///
    /// // Since we are using the default leftmost-first match and both
    /// // patterns match at the same starting position, only the first pattern
    /// // will be returned in this case when doing a search for any of the
    /// // patterns.
    /// let expected = Some(HalfMatch::must(0, 6));
    /// let got = dfa.try_search_fwd(&Input::new(haystack))?;
    /// assert_eq!(expected, got);
    ///
    /// // But if we want to check whether some other pattern matches, then we
    /// // can provide its pattern ID.
    /// let input = Input::new(haystack)
    ///     .anchored(Anchored::Pattern(PatternID::must(1)));
    /// let expected = Some(HalfMatch::must(1, 6));
    /// let got = dfa.try_search_fwd(&input)?;
    /// assert_eq!(expected, got);
    ///
    /// # Ok::<(), Box<dyn std::error::Error>>(())
    /// ```
    ///
    /// # Example: specifying the bounds of a search
    ///
    /// This example shows how providing the bounds of a search can produce
    /// different results than simply sub-slicing the haystack.
    ///
    /// ```
    /// use regex_automata::{dfa::{Automaton, dense}, HalfMatch, Input};
    ///
    /// // N.B. We disable Unicode here so that we use a simple ASCII word
    /// // boundary. Alternatively, we could enable heuristic support for
    /// // Unicode word boundaries.
    /// let dfa = dense::DFA::new(r"(?-u)\b[0-9]{3}\b")?;
    /// let haystack = "foo123bar".as_bytes();
    ///
    /// // Since we sub-slice the haystack, the search doesn't know about the
    /// // larger context and assumes that `123` is surrounded by word
    /// // boundaries. And of course, the match position is reported rel     Rasser)eeq!(r    /Aye(Ha(r

    / let // this c ing mean`ide its pattern ID.
    /// let i&/        3..6])DFA::new("abc|a")?;
    /// let expected = Some(HalfMatch::must(1, 6));
    /// let got = dfa.try_search_fwd(&input)?;
    /// assert_eq!(expected, got);
    ///
   we
    /ows how providice the hayo usthat co    ///  a search for any s usrce we sub-slice't,
    /// /ound Anot   Rass that. Thi   ///e position and a slithat. (// ///
    /dics dece a '+' iapping m that may
 rtion, even ifhe given ' only nd a ` we sub-this c ing meulti-sser)eeq// // return fan ID.
    /// let input = In.range(3..6)DFA::new("abc|a")?;
    / mut last_matct(1, 6));
    /// let got = dfa.try_search_fwd(&input)?;
    /// assert_eq!(expected, got);
    ///
    /// # Ok::<(), Box<dyn std::error::Error>>(()erialization.
   /// let got = dtateID) ->  fn tateID) -a.try: fa.try<'_ix_bytetion<u8>,
    /// ) -> Result<Option<HalfMatch>, n() {
  ().u alway=trans  /// assert &&trans   /// ass;ch>, n() {
  hm         let go::      = dffn matc.try_satch>, n()             # if cfg!(ck, S,
  ///            hm)///
!().u alway=  # if cfg!(     hm)S,
  ///            hm)/=  hm,
  ///   };ch>, n() new()
et /tterns ct the wparticuhe sethat if n one branch that can match then() newANDes are enabled, as when UTF.    ///
 occurredhen weoingited to retu  ///    matc' only use 1sthat
    ///. Smatch/ // Even n, then thie this   ///   includes
    //,eful in s enabled, a// // Sinch that rl # ExNles dowitly walermitue))beneficple, it'se _must_ rF-8. e.g impespond to spas dowitly waTe di ID ,eoingited cple, e prothat comidd/// A sisplit the an errs dowitly wa or for findi imperrespond to spything,
  and `accill alwayng the star  ///   neneficis usrredhen weit // bat` conis alable producing
    hes th star  ///  oding of a sing  ///  star  ///  .
    ///
 this crf the But ie largerp optioCeturns *an * we
    / whethe  ///  .nste use enabled, a // UTF-8utds of a sse _must_ rF-8. e.gg
    h whethe  ///  ch
    ///        /in thi/ b/ Thd in
   this DFtion thauns for
   s dowitly wa ohavi insteadddddust_ ::en w_use 1s  = ditomatohm,ohm/// assert_|itoma|atch>, n()     t(1, 6));
let go::      = dffn matc.try_s;ch>, n()     g!( 6)on(|&bhm| (hm,ohm/// asser)::error/   })er> {
        None
    }

 ffset `0`, then a forward searcd for fin /// termination, tlast_matct(
    // leftmost
    /// match that is found. If no match exismpty slice must bestate is returned.
    ///
    /// # Errors
    ///
    /// This routine errors if the search could not complete. This can occur
    /// in a number of circumstances:
    ///
    /// * The configuration of the DFA may permit it to "quit" the search.
    /// For example, setting quit bytes or enabling heuristic support for
    /// Unicode word boundaries. The default configuration does not enable any
    /// option that could result in the DFA quitting.
    /// * When the provided `Input` configuration is not supported. For
    /// example, by providing an unsupported anchor mode.
    ///
    /// When a search returns an error, callers cannot know whether a match
    /// exists or not.
    ///
    /// # Example
    ///
    /// This example shows how to use this method with a
    /// [`dense::DFA`](crate:h.
    ///
    /// Ithe more optimizlengtmatcipng of/
    /s are, thiioutinjunc /// // An, tlast_matc[`ig::utf8`](crate::nfa::ffset `pson::Config::utf8`](crate::nfa::ffset `)x of `0` whrovided `In:h.
 have as,y default,
    /o
    /d, it is tice that wet-fiait / let got = // `is_t / let gotffs` // An, tterns uld es bearch_fwd(& that matches instettertartinabling -DFA that iternatdi, it search configura gua it is  earlier parator from a state.
    ///
    /// ```
    /// use regex_automaton},
    ///     nfa::thomta::{
    ///     dfa::{Automaton, dense},
    /Match, PatternID, Input,
    /// };
    ///
    /// let dfa = dense::Builder::ner()
    ///     .thompson(thompsffset `alize_start_states(true))
 = dense::DFA::new("foo[0-9]+")?;
    /// let expected = Some(H0lfMatch::must(0, 3));
    /// assert_eq!(expecteffsdfa.try_search_fwd(&Input::new(b"foo12345"))?);
    ///
    /// // Even though a match is found e position(`cthe first byte (`a`),
    /// // the leftmost first match semantics demand that we find the earliest
    /// // match that prefers earlier parts of the pattern over latter parts.
    /// let dfa = dense::Builder::ner()
    ///     .thompson(thompsffset `alize_start_states(true))
 = dencFA::new("foo[0-9]+")?;
    /// let expected = Some(H0lfMatch::must(0, 3));
    /// assert_eq!(expecteffsdfa.try_search_fwd(&Input::new(b"abc"))?);
    ///
    /// # Ok::<(), Box<dyn std::error::Error>>(())
    /// ```
    ///
  enabled, 
    /// # Example
    ///
  s to
    /// .gg
    enabled, aacceleratioffset `refilter).FAs.t.
    ///
    /// When UTF that cohat rl # ExNlehas no aessary since is enabled, allular, t/ guaranteedspond to spy impaans of valid UTF-8. This  /
    # Ex includes
    /// ng
    hes thcoding of a single codepoint   ///
    /// // UTF-8 mode is epty strid. InThis eand wher includes
sary since is enabled, allimiza matc    enabl /// Unico: in certain cases.
    ///
    /// ```
    /// use regex_automata::{
    ///     dfa::{dense::DFA, Automaton},
    ///     nfa::thompson,
    ///    on, dense}, PatternID, Input,
    /// };
    ///

    /// let re = DFA::builder()
    ///     .thompson(thompsffset `alize_start_states(true))
 r"  .build("[^abc]+a")?;
 Runrywhereset `0hat cancoturct8 mode is en.rt!(re.is_utf8());
    /// let mut input = Input::new("�8())e is ena= vec![] Input::news exe regex_automarliestert_eq!(expecteffsdfc.try_satch>, build_many(&                  None => break     hm)/=  pos, prefix_byte) {
  e is en.push hm)                 };
  is hm/// asser == 0 ||);
    ender == 0 pos, prefix_byte) {
    //     :quit(b, pos - 1));
    ///     hm/// asser <);
    ender pos, prefix_byte) {
    //;
    ///
endehm/// asser):quit(b, pos - 1));
    ///  {ng the DFA through
    ///  .
    // wher routine ihether cod includes
sary sincA through
    ///  ome othere(Ha(r/ boundar match    // demonstrate in this exarough
    ///  W/// thi// dslice the hayead, th of tadva bearch_fwd( exarough
    ///  cept/// sefuyo demandnd the
 ng the start oix_byte) {
    //;
    ///
ende;
    ender -dfa.pattern_l        }
    ///             }
    ///         }
    st_match)
    /// }
 NorF-8. e.g ies thcoding of a single [0-9]+")?;
    /vec![    nfa::thompson,
   d = Some(Hal,    nfa::thompson,
   d = Some(Hch_pattern(s]Match::must(0, 3));
    /// assF-8. e.put::new(b"abc"))?);
    ///
    /// # Ok::<(), Box<dyn std::error::Error>>(())
    /// ``Nis 0-9's   ///// patterns rted. For
utte use enabled, ao common bytes, rig /// .nst   /// d snowman    /// ilte  ///# Ex enabled, ao common bytes,rate: in certain cases.
    ///
    /// ```
    /// use regex_automata::{
    ///     dfa::{dense::DFA, Automaton},
    ///     nfa::thompson,
    ///    on, dense}, PatternID, Input,
    /// };
    ///

    /// let re = DFA::builder()
    ///     .thompson(thompsffset `alize_tax::Config::new().utf8(false))
     .build("[^abc]+a")?;
 Runrywhereset `0hat cancoturct8 mode is en.rt!(re.is_utf8());
    /// let mut input = Input::new("�8())e is ena= vec![] Input::news exe regex_automarliestert_eq!(expecteffsdfc.try_satch>, build_many(&                  None => break     hm)/=  pos, prefix_byte) {
  e is en.push hm)                 };
  is hm/// asser == 0 ||);
    ender == 0 pos, prefix_byte) {
    //     :quit(b, pos - 1));
    ///     hm/// asser <);
    ender pos, prefix_byte) {
    //;
    ///
endehm/// asser):quit(b, pos - 1));
    ///  {ng the DFA through
    ///  .
    // wher routine ihether cod includes
sary sincA through
    ///  ome othere(Ha(r/ boundar match    // demonstrate in this exarough
    ///  W/// thi// dslice the hayead, th of tadva bearch_fwd( exarough
    ///  cept/// sefuyo demandnd the
 ng the start oix_byte) {
    //;
    ///
ende;
    ender -dfa.pattern_l        }
    ///             }
    ///         }
    st_match)
    /// }
 NorF-8. e.g ies thcoding of a single [0-9]+")?;
    /vec![    nfa::thompson,
   d = Some(Hal,    nfa::thompson,
   d = Some(H2l,    nfa::thompson,
   d = Some(H1l,    nfa::thompson,
   d = Some(Hch_pattern(s]Match::must(0, 3));
    /// assF-8. e.put::new(b"abc"))?);
    ///
    /// # Ok::<(), Box<dyn std::error::Error>>(()erialization.
   /// let gotffsdtateID) ->  fn tateID) -a.try: fa.try<'_ix_bytetion<u8>,
    /// ) -> Result<Option<HalfMatch>, n() {
  ().u alway=trans  /// assert &&trans   /// ass;ch>, n() {
  hm         let go::     ffsdfn matc.try_satch>, n()             # if cfg!(ck, S,
  ///            hm)///
!().u alway=  # if cfg!(     hm)S,
  ///            hm)/=  hm,
  ///   };ch>, n() ust_ ::en w_use 1s ffsditomatohm,ohm/// assert_|itoma|atch>, n()     t(1, 6));
let go::     ffsdfn matc.try_s;ch>, n()     g!( 6)on(|&bhm| (hm,ohm/// asser)::error/   })er> {
        None
    }

hen implement    /// Execute.Optiontheriated with a ,n::match_patternobbe r   viaemand[`O implementrator:: #[i     `]ws how ./
    /// # Errors
    ///
   engtmatcipng of wher/
    /s are-DFA that pers construdetermine how manyInpu.trys   ///  constructed fromuratie branch terns / ` the't merely a  ///:h.
    ///
    /returns ular,e `[ervot   Rstate ID 'sng the bounds oin a mat thetmaor/ // Thable Unimandnrait provides r, cs   /// und e poent any particumatchr bestate is returnedW are, s foun    ///
    are not requir strin  // a e of implementing overlappiears fid for`ovidice the haystate. /// indbe tht is  eare returns `Nion, the pos of a zIfanslatd both
    /// // patte `vious   cpon
   for the given Ieypattern
 immedhe pches.must be
(.
    //accekTF-8 m   ///
  on bytes, theplement ed a d) Ors cwiaries. Aine errorar, thisatsearcd forlementing ov terminat//
  r` must be in sync.
 pers to c      ate.
 /// /. Aine erris peret /arch d// // `viousbounds oin a ma a ford for /. Aine erre, ihat matches ate same st are-Dt get '3'bounds oin a mais [`O implementrator::d for`]fault, ces to sst
   estate is returned.
    ///
    /// # Errors
    ///
    /// This routine errors if the search could not complete. This can occur
    /// in a number of circumstances:
    ///
    /// * The configuration of the DFA may permit it to "quit" the search.
    /// For example, setting quit bytes or enabling heuristic support for
    /// Unicode word boundaries. The default configuration does not enable any
    /// option that could result in the DFA quitting.
    /// * When the provided `Input` configuration is not supported. For
    /// example, by providing an unsupported anchor mode.
    ///
    /// When a search returns an error, callers cannot know whether a match
    /// exists or not.
    ///
    /// # Example
    ///
    /// This exaru   /basmenttheplement ehe hayo use this method with a
    /// [`dense::DFA`](crate:h.
    ///
    /mple s'3'bounds oi and only filter must use
    /// whrovided `In:hOtheplement ehe haUTF-8. This  ///lt,
    /o
r
 kbat`t's ulterna  ////s are, // Since we areerror::Errwe used
    /// [`MatchKithe leftmost fir,mes be using the defaenting overlaptice t f// U provg of panmd bns fa DFA wtheplement ehe haUTn the DFA tring.
 wtheplement ehe haUTkely thatalable producing
    ytride ee   for the able Un semantics (such ehe haUTkault, this method must continue seaaent any particu inpbof tob[ervoF thaerns uis ps demand thvs useratih and returneturns `Nion, th of a zMslatesnc///ng.
 emantics (such ehe haUTk  // it h`1` fo for the gosearch shou ///
    ue seaarching forrather, w tha// mcodepo///eat `n the DFA Otheplement ehe haUThis c ingds  earopd retelied
this mget '3' b the bounds oiis ps demoovg ofnew producin(pots usng of f /// of any of ) specific patterns.
    ///
    /// ```
    /// # if cfg!(miri) { return Ok(()); } // miri takes too long
    /// use regex_automata::{
    ///    O implementrator   dfa::{Automaton, dense},
    /Match,on, dense}, PatternID, Input,
    /// };
    ///
    /// let dfa = dense::Builder::new()
    ///     .configure(dense::Config::new().match_kind(MatchKind::All))
    /// [
    ///    $"[a-z]+", r"[A-Z]+$ "[a-z][a-z0-9]{5}"])?;
    //@foo";s of the haystack.
    //O implementrator::d foroo123bar".as_bytes()ust(1)));
    /// let expected = Some(H4r):quit(b, pert_eq!(expectewtheplementt = dfa.try_search_fwd(&In, &tack.
   _search_fwd(&input)?;
    /// assed a d #[i     er):quit(b, ch_len(state), 3)sition, onlyring
 / // But '(ch terns ate same ssatal-ru natch the empty ice the hayo lt,rn `3n a/// of of a z.
    /ing
 e Unimand defaenting ovine how maer pattern, iue seaice thew(d zero lengful in sice thew(denting ovine how maeb ` nsd// /ratherts ID imand defa,ng to trs ID is match th find the earliest a fg to unabled, allt
    new("foo[0-9]+")?;
    /// let expected = Some(H4r):quit(b, pert_eq!(expectewtheplementt = dfa.try_search_fwd(&In, &tack.
   _search_fwd(&input)?;
    /// assed a d #[i     er):quit(b, ch_len(st;
    ///
    /// # Ok::<(), Box<dyn std::error::Error>>(()erialization.
   /// let gotwtheplementt = dtateID) ->  fn tateID) -a.try: fa.try<'_ix_byteaystack {: &tackO implementrator _bytetion<u8>,
  //
 ption<HalfMatch>, n() {
  ().u alway=trans  /// assert &&trans   /// ass;ch>, n() let go::     wtheplementt = dfn matc.try,k.
   _search_tomarliested a d #[i     eratch>, n()             g!(mir,
  ///            _)///
!().u alway=  g!(mir,
  ///            _)/=  en w_ alwa/// a_use 1s wtheplement(
x_byte) {
    //;
   ,
x_byte) {
    //sator _byteeeeeeeeeeeee|c.try,k.
   |atch>, n()     h>, n() let go::     wtheplementt = dfn matc.try,k.
   _ch>, n()     h>, } _byteeeeeeeeer,
  ///   }er> {
        None
    }

 ffset `0n implement    /// Execute.Optiontheriated with a ,eeds to hante, aobbe r   viaemand[`O implementrator:: #[i     `]ws how ./
    /// # ErrorW are, s foun    ///
    are not requir strin  // a e of implementing overlappiears fid for`ovidice the haystate. rmosin ch
 ri/// /.r    he match indstrin `In:hr(id)O implementrator`///
   l     Rahe hayo lt,keep/acceketurns `Nion, thtchr nt/ termination, thxecute.O(ero lengful in s construdetermine/ // Butrati that may
   '(ch terns ate same ssattarting pb the bounds oinrait provides /// // r, cs   /  l  adva ben /// termina// // retue in sync.
 pers to c      ate.
 /// /. Aine erris peret /arch d// // `viousbounds oin a ma a ford for /. Aine erre, ihat matches ate same st are-Dt get '3'bounds oin a mais [`O implementrator::d for`]fault, ces to sst
   estate is returned.
    ///
    /// # Errors
    ///
    /// This routine errors if the search could not complete. This can occur
    /// in a number of circumstances:
    ///
    /// * The configuration of the DFA may permit it to "quit" the search.
    /// For example, setting quit bytes or enabling heuristic support for
    /// Unicode word boundaries. The default configuration does not enable any
    /// option that could result in the DFA quitting.
    /// * When the provided `Input` configuration is not supported. For
    /// example, by providing an unsupported anchor mode.
    ///
    /// When a search returns an error, callers cannot know whether a match
    /// exists or not.
    ///
  enabled, 
    /// # Example
    ///
  s to
    /// .gg
    enabled, aacceleratioffset `refilter).FAs.t.
    ///
    /// When UTF that cohat rl # ExNlehas no aessary since is enabled, allular, t/ guaranteedspond to spy impaans of valid UTF-8. This  /
    # Ex includes
    /// ng
    hes thcoding of a single codepoint   ///
    /// // UTF-8 mode is epty strid. InThis eand wher includes
sary since is enabled, allimiza matc    enabl /// Unico: in certain cases.
    ///
    /// ```
    /// use regex_automata::{
    ///     dfa::{den  O implementratorse::DFA, Automaton},
    ///     nfa::thompson,
    ///    on, dense}, PatternID, Input,
    /// };
    ///

    /// let re = DFA::builder()
    ///     .configse::Config::new().match_kind(MatchKind::Aer()
    ///     .thompson(thompsffset `alize_start_states(true))
    /// [
"[a-zput ] .build("[^abc]+a")?;
 Runrywhereset `0hat cancoturct8 mode is en.rt!(re.is_utf;
    /// let mut input = Input::new("�8()).
    //O implementrator::d foroo123bar".aew("�8())e is ena= vec![] Input::news exe regex_automaert_eq!(expectewtheplementtffsdfc.try, &tack.
   _search_fwd(tomarliested a d #[i     eratch>, build_many(&                  None => break     hm)/=  e is en.push hm),
    ///         }
    st_match)
    /// }
 NorF-8. e.g ies thcoding of a single [0-9]+")?;
    /vec![    nfa::thompson,
   d = Some(Hal,    nfa::thompson,
   d = Som1(Hch_pattern(sthompson,
   d = Some(Hch_pattern(s]Match::must(0, 3));
    /// assF-8. e.put::new(b"abc"))?);
    ///
    /// # Ok::<(), Box<dyn std::error::Error>>(())
    /// ``Nis 0-9's   ///// patterns rted. For
utte use enabled, ao common bytes, rig /// .nst   /// d snowman    /// ilte  ///# Ex enabled, ao common bytes,rate: in certain cases.
    ///
    /// ```
    /// use regex_automata::{
    ///     dfa::{den  O implementratorse::DFA, Automaton},
    ///     nfa::thompson,
    ///    on, dense}, PatternID, Input,
    /// };
    ///

    /// let re = DFA::builder()
    ///     .configse::Config::new().match_kind(MatchKind::Aer()
    ///     .thompson(thompsffset `alize_tax::Config::new().utf8(false))
    /// [
"[a-zput ] .build("[^abc]+a")?;
 Runrywhereset `0hat cancoturct8 mode is en.rt!(re.is_utf;
    /// let mut input = Input::new("�8()).
    //O implementrator::d foroo123bar".aew("�8())e is ena= vec![] Input::news exe regex_automaert_eq!(expectewtheplementtffsdfc.try, &tack.
   _search_fwd(tomarliested a d #[i     eratch>, build_many(&                  None => break     hm)/=  e is en.push hm),
    ///         }
    st_match)
    /// }
 Now * mo*l not match   //,eontino usthahcoding of e first byte ful in s    ift once a// // Swill ne  /// // An matches, tht/ guaranteedspond to spy impaa single [0-9]+")?;
    /vec![    nfa::thompson,
   d = Some(Hal,    nfa::thompson,
   d = Some(H2l,    nfa::thompson,
   d = Some(H1l,    nfa::thompson,
   d = Som1(Hch_pattern(sthompson,
   d = Some(Hch_pattern(s]Match::must(0, 3));
    /// assF-8. e.put::new(b"abc"))?);
    ///
    /// # Ok::<(), Box<dyn std::error::Error>>(()erialization.
   /// let gotwtheplementtffsdtateID) ->  fn tateID) -a.try: fa.try<'_ix_byteaystack {: &tackO implementrator _bytetion<u8>,
  //
 ption<HalfMatch>, n() {
  ().u alway=trans  /// assert &&trans   /// ass;ch>, n() let go::     wtheplementtffsdfn matc.try,k.
   _search_tomarliested a d #[i     eratch>, n()             g!(mir,
  ///            _)///
!().u alway=  g!(mir,
  ///            _)/=  en w_ alwa/// a_use 1s wtheplement(
x_byte) {
    //;
   ,
x_byte) {
    //sator _byteeeeeeeeeeeee|c.try,k.
   |atch>, n()     h>, n() let go::     wtheplementtffsdfn matc.try,k.
   _ch>, n()     h>, } _byteeeeeeeeer,
  ///   }er> {
        NoWritSinch ttht oftd both
  ne  /// //"'(?m:^)a that co//
     the bounds oi provided `Inp a `d btht` zIfanconstructed fromura/// // patternsenting ov terminata demandhat rl # Exuld ey provs0n implement ome other pattaessary since is  at ted fromuimizwritt   l     R//
      a single codepoint n  ss8 moders earlier pa serializehes rep ase},
     patthave aslymits searchiak nevializeault,visrchi dissitionthat coy sub-slicing the haystackTtransitions. But th*ult conf* clitis earlier par   akTtran//
 ss to ever returlex   e 1y l     Rreturn (-cli'.ru natcanconstrucehe haUTkau An, tlast_matcerns aier par   )or
uttult cmAnot   RAPIr
ug-  /ne
    /// Nore, s fnce it has reerns aier par    pers construcehe haUTkb());
/eat `as rm /o
  eturns `None`peat f a single codepointIf ihatcan prov ome otF-8utd   R//
   `AnchoreSht`ault confi roulast_matceufficiehe anpac 1y l  sttf8) tserializatut` conin0, 3 know isilehelymits seardropp bestate is returned.
    ///
    /// # Errors
    ///
    /// This routine errors if the search could not complete. This can occur
    /// in a number of circumstances:
    ///
    /// * The configuration of the DFA may permit it to "quit" the search.
    /// For example, setting quit bytes or enabling heuristic support for
    /// Unicode word boundaries. The default configuration does not enable any
    /// option that could result in the DFA quitting.
    /// * When the provided `Input` configuration is not supported. For
    /// example, by providing an unsupported anchor mode.
    ///
    /// When a search returns an error, callers cannot know whether a match
    /// exists or not.
    ///
    /// # Example
    ///
    /// This exacs decmode is  at ted fromucan o we sub-sow whetherntino are-omucted fromura/// // patternsv terminatas /// of any of  specific patterns.
    ///
    /// ```
    /// # if cfg!(miri) { return Ok(()); } // miri takes too long
    /// use regex_automata::{
    ///     dfa://   se::DFA, Automa//    on, dense}, AnchoreSht, PatternID, Input,
    /// };
  ted fromu= &[    nfa::thom[
    ///    ",    nfa::thom[
 se::DF,    nfa::thom[
   alpha    ",    nfa::thom[
foo",    nfa::thom[
hays,    nfa::thom[
hayfoo",    nfa::thom[
foohays,    nfa::];    /// };
    ///

    /// let re = DFA::builder()
    ///     .configse::Config::new().match_kind(MatchKind::Ase))
    // any of )?, Input,
    /// };
  ;
    /// let mut infoohayso123bar".aew("�8())d btht //AnchoreSht mut iert_ any of_leh(r):quit(b, pert_eq!(nowma wtheplementtome othdfc.try, &tackd bthtA::new("foo[0-9]+")?;
    /vec![e(H2(Ha, 4, 6] last_matct(1, 6): Vec<, sze>  /d btht.strifigsep(|p| ptack, szenew(coturct()earch_fwd(&input)?;
    /// assert_eq!(expected, got);
    ///
    /// # Ok::<(), Box<dyn std::error::Error>>(()er ``(feaif   //"cmooc")]>>(()erialization.
   /// nowma wtheplementtome othdtateID) ->  fn tateID) -a.try: fa.try<'_ix_byteaystd btht: &tackAnchoreSht, Patttion<u8>,
  //
 ption<HalfMatch>, n() {
  8()).
    //O implementrator::d foroo123barrrrrhe las{
       m)/=atch>, n()     rans /// let gotwtheplementt = dc.try, &tack.
   _search_{
    //satord #[i     er
  ///   }atch>, n()     t(1,_  /d btht.sn0, 3(m_ any of(r):quit( dowitly waTe di't` co  at   // exacs d ssaty. Affertop. Or    Rreturnquit( dowitly waaskTF-u)); .
       };
  is d btht.ss_fullera||);
     #[i that weeratch>, n()       //     :quit(  ///   }er> {/   }er> {/   g!(mirer> {
 
  , bafndnrai<'a, A: dfa::{den + ?Sers > dfa::{den pers&'a Aatch>, erialization.
   nextutomatdffn mattchr ntlerator(&,-a.try: u8tion<rator(&atch>, n() (**fn ge.nextutomatdtchr ntatc.try_er> {
      erialization.
, bafnd   nextutomat_unBut ie dtateID) ->  fn tateID) -tchr ntlerator(&,tateID) -a.try: u8, Patttion<rator(&atch>, n() (**fn ge.nextutomat_unBut ie dtchr ntatc.try_er> {
      erialization.
   nextueoiutomatdffn mattchr ntlerator(&tion<rator(&atch>, n() (**fn ge.nextueoiutomatdtchr nt_er> {
      erialization.
   
    ftomat_   /// dtateID) ->  fn tateID) -a.try: fa.try<'_ix_bytetion<u8>,
  rator(&,-ption<HalfMatch>, n() (**fn ge.
    ftomat_   /// dc.try_er> {
      erialization.
   
    ftomat_ffset `atateID) ->  fn tateID) -a.try: fa.try<'_ix_bytetion<u8>,
  rator(&,-ption<HalfMatch>, n() (**fn ge.
    ftomat_ffset `ac.try_er> {
      erialization.
   uniset al_
    ftomatdffn matnsup:ense},
  et_prefilterrator(&Match>, n() (**fn ge.uniset al_
    ftomatdnsup_er> {
      erialization.
   ss_chingalftomatdffn matcelerator(&self,nchoatch>, n() (**fn ge.ss_chingalftomatdid_er> {
      erialization.
   ss_ it ftomatdffn matcelerator(&self,nchoatch>, n() (**fn ge.ss_ it ftomatdid_er> {
      erialization.
   ss_resuftomatdffn matcelerator(&self,nchoatch>, n() (**fn ge.ss_resuftomatdid_er> {
      erialization.
   ss_se::Cotomatdffn matcelerator(&self,nchoatch>, n() (**fn ge.ss_se::Cotomatdid_er> {
      erialization.
   ss_
    ftomatdffn matcelerator(&self,nchoatch>, n() (**fn ge.ss_c    ftomatdid_er> {
      erialization.
   ss_e [`Automatdffn matcelerator(&self,nchoatch>, n() (**fn ge.ss_e [`Automatdid_er> {
      erialization.
    any of_leh( fn get_pr, szeatch>, n() (**fn ge. any of_leh(rer> {
      erialization.
   se::Coleh( fn gatcelerator(&self,, szeatch>, n() (**fn ge.se::Coleh(id_er> {
      erialization.
   se::Co any of( fn gatcelerator(&,None`x:,, szeself,Anchored:atch>, n() (**fn ge.se::Co any of(id,None`x_er> {
      erialization.
    /// asser fn get_prnchoatch>, n() (**fn ge. /// asserter> {
      erialization.
   ss_// as fn get_prnchoatch>, n() (**fn ge.  /// asser> {
      erialization.
   ss_e// in_c    fack)
     fn get_prnchoatch>, n() (**fn ge.  /e// in_c    fack)
    ser> {
      erialization.
    #[inline]
    fn acelerator(&self, _id: StateID) -(**fn ge.accelerator = der> {
      erialization.
    #[inline]
    fn get_prefilter(&self) -> Option<&Pre(**fn ge. #[inline]
   der> {
      erialization.
   /// let got = dtateID) ->  fn tateID) -a.try: fa.try<'_ix_bytetion<u8>,
    /// ) -> Result<Option<HalfMatch>, n() (**fn ge./// let got = dc.try_er> {
      erialization.
   /// let gotffsdtateID) ->  fn tateID) -a.try: fa.try<'_ix_bytetion<u8>,
    /// ) -> Result<Option<HalfMatch>, n() (**fn ge./// let gotffsditoma_er> {
      erialization.
   /// let gotwtheplementt = dtateID) ->  fn tateID) -a.try: fa.try<'_ix_byteaystack {: &tackO implementrator _bytetion<u8>,
  //
 ption<HalfMatch>, n() (**fn ge./// let gotwtheplementt = dc.try, .
   _ch>, 
      erialization.
   /// let gotwtheplementtffsdtateID) ->  fn tateID) -a.try: fa.try<'_ix_byteaystack {: &tackO implementrator _bytetion<u8>,
  //
 ption<HalfMatch>, n() (**fn ge./// let gotwtheplementtffsditomato.
   _ch>, 
      er ``(feaif   //"cmooc")]>>(()erialization.
   /// nowma wtheplementtome othdtateID) ->  fn tateID) -a.try: fa.try<'_ix_byteaystd btht: &tackAnchoreSht, Patttion<u8>,
  //
 ption<HalfMatch>, n() (**fn ge./// nowma wtheplementtome othditomatod bthtAer> {
 
     &[]e `[entsn, thtchr nt/.
    findn wtheplement ehe ha.    
//  .
    //, thiperswtheplement ehe haUTks
    //eykely thatr, ca-omuo  at
//  arch doeste `vious xecute.Oe search.
   o arenconstructed fromura/// // pat
matcerns ate same st rans a maicceksn, the posbled, allaier par 
 e Unimandnext
matce/
    r, cs   /// ofhatalable  a/// of of a at ted frotch
 this metrch c/ty ice the hayUnimandnext/ termina/ Addiuseratg.
 tatio 
 ecceksnnowmans a mc/ty ice e pos  /// /oullsearch shoF th.    
//  .
   type/ Since thlittlonthtroua itinatanpa  e 1icode wortartingexamp
to hanturn Affed b/ Tc    /uc the ow ipassthe o thatfhaton of tsitions. But ts
s oiis  toohe DFAeccek/sator  // lal/ batkallers cannot knu inpbof t/// ma    
//  Ceturns state. /// indwe
    /  f `[ans a mTc    /uc    via
methodO implementrator::d for`]fa are-atch at afnew xecute.ORe, s fin a mat th
//  ate `vious xecuteuratioption tha pand, it     ///.
#[derise(Clonr  Debug, Eq, AnrusngEq)]>pub   /uc tO implementratoratch>, builT. And of bled, all8 m   /   //, i nt/ttheplement ehe hayexample shobounds oin a ma single codepointIf ihthe haystac` concs decingited toserializatut`+")?;
   canclitince it has ut`valuma singpub/// [`)gite:   /// ) -> Result<ch>, builT. An a mad:aion, thx a ma tnnowman   Rahe hayoamucanwtting.
 caessary sincearch shoF.uitting.    //it enters
   , `e poi     ` and `acctht is aent any pe _m     valuma single codepointAmatch exvalumNoneicatSinch tt for .
    finmand t/ guarans fnce it ha and only///
 an erroin sice actual (&,Ns
    oing n Rstate ID uratnce it ha rout   /tt for .
   s  // le(Ha(r/   engink  // ipe prooar  ve asbounds oinhe ha-tins factorsa singpub/// [`)gceleefilterrator(&M<ch>, builT. A termination, thxecute.orted anchor mode.
   `id assu     (i.e.,/
    //-atch at afxecute),ng.    //tht isnce it has reb ` nnatcavidice the hayasR//
   8 m   /anturn regard  ss8 meultbounds oi chr nt/valuma Subsequehe an/ This an wtheplement ehe ha piek/upa tnce it has ut`// assa singpub/// [`)gte: , sze<ch>, builT. Aone`x nd a , th of a at ted fromuvidice next/e brancatalable ion, tlast_matctchr nt/.
     //it enters
   . .
    ///
 thisrati th1 greaiseaicainstead manifemoovgoccur
    /   /// ngatalable an impthtchr nt/ enters
   . (In for the abificis u, thattf8)F-8. e.g hing m that may
 yUnimandtchr nt/ terminaarch_fwd(& ddice the haystate. /dva ben oimandnext/ termina/) singpub/// [`)gnextuse::Coone`x:,efilter, sze>, # Example
    //tht is lizenwttin
 ffset `0n implement the hay input or whultbounds oiEOI
    /// the 
    /// # Example
   ick, t, thiioua    /// Execute ful in sit r, cs l  sttpuld on, tlast_matc terminatexcly sas reached
    /sitions.ange:h.
 
 ffset `0`, the, # Exampls  ///
  in su //gr   // asssrredhdok, t"r, c"uld onwe'outg    p poent any p`0`a So eand wher/ i l  detec the iTkau An, ut`+"    flagde worffset `refilter)n implement the hayr, cs l  earch shouching fong ofue search inconfigura g may
 yUmode is enfue seafomoowget '3' EOI
    /// tha singpub/// [`)gffsueoi:rncho, 
  nraitO implementratoratch>, builCreais afnew  theplement ed a   ///
b ` nsdatsearcd for/.
    findnynce it ha and only/ singpub
   
    (et_pre implementratoratch>, /   g implementratoratch>, /   tomarli:u     _byteeeeeeeeecele     _byteeeeeeeeeli:u0 _byteeeeeeeeenextuse::Coone`x:,     _byteeeeeeeeeffsueoi:ronfig,
  ///   }er> {
        NoR if cft. And of bltion ion, th   //, i nt/ehe hayexaee
    kau An, utbounds oin a ma single codepointA ehe haUTkault, litis er pattion  and onfong o,eneficple, ih thent any particuen thougvializeault,and, itches.able atch e/ singpub
    #[i     e fn get_prefilter -> Resultatch>, /   rans m tnce i
 
     &[ud searc//
    theplement `ehe ha` f//itinat(   /// atch
cept/// s)su til
//  at // Even though  matc' only stac` con ies thcoding of a    
//  .
    //*onf* /// ind /d, it is ong :h.tystate.  wherb /anturdnwtting.
 DFA
t ha rse enabled, a // UTF-*& d*archounds of a x includes
    /// ioCetu at
//  alizeattint-fiaion, ople shngmuimik, tlizenmightioption thal ` tina mc/ty e is enfg/// Foren wp bes#[cold]
erializa(h of )]>   
n w_ alwa/// a_use 1s wtheplement<F>dtateIa.try: fa.try<'_ix_byteack {: &tackO implementrator _bytetack.et go: F,
tion<u8>,
  //
 ption<HalfM
m:^)a_byteF: FnMut(fa.try<'_ix &tackO implementratortion<u8>,
  //
 ption<HalfM,
tch>, bu .
    ///
 this ///
   r
 ks an i   /// at a forset `0`, the An matcherntin/
    /te di't` c .B. We dishether cod, opleis usde wat'An matcheful in swtheplement ehe haUTkdriseas rmranv/ ngat searchinatvia
 matche)O implementrator`a So Umodwea routl  d b/ Tpusharchu til that is emuimi
 matche/// ma 
n() {
  8())hm         ld a d #[i     eratch>, n()         # if cfg!(mir,
  ///        hm)/=  hm,
  //D, Inpuih ;
     #[iack)
    s.  /eck)
    satch>, n() //
!;
      /char_I word
 ehm/// asser)atch>, n()     rd a d     / mut last_/   }er> {/   # if cfg!(miri
/   }er> {he las!;
      /char_I word
 ehm/// asser)atch>, n() ehe ha(c.try,k.
   _search_tomahm         ld a d #[i     eratch>, n() n()         # if cfg!(mir,
  ///            hm)/=  hm,
  ///   };ch>, }er> {g!(mire
     &WritS ate `fix "ld a "Noneicatn i    fmt::Debugdnraisa    
//  Shing fong ovializetrlerationefc  /tcheds orngu sst
 ean produce
typemuvi
s oin a ms:/ it h`1` fo,r exam.
   s  /ccelerate h`1` fo,rt for .
   st a c/ty e is  .
   s:h.tyontinulithats an impth tesns fawtheplementmuvidn produce
s oin a maiypem.
pub/// [`)g   fmtftomat_oneicatn <A: dfa::{den>dtateIf: &tack /de::fmt::Formed fr<'_ix_byteta:: Ax_bytecelerator(&,
tion< /de::fmt::u8>,
 atch>, //
ert_ss_ it ftomatdid_atch>, n() write!(f, "D"_search_toma//
ert_ss_c    ftomatdid_atch>, n() n() write!(f, ">"_search_toma  ///  {ng thn() n() write!(f, " "_search_toma 
;
    ///     ert_ss_resuftomatdid_atch>, n() write!(f, "Q "_search_  ///     ert_ss_c    ftomatdid_atch>, n()    ert_ss_e [`Automatdid_ {ng thn() n() write!(f, "A>"_search_toma  ///  {ng thn() n() write!(f, " >"_search_toma 
;
    ///     ert_ss_se::Cotomatdid_atch>, n()    ert_ss_e [`Automatdid_ {ng thn() n() write!(f, "A*"_search_toma  ///  {ng thn() n() write!(f, " *"_search_toma 
;
    ///     ert_ss_e [`Automatdid_ {ng thn() write!(f, "A "_search_  ///  {ng thn() write!(f, "  "_search_ er> {g!(mire
  er ``(ng (  sy,kfeaif   //"syntax",kfeaif   //"ert-se))
"))]>ed,   sysatch>, butA basmen  sya /surget '3   thatdfa::{den    he iTkobj it bafn.O(ero lench>, butt. Andtha      awhyredhdok, td`fine    /sitions. But tsyasR/ave mentthe
  ///   nto<a.try>/) sing#[  sytion.
   obj it_bafneratch>, n() in s// [`de{ng thn() n() ta::{
    /  dfa::{dense::DFAAAAAAAAAnse},
    /Match, Patt/   };cch>, n() {
    ///
    /////   ut infwd(&.unwrapss;ch>, n() {
  ta:: &// #dfa::{den = &/fa;ch>, n() &input)?;
 ch>, n()     g!(// let expected = Some(H6)ir,
  ///           /// let got = dfa.try_search_xyzfwdxyz"ir,
  ///   ri
/   }e}
 long-    /// -0.3