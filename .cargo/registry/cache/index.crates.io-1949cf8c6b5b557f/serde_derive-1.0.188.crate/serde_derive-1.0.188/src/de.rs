use crate::fragment::{Expr, Fragment, Match, Stmts};
use crate::internals::ast::{Container, Data, Field, Style, Variant};
use crate::internals::{attr, replace_receiver, ungroup, Ctxt, Derive};
use crate::{bound, dummy, pretend, this};
use proc_macro2::{Literal, Span, TokenStream};
use quote::{quote, quote_spanned, ToTokens};
use std::collections::BTreeSet;
use std::ptr;
use syn::punctuated::Punctuated;
use syn::spanned::Spanned;
use syn::{parse_quote, Ident, Index, Member};

pub fn expand_derive_deserialize(input: &mut syn::DeriveInput) -> syn::Result<TokenStream> {
    replace_receiver(input);

    let ctxt = Ctxt::new();
    let cont = match Container::from_ast(&ctxt, input, Derive::Deserialize) {
        Some(cont) => cont,
        None => return Err(ctxt.check().unwrap_err()),
    };
    precondition(&ctxt, &cont);
    ctxt.check()?;

    let ident = &cont.ident;
    let params = Parameters::new(&cont);
    let (de_impl_generics, _, ty_generics, where_clause) = split_with_de_lifetime(&params);
    let body = Stmts(deserialize_body(&cont, &params));
    let delife = params.borrowed.de_lifetime();
    let serde = cont.attrs.serde_path();

    let impl_block = if let Some(remote) = cont.attrs.remote() {
        let vis = &input.vis;
        let used = pretend::pretend_used(&cont, params.is_packed);
        quote! {
            impl #de_impl_generics #ident #ty_generics #where_clause {
                #vis fn deserialize<__D>(__deserializer: __D) -> #serde::__private::Result<#remote #ty_generics, __D::Error>
                where
                    __D: #serde::Deserializer<#delife>,
                {
                    #used
                    #body
                }
            }
        }
    } else {
        let fn_deserialize_in_place = deserialize_in_place_body(&cont, &params);

        quote! {
            #[automatically_derived]
            impl #de_impl_generics #serde::Deserialize<#delife> for #ident #ty_generics #where_clause {
                fn deserialize<__D>(__deserializer: __D) -> #serde::__private::Result<Self, __D::Error>
                where
                    __D: #serde::Deserializer<#delife>,
                {
                    #body
                }

                #fn_deserialize_in_place
            }
        }
    };

    Ok(dummy::wrap_in_const(
        cont.attrs.custom_serde_path(),
        impl_block,
    ))
}

fn precondition(cx: &Ctxt, cont: &Container) {
    precondition_sized(cx, cont);
    precondition_no_de_lifetime(cx, cont);
}

fn precondition_sized(cx: &Ctxt, cont: &Container) {
    if let Data::Struct(_, fields) = &cont.data {
        if let Some(last) = fields.last() {
            if let syn::Type::Slice(_) = ungroup(last.ty) {
                cx.error_spanned_by(
                    cont.original,
                    "cannot deserialize a dynamically sized struct",
                );
            }
        }
    }
}

fn precondition_no_de_lifetime(cx: &Ctxt, cont: &Container) {
    if let BorrowedLifetimes::Borrowed(_) = borrowed_lifetimes(cont) {
        for param in cont.generics.lifetimes() {
            if param.lifetime.to_string() == "'de" {
                cx.error_spanned_by(
                    &param.lifetime,
                    "cannot deserialize when there is a lifetime parameter called 'de",
                );
                return;
            }
        }
    }
}

struct Parameters {
    /// Name of the type the `derive` is on.
    local: syn::Ident,

    /// Path to the type the impl is for. Either a single `Ident` for local
    /// types (does not include generic parameters) or `some::remote::Path` for
    /// remote types.
    this_type: syn::Path,

    /// Same as `this_type` but using `::<T>` for generic parameters for use in
    /// expression position.
    this_value: syn::Path,

    /// Generics including any explicit and inferred bounds for the impl.
    generics: syn::Generics,

    /// Lifetimes borrowed from the deserializer. These will become bounds on
    /// the `'de` lifetime of the deserializer.
    borrowed: BorrowedLifetimes,

    /// At least one field has a serde(getter) attribute, implying that the
    /// remote type has a private field.
    has_getter: bool,

    /// Type has a repr(packed) attribute.
    is_packed: bool,
}

impl Parameters {
    fn new(cont: &Container) -> Self {
        let local = cont.ident.clone();
        let this_type = this::this_type(cont);
        let this_value = this::this_value(cont);
        let borrowed = borrowed_lifetimes(cont);
        let generics = build_generics(cont, &borrowed);
        let has_getter = cont.data.has_getter();
        let is_packed = cont.attrs.is_packed();

        Parameters {
            local,
            this_type,
            this_value,
            generics,
            borrowed,
            has_getter,
            is_packed,
        }
    }

    /// Type name to use in error messages and `&'static str` arguments to
    /// various Deserializer methods.
    fn type_name(&self) -> String {
        self.this_type.segments.last().unwrap().ident.to_string()
    }
}

// All the generics in the input, plus a bound `T: Deserialize` for each generic
// field type that will be deserialized by us, plus a bound `T: Default` for
// each generic field type that will be set to a default value.
fn build_generics(cont: &Container, borrowed: &BorrowedLifetimes) -> syn::Generics {
    let generics = bound::without_defaults(cont.generics);

    let generics = bound::with_where_predicates_from_fields(cont, &generics, attr::Field::de_bound);

    let generics =
        bound::with_where_predicates_from_variants(cont, &generics, attr::Variant::de_bound);

    match cont.attrs.de_bound() {
        Some(predicates) => bound::with_where_predicates(&generics, predicates),
        None => {
            let generics = match *cont.attrs.default() {
                attr::Default::Default => bound::with_self_bound(
                    cont,
                    &generics,
                    &parse_quote!(_serde::__private::Default),
                ),
                attr::Default::None | attr::Default::Path(_) => generics,
            };

            let delife = borrowed.de_lifetime();
            let generics = bound::with_bound(
                cont,
                &generics,
                needs_deserialize_bound,
                &parse_quote!(_serde::Deserialize<#delife>),
            );

            bound::with_bound(
                cont,
                &generics,
                requires_default,
                &parse_quote!(_serde::__private::Default),
            )
        }
    }
}

// Fields with a `skip_deserializing` or `deserialize_with` attribute, or which
// belong to a variant with a `skip_deserializing` or `deserialize_with`
// attribute, are not deserialized by us so we do not generate a bound. Fields
// with a `bound` attribute specify their own bound so we do not generate one.
// All other fields may need a `T: Deserialize` bound where T is the type of the
// field.
fn needs_deserialize_bound(field: &attr::Field, variant: Option<&attr::Variant>) -> bool {
    !field.skip_deserializing()
        && field.deserialize_with().is_none()
        && field.de_bound().is_none()
        && variant.map_or(true, |variant| {
            !variant.skip_deserializing()
                && variant.deserialize_with().is_none()
                && variant.de_bound().is_none()
        })
}

// Fields with a `default` attribute (not `default=...`), and fields with a
// `skip_deserializing` attribute that do not also have `default=...`.
fn requires_default(field: &attr::Field, _variant: Option<&attr::Variant>) -> bool {
    if let attr::Default::Default = *field.default() {
        true
    } else {
        false
    }
}

enum BorrowedLifetimes {
    Borrowed(BTreeSet<syn::Lifetime>),
    Static,
}

impl BorrowedLifetimes {
    fn de_lifetime(&self) -> syn::Lifetime {
        match *self {
            BorrowedLifetimes::Borrowed(_) => syn::Lifetime::new("'de", Span::call_site()),
            BorrowedLifetimes::Static => syn::Lifetime::new("'static", Span::call_site()),
        }
    }

    fn de_lifetime_param(&self) -> Option<syn::LifetimeParam> {
        match self {
            BorrowedLifetimes::Borrowed(bounds) => Some(syn::LifetimeParam {
                attrs: Vec::new(),
                lifetime: syn::Lifetime::new("'de", Span::call_site()),
                colon_token: None,
                bounds: bounds.iter().cloned().collect(),
            }),
            BorrowedLifetimes::Static => None,
        }
    }
}

// The union of lifetimes borrowed by each field of the container.
//
// These turn into bounds on the `'de` lifetime of the Deserialize impl. If
// lifetimes `'a` and `'b` are borrowed but `'c` is not, the impl is:
//
//     impl<'de: 'a + 'b, 'a, 'b, 'c> Deserialize<'de> for S<'a, 'b, 'c>
//
// If any borrowed lifetime is `'static`, then `'de: 'static` would be redundant
// and we use plain `'static` instead of `'de`.
fn borrowed_lifetimes(cont: &Container) -> BorrowedLifetimes {
    let mut lifetimes = BTreeSet::new();
    for field in cont.data.all_fields() {
        if !field.attrs.skip_deserializing() {
            lifetimes.extend(field.attrs.borrowed_lifetimes().iter().cloned());
        }
    }
    if lifetimes.iter().any(|b| b JSON string.
    if !fie
     te()),
 ut syn::Deng` othen `'d_site()),
        ribute.tchite()),
  M boun&nion of lifetimes borrowed by each field of the contassnt.data.has_=      needs_dlse {
        false
    }&1, 'op            __yiite()),
        rib>) -> bool,
    boundn        }
  }
    }

    fn de_lide> fo   }

   op            __yiite()),
   o   }

       boundn        }
  }
    }
try

    fn de_lide> fo   }
try

   op            __yiite()),
 y,
   o   }
try

       boundn        }
ol {
 ithern::TraitB   let is_packethern::Trop           w(),
    };
    match &contcont.data {
        Data::En __yiite()), fal(erics {num(varian    };
, Some,tch &contcont.data    if lr, Daa    if   Data::Struct(_, fields) =     __yiite()),     }(erics {nData::n    };
, Somner,   }Forma    if )::Const(_) => {}
          .data    if lr, Daa        Data::St| .data    if lr, Daa New      Data::Struct(_, fields) =     __yiite()),t    serics {nData::n    };
, Somne     Forma      )::Const(_) => {}
          .data    if lr, Daa Unit  Data:: __yiite()),g/ru,     }(erics {n   };
, Some,tch &cont      }
        }
    }w(),
    };
    match &contcont.data {
        Data::En __yiite()),     coethern::Troerics {num(varian    };
, Some,tch &contcont.data    if l   Data::unrmes se].!("cont)e exam            _nt};
use ")::Static => None,
        (ersion  one            #fn_dese")]lifetimes borrowe = deserializ each field of the contassnt.data.has_=   param(&
    >truct Par Onlythat the      sthat d      s, be reduown bound so weuct Par 
        let fn_deserSet:hat the      srializast_ty!(!end_useed,
      >),
    
        false
    }&1, 'op:Static =|| de_lide> fo   }

   oprianparaop:Static =|| de_lide> fo   }
try

   oprianparaop:Static =|| de_lide> foethern::Troprianparaop:Static =|| de_l    .into_iter= cont
      _iter .data
        .all_f_iter .d(|f| fcs = matc   && variant.deseriparaop    .a{
     );
      times;     }
        }        let variants = match &cont.data    if lr, Daa    if   Data::Struct(_, fields) = __yiite()),     }t fn_deseserics {nData::n    };
, Som)? }
            }
        }
     r, Daa        Data::St| .data    if lr, Daa New      Data::Struct(_, fields) = __yiite()),t    t fn_deseserics {nData::n    };
, Som) }
            }
        {
   _St| .data    if lr, Daa Unit  Data::Struct(_, _) => {
   imes;               }
       &params));
    let delife = params.borrowed.de_lifet    s);
    l    :Field::de_be {
        let fn_deseria quote),
  !ndTyParams<'as
        let fn_dese  fn deserialize<__D>(__date:_deseeserialSifetime__lizer: __D) -> #serde::__clote::Result<Self, __D:                wh     _          __D: #serde::Deserializer<#d
        quote!t                   }
        }
 
    le {
        let fn_deseimpl_b     ( bo(ersion  one            #fn_dese"))]lifetimes borrowe = deserializ_ each field of the_ contassnt.data.has_=   param(&
    >truct Pimesof lifetimes borrow
        rib>) -h field of the contassnt.data.has_=      needs_dlse {de_be  let re let variants = match &cont.data    if l   Data::StrucData::n     }
        {
   _Sta::unrmes se].!(Punctuated::new(),
t);
        lace_bod.t);
      ed.de_life
        riata
  f let Somefield in   l|f| fcs = ma
    }&1, 'op_str(&serialized)cont.ith re let v
        riata
  cs = matc   && variant.deattrs.de_bound() th: &a::       #sit_path(&boundcates),
        None => {
      le        riata
  c        .    owed.de_lifetime quote::{quot!(::{q=> _          __D: #ses, anput, Deri               }
       &paastignf let Somefield i        .filtainer) -> Selm Iden  lata
  cm Iden;a.all_fieldsp {
 eqlifeti,le        riata
  p_deserializing(       #m Iden>(__e        rii          
        }
    }.remote()      l let vta
  cs = match *cont.attrs.default() {
                attr::Defa         &parse_quote!(_serde::__ken: <Token                ),
                attr th: &a::       #sit_en                ),
               cates),
         &parse_quote!(_se        mar)h(_) => generics,serializing(       #m Iden>(#)    i               }ialized) quote),
  !ndTyParams<_lizer: __D) -> #serde::_::            quote!sit_eeserialize<__D)h(_) => generi|__e        ri| #t);
       { #(#astign),*         of lifetimes borrow
   o   }

   e_bound('ast s      needs_dlse { quote),
  !ndTyParams<_lizer: __D) -> #serde::_::            quote<#   }

   h,

_          __D: #se>s, anput, Dereeserialize<__D)h(_) => generi_lizer: __D) -> #seF   e:
       bouof lifetimes borrow
 y,
   o   }
try

   e_bound('ast s      needs_dlse { quote),
  !ndTyParams<_lizer: __D) -> #serde::_::er};e is         quote<#   }
try

   h,

_          __D: #se>s, anput, Dereeserialize<__D)h(_) => generi|v|<_lizer: __D) -> #seTryF   e:
 y,
   ov i   t.che_lizer: er: sult<::     c)    bouof lifetimes borrowg/ru,     }(erics ssnt.data.has, c       variantifetimes(cont:   needs_dlse {de_b();
        ace_bod.t);
     ;::new(),
t);
        lace_bod.t);
      ed.de_life
ethods.
   ls = mads.
 )atc   && varids.
 )ters::new(&cont);
    let (deconResult<#remotpl_generics, _, ty_generics,elf) -> Sthere_clause) = split_wth_de_lifetime(&prams));
    let delife = params.borrowedfetime(&pexp};
ungf leor le!("g/ru/
      !("sece_bod.tethods.
 y(&cont, &paexp};
ungf lls = maexp};
ungn Err(ctxtor(&exp};
ungialized) quote),
  !ndTyParams<#[doc(hidthe),
        
      __V;

               impl #det #ty_generics #where_claus     //   &parse_quote!(_se        mar<#();
      ife> for #idrializer<#delif            &parse_quote!(_se        mar<&e::Dese ()>,{}
            }
   ed]
            impl #d_lizer: er: V;

   rde::Deseriali__V;

        fe> for #ident #ty_generics #where_claus     V      l#();
      ife> for #id),
            , Memb};
ungn&isit_ma_eor leeld.
erial_lizer: __D) -> #seFor leeldtime__lizer: __D) -> #sefmtserde::_.attrs.default() {
_lizer: __D) -> #seFor leeld};

it),   (a_eor leeld, #exp};
ungi
      #body
               #[inlmes]
            , M      g/ru  fE>(sifetime__lizer: __D) -> #serde::__Sifent:       fE>
__D::Error>
                where
 fE: _lizer: er: sult<ializer<#delifattrs.default() {
_lizer: __D) -> #seOk(#t);
      )         _ => {}
            }
   _          __D: #sers, anput, Derwg/ru,     }(           wh  erialize<__Dializer<#delif#tethods.
h(_) => generi__V;

    attrs.default() {
     //   &parse_quote!(_se        mar::<#();
      ife> for #idrializer<#delifelif            &parse_quote!(_se        marh(_) => generich(_) => ge) {
        fals     Form<'a,
            tr` argumifetimesich
// belods.
tr` aEx};
uselyT.com/(&'as on.
    l) tr` argumifetimesich
// belods.
 be ra
//
/ermed     lifetime of fetimed in fa:pun`Ident` folifetime oaram( field typereor        Unt.com/(&'as on.
    l::{Literal, S),of lifetimes borrow
    s
:Generics ssnt.data.has, &syn:: Som,
  t(fie], &sync       variantifetimes(,BTreeSet e_     Formound: &   needs_dlse {ast_ty!(!ls = maed,
ttrst pat:Field::de_be(fie_ eu)?;

               ariants
        .iter()     .fil() {
        if !field.attrs.skipparam
       un
        .coll();
        ace_bod.t);
     ;::new(),
t);
        lace_bod.t);
      ed.de_life&cont);
    let (deconResult<#remotpl_generics, _, ty_generics,elf) -> Sthere_clause) = split_wth_de_lifetime(&prams));
    let delife = params.borrowedfetim<'a, 'eserias `'      s (ter) attrmote type hass),does n     ut `f {
   of the gld be rerica
/`I   `doesow isurn o'    ut `hat the
   .a, 'eserias `'nstr` arg'      s e is oes n     ut `targife
eth dir};
ly.t = Ctxt::ne n     =() {
    seed,
      ntainer) -> Self {
    ace_bod.f {
 arams.is_packed)(#f {
 )     }
        }
    }acked)(#t);
      )     ted::new(),
t(|id| th re let vSet     }
    }     Forma            S n    ,  }
    }     Forma Ex};
uselyT.com/(
// bel_ams.con|}     Forma Unt.com/(
// bel_ams.c  Data::Struct(_, _) =acked)(#  S n    ::#
// bel_ams.co               }
 ont, &paexp};
ungf l let vSet     }
    }     Forma          eor le!("
    /
      !("sece_bod.tethods.
 y(,  }
    }     Forma Ex};
uselyT.com/(
// bel_ams.con|}     Forma Unt.com/(
// bel_ams.c  Data::Struct(_, _) =eor le!("
    /
// belo{}::!("sece_bod.tethods.
 y{num(vari_ams.co               }
 ont, &paexp};
ungf lls = maexp};
ungn Err(ctxtor(&exp};
ungialized)type_e  let reet Some(en        .coll      new    _ n     =( let vSet     }
    }     Forma       ) {_e  let rsegma::Struct(_, _) =und()tc   && varidew    _ n     sel|id| thsece_bod,lata
   = &)) }
            }
  _ifetimes::Stat}      .coll      seqs);
    let body = Stseq(         sel|id| thsece_bod,lData::n  else, c     ,aexp};
ung      im      .coll     or_ useria quot!ndTyParams<__V;

    attrs.default(     //   &parse_quote!(_se        mar::<#();
      ife> for #idrializer<#delif            &parse_quote!(_se        marh(_) => ge      }
 ont, &padisplet v=( let vSet     }
    }     Forma       ) {_e  let rsegma::Struct(_, _) =life
ethods.
   ls = mads.
 )atc   && varids.
 )ters::ont, &params);

        quote
   _          __D: #sers, anput, Derwdew    _ n       erialize<__Dif#tethods.
h
      or_ use)               }
            }
       Forma          Struct(_, _) =life
ethods.
   ls = mads.
 )atc   && varids.
 )ters::ont, &params);

        quote
   _          __D: #sers, anput, Derwt    t n       erialize<__Dif#tethods.
h
 e(fie_ eu)?h
      or_ use)               }
            }
       Forma Ex};
uselyT.com/(_ &a::      

        quote_lizer: er: Vm(variAccesthis    t(|varian_t(|variah
 e(fie_ eu)?h
      or_ use)         },  }
    }     Forma Unt.com/(_, lifetime of  &a::      

        quote_lizer:    __D: #sers, anput, Derwt    (#erialize<__Dif#e(fie_ eu)?h
      or_ use)         },  }
 }      .coll     or_(|v =() {e(fie_ eu)?;
= 0    }
    }acked)(_)     }
        }
    }acked)(rial_tseq)     ted::new quote),
  !ndTyParams<#[doc(hidthe),
        
      __V;

               impl #det #ty_generics #where_claus     //   &parse_quote!(_se        mar<#();
      ife> for #idrializer<#delif            &parse_quote!(_se        mar<&e::Dese ()>,{}
            }
   ed]
            impl #d_lizer: er: V;

   rde::Deseriali__V;

        fe> for #ident #ty_generics #where_claus     V      l#();
      ife> for #id),
            , Memb};
ungn&isit_ma_eor leeld.
erial_lizer: __D) -> #seFor leeldtime__lizer: __D) -> #sefmtserde::_.attrs.default() {
_lizer: __D) -> #seFor leeld};

it),   (a_eor leeld, #exp};
ungi
      #body
               #      new    _ n                  #[inlmes]
            , M      seq<__A>(sifeh
      or_(|v>(__Atime__lizer: __D) -> #serde::__Sifent:       fAResult<Self, __D::Err                where
 fA: _lizer: er: SeqAccestde::Deserializer<#delifs #where_clause {
       seq         _ => {}
            }
   #displet  None,
        (ersion  one            #fn_dese")]lifetimes borrowt    t fn_deses
:Generics ssnt.data.has, &syn:: Som,
  t(fie], &sync       variantifetimes(,Bnd: &   needs_dlse {ast_ty!(!ls = maed,
ttrst pat:Field::de_be(fie_ eu)?;

               ariants
        .iter()     .fil() {
        if !field.attrs.skipparam
       un
        .coll();
        ace_bod.t);
     ;::new(),
&cont);
    let (deconResult<#remotpl_generics, _, ty_generics,elf) -> Sthere_clause) = split_wth_de_lifetime(&prams));
    let delife = params.borrowedfetime(&pexp};
ungf leor le!("
    /
      !("sece_bod.tethods.
 y(
 ont, &paexp};
ungf lls = maexp};
ungn Err(ctxtor(&exp};
ungialized)type_e  let reet Some(en        .coll      new    _ n     =() {_e  let rsegmct TypeMacro<Wr own bound so we 
        let fn_deser) {) | y/// At leastt TypeMacro<tc   && variant.. HashSet::ne_ty!(ta
   = &cs = matc   && variant.deserinds.push(trs.de_bound()rams);

        quote! inlmes]
            , M      new    _ n      fE>(sife   f    _Etime__lizer: __D) -> #serde::__Sifent:       fEResult<Self, __D::Err                where
 fE  _          __D: #serde::Deserializer<#delifattrs.default() {
_lizer:    __D: #ses, anput, Dert fn_deses f ,  fn visit._dese.0)               }
       )     }
        }
    }imesoStat}      .coll      seqs);
    let body = Stseqt fn_deseserics {nData::n c     ,aexp};
ungim      .coll     or_ useria quot!ndTyParams<__V;

    attrs.default(_deseese:_deseializer<#delif            &parse_quote!(_se        marh(_) => ge      }
 d.de_life
ethods.
   ls = mads.
 )atc   && varids.
 )ters::new(displet v=() {_e  let rsegmct TypeMac         &parse_quote!(_sers, anput, Derwdew    _ n       erialize<__Dif#tethods.
h
      or_ use))     }
        }
    }acked)(_          __D: #sers, anput, Derwt    t n       erialize<__Dif#tethods.
h
 e(fie_ eu)?h
      or_ use))  }
 }      .coll     or_(|v =() {e(fie_ eu)?;
= 0    }
    }acked)(_)     }
        }
    }acked)(rial_tseq)     ted::newtter( = deser       impl #dialir       impl #. fn_deses)ters::new(( = deserfe> for #ide=econResult<#rem. fn_deses)ters::new( deserms));
  deserms))borrowedfetim quote),
  !ndTyParams<#[doc(hidthe),
        
      __V;

     ( = deser       impl #dnt #ty_generics #where_claus_deseese# deserms));rial#();
      ife> for #idializer<#delif            &parse_quote!(_se        mar<&e::Dese ()>,{}
            }
   ed]
  ( = deser       impl #d_lizer: er: V;

   rde::Deseriali__V;

     ( = deserfe> for #ident #ty_generics #where_claus     V      l()),
            , Memb};
ungn&isit_ma_eor leeld.
erial_lizer: __D) -> #seFor leeldtime__lizer: __D) -> #sefmtserde::_.attrs.default() {
_lizer: __D) -> #seFor leeld};

it),   (a_eor leeld, #exp};
ungi
      #body
               #      new    _ n                  #[inlmes]
            , M      seq<__A>(sifeh
      or_(|v>(__Atime__lizer: __D) -> #serde::__Sifent:       fAResult<Self, __D::Err                where
 fA: _lizer: er: SeqAccestde::Deserializer<#delifs #where_clause {
       seq         _ => {}
            }
   #displet  None,
   ifetimes borrowseq(     el|id| th.
e{Literal, S,
:Generics ssnt.data.has, &syn:: Som,
  t(fie], &syneripn    :.
    i&sync       variantifetimes(,BTreeexp};
ungnerics,Bnd: &   needs_dlse {ote() rde=e(0..et Some(en   i    e(fie_ih,

fn(_ &me__)
       &parabute, are _ eu)?;

               ariants
        .iter()     .fil() {
        if !field.attrs.skipparam
       un
    ont, &paexp};
ungf l) {rabute, are _ eu)?;
segmct TypeMaceor le!("{}..`), 1
  eeeds",aexp};
ungi) {
        true
    } or le!("{}..`), {}
  eeedss",aexp};
ung,{rabute, are _ eu)?)     }
 ont, &paexp};
ungf lls = maexp};
ungn Err(ctxtor(&exp};
ungialized)typeriali_quot fnseqs);0_ue a 
 ont, &pa &p      t relev       ...zi  e(fies i     (
//{nData:)|ata.all_fields) {
        if !field.attrs.skip_deserializing()l_sitetr::Defate:( use_erimisthislifeti,lc, Some(ters::ont, &params);

        quote
   )l_s#(|v =(#itetr::          return;
       
        }
    }.remote()      l let vta
  cs = matc   && variant.deattrs.de_boh(&boundcates),
        None = }
    } else(fie_ty;

     .te;       None = }
    } els      lta
  c        .    owed.de_lifetime }
    } elseuncs,elf) -> S                 quote::{quot!(::{q=> _       er: SeqAccesttimext_  eeeds::<#e(fie_ty>wed.de_lifetime }
    }acked)(#eunc  fn v_tseq)?)bound.clone()));
                }
und() th: &a::        None = }
    } els((ctxpld, (ctxpldpe::  l(ctxttimes borrow
(fie_ant.derics {nData:.te,t.ithwed.de_lifetime }
    }acked)(am::Const(_) => {
        #(ctxpldm::Const(_) => {
        _lizer: __D) -> #seOaram(::            quote_) => {
        _lizer: er: SeqAccesttimext_  eeeds::<#(ctxpldpe:>  fn v_tseq)?t.clone().into(),
            |__(ctx| __(ctx.     )         _ =>                        })
}(_) => generics,serializing(ote()    _ifinds.  l use_erimisthiswseq(imes:li_quot fnseq{nData:n c     ,aexp};
ungis,serializing(ote(astignf lrams);

        quote
   )l_s#(|v =( let v      :        None = }
    }_lizer: __D) -> #seund()_      )&a::_            this_val }
    }_lizer: __D) -> #secates),
#)    _ifinds.h: bound.clone(),
 ;(_) => generics,serializing(i_quot fnseqs+segs,serializing(astign               }ialized)typerialrde::_. l) {eripn    ntainer) -> Selds.
sf let Somefield i      | &fcm Idenparams.is_packed);
        quote#t(|id| th { #( #ds.
s>(#) rde),*  tch &cont      }
        }
    }acked);
        quote#t(|id| th ( #(#) rd),* i               }
      ) {
    seed,
      ntainer) -> Sel();
        ace_bod.t);
     ;::new   } els(_impl_generics, timesce_bod.ult<#rem.there_ orr    owed.de_liferde::_. l      

        quote_lizer: __D) -> #seI   ::<#();
      ife> for #idriant}o(#rde::_i          ;     }
        } &p itetr::Defde_bouns = match *cont.attrs.defa                attr::Defaund()rams);(,serializing(ote(_ itetr::: Sifent:    Def  &parse_quote!(_serde::__ken: <Tokened.de_lifey(,  }
    }                attr th: &a::und()rams);(,serializing(ote(_ itetr::: Sifent:    Def#ont.attr.de_lifey(,  }
    }               cates),
        None =ro<Wr own'tother de` lil be set to,n o'preveds_   unis;
 (|varble warnung       None =ro<we'llmes,v Path lmes empty.
e_boh(&boundcate               }
       quote),
  !ndTyParams<# &p itetr::TyParams<#(# &p      t)*
ult() {
_lizer: __D) -> #seOk(#rde::_i     ,
        (ersion  one            #fn_dese")]lifetimes borrowseqt fn_deses
:Generics ssnt.data.has, &syn:: Som,
  t(fie], &sync       variantifetimes(,BTreeexp};
ungnerics,Bnd: &   needs_dlse {ote(rabute, are _ eu)?;

               ariants
        .iter()     .fil() {
        if !field.attrs.skipparam
       un
    ont, &paexp};
ungf l) {rabute, are _ eu)?;
segmct TypeMaceor le!("{}..`), 1
  eeeds",aexp};
ungi) {
        true
    } or le!("{}..`), {}
  eeedss",aexp};
ung,{rabute, are _ eu)?)     }
 ont, &paexp};
ungf lls = maexp};
ungn Err(ctxtor(&exp};
ungialized)typeriali_quot fnseqs);0ue a 
 ont, &pa

it),     t reet Somefield i        .filtainer) -> Selm Iden  lata
  cm Iden;aa.all_fields) {
        if !field.attrs.skip_deserializing()l_sitetr::Defate:( use_erimisthislifeti,lc, Some(ters::ont, &params);

        quote
   isit._dese.#m Iden  l#itetr::          return;
       
        }
    }.remote()    _ifinds.  l use_erimisthiswseq(und()rams);(isit._dese.#m Iden  ly(,li_quot fnseq{nData:n c     ,aexp};
ungis,serializing(ote(

it)  l let vta
  cs = matc   && variant.deattrs.de_boh(&boundcates),
        None = }
    }rams);

        quote
   ds.last() {
   _lizer: __D) -> #secates) _lizer: er: SeqAccesttimext_  eeeds_lim/(&fn v_tseq,        quote_) => {
        _lizer: __D) -> #sed#seI PdeseSim/(&fn visit._dese.#m Iden))? }
      lizer<#delife>,
                {
    lause {
      _ifinds.t generics yet");
                        }
    }bound.clone()));
                }
und() th: &a::        None = }
    } els((ctxpld, (ctxpldpe::  l(ctxttimes borrow
(fie_ant.derics {nData:.te,t.ithwed.de_lifetime }
    }acked)(am::Const(_) => {
        #(ctxpldm::Const(_) => {
         let v_lizer: er: SeqAccesttimext_  eeeds::<#(ctxpldpe:>  fn v_tseq)?
                {
    lause {
_lizer: __D) -> #seund()_ (ctxicParam::Const(_) => {
                isit._dese.#m Iden  l__(ctx.     t generics yet");
            }               {
    lause {
_lizer: __D) -> #secates),
        None = }
    }    lause {
      _ifinds.t generics yet");
            }               {
    laus}         _ =>                        })
}(_) => generics,serializing(i_quot fnseqs+segs,serializing(

it)               }ialized)type();
        ace_bod.t);
     ;::new(),
&_impl_generics, timesce_bod.ult<#rem.there_ orr    owed.de_   } &p itetr::Defde_bouns = match *cont.attrs.defa                attr::Defaund()rams);(,serializing(ote(_ itetr::: #();
      ife> for #idDef  &parse_quote!(_serde::__ken: <Tokened.de_lifey(,  }
    }                attr th: &a::und()rams);(,serializing(ote(_ itetr::: #();
      ife> for #idDef#ont.attr.de_lifey(,  }
    }               cates),
        None =ro<Wr own'tother de` lil be set to,n o'preveds_   unis;
 (|varble warnung       None =ro<we'llmes,v Path lmes empty.
e_boh(&boundcate               }
       quote),
  !ndTyParams<# &p itetr::TyParams<#(#

it),     t)*
ult() {
_lizer: __D) -> #seOk(()    bouof lifetimes borrowdew    _ n          el|id| th.
e{Literal, S,
:Generics ssnt.data.has, &syn:: Sossnt(fielBnd: &{Literal, S_dlse {ote(rams));
    let delife = params.borrowed.de_lifee(fie_ty;

     .te; 
.remote()      l let vta
  cs = matc   && variant.deattrs.de_bocates),
        None => {
      lta
  c        .    owed.de_lifetime elseuncs,  quote::{quot!(::{q=> <#e(fie_tyh,

_          __D: #se>s, anput, Der(ters::ont, &params);

        quote
   #eunc __e)? }
      lize  }
            }
  und() th: &a::        None =rams);

        quote
   #sit_eese)? }
      lize  }
            }alized)typerialrde::_. lacked)(#tl|id| th(a_e(fie0e(ters::) {
    seed,
      ntainer) -> Sel();
        ace_bod.t);
     ;::new   } els(_impl_generics, timesce_bod.ult<#rem.there_ orr    owed.de_liferde::_. l      

        quote_lizer: __D) -> #seI   ::<#();
      ife> for #idriant}o(#rde::_i          ;     }
    =rams);

        q#[inlmes]
        , M      new    _ n      fE>(sife   f    _Etime__lizer: __D) -> #serde::__Sifent:       fEResult<Self, __D:                wh  E  _          __D: #serde::Deserializer<#d
        quoteote(_ e(fie0: #e(fie_ty;

#     t generics yet_lizer: __D) -> #seOk(#rde::_i     ic => None,
    falsr,   }Form<'a,
      Sn    ,  }
 rgumifetimesich
// belods.
tr` aEx};
uselyT.com/(&'as on.
    l) tr` argumifetimesich
// belods.
 be ra
//
/ermed     lifetime of fetimed in fa:pun`Ident` folifetime oaram( field typereor        In};
uselyT.com/(&'as on.
    l::{Literal, S),or` argumifetimesich
// belods.
 be ra
//
/ermed     lifetime of fetimed in fa:pun`Ident` folifetime oaram( field typereor        Unt.com/(&'as on.
    l::{Literal, S),of lifetimes borrow n          erics ssnt.data.has, &syn:: Som,
  t(fie], &sync       variantifetimes(,BTreeSet e_r,   }Form,Bnd: &   needs_dlse {ote(();
        ace_bod.t);
     ;::new(),
t);
        lace_bod.t);
      ed.de_life&cont);
    let (deconResult<#remotpl_generics, _, ty_generics,elf) -> Sthere_clause) = split_wth_de_lifetime(&prams));
    let delife = params.borrowedfetim<'a, 'eserias `'      s (ter) attrmote type hass),does n     ut `f {
   of the gld be rerica
/`I   `doesow isurn o'    ut `hat the
   .a, 'eserias `'nstr` arg'      s e is oes n     ut `targife
eth dir};
ly.t = Ctxt::ne n     =() {
    seed,
      ntainer) -> Self {
    ace_bod.f {
 arams.is_packed)(#f {
 )     }
        }
    }acked)(#t);
      )     ted::new(),
t(|id| th re let vSet     }
    }r,   }Forma    if       S n    ,  }
    }r,   }Forma Ex};
uselyT.com/(
// bel_ams.co:Static =|}r,   }Forma In};
uselyT.com/(
// bel_ams.c  Da:Static =|}r,   }Forma Unt.com/(
// bel_ams.c  Data::acked)(#  S n    ::#
// bel_ams.co,     }
 ont, &paexp};
ungf l let vSet     }
    }r,   }Forma    if      or le!("
      !("sece_bod.tethods.
 y(,  }
    }r,   }Forma Ex};
uselyT.com/(
// bel_ams.co:Static =|}r,   }Forma In};
uselyT.com/(
// bel_ams.c  Da:Static =|}r,   }Forma Unt.com/(
// bel_ams.c  Data::Struct(_, _) =eor le!("
      
// belo{}::!("sece_bod.tethods.
 y{num(vari_ams.co               }
 ont, &paexp};
ungf lls = maexp};
ungn Err(ctxtor(&exp};
ungialized)typee(fie_ds.
s_ams.c      <_>;

               ariants
        . falso wets
        yn::kipbe  let zing`sh`'den'to type that will nferric feriattrst p         is_yn:s

   y own'totxplarAll the sto  neAll their lmproc_=eor 
        .iter()  &l   Data:)il() {
        if !field.attrs.skip
   () {
        ttrst pat:
        .     (i{nData:)|ata.all_fieeeee         quote_) =) {
        ds.
 )atc   && varids.
 ),        quote_) =) {
 _i(i),        quote_) =) {
        & vasborrrivate::Default),
       param
       er().cled.de_lifee(fie_     orrialize_in_plac) {
 _ithern::Tro&e(fie_ds.
s_ams.c ,lc, Someedfetim<'aunt.com/ 
      
// bels own boundtich
     seqsus Desthe d ss.
 bphereic str` arg 
     t zing`onlythat dal lp  ///izenta expressiocoll      seqs); let vSet     }
    }r,   }Forma Unt.com/(..)ifetimes::Static =_ 
   s = maed,
ttrst patifetimes::Static =_ ),
        None => {
ria seqs);) {e(fie_ds.
s_ams.c seriemptydeattrs.de_boh(&boundacked)(_)     ;
       
        }
    }.rem   }acked)(rial_tseq)              ;   }
    }.remote()     seqs);
    let body = Stseq(                 sel|id| thsece_bod,lData::n  variac     ,aexp};
ung      .de_lifey(;   }
    }.remund()rams);

        quote    #[inlmes]
                , M      seq<__A>(sifeh
 ria seq>(__Atime__lizer: __D) -> #serde::__Sifent:       fAResult<Self, __D::Err:Err                where
ere
 fA: _lizer: er: SeqAccestde::Deserializer<#delife>,
                {
           seq         _ => })
}(_) => generico               }
 ont, &pa       lp );
    let body = St    sel|id| thsece_bod,lData::n c, Some(te    .coll     or_lim/s); let vSet     }
    }r,   }Forma Ex};
uselyT.com/(..)i
   s = maed,
ttrst patifetund()rams);

        quoteed]
            impl #d_lizer: er:    __D: #seSim/rde::Deseriali__V;

        fe> for #ident #ty_generics #where_clauslaus     V      l#();
      ife> for #id),
            ams<'as
        le  fn dsife   ferialize<__D>(__deseri_lizer: __D) -> #serde::__Sifent:       f:Result<Self, __D::Error>
                where
         _          __D: #serde::Deserializer<#delife>,
                {
    _          __D: #sers, anput, Derw      erialize<__Difsifet         _ => })
}(_) => generic),
       p,     }
  _ifetimes::Stat}      .collData::_t   s);) { s = maed,
ttrst pati   }
    }imesoStat}
        }
    }typee(fie_ds.
s;

     _ds.
s_ams.c    .all_f_iterriants
            .itrsw     &l      & vasbo)|a& vasbo)h(trs.de_bound()rams);

        quote! doc(hidthe),
        &sync S n FIELDS  v message[r messages a]   a[<#(#     _ds.
s),* ]; }
       )     }      .coll     or_ useria quot!ndTyParams<__V;

    attrs.default(     //   &parse_quote!(_se        mar::<#();
      ife> for #idrializer<#delif            &parse_quote!(_se        marh(_) => ge      }
 ont, &padisplet v=( let vSet     }
    }r,   }Forma    if  
   s = maed,
ttrst patifet      

        quote_lizer:    __D: #sers, anput, Derw      erialize<__Dif      or_ use)         },  }
    }r,   }Forma    if     Struct(_, _) =life
ethods.
   ls = mads.
 )atc   && varids.
 )ters::ont, &params);

        quote
   _          __D: #sers, anput, Derw n       erialize<__Dif#tethods.
h
FIELDSh
      or_ use)               }
            }
  r,   }Forma Ex};
uselyT.com/(_) 
   s = maed,
ttrst patifet      

        quote_lizer: er: Vm(variAccesthinew    _um(vari_lim/(_t(|variah
      or_ use)         },  }
    }r,   }Forma Ex};
uselyT.com/(_ &a::      

        quote_lizer: er: Vm(variAccesthi     }t(|varian_t(|variah
FIELDSh
      or_ use)         },  }
    }r,   }Forma In};
uselyT.com/(_, lifetime of  &a::      

        quote_lizer:    __D: #sers, anput, Derwifet#erialize<__Dif      or_ use)         },  }
    }r,   }Forma Unt.com/(_, lifetime of  &a::      

        quote_lizer:    __D: #sers, anput, Derwifet#erialize<__Dif      or_ use)         },  }
 }
       quote),
  !ndTyParams<#e(fie_     or
TyParams<#[doc(hidthe),
        
      __V;

               impl #det #ty_generics #where_claus     //   &parse_quote!(_se        mar<#();
      ife> for #idrializer<#delif            &parse_quote!(_se        mar<&e::Dese ()>,{}
            }
   ed]
            impl #d_lizer: er: V;

   rde::Deseriali__V;

        fe> for #ident #ty_generics #where_claus     V      l#();
      ife> for #id),
            , Memb};
ungn&isit_ma_eor leeld.
erial_lizer: __D) -> #seFor leeldtime__lizer: __D) -> #sefmtserde::_.attrs.default() {
_lizer: __D) -> #seFor leeld};

it),   (a_eor leeld, #exp};
ungi
      #body
               #      seq              #[inlmes]
            , M         <__A>(sifeh
rial_t   >(__Atime__lizer: __D) -> #serde::__Sifent:       fAResult<Self, __D::Err                where
 fA: _lizer: er: MapAccestde::Deserializer<#delifs #where_clause {
                   _ => {}
            }
   #     or_lim/
TyParams<#e(fie:_t        }
   #displet  None,
        (ersion  one            #fn_dese")]lifetimes borrow     }t fn_deses
:Generics ssnt.data.has, &syn:: Som,
  t(fie], &sync       variantifetimes(,Bnd: &param(&   needs>truct Par ialinowreduown bousupporw(( = deseolifetime oaram( iali
     t zingthe gld bre  ///izenter f Allp.
    
   s = maed,
ttrst pati   }
    }      times;     }
        }();
        ace_bod.t);
     ;::new(),
&cont);
    let (deconResult<#remotpl_generics, _, ty_generics,elf) -> Sthere_clause) = split_wth_de_lifetime(&prams));
    let delife = params.borrowedfetime(&pexp};
ungf leor le!("
      !("sece_bod.tethods.
 y(
 ont, &paexp};
ungf lls = maexp};
ungn Err(ctxtor(&exp};
ungialized)typee(fie_ds.
s_ams.c      <_>;

               ariants
        . falso wets
        .iter()  &l   Data:)il() {
        if !field.attrs.skip:
        .     (i{nData:)|ata.all_fieeeee         quote_) =) {
        ds.
 )atc   && varids.
 ),        quote_) =) {
 _i(i),        quote_) =) {
        & vasborrrivate::Default),
       param
       er().cledd.de_lifee(fie_     orrialize_in_plac) {
 _ithern::Tro&e(fie_ds.
s_ams.c ,lc, Someedfetim> {
ria seqs);) {e(fie_ds.
s_ams.c seriemptydeattrs.de_boacked)(_)     }
        }
    }acked)(rial_tseq)     ted   .coll      seqs);
    let body = Stseqt fn_deseserics {nData::n c     ,aexp};
ungim  ont, &pa       lp );
    let body = St   t fn_deseserics {nData::n c     )led.de_lifee(fie_ds.
s;

     _ds.
s_ams.c    .all_fariants
        .itrsw     &l      & vasbo)|a& vasbo)h(_) =life
ethods.
   ls = mads.
 )atc   && varids.
 )te::newtter( = deser       impl #dialir       impl #. fn_deses)ters::new(( = deserfe> for #ide=econResult<#rem. fn_deses)ters::new( deserms));
  deserms))borrowedfetimund()rams)e),
  !ndTyParams<#e(fie_     or
TyParams<#[doc(hidthe),
        
      __V;

     ( = deser       impl #dnt #ty_generics #where_claus_deseese# deserms));rial#();
      ife> for #idializer<#delif            &parse_quote!(_se        mar<&e::Dese ()>,{}
            }
   ed]
  ( = deser       impl #d_lizer: er: V;

   rde::Deseriali__V;

     ( = deserfe> for #ident #ty_generics #where_claus     V      l()),
            , Memb};
ungn&isit_ma_eor leeld.
erial_lizer: __D) -> #seFor leeldtime__lizer: __D) -> #sefmtserde::_.attrs.default() {
_lizer: __D) -> #seFor leeld};

it),   (a_eor leeld, #exp};
ungi
      #body
               #[inlmes]
            , M      seq<__A>(sifeh
 ria seq>(__Atime__lizer: __D) -> #serde::__Sifent:       fAResult<Self, __D::Err                where
 fA: _lizer: er: SeqAccestde::Deserializer<#delifs #where_clause {
       seq         _ => {             #[inlmes]
            , M         <__A>(sifeh
rial_t   >(__Atime__lizer: __D) -> #serde::__Sifent:       fAResult<Self, __D::Err                where
 fA: _lizer: er: MapAccestde::Deserializer<#delifs #where_clause {
                   _ => {}
            }
   #[doc(hidthe),
        c S n FIELDS  v message[r messages a]   a[<#(#     _ds.
s),* ]; 
uote
   _          __D: #sers, anput, Derw n       erialize<__Dif#tethods.
h
FIELDSh
__V;

    attrs.default(_deseese:_deseializer<#delif            &parse_quote!(_se        marh(_) => ge )     t)of lifetimes borrow fal(
:Generics ssnt.data.has, &syn
// bels,
  Vm(vari], &sync       variantifetimes(,Bnd: &   needs_dlse {     }

// bels hat dalready beis oont)e e(in f t.as_=zing`allaunt.com/ 
// bels txplarAa  ut `en       let v
// belsefield ipo

 am((|
//|v
//       unt.com/ip:attrs.de_bound()um(vari_amx)    Struct(_, _) =life(t.com/,aunt.com/) relev belsethere_at)um(vari_amx)ed.de_lifetime elst.com/_f  nDefate:(times borrowhomo forous, fal(erics {nt.com/,ac, Some(ters::ont, &pa anput, Derwg/t.com/_ fal_aftTroerics {ng/t.com/n c     ,a  }
  .com/_f  n)) }
            }
  cates),
times borrowhomo forous, fal(erics {num(varian c, Some,tch &uof lifetimes borrowhomo forous, fal(
:Generics ssnt.data.has, &syn
// bels,
  Vm(vari], &sync       variantifetimes(,Bnd: &   needs_dlse {de_bouns = ma .cnt.attrs.defa      Tag'asta Ex};
use::En __yiite()), x};
usely_t.com/_ fal(erics {num(varian c, Some,tch &defa      Tag'asta In};
use {nt.c }
ruct(_, fields) = __yiite()),in};
usely_t.com/_ fal(erics {num(varian c, Som{nt.c) }
            }
        Tag'asta Adjeseds_dnt.c,doesteds_}
ruct(_, fields) = __yiite()),adjesedsly_t.com/_ fal(erics {num(varian c, Som{nt.c,doesteds) }
            }
        Tag'asta cates),
times borrowg/t.com/_ fal(erics {num(varian c, Some,tch &uof lifepre    _ fal_um(vari_ fal(
:Gen
// bels,
  Vm(vari], &sync       variantifetimes(,Bnd: &({Literal, S,;
    )_dlse {ote(rialrabute, are _
// bels relev bels         ariants
        . falso wets
        .iter()  &l   lev bel)il(lev bel       if !field.attrs.skip:; 
.remote() (vari_ds.
s_ams.c      <_>;

rabute, are _
// belsaram
          ..
        .     (i{nlev bel)ilta.all_fieeeee         quote_) =lev bel       ds.
 )atc   && varids.
 ),        quote_) =) {
 _i(i),        quote_) =lev bel       & vasborrrivate::Default),
       param
       er().cledd.de_lifeeselthrough;

rabute, are _
// belsaram
     po

 am((|l   lev bel)illev bel       oeserip:
        .     oeser_amx| Struct(_, _) =lifeignor _um(vari relev bel_ds.
s_ams.c [oeser_amx].1      ..s,serializing(       _lizer: __D) -> #seOk(__t(fie::#ignor _um(vari)) }
       :; 
.remote() (vari:_t   s);   }
    }typelev bel_ds.
s relev bel_ds.
s_ams.c efield i     (ds.
h
   Da|ods.
params.is_packed);
        quote# doc(hidthe),
        &sync S n VARIANTS  v message[r messages a]   a[<#(#lev bel_ds.
s),* ]; }
            }      .coll ev bel_     orria
    let body = Stnd so we _ithern::Tro         slev bel_ds.
s_ams.c rivate::Dec, Som{ivate::De vari     }
  catei     }
  eselthrough      im      .() (vari:_t   ,l ev bel_     or)of lifetimes borrow x};
usely_t.com/_ fal(
:Generics ssnt.data.has, &syn
// bels,
  Vm(vari], &sync       variantifetimes(,Bnd: &   needs_dlse {   }();
        ace_bod.t);
     ;::new(),
&cont);
    let (deconResult<#remotpl_generics, _, ty_generics,elf) -> Sthere_clause) = split_wth_de_lifetime(&prams));
    let delife = params.borrowedfetime(&p
ethods.
   ls = mads.
 )atc   && varids.
 )ters::new(exp};
ungf leor le!(" fals!("sece_bod.tethods.
 y(
 ont, &paexp};
ungf lls = maexp};
ungn Err(ctxtor(&exp};
ungialized)type() (vari:_t   ,l ev bel_     or);
  re    _ fal_um(vari_ fal(um(varian c, Someedfetim<'aMe_bouarmic saextractich
// belo
   h,es aung     coll ev bel_armicrelev bels         ariants
        . falso wets
        .iter()  &l   lev bel)il(lev bel       if !field.attrs.skip:
        .     (i{nlev bel)ilta.all_fieeeeetypelev bel_ds.
;

     _i(i);   }
    }.remote(),
  ;

Me_bo(times borrow x};
usely_t.com/_(|varian        quote_) =erics {num(vari,ec, Som{ivate::Delifey(;   }
    }.remrams);

        quote
   (__t(fie::#lev bel_ds.
, _t(|varia)    #),
  (_) => generic),
       p
       &paall_if !pm/s);lev bels         ariants
        .all(|
// belillev bel       if !field.attrs.skip:; se {ote(re_bo_um(vari reifaall_if !pm/sct TypeMacro<T);
 ;
 an empty  falslike ` falsImpo
sible {}` nfean efalsin d in t TypeMacro<alla
// bels hat d`#[lizer(if !field.attrs.sk)]`.rams.is_packed);
        quotero<FIXME: Once ersion (exhnertivid| t};
u )_;
 mesble:        quotero<
   _lizer: __D) -> #seEche_t.ch)s) _lizer: er: {
  Accesthi
// bel::<__t(fie>   emar);        quotero<_lizer: __D) -> #seEche_t.ch) generics yet_lizer: __D) -> #serde::_::            quoteuote_lizer: er: {
  Accesthi
// bel::<__t(fie>   emar),        quote_) =|l nt);o
sible  Da|o let v_nt);o
sible {})tch &cont      }
        }
    }acked);
        quote let v_lizer: er: {
  Accesthi
// bel   emar)?
                {
#(#lev bel_armi)*
ult() {
lize  }
            }alized)rams)e),
  !ndTyParams<# ev bel_     or
TyParams<#[doc(hidthe),
        
      __V;

               impl #det #ty_generics #where_claus     //   &parse_quote!(_se        mar<#();
      ife> for #idrializer<#delif            &parse_quote!(_se        mar<&e::Dese ()>,{}
            }
   ed]
            impl #d_lizer: er: V;

   rde::Deseriali__V;

        fe> for #ident #ty_generics #where_claus     V      l#();
      ife> for #id),
            , Memb};
ungn&isit_ma_eor leeld.
erial_lizer: __D) -> #seFor leeldtime__lizer: __D) -> #sefmtserde::_.attrs.default() {
_lizer: __D) -> #seFor leeld};

it),   (a_eor leeld, #exp};
ungi
      #body
               , M      efal<__A>(sifeh
  emar>(__Atime__lizer: __D) -> #serde::__Sifent:       fAResult<Self, __D::Err                where
 fA: _lizer: er: {
  Accestde::Deserializer<#delifs #where_clause {
 re_bo_um(vari         _ => {}
            }
   #  (vari:_t    
uote
   _          __D: #sers, anput, Derw fal(
:Gen  where
 ferialize<__Dializer<#delif#tethods.
h(_) => generiVARIANTSh(_) => generi__V;

    attrs.default() {
     //   &parse_quote!(_se        mar::<#();
      ife> for #idrializer<#delifelif            &parse_quote!(_se        marh(_) => generich(_) => ge) {
       ifetimes borrowin};
usely_t.com/_ fal(
:Generics ssnt.data.has, &syn
// bels,
  Vm(vari], &sync       variantifetimes(,Blaus agnerics,Bnd: &   needs_dlse {ote(() (vari:_t   ,l ev bel_     or);
  re    _ fal_um(vari_ fal(um(varian c, Someedfetim<'aMe_bouarmic saextractich
// belo
   h,es aung     coll ev bel_armicrelev bels         ariants
        . falso wets
        .iter()  &l   lev bel)il(lev bel       if !field.attrs.skip:
        .     (i{nlev bel)ilta.all_fieeeeetypelev bel_ds.
;

     _i(i);   }
    }.remote(),
  ;

Me_bo(times borrowin};
usely_t.com/_(|varian        quote_) =erics {        quote_) =lev bel{        quote_) =c, Som{ivate::Delifeing(       _ferialize<__D){ivate::Delifey(;   }
    }.remrams);

        quote
   __t(fie::#lev bel_ds.
    #),
  (_) => generic),
       p
       &paexp};
ungf leor le!("in};
uselynt.com/  fals!("sece_bod.tethods.
 y(
 ont, &paexp};
ungf lls = maexp};
ungn Err(ctxtor(&exp};
ungialized)rams)e),
  !ndTyParams<# ev bel_     or
TyParams<#  (vari:_t    
uote
    els(__t.c,d__oesteds)s) _lizer:    __D: #sers, anput, Derwifet
:Gen  where
 ferialize<__Dializer<#delif_lizer: __D) -> #sed#seT.com/CestedsV;

   ::<__t(fie>hinew(#t.c,d#exp};
ungi)?;::new   } els ferialize<__DDef  &parse_quote!(_searseCesteds   __D: #sers,< f:Result<Shinew(__oesteds);   }
    } let v_nt.c 
        quote#(#lev bel_armi)*
ult() {
} {
       ifetimes borrowadjesedsly_t.com/_ fal(
:Generics ssnt.data.has, &syn
// bels,
  Vm(vari], &sync       variantifetimes(,Blaus agnerics,B&sync Stedsnerics,Bnd: &   needs_dlse {ote(();
        ace_bod.t);
     ;::new(),
t);
        lace_bod.t);
      ed.de_life&cont);
    let (deconResult<#remotpl_generics, _, ty_generics,elf) -> Sthere_clause) = split_wth_de_lifetime(&prams));
    let delife = params.borrowedfetimote(() (vari:_t   ,l ev bel_     or);
  re    _ fal_um(vari_ fal(um(varian c, Someedfetimcoll ev bel_arminer   <_>;

&lev bels         ariants
        . falso wets
        .iter()  &l   lev bel)il(lev bel       if !field.attrs.skip:
        .     (i{nlev bel)ilta.all_fieeeeetypelev bel_i_quo;

     _i(i);   }
    }.remote(),
  ;

Me_bo(times borrowg/t.com/_(|varian        quote_) =erics {        quote_) =lev bel{        quote_) =c, Som{ivate::Delifeing(       _ferialize<__D){ivate::Delifey(;   }
    }.remrams);

        quote
   __t(fie::#lev bel_i_quo;
  #),
  (_) => generic),
       param
       er().cledd.de_liferusl_ds.
;

ce_bod.tethods.
 yters::new(exp};
ungf leor le!("adjesedslynt.com/  fals!("serusl_ds.
(
 ont, &paexp};
ungf lls = maexp};
ungn Err(ctxtor(&exp};
ungialetime(&p
ethods.
   ls = mads.
 )atc   && varids.
 )ters::new(theywg/known_e  let rens = matceywg/known_e  letowedfetim<'a, 'g/knownbe  let bre selfe =,redupi  ;ut `     orrzing`canes ep ovldm::Co<'athose. Oeserwiricedupi  ;ut `     orrzing`fails on'g/knownbkeys.d.de_lifee(fie_     or_ty;

) {raeywg/known_e  let    }
    }acked);
f_lizer: __D) -> #sed#seT.cOrCestedst(fieV;

          }
        }
    }acked);
f_lizer: __D) -> #sed#seT.cCestedsOesert(fieV;

          }edfetime(&p
agtor_oestedsria quot!ndTyParams<#e(fie_     or_ty;s #where_claus agne#t.c,
        &sync Stedsne#c Steds, }
            }      .coll ev bel_lim/s); quot!ndTyParams<_lizer: __D) -> #sed#seAdjesedslyT.com/{
  Vm(variSim/::<__t(fie>;s #where_claus fal_ds.
ne#rusl_ds.
,
        &syn
// bels,
VARIANTSh(_) => generie(fie:_ fal    &parse_quote!(_se        mar }
            }alized)typerialmisthiswoestedsria quot!ndTyParams<_lizer: __D) -> #seEche< fAResult<h,

_       deResult<Shimisthiswe(fie(#c Steds))     ted   .collrialmisthiswoesteds_eselthrough;

       :; se {ote(risthiswoesteds_armicrelev bels         ariants
        . falso wets
        .iter()  &l   lev bel)il(lev bel       if !field.attrs.skip:
        .iter()_     (i{nlev bel)ilta.all_fieeeeetypelev bel_i_quo;

     _i(i); .all_fieeeeetypelev bel_idedsria&lev bel.ideds;   }
    }.remote(armv=( let vlev bel.stylics #where_clauslausStylia Unit&a::      

        quoterics yet_lizer: __D) -> #seOk(#t);
      ::#
// bel_ams.co         _ => })
}, #where_clauslausStylia New    
) {lev bel       tc   && variant.deserinds.pu&a::        None = }
    } els      llev bel         .    owed.de_lifetime }
    } elseuncs,  quote::{quot!(::{q=> _       __D) -> #sed#semisthiswe(fiewed.de_lifetime }
    }acked)
        None = }
    }    #eunc #c Steds).    #t);
      ::#
// bel_ams.co         _ => })
    }bound.clone()));
                }
_&a::        None = }
    }misthiswoesteds_eselthrough;

       _&a::#misthiswoestedswed.de_lifetime }
    }      times;              })
}(_) => generics,serializing(und()rams);

        quote    __t(fie::#lev bel_i_quo;
  #arm,(_) => generico          param
       er().::<   <_>>((ters::) {!risthiswoesteds_armiseriemptydeattrs.de_bomisthiswoestedsria quot!ndTyParams<   } let v_n// At                 {
#(#risthiswoesteds_armi)*
ult() {
lizee {
 risthiswoesteds_eselthrough(_) => generic),
       ;     }
     <'aAdvance ut ` lp by ateskey,}      ungfearlynin`ca   of eult<.d.de_lifemext_keyria quot!ndTyParams<_lizer: er: MapAccesttimext_key_lim/(&fn v_t lp,e#t.ctor_oesteds)? }
  }      .coll ev bel_
     lp ); quot!ndTyParams<_lizer: er: MapAccesttimext_     _lim/(&fn v_t lp,e# ev bel_lim/)? }
  }      .ro<W is selfeungfg/knownbe  let,reduwbeloto trans    dslyns ep through;keys
ne =ro<we own'tocbre sbon vg/til<we fi_q `t.c`, `oesteds`, t<hrun on vof keys.d.de_lifemext_relevbel_keyria) {raeywg/known_e  let    }
    }mext_key     }
        }
    }acked)(        None => {
riav_trk : _lizer: __D) -> #seOaram(<_lizer: __D) -> #sed#seT.cOrCestedst(fie>Def  &parse_quote!(_seimes;             whilic
   _lizer: __D) -> #seund()_ k);
 #mext_keyrattrs.default() {
  et v_nk

        quoterics yet_lizer: __D) -> #sed#seT.cCestedsOesert(fieseOesers),
        None = }
    }    
   _s) _lizer: er: MapAccesttimext_     ::<_lizer: er: Ignor dAn:>  fn v_t lp)?;::new   }       quote_) =cestin  t generics yet");
    },        quoterics yet_lizer: __D) -> #sed#seT.cCestedsOesert(fieseT nDe,
        None = }
    }    _trk = _lizer: __D) -> #seund()_lizer: __D) -> #sed#seT.cOrCestedst(fieseT.c);::new   }       quote_) =break;         _ => })
    }bound.clone()));
 yet_lizer: __D) -> #sed#seT.cCestedsOesert(fieseCestedsri,
        None = }
    }    _trk = _lizer: __D) -> #seund()_lizer: __D) -> #sed#seT.cOrCestedst(fieseCestedswed.de_lifetime }
    }_) =break;         _ => })
    }bound.clone()));
}
      #body
               _trk }
       )     }      .yn:: ep through;remai ungfkeys, lookungfialiduplins esvof previously-limn    .yn:keys.<W is g/knownbe  let bre raei =,rany:keyrzing`isn'totiduplins e fielthe gld b,
t);
 poidsrimmed    lynproducica
/eult<.d.de_life      remai ung_keys ); quot!ndTyParams< let v mext_relevbel_keyr
        quote_lizer: __D) -> #seund()_lizer: __D) -> #sed#seT.cOrCestedst(fieseT.c)ri,
        None = }
 _lizer: __D) -> #seEche< fAResult<h,

_       deResult<Shiduplins ewe(fie(#t n)) }
      ));
}
      #body
_lizer: __D) -> #seund()_lizer: __D) -> #sed#seT.cOrCestedst(fieseCestedswri,
        None = }
 _lizer: __D) -> #seEche< fAResult<h,

_       deResult<Shiduplins ewe(fie(#c Steds))         ));
}
      #body
_lizer: __D) -> #secates),
_lizer: __D) -> #seOk(__   ), }
            }      .collfi_ishwoesteds_e isnt.c =
) {lev bel_armiseriemptydeattrs.de_bo quot!ndTyParams<   } let v# ev bel_
     lp { tch &cont      }
        }
    }acked);
        quote els f    =( let v  ev bel_
     lp {       None = }
 ld    __D: #se ut `buffer ddoesteds_nowrrric fe knowrrr}

// bel.               {
#(#lev bel_armi)*
ult() {
lize ?;        quotero<V;

 ;remai ungfkeys, lookungfialiduplins es.             #      remai ung_keys }
            }alized)rams)e),
  !ndTyParams<# ev bel_     or
TyParams<#  (vari:_t    
uote
   #[doc(hidthe),
        
      __Sim/            impl #det #ty_generics #where_claus:: Soss__t(fie, #where_claus     //   &parse_quote!(_se        mar<#();
      ife> for #idrializer<#delif            &parse_quote!(_se        mar<&e::Dese ()>,{}
            }
   ed]
            impl #d_lizer: er:    __D: #seSim/rde::Deseriali__Sim/     fe> for #ident #ty_generics #where_claus     V      l#();
      ife> for #id),
            , M
        le  fn dsife   ferialize<__D>(__deseri_lizer: __D) -> #serde::__Sifent:       f:Result<Self, __D::Err                where
 f   _          __D: #serde::Deserializer<#delifattrs.default() {
  et visit.// At                 {
  {
#(#lev bel_armi)*
ult() {
lize })
}(_) => generic),
       
TyParams<#[doc(hidthe),
        
      __V;

               impl #det #ty_generics #where_claus     //   &parse_quote!(_se        mar<#();
      ife> for #idrializer<#delif            &parse_quote!(_se        mar<&e::Dese ()>,{}
            }
   ed]
            impl #d_lizer: er: V;

   rde::Deseriali__V;

        fe> for #ident #ty_generics #where_claus     V      l#();
      ife> for #id),
            , Memb};
ungn&isit_ma_eor leeld.
erial_lizer: __D) -> #seFor leeldtime__lizer: __D) -> #sefmtserde::_.attrs.default() {
_lizer: __D) -> #seFor leeld};

it),   (a_eor leeld, #exp};
ungi
      #body
               , M         <__A>(sifeh
rial_t   >(__Atime__lizer: __D) -> #serde::__Sifent:       fAResult<Self, __D::Err                where
 fA: _lizer: er: MapAccestde::Deserializer<#delifs #where_clause {
ro<V;

 ;rr}
firs ;relevbelfkey.ttrs.default() {
  et v mext_relevbel_keyr
        quote   quotero<Firs ;keyris ut `tag.       None = }
    }_lizer: __D) -> #seund()_lizer: __D) -> #sed#seT.cOrCestedst(fieseT.c)ri,
        None = }
    quotero<Parse ut `tag.       None = }
    }uote els f// At =v  ev bel_
     lp;       None = }
    quotero<V;

 ;rr}
seoesdfkey.ttrs.default() {
ult() {
  et v mext_relevbel_keyr
        quote   quote   quotero<Seoesdfkey ;
 aiduplins e of ut `tag.       None = }
    }uote   }_lizer: __D) -> #seund()_lizer: __D) -> #sed#seT.cOrCestedst(fieseT.c)ri,
        None = }
    quotene = }
 _lizer: __D) -> #seEche< fAResult<h,

_       deResult<Shiduplins ewe(fie(#t n)) }
      ));
    _ => })
    }bound.clone()));
 yet   quotero<Seoesdfkey ;
 ut `oesteds.       None = }
    }uote   }_lizer: __D) -> #seund()_lizer: __D) -> #sed#seT.cOrCestedst(fieseCestedswri,
        None = }
 ne = }
    }uote els f    =(_lizer: er: MapAccesttimext_     _lim/(&fn v_t lp,       None = }
 ne = }
    }uoteere
 fSim/ {       None = }
 ne = }
    }uoteere
laus:: Soss__f(fie, #where_clausssssssssssssssssssssssssssss     //   &parse_quote!(_se        mar, #where_clausssssssssssssssssssssssssssss            &parse_quote!(_se        marh(_) => generi    ));
    _ => })
    })?;::new   }       quote_) =   quotero<V;

 ;remai ungfkeys, lookungfialiduplins es.                           {
  {
#      remai ung_keys }
      ));
    _ => })
    }bound.clone()));
 yet   quotero<Tseria;
 no
seoesdfkey; mighto tyokay
) {ut `fe hat dalunit&
// bel.               {
      #body
_lizer: __D) -> #secates),
 risthiswoesteds generics yet");
                        }
    }bound.clone()));
uotero<Firs ;keyris ut `oesteds.       None = }
    }_lizer: __D) -> #seund()_lizer: __D) -> #sed#seT.cOrCestedst(fieseCestedswri,
        None = }
 ne = }
 ro<Buffer up ut `oesteds.       None = }
    }uote els foestedsria_lizer: er: MapAccesttimext_     ::<_lizer: _quote!(_searseCesteds>  fn v_t lp)?;::new   }       quote_) =ro<V;

 ;rr}
seoesdfkey.ttrs.default() {
ult() {
  et v mext_relevbel_keyr
        quote   quote   quotero<Seoesdfkey ;
 ut `tag.       None = }
    }uote   }_lizer: __D) -> #seund()_lizer: __D) -> #sed#seT.cOrCestedst(fieseT.c)ri,
        None = }
    quotene = }
  els ferialize<__DDef  &parse_quote!(_searseCesteds   __D: #sers,< fAResult<Shinew(__oesteds);                           {
  {
#fi_ishwoesteds_e isnt.c }
      ));
    _ => })
    }bound.clone()));
 yet   quotero<Seoesdfkey ;
 aiduplins e of ut `oesteds.       None = }
    }uote   }_lizer: __D) -> #seund()_lizer: __D) -> #sed#seT.cOrCestedst(fieseCestedswri,
        None = }
 ne = }
    }uote_lizer: __D) -> #seEche< fAResult<h,

_       deResult<Shiduplins ewe(fie(#c Steds))         ));
    _ => })
    }bound.clone()));
 yet   quotero<Tseria;
 no
seoesdfkey.               {
    lause {
_lizer: __D) -> #secates),
        None = }
    }    lause {
_lizer: __D) -> #seEche< fAResult<h,

_       deResult<Shimisthiswe(fie(#t n)) }
      ));
    _ => })
    }bound.clone()));
 yet   q                }
    }bound.clone()));
uotero<Tseria;
 no
firs ;key.       None = }
    }_lizer: __D) -> #secates),
        None = }
    }    _lizer: __D) -> #seEche< fAResult<h,

_       deResult<Shimisthiswe(fie(#t n)) }
      ));
    _ =>}bound.clone()));
}
      #body
               , M      seq<__A>(sifeh
rial_tseq>(__Atime__lizer: __D) -> #serde::__Sifent:       fAResult<Self, __D::Err                where
 fA: _lizer: er: SeqAccestde::Deserializer<#delifs #where_clause {
ro<V;

 ;rr}
firs ;  eeeds - ut `tag.       None = }
  let v_lizer: er: SeqAccesttimext_  eeeds  fn v_tseq)?
                {
    _lizer: __D) -> #seund()_ e(fiewri,
        None = }
 ne = }
 ro<V;

 ;rr}
seoesdf  eeeds - ut `oesteds.       None = }
    }uote let v_lizer: er: SeqAccesttimext_  eeeds_lim/( }
      ));
    _ => })
    &fn v_tseq,        quote_) => {
        _fSim/ {       None = }
 ne = }
    }uote:: Soss__f(fie, #where_clausssssssssssssssssssss     //   &parse_quote!(_se        mar, #where_clausssssssssssssssssssss            &parse_quote!(_se        marh(_) => generi    ));
    _ =>}h(_) => generi    ));
    )?
                {
    lause {
_lizer: __D) -> #seund()_    )s),
_lizer: __D) -> #seOk(__   ), }
      ne()));
 yet   quotero<Tseria;
 no
seoesdf  eeeds.               {
    lause {
_lizer: __D) -> #secates),
        None = }
    }    lause {
_lizer: __D) -> #seEche_       deResult<iant   id_length(1, &isit)) }
      ));
    _ => })
    }bound.clone()));
 yet   q                }
    }bound.clone()));
uotero<Tseria;
 no
firs ;  eeeds.               {
    _lizer: __D) -> #secates),
        None = }
    }    _lizer: __D) -> #seEche_       deResult<iant   id_length(0, &isit)) }
      ));
    _ =>}
ult() {
lize })
}(_) => generic),
       
TyParams<#[doc(hidthe),
        c S n FIELDS  v message[r messages a]   a[#t.c,d#oesteds]; }
      _          __D: #sers, anput, Derw n     
:Gen  where
 ferialize<__Dializer<#delif#tethods.
h(_) => generiFIELDSh(_) => generi__V;

    attrs.default() {
     //   &parse_quote!(_se        mar::<#();
      ife> for #idrializer<#delifelif            &parse_quote!(_se        marh(_) => generich(_) => ge) {
       ifetimes borrowg/t.com/_ fal(
:Generics ssnt.data.has, &syn
// bels,
  Vm(vari], &sync       variantifetimes(,Bnd: &   needs_dlse {   }firs _leelmpsriaimes;      anput, Derwg/t.com/_ fal_aftTroerics {num(varian c, Som{nfirs _leelmps)    ifetimes borrowg/t.com/_ fal_aftTro
:Generics ssnt.data.has, &syn
// bels,
  Vm(vari], &sync       variantifetimes(,Blausfirs _leelmps:&param(&ate:>,Bnd: &   needs_dlse {   }leelmpsicrelev bels         ariants
        .iter()  
// belil(lev bel       if !field.attrs.skip:
        .     
// belilattrs.default(ate:(times borrowg/t.com/_(|varian        quote_) =erics {        quote_) =lev bel{        quote_) =c, Som{ivate::Delifeing(       _ferialize<__D){ivate::Delifey(),
       p
 se {   }leelmpsicrefirs _leelmps.nt}o_field ichime(leelmpsip
 se {ro<TODO
t);
 mest neAc`'deo tyb     nby savungfut `eult<so
   hrr}
fail       ld b,elmpsithe d heurissageusm/ by TOML waic sac`'n ;rr}
falb  nof
           ld procestm/ beforica
/eult<, be rericut `eult<rrric htxplner fftTrcut      ld largi n falb  nof
      . I'mn bousuricIslike rric. May ty
 ;w`'deo t     ld b     n sasat dallfut `eult<sobe rcombmesfut lsin saatesmest neAzingthe gld explimesiwhy nds. of ut `
// bels  let ed.d.de_lifeeselthrough_msgf leor le!(),
      "emar didn bou let vany:
// beloofaunt.com/  fals!("s
uote_) =erics .tethods.
 y     i;d.de_lifeeselthrough_msgf lls = maexp};
ungn Err(ctxtor(&eselthrough_msgialized)rams)e),
  !ndTyParams< els foestedsria<_lizer: _quote!(_searseCestedsh,

_          __D: #se>s, anput, Der _ferialize<__D)?;::new   } els ferialize<__DDef  &parse_quote!(_searseCestedsRef   __D: #sers,< f:Result<Shinew(&__oesteds);   }
    }#n        quoteifc
   _lizer: __D) -> #seOk(__ok);
 #leelmpsicattrs.default() {
      t_lizer: __D) -> #seOk(__ok);(_) => generic),
      )*

   }    _lizer: __D) -> #seEche_       deResult<iacus   (#eselthrough_msgi) {
       ifetimes borrow x};
usely_t.com/_(|varian     erics ssnt.data.has, &syn
// belner ev bel{     c       variantifetimes(,Bnd: &   needs_dlse {ifc
   und()| th) relev bel       tc   && variant.dendTyParams< els((ctxpld, (ctxpld   {ng/(ctxtfn) re(ctxttc   && vari ev bel_ant.derics {num(vari,e| th);  }
    }      trams)e),
  !ndTyParams<   }#(ctxpld generics yet_lizer: __D) -> #serde::_::            quoteuote_lizer: er: Vm(variAccesthinew    _um(vari::<#(ctxpld   >n_t(|varia),d#g/(ctxtfn)),
       ;     }
     typelev bel_idedsria&lev bel.ideds;   }
  let vlev bel.stylics #where_cStylia Unit&a::Struct(_, _) =life
);
        lace_bod.t);
      ed.de_lifeing(     e),
  !ndTyParams<   }uote_lizer: er: Vm(variAccesthiunitt(|varian_t(|varia)?;::new   }       q_lizer: __D) -> #seOk(#t);
      ::#
// bel_ams.co         _ =>  }
            }
  r,ylia New    
:En __yiite()), x};
usely_t.com/_new    _um(vari(
        &syn
// bel_ams.c 
   quote_) =erics {        quote&lev bel.      [0],
        &sync, Som{ivate::De(,  }
    }r,ylia Tupl 
:En __yiite()),tupl (
   quote_) =erics {        quote&lev bel.      ,
        &sync, Som{ivate::DeeeeeTupl Forma Ex};
uselyT.com/(
// bel_ams.co{ivate::De(,  }
    }r,ylia    if      anput, Derw n     
:Gen  where
erics {        quote&lev bel.      ,
        &sync, Som{ivate::Deeeeer,   }Forma Ex};
uselyT.com/(
// bel_ams.co{ivate::De(,  }
      ld Gd so wes significbeloerit of ut `
     seqsbe r       lp bodiesvof      ors
ar ialiut `
// bels of in};
uselynt.com/  fal. ifetimes borrowin};
usely_t.com/_(|varian     erics ssnt.data.has, &syn
// belner ev bel{     c       variantifetimes(,B     anput, Der// {Literal, S,Bnd: &   needs_dlse {ifclev bel       tc   && variant.deserisnd()ti   }
    }      ttimes borrowg/t.com/_(|varianerics {num(vari,ec, Som{ lifetime of  ;     }
     typelev bel_idedsria&lev bel.ideds;   }
  let veff};
uvrw nyli((|varia) s #where_cStylia Unit&a::Struct(_, _) =life
);
        lace_bod.t);
      ed.de_lifeing(e(&p
ethods.
   ce_bod.tethods.
 yters::_fieeeeetypelev bel_ds.
   lev bel.ideds.}o_s aung yters::_fieeeeetypedefa::_.  lev bel.      .get(0 i          |ndTyParams<   }uotetypedefa::_.  ate:( use_;
 misthis(f(fie,ac, Some(ters::ont, &paing(       t#erfa::_))         ));
})ed.de_lifeing(     e),
  !ndTyParams<   }uote_lizer:    __D: #sers, anput, Derwifet#erialize<__Dif  &parse_quote!(_searseIn};
uselyT.com/UnitV;

   ::new(#tethods.
h
#lev bel_ds.
))?;::new   }       q_lizer: __D) -> #seOk(#t);
      ::#
// bel_ams.c #erfa::_)         _ =>  }
            }
  r,ylia New    
:En __yiite()),g/t.com/_new    _um(vari(
        &syn
// bel_ams.c 
   quote_) =erics {        quote&lev bel.      [0],
        &syn&erialize<__Dializer<#d(,  }
    }r,ylia    if      anput, Derw n     
:Gen  where
erics {        quote&lev bel.      ,
        &sync, Som{ivate::Deeeeer,   }Forma In};
uselyT.com/(
// bel_ams.c  erialize<__D){ivate::De(,  }
    }r,ylia Tupl 
:Enunl, chibl   "oont)e ein lizerttcruvrwin};
uses"e,tch &uof lifetimes borrowg/t.com/_(|varian     erics ssnt.data.has, &syn
// belner ev bel{     c       variantifetimes(,B     anput, Der// {Literal, S,Bnd: &   needs_dlse {ifc
   und()| th) relev bel       tc   && variant.dendTyParams< elsg/(ctxtfn reg/(ctxt}o_
// bel_closurinerics {num(vari,eesese);  }
    }      trams)e),
  !ndTyParams<   }_lizer: __D) -> #serde::_::    #| tht#erialize<__D),d#g/(ctxtfn)),
       ;     }
     typelev bel_idedsria&lev bel.ideds;   }
  let veff};
uvrw nyli((|varia) s #where_cStylia Unit&a::Struct(_, _) =life
);
        lace_bod.t);
      ed.de_lifeing(e(&p
ethods.
   ce_bod.tethods.
 yters::_fieeeeetypelev bel_ds.
   lev bel.ideds.}o_s aung yters::_fieeeeetypedefa::_.  lev bel.      .get(0 i          |ndTyParams<   }uotetypedefa::_.  ate:( use_;
 misthis(f(fie,ac, Some(ters::ont, &paing(       t#erfa::_))         ));
})ed.de_lifeing(     e use!rattrs.default() {
  et v_lizer:    __D: #sers, anput, Derwifet
:Gen  where
ams<   }#erialize<__Dializer<#delif));
 yet_lizer: __D) -> #sed#seUnt.com/UnitV;

   ::new(#tethods.
h
#lev bel_ds.
)alizer<#delif));
)

        quoterics yet_lizer: __D) -> #seOk(ip:a),
_lizer: __D) -> #seOk(#t);
      ::#
// bel_ams.c #erfa::_)ializer<#delif));
 yet_lizer: __D) -> #seEche_t.ch)s)>t_lizer: __D) -> #seEche_t.ch),
ult() {
lize })
}(_) => generic),
       
    }
  r,ylia New    
:En __yiite()),g/t.com/_new    _um(vari(
        &syn
// bel_ams.c 
   quote_) =erics {        quote&lev bel.      [0],
        &syn&erialize<__Dializer<#d(,  }
    }r,ylia Tupl 
:En __yiite()),tupl (
   quote_) =erics {        quote&lev bel.      ,
        &sync, Som{ivate::DeeeeeTupl Forma Unt.com/(
// bel_ams.c  erialize<__D){ivate::De(,  }
    }r,ylia    if      anput, Derw n     
:Gen  where
erics {        quote&lev bel.      ,
        &sync, Som{ivate::Deeeeer,   }Forma Unt.com/(
// bel_ams.c  erialize<__D){ivate::De(,  }
      ifetimes borrow x};
usely_t.com/_new    _um(vari(
    
// bel_ams.cneriyna Ims.c 
   qerics ssnt.data.has, &syn:: Sossnt(fie, #whec       variantifetimes(,Bnd: &   needs_dlse {   }();
        lace_bod.t);
      edlse {ifc) {
        if !field.attrs.skipndTyParams< elsdefa::_.  ate:( use_;
 misthis(f(fie,ac, Some(ters::ont,      trams)e),
  !ndTyParams<   }_lizer: er: Vm(variAccesthiunitt(|varian_t(|varia)?;::new   }    _lizer: __D) -> #seOk(#t);
      ::#
// bel_ams.ct#erfa::_))          ;     }
       et v) {
        tc   && variant.dendTyParams<cates),
        None =lifee(fie_ty;

) {
  tyters::_fieeeeetype      l) {
          .    owed.de_lifetime elseuncs,ers::ont, &paing(     e::{quot!(::{q=> _       er: Vm(variAccesthinew    _um(vari::<#e(fie_ty>)ed.de_lifeing(     e use!rattrs.default() {
_lizer: __D) -> #serde::_::    #eunc _t(|varia),d#t);
      ::#
// bel_ams.co         _ =>  }
            }
  rnd()| th) r  Struct(_, _) =life((ctxpld, (ctxpld   ) re(ctxttc   && varie(fie_ant.derics {n) {
  ty,e| th);  }
    }ing(     e),
  !ndTyParams<   }uote#(ctxpld generics yet yet_lizer: __D) -> #serde::_::            quoteuoteuote_lizer: er: Vm(variAccesthinew    _um(vari::<#(ctxpld   >n_t(|varia),        quoteuoteuote|__(ctxpld|d#t);
      ::#
// bel_ams.c(__(ctxpld.     )o         _ =>  }
            uof lifetimes borrowg/t.com/_new    _um(vari(
    
// bel_ams.cneriyna Ims.c 
   qerics ssnt.data.has, &syn:: Sossnt(fie, #whe anput, Der// &{Literal, S,Bnd: &   needs_dlse {(),
t);
        lace_bod.t);
      ed.de_lifee(fie_ty;

) {
  tyters::  et v) {
        tc   && variant.dendTyParams<cates),
        None =life      l) {
          .    owed.de_lifetime elseuncs,(     e::{quot!(::{q=> <#e(fie_tyh,

_          __D: #se>s, anput, Der)ed.de_lifeing(     e use!rattrs.default() {
_lizer: __D) -> #serde::_::    #eunc #erialize<__D),d#t);
      ::#
// bel_ams.co         _ =>  }
            }
  rnd()| th) r  Struct(_, _) =     e),
  !ndTyParams<   }uote els f     :__lizer: __D) -> #serde::__#e(fie_ty, _>;

#| tht#erialize<__D);ttrs.default() {
_lizer: __D) -> #serde::_::     f     ,d#t);
      ::#
// bel_ams.co         _ =>  }
            uof lifetimes borrownd so we _ithern::Tro     :: Som,
  (rics, Ims.c  &BTreeSet<S aung>)], &sync       variantifetimes(,Blaus;
   / belnebool,Blaus;gnor _um(vari:&param(&{Literal, Srializeeselthrough:&param(&{Literal, Sriand: &   needs_dlse {(),
t);
        l       _fF(fiewed.de_lifee(fie_ams.c   r   <_>;

&      .field i     (_, ams.c  Da|oams.co   er().cledd.de_life     or_ed]
 ia
    let body = Stithern::Tro         st);
      i     }
  e     ,
        ;
   / beli     }
  eselthrough      ams<cate      ams<!;
   / bel &&lls = mahas_itrstenrrrivate::Decate      p:; 
.remote(         =
) {!;
   / bel &&lls = mahas_itrstenrrattrs.de_bound()       <'de>))     }
        }
    }cate     }alized)rams)e),
  !ndTyParams<#[selfe(non_catal_ca       s),
        #[doc(hidthe),
         fals_fF(fie #         
        quote#(#e(fie_ams.c ,)*
ult() {
lize#ignor _um(vari),
       
TyParams<#[doc(hidthe),
        
      __t(fieV;

   ;     }
   ed]
<'de>d_lizer: er: V;

   r'de>diali__t(fieV;

    s #where_claus     V      l_fF(fie #        ),
            #     or_ed]
{}
            }
   ed]
<'de>d_lizer:    __D: #ser'de>diali__t(fie #         
        quote#[inlmes]
            , M
        le  fn d ferialize<__D>(__deseri_lizer: __D) -> #serde::__Sife   f:Result<Self, __D::Err                where
 f   _          __D: #serd'de>ializer<#delifs #where_clause {
_lizer:    __D: #sers, anput, Derwithern::Tro  erialize<__Dif__t(fieV;

   o         _ =>  }
            uof l/ld Gd so wes  falsbe rits `   __D: #se` ed]
eeedsaram(rrric repr  _els , chl/ld non-if !pm/s// At of ut `
     lifetimes borrowe(fie_ams.cn::Tro     :: Som,
  (rics, Ims.c  &BTreeSet<S aung>)], &sync       variantifetimes(,Beseri
    _dlse {ote((ignor _um(vari, eselthrough) =
) {ls = mahas_itrstenrrattrs.de_bolifeignor _um(vari re       _foeseri  &parse_quote!(_searseCesteds<'de>),);::new   } elseselthrough;

       _lizer: __D) -> #seOk(__t(fie::_foeseri _     )o);::new   }(und()ignor _um(vari),a  }
 eselthrough))     }
     ) {ls = matceywg/known_e  letowattrs.de_bo(cate }cate)     }
        }
    }lifeignor _um(vari re       _fignor ,);::new   } elseselthrough;

       _lizer: __D) -> #seOk(__t(fie::_fignor o);::new   }(und()ignor _um(vari),a  }
 eselthrough))     }),
    
    let body = Stnd so we _ithern::Tro         e     ,
        c, Som{ivate::Deesese,
        ;gnor _um(vari,     }
  eselthrough      im    ld Gd so wes `   __D: #ses, anput, Der` bodydialian efalsant. ld `lizer(e(fie_ams.cn::Tr)` nfe`lizer(
// bel_ams.cn::Tr)` , Soibute. ifetimes borrowcus   _ithern::Tro     erics ssnt.data.has, &syn
// bels,
  Vm(vari], &sync       variantifetimes(,Bnd: &   needs_dlse {   };
   / bel ={de_bouns = maithern::Trot.attrs.defa      Ithern::Tr: Vm(vari r   vari     }
        Ithern::Tr: t(fie r  esese,
              Ithern::Tr: No
:Enunl, chibl   (,  }
  edfetime(&p
);
        ce_bod.t);
     .}o_tLitew n , S :; se {ote(t);
        lce_bod.t);
      .}o_tLitew n , S :; lse {ote((ord   ry, eselthrough, eselthrough_delife =) =
) {
   und()last) relev belselastrrattrs.de_bolifelast_idedsria&last.ideds;    quoteifc
ast.      oeserip;
        quotero<Proceste`lizer(oeser)` , Soibute. I ;w`'deoalwayso tyfoue rm(rrre        quotero<
ast:
// belo(oont)e ein `oont)_ithern::Tr`),asodallfpr cedung        quotero<bre ord   ryelev belsed.de_lifetime elsord   rye

&lev bels[..lev belselenrra- 1]ed.de_lifetime elseselthrough;

       _lizer: __D) -> #seOk(#t);
      ::#last_idedse(ters::ont, &pa(ord   ry,   }
 eselthrough) }cate)         }
     ) {
   u,ylia New    
:c
ast.stylics #where_claus elsord   rye

&lev bels[..lev belselenrra- 1]ed.de_lifetime elseselthrough;

|     |ndTyParams<   }uote      

        quoterics yet_lizer: __D) -> #serde::_::            quoteuoteuotee {
_lizer:    __D: #ses, anput, Der                {
    lause {
_lizer: __D) -> #searseIthern::Tr   __D: #sers,
   (#le   )(_) => generi    ));
    ), }
      ne()));
 yet   q#t);
      ::#last_idedse              })
}(_) => generics,serializing(                {
ord   ry, #where_clauslausS }
 eselthrough(       _f     )o), #where_clauslausS }
 eselthrough(       _lizer: __D) -> #searseBelife =         quoteuoteuote_f     alizer<#delif));
))o), #where_claus)         }
     ta.all_fieeeee um(varian cate }cate)               u
     ta.all_fie um(varian cate }cate)      edfetime(&pds.
s_ams.c      <_>;

ord   ry         ariants
        .     
// belilattrs.default(         quote_) =lev bel       ds.
 )atc   && varids.
 ),        quote_) =lev bel.ideds.     ..,        quote_) =lev bel       & vasborrrivate::Default),
       param
       er().cledd.de_lifeds.
s reds.
s_ams.c efield iitrs_     &l      & vasbo)| & vasbo)edfetime(&pds.
s_c S n =
) {eselthroughserisnd()ti   }
    }cate     }
     ) {;
   / bel    }
    }typelev belsria quot!ndTyParams<   }# doc(hidthe),
        &sync S n VARIANTS  v message[r messages a]   a[<#(#ds.
s),* ]; }
       ;trs.de_bound()lev bels)     }
        }
    }lifee  let re quot!ndTyParams<   }# doc(hidthe),
        &sync S n FIELDS  v message[r messages a]   a[<#(#ds.
s),* ]; }
       ;trs.de_bound()e  let)      edfetime(&p&cont);
    let (deconResult<#remotpl_generics, _, ty_generics,elf) -> Sthere_clause) = split_wth_de_lifetime(&prams));
    let delife = params.borrowed.de_life     or_ed]
 ia
    let body = Stithern::Tro         st);
      i     }
  &ds.
s_ams.c rivate::De;
   / beli     }
  eselthrough      ams<eselthrough_delife ={ivate::Deesese,
        ls = maexp};
ungn       p:; 
.remrams)e),
  !ndTyParams<#ds.
s_c S n
TyParams<#[doc(hidthe),
        
      __t(fieV;

               impl #det #ty_generics #where_claus     //   &parse_quote!(_se        mar<#();
      ife> for #idrializer<#delif            &parse_quote!(_se        mar<&e::Dese ()>,{}
            }
   ed]
            impl #d_lizer: er: V;

   rde::Deseriali__t(fieV;

        fe> for #ident #ty_generics #where_claus     V      l#();
      ife> for #id),
            #     or_ed]
{}
            }
    els f ;

    =i__t(fieV;

    s #where_claus     //   &parse_quote!(_se        mar::<#();
      ife> for #idrializer<#delif            &parse_quote!(_se        marh(_) => ge}; }
      _          __D: #sers, anput, Derwithern::Tro  erialize<__Dif__v;

   o          ifetimes borrowithern::Tro     t);
      : &{Literal, S,B    :: Som,
  (rics, Ims.c  &BTreeSet<S aung>)], &syn;
   / belnebool,Blauseselthrough:&param(&{Literal, Sriaams<eselthrough_delife =:&param(&{Literal, Sriaams<  er().foeser_:: Som,
bool,Blausexp};
ung:&param(&ricsriand: &   needs_dlse {(),
ics_   pungf le     .field i     (_, ams.c  & vasbo)| ct TypeMacro<`& vasbo` ,lso`oestimesia mai pds.
  }
    }acked)(#(#& vasbo)|*a),
_lizer: __D) -> #seOk(#t);
      ::#idedse(
     p
 se {   }byt
s_   pungf le     .field i     (_, ams.c  & vasbo)| ct TypeMacro<`& vasbo` ,lso`oestimesia mai pds.
  }
    }   }l vasbof ll vasboalizer<#delifariants
            .     l vas| Lrianal::byt
_s aung l vas.as_byt
s()o);::new   }acked)(#(#& vasbo)|*a),
_lizer: __D) -> #seOk(#t);
      ::#idedse(
     p
  ont, &paexp};
ungf lexp};
ungErr(ctxtor() {;
   / bel    }
    }"  / bel ithern::Tr"     }
        }
    }"// At ithern::Tr"     }p
  ont, &pabyt
s_}o_s a =
) {eselthroughserisnd()ti||<  er().foeser_:: Somi   }
    }cate     }
     ttrs.de_bound()      ;
        quote els f       la_lizer: __D) -> #sef    utf8_lossy _f     ); }
       )     }      .e(&p&
uote_) =le   _a:_t r_oesteds,
uote_) =le   _a:_delife =_t r_oesteds,
uote_) =le   _a:_dyt
s_oesteds,
uote_) =le   _a:_delife =_dyt
s_oesteds,
uote) =
) {l er().foeser_:: Somi   }
    }(,serializing(und()rams);

        quote     els f       l  &parse_quote!(_searseCestedsa    ung   &parse_quote!(_seTo   ung::}o_s aung _f     )o;(_) => genericrrivate::Defaulund()rams);

        quote     els f       l  &parse_quote!(_searseCestedsa     _f     ); }
      nericrrivate::Defaulund()rams);

        quote     els f       l  &parse_quote!(_searseCestedsa Byt
Buf _f     .}o_vec()); }
      nericrrivate::Defaulund()rams);

        quote     els f       l  &parse_quote!(_searseCestedsa Byt
s _f     ); }
      nericrrivate::De)     }
        }
    }(cate }caten cate }cate)      edfetime(&peselthrough_arm_tLites;fetime(&peselthrough_arm =
) {
   und()eselthrough) =
&eselthrough    }
    }eselthrough(_) =}
     ) {;
   / bel    }
    }eselthrough_arm_tLites re quot!ndTyParams<   }_lizer: __D) -> #seEche_       deResult<iag/known_(|varian_t(|   ,dVARIANTS))          ;     }
  &eselthrough_arm_tLites     }
        }
    }eselthrough_arm_tLites re quot!ndTyParams<   }_lizer: __D) -> #seEche_       deResult<iag/known_e(fie(_t(|   ,dFIELDS))          ;     }
  &eselthrough_arm_tLites     }edd.de_life     foeser =
) {l er().foeser_:: Somi   }
    } quot!ndTyParams<   }, M      bool<__E dsife   f     : booltime__lizer: __D) -> #serde::__Sifent:       fESelf, __D::Err                where
 fE:
_       deResult<ializer<#delifs #where_clause {
_lizer: __D) -> #seOk(__t(fie::_foeseri  &parse_quote!(_searseCestedsa Bool _f     )o)
      #body
               , M      i8<__E dsife   f     : i8time__lizer: __D) -> #serde::__Sifent:       fESelf, __D::Err                where
 fE:
_       deResult<ializer<#delifs #where_clause {
_lizer: __D) -> #seOk(__t(fie::_foeseri  &parse_quote!(_searseCestedsa I8 _f     )o)
      #body
               , M      i16<__E dsife   f     : i16time__lizer: __D) -> #serde::__Sifent:       fESelf, __D::Err                where
 fE:
_       deResult<ializer<#delifs #where_clause {
_lizer: __D) -> #seOk(__t(fie::_foeseri  &parse_quote!(_searseCestedsa I16 _f     )o)
      #body
               , M      i32<__E dsife   f     : i32time__lizer: __D) -> #serde::__Sifent:       fESelf, __D::Err                where
 fE:
_       deResult<ializer<#delifs #where_clause {
_lizer: __D) -> #seOk(__t(fie::_foeseri  &parse_quote!(_searseCestedsa I32 _f     )o)
      #body
               , M      i64<__E dsife   f     : i64time__lizer: __D) -> #serde::__Sifent:       fESelf, __D::Err                where
 fE:
_       deResult<ializer<#delifs #where_clause {
_lizer: __D) -> #seOk(__t(fie::_foeseri  &parse_quote!(_searseCestedsa I64 _f     )o)
      #body
               , M      u8<__E dsife   f     : u8time__lizer: __D) -> #serde::__Sifent:       fESelf, __D::Err                where
 fE:
_       deResult<ializer<#delifs #where_clause {
_lizer: __D) -> #seOk(__t(fie::_foeseri  &parse_quote!(_searseCestedsa U8 _f     )o)
      #body
               , M      u16<__E dsife   f     : u16time__lizer: __D) -> #serde::__Sifent:       fESelf, __D::Err                where
 fE:
_       deResult<ializer<#delifs #where_clause {
_lizer: __D) -> #seOk(__t(fie::_foeseri  &parse_quote!(_searseCestedsa U16 _f     )o)
      #body
               , M      u32<__E dsife   f     : u32time__lizer: __D) -> #serde::__Sifent:       fESelf, __D::Err                where
 fE:
_       deResult<ializer<#delifs #where_clause {
_lizer: __D) -> #seOk(__t(fie::_foeseri  &parse_quote!(_searseCestedsa U32 _f     )o)
      #body
               , M      u64<__E dsife   f     : u64time__lizer: __D) -> #serde::__Sifent:       fESelf, __D::Err                where
 fE:
_       deResult<ializer<#delifs #where_clause {
_lizer: __D) -> #seOk(__t(fie::_foeseri  &parse_quote!(_searseCestedsa U64 _f     )o)
      #body
               , M      f32<__E dsife   f     : f32time__lizer: __D) -> #serde::__Sifent:       fESelf, __D::Err                where
 fE:
_       deResult<ializer<#delifs #where_clause {
_lizer: __D) -> #seOk(__t(fie::_foeseri  &parse_quote!(_searseCestedsa F32 _f     )o)
      #body
               , M      f64<__E dsife   f     : f64time__lizer: __D) -> #serde::__Sifent:       fESelf, __D::Err                where
 fE:
_       deResult<ializer<#delifs #where_clause {
_lizer: __D) -> #seOk(__t(fie::_foeseri  &parse_quote!(_searseCestedsa F64 _f     )o)
      #body
               , M      char<__E dsife   f     : chartime__lizer: __D) -> #serde::__Sifent:       fESelf, __D::Err                where
 fE:
_       deResult<ializer<#delifs #where_clause {
_lizer: __D) -> #seOk(__t(fie::_foeseri  &parse_quote!(_searseCestedsa Char _f     )o)
      #body
               , M      unit<__E dsifetime__lizer: __D) -> #serde::__Sifent:       fESelf, __D::Err                where
 fE:
_       deResult<ializer<#delifs #where_clause {
_lizer: __D) -> #seOk(__t(fie::_foeseri  &parse_quote!(_searseCestedsa Unit)o         _ =>  }
            u
        }
    }lifeu64_   pungf le     .field i falso wets.     (i{n(_, ams.c  Da)ilta.all_fieeeeetypei =
)h,

u64ed.de_lifeing(     !(#ia),
_lizer: __D) -> #seOk(#t);
      ::#idedse(
        }p
  ont,   }lifeu64_eselthrough_arm_tLites;fetim   }lifeu64_eselthrough_arm =
) {
   und()eselthrough) =
&eselthrough    }
    }   }eselthrough(_) =    }
     ta.all_fieeeeetypei_quo_exp};
ungf l) {;
   / bel  }"  / bel" }
     t}"// At"ics,serializing(lifeeselthrough_msgf leor le!("{}ei_quo 0 <=
)h<s!("sei_quo_exp};
ung,le     .lenrr); }
      neriu64_eselthrough_arm_tLites re quot!ndTyParams<   }   }_lizer: __D) -> #seEche_       deResult<iant   id_              quoteuoteuote_lizer: er: Unexp};
ed: Unsignee(_t(|   ), }
      ne()));
 yet&#eselthrough_msg,alizer<#delif));
))(_) => generics,serializing(&u64_eselthrough_arm_tLites          ;   }
    } quot!ndTyParams<   }, M      u64<__E dsife   f     : u64time__lizer: __D) -> #serde::__Sifent:       fESelf, __D::Err                where
 fE:
_       deResult<ializer<#delifs #where_clause {
  et v_n                      {
  {
#(#u64_   pung,)*
ult() {
lize })
ere
 s),
 u64_eselthrough_arm,
ult() {
lize })
}(_) => generic),
       
    }edd.de_life     fdelife = =
) {eselthroughfdelife =serisnd()ti||<  er().foeser_:: Somi   }
    }(),
ics_   pungf lics_   pung.     ..;fetim   }lifebyt
s_   pungf lbyt
s_   pung.     ..;fetim   }lifeeselthroughfdelife =_arm =
eselthroughfdelife =sas_refn Err(ctxtor(eselthrough_arm);trs.de_bound()      ;
        quote, M      bolife =_t r<__E dsife   f     : &'d `
  time__lizer: __D) -> #serde::__Sifent:       fESelf, __D::Err                where
 fE:
_       deResult<ializer<#delifs #where_clause {
  et v_n                      {
  {
#(#ics_   pung,)*
ult() {
lize })
ere
 s),
        None = }
    }    #le   _a:_delife =_t r_oesteds       None = }
    }    #eselthroughfdelife =_arm }
      ));
    _ =>}bound.clone()));
}
      #body
               , M      delife =_dyt
s<__E dsife   f     : &'d `[u8]time__lizer: __D) -> #serde::__Sifent:       fESelf, __D::Err                where
 fE:
_       deResult<ializer<#delifs #where_clause {
  et v_n                      {
  {
#(#byt
s_   pung,)*
ult() {
lize })
ere
 s),
        None = }
    }    #byt
s_}o_s a       None = }
    }    #le   _a:_delife =_dyt
s_oesteds       None = }
    }    #eselthroughfdelife =_arm }
      ));
    _ =>}bound.clone()));
}
      #body
  }
       )     }
        }
    }cate     }alized)rams)e),
  !ndTyParams<, Memb};
ungn&isit_ma_eor leeld.
erial_lizer: __D) -> #seFor leeldtime__lizer: __D) -> #sefmtserde::_.attrs.default(_lizer: __D) -> #seFor leeld};

it),   (a_eor leeld, #exp};
ungi
      #b 
TyParams<#     foeser

        , M      t r<__E dsife   f     : &
  time__lizer: __D) -> #serde::__Sifent:       fESelf, __D:                wh fE:
_       deResult<ializer<#ddTyParams<   } let v_n                      {
#(#ics_   pung,)*
ult() {
lize })
 s),
        None = }
    }#le   _a:_t r_oesteds
  None = }
    }    #eselthroughfarm }
      ));
    }(_) => generic),
       
TyParams<, M      dyt
s<__E dsife   f     : &[u8]time__lizer: __D) -> #serde::__Sifent:       fESelf, __D:                wh fE:
_       deResult<ializer<#ddTyParams<   } let v_n                      {
#(#byt
s_   pung,)*
ult() {
lize })
 s),
        None = }
    }#byt
s_}o_s a       None = }
    }#le   _a:_dyt
s_oesteds
  None = }
    }    #eselthroughfarm }
      ));
    }(_) => generic),
       
TyParams<#      delife =          ifetimes borrow         
     _| th: &{Literal, S,B    erics ssnt.data.has, &syn:: Som,
  t(fie], &sync       variantifetimes(,Bnd: &   needs_dlse {// Cl, te;rr}
fi At ds.
s ialiut `e     .d.de_lifee(fiesids.
      <_>;

               ariants
        . falso wets
        .     (i{ne(fiew| (f(fie,ae(fie_a(i)o)
      #b   er().cledd.de_ld   clbre , ch
fi At rric fillo tytimes borrod.d.de_lifelifn     s;

      ids.
          ariants
        .iter()  &&(f(fie,aDa|o!) {
        if !field.attrs.skipn&&o!) {
        itrstenrrs
        .     (f(fie,ads.
)|
        None =lifee(fie_ty;

) {
  tyters::_fieeeeerams);

        quote     elsrial#ds.
    &parse_quote!(_separam(&#e(fie_ty>  l  &parse_quote!(_seimes;       #body
  }
       )edd.de_ld C er().`oestedss ialiitrstenee  let in saa bufferd.de_lifelifn  er(). =
) {ls = mahas_itrstenrrattrs.de_bound()      ;
        quote elsfn v_t  er(). =
  &parse_quote!(_se   ::<_lizer: _quote!(_separam(&(TyParams<   }   }_lizer: __D) -> #searseCesteds,TyParams<   }   }_lizer: __D) -> #searseCestedsivate::Default>Shinew(); }
       )     }
        }
    }cate     }alized)ld Mlet varmic saextra). a=le   dialia
) {
       typele   _armic

      ids.
          ariants
        .iter()  &&(f(fie,aDa|o!) {
        if !field.attrs.skipn&&o!) {
        itrstenrrs
        .     (f(fie,ads.
)|
        None =lifeield._ds.
   ) {
        ds.
 )atc   && varids.
 )),
            life      ={de_bou) {
        tc   && variant.dendTyParams<yParams<cates),
        None =  None =lifee(fie_ty;

) {
  tyters::_fieeeee  None =life      l) {
          .    owed.de_lifetimelifetime elseuncs,ers::ont, &paing( &paing(     e::{quot!(::{q=> _       er: MapAccesttimext_     ::<#e(fie_ty>)ed.de_lifeing(   }uote      

        quoterics yet    #eunc  fn v_t lp)? }
      ));
    _ =>}bound.clone()));
}
      #body
}
  rnd()| th) r  Struct(_, _) =lifetime els((ctxpld, (ctxpld   ) re(ctxttc   && varie(fie_ant.derics {n) {
  ty,e| th);  }
    }ing(lifeing(     !(
        quoterics yet    #(ctxpld generics yet yetams<   } let v_       er: MapAccesttimext_     ::<#(ctxpld   >n fn v_t lp)
                {
    lause {
_lizer: __D) -> #seOk(__(ctxpld)s)>t__(ctxpld.     ,               {
    lause {
_lizer: __D) -> #seEche_t.ch)s)>t        None = }
    }    lause {
      t_lizer: __D) -> #seEche_t.ch); }
      ));
    _ => })
    }bound.clone()));
 yet   q                }
    }e              })
}(_) => generics,serializing( quot!ndTyParams<   }   }__t(fie::#ds.
  >t        None = }
    }) {_lizer: _quote!(_separam(::erisnd()&#ds.
)
                {
    laus      t_lizer: __D) -> #seEche< fAResult<h,

_       deResult<Shiduplins ewe(fie(#ield._ds.
)); }
      ));
    _ =>                }
    #ds.
  
_lizer: __D) -> #seund()#     ); }
      ));
    }       #body
  }
       )edd.de_ld V;

 ;;gnor d      s; sac`nsalsfut l
   }lifeignor d_arm =
) {ls = mahas_itrstenrrattrs.de_bound()      ;
        quote__t(fie::_foeseri _ds.
)
 >t        None = }
 _t  er()..push(_lizer: __D) -> #seund()         quoteuoteuote_fds.
h(_) => generiuoteuote_lizer: er: MapAccesttimext_       fn v_t lp)?)));
      #body
  }
       )     }
     ) {ls = matceywg/known_e  letowattrs.de_bocate     }
     ttrs.de_bound()      ;
        quote s),
   els ria_lizer: er: MapAccesttimext_     ::<_lizer: arseIgnor dAny>  fn v_t lp)?;
  }
       )     }edd.de_lifesel_if !pm/s le     .field isel       |n) {
        if !field.attrs.skipp
 se {   } let _keys =
) {ls = matceywg/known_e  letowa&&osel_if !pm/s   }
    } quot!ndTyParams<   }ro<FIXME:
Onc di, turinexhaus
uvrwpleeldns)a;
 stibl :        quotero<
   _lizer: __D) -> #secates,< ft(fie>ria_lizer: er: MapAccesttimext_key  fn v_t lp)?;::new   }    _lizer: _quote!(_separam(::            quoteuote_lizer: er: MapAccesttimext_keys,< ft(fie>  fn v_t lp)?h(_) => generiuote|__ed]ossibl |} let v_ned]ossibl  {})ed.de_life      u
        }
    } quot!ndTyParams<   }whil  
   _lizer: __D) -> #seund()_ key)ria_lizer: er: MapAccesttimext_keys,< ft(fie>  fn v_t lp)?fs #where_clause {
  et v_nkeyr
        quote   quote#(#le   _armi)*
ult() {
lize })
ere
#ignor d_arm
ult() {
lize })
}(_) => generic),
       
    }edd.de_lifeextra).n     s;

      ids.
          ariants
        .iter()  &&(f(fie,aDa|o!) {
        if !field.attrs.skipn&&o!) {
        itrstenrrs
        .     (f(fie,ads.
)|
        None =lifemisthisw use;

Mlet ( use_;
 misthis(f(fie,ac, Some(teers::_fieeeeerams);

        quote     els#ds.
  
  et v#ds.
                 {
    _lizer: __D) -> #seund()#ds.
)
 >t#ds.
h(_) => generiuoteuote_lizer: __D) -> #secates),
#misthisw use
ult() {
lize })
};       #body
  }
       )edd.de_lifeextra).n  er().m/s le     ids.
          ariants
        .iter()  &&(f(fie,aDa|o) {
        itrstenrrn&&o!) {
        if !field.attrs.skip:
        .     (f(fie,ads.
)|
        None =lifee(fie_ty;

) {
  tyters::_fieeeee elseuncs,(de_bou) {
        tc   && variant.dendTyParams<yParams<cates),
        None =  None =life      l) {
          .    owed.de_lifetimelifetime     e::{quot!(::{q=> _       er:    __D: #ses, anput, Der)bound.clone()));
}
      #body
}
  rnd()| th) r       !(#| th),(_) => generics,serializing( quot!ndTyParams<   }   } els#ds.
: #e(fie_ty;

#eunc alizer<#delif));
 yet_lizer: __D) -> #sed#seFtrsMap   __D: #ser                {
    laus&fn v_t  er().,       None = }
    }    _lizer: __D) -> #se        mar))?;::new   }      }
       )edd.de_life  er().m/_tceywg/known_e  let =
) {ls = mahas_itrstenrra&&lls = matceywg/known_e  letowattrs.de_bound()      ;
        quoteifc
   _lizer: __D) -> #seund()_lizer: __D) -> #seund() _nkey  Da))s,ers::ont, &paing(_t  er()..nt}o_field iiter() _lizer: _quote!(_separam(::erisnd().mextts
            dTyParams<   }   }ifc
   _lizer: __D) -> #seund()_ key)ria_ key.a:_t r()
                {
          t_lizer: __D) -> #seEche       None = }
    }    _lizer: deResult<iacus   (eor le_args!("g/known
fi At `{}`", &_ key))); }
      ));
    }
     ta.all_fieeeee  {
          t_lizer: __D) -> #seEche       None = }
    }    _lizer: deResult<iacus   (eor le_args!("g/exp};
ed  lp key"))); }
      ));
    }
      #body
  }
       )     }
        }
    }cate     }alized)
   rde::_. le     ids.
 .field i     (f(fie,ads.
)|
        Nolifemelb  n

&     .melb  ;    quoteifc) {
        if !field.attrs.skipndTyParams<    typele   .  ate:( use_;
 misthis(f(fie,ac, Some(ters::ont, &pa     !(#melb  : #le   )(_) => ge}
     ta.all_fieeeee     !(#melb  : #ds.
)alizer<#d}     }p
  ont, &palifndefa::_.  de_bouns = madefa::_ot.attrs.defa      Defa::_  Defa::_ r  und()               quote els fdefa::_: Sifent:      
_lizer: __D) -> #seDefa::_  defa::_otters::ont,o), #where_c      Defa::_  Pat.derth) r  und()               quote els fdefa::_: Sifent:      
#| thttters::ont,o), #where_c      Defa::_  cates),
        None =ro<We don't neediut `defa::_.(|   ,d saprevedsh,n unusm/   / bbl  warnung        quotero<we'lle eat dut `lmes lmpsyed.de_lifetimecate          
    }edd.de_lifefn vrde::_. l     !(#
     _| th
  #(#rde::_),* })ed.de_ifc   let has_g     n        Nolife
);
        &ce_bod.t);
     ;fetim   }life(_, pl_generics, _);
    let generics.there_for_ed]
((ters::ont,  e::_. l     !.attrs.default(_lizer: __D) -> #seIt}o::<#();
      ife> for #idriantto(#rde::_)          ;     }
     rams)e),
  !ndTyParams<#(#lifn     s)*

   }    #lifn  er().

   }    # let _keys

   }    #lifndefa::_   }
    }#n#extra).n     s)*

   }    #n#extra).n  er().m/)*

   }    #  er().m/_tceywg/known_e  let

   }    _lizer: __D) -> #seOk(#rde::_)          #[cfs(f, turi. l"times borrowin_place")] ifetimes borrow   win_place(B    erics ssnt.data.has, &syn:: Som,
  t(fie], &sync       variantifetimes(,Bnd: &   needs_dlse {asmest!(!ls = mahas_itrstenrr)edd.de_ld Cl, te;rr}
fi At ds.
s ialiut `e     .d.de_lifee(fiesids.
      <_>;

               ariants
        . falso wets
        .     (i{ne(fiew| (f(fie,ae(fie_a(i)o)
      #b   er().cledd.de_ld Falitimes borrowin_placedecoclbre booleans iali, ch
fi At rric fillo td.de_ld times borrod.d.de_lifelifnitrgs;

      ids.
          ariants
        .iter()  &&(f(fie,aDa|o!) {
        if !field.attrs.skips
        .     (_,ads.
)|
        None =rams);

        quote     elsrial#ds.
  bool =
esess;       #body
  }
       )edd.de_ld Mlet varmic saextra). a=le   dialia
) {
       typele   _armi_f   ;

      ids.
          ariants
        .iter()  &&(f(fie,aDa|o!) {
        if !field.attrs.skips
        .     (f(fie,ads.
)|
        None =lifeield._ds.
   ) {
        ds.
 )atc   && varids.
 )),   quote     elsrelb  n

&     .melb  ; 
            life      ={de_bou) {
        tc   && variant.dendTyParams<yParams<cates),
        None =  None =      

        quoterics yet    _lizer: er: MapAccesttimext_     _lied  fn v_t lpif  &parse_quote!(_searseInPlaceSied  fn vsife.place.#melb  ))? }
      ));
    _ =>}bound.clone()));
}
      #body
}
  rnd()| th) r  Struct(_, _) =lifetime els((ctxpld, (ctxpld   ) re(ctxttc   && varie(fie_ant.derics {n) {
  ty,e| th);  }
    }ing(lifeing(     !(
        quoterics yet    #(ctxpld generics yet yetams<    
ife.place.#melb   ={de_bou_       er: MapAccesttimext_     ::<#(ctxpld   >n fn v_t lp)
                {
    lause {
_lizer: __D) -> #seOk(__(ctxpld)s)>t__(ctxpld.     ,               {
    lause {
_lizer: __D) -> #seEche_t.ch)s)>t        None = }
    }    lause {
      t_lizer: __D) -> #seEche_t.ch); }
      ));
    _ => })
    }bound.clone()));
 yet   q ;               }
    }e              })
}(_) => generics,serializing( quot!ndTyParams<   }   }__t(fie::#ds.
  >t        None = }
    }) {#ds.
                 {
    laus      t_lizer: __D) -> #seEche< fAResult<h,

_       deResult<Shiduplins ewe(fie(#ield._ds.
)); }
      ));
    _ =>                }
    #     ;               }
    #ds.
  
 var; }
      ));
    }       #body
  }
       )edd.de_ld V;

 ;;gnor d      s; sac`nsalsfut l
   }lifeignor d_arm =
) {ls = matceywg/known_e  letowattrs.de_bocate     }
     ttrs.de_bound()      ;
        quote s),
   els ria_lizer: er: MapAccesttimext_     ::<_lizer: arseIgnor dAny>  fn v_t lp)?;
  }
       )     }edd.de_lifesel_if !pm/s le     .field isel       |n) {
        if !field.attrs.skipp
  se {   } let _keys =
) {ls = matceywg/known_e  letowa&&osel_if !pm/s   }
    } quot!ndTyParams<   }ro<FIXME:
Onc di, turinexhaus
uvrwpleeldns)a;
 stibl :        quotero<
   _lizer: __D) -> #secates,< ft(fie>ria_lizer: er: MapAccesttimext_key  fn v_t lp)?;::new   }    _lizer: _quote!(_separam(::            quoteuote_lizer: er: MapAccesttimext_keys,< ft(fie>  fn v_t lp)?h(_) => generiuote|__ed]ossibl |} let v_ned]ossibl  {})ed.de_life      u
        }
    } quot!ndTyParams<   }whil  
   _lizer: __D) -> #seund()_ key)ria_lizer: er: MapAccesttimext_keys,< ft(fie>  fn v_t lp)?fs #where_clause {
  et v_nkeyr
        quote   quote#(#le   _armi_f   )*
ult() {
lize })
ere
#ignor d_arm
ult() {
lize })
}(_) => generic),
       
    }edd.de_lifeoont)_itrgs;

      ids.
          ariants
        .iter()  &&(f(fie,aDa|o!) {
        if !field.attrs.skips
        .     (f(fie,ads.
)|
        None =lifemisthisw use;

 use_;
 misthis(f(fie,ac, Some;        quotero<Ifemisthisw use;unc`ndiram(selys      sian eult<i don't try         uotero< saassignrits le   d sa
ife.place.        quoteifc) {
        tcfa::_otserin   ..
ult() {
lize })
&&lls = matcfa::_otserin   ..
ult() {
lize })
&&l) {
        tc   && variant.deserisnd()t
            dTyParams<   }   }lifemisthisw use;


    lmisthisw use(ters::ont, &paing(      t        None = }
    }) {!#ds.
                 {
    laus#misthisw use; }
      ));
    _ =>}bound.clone()));
}
      #body
 
     ta.all_fieeeee  {
lifemelb  n

&     .melb  ;    quote   }   }lifemisthisw use;

ate:(misthisw use(ters::ont, &paing(      t        None = }
    }) {!#ds.
                 {
    laus
ife.place.#melb   ={#misthisw use; }
      ));
    _ =>}; }
      ));
    }       #body
  }
       )edd.de_life
);
        &ce_bod.t);
     ;fetimlife(_, _, pl_generics, _);
 there_clause) = split_wth_de_lif ont, &palifndefa::_.  de_bouns = madefa::_ot.attrs.defa      Defa::_  Defa::_ r  und()               quote els fdefa::_: #();
      ife> for #id  
_lizer: __D) -> #seDefa::_  defa::_otters::ont,o), #where_c      Defa::_  Pat.derth) r  und()               quote els fdefa::_: #();
      ife> for #id  
#| thttters::ont,o), #where_c      Defa::_  cates),
        None =ro<We don't neediut `defa::_.(|   ,d saprevedsh,n unusm/   / bbl  warnung        quotero<we'lle eat dut `lmes lmpsyed.de_lifetimecate          
    }edd.de_rams)e),
  !ndTyParams<#(#lifnitrgs)*

   }    # let _keys

   }    #lifndefa::_   }
    }#n#oont)_itrgs)*

   }    _lizer: __D) -> #seOk(ip:          ifee(fie_a(i: usDer)d: &Ims.cndTyParIms.chinew(&eor le!("__e  le!("sei),a pa(::csel_iiwets)of l/ld T);
seuncram(r(ctxsdut ` useestam(rin `#[lizer(tc   && variant.. l"...")]`l/ld in a tra
 ; saprevedsh
 ;f   ;accestungfut `in};
use `   __D: #se` messe. ife(ctxttc   && variant.d     erics ssnt.data.has, &syn
/   _ty: &{Literal, S,B    tc   && variant.neriyna ate:Pat.,Bnd: &({Literal, S, {Literal, S)_dlse {(),
t);
        &ce_bod.t);
     ;fetimlife(cont);
    let (deconResult<#remotpl_generics, _, ty_generics,elf) -> Sthere_clause) = split_wth_de_lifetime(&prams));
    let delife = params.borrowedfetime(&p(ctxpld. l     !.attrs.defa#[doc(hidthe),
        
      __   __D: #seWnt..           impl #det #ty_generics #where_claus     : #
/   _ty 
   quote_) =e      /   &parse_quote!(_se        mar<#();
      ife> for #idrializer<#delif            &parse_quote!(_se        mar<&e::Dese ()>,{}
            }
   ed]
            impl #d_lizer:    __D: #serde::Deseriali__   __D: #seWnt..    fe> for #ident #ty_generics #where_claus, M
        le  fn d ferialize<__D>(__deseri_lizer: __D) -> #serde::__Sife   f:Result<Self, __D::Err                where
 f   _          __D: #serdde::Deseializer<#delifs #where_clause {
_lizer: __D) -> #seOk(__   __D: #seWnt..                {
         : #tc   && variant.d ferialize<__D)?h(_) => generiuote_) =e      /   &parse_quote!(_se        marh(_) => generiuote_) =            &parse_quote!(_se        marh(_) => ge  }
    }e             c),
       
    }edd.de_life(ctxpld    re       _f   __D: #seWnt..    fe> for #idwedfetim((ctxpld, (ctxpld   )    ife(ctxttc   && varie(fie_ant.dB    erics ssnt.data.has, &syn:: So_ty: &iyna T   ,B    tc   && variant.neriyna ate:Pat.,Bnd: &({Literal, S, {Literal, S)_dlse {(ctxttc   && variant.derics {n&     !(#:: So_ty), tc   && variant.)    ife(ctxttc   && vari
// bel_ant.d     erics ssnt.data.has, &syn
// belne&V / beli     tc   && variant.neriyna ate:Pat.,Bnd: &({Literal, S, {Literal, S, {Literal, S)_dlse {(),
:: So_tys relev bel.e     .field i          |n) {
  ty);fetimlife((ctxpld, (ctxpld   ) relf, __D: ctxttc   && variant.derics {n&     !((#(#:: So_tys),*)), tc   && variant.)edd.de_liferr(ctxtf   lrr(ctxt}o_v// bel_closurinerics {num(vari,  varwedfetim((ctxpld, (ctxpld   ,err(ctxtf m    ld Gd so wes closuri rric c`nverts tungl `input ericsa.ha; saut `e use      . iferr(ctxt}o_v// bel_closurin     erics ssnt.data.has, &syn
// belne&V / beli     claus(ctxpld,
bool,Bnd: &{Literal, S_dlse {(),
t);
        lace_bod.t);
      ed.de_life
// bel_ams.ce

&lev bel.ideds; fetimlife(arg, (ctxpld) =
) {claus(ctxpld    }
    }(     !.at__(ctx },      !.at__(ctx.       )     }
        }
    }(),
:: So_tys relev bel.e     .field i          |n) {
  ty);fetim   }(     !.at__(ctx: (#(#:: So_tys),*) },      !.at__(ctx  )     }edd.de_life:: So_accest re(0..lev bel.e     .lenrr)i     n|
        NoMelb  ::Unds.
d(I_quo 
        quotei_quo: nh,

u32h(_) => ge  }
::{q:a pa(::csel_iiwets, }
       )     }wedfetimde_boulev bel.stylics #where_cu,ylia S      ) {lev bel.e     .lenrr == 1s),
        None =lifemelb  n

&lev bel.e     [0].melb  ;    quote   }      t        None = }
 |#arg|d#t);
      ::#
// bel_ams.c
  #melb  : #(ctxpld }         _ =>  }
            }
  r,ylia S      ),
        None =lifemelb  s relev bel.e     .field i          |n&     .melb  );    quote   }      t        None = }
 |#arg|d#t);
      ::#
// bel_ams.c
  #(#melb  s: #(ctxpld.#:: So_accest),* }         _ =>  }
            }
  r,ylia Tuple r       !t        None =|#arg|d#t);
      ::#
// bel_ams.c(#(#(ctxpld.#:: So_accest),*)          ,     }
  r,ylia New    
:       !t        None =|#arg|d#t);
      ::#
// bel_ams.c(#(ctxpld)          ,     }
  r,ylia Unit
:       !t        None =|#arg|d#t);
      ::#
// bel_ams.c          ,          ife use_;
 misthis(f(fiene&F(fie,ac, Som  variantifetimes(nd: &   needs_dlse {de_bou) {
        tcfa::_ot.attrs.defa      Defa::_  Defa::_ r          None =life      l) {
          .    owed.de_lifetime elseuncs,(     e::{quot!(::{q=> _       __D) -> #seDefa::_  defa::_wed.de_lifetime      t     e use!(#:unc ))ed.de_life      re_c      Defa::_  Pat.derth) r  {d.de_lifetime      t     e use!(#| thtt)ed.de_life      re_c      Defa::_  cates),
  /* below */       uolse {de_bou*ns = madefa::_ot.attrs.defa      Defa::_  Defa::_ |c      Defa::_  Pat.d_)s),
        None =lifemelb  n

&     .melb  ;    quote   }      t     e use!( fdefa::_.#melb  )ed.de_life      re_c      Defa::_  cates),
  /* below */       uolse {e(&pds.
   ) {
        ds.
 )atc   && varids.
 )),   qde_bou) {
        tc   && variant.dendTyParams<cates),
        None =life      l) {
          .    owed.de_lifetime elseuncs,(     e::{quot!(::{q=> _       __D) -> #se    misthiswe(fiew;    quote   }     e use!                 {
#:unc #ds.
)?         _ =>  }
            }
  rnd()_)s),
        None =     e use!                 {
      t_lizer: __D) -> #seEche< fAResult<h,

_       deResult<Shimisthiswe(fie #ds.
)o         _ =>  }
            uof life use_;
 misthis_  q(lse {asmignt}o:&param(&{Literal, Sriaams<i_quo: usDer, &syn:: Sone&F(fie, &sync       variantifetimes(,B&synexp};
ung:&rics,Bnd: &{Literal, S_dlse {de_bou) {
        tcfa::_ot.attrs.defa      Defa::_  Defa::_ r          None =life      l) {
          .    owed.de_lifetime      t     e::{quot!(::{q=> #asmignt}o
_lizer: __D) -> #seDefa::_  defa::_ot)ed.de_life      re_c      Defa::_  Pat.derth) r  {d.de_lifetime      t     e::{quot!(erth.    ow=> #asmignt}o
#| thtt)ed.de_life      re_c      Defa::_  cates),
  /* below */       uolse {de_bou*ns = madefa::_ot.attrs.defa      Defa::_  Defa::_ |c      Defa::_  Pat.d_)s),
        None =lifemelb  n

&     .melb  ;    quote   }     !(#asmignt}o
_fdefa::_.#melb  )d.de_life      re_c      Defa::_  cates),
               quote      t_lizer: __D) -> #seEche_       deResult<iant   id_lengt.d#i_quo{n&#exp};
ungi)d.de_life),          ife ff};
uv),  yli(
// belne&V / belnd: &Stylics #whede_boulev bel.stylics #where_cu,ylia New    
) {lev bel.e     [0].      if !field.attrs.skipn=> r,ylia Unit,     }
  oeser => oeser,          
      DeImplGfor #id<'a>(&'a t.data.has)ed#[cfs(f, turi. l"times borrowin_place")] 
      InPlaceImplGfor #id<'a>(&'a t.data.has)ed
    <'a>&{LTLites ialiDeImplGfor #id<'a>cs #wheife}o_tLitesn&isit_mtLites.
erial{Literal, S)_dlse {     elsrial for #id  

ife.0 generics.     ..;fetim   }) {
   und()params.borr)  

ife.0 delife = params.borr_ce_bodendTyParams<yPargenerics.ce_bod;


nd()iyna Gfor #it.dat::Lms.borroparams.borr).
ult() {
lize })
.nt}o_field 
ult() {
lize })
.chime(generics.ce_bod 
ult() {
lize })
.c er().cled.de_life      re_clife(t);
    let (de_, _);
 generics.there_for_ed]
((ters::ont,t);
    let (.}o_tLitesntLites);          #[cfs(f, turi. l"times borrowin_place")]     <'a>&{LTLites ialiInPlaceImplGfor #id<'a>cs #wheife}o_tLitesn&isit_mtLites.
erial{Literal, S)_dlse {     elsplacerams.borr;
  lacerams.borr..;fetim   }liferial for #id  

ife.0 generics.     ..;ft TypeMacro<Add=         iali`&' laceerialSife  and `'a: ' lace`TyParams<,alice_bo in &rial for #id.ce_bod;dTyParams<   } let vce_bo                 {
iyna Gfor #it.dat::Lms.borroce_bo)s)>t        None = }
    }ce_bo deun  .push( lacerams.borr.ams.borr.     ..); }
      ));
    }
      #body
  {
iyna Gfor #it.dat::T   oce_bo)s)>t        None = }
    }ce_bo deun  .push(iyna T   t.datBeun ::Lms.borro               {
    laus lacerams.borr.ams.borr.     ..h(_) => generiuote_) =.); }
      ));
    }
      #body
  {
iyna Gfor #it.dat::C S nd_)s),
 }         _ =>  }
            }
  generics.ce_bod;


nd()iyna Gfor #it.dat::Lms.borro lacerams.borr).
ult() {
lize.nt}o_field 
ult() {
lize.chime(generics.ce_bod 
ult() {
lize.c er().cled.de_life) {
   und()params.borr)  

ife.0 delife = params.borr_ce_bodendTyParams<yPargenerics.ce_bod;


nd()iyna Gfor #it.dat::Lms.borroparams.borr).
ult() {
lize })
.nt}o_field 
ult() {
lize })
.chime(generics.ce_bod 
ult() {
lize })
.c er().cled.de_life      re_clife(t);
    let (de_, _);
 generics.there_for_ed]
((ters::ont,t);
    let (.}o_tLitesntLites);          #[cfs(f, turi. l"times borrowin_place")]     <'a>&DeImplGfor #id<'a>cs #wheifein_place(sifetime_InPlaceImplGfor #id<'a>cs #wheyParInPlaceImplGfor #id(
ife.0)          
      DeT   Gfor #id<'a>(&'a t.data.has)ed#[cfs(f, turi. l"times borrowin_place")] 
      InPlaceT   Gfor #id<'a>(&'a t.data.has)ed ifeti         let (_}o_tLitesn #whedial for #id:
iyna Gfor #is, &syndelife =:&&Belife =Lms.borrs, &syntLites.
erial{Literal, S,Bnd{d.de_ifcdelife = params.borr_ce_bodeserisnd()tidlse {     elsdef  

yna Lms.borrPe_bo                         ::new()ializer<#delif          
yna Lms.borr::new("'de",a pa(::csel_iiwets),
        &sync    _tLite: cate 
        &syndeun  : Puncrua
ed: new()ializer<#d}; }
      ro<Prepend 'd `         }o
list ofl for #id
ams<yPargenerics.ce_bod;


nd()iyna Gfor #it.dat::Lms.borropaf).
ult() {
lize.nt}o_field 
ult() {
lize.chime(generics.ce_bod 
ult() {
lize.c er().cled.de_}
   }life(_, pl_generics, _);
 generics.there_for_ed]
((ters::pl_generics.}o_tLitesntLites); }d
    <'a>&{LTLites ialiDeT   Gfor #id<'a>cs #wheife}o_tLitesn&isit_mtLites.
erial{Literal, S)_dlse {    ti         let (_}o_tLitesn
ife.0 generics.     ..{n&
ife.0 delife =_mtLites);          #[cfs(f, turi. l"times borrowin_place")]     <'a>&{LTLites ialiInPlaceT   Gfor #id<'a>cs #wheife}o_tLitesn&isit_mtLites.
erial{Literal, S)_dlse {     elsrial for #id  

ife.0 generics.     ..;fetim   }generics.ce_bod;


nd()iyna Gfor #it.dat::Lms.borro lacerams.borr()).
ult() {
lize.nt}o_field 
ult() {
lize.chime(generics.ce_bod 
ult() {
lize.c er().cledlse {    ti         let (_}o_tLitesngenerics, &
ife.0 delife =_mtLites);          #[cfs(f, turi. l"times borrowin_place")]     <'a>&DeT   Gfor #id<'a>cs #wheifein_place(sifetime_InPlaceT   Gfor #id<'a>cs #wheyParInPlaceT   Gfor #id(
ife.0)          #[cfs(f, turi. l"times borrowin_place")] ife lacerams.borr()ime_
yna Lms.borrPe_bo       
yna Lms.borrPe_bo                     ::new()ializer<#d          
yna Lms.borr::new("'place",a pa(::csel_iiwets),
        c    _tLite: cate 
        deun  : Puncrua
ed: new()ialize     ifethere_clause) = split_w     erics ssnt.data.has, nd: &(     DeImplGfor #id,     DeT   Gfor #id,     
yna T   Gfor #id,     param(&riyna W    Ceneri>,Bnd{d.de_ elsde        impl #d= DeImplGfor #idwth_de_lifetime(&pra_fe> for #id  
DeT   Gfor #idwth_de_lifetime(&p(_, pl_generics, _, ty_generics,    let generics.there_for_ed]
((ters::(cont);
    let (deconResult<#remotpl_generics, _, ty_generic                   