//! A build dependency for Cargo libraries to find system artifacts through the
//! `pkg-config` utility.
//!
//! This library will shell out to `pkg-config` as part of build scripts and
//! probe the system to determine how to link to a specified library. The
//! `Config` structure serves as a method of configuring how `pkg-config` is
//! invoked in a builder style.
//!
//! A number of environment variables are available to globally configure how
//! this crate will invoke `pkg-config`:
//!
//! * `FOO_NO_PKG_CONFIG` - if set, this will disable running `pkg-config` when
//!   probing for the library named `foo`.
//!
//! * `PKG_CONFIG_ALLOW_CROSS` - The `pkg-config` command usually doesn't
//!   support cross-compilation, and this crate prevents it from selecting
//!   incompatible versions of libraries.
//!   Setting `PKG_CONFIG_ALLOW_CROSS=1` disables this protection, which is
//!   likely to cause linking errors, unless `pkg-config` has been configured
//!   to use appropriate sysroot and search paths for the target platform.
//!
//! There are also a number of environment variables which can configure how a
//! library is linked to (dynamically vs statically). These variables control
//! whether the `--static` flag is passed. Note that this behavior can be
//! overridden by configuring explicitly on `Config`. The variables are checked
//! in the following order:
//!
//! * `FOO_STATIC` - pass `--static` for the library `foo`
//! * `FOO_DYNAMIC` - do not pass `--static` for the library `foo`
//! * `PKG_CONFIG_ALL_STATIC` - pass `--static` for all libraries
//! * `PKG_CONFIG_ALL_DYNAMIC` - do not pass `--static` for all libraries
//!
//! After running `pkg-config` all appropriate Cargo metadata will be printed on
//! stdout if the search was successful.
//!
//! # Example
//!
//! Find the system library named `foo`, with minimum version 1.2.3:
//!
//! ```no_run
//! fn main() {
//!     pkg_config::Config::new().atleast_version("1.2.3").probe("foo").unwrap();
//! }
//! ```
//!
//! Find the system library named `foo`, with no version requirement (not
//! recommended):
//!
//! ```no_run
//! fn main() {
//!     pkg_config::probe_library("foo").unwrap();
//! }
//! ```
//!
//! Configure how library `foo` is linked to.
//!
//! ```no_run
//! fn main() {
//!     pkg_config::Config::new().atleast_version("1.2.3").statik(true).probe("foo").unwrap();
//! }
//! ```

#![doc(html_root_url = "https://docs.rs/pkg-config/0.3")]

use std::collections::HashMap;
use std::env;
use std::error;
use std::ffi::{OsStr, OsString};
use std::fmt;
use std::io;
use std::ops::{Bound, RangeBounds};
use std::path::PathBuf;
use std::process::{Command, Output};
use std::str;

#[derive(Clone, Debug)]
pub struct Config {
    statik: Option<bool>,
    min_version: Bound<String>,
    max_version: Bound<String>,
    extra_args: Vec<OsString>,
    cargo_metadata: bool,
    env_metadata: bool,
    print_system_libs: bool,
    print_system_cflags: bool,
}

#[derive(Clone, Debug)]
pub struct Library {
    /// Libraries specified by -l
    pub libs: Vec<String>,
    /// Library search paths specified by -L
    pub link_paths: Vec<PathBuf>,
    /// Library file paths specified without -l
    pub link_files: Vec<PathBuf>,
    /// Darwin frameworks specified by -framework
    pub frameworks: Vec<String>,
    /// Darwin framework search paths specified by -F
    pub framework_paths: Vec<PathBuf>,
    /// C/C++ header include paths specified by -I
    pub include_paths: Vec<PathBuf>,
    /// Linker options specified by -Wl
    pub ld_args: Vec<Vec<String>>,
    /// C/C++ definitions specified by -D
    pub defines: HashMap<String, Option<String>>,
    /// Version specified by .pc file's Version field
    pub version: String,
    /// Ensure that this struct can only be created via its private `[Library::new]` constructor.
    /// Users of this crate can only access the struct via `[Config::probe]`.
    _priv: (),
}

/// Represents all reasons `pkg-config` might not succeed or be run at all.
pub enum Error {
    /// Aborted because of `*_NO_PKG_CONFIG` environment variable.
    ///
    /// Contains the name of the responsible environment variable.
    EnvNoPkgConfig(String),

    /// Detected cross compilation without a custom sysroot.
    ///
    /// Ignore the error with `PKG_CONFIG_ALLOW_CROSS=1`,
    /// which may let `pkg-config` select libraries
    /// for the host's architecture instead of the target's.
    CrossCompilation,

    /// Failed to run `pkg-config`.
    ///
    /// Contains the command and the cause.
    Command { command: String, cause: io::Error },

    /// `pkg-config` did not exit sucessfully after probing a library.
    ///
    /// Contains the command and output.
    Failure { command: String, output: Output },

    /// `pkg-config` did not exit sucessfully on the first attempt to probe a library.
    ///
    /// Contains the command and output.
    ProbeFailure {
        name: String,
        command: String,
        output: Output,
    },

    #[doc(hidden)]
    // please don't match on this, we're likely to add more variants over time
    __Nonexhaustive,
}

impl error::Error for Error {}

impl fmt::Debug for Error {
    fn fmt(&self, f: &mut fmt::Formatter) -> Result<(), fmt::Error> {
        // Failed `unwrap()` prints Debug representation, but the default debug format lacks helpful instructions for the end users
        <Error as fmt::Display>::fmt(self, f)
    }
}

impl fmt::Display for Error {
    fn fmt(&self, f: &mut fmt::Formatter) -> Result<(), fmt::Error> {
        match *self {
            Error::EnvNoPkgConfig(ref name) => write!(f, "Aborted because {} is set", name),
            Error::CrossCompilation => f.write_str(
                "pkg-config has not been configured to support cross-compilation.\n\
                \n\
                Install a sysroot for the target platform and configure it via\n\
                PKG_CONFIG_SYSROOT_DIR and PKG_CONFIG_PATH, or install a\n\
                cross-compiling wrapper for pkg-config and set it via\n\
                PKG_CONFIG environment variable.",
            ),
            Error::Command {
                ref command,
                ref cause,
            } => {
                match cause.kind() {
                    io::ErrorKind::NotFound => {
                        let crate_name =
                            std::env::var("CARGO_PKG_NAME").unwrap_or_else(|_| "sys".to_owned());
                        let instructions = if cfg!(target_os = "macos") || cfg!(target_os = "ios") {
                            "Try `brew install pkg-config` if you have Homebrew.\n"
                        } else if cfg!(unix) {
                            "Try `apt install pkg-config`, or `yum install pkg-config`,\n\
                            or `pkg install pkg-config`, or `apk add pkgconfig` \
                            depending on your distribution.\n"
                        } else {
                            "" // There's no easy fix for Windows users
                        };
                        write!(f, "Could not run `{command}`\n\
                        The pkg-config command could not be found.\n\
                        \n\
                        Most likely, you need to install a pkg-config package for your OS.\n\
                        {instructions}\
                        \n\
                        If you've already installed it, ensure the pkg-config command is one of the\n\
                        directories in the PATH environment variable.\n\
                        \n\
                        If you did not expect this build to link to a pre-installed system library,\n\
                        then check documentation of the {crate_name} crate for an option to\n\
                        build the library from source, or disable features or dependencies\n\
                        that require pkg-config.", command = command, instructions = instructions, crate_name = crate_name)
                    }
                    _ => write!(f, "Failed to run command `{}`, because: {}", command, cause),
                }
            }
            Error::ProbeFailure {
                ref name,
                ref command,
                ref output,
            } => {
                write!(
                    f,
                    "`{}` did not exit successfully: {}\nerror: could not find system library '{}' required by the '{}' crate\n",
                    command, output.status, name, env::var("CARGO_PKG_NAME").unwrap_or_default(),
                )?;
                format_output(output, f)
            }
            Error::Failure {
                ref command,
                ref output,
            } => {
                write!(
                    f,
                    "`{}` did not exit successfully: {}",
                    command, output.status
                )?;
                format_output(output, f)
            }
            Error::__Nonexhaustive => panic!(),
        }
    }
}

fn format_output(output: &Output, f: &mut fmt::Formatter) -> fmt::Result {
    let stdout = String::from_utf8_lossy(&output.stdout);
    if !stdout.is_empty() {
        write!(f, "\n--- stdout\n{}", stdout)?;
    }
    let stderr = String::from_utf8_lossy(&output.stderr);
    if !stderr.is_empty() {
        write!(f, "\n--- stderr\n{}", stderr)?;
    }
    Ok(())
}

/// Deprecated in favor of the probe_library function
#[doc(hidden)]
pub fn find_library(name: &str) -> Result<Library, String> {
    probe_library(name).map_err(|e| e.to_string())
}

/// Simple shortcut for using all default options for finding a library.
pub fn probe_library(name: &str) -> Result<Library, Error> {
    Config::new().probe(name)
}

#[doc(hidden)]
#[deprecated(note = "use config.target_supported() instance method instead")]
pub fn target_supported() -> bool {
    Config::new().target_supported()
}

/// Run `pkg-config` to get the value of a variable from a package using
/// `--variable`.
///
/// The content of `PKG_CONFIG_SYSROOT_DIR` is not injected in paths that are
/// returned by `pkg-config --variable`, which makes them unsuitable to use
/// during cross-compilation unless specifically designed to be used
/// at that time.
pub fn get_variable(package: &str, variable: &str) -> Result<String, Error> {
    let arg = format!("--variable={}", variable);
    let cfg = Config::new();
    let out = cfg.run(package, &[&arg])?;
    Ok(str::from_utf8(&out).unwrap().trim_end().to_owned())
}

impl Config {
    /// Creates a new set of configuration options which are all initially set
    /// to "blank".
    pub fn new() -> Config {
        Config {
            statik: None,
            min_version: Bound::Unbounded,
            max_version: Bound::Unbounded,
            extra_args: vec![],
            print_system_cflags: true,
            print_system_libs: true,
            cargo_metadata: true,
            env_metadata: true,
        }
    }

    /// Indicate whether the `--static` flag should be passed.
    ///
    /// This will override the inference from environment variables described in
    /// the crate documentation.
    pub fn statik(&mut self, statik: bool) -> &mut Config {
        self.statik = Some(statik);
        self
    }

    /// Indicate that the library must be at least version `vers`.
    pub fn atleast_version(&mut self, vers: &str) -> &mut Config {
        self.min_version = Bound::Included(vers.to_string());
        self.max_version = Bound::Unbounded;
        self
    }

    /// Indicate that the library must be equal to version `vers`.
    pub fn exactly_version(&mut self, vers: &str) -> &mut Config {
        self.min_version = Bound::Included(vers.to_string());
        self.max_version = Bound::Included(vers.to_string());
        self
    }

    /// Indicate that the library'srs.to_strno           print_system_cflags: tt   pubsion(&mut self  pubd(vers.t<'a, R>> &mut Confi  pub: R  self.min_versi
arty noti/// IndicR:ath::PathBuf<&'abe]`ied by n = Bound::Included(vers.to_s        pub    rt_ }

 io::ErrorKind::Notring());
        seecaustring());
        self
    }

   ,ErrorKind::Notring()Ex
        seecaustring()Ex
        self
    }

   ,ErrorKind::Notring()   }

   caustring()tra_args: vec![],
 }n = Bound::Included(vers.to_s        pub  Co_ }

 io::ErrorKind::Notring());
        seecaustring());
        self
    }

   ,ErrorKind::Notring()Ex
        seecaustring()Ex
        self
    }

   ,ErrorKind::Notring()   }

   caustring()tra_args: vec![],
 }n = Bound::Incthat the libraryAddE texrgus and
  eck, bocommand, inshe error with `PKGof ttifying    // to s contairgus ansive Works, if an to `pkg-cion(&mut self,rg<S: AsRefadata:>>> &mut Confi,rg: S  self.min_version = Bound::Incl       pri.push( pr.as_ =>nfig {
s    }

    /// Indicate that the library" shaflag shoulon
//! st appropriathe Work
         used ncludtlectronbraryauthe
 controsystem houlinucturDg a li, boc`  //sion(&mut self         env_m> &mut Confi env_metadata: bool,  self.min_version = Bound::Incl env_metadata:g])?env_metadata: /// Indicate that the library" shaflag shoulon
//! st appropriathe Work
         used ncluectronbraryauthe
 controsreurce, e liscribed in
    /// the   (c) urDg a li, bo not exit   //sion(&mut self   }
    }

> &mut Confirint_system_libs:   self.min_version = Bound::Incl int_system_g]) int_system_ /// Indicate that the libraryEn descpendencies\d be ,
    /// which mtedTEM_SYSS   ///
    //e library Contains the name of the feren //y Co ren /tain, if ng a liion(&mut self            cargo> &mut Confi     libs:   self.min_version = Bound::Incl            cargog])      /// Indicate that the libraryEn descpendencies\d be ,
    /// which mtedTEM_CFLAGS   ///
    //e library Contains the name of the feren //y Co ren /tain, if ng a liion(&mut self            c print> &mut Confi     libs:   self.min_version = Bound::Incl            c printg])      /// Indicate that the librarye probe_library funcfs:

Th`en)]
`pub fn fin please don't match on  &str) -> Ratter) -rary, String> {
    probe_library(name).map_eund::Incl  )]
#[depr))
}

/// Simple shortcut fohat the libraryhe value of a variabfmed `fooo.
//!
//[dep`ll override the inference frnd selt-scoped environg
//i
   deons ion.e useyinvoknot exit sucessfully ren   ion(&mut self  )]
#tter) -rary, String> {
    probe_libraelf {
           able=, navari        variable){}nt variable.
 "firinsey#[depr  /// Indic runnncl intari ot> =, navari     )te!(s
   o::ErrorKind::No-variaaelf( name) => write!(f, "A=, navari     )  /// Indic          !nnncll {
    Config::new:ErrorKind::No-variaaelf( name) te_str(
          /// Indic 
         ablemutoo.
//!
/= r.
    /// U(pac         abletderr./= ate that             O_NAME"&["--argo"fi"-- print"]   Error::__No))
}

/// Sim      ommand,
                    ref comm               )rite!(             ref name,
                command: mandig {
    //mand, output.status
          and, output.status
  {
                wr]
    /output.status
  {shoule!({shou            writ_output(out `pkg-ciparsResulsc print>_NAME"&        ate pac         abletderr./= ate     O_NAME"&["--mod(vers.t"]t_output(out `pkg-ciparsRemod(vers.trap().trim_end().to_po_owned())
}pac         Ok( `pkg-cfohat the libraryT //he Deich makes ately dure instead oired bys of anycompilat
    CONFIG_SYSROOT_DIn(&mut selfl {
    Config::ntter)ew().target_supp    ablegure it=").unwrap ot>". `<va               )?;
   ;_supp    ablead oi=").unwrap ot>"`TAR               )?;
   ;_p()` prints O `[Cnd seich makes anead oi==egure itsitu
      if ng a li (used ncluanp()` prints om envir)./// Indic ruad oi==egure it:ErrorKind::No-variaa  // /// Indic 
         thisich makes ept in c`.
  inclort in `pkg-config`.,ent of n",
          thiand set it systeributio youupt via\n\
-e
[system the fol.          Errornnncll {
  g::_ intari(",
    /// which may le        "Try `breon u likend seich makes afThe variabledenciesd    "Try `bref
    => va   i> va i==e"0"     al              maf
   _ecausadata: true,
     sionte!(
                 on i> in cdenciesd,ent oeich makes ate   ///arge,                 on  that ated wiof ttf,
   at
    CONFIG_SYSROOT_DIn(&m
            nncll {
  g::_ intari(",
    /// ")te!(s
   oand, output.status
  ||rnnncll {
  g::_ intari(",
    /// wted in path")te!(s
   oand, output.s} Indicate whether the `--se probe_library function
#[top abvel `r, variable:`pub fn fin please don't match on  &str) r, variable: &str) -> Result<String, Error> {
    let arg = fory(name).map_eund:r, variable: &str) -= Config::n))
}

/// Simple shortcut fohat the libelfl {
  g::_ intari(tter) -rap ) th Error> {
 Versiondata: boo            Error().unwrap_o. `<va  E").unwrap_o`TAR         "Try `bre(Ok(l {
   E"Ok(ad o))te!(
                 able    acos")ad oi==egure it: o`TAR           o. `<va    write!(f, "Could ablegure i_u =egure i.entifyi('-'fi"_" ;_p()` prin= Bound::Incl intari ot> variable){}nfg = Con ) th,egure i)oand, output.status
  .d());
   |::Incl intari ot> variable){}nfg = Con ) th,egure i_u))oand, output.status
  .d());
   |::Incl intari ot> variable){}nfg =     = Con ) th))oand, output.status
  .d());
   |::Incl intari ot>Con ) th))  Error::__Nonexhaustive =>( na().unwVar       NotPult de E"_ec| (_raelf().unwVar       NotPult de )te!(
                 :Incl intari ot>Con ) th)  Error::__Nonexhaustive =>( na().unwVar       NotUniand (s) E"_ec| (_raelf().unwVar       NotUniand (s) )te!(
                 
}

fn ` did not exit success`TAR of . `<vascribed in
    /// th that arva iche iand : {:?ommand, output.status
               formatand, output.s} Indicate whether the elf   }ari ot> ter) -rary, String> {Versiondata: boo            runnncl int_system_g{_libs: true,
     lnle)     :re   -if- in-  (c) Ycfg =     );
output.s} Indicate).unwrap ot> }
       er the elfe!(ssed.
> ter) -rary, String> {target_supp    );
        .to_owned());
   |::Inclt var(ssed.
>    )      er the elf   O ter) -rary, Strifi,rg
   [Stri]> {
    let ++ du8>raelf {
           able.atleast_v_exe/= ate  l {
  g::_ intari(",
    /// ");_supp    able allbstr_exe/= e Deicleast_v_exete!(nionnew:ErrorKind::Nof
   data: bo).trim("       "))  Error::            "" // TheNng places:    write!(f,ableexe/= eicleast_v_exetto_owned());
   |:data: bo).trim("   h makes")pac         ablemutocmd/= ate         (exeKG_NAME",rg
pac                md.: &mut ).d());
   Sim     "" // Thee Dablef
   exe)   vallbstr_exe/
                 :Incl       (exeKG_NAME",rg
p.: &mut )
                        "" // There'self()tand, output.s} Indicate ew:ErrorKind::NoOk(to_po_ote!(
                 if      )?;
    .       io::ErrorKind::NotFound =Ok(to_po_is_empty
                            "" // There's no elf( name)  ref name,
                com    output: Ovariable){:?omm  md/mand, output.status
  s
  {
                wr]
  cate e      }
            Error::ProbeFailure {
      (
     te!(   (        ref command,
            output: Ovariable){:?omm  md/mand, output.statu
                mat), Indicate whether the elf       ( ter) -exe::data: bo -rary, Strifi,rg
   [Stri]> {
  ref command,
    ablemutocmd/=  ref co/// U(exe) /// Indic runnncle!(ssed.
>ed becmand,
         md.,rge);
ssed.
");
output.s} Indicate md.,rgs(,rg
p.,rgs(&:Incl       pripac         e Dablef
   a pac)/= ate  l {
  g::_ intari(",
    ///      "ecmand,
         md. in(",
    ///      ", a pac);
output.s} Indicatee Dablef
   a pac)/= ate  l {
  g::_ intari(",
    ///  SYSROO"ecmand,
         md. in(",
    ///  SYSROO", a pac);
output.s} Indicatee Dablef
   a pac)/= ate  l {
  g::_ intari(",
    ///  ted in path")cmand,
         md. in(",
    ///  ted in path", a pac);
output.s} Indicatee D:Incl            cargogmand,
         md. in(",
    ///  hich mtedTEM_SYSS"fi"1");
output.s} Indicatee D:Incl            c printgmand,
         md. in(",
    ///  hich mtedTEM_CFLAGS"fi"1");
output.s} Indicate md.,rge    );
output.s Errornnncluded(vers.to:ErrorKind::Notring());
       => vvers.tote!(
                  md.,rge variable){} >= fg =     , vvers.to  let instructi}ErrorKind::Notring()Ex
       => vvers.tote!(
                  md.,rge variable){} > fg =     , vvers.to  let instructi}ErrorKind::No run  format_output(outut.s Errornnncluded(vers.to:ErrorKind::Notring());
       => vvers.tote!(
                  md.,rge variable){} <= fg =     , vvers.to  let instructi}ErrorKind::Notring()Ex
       => vvers.tote!(
                  md.,rge variable){} < fg =     , vvers.to  let instructi}ErrorKind::No run  format_output(outut.s mdwhether the elf      
    }

> ut Conf, String           runnncl env_metadata:g{_libs: true,
     lnle)     :Ok(()));
output.s} Indier the elfe var(ssed.
> ter) -rary, String> {target_supp    able       rinsey#[depr /// Indic runnncl intari ot> variable){}n for a =     ))te!(s
   o::ErrorKind::Noadat/// Indic          nnncl intari ot> variable){}n-static =     ))te!(s
   o::ErrorKind::No al  /// Indic          nnncl intari ot>"pass `--static` for a")te!(s
   o::ErrorKind::Noadat/// Indic          nnncl intari ot>" do not pass `--static")te!(s
   o::ErrorKind::No al  /// Indic       :ErrorKind::No al  /// Indic t(output: `PKGll din
  Dg a liONFIua deoiabletringn to use till din
  Dg a li.eates Dg a liOnd syversion = Bofn   )?;
   ig {
            statik: None,
            min_version: Bound::Unbounded,
            max_version: Bound::Unbounded,
            extra_args: vec![],
            print_system_cflags: true,
            print_s al              ma            cargo_m al              ma env_metadata: b al              marint_system_li al            }ay for Error {
es specified b    Config {es specified b ccept specified b cce(out `p/// C//// U(p,ied b cce(out `   /// Librar/// U(p,ied b cce(out `   /// Darwin/// U(p,ied b cce(outf>,
    /// Linker/// U(p,ied b cce(out 
    /// C//// U(p,ied b cce(out    /// Darwin /// U(p,ied b cce(out    /// D /// Linker/// U(p,ied b cce(outOption<String>>,/// U(p,ied b cce(outEnsure that thi/// U(p,ied b cce(outnts all reaIndicate whether the `--sExnlesson
#[Strid
  eck, boc     :rustcrgetk-arg `--vari///      (jcflarecommend    , t are
n the rinvironment ) the `--s for f variabl
[system-ogic. the elf xnlesscarg_trim_///     <'a>(l {
  , Strifi///     , S'abe]`ng> {Version&'abe]`iified b cceelfles   Cpriori<'b>(///     , S'/ Lib,ng priori   [Stri]> {
 Version&'bbe]`iified b cce f)
   ng priobrarg priori(
                 if ///       Cos exam(g prioo::ErrorKind::NotFound =-variaaf
   &///     [..///      /  nfigrg prio /  nf]  let instructions    Error::ProbeFailure {
   Nng places:   c         able the fportarg" /// Indic rugure i.cutput.
("msvc        "Try `breon Accordncluect `  .exe/ statik(&mut :    "Try `breon g/0.3")]learnlud CONoft) to en-us/cpp/urce,/theariabl/getk-in   -/// D?view=msvc-170    "Try `breon    "Try `breon cepINKoss-compend s with tten Setti_CONFket atedially saboat lackSROOT_Dg as as wit.    "Try `breon ceIupport,epINKo_PATion<s for in   s withary is located.ale    aof /// eparat.    "Try `breon    "Try `breon h obligatrustcta w Cos `.arg`ons:

Thhortcuepariroename `--va

Th-l}", commalcateirgus an,    "Try `breon cause lariroename `--vainted   _p     :rustcrgetk-arg:    "Try `breon g/0.3")]config-rs/)

[Documen

[D/blob/657f246812ab2684e3c3954b1c77f98fd59e0b21/G_SYSRern

[Dc_and gen_ssa     bstr/getker.rs#L828    "Try `breon g/0.3")]config-rs/)

[Documen

[D/blob/657f246812ab2684e3c3954b1c77f98fd59e0b21/G_SYSRern

[Dc_and gen_ssa     bstr/getker.rs#L843    "Try `breon Ss:

Tha `[C with tten Setributiwork
    nMSVCugure is tha`.arg`ErrorKind::No-variaa es   Cpriori(///     E"&[".arg"]  /// Indic          gure i.cutput.
("w         && gure i.cutput.
("gnu        "Try `breon GNUugure is            ation the rignullvm,end s`by -WlFl fun::Gcc`for irsion iintrustc,    "Try `breon cause tellstrustctnfig` tool GNUugetker.trustct to use ttf,
 Co/a w Coons:

Thhortcuepa    "Try `breon iroename ment 
Th-l}", commalcateirgus an bef  __eck,ncludtlec `fooo.tker:    "Try `breon g/0.3")]config-rs/)

[Documen

[D/blob/657f246812ab2684e3c3954b1c77f98fd59e0b21/G_SYSRern

[Dc_and gen_ssa     bstr/getker.rs#L446    "Try `breon g/0.3")]config-rs/)

[Documen

[D/blob/657f246812ab2684e3c3954b1c77f98fd59e0b21/G_SYSRern

[Dc_and gen_ssa     bstr/getker.rs#L457    "Try `breon GNUuldct vied by3:
//!ONFIGypo perto dealibun jcflareco.arg ` dealibutnMSVC'st `  .exe/fig t.    "Try `breon GNUuldcce frtf,
 Co:

Th`arg`o the fpns:

The//      i> ie    librasoeparateokaer tiremove
            on  thh`arg`o the fp`--va

Th///       usual.a`ng priob*xample

*  thh`arg`o the f.    "Try `breon g/0.3")]es or OVIDEr opbinrarys]

us-2.39/ld.docs#   ex-nviron-kg-conf-to-a-dll
            if ///         rts exam( the f)(
                 ablee//      = &///     [ the f./  nf..];
Kind::NotFound =-variaa es   Cpriori(///     E"&[".dll.a"fi".dll"fi".arg"fi".a"]  let instructi            "" // There's-variaa es   Cpriori(///     E"&[".dll.a"fi".dll"fi".arg"]  let instructi}ErrorKind          gure i.cutput.
("to ie        "Try `breif ///         rts exam( the f)(
                 ablee//      = &///     [ the f./  nf..];
Kind::NotFound =-variaa es   Cpriori(///     E"&[".a"fi".so"fi".dyarg"]  let instructi}ErrorKindnd =-variaaNng ;/// Indic       :ErrorKind::Noif ///         rts exam( the f)(
                 ablee//      = &///     [ the f./  nf..];
Kind::NotFound =-variaa es   Cpriori(///     E"&[".a"fi".so"]  let instructi}ErrorKindnd =-variaaNng ;/// Indic whether the elf arsResulsc print> &mut Confirary, Strififmt::Form[u8], anycomormik: No)mmand,
    ablemutois_msvc   valse;_supp    ablegure it=").unwrap_o. `<va  ; Indicatee DableOk(l {
    = &gure it:ErrorKind::No rugure i.cutput.
("msvc        "Try `bre::No s_msvc     // /// Indicut.s} Indicate w_supp    able      corm macos") || cfg!(target_os = "ios"{ied b cce(outEnc![options).trim("/pt spec  E"options).trim("/S     "tch on ndic       :ErrorKind::Noable   orm a= anycom    "Try `bre::Nol intari ot>" do not pasted in path")
output.status
  .d());
   |:nd, ins intari ot>"ted in ")oand, output.statu))
}(options).trim ;_p()` prin= Bos") || cfg!(target_osw         
                 if ablef
      orm )/= a  orm a:ErrorKind::NotFound =Enc![a  orm ]
                            "" // There's no _systelet instructions    Error::Probe           "" // There'sEnc![a  orm tto_owned());
   |:options).trim("/usr")o]/// Indicut.s} Indicate ac         ablemutonviet_oker/// U(p;_supp    able      selnd, inse!(ssed.
>ed beac         ableed det_osplit_print>to_po_o;_p()` prints Homm defonfle-  (less // rgus ansill a `-I/usr/f>,
   `         able  rtst_oed de  Error::__No)is / )
            .///s / |l| l /  nfi> 2   Error::__No))
}(| rg| (_utf[0..2], _utf[2..]o  let instr    (prin, va   ine  rtst{
ind() {
            ///     "" // There's"-L"     let crate_name =
    ablemem_g])variable)rustcrgetk- -F
  =na }
 cfg = Col  let instructions = ifnd, ins      
    }

> 
     let instructions = ifnvie.push(options).trim(Col   let instructions = ifnnncl `   /// L.push(options).trim(Col   let instructions }    "" // There's"-F"     let crate_name =
    ablemem_g])variable)rustcrgetk- -F
  =    /// Dcfg = Col  let instructions = ifnd, ins      
    }

> 
     let instructions = ifnnncl    /// D /// L.push(options).trim(Col   let instructions }    "" // There's"-I"     let crate_name =
    :Inclt ,
    /// L.push(options).trim(Col   let instructions }    "" // There's"-l"     let crate_name =
    NFIG_Ssvironmprovid          CRTy3:
//MSVCErrorKind::NotFound =>fo s_msvc && ["m"fi"c"fi"pthe th"].cutput.
(&va   e,
                com    ountinre;                  _ => ErrorKind::NotFound =>fo      s&& e!(ssed.
_figure ho(Col, _      corm m, _nvie)  let crate_name =
            mem_g])variable)rustcrgetk-sul=ssed.
cfg = Col  let instructions = if= ifnd, ins      
    }

> 
     let instructions = if            "" // There's no easy    mem_g])variable)rustcrgetk-sul=fg = Col  let instructions = if= ifnd, ins      
    }

> 
     let instructions = if 
let instructions = ifnnncl `bL.push(Collf
    }

    /// Indicuctions }    "" // There's"-D"     let crate_name =
    ablemutois //= Col.split('='  let instructions = ifnnnclOption<lt sert(let instructions = if= ifis /.next ).ned())
}

 {
    //mand, output.status
  = ifis /.next ).)
}(|s| sig {
    ///mand, output.status
    /// Indicuctions }    "" // There's run {}/// Indicut.s} Indicate w_supp    ts Homm demulti-  (less // rgus ansi3:
//space-TH`
and d a packll a `-ecified byL_STAe =
    ablemutois //= ed de)is / ).  /  

}(| rg| :ErrorKind::No ru pr.   rts exam("-Wl,   
                 utf[4..].split(','). std::e )
                        "" // There'sEnc![ pr.as_ =>nf]/// Indicut.s} Indicate   /// Indicwhwithablef
     rt)/= is /.next )t{
ind() {
          
//!      "" // There's"-ecified b"     let crate_name =
    if ablef
    `b)/= is /.next )t{
ind() {
    re's no easy    mem_g])variable)rustcrgetk-sul=    /// Dcfg =  `b) let instructions = if= ifnd, ins      
    }

> 
     let instructions = if= ifnnncl    /// DL.push(    f
    }

    /// Indicuctions ons }    "" // There's}    "" // There's"-i      " |s"-iquote" |s"-invi    /"     let crate_name =
    if ablef
   t ,)/= is /.next )t{
ind() {
    re's no easy:Inclt ,
    /// L.push(options).trim(t ,)  /// Indicuctions ons }    "" // There's}    "" // There's_     let crate_name =
    able/// t_osd::process::{C/// U(  rt);let crate_name =
    if rocese!(///  )t{
ind() {
    re's no easyonfinted ss-compe     ow `atti_COnviron deoe useyiahout -l
  uect `  ,
ind() {
    re's no easyonfsoosplituuptn
#[d
  u   otn
#[d
r an nvironmey ommalco version .
ind() {
    re's no easyonfTODO: eck, out -l
  unviron dee lisgetk-={}"lco versGypo    Etanotezsd    "Try `bre   "Try `breon g/0.3")]config-rs/)

[Documen

[D/issues/99427and, output.status
  = ifif able(f
   nvi E"f
   out      ),eOk(l {
   )      std::env::var("CARGO_PKG_(rocesd
r an matrocesout       mat&gure i){instructions}\
              std::env::var("CARGO_PKG_      SInc:: xnlesscarg_trim_///     (    std::env::var("CARGO_PKG_::Noaure i,    std::env::var("CARGO_PKG_::No&out       f
    }

   if !),    std::env::var("CARGO_PKG_       "Try `apt install pkg-con::Nof
   arg_) thed becaus     "Try `apt install pkg-con::No    able `    -F
   =    "Try `apt install pkg-con::No    nstr   iable)rustcrgetk- -F
  =fg = nvi.d fmt(&    let instructions = if cfgons = if= ifnd, ins      
    }

>  `    -F
   ;_p()` prin= Bound:tall pkg-con::No    able `   arg ])variable)rustcrgetk-sul=fg = arg_) thed be let instructions = if cfgons = if= ifnd, ins      
    }

>  `    `b) let instructions = if= ifuctions = ifnnncl `   ` dea.push(options).trim(roce   let instructions = if cfgons = if}let instructions = if cfgons = ifsionte!(
                                          lnle)     :warropr=Fut -l
  u{}       as defined in out -fr Errormat rary '{}'  xnless"lco vers) the     
  eck, bocgetker}", commalcat"atrocesd fmt(&  =     );
output.suctions = if cfgons = if}let instructions = if cfgons }let instructions = if cfg}/// Indicuctions ons }    "" // There's}    "" // The} Indicate w_supp    ablegetker_tially s= ed de)is / ). //s / | rg|  pr.   rts exam("-Wl,    let instr           inegetker_tially s:ErrorKind::Noablemutopop   valse;_supp    ::Noablemutold_tially/= Csyste;ied b cce f)
   ng bor `yu       [4..].split(',') 
                 if pop 
                     pop   valse;_supp    ::No com    ountinre;                  
let instructions >fo  bor `==e"-ecified b" 
                     pop     // /// Indicut.s com    ountinre;                  
let instructions ld_tially.push(  bor   let instructi}E
re's no easy    mem_g])variable)rustcrgetk- pr=-Wl,fg = ad_tially.join(",    let instr= ifnd, ins      
    }

> 
     l
uctions = ifnnncl 
    /and, output.statu)push( d_tially.   o_is / ).

}(ta: bo).trim). std::e ));/// Indic whether the elf arsRemod(vers.tr &mut Confifmt::Formtring          nnncl(vers.t)pushg-conto_po_ilcats ).next ).ned())
}

rim ));/// Iput: &Ourinsey#[dep, String> {ta: bog             (ls )
        .)
}(|c| c f
 ascii_uet ic th())
        .)
}(|c| s") `==e'-' { '_'          ce e      }
 . std::e )
r using ed by the '{ub liapproprivate `run
//!). These va
elfe!(ssed.
_figure ho(rary, Strifi      corm morm[options]= nvimorm[options]ng> {target_suppablegeb       variable)geb{}.a"fied beac     nvie.is / ).any(|nvi| :ErrorKind!      corm m.is / ).any(|   | nvi.   rts exam(   )  && nvi.join(&geb    ).exists )
    })
r using plitutderr./produc      hich makes th printgomma/ of --argou   otTH`
and    //s`PKG_CONFIB forlash`yu  derr./ately du//
  efigureges /alw `at\n"
 f * `FOO_STAbyte.  Difearialeed detconfig -TH`
and d    uatscap    pace. Oshoulwtarg pace   (less /sive Wor".
  hary '{}' occur uatscap   get_varr"., a
//! `--va

Th/ Ulcateitrror as fof      )? Fof anaries.otetyi3:
//d.ale{shous get_s ofumy acceshich makes  derr./wary 'dovariab   Echedrio,rroryironmly du envi   ngplitOSS=1as get_we/// ik: plit_print>to_po_orm[u8]ng> {++ definitiet_suppablemuleed dt_oker/// U(p;_suppablemuleed dst_oker/// U(p;_suppablemuletscap     valse;_
 f)
   n&b`yu  derr./           Errorb 
             _ afThscap    !(
                 tscap     valse;_                ed d)push(b  let instructi}ErrorKindnd =b'\\'  !(tscap     adata: true,
     b'\t' | b'\n' | b'\r' | b' 'te!(
                 if !ed d)e!(f, "\n--- stderr\n            ed da.push(output.stderr);
 (ed downed())
}pacstderr\n            ed dt_oker/// U(p;_supp    uctions    Error::ProbeFailure {
    run cd d)push(b eaIndicate whether the if !ed d)e!(f, "\n--- stderr\ned da.push(output.stderr);
 (ed downed())
}pacstdeer the ed de catedcfg( es )]
moda es  s:Errorlone,ut i::*;// pleas es ]/ pleascfg( g!(target_os = "ios] the elf      carg ver_ = _ es n--- stderr\nse std::process::{C;w_supp    able      corm macoEnc![options).trim("/pt spec  E"options).trim("/S     "tc;w_supp    is wrble!e!(ssed.
_figure ho(Failure {
   "PluginManagermmand, output.s_      corm m,and, output.s_[options).trim("/pt spec/F   /// DL"tch on ndic}pacstderr\nis wrble!e!(ssed.
_figure ho(Failure {
   "python2.7mmand, output.s_      corm m,and, output.s_[options).trim(    "" // There's"/S     /pt spec/F   /// DL/Pythonl    /// D/sion: Ss/2.7/arg/python2.7/ makes"   Error::Commch on ndic}pacstderr\nis wrble!e!(ssed.
_figure ho(Failure {
   "ffileasveniiablmmand, output.s_      corm m,and, output.s_[options).trim(    "" // There's"/pt spec/Ruby/Gems/2.0.0/gems/ffi-1.9.10/ext/ffile/argffi-x86_64/l `bL"   Error::Commch on ndic}pac_supp    ts H       /ateyu /usr/locol,      t' use ta 
//! tion
#[OS Indicatee D::{C/// U("/usr/locol/arg/argpng16.a").exists )-- stderr\n    is wrblee!(ssed.
_figure ho(Failure {
   
   "png16mmand, output.statu_      corm m,and, output.sut.s_[options).trim("/usr/locol/arg"f]/// Indicut.s)  l
uctions = ifablegebpng out = cfg.run(pand, output.statu)  pubd(vers.t("1".."99")
output.status
  .  )]
#"argpng16")
output.status
  .ned())
}; stderr\n    is wrbleargpngl(vers.t)-> Ra'\n')te!(nionne);/// Indic whether the as es ]/ pleascfg( g!(target_oslcauxos] the elf      carg ver_lcaux_ es n--- stderr\nis wrble!e!(ssed.
_figure ho(Failure {
   "rary",and, output.s_[options).trim("/usr")],and, output.s_[options).trim("/usr/arg/x86_64-lcaux-gnu  ch on ndic}pacstderr\nis wrble!e!(ssed.
_figure ho(Failure {
   "dialog",and, output.s_[options).trim("/usr")],and, output.s_[options).trim("/usr/arg  ch on ndic}pacstdethe libelfles  arg ver_///     (l {
  , Strifi///     , String          is wrb_eqn ` did not exir.
    // xnlesscarg_trim_///     (aure i,i///     )            maf
   "foo")
output.spacstdethe libas es ]/ plefnt `   ///     _lcaux()et_supp    ablegure it=""x86_64-unknown-lcaux-gnu acstderr\nles  arg ver_///     (l {
  ,rtargfoo.a")acstderr\nles  arg ver_///     (l {
  ,rtargfoo.so"pacstdethe libas es ]/ plefnt `   ///     _to ie()et_supp    ablegure it=""x86_64-to ie-darO_S acstderr\nles  arg ver_///     (l {
  ,rtargfoo.a")acstderr\nles  arg ver_///     (l {
  ,rtargfoo.so"pacstderr\nles  arg ver_///     (l {
  ,rtargfoo.dyarg"pacstdethe libas es ]/ plefnt `   ///     _msvc()et_supp    ablegure it=""x86_64-pc-w      -msvc ;_supp    ts ssed.
     ). Thes the '{ub l     

Thh    .arg  Cpriocstderr\nles  arg ver_///     (l {
  ,rtfoo.arg"pacstdethe libas es ]/ plefnt `   ///     _mputw()et_supp    ablegure it=""x86_64-pc-w      -gnu acstderr\nles  arg ver_///     (l {
  ,rtfoo.arg"pacstderr\nles  arg ver_///     (l {
  ,rtargfoo.a")acstderr\nles  arg ver_///     (l {
  ,rtfoo.dll")acstderr\nles  arg ver_///     (l {
 