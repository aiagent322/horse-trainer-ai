//! [![github]](https://github.com/dtolnay/proc-macro2)&ensp;[![crates-io]](https://crates.io/crates/proc-macro2)&ensp;[![docs-rs]](crate)
//!
//! [github]: https://img.shields.io/badge/github-8da0cb?style=for-the-badge&labelColor=555555&logo=github
//! [crates-io]: https://img.shields.io/badge/crates.io-fc8d62?style=for-the-badge&labelColor=555555&logo=rust
//! [docs-rs]: https://img.shields.io/badge/docs.rs-66c2a5?style=for-the-badge&labelColor=555555&logo=docs.rs
//!
//! <br>
//!
//! A wrapper around the procedural macro API of the compiler's [`proc_macro`]
//! crate. This library serves two purposes:
//!
//! [`proc_macro`]: https://doc.rust-lang.org/proc_macro/
//!
//! - **Bring proc-macro-like functionality to other contexts like build.rs and
//!   main.rs.** Types from `proc_macro` are entirely specific to procedural
//!   macros and cannot ever exist in code outside of a procedural macro.
//!   Meanwhile `proc_macro2` types may exist anywhere including non-macro code.
//!   By developing foundational libraries like [syn] and [quote] against
//!   `proc_macro2` rather than `proc_macro`, the procedural macro ecosystem
//!   becomes easily applicable to many other use cases and we avoid
//!   reimplementing non-macro equivalents of those libraries.
//!
//! - **Make procedural macros unit test)]
    "\\x00"
        use cases a.rs.**` idx,
   fg(span_locati/!
//!000*`    }
annot ever exist in  use cafn nehe procatntinsprocedural
//!pro
//0*`    execue, C to pases a.rs.*. InTE_ORDEut fhelthe t
//!   `pnt_cs lpl e proc0*`    applicab

    rs.**` i
//!isol`locatelemy);
s     hose libr, Cthe pmacro`, the procedurit test)]
acro2:/issues/235
    match token crost)]
aer tha:/issues/235
    match token er tht test)]
# Usaght test)]
T    keal"vailaba-macvoiles easily applicabmacvoilnd look`proc_m    ust-lang.o```ang.o    
  :
//!..138)
    ;t test)]
# ";
   IGNOREstarts_wi*)
}

macrruct)]
#[.138)
    _l {
   MyD {
  )]st)]
# };st)]
#  group = match group {
 t)]
pan::caly_l {
   input      inner
            .to_stnner: TokenStream) -> Selfacro`,eral")input if he procedunStream) -> S"<unspecnput);t test)]
 if self.utput      inner
unStream) -> S iflfacro`,er lint* trans deb)input */facro`,er lin#)inputfacro`,er};t test)]
 if nner: TokenStream) -> S"<unspe.utput.io/b   ng.o```ang. ng.oIff rese pr[deri[Sro2, youinittingrg/rest)
    _input!`]ng: &strb

 t)]
prop `p/!.. Fromey foon, rrectnd  evenr = getkenTree> y dnf rese pr  }
nit test)]
rg/rest)
    _input!`]
//!
//! - **und  cro/    cro/pes ma/rest)
    _input.htmlt test)]
# Un.**` i
nStreamst test)]
T   defa_strnStream>size;
of the API f track sourcmossh('cStream ` iposes:enTree> ! c. Fld.rs and
//!iosystem
//!   rocatn    if yeream ` in    ifang.o  doc.d byof the API f by defa_stit test)]
T  mptlay forurcaddi agains! c(wrap_proc_ total nmossh('cStrenightndposes:enTree>become`ource_file(&self) -> Sou` ";
fipr lag);
s     p    rb

 t)]
ringc.rmatwinitpolyfinitdural nightnd-aller! c(w evenr =R
s  1.56   
   t)]
itere!   mun.**` i
! c(wocatntrackecomenightnds:enTree>beminnt_lf)s,
  roc0*`  f the API f codelatt b-> ke prchd::Isnr = gemfilereimtime.st-lang.o```shang.oRUSTFLAGS='--rou ource_file(&self) -> Sou'!prrgoom `pr ng.o```ang. ng.oN thwocatnt! [`;
s   if aller   dwritut fyfile:
//!,om ttut freim:
//!.ocat ng.odepend ronfyfile:
//!
//! [`inf(Clonu   tream>      ibragain   //itcro`]:  ng.oPathBremindcro ectfyfi!   manwhile `prcomendebul &self) guaranteunit test)]
Sself) -> Sou medurd r   mR_MA    s sucontincomes eae API f  **us
/// ava.t test)]
# TefCel-Safetyt test)]
Mosshmacro tinco   :
//!.   m`!Sroc`r usatingcome    rlye prcenTree> t)]
iacro cokntation oRefCel-<Sour memorybemanye proc y            c    , C to  ng.oP dif
    toRefCel.flow.P the API f tacro tinring **on omain.rselColocat'7')k  }

  dev.
#tps:/(html_root_ur   t"/!
//! - **und  {
        To      ro::#tprou_attr(reinot(span_loelf.s, 
    _un.**` i),rnStreamnot(span_loelf.s)o::#tprou_attr(
    _un.**` i,rnStreamnot(span_loe_site()
)o::#tprou_attr( **_rou,rnStreamn **_rou)o::#tp      start(       pan _lossl   ,start(       pan _docsi` i_trunoff,
 ,start(       d(spanrkdow ,start(       ()
ms_af  
e;
 t libr ,start(       sel_    rs mat_  tacrd,start(       m{ ptr_     l,start(       m{ ptr_nd::I_".0");
 ,start(       ming_ati_   d    i,start(       needl   _d(srs.*_enti,start(       new     anw_defa_st,start(          }
 _}
}
_   _ming_ati,start(       shadow_ted one, ,start(        debug.ly_".py_p   _by   o,start(               } e_ = ms,start(         atid_}
}
,start(        tid_    rs mat_bindffixed_nu(       vec_th a_ainn_d)
 
o::))]
impl Soource_file(&self) -> Sou,  = match group fn nex
    _un.**` i))o::cenTree_ey forru"\
 else {
ehe pr    if right.oIffyoui for    }

  }
  onf\
 elsource_file(&self) -> Sou, yfi!need}

 enseam>ocatn tf\
 els    }
 ed}n loor= getkenTreb fn l`prcomes eae API f \
 elsm `pr script  // wll.
"}

    
  :
//!.    c;rom<TokenStream> for proc_macro::    
  :
//!..138)
    ;t
modmR_MA r;
modm/rest;
modmrcvec;rom<Toke = match group {
 modmdet(Clonn;flow.Pubavorom(inner: TokeunSursive tnSuorcerence.e  uorcere,om ttdural    m- *tht t

  ichenting non
    eqomitn tf to pring **.eral:/(hidden: Stri modmursive t;
Stri modm   ra;rsor(src: &sr: literal,
       ting ue,
  ursive t  //imp;sorSourceF" of thend "]om<Toke = match group {
 modmimp;src: &str) -> Cursor {
  modm Cursor ;srting ue,
     raspanlimSBoundting ue,
  R_MA r::M_MA r;
lo = matchf.lo)O_ORDe p;
lo = matchmt.de{:ResulD)
    pl Debu};
lo = matchhashde{Hash, Hasher};
lo = match rang Option<Spa;
lo = match*)
::xError;;
lo =ng    y for Result<b fn source_file(&self) -> Sourcelo =ng        : };

  ;src: &str) -> Cursor {
  tri ting ue,
   Cursor        #[cfg; in thAn abstracstream.ex`prc    .,pnt_mor = mnc    anda an_locati/!
cfg(fe  innit t/in th/! [`epr: ourvile     irf fmtrom(iormatrarie
   
cfg(fe  innnce.eom(in thcolantse profg(fe  innnay fowrit.write_t t/in th/fg(feature = [`add rcomeinput ce.e.utputi/!
`#[.138)
    ]`,in th`#[.138)
    _attrim te]an the
#[.138)
    _l {
  ]andefth a r {.eral {
    repr: Stri RcVecBuilder<Token}

impl TokenS     oup {
    pub fn _R_MA r: M_MA r,ne in thFormat   }
 , C to p`tream) -> S"<unsp("li`.Stri RcVecBut::Formatter) - TokenS     t::Formaub fn _R_MA r: M_MA r,ne iw() -> Self {
   span: Span) -> TokenS     oup {
    p{
            inner: RcVecBuild       }
    }
}

imturn Ok(litera_R_MA r: M_MA r,nlf, span: Span) -> bool n) -_ursive t> TokenSursive tnSoup {
    p{
            inner: RcVecBuild       }
    }
}

im: str(" "y f        }
    }
_R_MA r: M_MA r,nlf, span: Span) -> bon thRery.
  an if stp`tream) -> S` ";
");
aries.
cfg(fe  innit) -> Self {
   {
            inner: RcVecBuild&self)      oup {
    p   if t) Span) -> bon thC    sbug t! [``tream) -> S`  [`if st.      // XXX(ni
     & self.hi == 0
    }
}

impl Dstr(" ")?;
     ach line in th`tream) -> S"<defa_st()`t   }
   an if stpte(),
  n thi.!
/      s! - **Make r[deri`oup {
    p   if t`.Slf, fmtfa_strnterator<Item = TokenStredefa_st()
            inner: RcVecBuild&s if tach line in thAing.
 snr =b-> k       Display for Toknnce.el From<ural r Toknnay foa r Tokin th.write_t t/in thMmut ailtut frcations, norits   fnut fexaose ,bug t!    Displ".0");
 in thunbalwithd  self.del`pnt_c(fuzzing)  if .
//!isplay t!  procuage_t t/in th whiche {
mey fooncodesatinger", sng: &strb nori }
 ispl`t::Forma`.rmain thstr rvngcomerightm<Tokhd::I
itere!ey foonay fo`t::Forma`s one,r.e Err = LexError;

    fn from_str(src: &str) -> Result<TokenStream, LexError> {
        // Create a dummy file & add it to the      _wi*rc parse t.m maey (|e|ut::Formatter) -}
    }
}

im: e      }
    }
_R_MA r: M_MA r,nlf, span:ecked_add(enOk( RcVecBuild&self) e))]
impl From<TokenStream> for proc_macro::#prou_attr( **_rou,rl:/(TokenStream> for proc_macro)or TokenStream {
    fn from(inner: proc_macro::TokenStream) -> Self {
        inner
            .to_string()
         RcVecBuild&self)  tr(" "y f  )]
impl From<TokenStream> for proc_macro::#prou_attr( **_rou,rl:/(TokenStream> for proc_macro)or TokenStream {
    fn from(inner: TokenStream) -> Self {
        inner
            .to_string()
            .. tr(" "y f  nStream {
    fn from(tree: TokenTree) -> Self {
        let me) -stream = RcVecBuilder::new();
  RcVecBuild&self)      oup {
    p   let me) -    fn fmt(&self, fn extend<I: IntoIterator<Item = TokenTree>>(&mut self, tokens: I) {
        let mut vec = selfut().extend(streams.into_iter().f    }
}

pub(cr TokenStream {
    fn extend<I: IntoIterator<Item = TokenStream>>(&mut self, streams: I) {
        self.inner.make_mut().extend(streams.into_iter().o compiler token  }
}

pub(crate) type Tom m(|

pub(| .write_str("ter = RcVecInn the lantssfrcations, noofg(fe  innnay fo() and
  .write_ttream {
    fn from_iter<I: IntoIterator<Item = TokenTree>>(tokens: I) -> Self {
        let mut st = RcVecBuilder::new();

      RcVecBuild&self) 

pub(crate) type Tocolants  )]
impl FrnStream {
    fn from_iter<I: IntoIterator<Item = TokenStream>>(streams: I) -> Self {
        let mut v = RcVecBuilder::new();

      RcVecBuild&self) 

pub(crate) type Tom m(|i|hi.str("tocolants  )]
impl Frnn thPDistsll(spang(feature =PathBuf {
 rocatn   s  fas  }

    lossl   ndposthcon   ti` iw evenay forurc     ang(feature =(modulormatio),eamcepteom(in thdocsi` tp`tream mut::", &s`s [deri`

        f.wri`  self.del`pce.erepr.insin thithinic    #[cfs.&self, f: &mut fmtterator<Item = TokenStt::Result {
        Display::fmt(&self.repr, f)
    }
}

impl Debug for Litera}

imt   fn fmt(&sen thPDistsllng(feay a  // hcon  nike r fmt     gemptylf, fmt: &mut fterator<Item = TokenStt::Result {
        Display::fmt(&self.repr, f)
    }
}

imp) {
  for Litera}

imt   fn fmt(&seepr: S::Formatter) -lf.span
    }

    pub fn set_span(&m pub(celf) 
o_iter().f
    fn fmt(&self, fmt: &mut fmtS::Formatter) -enStt::Result {
        Display::fmt(&self.repr, f)
    }
}

imp) {
  for Litera}

imt   fn fmt(&seepr:  f: &mut fmt:::Formatter) -enStt::Result {
        Display::fmt(&self.repr, f)
    }
}

impl Debug for Litera}

imt   fn fmt(&sem {
  ormat fmt:::Formatt&sen thT    (&self) -> laba-umber ` pub`it t/in th/! [`epr:    sself) -> Sou ce.erif .
doc.d byodefa_stit)]
impl Soource_file(&self) -> Sou, rein: &sr: literal,
    , 
    _un.**` i))o::#prou_attr( **_rou,rl:/(Tokeource_file(&self) -> Sour)o::#p) struct SourceFile {
    path: P
}

impl SourceFile {
    TokenS      SourceFilub fn _R_MA r: M_MA r,ne i)]
impl Soource_file(&self) -> Sou, rein: &sr: literal,
    , 
    _un.**` i))o::to this source file asSpan) -> TokenS     is source lo: cmp::max(self.hi.from("<unspecified>"),
 }

imturn Ok(litera_R_MA r: M_MA r,nlf, span: Span) -> bo a string.
    pub fn path(&self) ->ty paren/-> bo a s###oN thy paren/-> bo a sIte. Thisdormati    ocine, C[derit! [``.from("<un` walocanin(spd byo, span: a s    
  applica,nt! [`;mut        i  ctuiles  puopl Debuspano man. Ushy paren/ [`}

#[cf`]m<Tokheckty paren/-> bo a sAlsot   m>ocatneber ug `}

#[cf`t   }
   `    `,bug-> bo a s`--rem m-s  p-prefix` walop    rbopl Debcommce.e)
  ,ng.
    pualocmber-> bo a s;mut     ctuiller   w {
 ty paren/-> bo a s[`}

#[cf`]: #medurd
}

#[cf      self.path.clone()
    }

    pub fn is_real(er().fself.i Span) -> bon thRery.
  `    `bug t! [` (&self) -> iathBreul &(&self) ->, ce.erif-> bon thcanin(spd byo, s    
  applica's .
dtioava.t     // XXX(ni#[cfg& self.hi == 0
    }
}

impl Dstr(" ")?#[cfg((fuzzing)))]
thread_ource_file(&self) -> Sou, rein: &sr: literal,
    , 
    _un.**` i))o::to thmut fmt::Fos source file asSpatt::Result {
        Display::fmt(&self.repr, f)
    }
}

imp) {
  for Litera}

imt   fn fmt(&se a sABregfn l`pr&(&selfisdo, r Sopr[deri/!
//! 
dtioava
    pub fn .eral {
    Span  repr: Stri RcVecBu fn set_spa TokenS     i    pub f_R_MA r: M_MA r,ne iw() -ormatter) -> fn) -> TokenS     ing, true, span)
    }

ocations)]
        }

imturn Ok(litera_R_MA r: M_MA r,nlf, span: Span) -> bool n) -_ursive t> TokenSursive tnSing, true, span)
    }

ocations)]
        }

im: str(" "y f        }
    }
_R_MA r: M_MA r,nlf, span: Span) -> bon thT    cati`prcomeinvCursor rate. Thiur   to_macro2` types may paren/-> bo a sI        _  :
ene, C[derit! [`
}

#[dllr   ct which  //ifroc y wn eq(&se a s      } directnd aing.
 ional lrsim Cursor  (lrsi-e()
 hygikeeence.q(&se a smain.rs.de aing.
 ional lrsime()
 [dllr   id
//!  ref  
cf= gemfi// wll.
  Span { lo: 0, hi: 0 }
    }

    pub fn mix&self)       pub(crate) unsaf) Span) -> bon thT    cati{
      aing.
 invCursor rate. Th_macro2` types m,om tt[der-> bon th<Sour variid
/s, <br>
s, ce.e`$ ue,
` ct which  ing.
 defth a r me()
q(&se a smfng.
 ional
//! [`isorurc     hygikeer  havit fr  `$($name:ide`.    Span::call_site()
    }

    #[cfg(procmacro2elf)       pub(cll_site()
  ) Span) -> bon thAcolumn iat ct whics aing.
 ional defth a r me()
ay paren/-> bo a s/! [`medurd    sself) -> Sou ce.erif .
doc.d byodefa_stit  pub fn source_file(&self) -> SourceFile#prou_attr( **_rou,rl:/(Tokeource_file(&self) -> Sour)o:: Span::call_site()
    }

    pub fn resolved_elf)       pub(c_site()
  ) Span) -> bon thC
ene,sfrcaew}
}

#[derirurc     self
    }

    pub fn lr  `iter`om t-> bon th iat ct whics symbolslr    anghn tfwn e ain as us,.Span) -> Span {
        // Stab  }

    #[cfg(procmacro2_semve pub(celf) 
o_iter().fn {
        other[str("te Span) -> bon thC
ene,sfrcaew}
}

#[derirurc      Litan {
 u fn l  havit fr  `iter`om t-> bon th[derirurcself
    }

    pub fn lofn as us,.Span) -> Spa{
        other
    }

    #[cfg(procmacro2_semve pub(celf) 
o_iter().f{
        oother[str("te Span) -> bon thCon   t, the procedu   pub`
cf=`nner: TokenS pub`it paren/-> bo a s/! [`medurd    rap_proc_ y dnfm `pre pr[deriaenightnds:enTree>beo> y dn-> bo a sm `pre pr[deriringc 1.29+ *    anw* sself) -> Sou nStreamsty paren/-> bo a s#  }", sy paren/-> bo a sPr", sngfrom.
  C to panwhile `proc_macro2` types ma Unroc_-> bo a s`the procedu   pub`become`ourc: TokenS pub``epr: pro
aller.
//! None;
-> bon th iers.** Ty `proc_macro2` types m invCursor it  pub fn s = match group {
 pan) -> Sparst) {
 self.hi ourc: TokenS pub
    }
}

impl Dstr(" rst) {
 proc_macro,
   Sofsh()pre     . Plenon
ting pub(crst) {it  pub fn s = match group {
 pan)ral:/(hidden: Span) -> Spars.**` i
 self.hi ourc: TokenS pub
    }
}

impl Drst) {
 proc_macro,
  thT   originul &(&self) ->nay fopush(tt! [`
}

#poistsay paren/-> bo a s/! [`medurd    sself) -> Sou ce.erif .
doc.d byodefa_stit  pub fn sead_ource_file(&self) -> Sou, rein: &sr: literal,
    , 
    _un.**` i))o::File#prou_attr( **_rou,rl:/(Tokeource_file(&self) -> Sour)o:: Span::call    #[cfg(fuzzing)]
        return SourceFi      retu(celf) 
o_iter().f
   #[cfg(fute Span) -> bon thtring.
 ) {
 e prself
    }

  ng.
 )(&self) ->noor= g [`
}

ay paren/-> bo a s/! [`medurd r - *resorurc`)]
pu- Cursor {"`rnStream>

    in*` i ty paren/-> bo a sW dnfexecueisplay oc_macro2` types m s.** Tybecome   }
 , Cself
    }
-> bo a s   mallermanye pfulngfroenTreedr[deriaenightndst= 0chntirhT    m ` ip> bon th = 0chntirl:e)  if have          pub fn lrap_proc_.sW dnfexecueispq(&se a smnwhile `proc_macro2` types m, suconas entireleo> m `proc_,n informan th<elf
    }

   malwaysrmanye pfulnregardl   , noof 0chntir&self, f: &mut fmt::Formatter) -#prou_attr( **_rou,rl:/(TokenStream> fo]
pu- Cursor {"r)o:: Span::call fg(fuzzing)]
        return LineColu
o_iter().f
fg(fue Span) -> bon thtring.
 endffirself
    }

  ng.
 )(&self) ->noor= g [`
}

ay paren/-> bo a s/! [`medurd r - *resorurc`)]
pu- Cursor {"`rnStream>

    in*` i ty paren/-> bo a sW dnfexecueisplay oc_macro2` types m s.** Tybecome   }
 , Cself
    }
-> bo a s   mallermanye pfulngfroenTreedr[deriaenightndst= 0chntirhT    m ` ip> bon th = 0chntirl:e)  if have          pub fn lrap_proc_.sW dnfexecueispq(&se a smnwhile `proc_macro2` types m, suconas entireleo> m `proc_,n informan th<elf
    }

   malwaysrmanye pfulnregardl   , noof 0chntir&self, f: &mut fmt::Formatter) -#prou_attr( **_rou,rl:/(TokenStream> fo]
pu- Cursor {"r)o:: Span::callg(fuzzing)]
        return LineColuto_iter().f end) Span) -> bon thC
ene,frcaew}
}

#enoenTaIdent `iter`oce.e`as us,.Span)en/-> bo a sRery.
  `.wri` ug `iter`oce.e`as us,
   m to pdif
    touspanty paren/-> bo a sWa
 isp:gcome    rlye pr[`ourc: TokenS pub::> {
`]`medurd   -> bo a snightnd-alle.sW dnfom.
  C to pNone.
 oc_macro2` types m  if the p a-> bo a snightnds:enTree>beco [`medurd [dllralwaysr   }
  `.wri`ty paren/-> bo a s[`ourc: TokenS pub::> {
`]
//!
//! - **Bring proc-macro-like funcRcVecB.S, hi tml#medurd
> {
 Option<Span> {
        #[cfg(fuzzing)]
        return {
      to_iter().f> {
 other[str("tom m( pub(celf)e Span) -> bon thCom
    httpsmatio>

 see/ifroc y'  maqualay paren/-> bo a s/! [`medurd    sself) -> Sou ce.erif .
doc.d byodefa_stit  pub fn source_file(&self) -> SourceFile#prou_attr( **_rou,rl:/(Tokeource_file(&self) -> Sour)o:: Span::calllet other = other.uzzing)]
== 0
    }
}

impl Dstr(" let other[str("t Span) -> bon thRery.
  g.
 )(&self* Ty   hie.ea`
}

as/! [`pstr rvn  g.
 originul-> bon th&(&selfisdo, loping fou
}
cnnnce.ecommibr . If aller   }
   aan {f)
 ug-> bo a st    cati, rrespond r!  reul &(&selflibrar paren/-> bo a sN th:hT   obr rvroc_ n {f)
 `procpes m s anld aller  leropl Debr Tokn-> bo a s e.erif on t! [` (&self* TyrhT   n {f)
 `prt! [`ild.rs a iathBbest-> bon thef  pt>

    u , C fmt iagnost, snalle.n<String> {
        #[cfg(fuzzing)]
        return None;

 
o_iter().f
   #[c #[cf fn fmt(&sen thPDistsla`
}

eay a  // hcon  nike r fmt     gemptylf, fmt: &mut formatter) -> fmt::Result {
        #[cfg(span_locations)]
        return wp) {
  for Litera}

imt   fn fmt(&se a sAB and
  lng(fet frc self.ded an_locati/!
cfg(fe  inn (e.g. `[1, re,o..]`).eral {
    repr: Stri enum   let mut   span:  sABang(feature =surr       b{ }
    /  self.del`.n<Str", &s(", &s), span:  sAn          _.n<Strions))her.sy,-> bon thAcoand
  pld.rub fn lc(fuzzing (`+`be`,`be`$`beetc.).n<StrPld.r(Pld.ry,-> bon thAc   #[cflc(fuzzing (`'a'`) )*)
}

 (`"hello"`) )ations,(`2.3`) )etc.
ub fn span((n span(),ne iw() -> Sel mut   span:  sRery.
  g.
 )cati`prcoisormut,  seepr.i proforurc`spub``medurd of-> bon th iers.**nti  }

g(fet frc self.ded awrite_tr) -lf.span
    }

    pub fn set_span(&mmiter::Parions)]
        tream mut::", &s( u32::tf
    f,ns)]
        tream mut::ions)) u32::tf
    f,ns)]
        tream mut::Pld.r( u32::tf
    f,ns)]
        tream mut::n span(( u32::tf
    f,ns)]
    } Span) -> bon thConfiguresorurc)catiut f*allercoisorream*ar paren/-> bo a sN throcatn frcoisorream iathB`", &s`orurneco [`medurd [dllrrif configure-> bo a st    cati`preaer:`prcomein  
  apc    .,pco [`[dllrsw() y  seepr.  ln-> bo a st   `   self.``medurd ofreaer:variint.pan) {
        self.span = span;
    }

    pub fn submiter::Parions)]
        tream mut::", &s( u32::tf
  self.slf.s),ns)]
        tream mut::ions)) u32::tf
  self.slf.s),ns)]
        tream mut::Pld.r( u32::tf
  self.slf.s),ns)]
        tream mut::n span(( u32::tf
  self.slf.s),ns)]
       type Err = LexErr<", &s IntoIterat mut   span    let p:g", &s)lder::new();

      RcVe mut::", &s(g nStream {
    fn froall(|dIntoIterat mut   span    let p:gher.sym &&::new();

      RcVe mut::ions))g nStream {
    fn froPld.rdIntoIterat mut   span    let p:gPld.rym &&::new();

      RcVe mut::Pld.r(g nStream {
    fn fron span(dIntoIterat mut   span    let p:gn span()m &&::new();

      RcVe mut::n span((g)]
impl Frnn thPDistsll(spang(fermut=PathBuf {
 rocatn   s  fas  }

    lossl   ndposthcon   ti` iw evenay forurc     ang(fermut=(modulormatio),eamcepteom(in thdocsi` tp`tream mut::", &s`s [deri`

        f.wri`  self.del`pce.erepr.insin thithinic    #[cfs.&self, f: &mut fmtterat mut   span    t::Result {
        #[cfg(span_locations)]
        return wmiter::Parions)]
        tream mut::", &s( u32::pl Debug for tt   ,ns)]
        tream mut::ions)) u32::pl Debug for tt   ,ns)]
        tream mut::Pld.r( u32::pl Debug for tt   ,ns)]
        tream mut::n span(( u32::pl Debug for tt   ,ns)]
    }fn fmt(&sen thPDistsllng(fermut=ay a  // hcon  nike r fmt     gemptylf, fmt: &mut fterat mut   span    t::Result {
        #[cfg(span_locations)]
        return w thFaer:`prcomse hasll(sp Lita  ng.
 )cVecBuepr:  nng.
 de{
  dh()
    return w thso dwr't`add e> yderianm   ra ebuns, noindfr(Clonn return wmiter::Parions)]
        tream mut::", &s( u32::p) {
  for tt   ,ns)]
        tream mut::ions)) u32::ons)]
            ;
        debug.field("sym", &format_args!("{}", !("{}", self));
        debug_span_field_if_nont)rgs!("{}", !("{}",      ug, self.span);
        debug.finish()
    tf
    f[str("tgs!("{}", !("{}", self));
           = Span {
             tream mut::Pld.r( u32::p) {
  for tt   ,ns)]
        tream mut::n span(( u32::p) {
  for tt   ,ns)]
    }fn fmt(&se a sAB self.ded ang(feature it t/in thAB`", &s`oin  
  ands:e0");
 thB`tream) -> S` push(t);
surr       b{in th`

       `{.eral {
    repr: Stri RcVecBu::Formatter) TokenS     ::For,ne in thDescribes howda an_locati/!
cfg(fe  innt);
 self.ded.eral {
    Span  reprulD)
    
   eFile {
 : Stri enum 

          span:  s`(o... )`n<StrPa   tomsis,-> bon th`{o... }`n<StrBuzze,-> bon th`[o... ]`n<StrBuzz  /,-> bon th`Øo... Ø`y paren/-> bo a sAn hoseici/  self.del,rocatnmayfnut fexaose ,bf thae compiler Tokn-> bo a scome pr to pas"pes m variid
/"e`$var`. If i//imp ptantever etr rvnq(&se a smp -> Ser eioritiro tin non-mroc_m`$var * 3` pun e `$var` i//`1let `ty paren/ Ioseici/  self.del[`;mut    survinseompil depilaba-mng(feature =thrangh-> bo a s ars.next
}

impl ,ne iw() -::Formatter)> fn) -> TokenS     ", &s)lder::new();

     ::Forma) Token: Span) -> bool n) -_ursive t> TokenSursive tnS", &s)lder::new();

     ::Formans)]
        }

im: str(" "y f        }
  } Span) -> bon thC
ene,sfrcaew}`", &s`o[derirurcumber  self.delpce.eang(feature it paren/-> bo a s/! [`";
  VecBo> ydllrsring.
 )catiut fco [`g:Formln-> bo a s` pub(crate) unsaf`. TTokhd::I
ite )catiyfi!pro
tingcome`   self.`-> bo a s;edurd belowit) -> Self {
    self.del: 

       _mut().e            .to_string()
        ::Formans)]
        }

im: s    ", &s&s if d
       _mut().e[str("t,nlf, span: Span) -> bon thRery.
  . Th_ld.rub fn lu , Casll(sp self.delput fco [`g:For:da ant of-> bon thpa   toms/s, squ   m}
    /.,pnt_curl{ }
  nnit) -> Self { self.del }

    pub

          span;

 
o_iter().f self.del t Span) -> bon thRery.
  g.
 `tream) -> S` `prc    .rocatn   m self.ded tinco   `", &s`ar paren/-> bo a sN throcatncome   }
 , Cmng(feature =l:e)  if lopingell(sp self.del-> bo a s   }
 , Cabove.{
        let mre  }

    pub RcVecBuild       }
   RcVecBuild&self) 
o_iter().f
fmre  )t Span) -> bon thRery.
  g.
 )catiut fcoe  self.del`pnfrcoisorream te(),
  )catye proc -> bon thecros  `", &s`ar paren/-> bo a s``` #[c-> bon thpf.span
    }

    pub fn set_spa/   #[cffffffff^^^^^^^-> bo a s```er) -lf.span
    }

    pub fn set_span(&m pub(celf) 
o_iter().f
    fn fmt(&s-> bon thRery.
  g.
 )catipoisti proforurcmp ye pr self.delpnfrcoisog:Forar paren/-> bo a s``` #[c-> bon thpf.span
   _mp y }

    pub fn set_spa/   #[cfffffffffffff^-> bo a s```er) -lf.span
   _mp y }

    pub fn set_span(&m pub(celf) 
o_iter().f
   _mp y fn fmt(&s-> bon thRery.
  g.
 )catipoisti proforurcclose pr self.delpnfrcoisog:Forar paren/-> bo a s``` #[c-> bon thpf.span
   _close }

    pub fn set_spa/   #[cffffffffffffffffffff^-> bo a s```er) -lf.span
   _close }

    pub fn set_span(&m pub(celf) 
o_iter().f
   _close fn fmt(&s-> bon thRery.
  ati`bjecBuecatnholdsrcoisog:For'sc`spub_mp y f`nce.q(&se a s`
   _close f`
cfged e> (ay a mor = mmpacsttrivms//// avao ecosholdispq(&se a s<ural 2smatio>indfviduille)it) -> Self { self_
    }

    pubanlimSBou   return wp)limSBou&s if Litera}

im) Span) -> bon thConfiguresorurc)catiut fco   `", &s`'s  self.del`,om tt if ltsoin  
  ap> bon th =   .ay paren/-> bo a s/! [`medurd ydllr** if**rsring.
 )catilabanitdumein  
  apc    . )catye.q(&se a sbyrcoisog:For,om ttl macro tfwdllrallersring.
 )catilabl(sp self.del-> bo a sr Toknncing.
 lsyn]ilabl(sp`", &s`ar par{
        self.span = span;
    }

    pub fn subspan<er().f
  self.slf.s[str("tgs!("{l Frnn thPDistsll(spg:FormPathBuf {
 rocatns anld    lossl   ndhcon   ti` iw eve n thiy forurc     g:Form(modulormatio),eamcepteom(hdocsi` tp`tream mut::", &s`s
n th[deri`

        f.wri`  self.del`.&self, f: &mut fmt::Formatter)> f t::Result {g(span_l
        Display::fmt(&self.repr, f)
    }
}

impl Debug for Litera}

imt  lay::fmt( fmt(&self, fmt: &mut fmt::Formatter)> f t::Result {g(span_l
        Display::fmt(&self.repr, f)
    }
}

imp) {
  for Litera}

imt  lay::fmt( fmt(&selfn thAB`Pld.r` iathBoand
  pld.rub fn lc(fuzzing roc_m`+`be`-`pnt_`#`it t/in thMf)
ic(fuzzing mp -> Se-mroc_m`+=,
   mtrivms///, Casllwong: &with roc0*`/B`Pld.r` [deridif
    toulay`pnfr` pucand`s   }
 , .eral {
    repr: Stri RcVecBuPld.r    }
}chpr = S,nlf, spucand }

 cffixed_nu
    }

  ,ne in thWhed e> aB`Pld.r` iatfo    ed tmmedine,l{ }yo, dd e> `Pld.r` mat f    ed b{in th, dd e> 

g(fet fwh.de
}
cn.eral {
    Span  reprulD)
    
   eFile {
 : Stri enum 

 cffiset_spa/   E.g. `+` i//`Alwri` un `+ =`be`+     `pnt_`+ t`.S_spaAlwri,t_spa/   E.g. `+` i//`Joist` un `+=`pnt_`'` i//`Joist` un `'#`ar paren/-> bo a sAddi againlan oand
  er th_`'` pro
> {
 [derii        _   foulayforman th<efetime//`'     `ar parJoist,ne iw() -Pld.r    }
}n thC
ene,sfrcaew}`Pld.r`  to prurcumber c(fuzzing ce.espucanday paren/-> bo a s/!h_`ch,
  gus
//);
s     a w {
  pld.rub fn lc(fuzzing p -m    dsbyrconforman th<rocuager = othwiingcomeild.rs a winitpr", ay paren/-> bo a s/!h_   }
 , C`Pld.r` [dnithave     defa_str)catilab` pub(crate) unsaf`-> bon th[ush(tpro
//eilrain.rs.*figuredo[derirurc`   self.``medurd belowit) -> Self {
   chpr = S, spucand }

 cffito_string()
        Pld.r    }
}         h,ns)]
        s
 cffixed_nu        s
   }

  (crate) unsaf,nlf, span: Span) -> bon thRery.
  . Thw {uepnfrcoisopld.rub fn lc(fuzzing r  `c(fu`ar par{
     as      }

    pub     pub fn subspan<ch fmt(&s-> bon thRery.
  g.
 )cacffisnfrcoisopld.rub fn lc(fuzzing,>indfcr.i prwhed e>-> bon thit's tmmedine,l{  f    ed b{o, dd e> `Pld.r` inll(spang(feature , sn-> bo a st  y    hdo ibrailler    mmbti  }ay fo()mf)
ic(fuzzing mp -> Se-> bo a s(`Joist`),pnt_it's  f    ed b{os {
mdd e> 

g(fet fwh.de
}
cns(`Alwri`)-> bon th&(orurcmp -> Serhaslc  tailler.    _tr) -lf.span
  cffi }

    pub fncffiset_spa            cispq(&se) -> bon thRery.
  g.
 )catiut fcoisopld.rub fn lc(fuzzing.   self.span
    }

    pub fn set_span(&mut self, span: Span) n thConfigure g.
 )catiut fcoisopld.rub fn lc(fuzzing.   self.span
  self.span = span;
    }

    pub fn subspan<R: RangeBounds<usizFrnn thPDistsll(sppld.rub fn lc(fuzzing r  hBuf {
 rocatns anld    lossl   ndposthcon   ti` iw evenay forurc     c(fuzzing. self, f: &mut fmtPld.r    }
}enStt::Result {
        Display::fmt(&self.repr, f)
    }
}

impl Debug for Litera h,   fn fmt(&self, fmt: &mut fPld.r    }
}enStt::Result { {
        let mut debug = fmt.debug_struct("Literal");
        debug.field("lit", &Pld.rargs!("{}", self.repr));
c(fudebuitera hrgs!("{}", self.repr));
   cispdebuitera   cisprsor = curso    ug, self.span);
        debug.finish()
    n { lo, histr("tgs!("{}",                        fn thABword ofrR
s  isdo, [ush(t;mut   a keyword og regur variid
/p Litit t/in thAn          _`";
 is proceatnlenotowritU", .de  .de poist,l Debusrstroc0*`/B[ush(thasll(spXID_S     prop  typce.ea   n {
 `pr[ush(thave     XID_Con.i usin thprop  tyit t/in th-s/!h_if stpte(e pr    if an          _. Ush `]
     all(|d`it t/h-sAh<efetimer    if an          _. Ush `sy     fetime`ng: &strit t/in thAn          _`";
 lit",edo[deri`all(|&s if` i//p -m    ds

    arR
s in thkeyword,   anghn rese prwritthrangh ltso[`Parse`]ngose librb fn lrejecBs
n thR
s  keywords. Ush `input.rate(all(|&s/rest)any)` y dnf rese pr!   rth(tt!sin th  havitulpnfr`all(|&s if`it t/in th[`Parse`]
//!
//! - **und  cro/    cro//rest/trait.Parse.htmlt t/in th# Exaose st t/in thABaew}     tpro
//e:
ene, C to paste(e prthe p rurc`all(|&s if` ild.rs a.
n thAcolumn;
s     purviledm  seici/ler[ush(tg
   nsll(sp Litan {
 u fn in th  havitrilabl(spn {f)
e pr         _.n t/in th```ang/
tingthe procedu  {all(|,}

  };t t/in th:calail     /   #[cfal")rate)     t= all(|&s if;
cateigraphy",}

  (crate) unsaf);t t/in th elsouistlnd_if_nonrate)     );t t/   ngth```ang/in thAn      tpro
//ein  
poone, nay foa r Tokeature =the p rurc`er th!`ypes may e/in th```ang/
tingthe procedu  {all(|,}

  };t t/
tinger th::er th;t t/in th:calail     /   #[cfal")     t= all(|&s if;
demo",}

  (crate) unsaf);t t/in th els thC
ene,frcvariid
/pbindffir[ural namer         ll(|. /   #[cfal") 
dti     ger th!    l")#     t= 10; };t t/in th els thC
ene,frcvariid
/pbindffir[deriaeslightndsdif
    to Litit t/ #[cfal")ng.
)     t= all(|&s if;ug_spand_i) -_f_non     ),}

  (crate) unsaf);t t/ #[cfal") 
dti     ger th!    l")#ng.
)     t= 10; };t t/   ngth```ang/in thAste(e prtrivms//// avao`prcomei    t   rap_proc_ thrangh rurc`to_te(e paf`- a s;edurday e/in th```ang/
#
tingthe procedu  {all(|,}

  };t t/
#ang/
#
al")     t= all(|&s if;
, dd e>_         _",}

  (crate) unsaf);t t/
#ang/
   Exaoinercomei    tr  hBuf {
 it t/ al")     _te(e pt=  ll(|.to_te(e paf;t t/
if)     _te(e p.l y f > 60   /   #[cfouistlnd_iVerd lo pr         _: f_non     _te(e p)t t/   ngth```aral {
    repr: Stri RcVecBuall(|matter) TokenS     all(|,pub f_R_MA r: M_MA r,ne iw() -all(|matter)> fn) -> TokenS     her.sym &&::new();

     all(|matter)ed>"),
 }

imturn Ok(litera_R_MA r: M_MA r,nlf, span: Span) -> bo a sC
ene,sfrcaew}`I    `p[derirurcumber `te(e p`fi// wllCasll(sp}
annote.q(&se a s`
   `ay paren/-> bo a s/!h_`te(e p`fi gus
//);
s     a w {
           _`p -m    dsbyrconforman th<rocuager = othwiingcomeild.rs a winitpr", ay paren/-> bo a sN throcatn`
   `,hiur   tly tinringc,rs.*figuresll(sphygikeer    pub fn -> bo a sut fcoiso         _.n<Stren/-> bo a sA`pnfrcoisorimer` pub(crate) unsaf`m  seici/leropts-inllo "lrsi-e()
"-> bo a shygikeermanye procatii        _  :
ene, C[derit! [`
}

#[dllr   ct which-> bo a s //ifroc y wn es      } directnd aing.
 lCursor rate. Thional lrsi,nce.q(&se a smain.rs.de aing.
 ional lrsime()
 [dllr   id
//!  ref  
cf= gemfi// wll.
  Spen/-> bo a sLne,rsmatio>roc_m` pub(c_site()
  ` [dllral   !   mpt-inllo-> bo a s"defth a r -e()
"shygikeermanye procatii        _  :
ene, C[derit! [-> bon th&}

#[dllr   ct which  ing.
 lCursor rate. Thional defth a r mce.e.d e>-> bon ths.de aing.
 ional lrsime()
 [dllr        d
//!  ref  
cf= gem.
  Spen/-> bo a sDueroforurccur   toimp ptanati/!
hygikeert! [`";
  VecBo>, unroc_e.d e>-> bon thc    .,pr - *resoa ` pub`s

    }
annote. ain";
  VecBor it  puen/-> bo a s#  }", sy paren/-> bo a sPr", sngfrcomeinput te(e pr    eid e> aBkeyword nt frcregur variid
/-> bo a snLitioIffyou
   m    surerwhed e> t!    Displ".0");
  an          _nce.q(&se a sneed}

 hce.l   i ey fon non,
tinq(&se a s<a href="/!
//! - **und  cro/    cro/fna/rest)  D.html"><s.det_spa/   #[ogo=do"padding-right:0;">sy   /rest)  D</s.de></a><s.det_spa/   #[ogo=do"padding-left:0;">::&lt;I    &gt;</s.de>-> bo a s  macro ecosyall(|&s if`it) -> Self {
     Disp> {
  n;
    }

     &&::new();

     all(|d_elf)      all(|&s if;  Dispn;
   [str("te Span) -> bon thSamerr  `all(|&s if`,om ttc
ene,sfrcraw          _n(`r#     `)rhT  q(&se a s`
e(e p`fi gus
//);
s     a w {
           _`p -m    dsbyrconh<rocuage-> bo a s(loping foukeywords, e.g. `fn`)rhKeywordsr[ush(t   musroc_ totself-> bon th&egmibr  (e.g. `iter`, `i    `)
   m    supp pted, ce.e[dllrsatinga-> bon thpa", ay par Self {
  _raw   Disp> {
  n;
    }

     &&::new();

     all(|d_elf)_raw   Dispn;
   ) Span) -> bool n) -_raw   Disp> {
  n;
    }

     &&::new();

     all(|d_elf)      all(|&s if_raw   Dispn;
   [str("te Span) -> bon thRery.
  g.
 )cati`prcoiso`I    `.er) -lf.span
    }

    pub fn set_span(&m pub(celf) 
o_iter().f
    fn fmt(&s-> bon thConfiguresorurc)cati`prcoiso`I    `,hdocsi` tpkhd::e pr r  hygikee-> bon ths.** Tyar par{
        self.span = span;
    }

    pub fn subspan<er().f
  self.slf.s[str("tgs!("{l Frnw() -PFile {
 sut fall(|matter)> flet other = other.her.sym &&== 0
    }
}

impl Dstr(" == other[str("s!("{l Frnw() <T>-PFile {
 <T>-ut fall(|
pun es!("{T: ?Siz ds+sA`Ref<  D>,
atter)> flet other = other.Tym &&== 0
    }
}

impl Dstr(" == otherfn fmt(&sem {
   sut fall(|maFrnw() -PFile {Ordsut fall(|matter)> fpFile {_cmpt other = other.her.sym &&]
     O_ORDe p>rn SourceFi  mi
 sel.cmpt= othfn fmt(&self, fmtOrdsut fall(|matter)> fcmpt other = other.her.sym &&]_ORDe p
    }
}

impl Dto_te(e paf.cmpt other[to_te(e pafn fmt(&self, fmtHashsut fall(|matter)> fhash<H: Hasher>t other hasher
      H)
    }
}

impl Dto_te(e paf.hash(hashertgs!("{l Frnn thPDistsll(sp         _ncathBuf {
 rocatns anld    lossl   ndhcon   ti` iw eve n thiy forurc              _.nself, f: &mut fmtall(|matter)> ftt::Result {
        Display::fmt(&self.repr, f)
    }
}

impl Debug for Litera}

imt   fn fmt(&sem {
 mt: &mut fall(|matter)> ftt::Result {
        Display::fmt(&self.repr, f)
    }
}

imp) {
  for Litera}

imt   fn fmt(&se a sAB   #[cfl*)
}

 (`"hello"`) )bytel*)
}

 (`b"hello"`) )c(fuzzing (`'a'`) in th ytelc(fuzzing (`b'a'`) )

eaytegng mr flor.i prpoist)ations,[derios,[derou in thhBuuffix (`1`, `1u8`, `2.3`, `2.3f32`).e e/in thB= 0eati{  #[cfs>roc_m`    `bce.e`fcfsi`  or      lo prun etelemy)    ngth`I    `{.eral {
    repr: Stri RcVecBun span(tter) - TokenS     t span(,pub f_R_MA r: M_MA r,ne i$($name:ide!Buuffixed_ist_{  #[cfs>ter) -($($nLit:     t=> $kind:     ,)*u32::($( return w tthC
ene,sfrcaew}
uffixedeaytegng    #[cfl[derirurc 
annote. w {ue. return w tt return w tthT! [`ild.rs a [dllrs
ene,frneaytegng   c_m`1u32` pun e dumein  g).o compile tthw {uep 
annote. isorurcusrstrpFilrate. Thr Tokece.ea   in  g[cfl [-> bo> bo a s lsot
uffixedeaing.
 end.un span(se:
ene, C to prepr.ins)ations[`;mu-> bo> bo a s    survinseompil deps thrangh `tream) -> S` `rl*)
}

`pce.e;mut  -> bo> bo a sbrng(feay forwfor Toknn(`-`pce.eloe()inse   #[cf). return w tt return w tthn span(se:
ene, Cthrangh ru [`medurd have     ` pub(crate) unsaf`-> bo> bon th&}

#byodefa_st,h[ush(tpro
//es.*figuredo[derirurc`   self.``medurd-> bo> bo a sbelowit) -> par{
     $nLit(  }$kind)]
    span(tter) ---------  span(d_elf)        span(d_$nLit( ))nlf, span: Span)*une i$($name:ide!Bunuuffixed_ist_{  #[cfs>ter) -($($nLit:     t=> $kind:     ,)*u32::($( return w tthC
ene,sfrcaew}unuuffixedeaytegng    #[cfl[derirurc 
annote. w {ue. return w tt return w tthT! [`ild.rs a [dllrs
ene,frneaytegng   c_m`1` pun e dumein  g).o compile tthw {uep 
annote. isorurcusrstrpFilrate. Thr Tok. Not
uffixl [-> bo> bo a s 
annote. on t! [`r Tok,rmanye procatiinvCursor s>roc_-> bo> bo a s`  span(d_i8_unuuffixed(1),
   m - **Make rlo-> bo> bo a s`  span(d_u32_unuuffixed(1),.un span(se:
ene, C to prepr.ins)ations[-> bo> bo a s;mut    survinseompil deps thrangh `tream) -> S` `rl*)
}

`pce.e;mu-> bo> bo a sbesbrng(feay forwfor Toknn(`-`pce.eloe()inse   #[cf). return w tt return w tthn span(se:
ene, Cthrangh ru [`medurd have     ` pub(crate) unsaf`-> bo> bon th&}

#byodefa_st,h[ush(tpro
//es.*figuredo[derirurc`   self.``medurd-> bo> bo a sbelowit) -> par{
     $nLit(  }$kind)]
    span(tter) ---------  span(d_elf)        span(d_$nLit( ))nlf, span: Span)*une iepr: S span(tter) -> fn) -> TokenS     n span()m &&::new();

       span(tter) ---------}

imturn Ok(litera_R_MA r: M_MA r,nlf, span: Span) -> bool n) -_ursive t> TokenSursive tnSn span()m &&::new();

       span(tter) ---------}

im: str(" "y f        }
    }
_R_MA r: M_MA r,nlf, span: Span) -> bouuffixed_ist_{  #[cfs!tter) -----u8_uuffixede2::u8,nlf, spanu16_uuffixede2::u16,nlf, spanu32_uuffixede2::u32,nlf, spanu64_uuffixede2::u64,nlf, spanu128_uuffixede2::u128,nlf, spanusiz _uuffixede2::usiz ,nlf, spani8_uuffixede2::i8,nlf, spani16_uuffixede2::i16,nlf, spani32_uuffixede2::i32,nlf, spani64_uuffixede2::i64,nlf, spani128_uuffixede2::i128,nlf, spanisiz _uuffixede2::isiz ,nlf, ) -> bounuuffixed_ist_{  #[cfs!tter) -----u8_unuuffixede2::u8,nlf, spanu16_unuuffixede2::u16,nlf, spanu32_unuuffixede2::u32,nlf, spanu64_unuuffixede2::u64,nlf, spanu128_unuuffixede2::u128,nlf, spanusiz _unuuffixede2::usiz ,nlf, spani8_unuuffixede2::i8,nlf, spani16_unuuffixede2::i16,nlf, spani32_unuuffixede2::i32,nlf, spani64_unuuffixede2::i64,nlf, spani128_unuuffixede2::i128,nlf, spanisiz _unuuffixede2::isiz ,nlf, ) -> bo tthC
ene,sfrcaew}unuuffixedeflor.i p-poist){  #[cfit paren/-> bo a s/! [`";
  VecBo>  [`
imila 
cf= gral   c_m`  span(d_i8_unuuffixed` pun e-> bo a st   flor.'shw {uep [`if    dsdirectnd iy forurcr Tokem tt it
uffixl [-> bo t/
tind, sno tf;mut   inferr ds

    ar`f64` one,r inll(sp:enTree>ty paren/ n span(se:
ene, C to prepr.ins)ations[`;mut    survinseompil- deps-> bo a st rangh `tream) -> S` `rl*)
}

`pce.e;mut  sbrng(feay forwfor Toknn(`-`-> bo a s e.eloe()inse   #[cf). retuen/-> bo a s#  }", sy paren/-> bo a sT! [`ild.rs a r - *resoruatirurc 
annote. flor. iatfth aefnut fexaose -> bon thifo tf      th ay `rlNaNrt! [`ild.rs a winitpr", ay par{
     f64_unuuffixed({
 f64)]
    span(tter) -----    rt!(f ")?fth ae()rgs!("{}",   span(d_elf)        span(d_f64_unuuffixed({te Span) -> bon thC
ene,sfrcaew}
uffixedeflor.i p-poist){  #[cfit paren/-> bo a s/! [`";
  VecBo> [dllrs
ene,fr    #[cfl  c_m`1.0f64` pun e dumew {ue
> bo a s 
annote. isorurcpre eg foupFilrate. Thr Tokece.e`f64` isorurc uffixlof-> bon th ierr Tok. Toisorream [dllralwaysr   inferr ds

    ane`f64` inrconforman th:enTree>t n span(se:
ene, C to prepr.ins)ations[`;mut    survins-> bo a s mpil- depsst rangh `tream) -> S` `rl*)
}

`pce.e;mut  sbrng(feay forwf-> bo a sr Toknn(`-`pce.eloe()inse   #[cf). retuen/-> bo a s#  }", sy paren/-> bo a sT! [`ild.rs a r - *resoruatirurc 
annote. flor. iatfth aefnut fexaose -> bon thifo tf      th ay `rlNaNrt! [`ild.rs a winitpr", ay par{
     f64_uuffixed({
 f64)]
    span(tter) -----    rt!(f ")?fth ae()rgs!("{}",   span(d_elf)        span(d_f64_uuffixed({te Span) -> bon thC
ene,sfrcaew}unuuffixedeflor.i p-poist){  #[cfit paren/-> bo a s/! [`";
  VecBo>  [`
imila 
cf= gral   c_m`  span(d_i8_unuuffixed` pun e-> bo a st   flor.'shw {uep [`if    dsdirectnd iy forurcr Tokem tt it
uffixl [-> bo t/
tind, sno tf;mut   inferr ds

    ar`f64` one,r inll(sp:enTree>ty paren/ n span(se:
ene, C to prepr.ins)ations[`;mut    survinseompil- deps-> bo a st rangh `tream) -> S` `rl*)
}

`pce.e;mut  sbrng(feay forwfor Toknn(`-`-> bo a s e.eloe()inse   #[cf). retuen/-> bo a s#  }", sy paren/-> bo a sT! [`ild.rs a r - *resoruatirurc 
annote. flor. iatfth aefnut fexaose -> bon thifo tf      th ay `rlNaNrt! [`ild.rs a winitpr", ay par{
     f32_unuuffixed({
 f32)]
    span(tter) -----    rt!(f ")?fth ae()rgs!("{}",   span(d_elf)        span(d_f32_unuuffixed({te Span) -> bon thC
ene,sfrcaew}
uffixedeflor.i p-poist){  #[cfit paren/-> bo a s/! [`";
  VecBo> [dllrs
ene,fr    #[cfl  c_m`1.0f32` pun e dumew {ue
> bo a s 
annote. isorurcpre eg foupFilrate. Thr Tokece.e`f32` isorurc uffixlof-> bon th ierr Tok. Toisorream [dllralwaysr   inferr ds

    ane`f32` inrconforman th:enTree>t n span(se:
ene, C to prepr.ins)ations[`;mut    survins-> bo a s mpil- depsst rangh `tream) -> S` `rl*)
}

`pce.e;mut  sbrng(feay forwf-> bo a sr Toknn(`-`pce.eloe()inse   #[cf). retuen/-> bo a s#  }", sy paren/-> bo a sT! [`ild.rs a r - *resoruatirurc 
annote. flor. iatfth aefnut fexaose -> bon thifo tf      th ay `rlNaNrt! [`ild.rs a winitpr", ay par{
     f32_uuffixed({
 f32)]
    span(tter) -----    rt!(f ")?fth ae()rgs!("{}",   span(d_elf)        span(d_f32_uuffixed({te Span) -> bon th   ret){  #[cfit par     let me pa  Disp> {
  )]
    span(tter) -----  span(d_elf)        span(d_t me pa  Dispte Span) -> bon thC(fuzzing ro #[cfit par     lec(fuzzing chpr = S)]
    span(tter) -----  span(d_elf)        span(d_c(fuzzing chte Span) -> bon thBytel*)
}

 ro #[cfit par     le yte_te(e pas> {[u8])]
    span(tter) -----  span(d_elf)        span(d_ yte_te(e paste Span) -> bon thRery.
  g.
 )catienoenTaIdent t! [`{  #[cfit par     let    }

    pub fn set_span(&m pub(celf) 
o_iter().f
    fn fmt(&s-> bon thConfiguresorurc)cati   ocine, Cut fcoiso{  #[cfit par     let  self.span = span;
    }

    pub fn subspan<er().f
  self.slf.s[str("tgs!("{l -> bon thRery.
  a ` pub`s
catn   hBuubant of `iterf
    f`l".0");
e prwrly-> bo a st    (&self yteo tinrd::I
`rd::I`.sRery.
  `.wri` ug t   wanld-be-> bo a strtmmed`
}

eassmnwhile t   bmpils of `iter`ty paren/-> bo a sWa
 isp:gcome    rlye pr[`ourc: TokenS  span(d_tubapub`]`medurd   -> bo a snightnd-alle.sW dnfom.
  C to pNone.
 oc_macro2` types m  if the p a-> bo a snightnds:enTree>beco [`medurd [dllralwaysr   }
  `.wri`ty paren/-> bo a s[`ourc: TokenS  span(d_tubapub`]
//!
//! - **Bring proc-macro-like funcRcVecB.  span(i tml#medurd
tubapubt par     letubapub<R: Rd::IBmpils<usiz >>t other rd::I: Rng)]
        return {
      to_iter().ftubapub(rd::Itom m( pub(celf)e Span) -> bon ams:.    iut fcoe `er th!`ypes ms

 tingy dnf";
  VecBo p ac_mac-rocedu-> bon a

g(fetu
 `procpes mme:ide $:   #[cflr Tok,rpush(t);
al-> dy knowns

   -> bon aa w {
  {  #[cfisT! [`avoidsr   rese p/w {
 r.i prohse   #[cf'shte(e p-> bon atrivms//// ava
//! [`iso if    lic APImdd e> 
hatiut fer th. pan)ral:/(hidden: Span) -> unuafekenStreamte(_unkhecked(triv> {
  )]
  ::new();

       span(d_elf)        span(d_freamte(_unkhecked(triv) nStream {
    fn fr   t fmt: span(tter) -epr: Err =t:::Forma;
 span    letmte((triv> {
  )]
  r, f)
<Sther :::Formaurn {
      triva/rest(tom m(  span(d_elf)tom m_err(|er().|t:::Formatter) ---------}

imturn Ok(litera_R_MA r: M_MA r,nlf, span:n fmt(&self, fmt: &mut fmtS span(tter) -> ftt::Result {
        Display::fmt(&self.repr, f)
    }
}

imp) {
  for Litera}

imt   fn fmt(&seepr:  f: &mut fmt: span(tter) -> ftt::Result {
        Display::fmt(&self.repr, f)
    }
}

impl Debug for Litera}

imt   fn fmt(&sen thP  lic gose librb fn lde");lsiut fcoe `tream) -> S` epr:, suconas  span Se-.Stri mo Cmng(f_sBuild       ting ue,
::R_MA r::M_MA r;     ting ue,
::{gos, tream mut};     ting oreg for::{esult p) {
};
 span -> uing ue,
::tream) -> S;
-> bo a sAn hspan Se 
    `tream) -> S`'sc`tream mut`say paren/-> bo a s/!h_hspan s a iat"shal   ", e.g. t!h_hspan fmt oesr't`re uesteay f-> bo a s self.ded g:Fors, ce.e   }
   whol  g:Forslr   fg(fe  inn. pan)ral {
    repr: Sspan -> RcVecBuay fI      span;

  TokenS     tream mutI   ,nlf, span_R_MA r: M_MA r,nlf, ) -> bow() -aspan fmtut fay fI      span;

 epr: I  m =ttream mut;
-> bor) -> fn#[cfgan = spang)]
       tream mut::ons)]
        to_iter().fn#[cf fn fmlf, ) -> bor) -> fsiz _e.
cfg(fuzzing)(usiz ,
       usiz >):ons)]
        to_iter().fsiz _e.
cf)nlf, span: Span) -> bom {
 mt: &mut fay fI      span;

 > ftt::Result {
        Display::fmt(&self.repr, f)
    }
}

im;

 >.    e_te((" RcVecBuild ")?;  }
}

im;

 >.ug, seliscf).e  dees
 sel.crepr fn);
           = Sp: Span) -> bom {
 ay fI   n fmtut f RcVecBuild       }
  epr: I  m =ttream mut;
    }
  epr: Iy fI    = Iy fI   ;
-> bor) -> fay f_.del (fuzzing)ay fI      span;

     ay fI      span;

     ;

  TokenSmpl Dstr(" "y f_.del        }
    }
tera_R_MA r: M