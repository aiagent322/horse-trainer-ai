//! Defines conversion traits between Rust types and NumPy data types.

use std::{mem, os::raw::c_int, ptr};

use ndarray::{ArrayBase, Data, Dim, Dimension, IntoDimension, Ix1, OwnedRepr};
use pyo3::Python;

use crate::array::PyArray;
use crate::dtype::Element;
use crate::error::MAX_DIMENSIONALITY_ERR;
use crate::npyffi::{self, npy_intp};
use crate::sealed::Sealed;
use crate::slice_container::PySliceContainer;

/// Conversion trait from owning Rust types into [`PyArray`].
///
/// This trait takes ownership of `self`, which means it holds a pointer into the Rust heap.
///
/// In addition, some destructive methods like `resize` cannot be used with NumPy arrays constructed using this trait.
///
/// # Example
///
/// ```
/// use numpy::{PyArray, IntoPyArray};
/// use pyo3::Python;
///
/// Python::with_gil(|py| {
///     let py_array = vec![1, 2, 3].into_pyarray(py);
///
///     assert_eq!(py_array.readonly().as_slice().unwrap(), &[1, 2, 3]);
///
///     // Array cannot be resized when its data is owned by Rust.
///     unsafe {
///         assert!(py_array.resize(100).is_err());
///     }
/// });
/// ```
pub trait IntoPyArray {
    /// The element type of resulting array.
    type Item: Element;
    /// The dimension type of the har) {
    let nddrop( resized when its >));

            sar                        h_gil(|py| {
///     let py_ar{
///     lays constructed usingsy.resize(10esiza`
/// use nu.      leunwrap(), &[_inserPySlict_or_try_init(py, ||wrap(ement;
<    er.fold(    er   >;     deb<Tzed when >m: Element;
 t = Box<[T]hMap::wirop( resinlyT;il(|py| {
///nly::d       letunwrap(), &[_inserPySlict_or_try_init(py, ||wrap(ement;
<    er.fold(    er   >t_eq!(shared.ves into [`addreray`].
///
///e entryPySl)       if ptr_    0);   ([s into [`    ])       if ptr_trides.ite[n, ust  /_o er<T>dividieContainshared4);

;

      which mean100) {
   ters.
 afean1diser = FxHed.f`10esiz`reray`].
///
///`e GCD of all izaif ba//   #[sert!(key1   Box<[T]hMsome d00)curren .
 noert!(not divide thc.f.03
      g/
/ub4];m/ptr_diff /// });-on, -gudesl::{m/iseu{m/326
ssert_eq!(data_ra;

   s into [` ;

 iding_stT #[test]
    fn witress(py, d(), gcd).unwrainto    ,_trides.d wh     ,ayObject)  s into [`)let range =  deb<Tzed when >m: Element;
 t = Vec<T>Map::wirop( resinlyT;il(|py| {
///nly::d       letunwrap(), &[_insergs = &mut t_or_try_init(py, ||wrap(ement;
<    er.fold(    er   >t_eq!(shared.ve    0);   ([nwrap     ])       if ptr_trides.ite[n, ust  /_o er<T>dividieContainshared4);

!(data_ra;

   nwrap whh_de      #[test]
    fn wi             ress(py, d(), gcd).unwrag::new("_RUST_NUMPY_BORROW_CHECKING_A    ,= itemsize;
    }

ides.d wh     ,BORROW_CHECKING_A Object) -> (*mut         reray`].
///
///e entryPySl)G_API", capsuley {
    let range =  deb<Ae::>m: Element;
 t = 3::Python<pe::Eleme<A>e::> let first Azed when G_API"D     let py(test)]
rop( resinlyA;il(|py| {
///nlyD       letunwrap(), &[_inserPySlict_or_try_init(py, ||wrap(ement;
<    er.fold(    er   >t_eq!(shareress(py, d(), .is_e_), &[1, , nwra)t range = is trait takes ownership o      self`, which mes it holds a pointer into the Rust heap.
`&structr()s interio, some destructivalf64>t meanr_try_it be ted utrrayduce`  trueension   trure// use pyo3::Pythons;
///
/// Python::with_gil(|py| {
/// T let py_array = vec![1, 2, 3].into_pyarray(py);
///
///     assert_eq!(py_array.readonly().as_slice().wrap(), &[1, 2, 3]);
///
///     // Array cannot be resized when its data is owned by Rust.
/// ng array.
   3]);
///Duor.
 ducy FxHashMelion  ,PyArra this em, os:t//usn-s iniguoususe nump.
 C-or {
 s iniguoususe num.;
///
/// Python::with_gil(|py| {
/// T let py_array = vec};
use pyo
us3, narray = vec![1, 2, 3].into_pyarray(py);
///
///     assert_eq!(py_arrreadonly
us3(&[[d by Rust, [4, 5, 6]t, [[7, 8, 9t, [t(py) by12]]] type of re_array.readonlycannoten itss![.., 0.view..]).wrap(), &[1, 2, 3]);
///
///     // Array cannot be resized wh), &[1),y
us3(&[[d by Rustt, [[7, 8, 9t]]  type of reait IntoPyArray { elc_s iniguousnt type og array.
    type ItemTlement;
    /// The dimension type of the har) {
    let nddrop( resized when its >));

            sar                        h_gil(|py| {
///     let py_ar{
///     ce`  trues inon tch meaacquir()`&struct0esiza`new.
 alf64>t d`
/// use nu.      lewrap(), &[_inser&PySlict_or_try_init(py, ||wrap(ement;
<    er.fold(    er   >;     deb<Tzed when >mTlement;
 t = [T]Map::wirop( resinlyT;il(|py| {
///nly::d       letwrap(), &[_inser&PySlict_or_try_init(py, ||wrap(ement;
<    er.fold(    er   >t_eq!(shareress(py, d(), en its, , nwra)t range =  deb<Se::, A>mTlement;
 t = 3::Python<Se::> let first S:

use<d whnlyA>G_API"D     let py(trst Azed when G_est)]
rop( resinlyA;il(|py| {
///nlyD       letwrap(), &[_inser&PySlict_or_try_init(py, ||wrap(ement;
<    er.fold(    er   >t_eq!(share = pyray  nwrap     ;(entry) => {
  nwrapor {
 PyArray_Check(pyray1<    )aw_pAer.S_COPYashMap::with_capacity_   iicts(&self,d00)c iniguous, ducyctivr()`ducyt arasesl      `.      assert_eq!(same_rides.itenwrapeCon            });
    }
}
      fn wi              let base = base_address(py, rrayuninits, , nwra.gcd)   1),ytrides.d wh     ,a    ), -1);
               the :ducyt arasesl      (nwrap wh     ,a_with_non_di,pyra), -1);
               self, othe                                        _ashMap::with_capacity_   iicts(&self,d00)    c iniguous, ducyc assension   r()`3::Python::use `.      assert_eq!(samed//nlynwra.gcd)   1)   });
    }
}
      fn wi              let base = base_address(py, <Ae:as_arraainto   

            let loca let base = gs =ta_ra;

   _with_non_di      let loca let bast = end ize *wra.tor::r);
                    }

 gcd(self.ags(pyend .cangekey, -1);
               }

 gcd(self, array.elf.   cold(
               }

 } -1);
               self, othe                                    }
    /// exce pyfeatur"arr"nalgebra")]  deb<N, R, Cd( >mTlement;
 t = nalgebra::Maridx<N, R, Cd( > let first N: nalgebra::Scalar +ed when G_API"R: nalgebra::rate_API"C: nalgebra::rate_API"S: nalgebra::Storage<N, R, C>G_est)]
rop( resinlyN;il(|py| {
///nlying RusIx2_ar{
///   Noteent to he`
/// use nuc awnumpnce Fore Ina tmory layoutr{
///   > {
  FxHashM[ tmory layout][ tmory-layout]///
//r()[`nalgebra poi{
///  r{
///   [ tmory-layout]:03
      nalgebra= unsdocs/faq/#wt t-is-ash- tmory-layout-of-maridces     letwrap(), &[_inser&PySlict_or_try_init(py, ||wrap(ement;
<    er.fold(    er   >t_eq!(share   fn wi             e = base_address(py, <Ne:as_arraainto(nwrapn       anwrapncolsnt ,Borro      let borrow_flgs =ta_ra;

   _with_non_di      let locaape.s = gcd({ elc iniguousnt);
                the :ducyt arasesl      (nwrapgcd({     ,ayObject)  nwrap     wrap();
            }
        }
    }

 t = end ize *wra.tor::r);
                    gcd(self.ags(pyend .cangekey, -1);
               gcd(self, array.elf.   cold(
                                           self, othe    }
    /// e ty(ing R)pe Itemss(pyExtsult<(), (eCon        &PySly, ||[ntainer:eContain; 3e_base_a, (or {
 &PySly, || I::Iteon, I>;     deb<Ae:Se::>mss(pyExtst = 3::Python<Se::> let first S:

use<d whnlyA>G_API"D     let py(tult<(), (eCon        &PySly, ||[ntainer:eContain; 3e_t_eq!(shared.verrides.itenwrap            });
   t start = 0;
  n, ust  /_o er<A>dividi.all(|dim| *f reait Intotrides.d} else<= 3e, "{}", sealed::Sealed;
use cr    *readers -= gs =rraytrides.ite[0; 3e_balet offset = iize 0.vtrides.d} else;
            rraytrides.[i]    trides.[i] *tart = 0;ividieCoiner:eContain;a.offset(start) };
 rraytrides.ey) {
        lor {
 &PySly, || I::Iteon, I>e;
        ape.s =  elsta};
ud_layout PyArray_Check(pyray1<eCoiner:NPY_ORDERr:NPY_CORDERvidi_) array = base as *mnwrapn   1)e {
 &&ynwra.gcd)borrzedret ta_e_)x      elsta};
ud_layout PyArray_Check(pyray1<eCoiner:NPY_ORDERr:NPY_FORTRANORDERvidi_) array = base asArray_Check(py:<Py othe    }
    /// e/   Utilitye Rust ho specifyHashMts((*array)   anuse nu.  type ItemTlNpy   s     let py +eait frsArray_#[doc(hiddra)       len   _c, I &PySly, ||on, IsArray_Checnwrapn   1)eidion, I
    }
    #[doc(hiddra)       le wh    h    ss).unwra};

      eCoiner:eContainsArray_Checnwrapt type&key)p wh      iding_steCoiner:eContain
    }
    #[doc(hiddra)       lewran]", Nms ss).unwra};

 eCoiner:yObject;   ssArray_CheceCoiner:yObject;   ssArray_Chec    the  nwrap wh    h    )G_API", capsul} e:cnwrapn   _c, I )G_API", caet range =  deb<D>mTlNpy   set = D       D     let py {/ e/   T Item debwhen 
//r()ich mest tocanue
///
//ho index anuse nu. nter into thetheequivt fntes it };
use pyNdIndex`] bse =ccoun   t =r int
/// utrides.ibekey1.ce  .res

  yt meansteads

 ension  . nter intAassich mesome d0debwhen it rray;
use cra`] 0debwhen iyArray};
/ idiwell.r into thetnclues.ia pyrastr int- [tuebw](3
      doc.ptr_diff = unsstablesstd/primiusin.tuebw.html)r int- [
use ](3
      doc.ptr_diff = unsstablesstd/primiusin.se nu.html)r int- [t typ](3
      doc.ptr_diff = unsstablesstd/primiusin.t typ.html)r type ItemNpyIndex:Array;
use cra +eait frsArray_#[doc(hiddra)       le
   c    ed<T>dPySlicd  s  &[fe { ],ytrides.  &[.all(]y, || I::Ite.all(>;rray_#[doc(hiddra)       le
   unc    ed<T>dPySlictrides.  &[.all(]y, ||.all(|d =  deb<D:Array;
use cra>eait frst = D { =  deb<D:Array;
use cra>eNpyIndexst = D {      le
   c    ed<T>dPySlicd  s  &[fe { ],ytrides.  &[.all(]y, || I::Ite.all(>t_eq!(shared.ve.conflictenwrapunwrats((*arra     });
   t staconflicteaconfliten its.remove(&key).uaconflit} else!=cd  sd} else;
            des, nd:<Pyey {
    let ran&key).uaconflitde;

      d  s)       iicd)| ii>=cdse;
            des, nd:<Pyey {
    let
Check(pyray1<
   unc    ed_ deber<T>daconfli,ytrides.wKey) {
        l
   unc    ed<T>dPySlictrides.  &[.all(]y, ||.all(t_eq!(shared.ve.conflictenwrapunwrats((*arra     });
   t staconflicteaconfliten its.re });
   
   unc    ed_ deber<T>daconfli,ytrides.w c_char) {
  
   unc    ed_ deb<T>daconfli  &[fe { ],ytrides.  &[.all(]y, ||        return 1= 0;
  n, ust  /_o er<T>dividi.all(|dim| *aconflie });
   her) && *writers           if *