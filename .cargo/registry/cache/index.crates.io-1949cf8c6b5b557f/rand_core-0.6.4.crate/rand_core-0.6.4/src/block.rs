// Copyright 2018 Developers of the Rand project.
//
// Licensed under the Apache License, Version 2.0 <LICENSE-APACHE or
// https://www.apache.org/licenses/LICENSE-2.0> or the MIT license
// <LICENSE-MIT or https://opensource.org/licenses/MIT>, at your
// option. This file may not be copied, modified, or distributed
// except according to those terms.

//! The `BlockRngCore` trait and implementation helpers
//!
//! The [`BlockRngCore`] trait exists to assist in the implementation of RNGs
//! which generate a block of data in a cache instead of returning generated
//! values directly.
//!
//! Usage of this trait is optional, but provides two advantages:
//! implementations only need to concern themselves with generation of the
//! block, not the various [`RngCore`] methods (especially [`fill_bytes`], where
//! the optimal implementations are not trivial), and this allows
//! `ReseedingRng` (see [`rand`](https://docs.rs/rand) crate) perform periodic
//! reseeding with very low overhead.
//!
//! # Example
//!
//! ```no_run
//! use rand_core::{RngCore, SeedableRng};
//! use rand_core::block::{BlockRngCore, BlockRng};
//!
//! struct MyRngCore;
//!
//! impl BlockRngCore for MyRngCore {
//!     type Item = u32;
//!     type        t be copieB 16]/!
//! impppppfnnerated
/(&mstd
 an,sult ofs: &mstdf::Ite    t b)//!     typ unleslemented as!()!     typ}!    }!
//! impl BlodableRng};
r MyRngCore {
//!     type Itedable cop8; 32];! impppppfnnm_u64dinge [`d:df::Itedabl) ->df::I//!     typ unleslemented as!()!     typ}!    }!
//! impoption. Ty, runo implement `CrptoRng` mr MyRngCore {
!
//! impoptFl vers
//!
// let mstdr mr= ckRng::inn<ngCore {
>eed_from_u64` f(0);! impnted ln!("Firverses d: {}",dr m.t_u32_vi());! imp

Ra
//! implockRngCore`] tr:ate) plock::{BlckRngCore`] ! implol_bytes`], wngCore`,
ill_bytes`. 

 rante) plols onBlol_byt_fil_viachun or l_byt_fil_64achun o//! rante) plo{ptoRng` m, or` t, Core, SeedableRng};
//! rant`,
ilvert th::AsRef/! rant`,
ilfmt;
#[cfg(ture can= rde"] 1")]! rande"] lo{erialize` feedalize` f//!! i/fewit is  RNG
imsich gennot moderate a bdom number gesdividual or run proin! i/fck::{the yplly
#  `opieB N] This meatechnique conspn
  lyed to by! i/fctoRnggperh gG
imsitoprove genformance (#/!
//! i/fSthe ver[ules t][te) plock::{]cumentation (do details.
   pubwit is ckRngCore for   "sh i/f    t beeent `Cre It, . `ran` (#  Notpe Item = ;
  "sh i/f    t bee Ithis is pri ver'ck::{' "AS
implementing theockRngCore`] t  "sh i/ferate a which canl likully, r awar carraykely  `opieB 16]#  Notpe IteRlt ofs: AsRefelf::Item]>`.  + ut<[Self::Item]>`.  + Dult, b;
  "sh i/fGrate a blonewock of datult ofs  Notpfnnerated
/(&mstd
 an,sult ofs: &mstdf::Ite    t b);
}!! i/fewppers.
pe Itelementing thengCore`] met dete clie Itelementing th! i/flockRngCore`] trah `std` (#1arraykfers n; i.this cratbe used to derlementing! i/fall `st
impm rest usaaetraated
/unctionali/!
//! i/f `Bloe` is lds ey notawarcsaridocuctly.
/n pro regis  t befers ny not be/!
// P
implementingons aretbe slemese in ape and lias!
// (`pubwi andngCorr= ckRng::i<ngCore {
>;`)n promt 201fer to use thea!
// ppers.
pe Ite(`pubwuct MyRngCor(ckRng::i<ngCore {
>);`);o reglat fait
   
// 0.6lement `CryCore` tra prohs the Worlementation of ails.
 d all
  
//! `xcepit nctionality to aiddefauld in the *ne
imp
// (. `ranl BlongCorr{pfnnset_ucteam(...){...} } Th!
//! i/fockRng` or  beed.
v to imal d to lementations onlyhe [rangCore`] methods (e 
// 0.ng thiues dirm the Woris  t befers ns well as fu! i/fc
   thengckRngCore::Resraated
/u]cuctly.
/nthe *neoutpany rraykn im! i/flol_bytes`], w /flo_fill_bytes`. (] consad by,o lawsu a ferrayhe dithehods (e 
// o impdlinghe verk/)
pach on tfen impgetraate a blonewocatoblifiues dih!
//! i/fNoole, pnerated by d` (#1ues dir thus r attrwand all
  1ues dir thusistntad! i/fin-er to.flot_u32` (#] slemesetakthe Wort_u3ailable viad` (#1ues d.! i/flot_u64` an] conlemented as combinati to tadvd` (#1ues di,ast on! i/fnatecatiofor irve.flol_bytes`], w  [LICo_fill_bytes`. (] sistntawhole, p! i/fber gen`unsa (#1ues di,avert th enti thesa (#1a `Cres`. senseoin! i/fy ttle-ing arder to. the Woruirees as coliceengts not a
  ltiple of fou4,! i/fn clies perl be docuiscar td/!
//! i/fStheo imp[ockRng64` wr]ich canu are`` and rraykfers ns. Cent vethe Apis *n! i/fborect or port for typer crafers nyes.

  
//! i/fFeasieryitialisatzon of ockRng` and  implement `C`RngdableRng` ar]  
//! i/flot_u32` (#]ngCore`,
ilt_u32` (! i/flot_u64` an]ngCore`,
ilt_u32`64! i/flol_bytes`], wngCore`,
ill_bytes`. 
 i/flo_fill_bytes`. (]ngCore`,
il_fill_bytes`. 
#[ive `S(Ce or)]!#[cfg_ribu(ture can= rde"] 1",rive `S(Salize` feeerialize` f))]!#[cfg_ribu( Notpfure can= rde"] 1", Notpde"] (         nd to = r ty<'x> R:edalize` f + Duialize` f<'x> + Sd toor ex<'x> R::Rlt ofs: dalize` f + Duialize` f<'x>  rep )
)]!pubwuct MyRckRng::i<R:eckRngCore for+ ?Sd to>r   "shult ofs: R::Rlt ofs, Notpex` a:ing z   unl  i/f `Bl*e` i*rt of the Der
im,plementing the cortraated
/unctionali/! publicnt`,
i R,
}!! i Cemary ug` arlementation of t do nonot graortsthe `Bltents
   `randlts` bo.pleme<R:eckRngCore for+ fmt::ug` a> fmt::ug` ar BlockRng wr<R>r   "shfnnmmt(&
 an,sfmt: &mstdfmt::Fattinger) ->dfmt::Rlt ofr   "sh "shfmt.dg` a_uct My("ckRng wr")             .lds e("e"
ho, &
 an.e)
-              .lds e("dlts` _eeno, &
 an.ult ofs as_er ().een())             .lds e("ex` ao, &
 an.ex` a)             .ldhed ()     }
}!!leme<R:eckRngCore fo>ockRng wr<R>r   "sh i/fC0.na blonewoockRng` andm theexampisg RNGs `elementing th! "sh i/fockRngCore`] t.f    t bel be docerated by filesrusers /! pubnline]` f! publicnfnnnew(t`,
i R) ->dckRng wr<R>r   "shhhhhlet ult ofs_empt "htR::Rlt ofs::ault, b();
 "shhhhhckRng wra{             t`,
,             ex` a:iult ofs_empt  as_er ().een(),             ult ofs: ult ofs_empt ,         }     }
  "sh i/fGrhe integ` ater-oe Woris  t afers n.  "sh i/  "sh i/fIhis traenouq or offerwsu a hat Whe *neg z  the rands  t afers nen an  "sh i/f verkers neeno"empt "d `Deserated
/()`st retcopiad by,permuce andnew  "sh i/fult ofs  Notpnline]` (alwans)f! publicnfnneg` a(&
 an) ->dng z a{         
 an.ex` a     }
  "sh i/feedihe intber gen`unilable viault ofs  Notp i/f `ibel be  Blc blonewodihedatult ofs aiddeferated by filt_u3ars /! pubnline]` f! publicnfnneedit(&mstd
 an)a{         
 an.ex` a"ht
 an.ult ofs as_er ().een();     }
  "sh i/fGrate a blonewodihedatult ofs imia tyte rundihg the corex` a"-oe Wo  "sh i/fei if ues d.! pubnline]` f! publicnfnnerate_and_set`. (&mstd
 an,sex` a:ing z )a{         erted !(ex` a"<t
 an.ult ofs as_er ().een());
 "shhhhh
 an.e)
-.erated
/(&mstd
 an.ult ofs);
 "shhhhh
 an.ex` a"htex` a;     }
}!!leme<R:eckRngCore fo<m = u32;
/>> Core for MyRckRng wr<R>
re
//!    <R welckRngCore fo>::Rlt ofs: AsRefel;
/.  + ut<[Sel;
/. ,
{! pubnline]` f! pubfilt_u32_vi(&mstd
 an)a->dn32a{         such an.ex` a">ht
 an.ult ofs as_er ().een()a{             
 an.erate_and_set`. (0);
 "shhhhh}
  "shhhhhlet ues d"ht
 an.ult ofs as_er ()[h an.ex` a];
 "shhhhh
 an.ex` a"+= 1;
 "shhhhhues d     }
  "shnline]` f! pubfilt_u32_64(&mstd
 an)a->dn64r   "shhhhhlet ulad2_64"ht|ult ofs: &l;
/.,sex` a|a{             let a in = &ult ofs[ex` a..=ex` a"+ 1];
 "shhhhh unle64ill th(a in[1]) << 32a|le64ill th(a in[0])         };
  "shhhhhlet een"ht
 an.ult ofs as_er ().een();   "shhhhhlet ex` a"ht
 an.ex` a;         sucex` a"<teen"- 1a{             
 an.ex` a"+= 2;
 "shhhhh unli/feeany idn64rm the Worrent verex` a             ulad2_64(
 an.ult ofs as_er (),sex` a)         } elin ducex` a">hteen"{             
 an.erate_and_set`. (2);             ulad2_64(
 an.ult ofs as_er (),s0)         } elin {             let a"hte64ill th(
 an.ult ofs as_er ()[een"- 1]);             
 an.erate_and_set`. (1);             let y"hte64ill th(
 an.ult ofs as_er ()[0]);             (y << 32)a|lx         }     }
  "shnline]` f! pubfill_bytes`. (&mstd
 an,sdes : &mstd[u8])r   "shhhhhlet mstdrlad2een"ht0;         we redisad2een"<sdes .een()a{             such an.ex` a">ht
 an.ult ofs as_er ().een()a{                 
 an.erate_and_set`. (0);
 "shhhhh    }      "shhhhhlet (sistntad2_vir l_byad2_8) =                 l_byt_fil_viachun o(&
 an.ult ofs as_er ()[h an.ex` a...,s&mstddes [isad2een...);   "shhhhh    
 an.ex` a"+= sistntad2_vi;             ulad2een"+= l_byad2_8;         }     }
  "shnline]` (alwans)f! pubfil_fill_bytes`. (&mstd
 an,sdes : &mstd[u8])r->dRlt of<(),sor` t>a{         
 an.l_bytes`. (des );
 "shhhhhOk(())     }
}!!leme<R:eckRngCore fo + SableRng` a>odableRng};
r MyRckRng wr<R>r   "she Itedable cRtedabl;
  "shnline]` (alwans)f! pubfilm_u64dinge [`d:df::Itedabl) ->df::I//! "shhhhhf::Itenew(Rill th4dinge [`d))     }
  "shnline]` (alwans)f! pubfild_from_u64` f( [`d:d` f) ->df::I//! "shhhhhf::Itenew(Rild_from_u64` f( [`d))     }
  "shnline]` (alwans)f! pubfilm_u64rwr<SngCore`,
>(rwr:df)r->dRlt of<S an,sor` t>a{         Ok(f::Itenew(Rill th4rwr(rwr)?))     }
}!! i/fewppers.
pe Itelementing thengCore`] met dete clie Itelementing th! i/flockRngCore`] trah `std` and rraykfers n; i.this cratbe used to derlementing! i/fall `st
impm rest usaaetraated
/unctionali/!
//! i/f `traenosimbleo uselockRngCor whe procially d to  any rithms",  t do rs o
con i/fof o` andues dih!
//! i/fNoole, pnerated by d` andues dir thus r attrwand all
  1ues dir thusistntad! i/fin-er to.flot_u32` wr]islemesetakthe Wort_u3ailable viad` andues d.! i/flot_u32` (#] herever, t`Creirocially : f of whoaad` andconspicntad,ast v th! i/f *neor craf of the impfers n. the Wort_u3actionalipiad by,isflot_u32` (#]! i/f *nnf *neor craf of tsf *nnfspicntad,aever, t`h thelot_u32` wr]i
[CO i/flol_bytes`], w uiscar e rands t any othf of-spicntadad` ansen impiad by  
//! i/flol_bytes`], w  [LICo_fill_bytes`. (] sistntawhole, pfber gen`unsa an! i/fues dih the Woruirees as eengts not a
  ltiple of fou8,fn clies perl be do! i/fuiscar td/!
//! i/flot_u32` (#]ngCore`,
ilt_u32` (! i/flot_u64` an]ngCore`,
ilt_u32`64! i/flol_bytes`], wngCore`,
ill_bytes`. 
 i/flo_fill_bytes`. (]ngCore`,
il_fill_bytes`. 
#[ive `S(Ce or)]!#[cfg_ribu(ture can= rde"] 1",rive `S(Salize` feeerialize` f))]!pubwuct MyRckRng::i64<R:eckRngCore for+ ?Sd to>r   "shult ofs: R::Rlt ofs, Notpex` a:ing z   unl f of_d to:rk/)l,li/fe }
 suc  lyef of who prefervs [`Rds  t anotd to unl  i/f `Bl*e` i*rt of the Der
im,plementing the cortraated
/unctionali/! publicnt`,
i R,
}!! i Cemary ug` arlementation of t do nonot graortsthe `Bltents
   `randlts` bo.pleme<R:eckRngCore for+ fmt::ug` a> fmt::ug` ar BlockRng wr64<R>r   "shfnnmmt(&
 an,sfmt: &mstdfmt::Fattinger) ->dfmt::Rlt ofr   "sh "shfmt.dg` a_uct My("ckRng wr64")             .lds e("e"
ho, &
 an.e)
-              .lds e("dlts` _eeno, &
 an.ult ofs as_er ().een())             .lds e("ex` ao, &
 an.ex` a)             .lds e("f of_d too, &
 an.f of_d to)             .ldhed ()     }
}!!leme<R:eckRngCore fo>ockRng wr64<R>r   "sh i/fC0.na blonewoockRng` andm theexampisg RNGs `elementing th! "sh i/fockRngCore`] t.f    t bel be docerated by filesrusers /! pubnline]` f! publicnfnnnew(t`,
i R) ->dckRng wr64<R>r   "shhhhhlet ult ofs_empt "htR::Rlt ofs::ault, b();
 "shhhhhckRng wr64r   "shhhhh    t`,
,             ex` a:iult ofs_empt  as_er ().een(),             f of_d to:rfalse,             ult ofs: ult ofs_empt ,         }     }
  "sh i/fGrhe integ` ater-oe Woris  t afers n.  "sh i/  "sh i/fIhis traenouq or offerwsu a hat Whe *neg z  the rands  t afers nen an  "sh i/f verkers neeno"empt "d `Deserated
/()`st retcopiad by,permuce andnew  "sh i/fult ofs  Notpnline]` (alwans)f! publicnfnneg` a(&
 an) ->dng z a{         
 an.ex` a     }
  "sh i/feedihe intber gen`unilable viault ofs  Notp i/f `ibel be  Blc blonewodihedatult ofs aiddeferated by filt_u3ars /! pubnline]` f! publicnfnneedit(&mstd
 an)a{         
 an.ex` a"ht
 an.ult ofs as_er ().een();         
 an.f of_d to"htfalse;     }
  "sh i/fGrate a blonewodihedatult ofs imia tyte rundihg the corex` a"-oe Wo  "sh i/fei if ues d.! pubnline]` f! publicnfnnerate_and_set`. (&mstd
 an,sex` a:ing z )a{         erted !(ex` a"<t
 an.ult ofs as_er ().een());
 "shhhhh
 an.e)
-.erated
/(&mstd
 an.ult ofs);
 "shhhhh
 an.ex` a"htex` a;         
 an.f of_d to"htfalse;     }
}!!leme<R:eckRngCore fo<m = u32;64>> Core for MyRckRng wr64<R>
re
//!    <R welckRngCore fo>::Rlt ofs: AsRefel;64.  + ut<[Sel;64. ,
{! pubnline]` f! pubfilt_u32_vi(&mstd
 an)a->dn32a{         let mstdex` a"ht
 an.ex` a - 
 an.f of_d to"asing z ;         sucex` a">ht
 an.ult ofs as_er ().een()a{             
 an.e)
-.erated
/(&mstd
 an.ult ofs);
 "shhhhhhhhh
 an.ex` a"ht0;             ex` a"ht0;             i/fo
 an.f of_d tondcondefaultion, " `false`
 "shhhhhhhhh
 an.f of_d to"htfalse;     hhhh}
  "shhhhhlet shift"ht32a* (
 an.f of_d to"asing z );   "shhhhh
 an.f of_d to"ht!
 an.f of_d to;
 "shhhhh
 an.ex` a"+= 
 an.f of_d to"asing z ; 
 "shhhhh(
 an.ult ofs as_er ()[ex` a] >> shift)"asin (!    }
  "shnline]` f! pubfilt_u32_64(&mstd
 an)a->dn64r   "shhhhhsuch an.ex` a">ht
 an.ult ofs as_er ().een()a{             
 an.e)
-.erated
/(&mstd
 an.ult ofs);
 "shhhhhhhhh
 an.ex` a"ht0;         }
  "shhhhhlet ues d"ht
 an.ult ofs as_er ()[h an.ex` a];
 "shhhhh
 an.ex` a"+= 1;
 "shhhhh
 an.f of_d to"htfalse;     hhhhues d     }
  "shnline]` f! pubfill_bytes`. (&mstd
 an,sdes : &mstd[u8])r   "shhhhhlet mstdrlad2een"ht0;         
 an.f of_d to"htfalse;     hhhhwe redisad2een"<sdes .een()a{             such an.ex` a"asing z ">ht
 an.ult ofs as_er ().een()a{                 
 an.e)
-.erated
/(&mstd
 an.ult ofs);
 "shhhhhhhhhhhhh
 an.ex` a"ht0;             }
      "shhhhhlet (sistntad2_64r l_byad2_8) = l_byt_fil_64achun o(
 "shhhhhhhhhhhhh&
 an.ult ofs as_er ()[h an.ex` a"asing z ...,
 "shhhhhhhhhhhhh&mstddes [isad2een...,
 "shhhhhhhhh);   "shhhhh    
 an.ex` a"+= sistntad2_64;             ulad2een"+= l_byad2_8;         }     }
  "shnline]` (alwans)f! pubfil_fill_bytes`. (&mstd
 an,sdes : &mstd[u8])r->dRlt of<(),sor` t>a{         
 an.l_bytes`. (des );
 "shhhhhOk(())     }
}!!leme<R:eckRngCore fo + SableRng` a>odableRng};
r MyRckRng wr64<R>r   "she Itedable cRtedabl;
  "shnline]` (alwans)f! pubfilm_u64dinge [`d:df::Itedabl) ->df::I//! "shhhhhf::Itenew(Rill th4dinge [`d))     }
  "shnline]` (alwans)f! pubfild_from_u64` f( [`d:d` f) ->df::I//! "shhhhhf::Itenew(Rild_from_u64` f( [`d))     }
  "shnline]` (alwans)f! pubfilm_u64rwr<SngCore`,
>(rwr:df)r->dRlt of<S an,sor` t>a{         Ok(f::Itenew(Rill th4rwr(rwr)?))     }
}!!leme<R:eckRngCore fo + ptoRng` m>rptoRng` mr MyRckRng wr<R>r }!!#[cfg(t ve)f!moy,ps t {      rante) plo{dableRng};
, Core, S};      rante) plock::{BlockRngCor,RckRng wr64,eckRngCore fo};
  "shnlive `S(ug` a, Ce or)]! statit MyRDummy wra{         ntercla:in (,     }
  "shl BlockRngCore for MyRDummy wra{         e Item = u32;
//!         e Ite    t be copieB 16]/!  "sh "shfnnerated
/(&mstd
 an,sult ofs: &mstdf::Ite    t b)//!            lrigh theult ofs {                 *r"ht
 an.ntercla;                 
 an.e)ercla"ht
 an.ntercla.ppers th_add(3511615421);
 "shhhhh    }      "sh}     }
  "shl BlodableRng};
r MyRDummy wra{         e Itedable cop8; 4]/!  "sh "shfnnm_u64dinge [`d:df::Itedabl) ->df::I//! "shhhhh Deriummy wra{ ntercla:in (ill th4letes`. ( [`d) }      "sh}     }
  "sh#[ps tf! pubfilck::{rwr_t_u32_vi_vs_t_u32_64()r   "shhhhhlet mstdrng1r= ckRng::inn<iummy wr>ill th4dinge[1, 2, 3, 4]);
 "shhhhhlet mstdrng2r= rng1.ce or();
 "shhhhhlet mstdrng3r= rng1.ce or();

 "shhhhhlet mstdn = [0B 16]/! "shhhhh(&mstda[..4]).yrigom_u64sense(&rng1.t_u32_vi().to4letes`. ());
 "shhhhh(&mstda[4..12]).yrigom_u64sense(&rng1.t_u32_64().to4letes`. ());
 "shhhhh(&mstda[12...).yrigom_u64sense(&rng1.t_u32_vi().to4letes`. ());

 "shhhhhlet mstdb = [0B 16]/! "shhhhh(&mstdb[..4]).yrigom_u64sense(&rng2.t_u32_vi().to4letes`. ());
 "shhhhh(&mstdb[4..8]).yrigom_u64sense(&rng2.t_u32_vi().to4letes`. ());
 "shhhhh(&mstdb[8...).yrigom_u64sense(&rng2.t_u32_64().to4letes`. ());
 "shhhhherted _eq!(a, b);

 "shhhhhlet mstdc = [0B 16]/! "shhhhh(&mstdc[..8]).yrigom_u64sense(&rng3.t_u32_64().to4letes`. ());
 "shhhhh(&mstdc[8..12]).yrigom_u64sense(&rng3.t_u32_vi().to4letes`. ());
 "shhhhh(&mstdc[12...).yrigom_u64sense(&rng3.t_u32_vi().to4letes`. ());
 "shhhhherted _eq!(a, c);     }
  "shnlive `S(ug` a, Ce or)]! statit MyRDummy wr64r   "shhhhhntercla:in64,     }
  "shl BlockRngCore for MyRDummy wr64r   "shhhhhe Item = u32;64;          e Ite    t be cop64; 8]/!  "sh "shfnnerated
/(&mstd
 an,sult ofs: &mstdf::Ite    t b)//!            lrigh theult ofs {                 *r"ht
 an.ntercla;                 
 an.e)ercla"ht
 an.ntercla.ppers th_add(2781463553396133981);
 "shhhhh    }      "sh}     }
  "shl BlodableRng};
r MyRDummy wr64r   "shhhhhe Itedable cop8; 8]/!  "sh "shfnnm_u64dinge [`d:df::Itedabl) ->df::I//! "shhhhh Deriummy wr64r hntercla:in64ill th4letes`. ( [`d) }      "sh}     }
  "sh#[ps tf! pubfilck::{rwr64at_u32_vi_vs_t_u32_64()r   "shhhhhlet mstdrng1r= ckRng::i64il<iummy wr64>ill th4dinge[1, 2, 3, 4, 5, 6, 7, 8]);
 "shhhhhlet mstdrng2r= rng1.ce or();
 "shhhhhlet mstdrng3r= rng1.ce or();

 "shhhhhlet mstdn = [0B 16]/! "shhhhh(&mstda[..4]).yrigom_u64sense(&rng1.t_u32_vi().to4letes`. ());
 "shhhhh(&mstda[4..12]).yrigom_u64sense(&rng1.t_u32_64().to4letes`. ());
 "shhhhh(&mstda[12...).yrigom_u64sense(&rng1.t_u32_vi().to4letes`. ());

 "shhhhhlet mstdb = [0B 16]/! "shhhhh(&mstdb[..4]).yrigom_u64sense(&rng2.t_u32_vi().to4letes`. ());
 "shhhhh(&mstdb[4..8]).yrigom_u64sense(&rng2.t_u32_vi().to4letes`. ());
 "shhhhh(&mstdb[8...).yrigom_u64sense(&rng2.t_u32_64().to4letes`. ());
 "shhhhherted _ne!(a, b);
 "shhhhherted _eq!(&a[..4], &b[..4]);
 "shhhhherted _eq!(&a[4..12], &b[8...);   "shhhhhlet mstdc = [0B 16]/! "shhhhh(&mstdc[..8]).yrigom_u64sense(&rng3.t_u32_64().to4letes`. ());
 "shhhhh(&mstdc[8..12]).yrigom_u64sense(&rng3.t_u32_vi().to4letes`. ());
 "shhhhh(&mstdc[12...).yrigom_u64sense(&rng3.t_u32_vi().to4letes`. ());
 "shhhhherted _eq!(b, c);     }