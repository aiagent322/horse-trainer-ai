use std::borrow::Cow;

use crate::attributes::kw::frozen;
use crate::attributes::{
    self, kw, take_pyo3_options, CrateAttribute, ExtendsAttribute, FreelistAttribute,
    ModuleAttribute, NameAttribute, NameLitStr, RenameAllAttribute,
};
use crate::deprecations::Deprecations;
use crate::konst::{ConstAttributes, ConstSpec};
use crate::method::{FnArg, FnSpec};
use crate::pyimpl::{gen_py_const, PyClassMethodsType};
use crate::pymethod::{
    impl_py_getter_def, impl_py_setter_def, MethodAndMethodDef, MethodAndSlotDef, PropertyType,
    SlotDef, __INT__, __REPR__, __RICHCMP__,
};
use crate::utils::Ctx;
use crate::utils::{self, apply_renaming_rule, PythonDoc};
use crate::PyFunctionOptions;
use proc_macro2::{Ident, Span, TokenStream};
use quote::{format_ident, quote};
use syn::ext::IdentExt;
use syn::parse::{Parse, ParseStream};
use syn::punctuated::Punctuated;
use syn::{parse_quote, spanned::Spanned, Result, Token};

/// If the class is derived from a Rust `struct` or `enum`.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum PyClassKind {
    Struct,
    Enum,
}

/// The parsed arguments of the pyclass macro
#[derive(Clone)]
pub struct PyClassArgs {
    pub class_kind: PyClassKind,
    pub options: PyClassPyO3Options,
}

impl PyClassArgs {
    fn parse(input: ParseStream<'_>, kind: PyClassKind) -> Result<Self> {
        Ok(PyClassArgs {
            class_kind: kind,
            options: PyClassPyO3Options::parse(input)?,
        })
    }

    pub fn parse_stuct_args(input: ParseStream<'_>) -> syn::Result<Self> {
        Self::parse(input, PyClassKind::Struct)
    }

    pub fn parse_enum_args(input: ParseStream<'_>) -> syn::Result<Self> {
        Self::parse(input, PyClassKind::Enum)
    }
}

#[derive(Clone, Default)]
pub struct PyClassPyO3Options {
    pub krate: Option<CrateAttribute>,
    pub dict: Option<kw::dict>,
    pub extends: Option<ExtendsAttribute>,
    pub get_all: Option<kw::get_all>,
    pub freelist: Option<FreelistAttribute>,
    pub frozen: Option<kw::frozen>,
    pub mapping: Option<kw::mapping>,
    pub module: Option<ModuleAttribute>,
    pub name: Option<NameAttribute>,
    pub rename_all: Option<RenameAllAttribute>,
    pub sequence: Option<kw::sequence>,
    pub set_all: Option<kw::set_all>,
    pub subclass: Option<kw::subclass>,
    pub unsendable: Option<kw::unsendable>,
    pub weakref: Option<kw::weakref>,
}

enum PyClassPyO3Option {
    Crate(CrateAttribute),
    Dict(kw::dict),
    Extends(ExtendsAttribute),
    Freelist(FreelistAttribute),
    Frozen(kw::frozen),
    GetAll(kw::get_all),
    Mapping(kw::mapping),
    Module(ModuleAttribute),
    Name(NameAttribute),
    RenameAll(RenameAllAttribute),
    Sequence(kw::sequence),
    SetAll(kw::set_all),
    Subclass(kw::subclass),
    Unsendable(kw::unsendable),
    Weakref(kw::weakref),
}

impl Parse for PyClassPyO3Option {
    fn parse(input: ParseStream<'_>) -> Result<Self> {
        let lookahead = input.lookahead1();
        if lookahead.peek(Token![crate]) {
            input.parse().map(PyClassPyO3Option::Crate)
        } else if lookahead.peek(kw::dict) {
            input.parse().map(PyClassPyO3Option::Dict)
        } else if lookahead.peek(kw::extends) {
            input.parse().map(PyClassPyO3Option::Extends)
        } else if lookahead.peek(attributes::kw::freelist) {
            input.parse().map(PyClassPyO3Option::Freelist)
        } else if lookahead.peek(attributes::kw::frozen) {
            input.parse().map(PyClassPyO3Option::Frozen)
        } else if lookahead.peek(attributes::kw::get_all) {
            input.parse().map(PyClassPyO3Option::GetAll)
        } else if lookahead.peek(attributes::kw::mapping) {
            input.parse().map(PyClassPyO3Option::Mapping)
        } else if lookahead.peek(attributes::kw::module) {
            input.parse().map(PyClassPyO3Option::Module)
        } else if lookahead.peek(kw::name) {
            input.parse().map(PyClassPyO3Option::Name)
        } else if lookahead.peek(kw::rename_all) {
            input.parse().map(PyClassPyO3Option::RenameAll)
        } else if lookahead.peek(attributes::kw::sequence) {
            input.parse().map(PyClassPyO3Option::Sequence)
        } else if lookahead.peek(attributes::kw::set_all) {
            input.parse().map(PyClassPyO3Option::SetAll)
        } else if lookahead.peek(attributes::kw::subclass) {
            input.parse().map(PyClassPyO3Option::Subclass)
        } else if lookahead.peek(attributes::kw::unsendable) {
            input.parse().map(PyClassPyO3Option::Unsendable)
        } else if lookahead.peek(attributes::kw::weakref) {
            input.parse().map(PyClassPyO3Option::Weakref)
        } else {
            Err(lookahead.error())
        }
    }
}

impl Parse for PyClassPyO3Options {
    fn parse(input: ParseStream<'_>) -> syn::Result<Self> {
        let mut options: PyClassPyO3Options = Default::default();

        for option in Punctuated::<PyClassPyO3Option, syn::Token![,]>::parse_terminated(input)? {
            options.set_option(option)?;
        }

        Ok(options)
    }
}

impl PyClassPyO3Options {
    pub fn take_pyo3_options(&mut self, attrs: &mut Vec<syn::Attribute>) -> syn::Result<()> {
        take_pyo3_options(attrs)?
            .into_iter()
            .try_for_each(|option| self.set_option(option))
    }

    fn set_option(&mut self, option: PyClassPyO3Option) -> syn::Result<()> {
        macro_rules! set_option {
            ($key:ident) => {
                {
                    ensure_spanned!(
                        self.$key.is_none(),
                        $key.span() => concat!("`", stringify!($key), "` may only be specified once")
                    );
                    self.$key = Some($key);
                }
            };
        }

        match option {
            PyClassPyO3Option::Crate(krate) => set_option!(krate),
            PyClassPyO3Option::Dict(dict) => set_option!(dict),
            PyClassPyO3Option::Extends(extends) => set_option!(extends),
            PyClassPyO3Option::Freelist(freelist) => set_option!(freelist),
            PyClassPyO3Option::Frozen(frozen) => set_option!(frozen),
            PyClassPyO3Option::GetAll(get_all) => set_option!(get_all),
            PyClassPyO3Option::Mapping(mapping) => set_option!(mapping),
            PyClassPyO3Option::Module(module) => set_option!(module),
            PyClassPyO3Option::Name(name) => set_option!(name),
            PyClassPyO3Option::RenameAll(rename_all) => set_option!(rename_all),
            PyClassPyO3Option::Sequence(sequence) => set_option!(sequence),
            PyClassPyO3Option::SetAll(set_all) => set_option!(set_all),
            PyClassPyO3Option::Subclass(subclass) => set_option!(subclass),
            PyClassPyO3Option::Unsendable(unsendable) => set_option!(unsendable),
            PyClassPyO3Option::Weakref(weakref) => set_option!(weakref),
        }
        Ok(())
    }
}

pub fn build_py_class(
    class: &mut syn::ItemStruct,
    mut args: PyClassArgs,
    methods_type: PyClassMethodsType,
) -> syn::Result<TokenStream> {
    args.options.take_pyo3_options(&mut class.attrs)?;
    let doc = utils::get_doc(&class.attrs, None);

    let ctx = &Ctx::new(&args.options.krate);

    if let Some(lt) = class.generics.lifetimes().next() {
        bail_spanned!(
            lt.span() =>
            "#[pyclass] cannot have lifetime parameters. \
            For an explanation, see https://pyo3.rs/latest/class.html#no-lifetime-parameters"
        );
    }

    ensure_spanned!(
        class.generics.params.is_empty(),
        class.generics.span() =>
            "#[pyclass] cannot have generic parameters. \
            For an explanation, see https://pyo3.rs/latest/class.html#no-generic-parameters"
    );

    let mut field_options: Vec<(&syn::Field, FieldPyO3Options)> = match &mut class.fields {
        syn::Fields::Named(fields) => fields
            .named
            .iter_mut()
            .map(|field| {
                FieldPyO3Options::take_pyo3_options(&mut field.attrs)
                    .map(move |options| (&*field, options))
            })
            .collect::<Result<_>>()?,
        syn::Fields::Unnamed(fields) => fields
            .unnamed
            .iter_mut()
            .map(|field| {
                FieldPyO3Options::take_pyo3_options(&mut field.attrs)
                    .map(move |options| (&*field, options))
            })
            .collect::<Result<_>>()?,
        syn::Fields::Unit => {
            if let Some(attr) = args.options.set_all {
                return Err(syn::Error::new_spanned(attr, UNIT_SET));
            };
            if let Some(attr) = args.options.get_all {
                return Err(syn::Error::new_spanned(attr, UNIT_GET));
            };
            // No fields for unit struct
            Vec::new()
        }
    };

    if let Some(attr) = args.options.get_all {
        for (_, FieldPyO3Options { get, .. }) in &mut field_options {
            if let Some(old_get) = get.replace(Annotated::Struct(attr)) {
                return Err(syn::Error::new(old_get.span(), DUPE_GET));
            }
        }
    }

    if let Some(attr) = args.options.set_all {
        for (_, FieldPyO3Options { set, .. }) in &mut field_options {
            if let Some(old_set) = set.replace(Annotated::Struct(attr)) {
                return Err(syn::Error::new(old_set.span(), DUPE_SET));
            }
        }
    }

    impl_class(&class.ident, &args, doc, field_options, methods_type, ctx)
}

enum Annotated<X, Y> {
    Field(X),
    Struct(Y),
}

impl<X: Spanned, Y: Spanned> Annotated<X, Y> {
    fn span(&self) -> Span {
        match self {
            Self::Field(x) => x.span(),
            Self::Struct(y) => y.span(),
        }
    }
}

/// `#[pyo3()]` options for pyclass fields
struct FieldPyO3Options {
    get: Option<Annotated<kw::get, kw::get_all>>,
    set: Option<Annotated<kw::set, kw::set_all>>,
    name: Option<NameAttribute>,
}

enum FieldPyO3Option {
    Get(attributes::kw::get),
    Set(attributes::kw::set),
    Name(NameAttribute),
}

impl Parse for FieldPyO3Option {
    fn parse(input: ParseStream<'_>) -> Result<Self> {
        let lookahead = input.lookahead1();
        if lookahead.peek(attributes::kw::get) {
            input.parse().map(FieldPyO3Option::Get)
        } else if lookahead.peek(attributes::kw::set) {
            input.parse().map(FieldPyO3Option::Set)
        } else if lookahead.peek(attributes::kw::name) {
            input.parse().map(FieldPyO3Option::Name)
        } else {
            Err(lookahead.error())
        }
    }
}

impl FieldPyO3Options {
    fn take_pyo3_options(attrs: &mut Vec<syn::Attribute>) -> Result<Self> {
        let mut options = FieldPyO3Options {
            get: None,
            set: None,
            name: None,
        };

        for option in take_pyo3_options(attrs)? {
            match option {
                FieldPyO3Option::Get(kw) => {
                    if options.get.replace(Annotated::Field(kw)).is_some() {
                        return Err(syn::Error::new(kw.span(), UNIQUE_GET));
                    }
                }
                FieldPyO3Option::Set(kw) => {
                    if options.set.replace(Annotated::Field(kw)).is_some() {
                        return Err(syn::Error::new(kw.span(), UNIQUE_SET));
                    }
                }
                FieldPyO3Option::Name(name) => {
                    if options.name.replace(name).is_some() {
                        return Err(syn::Error::new(options.name.span(), UNIQUE_NAME));
                    }
                }
            }
        }

        Ok(options)
    }
}

fn get_class_python_name<'a>(cls: &'a syn::Ident, args: &'a PyClassArgs) -> Cow<'a, syn::Ident> {
    args.options
        .name
        .as_ref()
        .map(|name_attr| Cow::Borrowed(&name_attr.value.0))
        .unwrap_or_else(|| Cow::Owned(cls.unraw()))
}

fn impl_class(
    cls: &syn::Ident,
    args: &PyClassArgs,
    doc: PythonDoc,
    field_options: Vec<(&syn::Field, FieldPyO3Options)>,
    methods_type: PyClassMethodsType,
    ctx: &Ctx,
) -> syn::Result<TokenStream> {
    let Ctx { pyo3_path } = ctx;
    let pytypeinfo_impl = impl_pytypeinfo(cls, args, None, ctx);

    let py_class_impl = PyClassImplsBuilder::new(
        cls,
        args,
        methods_type,
        descriptors_to_items(
            cls,
            args.options.rename_all.as_ref(),
            args.options.frozen,
            field_options,
            ctx,
        )?,
        vec![],
    )
    .doc(doc)
    .impl_all(ctx)?;

    Ok(quote! {
        impl #pyo3_path::types::DerefToPyAny for #cls {}

        #pytypeinfo_impl

        #py_class_impl
    })
}

enum PyClassEnum<'a> {
    Simple(PyClassSimpleEnum<'a>),
    Complex(PyClassComplexEnum<'a>),
}

impl<'a> PyClassEnum<'a> {
    fn new(enum_: &'a mut syn::ItemEnum) -> syn::Result<Self> {
        let has_only_unit_variants = enum_
            .variants
            .iter()
            .all(|variant| matches!(variant.fields, syn::Fields::Unit));

        Ok(if has_only_unit_variants {
            let simple_enum = PyClassSimpleEnum::new(enum_)?;
            Self::Simple(simple_enum)
        } else {
            let complex_enum = PyClassComplexEnum::new(enum_)?;
            Self::Complex(complex_enum)
        })
    }
}

pub fn build_py_enum(
    enum_: &mut syn::ItemEnum,
    mut args: PyClassArgs,
    method_type: PyClassMethodsType,
) -> syn::Result<TokenStream> {
    args.options.take_pyo3_options(&mut enum_.attrs)?;

    let ctx = &Ctx::new(&args.options.krate);
    if let Some(extends) = &args.options.extends {
        bail_spanned!(extends.span() => "enums can't extend from other classes");
    } else if let Some(subclass) = &args.options.subclass {
        bail_spanned!(subclass.span() => "enums can't be inherited by other classes");
    } else if enum_.variants.is_empty() {
        bail_spanned!(enum_.brace_token.span.join() => "#[pyclass] can't be used on enums without any variants");
    }

    let doc = utils::get_doc(&enum_.attrs, None);
    let enum_ = PyClassEnum::new(enum_)?;
    impl_enum(enum_, &args, doc, method_type, ctx)
}

struct PyClassSimpleEnum<'a> {
    ident: &'a syn::Ident,
    // The underlying #[repr] of the enum, used to implement __int__ and __richcmp__.
    // This matters when the underlying representation may not fit in `isize`.
    repr_type: syn::Ident,
    variants: Vec<PyClassEnumUnitVariant<'a>>,
}

impl<'a> PyClassSimpleEnum<'a> {
    fn new(enum_: &'a mut syn::ItemEnum) -> syn::Result<Self> {
        fn is_numeric_type(t: &syn::Ident) -> bool {
            [
                "u8", "i8", "u16", "i16", "u32", "i32", "u64", "i64", "u128", "i128", "usize",
                "isize",
            ]
            .iter()
            .any(|&s| t == s)
        }

        fn extract_unit_variant_data(
            variant: &mut syn::Variant,
        ) -> syn::Result<PyClassEnumUnitVariant<'_>> {
            use syn::Fields;
            let ident = match &variant.fields {
                Fields::Unit => &variant.ident,
                _ => bail_spanned!(variant.span() => "Must be a unit variant."),
            };
            let options = EnumVariantPyO3Options::take_pyo3_options(&mut variant.attrs)?;
            Ok(PyClassEnumUnitVariant { ident, options })
        }

        let ident = &enum_.ident;

        // According to the [reference](https://doc.rust-lang.org/reference/items/enumerations.html),
        // "Under the default representation, the specified discriminant is interpreted as an isize
        // value", so `isize` should be enough by default.
        let mut repr_type = syn::Ident::new("isize", proc_macro2::Span::call_site());
        if let Some(attr) = enum_.attrs.iter().find(|attr| attr.path().is_ident("repr")) {
            let args =
                attr.parse_args_with(Punctuated::<TokenStream, Token![!]>::parse_terminated)?;
            if let Some(ident) = args
                .into_iter()
                .filter_map(|ts| syn::parse2::<syn::Ident>(ts).ok())
                .find(is_numeric_type)
            {
                repr_type = ident;
            }
        }

        let variants: Vec<_> = enum_
            .variants
            .iter_mut()
            .map(extract_unit_variant_data)
            .collect::<syn::Result<_>>()?;
        Ok(Self {
            ident,
            repr_type,
            variants,
        })
    }
}

struct PyClassComplexEnum<'a> {
    ident: &'a syn::Ident,
    variants: Vec<PyClassEnumVariant<'a>>,
}

impl<'a> PyClassComplexEnum<'a> {
    fn new(enum_: &'a mut syn::ItemEnum) -> syn::Result<Self> {
        let witness = enum_
            .variants
            .iter()
            .find(|variant| !matches!(variant.fields, syn::Fields::Unit))
            .expect("complex enum has a non-unit variant")
            .ident
            .to_owned();

        let extract_variant_data =
            |variant: &'a mut syn::Variant| -> syn::Result<PyClassEnumVariant<'a>> {
                use syn::Fields;
                let ident = &variant.ident;
                let options = EnumVariantPyO3Options::take_pyo3_options(&mut variant.attrs)?;

                let variant = match &variant.fields {
                    Fields::Unit => {
                        bail_spanned!(variant.span() => format!(
                        "Unit variant `{ident}` is not yet supported in a complex enum\n\
                        = help: change to a struct variant with no fields: `{ident} {{ }}`\n\
                        = note: the enum is complex because of non-unit variant `{witness}`",
                        ident=ident, witness=witness))
                    }
                    Fields::Named(fields) => {
                        let fields = fields
                            .named
                            .iter()
                            .map(|field| PyClassEnumVariantNamedField {
                                ident: field.ident.as_ref().expect("named field has an identifier"),
                                ty: &field.ty,
                                span: field.span(),
                            })
                            .collect();

                        PyClassEnumVariant::Struct(PyClassEnumStructVariant {
                            ident,
                            fields,
                            options,
                        })
                    }
                    Fields::Unnamed(_) => {
                        bail_spanned!(variant.span() => format!(
                        "Tuple variant `{ident}` is not yet supported in a complex enum\n\
                        = help: change to a struct variant with named fields: `{ident} {{ /* fields */ }}`\n\
                        = note: the enum is complex because of non-unit variant `{witness}`",
                        ident=ident, witness=witness))
                    }
                };

                Ok(variant)
            };

        let ident = &enum_.ident;

        let variants: Vec<_> = enum_
            .variants
            .iter_mut()
            .map(extract_variant_data)
            .collect::<syn::Result<_>>()?;

        Ok(Self { ident, variants })
    }
}

enum PyClassEnumVariant<'a> {
    // TODO(mkovaxx): Unit(PyClassEnumUnitVariant<'a>),
    Struct(PyClassEnumStructVariant<'a>),
    // TODO(mkovaxx): Tuple(PyClassEnumTupleVariant<'a>),
}

trait EnumVariant {
    fn get_ident(&self) -> &syn::Ident;
    fn get_options(&self) -> &EnumVariantPyO3Options;

    fn get_python_name(&self, args: &PyClassArgs) -> Cow<'_, syn::Ident> {
        self.get_options()
            .name
            .as_ref()
            .map(|name_attr| Cow::Borrowed(&name_attr.value.0))
            .unwrap_or_else(|| {
                let name = self.get_ident().unraw();
                if let Some(attr) = &args.options.rename_all {
                    let new_name = apply_renaming_rule(attr.value.rule, &name.to_string());
                    Cow::Owned(Ident::new(&new_name, Span::call_site()))
                } else {
                    Cow::Owned(name)
                }
            })
    }
}

impl<'a> EnumVariant for PyClassEnumVariant<'a> {
    fn get_ident(&self) -> &syn::Ident {
        match self {
            PyClassEnumVariant::Struct(struct_variant) => struct_variant.ident,
        }
    }

    fn get_options(&self) -> &EnumVariantPyO3Options {
        match self {
            PyClassEnumVariant::Struct(struct_variant) => &struct_variant.options,
        }
    }
}

/// A unit variant has no fields
struct PyClassEnumUnitVariant<'a> {
    ident: &'a syn::Ident,
    options: EnumVariantPyO3Options,
}

impl<'a> EnumVariant for PyClassEnumUnitVariant<'a> {
    fn get_ident(&self) -> &syn::Ident {
        self.ident
    }

    fn get_options(&self) -> &EnumVariantPyO3Options {
        &self.options
    }
}

/// A struct variant has named fields
struct PyClassEnumStructVariant<'a> {
    ident: &'a syn::Ident,
    fields: Vec<PyClassEnumVariantNamedField<'a>>,
    options: EnumVariantPyO3Options,
}

struct PyClassEnumVariantNamedField<'a> {
    ident: &'a syn::Ident,
    ty: &'a syn::Type,
    span: Span,
}

/// `#[pyo3()]` options for pyclass enum variants
struct EnumVariantPyO3Options {
    name: Option<NameAttribute>,
}

enum EnumVariantPyO3Option {
    Name(NameAttribute),
}

impl Parse for EnumVariantPyO3Option {
    fn parse(input: ParseStream<'_>) -> Result<Self> {
        let lookahead = input.lookahead1();
        if lookahead.peek(attributes::kw::name) {
            input.parse().map(EnumVariantPyO3Option::Name)
        } else {
            Err(lookahead.error())
        }
    }
}

impl EnumVariantPyO3Options {
    fn take_pyo3_options(attrs: &mut Vec<syn::Attribute>) -> Result<Self> {
        let mut options = EnumVariantPyO3Options { name: None };

        for option in take_pyo3_options(attrs)? {
            match option {
                EnumVariantPyO3Option::Name(name) => {
                    ensure_spanned!(
                        options.name.is_none(),
                        name.span() => "`name` may only be specified once"
                    );
                    options.name = Some(name);
                }
            }
        }

        Ok(options)
    }
}

fn impl_enum(
    enum_: PyClassEnum<'_>,
    args: &PyClassArgs,
    doc: PythonDoc,
    methods_type: PyClassMethodsType,
    ctx: &Ctx,
) -> Result<TokenStream> {
    match enum_ {
        PyClassEnum::Simple(simple_enum) => {
            impl_simple_enum(simple_enum, args, doc, methods_type, ctx)
        }
        PyClassEnum::Complex(complex_enum) => {
            impl_complex_enum(complex_enum, args, doc, methods_type, ctx)
        }
    }
}

fn impl_simple_enum(
    simple_enum: PyClassSimpleEnum<'_>,
    args: &PyClassArgs,
    doc: PythonDoc,
    methods_type: PyClassMethodsType,
    ctx: &Ctx,
) -> Result<TokenStream> {
    let Ctx { pyo3_path } = ctx;
    let cls = simple_enum.ident;
    let ty: syn::Type = syn::parse_quote!(#cls);
    let variants = simple_enum.variants;
    let pytypeinfo = impl_pytypeinfo(cls, args, None, ctx);

    let (default_repr, default_repr_slot) = {
        let variants_repr = variants.iter().map(|variant| {
            let variant_name = variant.ident;
            // Assuming all variants are unit variants because they are the only type we support.
            let repr = format!(
                "{}.{}",
                get_class_python_name(cls, args),
                variant.get_python_name(args),
            );
            quote! { #cls::#variant_name => #repr, }
        });
        let mut repr_impl: syn::ImplItemFn = syn::parse_quote! {
            fn __pyo3__repr__(&self) -> &'static str {
                match self {
                    #(#variants_repr)*
                }
            }
        };
        let repr_slot =
            generate_default_protocol_slot(&ty, &mut repr_impl, &__REPR__, ctx).unwrap();
        (repr_impl, repr_slot)
    };

    let repr_type = &simple_enum.repr_type;

    let (default_int, default_int_slot) = {
        // This implementation allows us to convert &T to #repr_type without implementing `Copy`
        let variants_to_int = variants.iter().map(|variant| {
            let variant_name = variant.ident;
            quote! { #cls::#variant_name => #cls::#variant_name as #repr_type, }
        });
        let mut int_impl: syn::ImplItemFn = syn::parse_quote! {
            fn __pyo3__int__(&self) -> #repr_type {
                match self {
                    #(#variants_to_int)*
                }
            }
        };
        let int_slot = generate_default_protocol_slot(&ty, &mut int_impl, &__INT__, ctx).unwrap();
        (int_impl, int_slot)
    };

    let (default_richcmp, default_richcmp_slot) = {
        let mut richcmp_impl: syn::ImplItemFn = syn::parse_quote! {
            fn __pyo3__richcmp__(
                &self,
                py: #pyo3_path::Python,
                other: &#pyo3_path::Bound<'_, #pyo3_path::PyAny>,
                op: #pyo3_path::basic::CompareOp
            ) -> #pyo3_path::PyResult<#pyo3_path::PyObject> {
                use #pyo3_path::conversion::ToPyObject;
                use #pyo3_path::types::PyAnyMethods;
                use ::core::result::Result::*;
                match op {
                    #pyo3_path::basic::CompareOp::Eq => {
                        let self_val = self.__pyo3__int__();
                        if let Ok(i) = other.extract::<#repr_type>() {
                            return Ok((self_val == i).to_object(py));
                        }
                        if let Ok(other) = other.extract::<#pyo3_path::PyRef<Self>>() {
                            return Ok((self_val == other.__pyo3__int__()).to_object(py));
                        }

                        return Ok(py.NotImplemented());
                    }
                    #pyo3_path::basic::CompareOp::Ne => {
                        let self_val = self.__pyo3__int__();
                        if let Ok(i) = other.extract::<#repr_type>() {
                            return Ok((self_val != i).to_object(py));
                        }
                        if let Ok(other) = other.extract::<#pyo3_path::PyRef<Self>>() {
                            return Ok((self_val != other.__pyo3__int__()).to_object(py));
                        }

                        return Ok(py.NotImplemented());
                    }
                    _ => Ok(py.NotImplemented()),
                }
            }
        };
        let richcmp_slot =
            generate_default_protocol_slot(&ty, &mut richcmp_impl, &__RICHCMP__, ctx).unwrap();
        (richcmp_impl, richcmp_slot)
    };

    let default_slots = vec![default_repr_slot, default_int_slot, default_richcmp_slot];

    let pyclass_impls = PyClassImplsBuilder::new(
        cls,
        args,
        methods_type,
        simple_enum_default_methods(
            cls,
            variants.iter().map(|v| (v.ident, v.get_python_name(args))),
            ctx,
        ),
        default_slots,
    )
    .doc(doc)
    .impl_all(ctx)?;

    Ok(quote! {
        #pytypeinfo

        #pyclass_impls

        #[doc(hidden)]
        #[allow(non_snake_case)]
        impl #cls {
            #default_repr
            #default_int
            #default_richcmp
        }
    })
}

fn impl_complex_enum(
    complex_enum: PyClassComplexEnum<'_>,
    args: &PyClassArgs,
    doc: PythonDoc,
    methods_type: PyClassMethodsType,
    ctx: &Ctx,
) -> Result<TokenStream> {
    let Ctx { pyo3_path } = ctx;

    // Need to rig the enum PyClass options
    let args = {
        let mut rigged_args = args.clone();
        // Needs to be frozen to disallow `&mut self` methods, which could break a runtime invariant
        rigged_args.options.frozen = parse_quote!(frozen);
        // Needs to be subclassable by the variant PyClasses
        rigged_args.options.subclass = parse_quote!(subclass);
        rigged_args
    };

    let ctx = &Ctx::new(&args.options.krate);
    let cls = complex_enum.ident;
    let variants = complex_enum.variants;
    let pytypeinfo = impl_pytypeinfo(cls, &args, None, ctx);

    let default_slots = vec![];

    let impl_builder = PyClassImplsBuilder::new(
        cls,
        &args,
        methods_type,
        complex_enum_default_methods(
            cls,
            variants
                .iter()
                .map(|v| (v.get_ident(), v.get_python_name(&args))),
            ctx,
        ),
        default_slots,
    )
    .doc(doc);

    // Need to customize the into_py impl so that it returns the variant PyClass
    let enum_into_py_impl = {
        let match_arms: Vec<TokenStream> = variants
            .iter()
            .map(|variant| {
                let variant_ident = variant.get_ident();
                let variant_cls = gen_complex_enum_variant_class_ident(cls, variant.get_ident());
                quote! {
                    #cls::#variant_ident { .. } => {
                        let pyclass_init = #pyo3_path::PyClassInitializer::from(self).add_subclass(#variant_cls);
                        let variant_value = #pyo3_path::Py::new(py, pyclass_init).unwrap();
                        #pyo3_path::IntoPy::into_py(variant_value, py)
                    }
                }
            })
            .collect();

        quote! {
            impl #pyo3_path::IntoPy<#pyo3_path::PyObject> for #cls {
                fn into_py(self, py: #pyo3_path::Python               #cls: thariant_cls name.splf> {
         "isize",
  if let Ok(other) = other   fn __pyopeinfo

        # Nariant
  e"isize",
  if let Ok(othe [      #[doc(h ctx);

.riants  = #py  le,      #[doc(h ctx);

.riant  }
   ;

   le,      #[d impl so that it ,      #[doc(h ctx);

.riants  = #prian     d,      #[doc(h ctx);

.riantss_io t    Pyy  le,      #[doc(h ctx);

.riantPyClassPy  le,     ]
?;
            if let      }
         ig the e3_path::PyC_zstypeinfo(cls,    ig the e3_path::PyC_s = compleypeinfo(cls,    ig the e3_path::PyC_s  default_int_snfo(cls,    ig the e3_path::PyC_lt_int_snfo(cls,        to custo_alls, syn::Fields::Univariant_ident = variant.get_ident();
                let variant_cls = gen_complexelds::Univariant_ident =_zst va   }
            })
         #pytypeinfo

  

        #pyclac   lpls

der::sypeinfo

  

  }

/// o3_path::PyC;py.NotImplemented())3_path::PyC_zsty?
   (3_path::PyC_zstlexelds::Univariant_idenlass op'_>, kind: PyClassKind) -> Result<Self>) -> syn::Result<S,iant| {
        >),
    Struct(   pagarg yClassEnumVaria       Ok(PyClassArgs ant PyClassesons.krat=    i,     PyClassPyO3Op}exelds::Univariant_ident =_t;
    let variants = complex&ant_ident =,lls, syn:_variants;
    let ented())3_path::PyC_s = compley?
   (3_path::PyC_s = complelexelds::Univariant_iden   );
    let cls _ant_iden   et variant_cl    le?exelds::Univari(3_path::PyC_lt_i     }
 lassMe from
            #def);
        set variant_cl    le?exented())3_path::PyC_lt_in?
   (3_path::PyC_lt_ilexelds::Univaris  default_i    let default_slots = vec![];

    buildant_ident =,[];

    buildant_idener = PyClassImssImplsBuilder::new(
     l.as_ref()lassMe         complexfo(cant_iden   ]_ident(), v  .map(|na  ),
        default_d())3_path::PyC_s  default_in?
   (s  default_ipyclass] can'tslots,
    )
    .doc(doc)
    .impl_all(ctx)?;

    Ok(quote! {
        #pytypeinfo

        #pyclass_impls

        #[doc(hidden)]      impl #yo3_path::PyC_zsty{
     impl #yo3_path::PyC_s = compley{
     impl #yo3_path::PyC_s )?;

    Ok{
     impl #yo3_path::PyC_   Ok{
  #default_int
            #def);
        se        }
{
    & }
}

struct PyClassComm(
    com         })
 _complexPythonDoc,
    methods_( =
             lethod::{
    impl_>)ssMethodsType,v        PyClassEnariantPyO3Options {
        match self {
          }
        PyClassEnum::Com_ match self {
   se   }
{
  ,        PyClasspl_complex_enum(complex_enum, argsassEnum::Com_ match self {
   se        }
{
    & }
}

struct PyClassComm(
    com     A struct varia_complexPythonDoc,
    methods_( =
             lethod::{
    impl_>)ssMethodsType,
    ctx: &Ctx,
) -> Result<Tokr()
                    use syn::Fievariant_ident = variant.get_ident();
                le   }
{
  ,        use sy)n::Fievariant_ident =;
      ls = simple_en3_path::PyClas3.rs/latest/class.h{
  s
    lthon_na_snfo(cls,    ig the eumStru     der::s
    let enum_into_py_fo(cls,    ig the eumStr)lassMe _py_fo(cls,    ig the eumStr)lassMeze",
  i   let enum_into_py_fo(cls,              _alls, syn:ttrs)?;

           Fields:riants.itNamedField;           Fields:r
      n identi;           Fields:r    der:: va   }
    #elds:riant: #elds:rer:: }exelds::UnivariumStr)lassMe  }
           t.get_ident();
      umStr)lassMex&ant_ident ={ #cls:elds:riant, ty: &field    le?exelds::UnivariumStr)lassMeze",
 va   }
            })
 um,#elds:riant(slf:                   if le        op: #pyo3_path::baselds:rer::>! {
            fn __pyo3&*s{
      sup   ient(cls, variant.get_ide   }
{
   );
               #elds:riant,  quote! slo#elds:riants
    leanned!(
               menteunrttrspars!("Wrong   "Tuple var,v       f3_pa _al\
       antp  nariantP"    }
                    _ => Ok(py.NotImplem
    l.as_ref(){
  s?
   (elds:riants
    lea;
    l.as_ref(u     der::s?
   (elds:r    der::a;
    l.as_ref()lassMe ?
   (elds:rlassMea;
    l.as_ref()lassMeult_in?
   (_ref()lassMeult_ipyclass] can't be PyC_   O va   }
                    #pytypeinfo

        #pyclass_impls

        #[doc(hidant_ident = ut richcmp_impl: syn:sEnum::cArgA stroemFnyObject> for #cls {
  }

imp#o#elds:u     der::s,)*        op: #pyo3_p                <dant_ident =>riants
            .itebs

ds(#varian   }
{
   );
               #o#elds:riants,)*ant.span() => "M:new(py, pyclass                      letbs

ds(#valass_init = #pyo3_path::PyCl
= other.__pyo3__int__()).to#o#elds:rlassMeult_in{
                 # Nari:PyRPyC_lt_i     }
 lassMe f) }
      ant.get_ident();
                le   }
  & }
}

strucClassComm(
> syn::Result<SassEnumUnitVarianare th     l!("{}_
     let en         }
      a        };
        let richcor_else(|| Cow::
    doc: sEnum:)
        })
ichcmp_sla> {
  ich)
 Sichpl_ldPyO3Options)>,
    methods_type:ethod::{
Sichpl_ssMethodsTyp    AttrnSp    ahead.impl_build    sEnum:.sig,impl_build              ,PyClassEnarF    sAr.ident;
       letnew(
      et_identif let ariant_value =0))
        p  .let new_name = a;> {
  ich.  a      er:: richcor_elote! {et cls = simple_enum.i,impl_build p  ,impl_buildare the "_   };
   {}__           PyClass et_identif}
        cls,
        args,
         or_else(|| truct PyClassEnumVants
         {
  s
 oc(hict()cmp   or<cmp_   ((options)
    }
e<'a>(cls: &'a syn:)complexPythonDoc,
    m   lethod::{
    impl_>sMethodsTypt =;
      let cls = simple_enum.ident;
    let ty:io thead = in   eam>_ns,
}

sions)
    }
hat s,
}

sions)
    ame
rgASp  riants
    
   t s,
}

am>_ns,
}s
    lepyclass_impead = inpume
rgAions {
  _, FieldPyO3Optios       pead: A sOptions {
                Attribute>,
}riants
            kw:) = {
        let mu
     }{}",
               #va:n<NamLitum_(hat s,
}s
    leanned!(
       }anned!(
       ds/encassArgs Ds/encassArgs       le,      #[d}{}",
 nt.spannts
         {
  s
ted)?;
            if let SomenStre(3_p}
hat     |   anyAny
rgA_SET={ #cls:&let ty:io thead = in(3_p}
&hat         leif let Some     }
  f}
       cls,
        &args,
          or_else(|| truct PyClassEnumVa        {
  s
 oc(hict()cmp   or<cmp_   ((options)
    }
e<'a>(cls: &'a syn:)complexPythonDoc,
    m   lethod::{
    impl_>sMethodsTypt =;
      let cls = simple_enum.ident;
    let ty:io thead = in   eam>_ns,
}

sions)
    }
hat s,
}

sions)
    ame
rgASp  riants
    
   t s,
}

am>_ns,
}s
    lepyclass_impead = inpume
rgAions {
  _, FieldPyO3Optios       pead: A sOptions {
                Attribute>,
}riants
            kw:) = {
        let mu
     }{}",
               #va:n<NamLitum_(hat s,
}s
    leanned!(
       }anned!(
       ds/encassArgs Ds/encassArgs       le,      #[d}{}",
 nt.span        {
  s
ted)?;
            if let SomenStre(3_p}
hat     | t<Self> {
      ant.get_ident();
      peadx_enum.ET={ #cls:&let ty:io thead = in(3_p}
&hat         le
lue, py)
          e     }
  f}
      Se  ant.get_ident();
      peadxor_else(|| Cow::Owned(cls.uET={ #cl|| Cow::
    doc:  p  honD
rgASp  ia_complexPythonDoc,
    method::{
    impl_sMethodsType,
    ctx: &Ctx,
) -> Result<Tokmemb

   d p  .
   t s,
}Result<Tok antp           are th     l!("syn:sEnum::ant_ident ={{}__   memb

ident;
    ds/encassArg   d p  .pead = inp.ds/encassArg_enum.ident;
()
        d p  .nullargs_with(Piter()
      las3.rs/lateant_ident = vaare th     l!("{}_
    _enummemb

ident;
       ocith(PisEnum: va   }
            um,# antp        nyObject> for #cls {
  }

i        op: #pyo3_path::basic::CompareOp
            ) -> #pyo#ds/encassArg    ) -> #pyo::stdpath::types::PyAnyd());
 = ger:: b3_pa    ant_ident =>Some    ize" varb    ))opeinfo

        # Nariant
sEnum::    va   }
             yResult<#pyo
    eOp    impl_
   ::>, kinead = in(     ) -> #pyo#yResult<#pyo
    eOp>, kinead = inpl_= vec![];

    buil .doc(do()
     ,.span() => "M:new(py, pyclass args{
 :sEnum:  eOp>, kinead = inFatroeyenum.{ #cl|:# antp        l
= other.__py::new(enum_)?;
    # Nariethod::{
    impl_sMethods_imp  ocith(PisEnum: PyClassImplsBui:   ,complex_enum,    let cls _ant_iden        or_else(|| truct PyClassEnumVa       n get_class_p         })
   omplexPythonDoc,
    methods_ethod::{
Sichpl_ssMethodsType,v        PyClassEnariantPyO3Options {
        match self {
          }
       assEnum::Com_ match self {
    et var       PyClasspl_complex_enum(complex_enum,assEnum::Com_ match self {
         or_else(|| truct PyClassEnumVa       n get_class_p     A struct variantomplexPythonDoc,
    methods_ethod::{
Sichpl_ssMethodsType,
    ctx: &Ctx,
) -> Result<Tokr()
    t = vaare th     l!("{}_
    _enum       use sy)n::Fievariant_ident =;
    } = ctx;
    ls = simple_en3_path::PyClas3.rs/latearg_hat s,
}

assEnumUnit  ls = simple_epyident;
     rg_hat
    } = ctx;
    ls = simple_enct> for #cls {
  }

i as3.rs/latearg  // Need to rig the eno      me: N_py_fo(cls,    .rs/lateae: N_pyc    {
 :f    sArcls F    sArArg    Aead = input  le me: Nt optino      me: Ne?exelds::Univarifn build_py_fo(ciant| {
        yObjs {
  }

i        "#[pycrArgriants
            {
    &arg_hat s,
},.span() => "M:newriant rg_hat
        other: &#pyo3_p sAraldPyO3Options {
     ython_name(dPyO3Options {
     ythoyObjA sOptions {
     s_impead(||pan::c
    lepyclass_imPyO3Optios 3_p_enum(falsepyclass_imPyO3Optios kw_enum(falsepyclass_imPyO3Optios cancel_handlem(falsepyclass_imPyO3}{}",
     ]t mut options =      _alls, syn:ttrs)?;

         plex_enu?
   (crArgriants
            {
    tNamedField,.span() => "M:newriann identifier"),
          _p sAraldPyO3Options {
     ython_name(dPyO3Options {
     ythoyObjfalsepyclass_imPyO3Optipead(||pan::c
    lepyclass_imPyO3Optios 3_p_enum(falsepyclass_imPyO3Optios kw_enum(falsepyclass_imPyO3Optios cancel_handlem(falsepyclass_imPyO3}a;
    l.as}yclass_impls }",
 nt.span

    githure_pyc    {
 :f    sArclF    sArS githureut  le mrgu    s  vari
    args.op    AttrnSp  riants
    ted i    {
sEnum:):Fn
   ::FnNewpyclass_im{
    &are th     l!("syn:sEnum::cArgA stroemF"    }
     (do()
     : are th     l!("sytrinF"    }
       githurenew(
       nv allArc i    {
sEnum:):CallingC nv allArc:TpNewpyclass_im ;

_  githuredPyO3Options {
 a = c}`",dPyO3Options {
 unsaferianyO3Options {
 ds/encassArgs Ds/encassArgs       le,       # Naric    {
 :sEnum:):riants _plsBui:       e&ant_ident ={ #cls:d p  ,num_)?;
 um,    let cls _ant_iden   }
 lassMe     or_elant_ident =;
    }tNamedField<'a> {
 elds:riant: lds
struct PyClassEnumStr_   ident: &'plexPythonDoc,
    methods_ethod::{
    impl_>sMethodsTyp  githure_pyc    {
 :f    sArclF    sArS githureut  le mrgu    s _fo(cli
    args.op f<Se
      i    {
sEnum:):if l
   ::TryF leo3_paRef(umStr_   i)    args.op    AttrnSp  riants
    ted i    {
sEnum:):Fn
   ::GassMex f<Se
   s
    leanned!(
   {
    tName     ,.span() =(do()
     : alds:riants
    le   }
       githurenew(
       nv allArc i    {
sEnum:):CallingC nv allArc:Noer = PyClassIm ;

_  githuredPyO3Options {
 a = c}`",dPyO3Options {
 unsaferianyO3Options {
 ds/encassArgs Ds/encassArgs       le,       # Nariidentrop  tye
      i    {
 :sEnum:):Prop  ty
   ::F    sArtVariant<'a> {
{ #cl|| C {
{ #cl   }
      p  hon p  ,impl_buil PyCli    {
 without []s");
  ,       # NariidenlassMe  ic    {
 :sEnum:):riants _lassMeu   (ant_ident ={ #cls:trop  tye
       le?exented()lassMea?;
 um,    cls,
        args,
   se(|| Cow::Owned(cls.u);
       num varia&R;
   Allstruct EnumVssEnu   Pynum variau   Py>yn::Ident,
    args: &PyClassArgs,
    doc: PythonDoc,
    fielOptions)>,
    methods_type:   lethod::{
    impl_>>sMethodsTypty   let cls = simple_enum.ident;
     let  arg             s,        (umStr_   ex, (umStrttrs)?;
 )et_alent,
    args           i.referenc              );
    ribute>) -> Result<Self> {
                       PyClassrepr =  let mut options = FieldPyO3Options {
 ,
) umVaria       Ok{
_object(py));
     ace(name).is_some()yO3Optio(iant, USELESSeturn Err(syn::Ero3__int__()   FieldPyO3Opt {
                    iidenlassMe  iriants _lassMeu   (syn::parse_quote! tifier"),
          Prop  ty
   ::D   cls,
 ent(cls, variant.get_idumStr_   ex,t(cls, variant.get_idumStr,t(cls, variant.get_id(do()
     :             e            cls,
     ect(py));
ame_all {
 :u);
       enStre);
       |u);
       e              }
                 }
             get_ident(), __py:nctuated::<Token arg?
   (lassMea;
    l.aso3__int__()   ums can't e    }FieldPyO3Opent(cls, varianriantPyO3Option:u   Pyensure_spanFiel options.namcan
   use Ident,
  e    ty    `u   Py`> Resu")t.span() => "Must sassMe  iriants _sassMeu   (syn::parse_quote! tifier"),
          Prop  ty
   ::D   cls,
 ent(cls, variant.get_idumStr_   ex,t(cls, variant.get_idumStr,t(cls, variant.get_id(do()
     :             e            cls,
     ect(py));
ame_all {
 :u);
       enStre);
       |u);
       e              }
                 }
             get_ident(), __py:nctuated::<Token arg?
   (sassMea;
    l.asoyclass] ented()n argault_int
    s = complexor_else(|| Cow::Owned(cls.unead: 
    complex_enum: s/encassArgs m varia&Ds/encassArgiant,  fielOptions)>,
    mf let Ok(othMethodsType,
    ctx: &Ctx,
) -> Result<TokenS         = format!(
                lf.gnew_name = a;>ent;
        Py  ir  ums can'tM   Pyibute>,
}ri         quoget_id                Py {            }
    #pyo3_pao      m        }an't#s(#valm(compleut.parse().map(E   }
    #pyo3_pao      m            le       # Nari   }
                  #p s/encased        #[dunsafeoc(doc)
    .impl_all(     re::HasPyGilRef        impl #pyo3_path:
    AsRefTer et { .. } => {
     ell if le;
    l.aso3__int__()unsafeoc(doc)
    .impl_all(     re::Py
   Ilet        impl #pyo3_path:cArgA turn:arse_quote! {
=    i     ;l #pyo3_path:cArgA MODULn:a::stdpao      m      <rse_quote! {o_py#    Pyess=witness))
 #[inline]t richcmp_impl: all(     re_e(||yObject> for #cls {
  }

i     * letect> for #clffi::Py
   to_py(self, py: #pyo3_pat #pyo3_path::con/enlude::Py
   yObject;
                #ds/encassArg 
                <   im quopy, pyclass args{
 :o
    eOp>, ki
ich>::lazye
        ret        #pyo3_path::In: &PyCr  let(          #pyo3_path::Ine   
    ptch_arms: Vec<Tok}t::Struct(struct_variant         s   gA ODO(msyn::Idby Ident bail_`.rianriantS          y,);

i        s ODO(msy(doc) all ds/    y  the va    ,.iantlyinpead = inp    Ident bail_`,tlyinhouname =s.rianassS   o3_);

doesnned,
    // TODO(msy(doc)ds/   s y  }

/// trs)?;
lyin  span: Span,.edField<'a>>,
 fault_slots ntPyO3Optiose(|| truct PyClassEnumVanead: 
et_class_pythoxEnum<'_>,
    args: &PyClassArgs,
    doc:    &args,
     :m   lethod::{
    impl_> doc:    &argsargs):m   lethod::{
Sichpl_s_enum: PyCl      <assComple syn::Ident,
    variafault_slots ntPyO3Optioriant<'[];

    let|| truct PyClassEnumVaumVanead: 
et_class_pythoxEnum<num<'_>,
    args: &PyClassArgs,
    doc: oc:    &args,
     :m   lethod::{
    impl_> doc: oc:    &argsargs):m   lethod::{
Sichpl_s_enum:                .col           .collecthods_type,
       ead PyClassImssImplsBuilder::new(
     l.as   &args,
     new(
     l.as   &argsargs))),
  mpl_buil PyClyO3Options {
 , get_ident(&selhoutath::P PyClassComple                .col           .collect PyCl}an'ttx,
)),
  mpl_buil..ath:tions {
 , get_ident(&sel  ),
     -> &EnOptions)>    methods_type: PyClassMethodthodsTyptype:she [      #[dt<'a> {
.riants  = #py  le,      #[dt<'a> {
.riant  }
   ;

   le,      #[dt<'a> {
.riant<#pyo3_p  le,      #[dt<'a> {
.riants  = #prian     d,      #[dt<'a> {
.riantss_io t    Pyy  le,      #[dt<'a> {
.riantPyClassPy  le,         ]
?;
 ?;
            if let Some     }
     let Somd()type:s) get_ident(&sel  ),
s  = #py -> &EnOptions)>    mf let Ok(othMethodthodsType,
    ctx: &Ctx,
) -> Result   };

    let> {
.PyC;pelds::Univariueak a rur  > {
.d            u   Pyensu                    i   }
    #3_path::con/:o
    eelf>ean_ match::Truek}t::Struct(ut.parse().map(EnumV   }
    #3_path::con/:o
    eelf>ean_ match::Falsek(py.NotImplem
    l.as   }
            })
            .colletx { pyo       impl #pyo3_path::Int
    Feak a ru#u   Py;arms: Vec<Tok}t::Struct(struct_nt(&sel  ),
  }
   ;

  -> &EnOptions)>    mf let Ok(othMethodthodsType,
    ctx: &Ctx,
) -> Result   };

    let> {
.PyC;p_int__()   > {
.d            u   Pyensu                    i   }
   yclass_imPyO3Optiodent,
, 'py>uopy, pyclass args{
  .variamrgu    cls F    sArArgu    t,
, 'py>u    
et_   iyclass_imPyO3Optint(cls, variant.get_id
    Ho);

   ::stdpao      m      <                  '       i>>            })
        #[inline]t richcmp_imphcmp_impl:   .vari(   : 
et_     py: #pyo3_path     thon,
             ho);

      let     ::Ho);

        op: #pyo3_path::ba3_options(attrs:span() => "M:new(py, pyclass args{
  .variamrgu    cl  .varias )?;

          ho);

)         "isize",
  if let Ok(other) = other   fn __pyopeinfo

 ut.parse().map(EnumV   }
   yclass_imPyO3Optiodent,
, 'py>uopy, pyclass args{
  .variamrgu    cls F    sArArgu    t,
, 'py>u    
et_   iyclass_imPyO3Optint(cls, variant.get_id
    Ho);

   ::stdpao      m      <                  '       i>>            })
        #[inline]t richcmp_imphcmp_impl:   .vari(   : 
et_     py: #pyo3_path     thon,
             ho);

      let     ::Ho);

        op: #pyo3_path::ba3_options(attrs:span() => "M:new(py, pyclass args{
  .variamrgu    cl  .varias )?;

          ho);

)         "isize",
  if let Ok(othr.__pyo3__int__()).to_objodent,
, 'py>uopy, pyclass args{
  .variamrgu    cls F    sArArgu    t,
, 'py>u    
et_ lete  iyclass_imPyO3Optint(cls, variant.get_id
    Ho);

   ::stdpao      m      <                 Mut '       i>>            })
        #[inline]t richcmp_imphcmp_impl:   .vari(   : 
et_     py: #pyo3_path     thon,
             ho);

      let     ::Ho);

        op: #pyo3_path::ba3_options(attrs:span() => "M:new(py, pyclass args{
  .variamrgu    cl  .varias )?;

    ec<_>     ho);

)         "isize",
  if let Ok(other) = other   fn __pyopeinfo

  get_ident(&sel  ),
<#pyo3_p -> &EnOptions)>    mf let Ok(othMethodthodsType,
    ctx: &Ctx,
) -> Result   };

    let> {
.PyC;p_int__()lateae: let> {
.ae:     rigged_arIf    imt!(
   ons.kr         we defau     ->into_py(so3_path::Pp_int__()   d            ons.kraensure_sparse().map(EnumV   }
   yclass_imPyO3Optioden       .collect();

        quote! {
            impl #pyo3_path::Int:IntoPy<#pyo3_path::PyObject> for #cls {
                fn into_py(self, py: #pyo3_path::P:new(py, pyclass_init).unwrap();nt_cls);
                pyclaariant_v            #pyo3_path::IntoPy::into_py(variant_value, py)
opeinfo

 ut.parse().map(EnumV   }
   }t::Struct(struct_nt(&sel  ),
s  = #prian  -> &EnOptions)>    methods_type: PyClassMethodthodsType,
    ctx: &Ctx,
) -> Result   };

    let> {
.PyC;p_int__()latetx,let> {
.tx, {
       m Cow:ots,
    "\0"}, |tx,|V   }
   #tx,name => #cls::#vnsubs


      l {
.d            nit = #pensu      me => #cls::#vbs

ns(&mut val {
.d            ons.kratse().map(EnumV}an'tons.kra_elf.get> ons.kra_elf.e      
    lepyclass_imPyO3    lt>         let mu
 thon,
               }
     }me => #cls::#vnsuby the varil {
.d            ons.kraensu      me => #cls::#vnsum Cping: elf>aril {
.d            m Cpingensu      me => #cls::#vnsusequence: elf>aril {
.d            sequenceensu      me
, varianriantPyO3Option:yclass_imPyO3!(nsum Cping &&vnsusequencee,      #[dt<'a> {
.PyC options.nama Ident bail_` can
   be elCtxa Im Cping`tlyinp `sequence`    name.slexelds::Univaridiriaoffset {    > {
.d            diriensu                    i   }
   yclass_imPyO3Optiselhiriaoffset(    m::stdpao      m      <            ffi::Py_#prze_ttions(attrs:span() => "M::stdpao      m        }an't#py, pyclass args{
 :o
    ehiriaoffset::a3_opt())oPy::into_py(variant_value, py)
opeinfo

 ut.parse().map(EnumVtype: PyCla       py.NotImplem
    l.as_arins = {optcantPyOwroze   elds::UnivariwrozassPaoffset {    > {
.d            wroz   ensu                    i   }
   yclass_imPyO3OptiselwrozassPaoffset(    m::stdpao      m      <            ffi::Py_#prze_ttions(attrs:span() => "M::stdpao      m        }an't#py, pyclass args{
 :o
    ewrozassPaoffset::a3_opt())oPy::into_py(variant_value, py)
opeinfo

 ut.parse().map(EnumVtype: PyCla       py.NotImplem
    l.assTypthyCld_checkMe  ir  > {
.d            uns ndparsensu                    i   }
    #3_path::con args{
 :o
    eThyCldCheckMefaulk}t::Struct(ut.parse().map(EnumV   }
    #3_path::con args{
 :o
    eS ndparstx { py<   i>k(py.NotImplem
    l.asvari( :sEnum:    arg intv alory intv aloryformat)ns(&mut v> {
.plsBuilder::self) -> &EnumVariantPssArgs,
    eS        _int, .naots,
          }
or.s _plsBuis   }ants;
  );
  ,     > &EnumVariantPssArgs,
    eItv aloryte! {
                anaso defau modsiariadentplsBuis] block  we defineintv alory er::s?ants
            .itentv aloryformat        ct PyClass= vec![];

    buil .dobuildare the "P_passArgs,Itv aloryFor
    _enelse(||      cls,
     ect(py))                     cls,
     ect(value = #pyo3_path:![];

    buil .dobuilass_ident(cls, variant.get_id> "M::stdpaboxedpyo3x= vec![];

    buil .dobuilt_id> "M::stdpa    PyCmp   or::nStr[];

    buil .dobuilt_id> "M:new(py, pyclass tv alorypa    Py<a3_opm quopy, pyclass args{
 :o
    eOp>, ki
ich>::Itv alory>panned!(
                   > "M:new(py, pyclass args{
 :o
    eOp>, ki
tv alorypa   msned!(
                   > "M)

                   > "M)

                   }    cls,
     ect(py))     ts,
     er::sItv aloryte #ntv aloryformat     ; }anned!(
       ect(py))     define_ntv aloryformat(&ntv aloryformat         lei    cls,
     ect(v      _ => Ok(py.NotImplem
    l.aseinfo = implplsBuisaril {
),
  mpl_buil.o = implplsBuis{
        let match_arms: Vec<TokenStreplsB| &plsB.p  ocith(PisEnum:                hainr[];

    buil .do> {
.t  &argsargs)       #pyo3_path::Ine          cls,
        <TokenStreplsB| &plsB.p  ocith(PisEnum:  args),
         
    l.aseinfo = implplsBuiu   varil {
.o = implplsBuisefault_methodplsB| &plsB.plsBuiu    me => #cls::#vt  &argsargsu   varil {
.o = implargs)efault_methodargs| & ich.argsu    me => #cls::#vPyClassPl_pytypeil {
.PyClassPl_pyty(  let pytyp   };

   mat mutability      > {
.d            u   Pyensu                    i   }
   yclass_imPyO3OptiImmutableChildther   fn __pyopeinfo

 ut.parse().map(EnumV   }
   yclass_imPyO3OptiMutableChildther   fn __pyopeinfo

 t pytyp   };

    let> {
.PyC;p_int__()lateae: let> {
.ae:     riggedvaridiri      d            diriensu                    i   }
   w(py, pyclass args{
 :o
    eOp>, kiDiriSichk}t::Struct(ut.parse().map(EnumV   }
    #3_path::con args{
 :o
    eOp>, kiDummySichk}t::Struct(em
    l.as_arins = {optcantPyOwroze   elds::Univariwrozr   va   d            wroz   ensu                    i   }
    #3_path::con args{
 :o
    eOp>, kiWrozRefSichk}t::Struct(ut.parse().map(EnumV   }
    #3_path::con args{
 :o
    eOp>, kiDummySichk}t::Struct(em
    l.as.itebs

dn_inv

         d            ons.kraensu                    i   }
    <    ::Bs

x;
   quopy, pyclass args{
 :o
    eOp>, kiBs

x;
 >::Bs

N_inv
x;
  }t::Struct(ut.parse().map(EnumV   }
    #3_path::con       t::Struct(em
    l.asslots,
    )
    .doOptioden       .colle args{
 :o
    eOp>, ki
ich        impl #pyo3_path::IntcArgA IS_BASETYPE: elf>ari#nsubs


   ;l #pyo3_path::IntcArgA IS_SUBCLASS: elf>ari#nsuby the v;l #pyo3_path::IntcArgA IS_MAPPING: elf>ari#nsum Cping;l #pyo3_path::IntcArgA IS_SEQUENCE: elf>ari#nsusequence            })
    
    Bs

x;
  ri#bs

;          })
    
    ThyCldCheckMe ri#thyCld_checkMe;
                #ntv alory          })
    
    ariantPsutability   <<#bs

  quopy, pyclass args{
 :o
    eOp>, kiBs

x;
 >::ariantPsutability  quopy, pyclass args{
 :oell::ariantPsutability>::#  mat mutability;          })
    
    Diri   #diri;          })
    
    WrozRef   #wroz   ;          })
    
    Bs

N_inv
x;
  ri#bs

dn_inv

               })
    sel   ms      i             fn  args{
 :o
    eOp>, ki
  msCmp ent(cls, variant.get_id #pyo3_path::con args{
 :o
    e*alue = #pyo3_path::Py:;

      }
or    let defaulC    }
or::a3_opt       s,    ];

    buil .do>_quoteINTRINSIC_ITEMSs: &PyClaI arg    &PyClaI arg nt(cls, variant.get_id> "M,
     :m&[#(#o = implplsBuiu   v),*]nned!(
                   args):m&[#(#o = implargsu   v),*o#o#eyClassPl_pyty),*]nned!(
               }s,    ];

    buil .doOp>, ki
  msCmp lass);
INTRINSIC_ITEMS   thsEnum:    arg) let Ok(othr.__pyo3__int__()).to_objselhoutyObject> for #cls {
  }

i        op: #pyo3_path::barse_quote::stdpaffi::CS {o_ent(cls, variant.get_id #pyo3_path::con args{
 :o
    e*alue = #pyo3_path::Py:e_quoteDOCbject> for #cl = c::GILOnce ell ::stdpaborrow    w<se_quot,e::stdpaffi::CS {o> { .. } => {
   = c::GILOnce ell       s,    ];

    buil .doDOC: &PyCr tryf let(  , || {
                    #cls::#v     }
or    let defaulC    }
or::a3_opt       s,    ];

    buil .doooooctx);as )?;

 hout<   im quopy, pyclassPy
   Ilett  turn    {
       }
or.e()y ;

_  githure())oPy::into_py(variPyO3}ametho::stdpao s::D rl_= d rl_) let Ok(othr.__pyo3__int__()).to_obj#hiriaoffset3__int__()).to_obj#wrozassPaoffset3__int__()).to_objsellazye
        ret ::parse_quoteo3_path::con args{
 :o
    eLazy
   to_py(a3_options(attrs:span() => "M #pyo3_path::con args{
 :o
    eLazy
   to_py(alue = #pyo3_path::Py:e_quoteTYPE_OBJECT: Lazy
   to_py(a   i>k= Lazy
   to_py(       s,    ];

    buil .do&TYPE_OBJECToPy::into_py(variant_value, py)
o         })
         #pytypeinfo

  

        #pyclass_impls

        #[dOptioden    impl #pyo3_path::Int#(#o = implplsBui {
         "isi
o         })
  ntv aloryformat:new(enum_)?;
   dent(&sel  ),
 s_io t    Pyy -> &EnOptions)>    mf let Ok(othMethodthodsType,
    ctx: &Ctx,
) -> Result   };

    let> {
.PyC;p_int__()ts,
    )
    .doOptioden    impl #pyo3_path::Int#       #pytypeinfo

  

  t_id(ubtcArgA _PYO3_DEF:w(py, pyclass args{
 :s   Py::Addet deToM   Pya3_opti=w(py, pyclass args{
 :s   Py::Addet deToM   Py       s,    ];

    yopeinfo

  get_ident(&sel  ),
PyClassPy -> &EnOptions)>    mf let Ok(othMethodthodsTyp   let> {
.PyC;p_int__()latee,
    ctx: &Ctx,
) -> Result< .do> {
.d            u ClassP {
       m Cow:ots,
  {}, |u ClassP   let variants_to_iu ClassPet_iu ClassP      ;e().map(EnumV   }
   yclass_imPyO3Optioden       .colle args{
 :o
    eOp>, kiWithF ClLssPe       impl #pyo3_path::Int:Int#[inline]t richcmp_imphcmp_impl:  &Pyu Cl_assPyyObject> for #cls {
  }

i     & letect> for #cl args{
u ClassP::F ClLssP<* letect> for #clffi::Py
            ) -> #pyo3_paath::Py:e_quote letFREELIST: * letect> for #cl args{
u ClassP::F ClLssP<* letect> for #clffi::Py
       = 0m qu* let_s,    ];

    buil .dooooounsafeo(other) = other.extract::<#pyo   FREELISTensurull Ok(other) = other.extract::<#pyo#[pycREELIST   ::stdpaboxedpyo3x= nwrape(||::stdpaboxedpyo3x= vec![];

    buil .dobuilt_id> "M> "M:new(py, pyclass args{
u ClassP::F ClLssP::    dcapacityo#eyClassP)n Ok((self_val != other.__py::IntoPy::into_py(vari    buil .do& let*cREELIST            return Ok((self_val != i).to_objecttoPy::into_py(variant_value, py)
opeinfo

 )?;
   dent(&selPyClassPl_pyty( -> &EnOptions)>    m   let enum_into_MethodthodsType,
    ctx: &Ctx,
) -> Result   };

    let> {
.PyC;pelds::Uni   > {
.d            u ClassP nsu                    i_fo(ciant| {
     builass_ident(cls, variant.get_idect> for #clffi::Py
   _Sichk{ned!(
                   args:dect> for #clffi::Py_tp
   ocnned!(
                   pf   :       .colle args{
 :o
    e   oc     du ClassP::a   i>k qu* let_,f_val != i).to_objecttoPy::into_py(varia,iant| {
     builass_ident(cls, variant.get_idect> for #clffi::Py
   _Sichk{ned!(
                   args:dect> for #clffi::Py_tp
u Clnned!(
                   pf   :       .colle args{
 :o
    eu Cl_    du ClassP::a   i>k qu* let_,f_val != i).to_objecttoPy::into_py(varia,iant| {
     ]t::Struct(ut.parse().map(EnumV          plex_enum(complex_enum,define_ntv aloryformat(ntv aloryformat     

sions)
    }
Options)>    mf let Ok(othMethodsType,
    ctx: &Ctx,
) -> Result   }
                    #pytypeinfo

  (ubt}

/// ontv aloryformat      {tuated::<Token arg:          fn  args{
 :o
    eOp>, ki
  ms,
    l.as}yclass_imoden  ntv aloryformat      {tuated::<Toke(ubtcArgA riant<'n arg:          fn  args{
 :o
    eOp>, ki
  ms                .col    .col      t  arg other   fn __pyopeinfo

  
 .doOptioden       .colle args{
 :o
    eOp>, ki
tv aloryt     ntv aloryformat      {tuated::<Tokesel   ms( -> &     &         fn  args{
 :o
    eOp>, ki
  ms       .col    .colal {
.   msned!(
       yopeinfo

  
 .doOpti(py, pyclass tv alorypa     }
!( ntv aloryformat     pyclass]   
cArgA UNIQUE_GET

si: let"` &P` may) all s.fr      e  y ce";
cArgA UNIQUE_SET

si: let"`s&P` may) all s.fr      e  y ce";
cArgA UNIQUE_turn:ari: let"`    ` may) all s.fr      e  y ce";

cArgA DUPE_SET

si: let" #pless `s&P` -Need }

/// iim lyCldy an
  th(P      `s&P
   `";
cArgA DUPE_GET

si: let" #pless `g&P` -Need }

/// iim lyCldy an
  th(P      `g&P
   `";
cArgA UNIT_GET

si: leclass"`g&P
   `ty   nnnts
 }

/// does(
  hing, s.ca #pynts
 }

///s have(
  trs)?;";
cArgA UNIT_SET

si: leclass"`s&P
   `ty   nnnts
 }

/// does(
  hing, s.ca #pynts
 }

///s have(
  trs)?;";

cArgA USELESSeturn:ari: let"`    ` isyn::less     olet`g&P`    `s&P`";
                                                     