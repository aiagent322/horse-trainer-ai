use std::cell::UnsafeCell;
use std::collections::HashMap;
use std::fmt;
use std::marker::PhantomData;
use std::mem;
use std::ops::{Deref, DerefMut};
use std::panic::{RefUnwindSafe, UnwindSafe};
use std::sync::{LockResult, PoisonError, TryLockError, TryLockResult};
use std::sync::{Mutex, RwLock, RwLockReadGuard, RwLockWriteGuard};
use std::thread::{self, ThreadId};

use crate::sync::once_lock::OnceLock;
use crate::CachePadded;

/// The number of shards per sharded lock. Must be a power of two.
const NUM_SHARDS: usize = 8;

/// A shard containing a single reader-writer lock.
struct Shard {
    /// The inner reader-writer lock.
    lock: RwLock<()>,

    /// The write-guard keeping this shard locked.
    ///
    /// Write operations will lock each shard and store the guard here. These guards get dropped at
    /// the same time the big guard is dropped.
    write_guard: UnsafeCell<Option<RwLockWriteGuard<'static, ()>>>,
}

/// A sharded reader-writer lock.
///
/// This lock is equivalent to [`RwLock`], except read operations are faster and write operations
/// are slower.
///
/// A `ShardedLock` is internally made of a list of *shards*, each being a [`RwLock`] occupying a
/// single cache line. Read operations will pick one of the shards depending on the current thread
/// and lock it. Write operations need to lock all shards in succession.
///
/// By splitting the lock into shards, concurrent read operations will in most cases choose
/// different shards and thus update different cache lines, which is good for scalability. However,
/// write operations need to do more work and are therefore slower than usual.
///
/// The priority policy of the lock is dependent on the underlying operating system's
/// implementation, and this type does not guarantee that any particular policy will be used.
///
/// # Poisoning
///
/// A `ShardedLock`, like [`RwLock`], will become poisoned on a panic. Note that it may only be
/// poisoned if a panic occurs while a write operation is in progress. If a panic occurs in any
/// read operation, the lock will not be poisoned.
///
/// # Examples
///
/// ```
/// use crossbeam_utils::sync::ShardedLock;
///
/// let lock = ShardedLock::new(5);
///
/// // Any number of read locks can be held at once.
/// {
///     let r1 = lock.read().unwrap();
///     let r2 = lock.read().unwrap();
///     assert_eq!(*r1, 5);
///     assert_eq!(*r2, 5);
/// } // Read locks are dropped at this point.
///
/// // However, only one write lock may be held.
/// {
///     let mut w = lock.write().unwrap();
///     *w += 1;
///     assert_eq!(*w, 6);
/// } // Write lock is dropped here.
/// ```
///
/// [`RwLock`]: std::sync::RwLock
pub struct ShardedLock<T: ?Sized> {
    /// A list of locks protecting the internal data.
    shards: Box<[CachePadded<Shard>]>,

    /// The internal data.
    value: UnsafeCell<T>,
}

unsafe impl<T: ?Sized + Send> Send for ShardedLock<T> {}
unsafe impl<T: ?Sized + Send + Sync> Sync for ShardedLock<T> {}

impl<T: ?Sized> UnwindSafe for ShardedLock<T> {}
impl<T: ?Sized> RefUnwindSafe for ShardedLock<T> {}

impl<T> ShardedLock<T> {
    /// Creates a new sharded reader-writer lock.
    ///
    /// # Examples
    ///
    /// ```
    /// use crossbeam_utils::sync::ShardedLock;
    ///
    /// let lock = ShardedLock::new(5);
    /// ```
    pub fn new(value: T) -> ShardedLock<T> {
        ShardedLock {
            shards: (0..NUM_SHARDS)
                .map(|_| {
                    CachePadded::new(Shard {
                        lock: RwLock::new(()),
                        write_guard: UnsafeCell::new(None),
                    })
                })
                .collect::<Box<[_]>>(),
            value: UnsafeCell::new(value),
        }
    }

    /// Consumes this lock, returning the underlying data.
    ///
    /// # Errors
    ///
    /// This method will return an error if the lock is poisoned. A lock gets poisoned when a write
    /// operation panics.
    ///
    /// # Examples
    ///
    /// ```
    /// use crossbeam_utils::sync::ShardedLock;
    ///
    /// let lock = ShardedLock::new(String::new());
    /// {
    ///     let mut s = lock.write().unwrap();
    ///     *s = "modified".to_owned();
    /// }
    /// assert_eq!(lock.into_inner().unwrap(), "modified");
    /// ```
    pub fn into_inner(self) -> LockResult<T> {
        let is_poisoned = self.is_poisoned();
        let inner = self.value.into_inner();

        if is_poisoned {
            Err(PoisonError::new(inner))
        } else {
            Ok(inner)
        }
    }
}

impl<T: ?Sized> ShardedLock<T> {
    /// Returns `true` if the lock is poisoned.
    ///
    /// If another thread can still access the lock, it may become poisoned at any time. A `false`
    /// result should not be trusted without additional synchronization.
    ///
    /// # Examples
    ///
    /// ```
    /// use crossbeam_utils::sync::ShardedLock;
    /// use std::sync::Arc;
    /// use std::thread;
    ///
    /// let lock = Arc::new(ShardedLock::new(0));
    /// let c_lock = lock.clone();
    ///
    /// let _ = thread::spawn(move || {
    ///     let _lock = c_lock.write().unwrap();
    ///     panic!(); // the lock gets poisoned
    /// }).join();
    /// assert_eq!(lock.is_poisoned(), true);
    /// ```
    pub fn is_poisoned(&self) -> bool {
        self.shards[0].lock.is_poisoned()
    }

    /// Returns a mutable reference to the underlying data.
    ///
    /// Since this call borrows the lock mutably, no actual locking needs to take place.
    ///
    /// # Errors
    ///
    /// This method will return an error if the lock is poisoned. A lock gets poisoned when a write
    /// operation panics.
    ///
    /// # Examples
    ///
    /// ```
    /// use crossbeam_utils::sync::ShardedLock;
    ///
    /// let mut lock = ShardedLock::new(0);
    /// *lock.get_mut().unwrap() = 10;
    /// assert_eq!(*lock.read().unwrap(), 10);
    /// ```
    pub fn get_mut(&mut self) -> LockResult<&mut T> {
        let is_poisoned = self.is_poisoned();
        let inner = unsafe { &mut *self.value.get() };

        if is_poisoned {
            Err(PoisonError::new(inner))
        } else {
            Ok(inner)
        }
    }

    /// Attempts to acquire this lock with shared read access.
    ///
    /// If the access could not be granted at this time, an error is returned. Otherwise, a guard
    /// is returned which will release the shared access when it is dropped. This method does not
    /// provide any guarantees with respect to the ordering of whether contentious readers or
    /// writers will acquire the lock first.
    ///
    /// # Errors
    ///
    /// This method will return an error if the lock is poisoned. A lock gets poisoned when a write
    /// operation panics.
    ///
    /// # Examples
    ///
    /// ```
    /// use crossbeam_utils::sync::ShardedLock;
    ///
    /// let lock = ShardedLock::new(1);
    ///
    /// match lock.try_read() {
    ///     Ok(n) => assert_eq!(*n, 1),
    ///     Err(_) => unreachable!(),
    /// };
    /// ```
    pub fn try_read(&self) -> TryLockResult<ShardedLockReadGuard<'_, T>> {
        // Take the current thread index and map it to a shard index. Thread indices will tend to
        // distribute shards among threads equally, thus reducing contention due to read-locking.
        let current_index = current_index().unwrap_or(0);
        let shard_index = current_index & (self.shards.len() - 1);

        match self.shards[shard_index].lock.try_read() {
            Ok(guard) => Ok(ShardedLockReadGuard {
                lock: self,
                _guard: guard,
                _marker: PhantomData,
            }),
            Err(TryLockError::Poisoned(err)) => {
                let guard = ShardedLockReadGuard {
                    lock: self,
                    _guard: err.into_inner(),
                    _marker: PhantomData,
                };
                Err(TryLockError::Poisoned(PoisonError::new(guard)))
            }
            Err(TryLockError::WouldBlock) => Err(TryLockError::WouldBlock),
        }
    }

    /// Locks with shared read access let p = => Erri};
                Err(TryLockError::Poiso => E      
    //deturned [`Unparker`] dutab local var# Poisoni[`park_t availabl///nt.
nrefore s lock fiharedhMPTY lock ge.`Unparker`] re     letaccessers willt
    /// ins resisoned.
//akes
 n error ifTIFIED`    /// provi`Unparker any partwith respect to the ordering of whether contentious readers or
    /// writers wilcs.
    //rhe lock first.
    ///
    /// # Errors
    ///
    //ence to thGuard shared access when it is dropped. This metd: UnsafeCell  ///
    /// This method will return an error if the lock is poisoned. A lock gets poisoned when a write
    /// operation panics.
    ///
    /// # Examples
    ///
    //If `f` panics, the pani an error ifmight/ read eratiead `NO. A lock gets p      PA     ker`].
(TryLockError:mples
    ///
    /// ```
    /// use crossbeam_utils::sync::ShardedLock;
    /// use std::sync::Arc;
    /// use std::thread;
    ///
    /// let lock = Arc::new(ShardedLock::new(0));
    /// let c_lock1= lock.clone();
    ///
    /// let _ = thread::spawn(move n;
///     assert_eq!(*r1,k.read().unwrap(), 1_) =>d::spawn(move || {
    ///     thread::sleep(Duration:wrap(p();
    /  asse // the lock gmpleted(r            /// // Wa_eq!(lort_eq!(*r1,k.read()(&self) -> TryLesult<ShardedLoeadGuard<'_, T>> {
        // Take the current thread index and map it to a shard index. Thread indices will tend to
        // distribute shards among threads equally, thus reducing contention due to read-locking.
        let current_index = current_index().unwrap_or(0);
        let shard_index = current_index & (self.shards.len() - 1);

        match self.shards[shard_index].lock.try_read() {
          (guard) => Ok(ShardedLockReadGuard {
                lock: self,
                _guard: guard,
                _marker: PhantomData,
            }),
            Err(TryLockError::Poisoned(    ouldBloc))
            }
                lock: self,
                _guard: guard,
                               _marker: PhantomDat           }),
            Err(TryLo /// Locks with shared read s lock with shared read access.
   exclus    
/// { If the access could not be granted at this time, an error is returned. Otherwise, a guard
    /// is returned which will release the shared access when it iexclus    ed. This method does not
    /// provide anich will partwith respect to the ordering of whether contentious readers or
    /// writers will acquire the lock first.
    ///
    /// # Errors
    ///
    /// This method will return an error if the lock is poisoned. A lock gets poisoned when a write
    /// operation panics.
    ///
    /// # Examples
    ///
    /// ```
    /// use crossbeam_utils::sync::ShardedLock;
    ///
    /// let lock = ShardedLock::new(1);
    ///
    /// match lock.try_read() {ove n;
///     assert_eq!(*r1,k.read().unwrap(), 1_) =>d::spawn(move || {mpleted(       Ok//     p   iso( fn park_timeout(&self, tim  Ok//    <ShardedLockReadGuard<'_, T>> {
   >>,
}

/// Ae the current throck::newoned();
   hould;rrent throck::new[`park_t=(m).uhe inner value>>,
}-re the guard herBy splitting th { .. }")ned(i,ard he)rBy s
        malock  penum
   erd) => Ok(ShardedReadGuard {
_index]    .       Ok//     : self,
           LockReadGuard_marker: PhantomData,
 ned(err)) => {
                let guard = ShardedLock(&selned();
   pub 
                }
                  _
           }
            };

     Block) => Err(TryLockError::Woulduard = ShardedLock(&se[`park_t=(     iif now < deadline {
   b  ak;        };

            if self
               ows ese guards get  read the curr.*self.value.get()).asard = ShardedLockReadGuard: c, ()>>>,
}

/// A sharded re {
_d::scells:neeckReadG;ard = ShardedLockReaddest: *:new|| { curr.::new(None)nce.callrd = ShardedLock*destt=(     kReadG;ard = Sharded Otherwise we need to deadline {
ieq!([`park_tthe current threaUn on the c//
/// By rck msontentie internt_index = cur. }")nedrd herBy soisoned()
  ..i]alock  prck  : self,
           et()).asard = ShardedLockLockReaddest: *:new|| { curr.::new(None)nce.callrd = ShardedLockrdedReadGuard {
(*dest). ///callrd = ShardedLockrdednwrapkReadG;ard = ShardedLock}    Err(TryLockError::WouldBlock) => Err(TryLockError::W       Ok(inner) deErr(PoisonError::new(inReadGuard {
           >>,
}

///: self,
                _guard: guard,
                   }),
            Err(TryL;
Error::Poisoned(PoisonError::new(guard)))
            }
            Err(T(inner)
        }
    }
           >>,
}

///: self,
                _guard: guard,
                   }),
            Err(TryL)// Locks with shared read access let exclus    
/// { If th            Err(TryLockError::Poiso => E      
    //deturned [`Unparker`] dutab local var# Poisoni[`park_t availabl///nt.
nrefore s lock fiharedhMPTY lock ge.`Unparker`] re     letaccessers willt
    /// ins resisoned.
//akes
 n error ifTIFIED`    /// provi`Unparker any partwith respect to the ordering of whether contentious readers or
    /// writers wilcs.
    //rhe lock first.
    ///
    /// # Errors
    ///
    //ence to thGuard shared access when it iexclus    ed. This metd: UnsafeCell  ///
    /// This method will return an error if the lock is poisoned. A lock gets poisoned when a write
    /// operation panics.
    ///
    /// # Examples
    ///
    //If `f` panics, the pani an error ifmight/ read eratiead `NO. A lock gets p      PA     ker`].
(TryLockError:mples
    ///
    /// ```
    /// use crossbeam_utils::sync::ShardedLock;
    /// use std::sync::Arc;
  rdedLock::new(1);
    ///
    /// match lock.try_read() {ove :newn);
    ///     *s = "modified".to_*n   sta:spawn(move || {mpleted(       Ok  asser   iso( fn park_timeout(&self, tim//    <ShardedLoeadGuard<'_, T>> {
   >>,
}

/// Ae the current throck::newoned();
   hould;r inner value>>,
}-re the guard herBy splitting th { .. }")nedrd herBy soisoned()
alock  ) => Ok(ShardedReadGuard {
_index]    .     //     : self,
           LockReadGuard_marker: PhantomData,
 ned(    oulduard = ShardedLock(&selned();
   pub 
                }
                  _
           }
            };

 
               ows ese guards get  read the curr.*self.value.get()).asard = ShardedLockReadGuard: c, ()>>>,
}

/// A_ed re {
Guard;ard = ShardedLockReadGuard: c, ()>>>,
}

/// A sharded re {
_d::scells:neeckReadG;ard = ShardedLockReaddest: *:new|| { curr.::new(None)nce.callrd = ShardedLock*destt=(     kReadG;ard = Sharded Otherwise we need to deErr(PoisonError::new(inner))
        } else            >>,
}

///: self,
                _guard: guard,
                   }),
            Err(TryL)     Err(T(inner)
        }
    }
           >>,
}

///: self,
                _guard: guard,
                   }),
            Err(TryL)// Locks with shadedLock<T> {
     +r {
    fn >r {
    fn fmt(&/ Returns `true` if tmt::Formatter<'_>) -> fmt::Result {
        f.pad("Unparker { .. }"_index].loc  Ok(guard) => Ok(ShardedLockReadGuarde
                ..is_coSized>("/ Returns `"ect::<Box<[_]>>(),
fi   ("ince", &&*kReadGct::<Box<[_]>>(),
finish(ockError::Poisoned(err)) => {
                let ge
                ..is_coSized>("/ Returns `"ect::<Box<[_]>>(),
fi   ("ince", &&**    ockRref()Gct::<Box<[_]>>(),
finish(ockError::Poisoned(err)) => {
   ockError::Woulduard = ShardedLockSized> Lpark_P ErrhMPT p = Par             rker {
    fn fmt(&Lpark_P ErrhMPT pduard = ShardedLock(&semt::Formatter<'_>) -> fmt::Result {
        f.pad("Unparker { .. }" ShardedLock(&sem.::new(Siz("<`park_>"ect::<Box<[_]>>(),
            };

            if self(&sem..is_coSized>("/ Returns `"ect::<Box<[_]>>(),>(),
fi   ("ince", &Lpark_P ErrhMPT pect::<Box<[_]>>(),>(),
finish(oard = Sharded Otherwise wth shadedLock<T>   fn de>   fn default/ Returns `true` if tmt:     Self {
   ShardedLock {
            shards:  else   fn de/// Blocks  for OnceLock<T> {
From> {
mt(&/ Returns `true` if tmt::rom(t{
                 unpar  shards:  else ta thread parkedAds get can a    drop(seit is droppErri};
     each [wLock`], will]is metd: Unsafe#[clippy::has_sign     n   }
}]<T: ?Sized> {
    /// A     // Taka thist of locks pro     _&'a&/ Returns `truata<*coGuard: c, ()>     // Taka t
}

impl onst ()>,
}

unsafe ic, ()>     // Taka tT>ized + Send> Send for ShardedLock<T> {}

impl<T: ?Sized>     // Take thewindSafe for ShardedLic::{
impl<T: ?Sized>     // Take thewiimpl  thatTarthe = T       mt:  ref(debug_assert!(self.onceue.get() }*());
      if is_poisonwth shadedLock<T>  {
    fn >r {
    fn fmt(&/ Returns `     // Take thewiimpl mt::Formatter<'_>) -> fmt::Result {
        f.pad("Unparker { .. }")
.is_coSized>("/ Returns `     // T"ect::<Box<[_]>
fi   ("    ", &());
    ect::<Box<[_]>
finish(oard =hadedLock<T> {
     +r {
   isplay>r {
   isplayfmt(&/ Returns `     // Take thewiimpl mt::Formatter<'_>) -> fmt::Result {
        f.pad("Unparker { .. }"(**());).:Forfa thread parkedAds get can a    drop(seit iexclus    
/// { If th each [wLock`], will]is metd: Unsafe#[clippy::has_sign     n   }
}]<T: ?Sized> {
    /// A>>,
}

/// Aa thist of locks pro     _&'a&/ Returns `truata<*const ()>,
}

unsafe ic, ()>>>,
}

/// Aa th>ized + Send> Send for ShardedLock<T> {}

impl<T: ?Sized>>>,
}

/// Ae thewindSafe for ShardedLi   fn dr<T: ?Sized>>>,
}

/// Ae thewi {
        if self.once.is_completreaUn on the c//
/// By rck msontentie internt_index = cur)nedrd herBy soiso          malock  prck  : self,
       et()).asard = ShardedLockReaddest: *:new|| { curr.::new(None)nce.callrd = ShardedLockReadGuard {
(*dest). ///callrd = ShardedLocknwrapkReadG;ard = Sharded Otherwise wth shadedLock<T>  {
    fn >r {
    fn fmt(&/ Returns `>>,
}

/// Ae thewi {
     :Formatter<'_>) -> fmt::Result {
        f.pad("Unparker { .. }")
.is_coSized>("/ Returns `>>,
}

///"ect::<Box<[_]>
fi   ("    ", &());
    ect::<Box<[_]>
finish(oard =hadedLock<T> {
     +r {
   isplay>r {
   isplayfmt(&/ Returns `>>,
}

/// Ae thewi {
     :Formatter<'_>) -> fmt::Result {
        f.pad("Unparker { .. }"(**());).:Forfa thread paafe for ShardedLic::{
impl<T: ?Sized>>>,
}

/// Ae thewi {
   thatTarthe = T       mt:  ref(debug_assert!(self.onceue.get() }*());
      if is_poisonwth shadedLock<T> ShardedLic::{Mutfn dr<T: ?Sized>>>,
}

/// Ae thewi {
      c::{Result<&mut T> {
  s_pois!(self.onceue.get() };

             if is_poisonwth shaded  //ence to th` cont`/ poisooper  pusr`].
(TryLockError:mp::sync::E gua to a shs
pub struct eringan '{
   '. Wis inabl///nt.
nrebe used.
// to the or,       /s::sync      ribute // inonsecu, itan be hsd thread 0ed
     an be held aunn local varsmp::sync:: the lock mfunc.
    If thusrTLS, `Ne parkight/b doesn't ha. A loc(TryLockError:'srTLSbeca|| {
eaious downfe#[inr sc]
rkerr(0);
        {
  <'stati contewi {
  REGISTRATION   Ok/rin(|reg|doeg.     ).     }rds per shglobae logthreyked.
    /rvelyld atgthrere://github.d
        // The innsync::o     //leep(DuratMap
    to `s`sync::on`ther co a shard ndex =map
   : use std<sync::on,d contl data.
    ing the infree       // {
   ree_g th: Vec< contl data.
    T   Err(Nn() - th sl     }

 A locfree g theck`]    / {
  Err(      rd contzed +tim ync::_      /  {
  &A shardondvar,sync::o     />ze,
    locrdoTHREAD_INDICES: chePadde<ndvar,sync::o     />e {
chePadde= p.unparker(LockRielf {
 ndvar,sync::o     />ze,
                  sync::o     //leep(D { .. }"_ip
   : use std  }),
            },
 ree_g th: Vec  }),
            },
Err(      rd0/// Locks wa threadthreTHREAD_INDICES ockRor_kRielkRie)d parkedAdlogthre   ///each al var# Pingan hard nd::sync::W metd: Unsa,/ };
gthrers[`park`] or d
   reesit_timee bef shard ndThe innRogthre   ///,
}

uns   rd contzeion::from__id: sync::on, park(&sei   fn drRogthre   ///,
}

u      if self.once.is_completock::new      //=m ync::_      /      match self.staer.clone()    //_ip
   prchrea(debug.:from__idstaer.clone()    // ree_g th.push(     }
   )          
:from__    l!ze,
    locrdoREGISTRATION:rRogthre   ///=.is_completock::from__id| {
    ///rr(0);
ser = unsafe { &mut *:new      //=m ync::_      /      match self.stasafe { &mut *seself.s_index()    // ree_g th.pop(adline) => self.park_iWouldielf.park(),
        }
sard = ShardedLockReadif.s()    //Err(       = Par             )    //Err(      q!(*w,  Par             ard = Sharded Otherwise taer.clone()    //_ip
   pinlete(:from__id, }
   )  aer.cloneRogthre   ///,
}

uer.clone() exelf.park(),
  :from__