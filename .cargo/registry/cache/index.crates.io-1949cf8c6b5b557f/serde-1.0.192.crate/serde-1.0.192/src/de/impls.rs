use crate::lib::*;

use crate::de::{
    Deserialize, Deserializer, EnumAccess, Error, MapAccess, SeqAccess, Unexpected, VariantAccess,
    Visitor,
};

use crate::seed::InPlaceSeed;

#[cfg(any(feature = "std", feature = "alloc"))]
use crate::de::size_hint;

////////////////////////////////////////////////////////////////////////////////

struct UnitVisitor;

impl<'de> Visitor<'de> for UnitVisitor {
    type Value = ();

    fn expecting(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
        formatter.write_str("unit")
    }

    fn visit_unit<E>(self) -> Result<Self::Value, E>
    where
        E: Error,
    {
        Ok(())
    }
}

impl<'de> Deserialize<'de> for () {
    fn deserialize<D>(deserializer: D) -> Result<Self, D::Error>
    where
        D: Deserializer<'de>,
    {
        deserializer.deserialize_unit(UnitVisitor)
    }
}

#[cfg(feature = "unstable")]
#[cfg_attr(doc_cfg, doc(cfg(feature = "unstable")))]
impl<'de> Deserialize<'de> for ! {
    fn deserialize<D>(_deserializer: D) -> Result<Self, D::Error>
    where
        D: Deserializer<'de>,
    {
        Err(Error::custom("cannot deserialize `!`"))
    }
}

////////////////////////////////////////////////////////////////////////////////

struct BoolVisitor;

impl<'de> Visitor<'de> for BoolVisitor {
    type Value = bool;

    fn expecting(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
        formatter.write_str("a boolean")
    }

    fn visit_bool<E>(self, v: bool) -> Result<Self::Value, E>
    where
        E: Error,
    {
        Ok(v)
    }
}

impl<'de> Deserialize<'de> for bool {
    fn deserialize<D>(deserializer: D) -> Result<Self, D::Error>
    where
        D: Deserializer<'de>,
    {
        deserializer.deserialize_bool(BoolVisitor)
    }
}

////////////////////////////////////////////////////////////////////////////////

macro_rules! impl_deserialize_num {
    ($primitive:ident, $nonzero:ident $(cfg($($cfg:tt)*))*, $deserialize:ident $($method:ident!($($val:ident : $visit:ident)*);)*) => {
        impl_deserialize_num!($primitive, $deserialize $($method!($($val : $visit)*);)*);

        $(#[cfg($($cfg)*)])*
        impl<'de> Deserialize<'de> for num::$nonzero {
            fn deserialize<D>(deserializer: D) -> Result<Self, D::Error>
            where
                D: Deserializer<'de>,
            {
                struct NonZeroVisitor;

                impl<'de> Visitor<'de> for NonZeroVisitor {
                    type Value = num::$nonzero;

                    fn expecting(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
                        formatter.write_str(concat!("a nonzero ", stringify!($primitive)))
                    }

                    $($($method!(nonzero $primitive $val : $visit);)*)*
                }

                deserializer.$deserialize(NonZeroVisitor)
            }
        }
    };

    ($primitive:ident, $deserialize:ident $($method:ident!($($val:ident : $visit:ident)*);)*) => {
        impl<'de> Deserialize<'de> for $primitive {
            #[inline]
            fn deserialize<D>(deserializer: D) -> Result<Self, D::Error>
            where
                D: Deserializer<'de>,
            {
                struct PrimitiveVisitor;

                impl<'de> Visitor<'de> for PrimitiveVisitor {
                    type Value = $primitive;

                    fn expecting(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
                        formatter.write_str(stringify!($primitive))
                    }

                    $($($method!($val : $visit);)*)*
                }

                deserializer.$deserialize(PrimitiveVisitor)
            }
        }
    };
}

macro_rules! num_self {
    ($ty:ident : $visit:ident) => {
        #[inline]
        fn $visit<E>(self, v: $ty) -> Result<Self::Value, E>
        where
            E: Error,
        {
            Ok(v)
        }
    };

    (nonzero $primitive:ident $ty:ident : $visit:ident) => {
        fn $visit<E>(self, v: $ty) -> Result<Self::Value, E>
        where
            E: Error,
        {
            if let Some(nonzero) = Self::Value::new(v) {
                Ok(nonzero)
            } else {
                Err(Error::invalid_value(Unexpected::Unsigned(0), &self))
            }
        }
    };
}

macro_rules! num_as_self {
    ($ty:ident : $visit:ident) => {
        #[inline]
        fn $visit<E>(self, v: $ty) -> Result<Self::Value, E>
        where
            E: Error,
        {
            Ok(v as Self::Value)
        }
    };

    (nonzero $primitive:ident $ty:ident : $visit:ident) => {
        fn $visit<E>(self, v: $ty) -> Result<Self::Value, E>
        where
            E: Error,
        {
            if let Some(nonzero) = Self::Value::new(v as $primitive) {
                Ok(nonzero)
            } else {
                Err(Error::invalid_value(Unexpected::Unsigned(0), &self))
            }
        }
    };
}

macro_rules! num_as_copysign_self {
    ($ty:ident : $visit:ident) => {
        #[inline]
        fn $visit<E>(self, v: $ty) -> Result<Self::Value, E>
        where
            E: Error,
        {
            #[cfg(any(no_float_copysign, not(feature = "std")))]
            {
                Ok(v as Self::Value)
            }

            #[cfg(all(not(no_float_copysign), feature = "std"))]
            {
                // Preserve sign of NaN. The `as` produces a nondeterministic sign.
                let sign = if v.is_sign_positive() { 1.0 } else { -1.0 };
                Ok((v as Self::Value).copysign(sign))
            }
        }
    };
}

macro_rules! int_to_int {
    ($ty:ident : $visit:ident) => {
        #[inline]
        fn $visit<E>(self, v: $ty) -> Result<Self::Value, E>
        where
            E: Error,
        {
            if Self::Value::min_value() as i64 <= v as i64
                && v as i64 <= Self::Value::max_value() as i64
            {
                Ok(v as Self::Value)
            } else {
                Err(Error::invalid_value(Unexpected::Signed(v as i64), &self))
            }
        }
    };

    (nonzero $primitive:ident $ty:ident : $visit:ident) => {
        fn $visit<E>(self, v: $ty) -> Result<Self::Value, E>
        where
            E: Error,
        {
            if $primitive::min_value() as i64 <= v as i64
                && v as i64 <= $primitive::max_value() as i64
            {
                if let Some(nonzero) = Self::Value::new(v as $primitive) {
                    return Ok(nonzero);
                }
            }
            Err(Error::invalid_value(Unexpected::Signed(v as i64), &self))
        }
    };
}

macro_rules! int_to_uint {
    ($ty:ident : $visit:ident) => {
        #[inline]
        fn $visit<E>(self, v: $ty) -> Result<Self::Value, E>
        where
            E: Error,
        {
            if 0 <= v && v as u64 <= Self::Value::max_value() as u64 {
                Ok(v as Self::Value)
            } else {
                Err(Error::invalid_value(Unexpected::Signed(v as i64), &self))
            }
        }
    };

    (nonzero $primitive:ident $ty:ident : $visit:ident) => {
        fn $visit<E>(self, v: $ty) -> Result<Self::Value, E>
        where
            E: Error,
        {
            if 0 < v && v as u64 <= $primitive::max_value() as u64 {
                if let Some(nonzero) = Self::Value::new(v as $primitive) {
                    return Ok(nonzero);
                }
            }
            Err(Error::invalid_value(Unexpected::Signed(v as i64), &self))
        }
    };
}

macro_rules! uint_to_self {
    ($ty:ident : $visit:ident) => {
        #[inline]
        fn $visit<E>(self, v: $ty) -> Result<Self::Value, E>
        where
            E: Error,
        {
            if v as u64 <= Self::Value::max_value() as u64 {
                Ok(v as Self::Value)
            } else {
                Err(Error::invalid_value(Unexpected::Unsigned(v as u64), &self))
            }
        }
    };

    (nonzero $primitive:ident $ty:ident : $visit:ident) => {
        fn $visit<E>(self, v: $ty) -> Result<Self::Value, E>
        where
            E: Error,
        {
            if v as u64 <= $primitive::max_value() as u64 {
                if let Some(nonzero) = Self::Value::new(v as $primitive) {
                    return Ok(nonzero);
                }
            }
            Err(Error::invalid_value(Unexpected::Unsigned(v as u64), &self))
        }
    };
}

impl_deserialize_num! {
    i8, NonZeroI8 cfg(not(no_num_nonzero_signed)), deserialize_i8
    num_self!(i8:visit_i8);
    int_to_int!(i16:visit_i16 i32:visit_i32 i64:visit_i64);
    uint_to_self!(u8:visit_u8 u16:visit_u16 u32:visit_u32 u64:visit_u64);
}

impl_deserialize_num! {
    i16, NonZeroI16 cfg(not(no_num_nonzero_signed)), deserialize_i16
    num_self!(i16:visit_i16);
    num_as_self!(i8:visit_i8);
    int_to_int!(i32:visit_i32 i64:visit_i64);
    uint_to_self!(u8:visit_u8 u16:visit_u16 u32:visit_u32 u64:visit_u64);
}

impl_deserialize_num! {
    i32, NonZeroI32 cfg(not(no_num_nonzero_signed)), deserialize_i32
    num_self!(i32:visit_i32);
    num_as_self!(i8:visit_i8 i16:visit_i16);
    int_to_int!(i64:visit_i64);
    uint_to_self!(u8:visit_u8 u16:visit_u16 u32:visit_u32 u64:visit_u64);
}

impl_deserialize_num! {
    i64, NonZeroI64 cfg(not(no_num_nonzero_signed)), deserialize_i64
    num_self!(i64:visit_i64);
    num_as_self!(i8:visit_i8 i16:visit_i16 i32:visit_i32);
    uint_to_self!(u8:visit_u8 u16:visit_u16 u32:visit_u32 u64:visit_u64);
}

impl_deserialize_num! {
    isize, NonZeroIsize cfg(not(no_num_nonzero_signed)), deserialize_i64
    num_as_self!(i8:visit_i8 i16:visit_i16);
    int_to_int!(i32:visit_i32 i64:visit_i64);
    uint_to_self!(u8:visit_u8 u16:visit_u16 u32:visit_u32 u64:visit_u64);
}

impl_deserialize_num! {
    u8, NonZeroU8, deserialize_u8
    num_self!(u8:visit_u8);
    int_to_uint!(i8:visit_i8 i16:visit_i16 i32:visit_i32 i64:visit_i64);
    uint_to_self!(u16:visit_u16 u32:visit_u32 u64:visit_u64);
}

impl_deserialize_num! {
    u16, NonZeroU16, deserialize_u16
    num_self!(u16:visit_u16);
    num_as_self!(u8:visit_u8);
    int_to_uint!(i8:visit_i8 i16:visit_i16 i32:visit_i32 i64:visit_i64);
    uint_to_self!(u32:visit_u32 u64:visit_u64);
}

impl_deserialize_num! {
    u32, NonZeroU32, deserialize_u32
    num_self!(u32:visit_u32);
    num_as_self!(u8:visit_u8 u16:visit_u16);
    int_to_uint!(i8:visit_i8 i16:visit_i16 i32:visit_i32 i64:visit_i64);
    uint_to_self!(u64:visit_u64);
}

impl_deserialize_num! {
    u64, NonZeroU64, deserialize_u64
    num_self!(u64:visit_u64);
    num_as_self!(u8:visit_u8 u16:visit_u16 u32:visit_u32);
    int_to_uint!(i8:visit_i8 i16:visit_i16 i32:visit_i32 i64:visit_i64);
}

impl_deserialize_num! {
    usize, NonZeroUsize, deserialize_u64
    num_as_self!(u8:visit_u8 u16:visit_u16);
    int_to_uint!(i8:visit_i8 i16:visit_i16 i32:visit_i32 i64:visit_i64);
    uint_to_self!(u32:visit_u32 u64:visit_u64);
}

impl_deserialize_num! {
    f32, deserialize_f32
    num_self!(f32:visit_f32);
    num_as_copysign_self!(f64:visit_f64);
    num_as_self!(i8:visit_i8 i16:visit_i16 i32:visit_i32 i64:visit_i64);
    num_as_self!(u8:visit_u8 u16:visit_u16 u32:visit_u32 u64:visit_u64);
}

impl_deserialize_num! {
    f64, deserialize_f64
    num_self!(f64:visit_f64);
    num_as_copysign_self!(f32:visit_f32);
    num_as_self!(i8:visit_i8 i16:visit_i16 i32:visit_i32 i64:visit_i64);
    num_as_self!(u8:visit_u8 u16:visit_u16 u32:visit_u32 u64:visit_u64);
}

macro_rules! num_128 {
    ($ty:ident : $visit:ident) => {
        fn $visit<E>(self, v: $ty) -> Result<Self::Value, E>
        where
            E: Error,
        {
            if v as i128 >= Self::Value::min_value() as i128
                && v as u128 <= Self::Value::max_value() as u128
            {
                Ok(v as Self::Value)
            } else {
                Err(Error::invalid_value(
                    Unexpected::Other(stringify!($ty)),
                    &self,
                ))
            }
        }
    };

    (nonzero $primitive:ident $ty:ident : $visit:ident) => {
        fn $visit<E>(self, v: $ty) -> Result<Self::Value, E>
        where
            E: Error,
        {
            if v as i128 >= $primitive::min_value() as i128
                && v as u128 <= $primitive::max_value() as u128
            {
                if let Some(nonzero) = Self::Value::new(v as $primitive) {
                    Ok(nonzero)
                } else {
                    Err(Error::invalid_value(Unexpected::Unsigned(0), &self))
                }
            } else {
                Err(Error::invalid_value(
                    Unexpected::Other(stringify!($ty)),
                    &self,
                ))
            }
        }
    };
}

impl_deserialize_num! {
    i128, NonZeroI128 cfg(not(no_num_nonzero_signed)), deserialize_i128
    num_self!(i128:visit_i128);
    num_as_self!(i8:visit_i8 i16:visit_i16 i32:visit_i32 i64:visit_i64);
    num_as_self!(u8:visit_u8 u16:visit_u16 u32:visit_u32 u64:visit_u64);
    num_128!(u128:visit_u128);
}

impl_deserialize_num! {
    u128, NonZeroU128, deserialize_u128
    num_self!(u128:visit_u128);
    num_as_self!(u8:visit_u8 u16:visit_u16 u32:visit_u32 u64:visit_u64);
    int_to_uint!(i8:visit_i8 i16:visit_i16 i32:visit_i32 i64:visit_i64);
    num_128!(i128:visit_i128);
}

////////////////////////////////////////////////////////////////////////////////

struct CharVisitor;

impl<'de> Visitor<'de> for CharVisitor {
    type Value = char;

    fn expecting(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
        formatter.write_str("a character")
    }

    #[inline]
    fn visit_char<E>(self, v: char) -> Result<Self::Value, E>
    where
        E: Error,
    {
        Ok(v)
    }

    #[inline]
    fn visit_str<E>(self, v: &str) -> Result<Self::Value, E>
    where
        E: Error,
    {
        let mut iter = v.chars();
        match (iter.next(), iter.next()) {
            (Some(c), None) => Ok(c),
            _ => Err(Error::invalid_value(Unexpected::Str(v), &self)),
        }
    }
}

impl<'de> Deserialize<'de> for char {
    #[inline]
    fn deserialize<D>(deserializer: D) -> Result<Self, D::Error>
    where
        D: Deserializer<'de>,
    {
        deserializer.deserialize_char(CharVisitor)
    }
}

////////////////////////////////////////////////////////////////////////////////

#[cfg(any(feature = "std", feature = "alloc"))]
struct StringVisitor;
#[cfg(any(feature = "std", feature = "alloc"))]
struct StringInPlaceVisitor<'a>(&'a mut String);

#[cfg(any(feature = "std", feature = "alloc"))]
impl<'de> Visitor<'de> for StringVisitor {
    type Value = String;

    fn expecting(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
        formatter.write_str("a string")
    }

    fn visit_str<E>(self, v: &str) -> Result<Self::Value, E>
    where
        E: Error,
    {
        Ok(v.to_owned())
    }

    fn visit_string<E>(self, v: String) -> Result<Self::Value, E>
    where
        E: Error,
    {
        Ok(v)
    }

    fn visit_bytes<E>(self, v: &[u8]) -> Result<Self::Value, E>
    where
        E: Error,
    {
        match str::from_utf8(v) {
            Ok(s) => Ok(s.to_owned()),
            Err(_) => Err(Error::invalid_value(Unexpected::Bytes(v), &self)),
        }
    }

    fn visit_byte_buf<E>(self, v: Vec<u8>) -> Result<Self::Value, E>
    where
        E: Error,
    {
        match String::from_utf8(v) {
            Ok(s) => Ok(s),
            Err(e) => Err(Error::invalid_value(
                Unexpected::Bytes(&e.into_bytes()),
                &self,
            )),
        }
    }
}

#[cfg(any(feature = "std", feature = "alloc"))]
impl<'a, 'de> Visitor<'de> for StringInPlaceVisitor<'a> {
    type Value = ();

    fn expecting(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
        formatter.write_str("a string")
    }

    fn visit_str<E>(self, v: &str) -> Result<Self::Value, E>
    where
        E: Error,
    {
        self.0.clear();
        self.0.push_str(v);
        Ok(())
    }

    fn visit_string<E>(self, v: String) -> Result<Self::Value, E>
    where
        E: Error,
    {
        *self.0 = v;
        Ok(())
    }

    fn visit_bytes<E>(self, v: &[u8]) -> Result<Self::Value, E>
    where
        E: Error,
    {
        match str::from_utf8(v) {
            Ok(s) => {
                self.0.clear();
                self.0.push_str(s);
                Ok(())
            }
            Err(_) => Err(Error::invalid_value(Unexpected::Bytes(v), &self)),
        }
    }

    fn visit_byte_buf<E>(self, v: Vec<u8>) -> Result<Self::Value, E>
    where
        E: Error,
    {
        match String::from_utf8(v) {
            Ok(s) => {
                *self.0 = s;
                Ok(())
            }
            Err(e) => Err(Error::invalid_value(
                Unexpected::Bytes(&e.into_bytes()),
                &self,
            )),
        }
    }
}

#[cfg(any(feature = "std", feature = "alloc"))]
#[cfg_attr(doc_cfg, doc(cfg(any(feature = "std", feature = "alloc"))))]
impl<'de> Deserialize<'de> for String {
    fn deserialize<D>(deserializer: D) -> Result<Self, D::Error>
    where
        D: Deserializer<'de>,
    {
        deserializer.deserialize_string(StringVisitor)
    }

    fn deserialize_in_place<D>(deserializer: D, place: &mut Self) -> Result<(), D::Error>
    where
        D: Deserializer<'de>,
    {
        deserializer.deserialize_string(StringInPlaceVisitor(place))
    }
}

////////////////////////////////////////////////////////////////////////////////

struct StrVisitor;

impl<'a> Visitor<'a> for StrVisitor {
    type Value = &'a str;

    fn expecting(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
        formatter.write_str("a borrowed string")
    }

    fn visit_borrowed_str<E>(self, v: &'a str) -> Result<Self::Value, E>
    where
        E: Error,
    {
        Ok(v) // so easy
    }

    fn visit_borrowed_bytes<E>(self, v: &'a [u8]) -> Result<Self::Value, E>
    where
        E: Error,
    {
        str::from_utf8(v).map_err(|_| Error::invalid_value(Unexpected::Bytes(v), &self))
    }
}

impl<'de: 'a, 'a> Deserialize<'de> for &'a str {
    fn deserialize<D>(deserializer: D) -> Result<Self, D::Error>
    where
        D: Deserializer<'de>,
    {
        deserializer.deserialize_str(StrVisitor)
    }
}

////////////////////////////////////////////////////////////////////////////////

struct BytesVisitor;

impl<'a> Visitor<'a> for BytesVisitor {
    type Value = &'a [u8];

    fn expecting(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
        formatter.write_str("a borrowed byte array")
    }

    fn visit_borrowed_bytes<E>(self, v: &'a [u8]) -> Result<Self::Value, E>
    where
        E: Error,
    {
        Ok(v)
    }

    fn visit_borrowed_str<E>(self, v: &'a str) -> Result<Self::Value, E>
    where
        E: Error,
    {
        Ok(v.as_bytes())
    }
}

impl<'de: 'a, 'a> Deserialize<'de> for &'a [u8] {
    fn deserialize<D>(deserializer: D) -> Result<Self, D::Error>
    where
        D: Deserializer<'de>,
    {
        deserializer.deserialize_bytes(BytesVisitor)
    }
}

////////////////////////////////////////////////////////////////////////////////

#[cfg(any(feature = "std", all(not(no_core_cstr), feature = "alloc")))]
struct CStringVisitor;

#[cfg(any(feature = "std", all(not(no_core_cstr), feature = "alloc")))]
impl<'de> Visitor<'de> for CStringVisitor {
    type Value = CString;

    fn expecting(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
        formatter.write_str("byte array")
    }

    fn visit_seq<A>(self, mut seq: A) -> Result<Self::Value, A::Error>
    where
        A: SeqAccess<'de>,
    {
        let capacity = size_hint::cautious::<u8>(seq.size_hint());
        let mut values = Vec::<u8>::with_capacity(capacity);

        while let Some(value) = tri!(seq.next_element()) {
            values.push(value);
        }

        CString::new(values).map_err(Error::custom)
    }

    fn visit_bytes<E>(self, v: &[u8]) -> Result<Self::Value, E>
    where
        E: Error,
    {
        CString::new(v).map_err(Error::custom)
    }

    fn visit_byte_buf<E>(self, v: Vec<u8>) -> Result<Self::Value, E>
    where
        E: Error,
    {
        CString::new(v).map_err(Error::custom)
    }

    fn visit_str<E>(self, v: &str) -> Result<Self::Value, E>
    where
        E: Error,
    {
        CString::new(v).map_err(Error::custom)
    }

    fn visit_string<E>(self, v: String) -> Result<Self::Value, E>
    where
        E: Error,
    {
        CString::new(v).map_err(Error::custom)
    }
}

#[cfg(any(feature = "std", all(not(no_core_cstr), feature = "alloc")))]
#[cfg_attr(doc_cfg, doc(cfg(any(feature = "std", feature = "alloc"))))]
impl<'de> Deserialize<'de> for CString {
    fn deserialize<D>(deserializer: D) -> Result<Self, D::Error>
    where
        D: Deserializer<'de>,
    {
        deserializer.deserialize_byte_buf(CStringVisitor)
    }
}

macro_rules! forwarded_impl {
    (
        $(#[$attr:meta])*
        ($($id:ident),*), $ty:ty, $func:expr
    ) => {
        $(#[$attr])*
        impl<'de $(, $id : Deserialize<'de>,)*> Deserialize<'de> for $ty {
            fn deserialize<D>(deserializer: D) -> Result<Self, D::Error>
            where
                D: Deserializer<'de>,
            {
                Deserialize::deserialize(deserializer).map($func)
            }
        }
    }
}

forwarded_impl! {
    #[cfg(any(feature = "std", all(not(no_core_cstr), feature = "alloc")))]
    #[cfg_attr(doc_cfg, doc(cfg(any(feature = "std", feature = "alloc"))))]
    (), Box<CStr>, CString::into_boxed_c_str
}

forwarded_impl! {
    (T), Reverse<T>, Reverse
}

////////////////////////////////////////////////////////////////////////////////

struct OptionVisitor<T> {
    marker: PhantomData<T>,
}

impl<'de, T> Visitor<'de> for OptionVisitor<T>
where
    T: Deserialize<'de>,
{
    type Value = Option<T>;

    fn expecting(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
        formatter.write_str("option")
    }

    #[inline]
    fn visit_unit<E>(self) -> Result<Self::Value, E>
    where
        E: Error,
    {
        Ok(None)
    }

    #[inline]
    fn visit_none<E>(self) -> Result<Self::Value, E>
    where
        E: Error,
    {
        Ok(None)
    }

    #[inline]
    fn visit_some<D>(self, deserializer: D) -> Result<Self::Value, D::Error>
    where
        D: Deserializer<'de>,
    {
        T::deserialize(deserializer).map(Some)
    }

    fn __private_visit_untagged_option<D>(self, deserializer: D) -> Result<Self::Value, ()>
    where
        D: Deserializer<'de>,
    {
        Ok(T::deserialize(deserializer).ok())
    }
}

impl<'de, T> Deserialize<'de> for Option<T>
where
    T: Deserialize<'de>,
{
    fn deserialize<D>(deserializer: D) -> Result<Self, D::Error>
    where
        D: Deserializer<'de>,
    {
        deserializer.deserialize_option(OptionVisitor {
            marker: PhantomData,
        })
    }

    // The Some variant's repr is opaque, so we can't play cute tricks with its
    // tag to have deserialize_in_place build the content in place unconditionally.
    //
    // FIXME: investigate whether branching on the old value being Some to
    // deserialize_in_place the value is profitable (probably data-dependent?)
}

////////////////////////////////////////////////////////////////////////////////

struct PhantomDataVisitor<T: ?Sized> {
    marker: PhantomData<T>,
}

impl<'de, T: ?Sized> Visitor<'de> for PhantomDataVisitor<T> {
    type Value = PhantomData<T>;

    fn expecting(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
        formatter.write_str("unit")
    }

    #[inline]
    fn visit_unit<E>(self) -> Result<Self::Value, E>
    where
        E: Error,
    {
        Ok(PhantomData)
    }
}

impl<'de, T: ?Sized> Deserialize<'de> for PhantomData<T> {
    fn deserialize<D>(deserializer: D) -> Result<Self, D::Error>
    where
        D: Deserializer<'de>,
    {
        let visitor = PhantomDataVisitor {
            marker: PhantomData,
        };
        deserializer.deserialize_unit_struct("fn de&oTiD) -> Resulit_struct("fn de&o    marker: PhantomD      {
                if |"  ) => mvvisit_i8 i16:visit_i16 i32:visit_i32 i64:visit_i64);
    uint_to_self!(u32:visit_u32 u64:visit_u64);
}

impl_deserialize_num! {
    u32, NonZeroU32, deserialize
}

rror>
   +alize
}
2 $primiti*{
    mataram $ty) -> Rze
}

rror>
   +alze
}
2 $primiti*(deserializ$aous::: $visieserializ$    O, $idieserializ$ tri!(seq.nex, $idieserializ$ sign.
, $idieserializ$inignt, $id : Deserialize<'de>,)*> Deserialize<'de> for $ty  de{
    mataram<D>(deserializer: D) -> Resu<e{
    mataram<D>  if v as i128 >= $primitiv: D) -> Result<Self   +alize
}
1   +alize
}
2iti*deserializer).$( mataram  Rze
}

   +alze
}
2i*dalize<'de> t<Self, D::Error>
            where
                D: Deserializer<'de>,
            {
                struct NonZeroVisitor;

                impl<'de> Visitor<'de> fSeqecting(&s{
    mataram<D>(::Unsigned(0), &self))de> for PhantomDataVesu<e{
    mataram<D>>,lize(PrimitiveVisitor)
            }for $ty  de{
    mataram<D>(e = ();

    fn exeqecting(&s{
    mataram<D>or)
            }
                strucitiv: D) -> Result<Self   +alize
}
1   +alize
}
2iti*deserializer).alizer).$( mataram  Rze
}

   +alze
}
2i*dalize<'de>          impl<'de> Visitorcting(&self, formasu<e{
    mataram<D>t fmt::Formatter) -> fmt::Result {
                        formatter.write_str(stringify!($primitive))
                    }

                 self"($val : $visit);)*)*
                }

     -> Result<Self, D::Errr) -> fmt::Error>
    where
      $aous::: SeqAccess<'de>,
    {
        let capacir)
            }
                strucitivhint::cautious::<u8>(seq.size<'de>          impl<'de> Visitorctin
        while let So$ tri!(seq.next fmt::Formatter) -> fm          values.push(value);
   $aous::  }

        CString::new(valuealizer).alizer).$inignt(& while let, rror::custom)
  : $visit);)*)*
                }

     ze<'de> >(self$val : $visit);)*)*
   : $visit);)*)*
                }

 antomData,
   xeqecting( {)de> for PhantomData
            }
     / # fn example<'de, D>(deserivm_self {
    ($ty:iden<Self, D::Error>
          <(), D::Error>
    where
        D: Deserializer<'de>,
    {
        deseria       {
                struct NonZeroVisitor;

                impl<'de> Visitor<'de> fSeqng(&self, formatt dese'a{
    mataram e'a<D>alloc"))]asu<e{
    mataram<D>)sitor {
                 ype Va de{
    mataram<D>(e = ();

    fn exeqng(&self, formatt de{
    mataram<D>or)
            }
                strucitiv: D) -> Result<Self   +alize
}
1   +alize
}
2iti*deserializer).alizer).$( mataram  Rze
}

   +alze
}
2i*dalize<'de>          impl<'de> Visitorcting(&self, form()t fmt::Formatter) -> fmt::Result {
                        formatter.write_str(stringify!($primitive))
                    }

                 self"($val : $visit);)*)*
                }

     -> Result<Self, D::Errr) -> fmt::Error>
    wh      e
      $aous::: SeqAccess<'de>,
    {
        let capacir)
            }
                strucitivhint::cautious::<u8>(seq.size<'de>          impl<'de> Visitorctin
   $    O(& whi    Er:custom)
  : $visit);)*)*
 $ sign.
(& whi    Er,mut values = Vec::<u8>:T> $aous:: pacity(capac)t fmt::Formatter) -> fm    being Sometryunco/        value is ps     ? (Vec,ErroDehave LinkedList)fmt::Formatter) -> fm          values.push(value);
   $aous::  }

        CString::new(valuealizer).alizer).$inignt(& whi    Er,mrror::custom)
  : $visit);)*)*
                }

     ze<'de>()f$val : $visit);)*)*
   : $visit);)*)*
                }

 / # fn example<'de, D>(deserixeqng(&self, form/////////////any(feature = "std", all(not(thisummy          sign.
tr(doc_cfg, doc(cfg(any(feature = "std", feature t::nop_ sign.
:T> _  A: T, _n::visittriot(:visit_u!(ature = "alloc")))]
    #[cfg_ature = "std", feature ure = "alloc"))))]
    (), Box<CStr>, CString::into_boxed_c_str
}

forwarded_impBinaryHeap ?SiOrd(seq.si:vi,d_impBinaryHeap =    O,d_impBinaryHeap = tri!(seq.nextut values = Vec::<u8>:T> h_capacity(capac),d_impBinaryHeap = sign.
,d_impBinaryHeap =err(
)t f:visit_u!(ature = "alloc")))]
    #[cfg_ature = "std", feature ure = "alloc"))))]
    (), Box<CStr>, CString::into_boxed_c_str
}

forwarded_impBTreeSet ?SiEq +iOrd(seq.si:vi,d_impBTreeSet =    O,d_impBTreeSet == "s),d_impnop_ sign.
,d_impBTreeSet =inignt
)t f:visit_u!(ature = "alloc")))]
    #[cfg_ature = "std", feature ure = "alloc"))))]
    (), Box<CStr>, CString::into_boxed_c_str
}

forwarded_impLinkedListVisitq.si:vi,d_impLinkedList =    O,d_impLinkedList == "s),d_impnop_ sign.
,d_impLinkedList =     back
)t f:visit_u!(ature = "alrve sign of NaN.e ure = "alloc"))))]
    (), Box<C Self::Value)
          HashSet ?SiEq +iHash, S: BFIXMHasher +iDefa<'dsitq.si:vi,d_impHashSet =    O,d_impHashSet = tri!(seq.nex_and_hashertut values = Vec::<u8>:T> h_capacity(capac, S::defa<'d }
}

#[cHashSet = sign.
,d_impHashSet =inignt
)t f:visit_u!(ature = "alloc")))]
    #[cfg_ature = "std", feature ure = "alloc"))))]
    (), Box<CStr>, CString::into_boxed_c_str
}

forwarded_imprroDehavVisitq.si:vi,d_imprroDehav =    O,d_imprroDehav = tri!(seq.nextut values = Vec::<u8>:T> h_capacity(capac),d_imprroDehav = sign.
,d_imprroDehav =     back
)t f///////////////////////

#[cfg(any(feature = "std", feature = "alloc"))]
struct StringVisitor;
#[cfg(any(feature = "std", feature = "alloc"))))]
impl<'de> Deserialize<'de> for CString {
    fn deserialize<D>(deize<'de>,
{
    fn deseriarror(deserializer: D) -> Result<Self, D::Error>
    where
        D: Deserializer<'de>,
    {
        deserializer.deserialize_option(OptionVisitor {
         <'de> frroecting(&self, for &self))de> for PhantomDataVT>,ustom)
    }

    fnT: Deserialize<'de>,
{
    typrroecting(&se  if v as i128 >= $primitiv: D) -> Result<Selfalue() as i128
         g(&self, formrror(d;n<Self, D::Error>Result {
                        formatter.write_str(stringify!($primitive))
            }

                 self"($val : $visiten<Self, D::Error>Error>
    where
        A: SeqAccess<'de>,
    {
        let capaci       }
                struc::cautious::<u8>(seq.size<'de> {             }

 anto      let mut values = Vec::<u8>:Tith_capacity(capacity);

   y);

        while let Some(valT) = tri!(seq.next_element()) {
      {
            values.push(value);
        }

        CString::new(valueew(values).map_err(Error::custom)
  );)*)*
                }

 de> >(self$val : $visit}ustom)
    }

    fnantomData,
   rroecting(serializer.deserialize_unit_struct("fn de&oTiD) -> Resulit_struct("fn de&o    maserivm_self {
    &mut Self) -> Result<(), D::Error>
    where
        D: Deserializer<'de>,
    {
        deserializer.deserialize_string(StringInPlaceVisitor(plac<'de> frrong(&self, formatt dese'a>alloc"))]rror(d()) {
            ype Va deize<'de>,
{
    typrrong(&self, formatt dee  if v as i128 >= $primitiv: D) -> Result<Selfalue() as i128
         g(&self, form()t fmt::Formatteor>Result {
                        formatter.write_str(stringify!($primitive))
            }

                 self"($val : $visiten<Self, D::Error>Error>
    where
        A: SeqAccess<'de>,
    {
        let capaci       }
                struc::cautious::<u8>(seq.size<'de> {             }

 antoy(cat mut values = Vec::<u8>:Tith_capacity(capacity);

   y);

   {
          adching onlue)y(ca.check wheub(       lenCString::new(valueew(value        sign.
(adching onlcustom)
  );)*)*
                }

  typite w0..       lenCSring::new(valueew(value     }

ue) impl<'de> Visitorctin
        }

 }

///= "))]
use cr(& whi    Er[i]:custom)
  : $visit);)*)*
 ;
        }

        _"all( }

 }

//)f$val : $visit);)*)*
  custom)
  : $visit);)*{
  }

  Ok E: (tring::new(valuealizer).aliz       'de    e(i:custom)
  : $visit);)*)*
        Errpacity);

   y);

   )*
   : $visit);)*)*
                }

       values.push(value);
        }

        CString::new(valueew(value           Error::custom)
  );)*)*
                }

 de>()f$val : $visit}ustom)
    }

    fnlit_struct("fn de&o    maserirrong(&self, form/////////////////////////////////////////

struct StrVisitor;

impl<'a> Visitor<'a> for StrVisitor {
    tyAsultf, formaAisitor<'de> for PhantomDataVAsitor
    tyAsultng(&self, formatt dAse'a>alloc"))]A) = &'a [AisAsultf, formaAisitor<'t::n "s)qAccSe]
       truc:sultf, formserializer.deserialize_unit_struct("fn de&oTire
    T: Deserialize<'e<'de>,
{
    typAsultf, forma[T; 0]elf, formatter: &mut [T; 0]) -> fmt::Result {
        formatter.write_str("a borrowed byte array")
    }

    fn visit_borrowed_bytes::Rmpletesult<Self::Value, Result<Self::Value, D::E    where
  _: SeqAccess<'de>,
    {
        let capacity = size_hint::cautious::<u8>(seq.size_hint())de>[]), all(not(thisoet ////r   i{
 : D) -> Result<Self.ize<D>(deize<'de>,
{
    fn deseria[T; 0] D::Error>
    where
        D: Deserializer<'de>,
    {
        deserializer.deserialize_byte_buf(CStringVisitor)
    }
}

macro_rules! forwarded_tuple(0,pAsultf, form8>:[T; 0]e == "s)#[$attr:meta])*
        esultsit_usE>(self, ($len, $ideria, ($nt : +) +)erialize<'de>,)*
           }for $ty  de<'e<'de>,
{
    typAsultf, forma[T; $len]capaci       }
                struc: D) -> Result<Selfalue() as de> {             }

 matter: &mut [T; $len])) {
      {
      t::Result {
                        formatter.write_str(stringify!($primitive))
         mitive)))
                    n esult    length    $len Err(Error::invalid_v
        }

     -> Result<Self, D::Errr) -or>Error>
    where
        A: SeqAccess<'de>,
    {
        let capaci       }   }
                strucitiv::cautious::<u8>(seq.size<'de>     {
                    Err[$(ustom)
  : $visit);)*)*
       ;
        }

        CString::new(valueew(valueeeeeeeeees.push()eriash(,ng::new(valueew(valueeeeeeeeeeriaeria       es(&e.into_bytes())length($n, v: Vec<u8>) -> Re
   y);

   )*
   : $visit);)*)*
 : Des,+]Err(Error::invalid_value(
       


                 ype Va de<'e<'de>,
{
    typAsultng(&self, formatt d[T; $len]capaci       }
                struc: D) -> Result<Selfalue() as de> {             }

 matter: &mut ()t fmt::Formatter) -t::Result {
                        formatter.write_str(stringify!($primitive))
         mitive)))
                    n esult    length    $len Err(Error::invalid_v
        }

     -> Result<Self, D::Errr) -or>Error>
    where
        A: SeqAccess<'de>,
    {
        let capaci       }   }
                strucitiv::cautious::<u8>(seq.size<'de>     {
                         whifail_idxut eria;primitive))
         mit (idx     t)te w    Er[..].    _ wh().enumer  e(tring::new(valueew(valueeeee{
 ;
        }

        _"all("))]
use cr(   t)))  Ok E: (tring::new(valuealizer).aliz    mail_idxut es.puidx:custom)
  : $visit);)*)*
     break;8>) -> Re
   y);

   )*
   : $visit);)*)*
 : De}ustom)
  : $visit);)*{
 values.puidx:ut mail_idxu{ustom)
  : $visit);)*)*
        es(&e.into_bytes())length(idx  v: Vec<; : $visit);)*)*
 : De}ustom)
  : $visit);)*de>()f$val : $visit);)*_value(
       


                 deize<'de>,
{
    fn deseria[T; $len]apaci       }
                struc: D) -> Result<Selfalue() as de> {             }

 or>
            where
                D: Deserializer<'de>,
            {   }
                strucitivt NonZeroVisitor;

                   {
                    

macro_rules! forwarded_tuple($len,pAsultf, form8>:[T; $len]c == "s)#[$att)
  );)*)*
                }

  r>
          <(), D::Error>
    where
        D: Deserializer<'de>,
    {
        deseria       {   }
                strucitivt NonZeroVisitor;

                   {
                    

macro_rules! forwarded_tuple($len,pAsultng(&self, form/////////////any(feat);)*_value(
       
)*
 : Des+[$attr:metesultsit_us////////1eria,0//////2eria,0 1//////3eria,0 1 2//////4eria,0 1 2 3//////5eria,0 1 2 3 4//////6eria,0 1 2 3 4 5//////7eria,0 1 2 3 4 5 6//////8eria,0 1 2 3 4 5 6 7//////9eria,0 1 2 3 4 5 6 7 8//////10eria,0 1 2 3 4 5 6 7 8 9//////11eria,0 1 2 3 4 5 6 7 8 9/10//////12eria,0 1 2 3 4 5 6 7 8 9/10/11//////13eria,0 1 2 3 4 5 6 7 8 9/10/11/12//////14eria,0 1 2 3 4 5 6 7 8 9/10/11/12/13//////15eria,0 1 2 3 4 5 6 7 8 9/10/11/12/13/14//////16eria,0 1 2 3 4 5 6 7 8 9/10/11/12/13/14/15//////17eria,0 1 2 3 4 5 6 7 8 9/10/11/12/13/14/15/16//////18eria,0 1 2 3 4 5 6 7 8 9/10/11/12/13/14/15/16/17//////19eria,0 1 2 3 4 5 6 7 8 9/10/11/12/13/14/15/16/17/18//////20eria,0 1 2 3 4 5 6 7 8 9/10/11/12/13/14/15/16/17/18/19//////21eria,0 1 2 3 4 5 6 7 8 9/10/11/12/13/14/15/16/17/18/19/20//////22eria,0 1 2 3 4 5 6 7 8 9/10/11/12/13/14/15/16/17/18/19/20/21//////23eria,0 1 2 3 4 5 6 7 8 9/10/11/12/13/14/15/16/17/18/19/20/21/22//////24eria,0 1 2 3 4 5 6 7 8 9/10/11/12/13/14/15/16/17/18/19/20/21/22/23//////25eria,0 1 2 3 4 5 6 7 8 9/10/11/12/13/14/15/16/17/18/19/20/21/22/23/24//////26eria,0 1 2 3 4 5 6 7 8 9/10/11/12/13/14/15/16/17/18/19/20/21/22/23/24/25//////27eria,0 1 2 3 4 5 6 7 8 9/10/11/12/13/14/15/16/17/18/19/20/21/22/23/24/25/26//////28eria,0 1 2 3 4 5 6 7 8 9/10/11/12/13/14/15/16/17/18/19/20/21/22/23/24/25/26/27//////29eria,0 1 2 3 4 5 6 7 8 9/10/11/12/13/14/15/16/17/18/19/20/21/22/23/24/25/26/27/28//////30eria,0 1 2 3 4 5 6 7 8 9/10/11/12/13/14/15/16/17/18/19/20/21/22/23/24/25/26/27/28/29//////31eria,0 1 2 3 4 5 6 7 8 9/10/11/12/13/14/15/16/17/18/19/20/21/22/23/24/25/26/27/28/29/30//////32eria,0 1 2 3 4 5 6 7 8 9/10/11/12/13/14/15/16/17/18/19/20/21/22/23/24/25/26/27/28/29/30/31)|"  ) => mvvisit_i8 i16:visit_i16 i32:visit_i32 i64:visit_i64);
    uint_to_self!(u32:visit_u32 u64tuplesit_usE>(self, ($len,tteria, ($nt : $namE>(self +) +)erialize<'de>,)*
           }for $ty  d ($namE>D) -> Result<Selfs,+<'de>,
{
    fn deseria( ($namE, +)e{
        }

     -> Result<Self, D::Errr) -or>
            where
                D: Deserializer<'de>,
            {   }
                strucitivt NonZeroVisitor;

                   {
                    
    tyTuplef, forma ($namE, +>u{ustom)
  : $visit);)*)*
 de> for PhantomDataV( ($namE, +)(seq.size<'de>                        }

     for $ty  d ($namE>D) -> Result<Selfs,+<'e<'de>,
{
    typTuplef, forma ($namE, +>u{ustom)
  : $visit);)*)*
 matter: &mut ( ($namE, +)t fmt::Formatter) -> fm    t::Result {
                        formatter.write_str(stringify!($primitive))
                 mitive)))
                    4tuple     num_   $len Err(Error::invalid);)*)*
                }

     ze<'-> Result<Self, D::Errr) -> fmze<'->fn dwr(Er_snake_case)]fmt::Formatter) -> fm    t::Error>
    where
        A: SeqAccess<'de>,
    {
        let capaci       }   }       }
                strucitivhinthint::cautious::<u8>(seq.size<'de>              impl<'de> Visitorctin
   de>,)*
           }                        $namEut       ;
        }

        CString::new(valueew(valueeeeeeeeeeeeeeeeees.push(ue)eriash(ue,ng::new(valueew(valueeeeeeeeeeeeeeeeeeriaeria       es(&e.into_bytes())length($n, v: Vec<u8>) -> Re
   y);

   )*
 );)*)*
  custom)
  : $visit);)*)*
 : Des+[ustom)
  : $visit);)*)*
 : Dede>( ($namE, +))8>) -> Re
   y);

   )*
   : $visit);)*)*
 : De}u
                    

macro_rules! forwarded_tuple($len,pTuplef, form {)de> for PhantomData
 Err(Error::invalid_v
        }

     -> Result<Self, D::Errr) -or>
          <(), D::Error>
    where
        D: Deserializer<'de>,
    {
        deseria       {   }
                strucitivt NonZeroVisitor;

                   {
                    
    tyTupleng(&self, formatt d ($namE>Dtt  +>alloc"))]( ($namE, +));              }

     for $type Va d ($namE>D) -> Result<Selfs,+<'e<'de>,
{
    typTupleng(&self, formatt d ($namE, +>u{ustom)
  : $visit);)*)*
 matter: &mut ()t fmt::Formatter) -> fm    t::Result {
                        formatter.write_str(stringify!($primitive))
                 mitive)))
                    4tuple     num_   $len Err(Error::invalid);)*)*
                }

     ze<'-> Result<Self, D::Errr) -> fmze<'->fn dwr(Er_snake_case)]fmt::Formatter) -> fm    t::Error>
    where
        A: SeqAccess<'de>,
    {
        let capaci       }   }       }
                strucitivhinthint::cautious::<u8>(seq.size<'de>              impl<'de> Visitorctin
   de>,)*
                                {
 ;
        }

        _"all("))]
use cr(     (      ).$n)))  Ok E: (tring::new(valuealizer).aliz    );)*)*
        es(&e.into_bytes())length($n, v: Vec<;8>) -> Re
   y);

   )*
 );)*)*
  ustom)
  : $visit);)*)*
 : Des+[ustom)
  : $visit);)*)*
 : Dede>())8>) -> Re
   y);

   )*
   : $visit);)*)*
 : De}u
                    

macro_rules! forwarded_tuple($len,pTupleng(&self, form/////////////any(feat);)*_value(
       
)*
 : Des+[$attr:mettuplesit_us////////1eeria,0 T0//////2eeria,0 T0/1eT1//////3eeria,0 T0/1eT1/2eT2//////4eeria,0 T0/1eT1/2eT2/3eT3//////5eeria,0 T0/1eT1/2eT2/3eT3/4eT4//////6eeria,0 T0/1eT1/2eT2/3eT3/4eT4/5eT5//////7eeria,0 T0/1eT1/2eT2/3eT3/4eT4/5eT5/6eT6//////8eeria,0 T0/1eT1/2eT2/3eT3/4eT4/5eT5/6eT6/7eT7//////9eeria,0 T0/1eT1/2eT2/3eT3/4eT4/5eT5/6eT6/7eT7/8eT8//////10eria,0 T0/1eT1/2eT2/3eT3/4eT4/5eT5/6eT6/7eT7/8eT8/9eT9//////11eria,0 T0/1eT1/2eT2/3eT3/4eT4/5eT5/6eT6/7eT7/8eT8/9eT9/10eT10//////12eria,0 T0/1eT1/2eT2/3eT3/4eT4/5eT5/6eT6/7eT7/8eT8/9eT9/10eT10/11eT11//////13eria,0 T0/1eT1/2eT2/3eT3/4eT4/5eT5/6eT6/7eT7/8eT8/9eT9/10eT10/11eT11/12eT12//////14eria,0 T0/1eT1/2eT2/3eT3/4eT4/5eT5/6eT6/7eT7/8eT8/9eT9/10eT10/11eT11/12eT12/13eT13//////15eria,0 T0/1eT1/2eT2/3eT3/4eT4/5eT5/6eT6/7eT7/8eT8/9eT9/10eT10/11eT11/12eT12/13eT13/14eT14//////16eria,0 T0/1eT1/2eT2/3eT3/4eT4/5eT5/6eT6/7eT7/8eT8/9eT9/10eT10/11eT11/12eT12/13eT13/14eT14/15eT15//"  ) => mvvisit_i8 i16:visit_i16 i32:visit_i32 i64:visit_i64);
    uint_to_self!(u32:visit_u32 u64, alit_u64);
}

impl_deserialize_num! {
    u32, NonZeroU32, dKserialkze
}

rror>
   +alkze
}
2 $primiti*, V{
    mataram $ty) -> Rze
}

rror>
   +alze
}
2 $primiti*(deserializ$aous::: $visieserializ$ tri!(seq.nex, $idieseriserialize<'de>,)*> Deserialize<'de> for $ty  dK, V{
    mataram<D>(deserializer: D) -> Resu<K, V{
    mataram<D>  if v as i128 >= $primitivK D) -> Result<Self   +alkze
}

   +alkze
}
2iti*deserializer).V D) -> Result<Selfalue() as de> $( mataram  Rze
}

   +alze
}
2i*),lize<'de> t<Self, D::Error>
            where
                D: Deserializer<'de>,
            {
                struct NonZeroVisitor;

                impl<'de> Visitor<'de> fMapf, formaK, V{
    mataram<D>(::Unsigned(0), &self))de> for PhantomDataVesu<K, V{
    mataram<D>>,lize(PrimitiveVisitor)
            }for $ty  dK, V{
    mataram<D>(e<'de>,
{
    typMapf, formaK, V{
    mataram<D>seria       {   }
                strucitivK D) -> Result<Self   +alkze
}

   +alkze
}
2iti*deserializer).alizer).V D) -> Result<Selfalue() as de>  as de> $( mataram  Rze
}

   +alze
}
2i*),lize<'de>          impl<'de> Visitorcting(&self, formesu<K, V{
    mataram<D>t fmt::Formatter) -> fmt::Result {
                        formatter.write_str(stringify!($primitive))
                    }

             , a"($val : $visit);)*)*
                }

     -> Result<Self, D::Errr) -> fmt::Error>, a  where
      $aous::: SeqAccess<'de>,
    {
        let capacir)
            }
                strucitivhint::cMapious::<u8>(seq.size<'de>          impl<'de> Visitorctin
        while let So$ tri!(seq.next fmt::Formatter) -> fm          values.pu(key,mrror::lue);
   $aous::  }

  ntryCString::new(valueew(valueeeeeeeees).map_inignt(key,mrror::custom)
  : $visit);)*)*
                }

     ze<'de> >(self$val : $visit);)*)*
   : $visit);)*)*
                }

 antomData,
   Mapf, form {)de> for PhantomData
            }
     / # fn example<'de, D>(de>(sevm_self {
    ($ty:idenfn de&oTire
    T: , alit_u feature = "alloc")))]
    #[cfg_ature = "std", feature ure = "alloc"))))]
    (), Box<CStr>, CString::into_boxed_c_str
}

forwarded_impBTreeMap<KSiOrd, V(seq.si, a,d_impBTreeMap == "s),dT: , alit_u feature = "alrve sign of NaN.e ure = "alloc"))))]
    (), Box<C Self::Value)
          HashMap<KSiEq +iHash, V, S: BFIXMHasher +iDefa<'dsitq.si, a,d_impHashMap = tri!(seq.nex_and_hashertut values = Vec::<u8>:(K, V)>(, aapacity(capac, S::defa<'d }
}
"  ) => mvvisit_i8 i16:visit_i16 i32:visit_i32 i64:visit_i64);
    uint_to_self!(u32:visit_u32 u64tarsesialit_u64);
}

impl_deserialize_num! {
    u32, NonZerpl<'dResult {
, $idi $paci:tteseriserialize<'de>,)*> Deserialize<'de> for $ty >(deserializer: D) -> Result<Self, D::Error>
            where
                D: Deserializer<'de>,
            {
                Deserialize::deserialize(deserializer).map($func)
       if / # fn examplis_human_read////(tring::new(valuealizer)./////////////////////////////From////////// == "sdResult {
):invalid_value(Unexpected::Unsigned(0), &self))<[u8; $paci]c =te_visit_untagged_option<D>(seVesu>d::Byt//////any(feat);)*_value(
       
)*
 : De cfg(not(no_ = "alrve sign of NaN.e visit_u32 u64th its
_ $visifier64);
}

impl_desernamE_kinttr])*
]( ($th its
tr])*
; $ere
 , $id;.$index, $id    impl_deserResult {
_ms::ag
, $idieserializ$th its
s_namE>(selfeseriserialize<'de>,enumernamE_kintd::Unsigned(0), ($th its
),lize<'de>            staticz$th its
s_namE> &[r,
 ]::Fo[$(where
ify!($th its
)),l];
ize<'de> for $ty >(deserializer: D) -> RenamE_kintd::Unsigned(0),or>
            where
                D: Deserializer<'de>,
            {
                struct NonZeroVisitor;

                impl<'de> Visitor<'de> fKint), featurer)
            }for $ty >(e<'de>,
{
    typKint), feat  impl<'de> Visitorcting(&self, formenamE_kintt fmt::Formatter) -> fmt::Result {
                        formatter.write_str(stringify!($primitive))
                    }

          rResult {
_ms::ag
($val : $visit);)*)*
                }

     e
        64        E: f, f:  64   {
        Ok(PhantomData)
   r)
            }
                strucitivhint, T: ?Sized> Dze<'de>          impl<'de> Visitorctin
         ////// impl<'de> Visitorctin
   de>,)*
                                $index(
     enamE_kintd:: $th its
),ustom)
  : $visit);)*)*
 : Des*ustom)
  : $visit);)*)*
 : De,
        }
    }
}

impl<'de> DeserializeUnsigexperror::, v: Vec,<u8>) -> Re
   y);

   )*
   : $visit);)*)*
 : De               }

     e
       
        E: Erf, f: r,
    {
        CString::new(v).mapr)
            }
                strucitivhint, T: ?Sized> Dze<'de>          impl<'de> Visitorctin
         ////// impl<'de> Visitorctin
   de>,)*
                                where
ify!($th its
)(
     enamE_kintd:: $th its
),ustom)
  : $visit);)*)*
 : Des*ustom)
  : $visit);)*)*
 : De,
        }
    unknown_th its
error:,z$th its
s_namE)<u8>) -> Re
   y);

   )*
   : $visit);)*)*
 : De               }

     e
       ere
        E: Ef, f: rr,
    {
        CString::new(v).mapr)
            }
                strucitivhint, T: ?Sized> Dze<'de>          impl<'de> Visitorctin
         ////// impl<'de> Visitorctin
   de>,)*
                                $ere
 (
     enamE_kintd:: $th its
),ustom)
  : $visit);)*)*
 : Des*ustom)
  : $visit);)*)*
 : De,
   ing::new(valuealizer).aliz    );)*        self.0.clear()h(ue)eing::new(valuealizer).aliz    );)*)*
 de> >(se)
        }
    unknown_th its
error:,z$th its
s_namE)<u8>) -> Re
   y);

   )*
 trucitivhint,self)),
        }
    }

    fn visit_byte_buf<E>(selror::, v: Vec<u8>) -> Re
   y);

   )*
 );)*)*
  
> Re
   y);

   )*
 );)*)*
  
> Re
   y);

   )*
 );)*}$val : $visit);)*)*
   : $visit);)*)*
                }

 / # fn example<'de, D>(de $visifier(Kint), feat {
    ($ty:idenfn de&oTire
    T:  = "alrve sign of NaN.e visit_u32 u64e<'de, D>(deenume4);
}

impl_desernamError>
  namE_kinttr])*
]( ($th its
tr])*
; $ere
 , $id;.$index, $id    impl_deserResult {
_ms::ag
, $idieserializ$ere
          $id : Deserialize<'de>,th its
_ $visifier!d::Unsigned(0), namE_kintd( ($th its
; $ere
 ;.$index    impl_desedeserResult {
_ms::ag
deserializer).VARIANTSize<'de>            stde> fEnum), featur       }for $ty >(e<'de>,
{
    typEnum), feat i128
         g(&self, form namEt fmt::Formatteor>Result {
                        formatter.write_str(stringify!($primitive))
            }

                    4", where
ify!($namE)<($val : $visiten<<Self, D::Error>Error>enum  where
  ////: SeqAccess<'de>,
    {
        let capaci       }
                struc::cEnumious::<u8>(seq.size<'de> {             }

       ;
   ////.th its
eString::new(valueew(value)*
                         enamE_kintd:: $th its
: E)erias.= "g(&s_th its
empl! {
namEu:: $th its
),ustom)
  : $visit);)*s*ustom)
  : $visit_value(
       
)*
 : De cfg(naliz$ere
        .e<'de, D>(deenum(where
ify!($namE),.VARIANTS,pEnum), feat)re
    T:  = "alrve sign of NaN.e = "alloc"))))]
    (), Box<C Self::Value)
      for $ty >(deserializer: D) -> Rnet =IpAdd, D::Error>
    where
        D: Deserializer<'de>,
    {
        deserializer.deserialize_str(StrVisitor)
    }
}

///////if / # fn examplis_human_read////(tring::new(value/////////////////////////////From////////// == "s"IP add,s::"<($val : $vxpected::Unsigned(0),utedcr  e::lib == t =IpAdd,;ng::new(value///////////eenum!ring::new(valueew(vIpAdd, IpAdd,Kintd(V4; b"V4"; 0,.V6; b"V6"; 1($val : $visit);)*"`V4` > R`V6`",             }

 / # fn examp{
    ($ty:idenfn de&oTire
    T: tarsesialit_u feature = "alrve sign of NaN.e ure = "alloc"))))]
    (), Box<C Self::Value)
          = t =Ipv4Add,, "IPv4 add,s::", 4 T: tarsesialit_u feature = "alrve sign of NaN.e ure = "alloc"))))]
    (), Box<C Self::Value)
          = t =Ipv6Add,, "IPv6 add,s::", 16:meta])*
        tarsessocketlit_u64);
}

impl_deserialize_num! {
    u32, NonZerpl<'dResult {
,tsieserializ$= ", $idieseriserialize<'de>,)*> Deserialize<'de> for $ty >(deserializer: D) -> Result<Self, D::Error>
            where
                D: Deserializer<'de>,
            {
                Deserialize::deserialize(deserializer).map($func)
       if / # fn examplis_human_read////(tring::new(valuealizer)./////////////////////////////From////////// == "sdResult {
):invalid_value(Unexpected::Unsigned(0), &self))<(_, u16)c =te_visit_untagged_option<D>(se$= "//////any(feat);)*_value(
       
)*
 : De cfg(not(no_ = "alrve sign of NaN.e = "alloc"))))]
    (), Box<C Self::Value)
      for $ty >(deserializer: D) -> Rnet =SocketAdd, D::Error>
    where
        D: Deserializer<'de>,
    {
        deserializer.deserialize_str(StrVisitor)
    }
}

///////if / # fn examplis_human_read////(tring::new(value/////////////////////////////From////////// == "s"socket add,s::"<($val : $vxpected::Unsigned(0),utedcr  e::lib == t =SocketAdd,;ng::new(value///////////eenum!ring::new(valueew(vSocketAdd, SocketAdd,Kintd(V4; b"V4"; 0,.V6; b"V6"; 1($val : $visit);)*"`V4` > R`V6`",             }

 / # fn examp{
    ($ty:idenfn de&oTire
    T: tarsessocketlit_u feature = "alrve sign of NaN.e ure = "alloc"))))]
    (), Box<C Self::Value)
          = t =SocketAdd,V4, "IPv4 socket add,s::",     |(ip, port)| = t =SocketAdd,V4 == "sip, port), T: tarsessocketlit_u feature = "alrve sign of NaN.e ure = "alloc"))))]
    (), Box<C Self::Value)
          = t =SocketAdd,V6, "IPv6 socket add,s::",     |(ip, port)| = t =SocketAdd,V6 == "sip, port, 0,.0
}
"  ) => mvvisit_i8 i16:visit_i16 i32:visit_i32 i64:visit_i64);
    uint_to_self!(u32: = "alrve sign of NaN.e mData<T>ath), feature = "alrve sign of NaN.e for $ty>(e<'de>,
{a: D) ->ath), featlf, formatter: &mut lloc>ath) -> fmt::Result {
        formatter.write_str("a borrowed byte array")
    }

    fn visit_borrowed_bytes bo   wed tath<Self::Value, A::Error>bo   wede
        E: Errorloc,
    {
        CString::new(v).map_err(Error::custom)
    }

    fn viside> .as_refs)#[$attr:lue, A::Error>bo   wedeere
        E: Errolocr,
    {
        CString::new(v).map_err(Error::custom)
    }

    fn visi  self.0.clear()($val : $visitD>(seAsRetrias_ref($val : $visitD>(sll(no|_|    }
    }

    fn visit_byte_buf<E>(sel:, v: Vec<re
    T:  = "alrve sign of NaN.e = "alloc"))))]
    (), Box<C Self::Value)
      for $ty >Dtt e'a>(deserializer: D) -> Rlloc>ath D::Error>
    where
        D: Deserializer<'de>,
    {
        deserializer.deserialize_byte_buf(CStringVisitor)
    }
}

macro_rules! forwarded__byt>ath), feat<re
    T:  = "alrve sign of NaN.e mData<T>athBuf), feature = "alrve sign of NaN.e for $ty >(e<'de>,
{
    typ>athBuf), featlf, formatter: &mut fathBuf) -> fmt::Result {
        formatter.write_str("a borrowed byte array")
    }

    fn visit_borrowed_bytetath where
"f::Value, E>
    where
        E: Error,
    {
        CString::new(v).map_err(Error::custom)
    }

    fn viside>Fromelf.0.el:t<Self::Value, E>
    where
        E: Error,
    {
        CString::new(v).map_err(Error::custom)
    }
}

#[cfg(anyde>Fromelf.0.el:t<Self::Value, E>
    ere
        E: Error,
    {
        CString::new(v).map_err(Error::custom)
    }

    fn visi  self.0.clear()($val : $visitD>(seFromelf.0.($val : $visitD>(sll(no|_|    }
    }

    fn visit_byte_buf<E>(sel:, v: Vec<re
    Value, E>
    ere
 {
        E: Errrroru8>   {
        CString::new(v).map_err(Error::custom)
    }

    fn visiverse<T>f.0.clear()($val : $visitD>(seFromelf.0.($val : $visitD>(sll(no|e|    }
    }

    fn visit_byte_buf<E>(se&e., ReveE>(se):, v: Vec<re
    T:  = "alrve sign of NaN.e = "alloc"))))]
    (), Box<C Self::Value)
      for $ty e<D>(deserializer: D) ->athBuf D::Error>
    where
        D: Deserializer<'de>,
    {
        deserializer.deserialize_byte_buf(CStringVisitor)
    }
}

macro_rules! forwarded__by {
 >athBuf), feat), all(not(no_core_cstr), feature = "alrve sign of NaN.e ure = "alloc"))))]
    (), Box<C Self::Value)
          l! {
   >ath>,->athBufT>, Reverse
}tath
"  ) => mvvisit_i8 i16:visit_i16 i32:visit_i32 i64:visit_i64);
    uint_to_self!(u32:// If this wzer outside    ////fordedcr  e, it would just,ute:://:// re = dorwve(_byte_buf(C   // re = forde(th its
_ $visifier.e = "al(tr(d)))]
    #[cfg_attny(unix, wintows     th its
_ $visifier!d::UnsiOsverse<Kintd(Unix; b"Unix"; 0,.Wintows; b"Wintows"; 1($val "`Unix` > R`Wintows`",     OSSTR_VARIANTSiT:  = "altr(d)))]
    #[cfg_attny(unix, wintows     impl<'desverse<), feature = "altr(d)))]
    #[cfg_attny(unix, wintows     for $ty >(e<'de>,
{
    typesverse<), featlf, formatter: &mut esverse<) -> fmt::Result {
        formatter.write_str("option")
    }

    #[inline]
    fn visit_unit<E>(self) -s where
"f::Value, E>
 = "alunix)elf::Value, D::enum  where
  ////: SeqAccess<'de>,
    {
        let capacity = size_hint::cEnumious::<u8>(seq.sine]
    fnutedcfg::os  unixelffi::esverse<Extt fmt::Form      ;
   ////.th its
eString::new(value(Osverse<KintzeUnix, E)erias.= "g(&s_th its
empl! {Osverse<T>f.0.cvec),ustom)
  : $v(Osverse<KintzeWintows, f)),
        }
  cust0.e$val : $visit);)*"can////! forwarded.Wintows OS where
ce tUnix",ustom)
  : $vc<u8>) -> Re}::Value, E>
 = "alwintows elf::Value, D::enum  where
  ////: SeqAccess<'de>,
    {
        let capacity = size_hint::cEnumious::<u8>(seq.sine]
    fnutedcfg::os  wintowselffi::esverse<Extt fmt::Form      ;
   ////.th its
eString::new(value(Osverse<KintzeWintows, E)erias$val : $visit);)*.= "g(&s_th its
::<rroru16>>(($val : $visit);)*pl! {|vec| Osverse<T>f.0.cw $v(&vec)),ustom)
  : $v(Osverse<KintzeUnix, f)),
        }
  cust0.e$val : $visit);)*"can////! forwarded.Unix OS where
ce tWintows",ustom)
  : $vc<u8>) -> Re}::ValueT:  = "altr(d)))]
    #[cfg_attny(unix, wintows     = "alloc"))))]
    (), Box<CSr(d)))]
    #[cfg_attny(unix, wintows       for $ty e<D>(deserializer: D) -Osverse< D::Error>
    where
        D: Deserializer<'de>,
    {
        deserializer.deserialize_byte_buf(CStringVisitor)
    }
}

macro_rules! forwarded_enum("Osverse<_atOSSTR_VARIANTS,pesverse<), feat//////////////////////////////////

struct StrVisitor;

impl<'a> Visitor<'a> for StrVisitor {no_core_cstr), feature = "alloc")))]
    #[cfg_ature = "std", feature ure = "alloc"))))]
    (), Box<CStr>, CString::into_boxed_c_str
}

forwarded_imp(T! {
   T> {
   == "not(no_core_cstr), feature = "alloc")))]
    #[cfg_ature = "std", feature ure = "alloc"))))]
    (), Box<CStr>, CString::into_boxed_c_str
}

forwarded_imp(T! {
   [T]>,ome(va, Reverse
}slicenot(no_core_cstr), feature = "alloc")))]
    #[cfg_ature = "std", feature ure = "alloc"))))]
    (), Box<CStr>, CString::into_boxed_c_str
}

forwarded_imp(! {
   whe>,overse<T>, Reverse
}strnot(no_core_cstr), feature = "allr(d)))]
    #[cfg_attny(unix, wintows     ure = "alloc"))))]
    (), Box<CSr(d)))]
    #[cfg_attny(unix, wintows       _imp(! {
   esver>, Osverse<T>, Reverse
}os}strnot(ringVisitor;
#[cfg(any(feature = "std", feature = "alloc"))))]
impl<'de> Deserialize<'de> for CString {
    fn deserialize<D>(deiztt dese?Sdedde<D>(deserializer: D) -Cowatt dee serializer: DToOwned,lizer: :Owned D) -> Result<Self, D::ErrResult<Self::Valu
    where
        D: Deserializer<'de>,
    {
        deserializer.deserialize_byte_buf(CStringVisitor)
    }
}: :Owned =te_visit_untagged_option<D>(seCow :Owned//////////////////////////////////

struct StrVisitor;

impl<'a> Visitor<'a> for StrVisitor {tor This it_u6r   i{
s ////[`"rc"`] Cargotring {
    Sorde. The  si>,
se<{tor `Weak T>` has a  sfzerncedcount    0ttnd can////be upgrae_c.{tor{tor [`"rc"`]: https://forde.rs/ring {
-flags.html#-ring {
s-rc  = "altr(d)))]
    #[rc"attny(lize<'de> for CString {
    fn deserie = "alloc"))/////))]
impl/////))]( "altr(d)))]
    #[rc"attny(lize<'de> for CString {
    fn deseri)
alize<D>(deizese?Sdedde<D>(deserializer: D) -RcWeak T>eserializer: D) -> Result<Self, D::Error>
    where
        D: Deserializer<'de>,
    {
        deserializer.deserialize_option(OptionVisitor {
         ;
   Oping valT) =te_visit_untagged_option<:custom)
  Ok(RcWeak == "s)#[$attr:mettor This it_u6r   i{
s ////[`"rc"`] Cargotring {
    Sorde. The  si>,
se<{tor `Weak T>` has a  sfzerncedcount    0ttnd can////be upgrae_c.{tor{tor [`"rc"`]: https://forde.rs/ring {
-flags.html#-ring {
s-rc  = "altr(d)))]
    #[rc"attny(lize<'de> for CString {
    fn deserie = "alloc"))/////))]
impl/////))]( "altr(d)))]
    #[rc"attny(lize<'de> for CString {
    fn deseri)
alize<D>(deizese?Sdedde<D>(deserializer: D) -ArcWeak T>eserializer: D) -> Result<Self, D::Error>
    where
        D: Deserializer<'de>,
    {
        deserializer.deserialize_option(OptionVisitor {
         ;
   Oping valT) =te_visit_untagged_option<:custom)
  Ok(ArcWeak == "s)#[$attr:mettor> mvvisit_i8 i16:visit_i16 i32:visit_i32 i64:visit_i64);
    uint_to_self!(u32:visit_u32 u64ers_no_core_cstr),64);
}

impl_deserialize_num! {
    u32, NonZ>(selfeseriserialize<'de>,)*> Deserialize<'de> for $ty  dese?Sdedde<D>(deserializer: D) -$t&se  if v as i128 >= $primitiv
   T> D) -> Result<Selfalue() as i128
         or>
            where
                D: Deserializer<'de>,
            {
                Deserialize::deserialize(deserializer).map($func)
       
   =te_visit_untagged_option<D>(seI ReT>, Re)value(
       
)*
 : De cfg(not(no_ers_no_core_cstr), featuretor This it_u6r   i{
s ////[`"rc"`] Cargotring {
    Sorde.aturetoraturetor ize::deserse< a //// stde>  {
 containse< `Rc` will ////it_umpt toaturetor e_cuplicate `Rc`  sfzerncesunco////famEu////. Every>
          d `Rc`aturetor will end up  tri / stdoe< count    1.aturetoraturetor [`"rc"`]: https://forde.rs/ring {
-flags.html#-ring {
s-rc ture = "allr(d)))]
    #[rc"attny(lize<'de> for CString {
    fn deserie ure = "alloc"))))]
    (), Box<CSr(d)))]
    #[rc"attny(lize<'de> for CString {
    fn deseri)ie ure Rc(no_ers_no_core_cstr), featuretor This it_u6r   i{
s ////[`"rc"`] Cargotring {
    Sorde.aturetoraturetor ize::deserse< a //// stde>  {
 containse< `Arc` will ////it_umpt toaturetor e_cuplicate `Arc`  sfzerncesunco////famEu////. Every>
          d `Arc`aturetor will end up  tri / stdoe< count    1.aturetoraturetor [`"rc"`]: https://forde.rs/ring {
-flags.html#-ring {
s-rc ture = "allr(d)))]
    #[rc"attny(lize<'de> for CString {
    fn deserie ure = "alloc"))))]
    (), Box<CSr(d)))]
    #[rc"attny(lize<'de> for CString {
    fn deseri)ie ure Arc:mettor> mvvisit_i8 i16:visit_i16 i32:visit_i32 i64:visit_i64);
    uint_to_self!(u32:      deize<'de>,
{
    fn deseriaCell T>eserializer: D) -> Result<Self +-Copy, D::Error>
    where
        D: Deserializer<'de>,
    {
        deserializer.deserialize_option(OptionVisitor {
         T =te_visit_untagged_option<D>(seCell == "), all(not(no_core_cstr), feature(T! {RefCell T> {RefCell == "not(no_core_cstr), feature = "alrve sign of NaN.e ure = "alloc"))))]
    (), Box<C Self::Value)
          lT! {Mute  T> {Mute  == "not(no_core_cstr), feature = "alrve sign of NaN.e ure = "alloc"))))]
    (), Box<C Self::Value)
          lT! {RwLock T> {RwLock == "not() => mvvisit_i8 i16:visit_i16 i32:visit_i32 i64:visit_i64);
    uint_to_self!(u32:// This is a     ned-up versng     ////it_u6gener  ed by:://:// re  = dorwve(_byte_buf(C   // re  = forde(sely_unknown_fields   // re  impl<'dDur  ng  { // re  re  iecs:  64, // re  re  nanos:  32, // re  } for $ty e<D>(deserializer: D) -Dur  ng  { :Error>
    where
        D: Deserializer<'de>,
    {
        deserializer.deserialize_option(OptionVisitor {
         // If this wzer outside    ////fordedcr  e, it would just,ute::        //         // e  = dorwve(_byte_buf(C           // e  = forde(field_ $visifier,  snamE_fn Valulowzecase"           enumeField.map($func)
   Secsdeserializer).Nanos,ustom)
    }

    fnT: Desere<D>(deserializer: D) -Field.map($func)
   or>
            where
                D: Deserializer<'de>,
            {
                struct NonZeroVisitor;

                impl<'de> Visitor<'de> fField), featurer)
            }for $ty >(e<'de>,
{
    typField), feat  impl<'de> Visitorcting(&self, formFieldt fmt::Formatter) -> fmt::Result {
                        formatter.write_str(stringify!($primitive))
                    }

           `iecs` > R`nanos`") : $visit);)*)*
 : De               }

     e
       
        E: Erf, f: r,
    {
        CString::new(v).mapr)
            }
                strucitivhint, T: ?Sized> Dze<'de>          impl<'de> Visitorctin
         ////// impl<'de> Visitorctin
   de>,"iecs"(
     Field::Secs<u8>) -> Re
   y);

   )*
 );)*"nanos"(
     Field::Nanos<u8>) -> Re
   y);

   )*
 );)*,
        }
    unknown_fielderror:,zFIELDS)<u8>) -> Re
   y);

   )*
   : $visit);)*)*
 : De               }

     e
       ere
        E: Ef, f: rr,
    {
        CString::new(v).mapr)
            }
                strucitivhint, T: ?Sized> Dze<'de>          impl<'de> Visitorctin
         ////// immmmmmmmmmmmmmmmmmmmmmmmmmmmb"iecs"(
     Field::Secs<u8>) -> Re
   y);

   )*
 );)*b"nanos"(
     Field::Nanos<u8>) -> Re
   y);

   )*
 );)*,
   {
           }                        vf, formcr  e::__prwv  e::f.0.clear_lossy(rror::custom)
  : $visit);)*)*
 itivhint,sel }
    unknown_fielde&*rror:,zFIELDS)<
> Re
   y);

   )*
 );)*)*
  
> Re
   y);

   )*
 );)*}$val : $visit);)*)*
   : $visit);)*)*
                }

 / # fn example<'de, D>(de $visifier(Field), featf$val : $visit}ustom)
    }

    fne
 check_overflow      cs:  64, nanos:  32er<'de>,
    {
 Ee  if v as i128 >= $primitiv, T: ?Sized> Dze<'{
           }staticzNANOS_PER_SEC:  32orm1_000_000_000;
aliz    );)*        cs.check whadd((nanos /zNANOS_PER_SEC) as  64  ing::new(valueew(vSomelf)),
 de>())u8>) -> Re
   y);
eriaeria,sel   cust0.e"overflow / # fn exase< Dur  ng "))u8>) -> Re
   }ize<'de>            stde> fDur  ng ), featurer)
     for $ty >(e<'de>,
{
    typDur  ng ), feat i128
         g(&self, formDur  ng t fmt::Formatteor>Result {
                        formatter.write_str(stringify!($primitive))
            }

          "stde> fDur  ng ")value(
       


           t::Error>
    where
        A: SeqAccess<'de>,
    {
        let capaci       }
                struc::cautious::<u8>(seq.size<'de> {             }

 anto  cs:  64ut       ;
        }

        CString::new(valueew(valuees.push(ue)eriash(ue,ng::new(valueew(valueeriaeria{ustom)
  : $visit);)*)*
        es(&e.into_bytes())length(0  v: Vec<; : $visit);)*)*
 : De}ustom)
  : $visit            }
          anos:  32ut       ;
        }

        CString::new(valueew(valuees.push(ue)eriash(ue,ng::new(valueew(valueeriaeria{ustom)
  : $visit);)*)*
        es(&e.into_bytes())length(1  v: Vec<; : $visit);)*)*
 : De}ustom)
  : $visit            }
     ;
   check_overflow   cs, nanosc<; : $visit);)*)*
 de>Dur  ng  == "s  cs, nanosc<value(
       


           t::Error>, a  where
      , a: SeqAccess<'de>,
    {
        let capaci       }
                struc::cMapious::<u8>(seq.size<'de> {             }

 anto      cs: Oping < 64>ut eria;primitive))
     anto     anos: Oping < 32>ut eria;primitive))
           values.pukeylue);
   , aa }

 keyCString::new(valueew(value      keya{ustom)
  : $visit);)*)*
 Field::Secs
   {
           }                if   cs.is_ss.pu)eing::new(valuealizer).aliz    );)*       es(&<    let  as  let c::cuplicate_fielde"iecs"c<;8>) -> Re
   y);

   )*
 );)* 
> Re
   y);

   )*
 );)*)*
 secs
 ues.pu;
   , aa }

  fn vi)));8>) -> Re
   y);

   )*
   : $visit);)*)*
 : De)*
 Field::Nanos
   {
           }                if  anos.is_ss.pu)eing::new(valuealizer).aliz    );)*       es(&<    let  as  let c::cuplicate_fielde"nanos"c<;8>) -> Re
   y);

   )*
 );)* 
> Re
   y);

   )*
 );)*)*
 nanos  ues.pu;
   , aa }

  fn vi)));8>) -> Re
   y);

   )*
   : $visit);)*)*
 : De}
isit);)*)*
 : De}
isit);)*)*
 : Deanto  csut         csuing::new(valueew(valuees.pu  cs)eriasecsdeserializer).ew(valueeriaeria       es(&<    let  as  let c::miss {
_fielde"iecs"c<,ustom)
  : $visit            }
          anosut        anosuing::new(valueew(valuees.punanosceriananos,ustom)
  er).ew(valueeriaeria       es(&<    let  as  let c::miss {
_fielde"nanos"c<,ustom)
  : $visit            }
     ;
   check_overflow   cs, nanosc<; : $visit);)*)*
 de>Dur  ng  == "s  cs, nanosc<value(
       
(
       


       constzFIELDS> &[r,
 ]::Fo["iecs",*"nanos"];)
    }
}

macro_rules! forwarded__bye> ("Dur  ng ",zFIELDS,pDur  ng ), feat#[$attr:mettor> mvvisit_i8 i16:visit_i16 i32:visit_i32 i64:visit_i64);
    uint_to_self!(u32: = "alrve sign of NaN.e = "alloc"))))]
    (), Box<C Self::Value)
      for $ty e<D>(deserializer: D) -SystemTime { :Error>
    where
        D: Deserializer<'de>,
    {
        deserializer.deserialize_option(OptionVisitor {
         // Reuteddur  ng          enumeField.map($func)
   Secsdeserializer).Nanos,ustom)
    }

    fnT: Desere<D>(deserializer: D) -Field.map($func)
   or>
            where
                D: Deserializer<'de>,
            {
                struct NonZeroVisitor;

                impl<'de> Visitor<'de> fField), featurer)
            }for $ty >(e<'de>,
{
    typField), feat  impl<'de> Visitorcting(&self, formFieldt fmt::Formatter) -> fmt::Result {
                        formatter.write_str(stringify!($primitive))
                    }

           `iecs_s {ce_epoch` > R`nanos_s {ce_epoch`") : $visit);)*)*
 : De               }

     e
       
        E: Erf, f: r,
    {
        CString::new(v).mapr)
            }
                strucitivhint, T: ?Sized> Dze<'de>          impl<'de> Visitorctin
         ////// impl<'de> Visitorctin
   de>,"iecs_s {ce_epoch"(
     Field::Secs<u8>) -> Re
   y);

   )*
 );)*"nanos_s {ce_epoch"(
     Field::Nanos<u8>) -> Re
   y);

   )*
 );)*,
        }
    unknown_fielderror:,zFIELDS)<u8>) -> Re
   y);

   )*
   : $visit);)*)*
 : De               }

     e
       ere
        E: Ef, f: rr,
    {
        CString::new(v).mapr)
            }
                strucitivhint, T: ?Sized> Dze<'de>          impl<'de> Visitorctin
         ////// immmmmmmmmmmmmmmmmmmmmmmmmmmmb"iecs_s {ce_epoch"(
     Field::Secs<u8>) -> Re
   y);

   )*
 );)*b"nanos_s {ce_epoch"(
     Field::Nanos<u8>) -> Re
   y);

   )*
 );)*,
   {
           }                        vf, formverse<T>f.0.clear_lossy(rror::custom)
  : $visit);)*)*
 itivhint,sel }
    unknown_fielde&rror:,zFIELDS)<
> Re
   y);

   )*
 );)*)*
  
> Re
   y);

   )*
 );)*}$val : $visit);)*)*
   : $visit);)*)*
                }

 / # fn example<'de, D>(de $visifier(Field), featf$val : $visit}ustom)
    }

    fne
 check_overflow      cs:  64, nanos:  32er<'de>,
    {
 Ee  if v as i128 >= $primitiv, T: ?Sized> Dze<'{
           }staticzNANOS_PER_SEC:  32orm1_000_000_000;
aliz    );)*        cs.check whadd((nanos /zNANOS_PER_SEC) as  64  ing::new(valueew(vSomelf)),
 de>())u8>) -> Re
   y);
eriaeria,sel   cust0.e"overflow / # fn exase< SystemTime epoch offset"))u8>) -> Re
   }ize<'de>            stde> fDur  ng ), featurer)
     for $ty >(e<'de>,
{
    typDur  ng ), feat i128
         g(&self, formDur  ng t fmt::Formatteor>Result {
                        formatter.write_str(stringify!($primitive))
            }

          "stde> fSystemTime")value(
       


           t::Error>
    where
        A: SeqAccess<'de>,
    {
        let capaci       }
                struc::cautious::<u8>(seq.size<'de> {             }

 anto  cs:  64ut       ;
        }

        CString::new(valueew(valuees.push(ue)eriash(ue,ng::new(valueew(valueeriaeria{ustom)
  : $visit);)*)*
        es(&e.into_bytes())length(0  v: Vec<; : $visit);)*)*
 : De}ustom)
  : $visit            }
          anos:  32ut       ;
        }

        CString::new(valueew(valuees.push(ue)eriash(ue,ng::new(valueew(valueeriaeria{ustom)
  : $visit);)*)*
        es(&e.into_bytes())length(1  v: Vec<; : $visit);)*)*
 : De}ustom)
  : $visit            }
     ;
   check_overflow   cs, nanosc<; : $visit);)*)*
 de>Dur  ng  == "s  cs, nanosc<value(
       


           t::Error>, a  where
      , a: SeqAccess<'de>,
    {
        let capaci       }
                struc::cMapious::<u8>(seq.size<'de> {             }

 anto      cs: Oping < 64>ut eria;primitive))
     anto     anos: Oping < 32>ut eria;primitive))
           values.pukeylue);
   , aa }

 keyCString::new(valueew(value      keya{ustom)
  : $visit);)*)*
 Field::Secs
   {
           }                if   cs.is_ss.pu)eing::new(valuealizer).aliz    );)*       es(&<    let  as  let c::cuplicate_fielde8>) -> Re
   y);

   )*
 trucitivhint"iecs_s {ce_epoch"u8>) -> Re
   y);

   )*
 );)*)*
 c<;8>) -> Re
   y);

   )*
 );)* 
> Re
   y);

   )*
 );)*)*
 secs
 ues.pu;
   , aa }

  fn vi)));8>) -> Re
   y);

   )*
   : $visit);)*)*
 : De)*
 Field::Nanos
   {
           }                if  anos.is_ss.pu)eing::new(valuealizer).aliz    );)*       es(&<    let  as  let c::cuplicate_fielde8>) -> Re
   y);

   )*
 trucitivhint"nanos_s {ce_epoch"u8>) -> Re
   y);

   )*
 );)*)*
 c<;8>) -> Re
   y);

   )*
 );)* 
> Re
   y);

   )*
 );)*)*
 nanos  ues.pu;
   , aa }

  fn vi)));8>) -> Re
   y);

   )*
   : $visit);)*)*
 : De}
isit);)*)*
 : De}
isit);)*)*
 : Deanto  csut         csuing::new(valueew(valuees.pu  cs)eriasecsdeserializer).ew(valueeriaeria       es(&<    let  as  let c::miss {
_fielde"iecs_s {ce_epoch"c<,ustom)
  : $visit            }
          anosut        anosuing::new(valueew(valuees.punanosceriananos,ustom)
  er).ew(valueeriaeria       es(&<    let  as  let c::miss {
_fielde"nanos_s {ce_epoch"c<,ustom)
  : $visit            }
     ;
   check_overflow   cs, nanosc<; : $visit);)*)*
 de>Dur  ng  == "s  cs, nanosc<value(
       
(
       


       constzFIELDS> &[r,
 ]::Fo["iecs_s {ce_epoch"ut"nanos_s {ce_epoch"];)
    }
}    dur  ng ue);
   

macro_rules! forwarded__bye> ("SystemTime",zFIELDS,pDur  ng ), feat#<; : $visit = "alnotlno_systemtime_check whadd)                  ue)UNIX_EPOCH$val : $visitDcheck whadd(dur  ng ($val : $visitDok_or_ecte(||zer<'de>,  cust0.e"overflow / # fn exase< SystemTime"#<; : $visit = "alno_systemtime_check whadd)                 ue)de>UNIX_EPOCH + dur  ng <; : $visit   /////////////////////////////////

struct StrVisitor;

impl<'a> Visitor<'a> for StrVisitor {to Similar to:://:// re  = dorwve(_byte_buf(C   // re  = forde(sely_unknown_fields   // re  impl<'dRange<Idx> { // re  re  itart: Idx, // re  re  end: Idx, // re  }:      deizIdx> D>(deserializer: D) -Range<Idx>eserializerIdx D) -> Result<Self, D::Error>
    where
        D: Deserializer<'de>,
    {
        deserializer.deserialize_option(OptionVisitor {
             (itart, end)ue);
   

macro_rules! forwarded__bye> ($val : $visit"Range"u8>) -> Re
   rangematIELDS,8>) -> Re
   rangemaRange), feat  impl<'de> VisitorResult {
, "impl<'dRange"u8>) -> Re
   y);
phantomr PhantomDatau8>) -> Re
   }u8>) -> Re<:custom)
  Ok(itart..end)//////////      deizIdx> D>(deserializer: D) -RangeIncluswve<Idx>eserializerIdx D) -> Result<Self, D::Error>
    where
        D: Deserializer<'de>,
    {
        deserializer.deserialize_option(OptionVisitor {
             (itart, end)ue);
   

macro_rules! forwarded__bye> ($val : $visit"RangeIncluswve"u8>) -> Re
   rangematIELDS,8>) -> Re
   rangemaRange), feat  impl<'de> VisitorResult {
, "impl<'dRangeIncluswve"u8>) -> Re
   y);
phantomr PhantomDatau8>) -> Re
   }u8>) -> Re<:custom)
  Ok(RangeIncluswve == "s tart, end))//////////mod range  impl<utedcr  e::lib =*t fmt::utedcr  e::de::{_option(Opt,e_option(Opti,T: ?SizcMapious::,cautious::,(e<'de>,}t fmt::pub constzFIELDS> &[r,
 ]::Fo["itart"ut"end"];
ize<'// If this wzer outside    ////fordedcr  e, it would just,ute::    oratureto e  = dorwve(_byte_buf(C       // e  = forde(field_ $visifier,  snamE_fn Valulowzecase"       enumeField.map($func)Start,Error::cusnd,lizer 


   T: Desere<D>(deserializer: D) -Field.map($func)or>
            where
                D: Deserializer<'de>,
         
                st NonZeroVisitor;

           {
           }stde> fField), featurer)
         for $ty >(e<'de>,
{
    typField), feat  impl<'de> Visitorg(&self, formFieldt fmt::Formatter) -t::Result {
                        formatter.write_str(stringify!($primitive))
                }

           `itart` > R`end`") : $visit);)*)*
 } fmt::Formatter) -t::      
        E: Erf, f: r,
    {
        CString::new(v).mapr)
         
                strucitiv, T: ?Sized> Dze<'de>     ing::new(valueew(value      ////// immmmmmmmmmmmmmmmmmmmmmmm"itart"(
     Field::Start<u8>) -> Re
   y);

   )*
 "end"(
     Field::snd<u8>) -> Re
   y);

   )*
 ,
        }
    unknown_fielderror:,zFIELDS)<u8>) -> Re
   y);

   } : $visit);)*)*
 } fmt::Formatter) -t::      ere
        E: Ef, f: rr,
    {
        CString::new(v).mapr)
         
                strucitiv, T: ?Sized> Dze<'de>     ing::new(valueew(value      ////// immmmmmmmmmmmmmmmmmmmmmmmb"itart"(
     Field::Start<u8>) -> Re
   y);

   )*
 b"end"(
     Field::snd<u8>) -> Re
   y);

   )*
 ,
   ing::new(valuealizer).aliz        vf, formcr  e::__prwv  e::f.0.clear_lossy(rror::custom)
  : $visit);)*)*
 itiv,sel }
    unknown_fielde&*rror:,zFIELDS)<
> Re
   y);

   )*
 );)*  : $visit);)*)*
 : De}
isit);)*)*
 : De}
isit);)*)*
 } fmt::Formatte/ # fn example<'de, D>(de $visifier(Field), featf$val : $v}::Value, E>
pub impl<'dRangee<'de>,
Idx> { 
   y);
pub Result {
, &'staticzimp, 
   y);
pub phantomr PhantomData
Idx>,lizer 


   T: DeserizIdx> e<'de>,
{
    typRangee<'de>,
Idx>serializer.deserialIdx D) -> Result<Self,     ing::new(vg(&self, form(Idx,lIdx); }

    fne
 Result {
                        formatter.write_str(stringify!($primitive))
        }

              .Result {
)ustom)
    }

    fne
 Error>
    where
        A: SeqAccess<'de>,
    {
        let capaci    
                s::cautious::<u8>(seq.size<'$primitive))
 anto tart: Idxut       ;
        }

        CString::new(valueew(ves.push(ue)eriash(ue,ng::new(valueew(veriaeria{ustom)
  : $visit);)*       es(&e.into_bytes())length(0  v: Vec<; : $visit);)*)*
 }
isit);)*)*
 };primitive))
 antoend: Idxut       ;
        }

        CString::new(valueew(ves.push(ue)eriash(ue,ng::new(valueew(veriaeria{ustom)
  : $visit);)*       es(&e.into_bytes())length(1  v: Vec<; : $visit);)*)*
 }
isit);)*)*
 };primitive))
 de>( tart, end))/////)
    }

    fne
 Error>, a  where
      , a: SeqAccess<'de>,
    {
        let capaci    
                s::cMapious::<u8>(seq.size<'$primitive))
 anto     tart: Oping <Idx> t eria;primitive))
 anto    end: Oping <Idx> t eria;primitive))
       values.pukeylue);
   , aa }

 keyCString::new(valueew(v      keya{ustom)
  : $visit);)*Field::Start
   ing::new(valuealizer).alizif  tart.is_ss.pu)eing::new(valuealizer).aliz           es(&<    let  as  let c::cuplicate_fielde"itart"));8>) -> Re
   y);

   )*
   : $visit);)*)*
 : De)*
 start
 ues.pu;
   , aa }

  fn vi)));8>) -> Re
   y);

   }ustom)
  : $visit);)*Field::snd
   ing::new(valuealizer).alizif end.is_ss.pu)eing::new(valuealizer).aliz           es(&<    let  as  let c::cuplicate_fielde"end"));8>) -> Re
   y);

   )*
   : $visit);)*)*
 : De)*
 end  ues.pu;
   , aa }

  fn vi)));8>) -> Re
   y);

   }ustom)
  : $visit_value(
       
)*
 : De))
 anto tartut        tartuing::new(valueew(ves.pu tart)eriastart,Error::cuew(valueeriaeria       es(&<    let  as  let c::miss {
_fielde"itart")),
isit);)*)*
 };primitive))
 antoendut       entd::Unsigned(0),ew(ves.puend)ue> ent,Error::cuew(valueeriaeria       es(&<    let  as  let c::miss {
_fielde"end")),
isit);)*)*
 };primitive))
 de>( tart, end))/////)
    ////////////////////////////////

struct StrVisitor;

impl<'a> Visitor<'a> for StrVisitor {to Similar to:://:// re  = dorwve(_byte_buf(C   // re  = forde(sely_unknown_fields   // re  impl<'dRangeFrom<Idx> { // re  re  itart: Idx, // re  }:      deizIdx> D>(deserializer: D) -RangeFrom<Idx>eserializerIdx D) -> Result<Self, D::Error>
    where
        D: Deserializer<'de>,
    {
        deserializer.deserialize_option(OptionVisitor {
              tartut ;
   

macro_rules! forwarded__bye> ($val : $visit"RangeFrom"u8>) -> Re
   range_fromeltIELDS,8>) -> Re
   range_fromelRangeFrom), feat  impl<'de> VisitorResult {
, "impl<'dRangeFrom"u8>) -> Re
   y);
phantomr PhantomDatau8>) -> Re
   }u8>) -> Re<:custom)
  Ok(itart..)//////////mod range_from  impl<utedcr  e::lib =*t fmt::utedcr  e::de::{_option(Opt,e_option(Opti,T: ?SizcMapious::,cautious::,(e<'de>,}t fmt::pub constzFIELDS> &[r,
 ]::Fo["end"];
ize<'// If this wzer outside    ////fordedcr  e, it would just,ute::    oratureto e  = dorwve(_byte_buf(C       // e  = forde(field_ $visifier,  snamE_fn Valulowzecase"       enumeField.map($func)snd,lizer 


   T: Desere<D>(deserializer: D) -Field.map($func)or>
            where
                D: Deserializer<'de>,
         
                st NonZeroVisitor;

           {
           }stde> fField), featurer)
         for $ty >(e<'de>,
{
    typField), feat  impl<'de> Visitorg(&self, formFieldt fmt::Formatter) -t::Result {
                        formatter.write_str(stringify!($primitive))
                }

           `end`") : $visit);)*)*
 } fmt::Formatter) -t::      
        E: Erf, f: r,
    {
        CString::new(v).mapr)
         
                strucitiv, T: ?Sized> Dze<'de>     ing::new(valueew(value      ////// immmmmmmmmmmmmmmmmmmmmmmm"end"(
     Field::snd<u8>) -> Re
   y);

   )*
 ,
        }
    unknown_fielderror:,zFIELDS)<u8>) -> Re
   y);

   } : $visit);)*)*
 } fmt::Formatter) -t::      ere
        E: Ef, f: rr,
    {
        CString::new(v).mapr)
         
                strucitiv, T: ?Sized> Dze<'de>     ing::new(valueew(value      ////// immmmmmmmmmmmmmmmmmmmmmmmb"end"(
     Field::snd<u8>) -> Re
   y);

   )*
 ,
   ing::new(valuealizer).aliz        vf, formcr  e::__prwv  e::f.0.clear_lossy(rror::custom)
  : $visit);)*)*
 itiv,sel }
    unknown_fielde&*rror:,zFIELDS)<
> Re
   y);

   )*
 );)*  : $visit);)*)*
 : De}
isit);)*)*
 : De}
isit);)*)*
 } fmt::Formatte/ # fn example<'de, D>(de $visifier(Field), featf$val : $v}::Value, E>
pub impl<'dRangeFrom), feat
Idx> { 
   y);
pub Result {
, &'staticzimp, 
   y);
pub phantomr PhantomData
Idx>,lizer 


   T: DeserizIdx> e<'de>,
{
    typRangeFrom), feat
Idx>serializer.deserialIdx D) -> Result<Self,     ing::new(vg(&self, formIdx; }

    fne
 Result {
                        formatter.write_str(stringify!($primitive))
        }

              .Result {
)ustom)
    }

    fne
 Error>
    where
        A: SeqAccess<'de>,
    {
        let capaci    
                s::cautious::<u8>(seq.size<'$primitive))
 antoend: Idxut       ;
        }

        CString::new(valueew(ves.push(ue)eriash(ue,ng::new(valueew(veriaeria{ustom)
  : $visit);)*       es(&e.into_bytes())length(0  v: Vec<; : $visit);)*)*
 }
isit);)*)*
 };primitive))
 de>end)/////)
    }

    fne
 Error>, a  where
      , a: SeqAccess<'de>,
    {
        let capaci    
                s::cMapious::<u8>(seq.size<'$primitive))
 anto    end: Oping <Idx> t eria;primitive))
       values.pukeylue);
   , aa }

 keyCString::new(valueew(v      keya{ustom)
  : $visit);)*Field::snd
   ing::new(valuealizer).alizif end.is_ss.pu)eing::new(valuealizer).aliz           es(&<    let  as  let c::cuplicate_fielde"end"));8>) -> Re
   y);

   )*
   : $visit);)*)*
 : De)*
 end  ues.pu;
   , aa }

  fn vi)));8>) -> Re
   y);

   }ustom)
  : $visit_value(
       
)*
 : De))
 antoendut       entd::Unsigned(0),ew(ves.puend)ue> ent,Error::cuew(valueeriaeria       es(&<    let  as  let c::miss {
_fielde"end")),
isit);)*)*
 };primitive))
 de>end)/////)
    ////////////////////////////////

struct StrVisitor;

impl<'a> Visitor<'a> for StrVisitor {to Similar to:://:// re  = dorwve(_byte_buf(C   // re  = forde(sely_unknown_fields   // re  impl<'dRangeTo<Idx> { // re  re  itart: Idx, // re  }:      deizIdx> D>(deserializer: D) -RangeTo<Idx>eserializerIdx D) -> Result<Self, D::Error>
    where
        D: Deserializer<'de>,
    {
        deserializer.deserialize_option(OptionVisitor {
             endut ;
   

macro_rules! forwarded__bye> ($val : $visit"RangeTo"u8>) -> Re
   range_ReT>tIELDS,8>) -> Re
   range_ReT>RangeTo), feat  impl<'de> VisitorResult {
, "impl<'dRangeTo"u8>) -> Re
   y);
phantomr PhantomDatau8>) -> Re
   }u8>) -> Re<:custom)
  Ok(..end)//////////mod range_to  impl<utedcr  e::lib =*t fmt::utedcr  e::de::{_option(Opt,e_option(Opti,T: ?SizcMapious::,cautious::,(e<'de>,}t fmt::pub constzFIELDS> &[r,
 ]::Fo["itart"];
ize<'// If this wzer outside    ////fordedcr  e, it would just,ute::    oratureto e  = dorwve(_byte_buf(C       // e  = forde(field_ $visifier,  snamE_fn Valulowzecase"       enumeField.map($func)Start,Error 


   T: Desere<D>(deserializer: D) -Field.map($func)or>
            where
                D: Deserializer<'de>,
         
                st NonZeroVisitor;

           {
           }stde> fField), featurer)
         for $ty >(e<'de>,
{
    typField), feat  impl<'de> Visitorg(&self, formFieldt fmt::Formatter) -t::Result {
                        formatter.write_str(stringify!($primitive))
                }

           `itart`") : $visit);)*)*
 } fmt::Formatter) -t::      
        E: Erf, f: r,
    {
        CString::new(v).mapr)
         
                strucitiv, T: ?Sized> Dze<'de>     ing::new(valueew(value      ////// immmmmmmmmmmmmmmmmmmmmmmm"itart"(
     Field::Start<u8>) -> Re
   y);

   )*
 ,
        }
    unknown_fielderror:,zFIELDS)<u8>) -> Re
   y);

   } : $visit);)*)*
 } fmt::Formatter) -t::      ere
        E: Ef, f: rr,
    {
        CString::new(v).mapr)
         
                strucitiv, T: ?Sized> Dze<'de>     ing::new(valueew(value      ////// immmmmmmmmmmmmmmmmmmmmmmmb"itart"(
     Field::Start<u8>) -> Re
   y);

   )*
 ,
   ing::new(valuealizer).aliz        vf, formcr  e::__prwv  e::f.0.clear_lossy(rror::custom)
  : $visit);)*)*
 itiv,sel }
    unknown_fielde&*rror:,zFIELDS)<
> Re
   y);

   )*
 );)*  : $visit);)*)*
 : De}
isit);)*)*
 : De}
isit);)*)*
 } fmt::Formatte/ # fn example<'de, D>(de $visifier(Field), featf$val : $v}::Value, E>
pub impl<'dRangeTo), feat
Idx> { 
   y);
pub Result {
, &'staticzimp, 
   y);
pub phantomr PhantomData
Idx>,lizer 


   T: DeserizIdx> e<'de>,
{
    typRangeTo), feat
Idx>serializer.deserialIdx D) -> Result<Self,     ing::new(vg(&self, formIdx; }

    fne
 Result {
                        formatter.write_str(stringify!($primitive))
        }

              .Result {
)ustom)
    }

    fne
 Error>
    where
        A: SeqAccess<'de>,
    {
        let capaci    
                s::cautious::<u8>(seq.size<'$primitive))
 anto tart: Idxut       ;
        }

        CString::new(valueew(ves.push(ue)eriash(ue,ng::new(valueew(veriaeria{ustom)
  : $visit);)*       es(&e.into_bytes())length(0  v: Vec<; : $visit);)*)*
 }
isit);)*)*
 };primitive))
 de> tart)/////)
    }

    fne
 Error>, a  where
      , a: SeqAccess<'de>,
    {
        let capaci    
                s::cMapious::<u8>(seq.size<'$primitive))
 anto     tart: Oping <Idx> t eria;primitive))
       values.pukeylue);
   , aa }

 keyCString::new(valueew(v      keya{ustom)
  : $visit);)*Field::Start
   ing::new(valuealizer).alizif  tart.is_ss.pu)eing::new(valuealizer).aliz           es(&<    let  as  let c::cuplicate_fielde"itart"));8>) -> Re
   y);

   )*
   : $visit);)*)*
 : De)*
 start
 ues.pu;
   , aa }

  fn vi)));8>) -> Re
   y);

   }ustom)
  : $visit_value(
       
)*
 : De))
 anto tartut        tartuing::new(valueew(ves.pu tart)eriastart,Error::cuew(valueeriaeria       es(&<    let  as  let c::miss {
_fielde"itart")),
isit);)*)*
 };primitive))
 de> tart)/////)
    ////////////////////////////////

struct StrVisitor;

impl<'a> Visitor<'a> for StrVisitor {      deize<'de>,
{
    fn deseriaBound T>eserializer: D) -> Result<Self, D::Error>
    where
        D: Deserializer<'de>,
    {
        deserializer.deserialize_option(OptionVisitor {
         enumeField.map($func)
   Unboundet,Error::cuew(vIncludet,Error::cuew(vExcludet,Error::cu  }

    fnT: Desere<D>(deserializer: D) -Field.map($func)
   Result<Self::Vp($func)or>
            where
                D: Deserializer<'de>,
             
                struct NonZeroVisitor;

                impl<'de> Visitor<'de> fField), featurer)
            }for $ty >(e<'de>,
{
    typField), feat  impl<'de> Visitorcting(&self, formFieldt fmt::Formatter) -> fmt::Result {
                        formatter.write_str(stringify!($primitive))
                    }

           `Unboundet`, `Includet` > R`Excludet`") : $visit);)*)*
 : De               }

     e
       u64       E: Ef, f:  64   {
        CString::new(v).mapr)
            }
                strucitivhint, T: ?Sized> Dze<'de>          impl<'de> Visitorctin
         ////// immmmmmmmmmmmmmmmmmmmmmmmmmmm0(
     Field::Unboundet<u8>) -> Re
   y);

   )*
 );)*1(
     Field::Includet<u8>) -> Re
   y);

   )*
 );)*2(
     Field::sxcludet<u8>) -> Re
   y);

   )*
 );)*,
        }
    bytes()) fn viUnResulted::Unsignederror:)  v: Vec<u8>) -> Re
   y);

   )*
   : $visit);)*)*
 : De               }

     e
       
        E: Erf, f: r,
    {
        CString::new(v).mapr)
            }
                strucitivhint, T: ?Sized> Dze<'de>          impl<'de> Visitorctin
         ////// impl<'de> Visitorctin
   de>,"Unboundet"(
     Field::Unboundet<u8>) -> Re
   y);

   )*
 );)*"Includet"(
     Field::Includet<u8>) -> Re
   y);

   )*
 );)*"sxcludet"(
     Field::sxcludet<u8>) -> Re
   y);

   )*
 );)*,
        }
    unknown_th its
error:,zVARIANTS)<u8>) -> Re
   y);

   )*
   : $visit);)*)*
 : De               }

     e
       ere
        E: Ef, f: rr,
    {
        CString::new(v).mapr)
            }
                strucitivhint, T: ?Sized> Dze<'de>          impl<'de> Visitorctin
         ////// immmmmmmmmmmmmmmmmmmmmmmmmmmmb"Unboundet"(
     Field::Unboundet<u8>) -> Re
   y);

   )*
 );)*b"Includet"(
     Field::Includet<u8>) -> Re
   y);

   )*
 );)*b"sxcludet"(
     Field::sxcludet<u8>) -> Re
   y);

   )*
 );)*,
          tr::f.0.clearush(ue)eing::new(valuealizer).aliz    );)*   sh(ue)eria     }
    unknown_th its
error:,zVARIANTS)<u8>) -> Re
   y);

   )*
 )*
 itiv,sel_)
   {
           }                    itiv,sel }
    bytes()) fn viUnResulted::Bre
 error:)  v: Vec<
           }                     
> Re
   y);

   )*
 );)*)*
 },
> Re
   y);

   )*
 );)*}$val : $visit);)*)*
   : $visit);)*)*
                }

 / # fn example<'de, D>(de $visifier(Field), featf$val : $visit}ustom)
    }

    fn<'de> fBounde<'de>,
T>(PhantomData
Bound T>>)urer)
     for $ty ize<'e<'de>,
{
    typBounde<'de>,
T>apaci    
                sT D) -> Result<Selfalue() as i128
         g(&self, formBound T>t fmt::Formatteor>Result {
                        formatter.write_str(stringify!($primitive))
            }

          "enumeBound")value(
       


           t::Error>enum  where
  ////: SeqAccess<'de>,
    {
        let capaci       }
                struc::cEnumious::<u8>(seq.size<'de> {             }

       ;
   ////.th its
eString::new(valueew(value Field::Unboundet: E)erias.unit_th its
e<D>(se|()|eBound::Unboundet<u8>) -> Re
   y);

    Field::Includet: E)erias.newg(&s_th its
e<D>(seBound::Includet<u8>) -> Re
   y);

    Field::sxcludet: E)erias.newg(&s_th its
e<D>(seBound::sxcludet<u8>) -> Re
   y);
}value(
       
(
       


       constzVARIANTS> &[r,
 ]::Fo["Unboundet",*"Includet",*"sxcludet"]t fmt::Form/ # fn example<'de, D>(deenum("Bound",zVARIANTS,pBounde<'de>,(PhantomData)#[$attr:mettor> mvvisit_i8 i16:visit_i16 i32:visit_i32 i64:visit_i64);
    uint_to_self!(u32:for $ty izeew(v D>(deserializer: D) -Rss<'deeew(veserializer: D) -> Result<Self, hint, T) -> Result<Self, D::Error>
    where
        D: Deserializer<'de>,
    {
        deserializer.deserialize_option(OptionVisitor {
         // If this wzer outside    ////fordedcr  e, it would just,ute::        //         // e  = dorwve(_byte_buf(C           // e  = forde(th its
e $visifier           enumeField.map($func)
   Ok,Error::cuew(vErr,Error::cu  }

    fnT: Desere<D>(deserializer: D) -Field.map($func)
   Result<Self::Vp($func)or>
            where
                D: Deserializer<'de>,
             
                struct NonZeroVisitor;

                impl<'de> Visitor<'de> fField), featurer)
            }for $ty >(e<'de>,
{
    typField), feat  impl<'de> Visitorcting(&self, formFieldt fmt::Formatter) -> fmt::Result {
                        formatter.write_str(stringify!($primitive))
                    }

           `Ok` > R`Err`") : $visit);)*)*
 : De               }

     e
       u64       E: Ef, f:  64   {
        CString::new(v).mapr)
            }
                strucitivhint, T: ?Sized> Dze<'de>          impl<'de> Visitorctin
         ////// immmmmmmmmmmmmmmmmmmmmmmmmmmm0(
     Field::Ok<u8>) -> Re
   y);

   )*
 );)*1(
     Field::: ?<u8>) -> Re
   y);

   )*
 );)*,
        }
    bytes()) fn viUnResulted::Unsignederror:)  v: Vec<u8>) -> Re
   y);

   )*
   : $visit);)*)*
 : De               }

     e
       
        E: Erf, f: r,
    {
        CString::new(v).mapr)
            }
                strucitivhint, T: ?Sized> Dze<'de>          impl<'de> Visitorctin
         ////// impl<'de> Visitorctin
   de>,"Ok"(
     Field::Ok<u8>) -> Re
   y);

   )*
 );)*": ?"(
     Field::: ?<u8>) -> Re
   y);

   )*
 );)*,
        }
    unknown_th its
error:,zVARIANTS)<u8>) -> Re
   y);

   )*
   : $visit);)*)*
 : De               }

     e
       ere
        E: Ef, f: rr,
    {
        CString::new(v).mapr)
            }
                strucitivhint, T: ?Sized> Dze<'de>          impl<'de> Visitorctin
         ////// immmmmmmmmmmmmmmmmmmmmmmmmmmmb"Ok"(
     Field::Ok<u8>) -> Re
   y);

   )*
 );)*b": ?"(
     Field::: ?<u8>) -> Re
   y);

   )*
 );)*,
          tr::f.0.clearush(ue)eing::new(valuealizer).aliz    );)*   sh(ue)eria     }
    unknown_th its
error:,zVARIANTS)<u8>) -> Re
   y);

   )*
 )*
 itiv,sel_)
   {
           }                    itiv,sel }
    bytes()) fn viUnResulted::Bre
 error:)  v: Vec<
           }                     
> Re
   y);

   )*
 );)*)*
 },
> Re
   y);

   )*
 );)*}$val : $visit);)*)*
   : $visit);)*)*
                }

 / # fn example<'de, D>(de $visifier(Field), featf$val : $visit}ustom)
    }

    fn<'de> f      e<'de>,
Tew(v(PhantomData
Rss<'deeew(v>)urer)
     for $ty izeew(v e<'de>,
{
    typR     e<'de>,
Tew(vapaci    
                sT D) -> Result<Selfalue() as hint, T) -> Result<Self, ue() as i128
         g(&self, formRss<'deeew(vt fmt::Formatteor>Result {
                        formatter.write_str(stringify!($primitive))
            }

          "enumengify!")value(
       


           t::Error>enum  where
  ////: SeqAccess<'de>,
    {
        let capaci       }
                struc::cEnumious::<u8>(seq.size<'de> {             }

       ;
   ////.th its
eString::new(valueew(value Field::Ok, E)erias.newg(&s_th its
e<D>(seOk<u8>) -> Re
   y);

    Field::: ?, E)erias.newg(&s_th its
e<D>(se: ?<u8>) -> Re
   y);
}value(
       
(
       


       constzVARIANTS> &[r,
 ]::Fo["Ok",*": ?"]t fmt::Form/ # fn example<'de, D>(deenum("ngify!",zVARIANTS,pR     e<'de>,(PhantomData)#[$attr:mettor> mvvisit_i8 i16:visit_i16 i32:visit_i32 i64:visit_i64);
    uint_to_self!(u32:for $ty izee<D>(deserializer: D) -Wrapp {
 T>eserializer: D) -> Result<Self, D::Error>
    where
        D: Deserializer<'de>,
    {
        deserializer.deserialize_option(OptionVisitor {
         _option(Opt::deption(Opt     D: Deser<D>(seWrapp {
#[$attr:met = "alallC Self::Value)
 , notlno_std_atomic     macro_rules! atomic_it_u6
     ($($ty: $vis $sOpt:Resr)*)
   {
        $(ap($func)
   Re "alanylno_target_has_atomic, target_has_atomicVal$sOpt)           
   Re "aloc"))))]
    (), Box<CallC Self::Value)
 , target_has_atomicVal$sOpt) )           
   T: Desere<D>(deserializer: D) -$ty($primitive))
      r>
            where
                D: Deserializer<'de>,
                }
                strucitivt NonZeroVisitor;

                    impl<'de> Visitorctin_option(Opt::deption(Opt     D: Deser<D>(se>,
   new)8>) -> Re
   y);
}value(
       
(
      )*
)*
 };pmet = "alallC Self::Value)
 , notlno_std_atomic     atomic_it_u!  impl<AtomicBool "8"impl<AtomicI8 "8"impl<AtomicI16 "16"impl<AtomicI32 "32"impl<AtomicIsOpt "ptr"impl<AtomicU8 "8"impl<AtomicU16 "16"impl<AtomicU32 "32"impl<AtomicUsOpt "ptr"imet = "alallC Self::Value)
 , notlno_std_atomic64     atomic_it_u!  impl<AtomicI64 "64"impl<AtomicU64 "64"i}2: = "alrve sign of NaN.e <'de> fF.0.Stre<'de>,
T>  impl<Result {
, &'staticzimp, 
   ty: PhantomData
T   }2: = "alrve sign of NaN.e T: DeT> F.0.Stre<'de>,
T>  impl< r>= "sResult {
, &'staticzimp     >,
   impl<'de>F.0.Stre<'de>,  impl<'de> VisResult {
,128
         g(r PhantomDatau8>) -> Re}[$attr:met = "alrve sign of NaN.e T: Dety ize<'e<'de>,
{
    typF.0.Stre<'de>,
T>eserializer: D tr::F.0.Str,lizer: <'de:r(striDisplay, D::Errg(&self, formTt fmt::or>Result {
                        formatter.write_str(stringify!($primitive       }

              .Result {
)ustom} fmt::or>      
        E: Es: r,
    {
        CString::new(v).map
             , T: ?Si