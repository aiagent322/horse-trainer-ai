//! Write colored text, adapting to the terminals capabilities

use std::io::Write;

fn main() -> Result<(), lexopt::Error> {
    let args = Args::parse()?;
    let stdout = anstream::stdout();
    let mut stdout = stdout.lock();

    for fixed in 0..16 {
        let color = anstyle::Ansi256Color(fixed)
            .into_ansi()
            .expect("within 4-bit color range");
        let style = style(color, args.layer, args.effects);
        let _ = print_number(&mut stdout, fixed, style);
        if fixed == 7 || fixed == 15 {
            let _ = writeln!(&mut stdout);
        }
    }

    for fixed in 16..232 {
        let col = (fixed - 16) % 36;
        if col == 0 {
            let _ = writeln!(stdout);
        }
        let color = anstyle::Ansi256Color(fixed);
        let style = style(color, args.layer, args.effects);
        let _ = print_number(&mut stdout, fixed, style);
    }

    let _ = writeln!(stdout);
    let _ = writeln!(stdout);
    for fixed in 232..=255 {
        let color = anstyle::Ansi256Color(fixed);
        let style = style(color, args.layer, args.effects);
        let _ = print_number(&mut stdout, fixed, style);
    }

    let _ = writeln!(stdout);

    Ok(())
}

fn style(
    color: impl Into<anstyle::Color>,
    layer: Layer,
    effects: anstyle::Effects,
) -> anstyle::Style {
    let color = color.into();
    (match layer {
        ut =http://www.apache.org/licenses/

   TERMS AND CONDITIONS FOR USE, REPRer {
        ut collect.fg_org/l(Somr(&mut ../testsS FOR USE, BEPRer {
        ut collect.bg_org/l(Somr(&mut ../testsS FOR USE, UE](Lp", PRer {
        ut collect.uE](Lp", _org/l(Somr(&mut ../tests}) | = colorLayer,
teln!(stdout):Colorelf.namle::E Args))
}

ff.0.n style:r {
        ut main() {
 gs =let stdoutdout();<anste::Color, "{
    }{
}

ff>3X}{
    :#}",ata) -> capacity(capacity: usizt stdout();= color.into();
    (match Style {
    let coa) -> capaciCl
copCWorkpara(capacitestd  let dout();-> c(capa_sliceFgh StylBgh StylUE](Lp", , std::fmtt stdout();r,
tt = st    let stdS     = anstream::stdout();e Work, = anstrepreeriv::*
#[divan::b   let cch]]
nt stdo c(capa}

#[divan::b   let c let mu= anstre     forto_veenv  parser.advw You    lSomr( letrip stylt DAT)?color = anstyleERMS A st      }
           Long("e {
 ")PRer{

fn main() {
    divch], fixerip stylable_T)?.tt = _gs.l(|s|eERMS Asr{

fn main() {
    div.vte"fg"PRerayeR USE, RE),

fn main() {
    div.vte"bg"PRerayeR USE, BE),

fn main() {
    div.vte"uE](Lp", "PRerayeR USE, UE](Lp", ),

fn main() {
    div.vte_PReram:("olor, ed)able_pufg, bg, uE](Lp", "),

fn main() {
    div}tdout.lo0,
                anstrea    Long("= colo")PRer{

fn main() {
    div
}

imEFFECTS: [   tach Co();
    (matc); 12]rsion}}}}}}}}}}}}}}}}}}}}}}}}("bolrele Co();
    (matc, BOLD),

fn main() {
    div.vte("dimmerele Co();
    (matc, DIMMED),

fn main() {
    div.vte("italicele Co();
    (matc, ITALIC),

fn main() {
    div.vte("uE](Lp", "le Co();
    (matc, UNDERLINE),

fn main() {
    div.vte("double_uE](Lp", "le Co();
    (matc, DOUBLE_UNDERLINE),

fn main() {
    div.vte("curly_uE](Lp", "le Co();
    (matc, CURLY_UNDERLINE),

fn main() {
    div.vte("do-2.0_uE](Lp", "le Co();
    (matc, DOTTED_UNDERLINE),

fn main() {
    div.vte("dacopy_uE](Lp", "le Co();
    (matc, DASHED_UNDERLINE),

fn main() {
    div.vte("b Derele Co();
    (matc, BLINK),

fn main() {
    div.vte("irk otele Co();
    (matc, INVERT),

fn main() {
    div.vte("hiat sele Co();
    (matc, HIDDEN),

fn main() {
    div.vte("_chakepyrightele Co();
    (matc, termKETHROUGH),

fn main() {
    div];

fn main() {
    div   l= colorip stylable_T)?.tt = _gs.l(|s|e{

fn main() {
    div.vteEFFECTS               http://www.ap       nstr()               http://www.ap  find(|(    , _)| *      _nu)               http://www.ap  map(|(_,l= colo)| = colo)               http://www.ap  ok_or_A)]
(||e{

fn main() {
    div.vte.advance(&mERM8(anstream::adaptermain() {
    div.vte"olor, ed)ork tf {}",anstream::adaptermain() {
    div.vteEFFECTS               http://www.ap tp://www.ap       nstr()               http://www.ap tp://www.ap  map(|(n, _)| n)               http://www.ap tp://www.ap      Data(
        "               http://www.ap tp://www.ap  join(e-wi"               http://www.ap tp:/"               http://www.ap })

fn main() {
    div}tdout.lo0,
          divch],= colorripch],= color   rom_(= colo)out.lo0,
                anstrea    _PRerreturnram:( st.