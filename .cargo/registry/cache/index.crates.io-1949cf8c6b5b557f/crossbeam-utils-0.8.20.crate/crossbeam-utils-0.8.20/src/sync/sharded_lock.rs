use std::boxed::Box;
use std::cell::UnsafeCell;
use std::collections::HashMap;
use std::fmt;
use std::marker::PhantomData;
use std::mem;
use std::ops::{Deref, DerefMut};
use std::panic::{RefUnwindSafe, UnwindSafe};
use std::sync::{LockResult, PoisonError, TryLockError, TryLockResult};
use std::sync::{Mutex, RwLock, RwLockReadGuard, RwLockWriteGuard};
use std::thread::{self, ThreadId};
use std::vec::Vec;

use crate::sync::once_lock::OnceLock;
use crate::CachePadded;

/// The number of shards per sharded lock. Must be a power of two.
const NUM_SHARDS: usize = 8;

/// A shard containing a single reader-writer lock.
struct Shard {
    /// The inner reader-writer lock.
    lock: RwLock<()>,

    /// The write-guard keeping this shard locked.
    ///
    /// Write operations will lock each shard and store the guard here. These guards get dropped at
    /// the same time the big guard is dropped.
    write_guard: UnsafeCell<Option<RwLockWriteGuard<'static, ()>>>,
}

/// A sharded reader-writer lock.
///
/// This lock is equivalent to [`RwLock`], except read operations are faster and write operations
/// are slower.
///
/// A `ShardedLock` is internally made of a list of *shards*, each being a [`RwLock`] occupying a
/// single cache line. Read operations will pick one of the shards depending on the current thread
/// and lock it. Write operations need to lock all shards in succession.
///
/// By splitting the lock into shards, concurrent read operations will in most cases choose
/// different shards and thus update different cache lines, which is good for scalability. However,
/// write operations need to do more work and are therefore slower than usual.
///
/// The priority policy of the lock is dependent on the underlying operating system's
/// implementation, and this type does not guarantee that any particular policy will be used.
///
/// # Poisoning
///
/// A `ShardedLock`, like [`RwLock`], will become poisoned on a panic. Note that it may only be
/// poisoned if a panic occurs while a write operation is in progress. If a panic occurs in any
/// read operation, the lock will not be poisoned.
///
/// # Examples
///
/// ```
/// use crossbeam_utils::sync::ShardedLock;
///
/// let lock = ShardedLock::new(5);
///
/// // Any number of read locks can be held at once.
/// {
///     let r1 = lock.read().unwrap();
///     let r2 = lock.read().unwrap();
///     assert_eq!(*r1, 5);
///     assert_eq!(*r2, 5);
/// } // Read locks are dropped at this point.
///
/// // However, only one write lock may be held.
/// {
///     let mut w = lock.write().unwrap();
///     *w += 1;
///     assert_eq!(*w, 6);
/// } // Write lock is dropped here.
/// ```
///
/// [`RwLock`]: std::sync::RwLock
pub struct ShardedLock<T: ?Sized> {
    /// A list of locks protecting the internal data.
    shards: Box<[CachePadded<Shard>]>,

    /// The internal data.
    value: UnsafeCell<T>,
}

unsafe impl<T: ?Sized + Send> Send for ShardedLock<T> {}
unsafe impl<T: ?Sized + Send + Sync> Sync for ShardedLock<T> {}

impl<T: ?Sized> UnwindSafe for ShardedLock<T> {}
impl<T: ?Sized> RefUnwindSafe for ShardedLock<T> {}

impl<T> ShardedLock<T> {
    /// Creates a new sharded reader-writer lock.
    ///
    /// # Examples
    ///
    /// ```
    /// use crossbeam_utils::sync::ShardedLock;
    ///
    /// let lock = ShardedLock::new(5);
    /// ```
    pub fn new(value: T) -> ShardedLock<T> {
        ShardedLock {
            shards: (0..NUM_SHARDS)
                .map(|_| {
                    CachePadded::new(Shard {
                        lock: RwLock::new(()),
                        write_guard: UnsafeCell::new(None),
                    })
                })
                .collect::<Box<[_]>>(),
            value: UnsafeCell::new(value),
        }
    }

    /// Consumes this lock, returning the underlying data.
    ///
    /// # Errors
    ///
    /// This method will return an error if the lock is poisoned. A lock gets poisoned when a write
    /// operation panics.
    ///
    /// # Examples
    ///
    /// ```
    /// use crossbeam_utils::sync::ShardedLock;
    ///
    /// let lock = ShardedLock::new(String::new());
    /// {
    ///     let mut s = lock.write().unwrap();
    ///     *s = "modified".to_owned();
    /// }
    /// assert_eq!(lock.into_inner().unwrap(), "modified");
    /// ```
    pub fn into_inner(self) -> LockResult<T> {
        let is_poisoned = self.is_poisoned();
        let inner = self.value.into_inner();

        if is_poisoned {
            Err(PoisonError::new(inner))
        } else {
            Ok(inner)
        }
    }
}

impl<T: ?Sized> ShardedLock<T> {
    /// Returns `true` if the lock is poisoned.
    ///
    /// If another thread can still access the lock, it may become poisoned at any time. A `false`
    /// result should not be trusted without additional synchronization.
    ///
    /// # Examples
    ///
    /// ```
    /// use crossbeam_utils::sync::ShardedLock;
    /// use std::sync::Arc;
    /// use std::thread;
    ///
    /// let lock = Arc::new(ShardedLock::new(0));
    /// let c_lock = lock.clone();
    ///
    /// let _ = thread::spawn(move || {
    ///     let _lock = c_lock.write().unwrap();
    ///     panic!(); // the lock gets poisoned
    /// }).join();
    /// assert_eq!(lock.is_poisoned(), true);
    /// ```
    pub fn is_poisoned(&self) -> bool {
        self.shards[0].lock.is_poisoned()
    }

    /// Returns a mutable reference to the underlying data.
    ///
    /// Since this call borrows the lock mutably, no actual locking needs to take place.
    ///
    /// # Errors
    ///
    /// This method will return an error if the lock is poisoned. A lock gets poisoned when a write
    /// operation panics.
    ///
    /// # Examples
    ///
    /// ```
    /// use crossbeam_utils::sync::ShardedLock;
    ///
    /// let mut lock = ShardedLock::new(0);
    /// *lock.get_mut().unwrap() = 10;
    /// assert_eq!(*lock.read().unwrap(), 10);
    /// ```
    pub fn get_mut(&mut self) -> LockResult<&mut T> {
        let is_poisoned = self.is_poisoned();
        let inner = unsafe { &mut *self.value.get() };

        if is_poisoned {
            Err(PoisonError::new(inner))
        } else {
            Ok(inner)
        }
    }

    /// Attempts to acquire this lock with shared read access.
    ///
    /// If the access could not be granted at this time, an error is returned. Otherwise, a guard
    /// is returned which will release the shared access when it is dropped. This method does not
    /// provide any guarantees with respect to the ordering of whether contentious readers or
    /// writers will acquire the lock first.
    ///
    /// # Errors
    ///
    /// This method will return an error if the lock is poisoned. A lock gets poisoned when a write
    /// operation panics.
    ///
    /// # Examples
    ///
    /// ```
    /// use crossbeam_utils::sync::ShardedLock;
    ///
    /// let lock = ShardedLock::new(1);
    ///
    /// match lock.try_read() {
    ///     Ok(n) => assert_eq!(*n, 1),
    ///     Err(_) => unreachable!(),
    /// };
    /// ```
    pub fn try_read(&self) -> TryLockResult<ShardedLockReadGuard<'_, T>> {
        // Take the current thread index and map it to a shard index. Thread indices will tend to
        // distribute shards among threads equally, thus reducing contention due to read-locking.
        let current_index = current_index().unwrap_or(0);
        let shard_index = current_index & (self.shards.len() - 1);

        match self.shards[shard_index].lock.try_read() {
            Ok(guard) => Ok(ShardedLockReadGuard {
                lock: self,
                _guard: guard,
                _marker: PhantomData,
            }),
            Err(TryLockError::Poisoned(err)) => {
                let guard = ShardedLockReadGuard {
                    lock: self,
                    _guard: err.into_inner(),
                    _marker: PhantomData,
                };
                Err(TryLockError::Poisoned(PoisonError::new(guard)))
            }
            Err(TryLockError::WouldBlock) => Err(TryLockError::WouldBlock),
        }
    }

    /// Locks with shared read access();
///  => Erri     // SAFETY: The inner value has been inlocked ut.
    d returned [`Unparker`] mutow local v/ # Poisor [`parkde availa  /ointnhereforehe lock  sharh(EMP A lock . [`Unparker`re//     ll acceiters wient
    //insth rpoisoned.
 wakes an error NOTIFIEt
    /// pro [`Unparkat any pas with respect to the ordering of whether contentious readers or
    /// writers wnics.
    r the lock first.
    ///
    /// # Errors
    ///
    erence to adGuare shared access when it is dropped. This mard: UnsafeCe    ///
    /// This method will return an error if the lock is poisoned. A lock gets poisoned when a write
    /// operation panics.
    ///
    /// # Examples
    ///
    / If `f` panics, the parn an error might/// reaopera read `ed. A lock gets        //   arker`]inner value haxamples
    ///
    /// ```
    /// use crossbeam_utils::sync::ShardedLock;
    /// use std::sync::Arc;
    /// use std::thread;
    ///
    /// let lock = Arc::new(ShardedLock::new(0));
    /// let c_lo1k = lock.clone();
    ///
    /// let _ = thread::spawn(movn();
///     assert_eq!(*rock.read().unwrap(),r(_) ead::spawn(move || {
    ///     thread::sleep(Duratiounwrarap();
       as); // the lockcompleter{
      /
    /// // rt_eq!(sert_eq!(*rock.readad(&self) -> TrkResult<ShardedkReadGuard<'_, T>> {
        // Take the current thread index and map it to a shard index. Thread indices will tend to
        // distribute shards among threads equally, thus reducing contention due to read-locking.
        let current_index = current_index().unwrap_or(0);
        let shard_index = current_index & (self.shards.len() - 1);

        match self.shards[shard_index].lock.try_read() {
        Ok(guard) => Ok(ShardedLockReadGuard {
                lock: self,
                _guard: guard,
                _marker: PhantomData,
            }),
            Err(TryLockError::Poisone    :WouldBld)))
            {
                lock: self,
                _guard: guard,
                               _marker: PhantomD
            }),
            Err(Try   /// Locks with shared reahis lock with shared read access.
 exclus
   d.
///// If the access could not be granted at this time, an error is returned. Otherwise, a guard
    /// is returned which will release the shared access when itexclus
   pped. This method does not
    /// provide which wily pas with respect to the ordering of whether contentious readers or
    /// writers will acquire the lock first.
    ///
    /// # Errors
    ///
    /// This method will return an error if the lock is poisoned. A lock gets poisoned when a write
    /// operation panics.
    ///
    /// # Examples
    ///
    /// ```
    /// use crossbeam_utils::sync::ShardedLock;
    ///
    /// let lock = ShardedLock::new(1);
    ///
    /// match lock.try_read()(movn();
///     assert_eq!(*rock.read().unwrap(),r(_) ead::spawn(move ||complete          ///    
  poi(ub fn park_timeout(&self, t     ///  lt<ShardedLockReadGuard<'_, T>> {
 )>>>,
}

///ake the current tdLock::nisoned();
  shou;current tdLock::nr [`park=it(m) The inner val)>>>,-tore the guard h/ By splitting er { .. }son(i,guard )h/ By;

        e lo   enum//
 euard) => Ok(ShardckReadGuard rd_inde    .          ///   ck: self,
         edLockReadGua  _marker: PhantomData,soned(err)) => {
                let guard = ShardedLout(&ssoned();
   pu }
                }
                 
             }
            };

   ldBlock) => Err(TryLockError::Wou guard = ShardedLout(&r [`park=i     i  if now < deadline {
 b   k;          };

            if self
             rrowThese guards gent reon the cu. (*self.value.get()).guard = ShardedLockReadGua: tic, ()>>>,
}

/// A sharded rd rstd:e cesk::eLockRea;guard = ShardedLockRedest: *k::ne ||he cu.ll::new(Non.once.cauard = ShardedLo*destk=i     ockRea;guard = Shard// Otherwise we need  = deadline it_eqr [`parkk the current thrUnad on the
///
/// Brlocks contenthe inteent_index = c .. }sonuard h/ By_poisoned()
..i] e lo   rlo  ck: self,
         .get()).guard = ShardedLoedLockRedest: *k::ne ||he cu.ll::new(Non.once.cauard = ShardedLohardckReadGuard (*dest).   /e.cauard = ShardedLohard.unwrockRea;guard = ShardedLo}      Err(TryLockError::WouldBlock) => Err(TryLockError:         Ok(inne =   Err(PoisonError::new(ckReadGuard {
         )>>>,
}

/ck: self,
                _guard: guard,
                   }),
            Err(Tr;
ckError::Poisoned(PoisonError::new(guard)))
            }
            ErrOk(inner)
        }
    {
         )>>>,
}

/ck: self,
                _guard: guard,
                   }),
            Err(Tr) /// Locks with shared read access();exclus
   d.
///// If // SAFETY: The inner value has been inlocked ut.
    d returned [`Unparker`] mutow local v/ # Poisor [`parkde availa  /ointnhereforehe lock  sharh(EMP A lock . [`Unparker`re//     ll acceiters wient
    //insth rpoisoned.
 wakes an error NOTIFIEt
    /// pro [`Unparkat any pas with respect to the ordering of whether contentious readers or
    /// writers wnics.
    r the lock first.
    ///
    /// # Errors
    ///
    erence to adGuare shared access when itexclus
   pped. This mard: UnsafeCe    ///
    /// This method will return an error if the lock is poisoned. A lock gets poisoned when a write
    /// operation panics.
    ///
    /// # Examples
    ///
    / If `f` panics, the parn an error might/// reaopera read `ed. A lock gets        //   arker`]inner value haxamples
    ///
    /// ```
    /// use crossbeam_utils::sync::ShardedLock;
    /// use std::sync::Arc;
hardedLock::new(1);
    ///
    /// match lock.try_read()(movk::nnp();
    ///     *s = "modified".t*n
    sd::spawn(move ||complete             ass
  poi(ub fn park_timeout(&self, t ///  lt<ShardedkReadGuard<'_, T>> {
 )>>>,
}

///ake the current tdLock::nisoned();
  shou;che inner val)>>>,-tore the guard h/ By splitting er { .. }sonuard h/ By_poisoned( e lo  rd) => Ok(ShardckReadGuard rd_inde    .      ///   ck: self,
         edLockReadGua  _marker: PhantomData,sone    :Wou guard = ShardedLout(&ssoned();
   pu }
                }
                 
             }
            };
lf
             rrowThese guards gent reon the cu. (*self.value.get()).guard = ShardedLockReadGua: tic, ()>>>,
}

///_rded rd adGua;guard = ShardedLockReadGua: tic, ()>>>,
}

/// A sharded rd rstd:e cesk::eLockRea;guard = ShardedLockRedest: *k::ne ||he cu.ll::new(Non.once.cauard = ShardedLo*destk=i     ockRea;guard = Shard// Otherwise we need  =   Err(PoisonError::new(inner))
        } els{
         )>>>,
}

/ck: self,
                _guard: guard,
                   }),
            Err(Tr)       ErrOk(inner)
        }
    {
         )>>>,
}

/ck: self,
                _guard: guard,
                   }),
            Err(Tr) /// Locks with sardedLock<T> {
   +ker {
    f>ker {
    fn fmt/// Returns `true` if fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Unparker { .. rd_index].l    Ok(guard) => Ok(ShardedLockReadGuaate
               ce.is_ ?Size("/// Returns"llect::<Box<[_]>>()fi/  (" Sin", &&*ockRealect::<Box<[_]>>()finish(yLockError::Poisoned(err)) => {
                letate
               ce.is_ ?Size("/// Returns"llect::<Box<[_]>>()fi/  (" Sin", &&**     Locref()alect::<Box<[_]>>()finish(yLockError::Poisoned(err)) => {
 yLockError::Wou guard = ShardedLo ?SizedL[`parP # Eh(EMet p = P             parker {
    fn fmtL[`parP # Eh(EMetu guard = ShardedLout(& fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Unparker { ..  = ShardedLout(& .ll::ne ?S("< [`par>"llect::<Box<[_]>>( }
            };

            if seut(& .ce.is_ ?Size("/// Returns"llect::<Box<[_]>>(]>>()fi/  (" Sin", &L[`parP # Eh(EMetllect::<Box<[_]>>(]>>()finish(yguard = Shard// Otherwisewith sardedLock<T    fn >
    fn defau/// Returns `true` if fm       Self {
   ShardedLock {
            shards } els    fn   /// Blockop for OnceLock<T> From<T>  fmt/// Returns `true` if fmtrom(t> {
                 unp    shards } elsts a thread parkAards get can      drop(n it is dro> Erri     *, eac[`RwLock`], wi]This mard: Unsa#[clippy::has_sign
    n
    }]ck<T: ?Sized> {
    ///       // Take  list of locks p      &'at/// Returns `tmData<*adGua: tic, (       // Taker,
}

imp*const ()>,
}

unsafetic, (       // TakeT>?Sized + Send> Send for ShardedLock<T> {}

impl<T: ?Size       // Take tUnwindSafe for Shardeanic:}

impl<T: ?Size       // Take tUn

impee thTar/ th= Tf
      fm  ref(  debug_assert!(self.onalue.get()*ap());
      if is_poisewith sardedLock<Ter {
    f>ker {
    fn fmt/// Returns       // Take tUn

imp fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Unparker { .. }"ce.is_ ?Size("/// Returns       //"llect::<Box<[_)fi/  (";
  ", &ap());
  llect::<Box<[_)finish(yguard sardedLock<T> {
   +ker {
 isplay>ker {
 isplayn fmt/// Returns       // Take tUn

imp fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Unparker { .. (**ap()).t::Ffs a thread parkAards get can      drop(n itexclus
   d.
///// If *, eac[`RwLock`], wi]This mard: Unsa#[clippy::has_sign
    n
    }]ck<T: ?Sized> {
    ///)>>>,
}

///ake  list of locks p      &'at/// Returns `tmData<*const ()>,
}

unsafetic, ()>>>,
}

///ake >?Sized + Send> Send for ShardedLock<T> {}

impl<T: ?Size)>>>,
}

///ake tUnwindSafe for Shardea
    fn pl<T: ?Size)>>>,
}

///ake tUnf) {
        if self.once.is_complthrUnad on the
///
/// Brlocks contenthe inteent_index = c}sonuard h/ By_poi;
          e lo   rlo  ck: self,
     .get()).guard = ShardedLockRedest: *k::ne ||he cu.ll::new(Non.once.cauard = ShardedLockReadGuard (*dest).   /e.cauard = ShardedLo.unwrockRea;guard = Shard// Otherwisewith sardedLock<Ter {
    f>ker {
    fn fmt/// Returns)>>>,
}

///ake tUnf) {
   t::Formatter<'_>) -> fmt::Result {
        f.pad("Unparker { .. }"ce.is_ ?Size("/// Returns)>>>,
}

/"llect::<Box<[_)fi/  (";
  ", &ap());
  llect::<Box<[_)finish(yguard sardedLock<T> {
   +ker {
 isplay>ker {
 isplayn fmt/// Returns)>>>,
}

///ake tUnf) {
   t::Formatter<'_>) -> fmt::Result {
        f.pad("Unparker { .. (**ap()).t::Ffs a thread dSafe for Shardeanic:}

impl<T: ?Size)>>>,
}

///ake tUnf) {
ee thTar/ th= Tf
      fm  ref(  debug_assert!(self.onalue.get()*ap());
      if is_poisewith sardedLock<Tr Shardeanic:Mut  fn pl<T: ?Size)>>>,
}

///ake tUnf) {
    nic:ckResult<&mut T> {
 is_port!(self.onalue.get() };

     ;
      if is_poisewith sard    erence to `rd co`/// poig op    sker`]inner value haxatd::syncEhe git to a s].
pub strucrderian ') {
 '. Wn is ila  /ointnhel be used.
ct to the ,
       ils::sy.
    stribut  // onsecuut,  can besked threa0rked
    can be heldunnow local vsxatd::syncws the lockfuncly.
  / If  skTLS, `Nthe paight/b`] doesn't ed. A linner value ha'skTLS/ bee || eantioudownsa#[infor ]
park_or(0);
      > {
rd<'stard cotUnf) {
REGISTRATION      der(|reg|] dg.
    ).     }hards per globathe gg thyocked.
   rtiveheld gg tereps://githuked
       /// The iec::Vec       :sleep(DurMapd.
  e to `ec::Vec;`hether to a shar_indexmapd.
 : ;
use s<ec::Vec;,ard conal data.
  cting the free
       //) {
 ree_ing : Vec<rd conal data.
  T     Errlen() withl;
     }d. A lfree
ing tLock    //) {
  Er;
    hard coSized, t c::Ve_         > {
&/ A sha Condvaec::Vec      >size,
    lha THREAD_INDICES: CachePad<Condvaec::Vec      > rd CachePadu = p.unparke> Loci Self {Condvaec::Vec      >size,
                ec::Vec       :sleeper { .. rdpd.
 : ;
use s    }),
            } ree_ing : Vec    }),
            }  Er;
    ha0  /// Lockss a threa thTHREAD_INDICES  Locor_oci Soci )ead parkAae gg th
    /, eacocal v/ #erian  shar_itd::syncWis mard: Un,/// }gg tersn [`park`] oked
 reeswait_tiade b a shar_i/ The iR gg th
    /r>,
}

u   hard coSiation::fro_ia: ec::Vec;,fn park(&a
    fn R gg th
    /r>,
}
        if self.once.is_compldLock::n        =t c::Ve_               match self.snner.clone     /rdpd.
  rl thr(  deb.n::fro_iaf.snner.clone     / ree_ing .push(          )          
    /// let);
 al!size,
    lha REGISTRATION: R gg th
    /=ce.is_compldLocn::fro_ia || {
    /k_or(0)ass
r = unsafe { &mutk::n        =t c::Ve_               match self.sunsafe { &mut * (selfrd_indne     / ree_ing .pop(deadline) => self.pari::Woui self.park(),
        .guard = ShardedLockReielfne     /  Er;
     p = P             e     /  Er;
    _eq!(*w = P             guard = Shard// Otherwis.snner.clone     /rdpd.
  inmple(n::fro_ia,      )  snner.cloR gg th
    /r>,
}
nner.clone ex self.park(),
n::fro_ia