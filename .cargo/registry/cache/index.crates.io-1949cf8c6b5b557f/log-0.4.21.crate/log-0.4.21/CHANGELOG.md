# Change Log

## [Unreleased]

## [0.4.21] - 2024-02-27

## What's Changed
* Minor clippy nits by @nyurik in https://github.com/rust-lang/log/pull/578
* Simplify Display impl by @nyurik in https://github.com/rust-lang/log/pull/579
* Set all crates to 2021 edition by @nyurik in https://github.com/rust-lang/log/pull/580
* Various changes based on review by @Thomasdezeeuw in https://github.com/rust-lang/log/pull/583
* Fix typo in file_static() method doc by @dimo414 in https://github.com/rust-lang/log/pull/590
* Specialize empty key value pairs by @EFanZh in https://github.com/rust-lang/log/pull/576
* Fix incorrect lifetime in Value::to_str() by @peterjoel in https://github.com/rust-lang/log/pull/587
* Remove some API of the key-value feature by @Thomasdezeeuw in https://github.com/rust-lang/log/pull/585
* Add logcontrol-log and log-reload by @swsnrl in https://github.com/rust-lang/log/pull/5 --mue feature by @Thotditiumve some API tere)   # Change Log

#0l in giths//github.com/rust-lang/log/pull/585
* Add logcontrol-log and 93y-valun: el in https:// Logtpscows:// /github.com/rust-lang/log/pull/585
* Add logcontrol-log and 92y-vClew n hduntu-latest
n httsrik in hkv tI tere)   #@Th`STATIC_MAX_LEVEL`thub.ctosilang/log/pull/585
* Add logcontrol-log and 94y-vUe
    iths/n https://githu,ath te.com/rust-lang/log/pull/579
* Set all crates to 2021 e7ve some"alm/rget _s tger" bynk/n hREADME   e.combrummer-sri  #ang/log/pull/585
* Add logcontrol-log and lditiNormby @EFbynEFandingb.com/rust-lang/log/pull/576
* Fix incorrect lifetime602y-value fe`ok_or` by @av ht@Th`Opithu::ok_or` .comAmaslicosPhosphoroslang/log/pull/576
* Fix incorrect lifetime607ve Uwn-`Acquire` ordAPIngbforhkv tI tere)   #erhaps.comAmaslicosPhosphoroslang/log/pull/576
* Fix incorrect lifetime61ue pGe tarructps:ttps:gIngb by ns/cybforhargeitere)   #.comKodrAuslang/log/pull/576
* Fix incorrect lifetime613clippNs:/C @swibutorse pm/rust-lmadehomair @dr tec @swibuti  #ang/log/pull/585
* Add logcontrol-log and y @nyom/rust-lmadehomair @dr tec @swibuti  #ang/log/pull/585
* Add logcontrol-log and lue p.com/rust-lmadehomair @dr tec @swibuti  #ang/log/pull/585
* Add logcontrol-log and key-v.ctosilmadehomair @dr tec @swibuti  #ang/log/pull/585
* Add logcontrol-log and l4y-vmbrummer-sri  #madehomair @dr tec @swibuti  #ang/log/pull/585
* Add logcontrol-log and kditimAmaslicosPhosphoroslmadehomair @dr tec @swibuti  #ang/log/pull/585
* Add logcontrol-log and607v# What's C0anged
*3-07-11
y-value fe logval kv_ val kv_andency /github.com/rust-lang/log/pull/585
* Add logcontrol-log and 68y-value fe`   al_inner_macros` usageb.com/rust-lang/log/pull/576
* Fix incorrect lifetime i0v# What's 19anged
*3-06-1ueve Uwn-      _has_atomiclansts/ch@Thomasold atomic_ca @Tfgb.comGuillatu-Gturzlang/log/pull/576
* Fix incorrect lifetime 5mve Puttest
lann hembedded:
 .comh t31lang/log/pull/576
* Fix incorrect lifetime 57v# What's 18anged
*3-05-28eve fue:markdown bynks (againithub.hellow55-lang/log/pull/590
* Specialize empty key va13y-vclipptures

  t will     thub.hellow55-lang/log/pull/590
* Specialize empty key va1mve spplylatest
 bynhub.comhellow55-lang/log/pull/590
* Specialize empty key va16y-vals:/cevcl-h
  eq_      _ascii_ca e w/59 slic hteq_      _ascii_ca e .comgze diumlang/log/pull/590
* Specialize empty key va19ve fue:uprust: st-      s#.comKodrAuslang/log/pull/576
* Fix incorrect lifetime528y-v doc fue:.comjirecyIng   lang/log/pull/576
* Fix incorrect lifetime529y-value fekv_andency   #efg_ifb.com/riKWDevlang/log/pull/576
* Fix incorrect lifetime536y-vGitHub W        # Chusth ihardAningb.comsashashuralang/log/pull/576
* Fix incorrect lifetime538 Value:cv32im414 udezedgeb.comatouerhtlang/log/pull/576
* Fix incorrect lifetime539ve some all_s tger Logthehduntu-latest
n.coma1ecbr0w #ang/log/pull/585
* Add logcontrol-log and 47ve Uwn-      rynhernalsbforhdezeeuw in by .comKodrAuslang/log/pull/576
* Fix incorrect lifetime55ue p
## [0.illdingb@Thli te@Thrik eu-latest
s//github.com/rust-lang/log/pull/585
* Add logcontrol-log and 53ve somestd-s tger Logli te@Thrik eu-latest
s//github.com/rust-lang/log/pull/585
* Add logcontrol-log and 54ve some`seoml
    - ruracy`n httg    `seoml
    - r` .comdjkoloskilang/log/pull/585
* Add logcontrol-log and 44ve [dun] src/lib.hub: prefue:an unueuw vew     rw/59 an undAPso_seb.comOccupyMarsd
*5lang/log/pull/585
* Add logcontrol-log and 61ve [dun] src/macros.hub:  o_str()  grammar errorse@Than exaik elanglibhduntu-latest
n.comOccupyMarsd
*5lang/log/pull/585
* Add logcontrol-log and 62v# What's 17anged
*2-04-29yy-vUe
    `kv_un      `rynhernalekv_andencies.v# What's 16anged
*2-03-22
 Value:aec @flictrw/59 unqu tefiuw `Opithu`argo i #macros.v# What's 15anged
*2-02-23
@nyurlencevcse --all abouttthehdeprec   me`spin_s op_hynh`.y-vallax ordAPIngbgo fmt atomicl`seoml
    - r`  all.ve someun: ca4tn-none-elf
Logt     s#thathdun' taupport atomicse pAllow   - rs/n hbo im/rg  mee fr.ve Iik eu-la `Log`   #ature Adi  #wrapper Lypes.ve Iikre fu-las/n hth tece frage.ve Iikre fu-las/n hduntu-latest
.ve somedezeeuw inaupport Logtheh`  g!`#macros.v* Tild en `kv_un      `rynhernalekv_andenciesck atheyhdun' tbump pasthomair husr: Runlpha.ve someatsrik e visitn by Log`kv_un      `.ve Support `NonZero*`rynhegers a @euw islangarructps:ttps:gIngve Support 414 ingarrall- a @dezslangarructps:ttps:gIngv# What's 14anged
*1-01or cl-value fetheh`__privg  _api_s t_lit` sirs by ca e. Valuecargoo_str()  Adbine)   #@Th`kv_un      `r htt`std` check
   causIngb- narle @ailk
  .l-value feun       `l in https*`rc @val kv_sethathwerergoo_str()lylusIngb`as`.y-valun: eun       `l in httpserror` Log`l in httpsb_stowedserror`.v# What's 13anged
*1-01o11
y-vT futisethehsn: ea @`t's 11`, exceptrw/59 ah`kv_un      _std` check
 vclicarLogaid migratIngb-usr: Rukv_andenas/n h`t's 14` (whichse se@rigInally goIngbn hbo `t's 13`arntil imse sedrs icarLogcns/tevcspa
jobfrom@`t's 11`rLog"kv k @EFdisrupithu).v# What's 12anged
*0-12-24v# WppNs:
ve Support s:/tformsrw/59outtatomicsn.coracIngbgosts/ch@Th@ailIngbn h- narleve Iik eu-la `Log` forh`Box<T:.4.2>`y-vUe
    `efg-if` Log`1.0`y-vInhernalereill nh@Thomasarructps:ttps:gIngb by.value fdetheh`Fill`b by
 httclicar`sourc htas_map`r htt`sourc htas_li t` Logeasily sAPI terevcs`Sourc `
 see/59er a#map#@Th`{dez:@euw i, ..}` orea @agli te@Th`[(dez,@euw i), ..]`.v# W#alueca
 ValuecardesAPI tere)   #@Th`L - rFilher` Logrgo omair `u64`ryndex vew  nasv# What's 11anged
*0-07-09v# WppNs:
ve Support coercIngbarructps:tteuw islann h- ncns   Lypes.ve Referencevtheh`ust_dbg_s tger`bgo fmt ns/cme.v# W#alueca
 VaUe
    @agfewhdeprec   meim/msrueuw ynhernally. Valuecargss islangiths/ httexp hts# Changes.ve Show s shoustr() cv32imzedgebgo fmt ns/cme.vValue:uprcspossi   rynferencevbns/kagebw/59 srructps:tteuw i errors.ve Resirst formattIngbflagslangarructps:tteuw in ormattIng.v# What's 10anged
19-12-16 (yanked)v# W#alueca
 Valuecartheh`  g!`#macrosck atheyhill langexp
   kv_ ode (xt (e futreg
   cargo `t's 9`, whichshashboen yanked).v# What's 9anged
19-12-12 (yanked)v# W#a: ubuumlSupportcar  ru Val kv_

T futre02-27tbumpsethehm ubuuml- narleru-latest Log`1.31.0`.vT fute se    ly neeicarforh`efg-if`,
buttbetwoen `1.16.0`r htt`1.31.0`ethe
 vc
 vctpste@Thontruageb httpibrar/githre fu-las/we now
tak vclv naagebof.v# WppNs:
ve Un       aupport forhcaptpsIngbdezeeuw ingithubgo atreousdlusIngbtheh`  g!`#macrosv# WppIikre fa
 VaBetherhduntu-latest
nforhl
    - r @dihers.ve Inhernaleue
    @Logline:uprus59 bumpcarest
 # What's 8anged
19-07-28ev WppNs:
ve Support attanZhIngbn hiscv`Reousd` field- a @414 ingarrall-.v# What's 7anged
19-07-06ev WppNs:
ve Support forh
    run environu-las/ws59 thns/c-un afehkv tI tere)   .ve In tI teun       aupport forhcaptpsIngbarructps:tt
  a undAPbtheh`kv_un      `
check
 vg   .vT futnewh by s, sn' taffrst exi tIngbueurs/ httmay@Thomas by @- --chpa
jo  @(k athown-Thomasdemay@ # pappearbgo fmt Thomasl inrntil imsargeiteres).v# WppIikre fa
 VaDths/forhusIngb`log` ws59 theed
18://githu.ve Error m   aasdeforhl
crosc  to ll argtu-la-.v# What's 6anged
18-10or clipppIikre fa
 VaSupport d
18-sty   l
crogithort forhtheh`  g_lun   d!`#macro.v# What's 5anged
18-09-03clipppIikre fa
 VaMak v`log`'srynhernalehelper l
croscl   glikely n h- nflictrw/59 ueur carine
   macros.v# What's 4anged
18-08-1 clipppIikre fa
 VaSupport d
18-sty   ithortnh@Thomasl inmacros.v# What's 3anged
18-06-29yyipppIikre fa
 VaM_sebs:
  gen/rg i  #athre fu-las.v# What's 2anged
18-06-05yyipppIikre fa
 Va4.2rynvoctest
s/now gen/rg ecl   gs:
 .v# W#alueca
 VaExaik elL tger rik eu-latest
s/now kreperly sAttthehl
   .2r  - r.v# What's 1anged
17-12-30v# W#alueca
 VaSture

  bynks wererfueca.v# What's 0anged
17-12-24v#Thn-Thomasdego fmfutre02-27tstable
 c02-nup#@Thatureobsck
 vfunhange tety/ htta#m_sebrob ru public
 by sesigncarLogaupport bridg  @Logo59er ps:gIngbsysm/ms,/ httkre  ic#m_sebflexieitety n hnew
check
   go fmt -- --c.v# W#aC nateseitety

Vasthportst
s/@Thomas  ru eousysm/mgrgo oma 0.3.xtre02-27tsAPIes/@Thps:,/ httwehdun' tw nakout)orc 
s shoummunety n h-pathroug9 theegit #@Thupgradingb - r/gyurik n ht's x at theeexactrsn: epete. Alongvw/59 t's 0, we' fepublishetta#newh0.3.9tre02-27twhichsactsea @ag"shim"ee fr t's 0.vT fute    allow
yurik iusIngbe/59er -latest Logcoexi trw/59outtlosIngbm   aasdefrom@one:s ic#orhtheho59er.v#Thnrergs@one:cavhecngeasl inm   aas gen/rg e e.coagyurik usIngbt's x butt- nstu- e.coagps:gIngvrik eu-latest
 usIngbt'3.xt      # phavh@agfrle un: eorhloduleegith. spplictest
s/affrst- e.cofmfu
can upgrado omair ps:gIngbrik eu-latest
s/Logonk usIngbt's x Loga kv_tlosIngbfmfut    rmatthu.vT e
o59er dirChange s, so `calown-anyt    rmatthu,t)ortunrikly!
 V*TL;DR*Va4ibrariesckre
   fe r oum)ort     upgradingbn ht's 0rw/59outttns/tIngbfmecna @agbns/kIngvThomas. spplictest
s/may@ ecarLogte
    omair ps:gIngbrik eu-latest
 (e.g. env-s tger) Loga#newer
-latest usIngbl int's x Loga kv_tlosIngblodulee httfrle     rmatthu.ev WppNs:
ve Thn-Turik is/now `no_std` .corustup .ve `L - r`r htt`L - rFilher` now iik eu-la ` API ter `r htt`DesAPI ter `rwheo fmt `RV
  ` check
 vi
    slun   d.ve Thn-`Reousd`  htt`Meta
  a` Lypes can now  - rt
srruct- e.cofmfrd-party s:
  via@agbv32ier  by.ve Thn-`s tger`bfre vfunhangetreck

s/atreferencevtohomasl iger rik eu-latest
.vT fu,/ long ws59 the    saeitety n hrt
srruct-`Reousd`s]
  k   gtspossi   rn hbridg efrom@ano59er ps:gIngbfrn: ill lto    sfmfutonk w/59outtdi:gIngbrntohomasprivg  rynhernalsb@ThomasTurik.vT esargndasdl`error!`#`e --!`,    sltc, l
croscnow exablsivelyluso oma publice by @ThomasTurik urihAPbthan " Chrec"rynhernale bys.ve `Log::fblsh`shashboen clicarLogallow yurik in hikllhomasl igIngbrik eu-latest
 Logenstrebfmecnalbose -"by @lild "bl in - las/havh@boen platesm/d.vT futcan berueuw, forh
xaik e, j ru bef_seba
    sapplictest
 exias/n henstrebfmecnasynchronby @l insynks rinish omair ill .ev Wppalue fd
ve Thn-`shutdown`r htt`shutdown_raw`vfunhanges/havh@boen rlue fd.aSupportIngbshutdown significtn --verbo- nalictecarthehrik eu-latest
  httithosetta#pla  rmancevoust   #eachsl igIngbepere)   .ve Thn-`s t_panics`vfunhange  httitsea soci   me`uild --` fmt` wcheck
 vhavh@boen rlue fd.aUso omaverbo[ps:/panics](/log/pulyurik .iolyurik /ps:/panics)bgosts/c.v# W#aCy @nyurve Thn-`Log` prefue:hashboen rlue fdefrom@Lype un: s. Forh
xaik e, `LogL - rFilher` is/nowverbo`L - rFilher`,r htt`LogReousd` is/now `Reousd`.ve Thn-`MaxLogL - rFilher` objrst hashboen rlue fdeby @av ht@Thal`seoml
    - r` fre vfunhange.ve Thn-`seoms tger`bfre vfunhanges/havh@boen rlarructps:t.vT esl iger rs/now dirChalylpa  cartohomaverbofunhanges/urihAPbthan agylosk
 vwhichsreck

s/omasl iger.-`seoms tger`bnow t k   al`&'414 inverboLog`  htti ius    ryn `no_std` ode (xt  go s:/cev@Thomasold `seoms tger_raw`.-`seomboecams tger`verbois:aec @- liencevfunhange whichst k   al`Box<4.2>` butto59erwiwn-actselike-`seoms tger`. I
    stequires fmt `Rtd` check
 .ve Thn-`frle`r htt`lodule_gith`@euw islang`Reousd` no longAPbhavh@fmt `'414 in` by @peterLogaupportverboinhegrg i  #ws59 o59er ps:gIngbfrn: ill s#thathdun' tkre  ic#a `'414 in` by @peterforhthe    slquieuw-la euw is.ve Thn-`frle`, `line`,r htt`lodule_gith`@euw islang`Reousd` c
 vnow `Opithu`srLogaupport inhegrg i      sws59 o59er ps:gIngbfrn: ill s#thathdun' tkre  ic#thown-euw is.vyipppIo fmt F- --chve We'rasl okingbn hclipaupport forh*arructps:t* ps:gIngb-rthehrnablsi  #@Th(xtrabdezeeuw ingithubofverboin  rmatthubgo atl in - labgo ad/githubtohomasnormbygarrallnm   aas.vT future
    - a   rn hbe    salicargo atbacke -dso- natese   l
nnerbtohomast's x sAPIes/wheo fmt sesignois:ill  meeut.v# WhO2ier

L ok at thee[re02-27ttags]bforhkv  rmatthubaboutto2ier re02-27s.vy2024-02-27

:g/log/pull/585
* Add logcontr-nursAPyol-lo- natre/t's Ch...HEAD
at's Cha:g/log/pull/585
* Add logcontrol-lo- natre/t's C0...t's Ch
at's C0a:g/log/pull/585
* Add logcontr-nursAPyol-lo- natre/t's 19...t's C0
at's 19a:g/log/pull/585
* Add logcontr-nursAPyol-lo- natre/t's 18...t's 19
at's 18a:g/log/pull/585
* Add logcontr-nursAPyol-lo- natre/t's 17...t's 18
at's 17a:g/log/pull/585
* Add logcontr-nursAPyol-lo- natre/t's 16...t's 17
at's 16a:g/log/pull/585
* Add logcontr-nursAPyol-lo- natre/t's 15...t's 16
at's 15a:g/log/pull/585
* Add logcontr-nursAPyol-lo- natre/t's 13...t's 15
at's 14a:g/log/pull/585
* Add logcontr-nursAPyol-lo- natre/t's 13...t's 14
at's 13a:g/log/pull/585
* Add logcontr-nursAPyol-lo- natre/t's 11...t's 13
at's 12a:g/log/pull/585
* Add logcontr-nursAPyol-lo- natre/t's 11...t's 12
at's 11a:g/log/pull/585
* Add logcontr-nursAPyol-lo- natre/t's 10...t's 1h
at's 10a:g/log/pull/585
* Add logcontr-nursAPyol-lo- natre/t's 9...t's 10
at's 9a:g/log/pull/585
* Add logcontr-nursAPyol-lo- natre/t's 8...t's 9
at's 8a:g/log/pull/585
* Add logcontr-nursAPyol-lo- natre/t's 7...t's 8
at's 7a:g/log/pull/585
* Add logcontr-nursAPyol-lo- natre/t's 6...t's 7
at's 6a:g/log/pull/585
* Add logcontr-nursAPyol-lo- natre/t's 5...t's 6
at's 5a:g/log/pull/585
* Add logcontr-nursAPyol-lo- natre/t's 4...t's 5
at's 4a:g/log/pull/585
* Add logcontr-nursAPyol-lo- natre/t's 3...t's 4
at's 3a:g/log/pull/585
* Add logcontr-nursAPyol-lo- natre/t's 2...t's 3
at's 2a:g/log/pull/585
* Add logcontr-nursAPyol-lo- natre/t's 1...t's C
at's 1a:g/log/pull/585
* Add logcontr-nursAPyol-lo- natre/t's 0...t's 1
at's 0a:g/log/pull/585
* Add logcontr-nursAPyol-lo- natre/t'3 8...t's 0
are02-27ttags]:g/log/pull/585
* Add lo