1.10.2 (2023-10-16)
===================
This is a new patch release that fixes a search regression where incorrect
matches could be reported.

Bug fixes:

* [BUG #1110](https://github.com/rust-lang/regex/issues/1110):
Revert broadening of reverse suffix literal optimization introduced in 1.10.1.


1.10.1 (2023-10-14)
===================
This is a new patch release with a minor increase in the number of valid
patterns and a broadening of some literal optimizations.

New features:

* [FEATURE 04f5d7be](https://github.com/rust-lang/regex/commit/04f5d7be4efc542864cc400f5d43fbea4eb9bab6):
Loosen ASCII-compatible rules such that regexes like `(?-u:☃)` are now allowed.

Performance improvements:

* [PERF 8a8d599f](https://github.com/rust-lang/regex/commit/8a8d599f9d2f2d78e9ad84e4084788c2d563afa5):
Broader the reverse suffix optimization to apply in more cases.


1.10.0 (2023-10-09)
===================
This is a new minor release of `regex` that adds support for start and end
word boundary assertions. That is, `\<` and `\>`. The minimum supported Rust
version has also been raised to 1.65, which was released about one year ago.

The new word boundary assertions are:

* `\<` or `\b{start}`: a Unicode start-of-word boundary (`\W|\A` on the left,
`\w` on the right).
* `\>` or `\b{end}`: a Unicode end-of-word boundary (`\w` on the left, `\W|\z`
on the right)).
* `\b{start-half}`: half of a Unicode start-of-word boundary (`\W|\A` on the
left).
* `\b{end-half}`: half of a Unicode end-of-word boundary (`\W|\z` on the
right).

The `\<` and `\>` are GNU extensions to POSIX regexes. They have been added
to the `regex` crate because they enjoy somewhat broad support in other regex
engines as well (for example, vim). The `\b{start}` and `\b{end}` assertions
are aliases for `\<` and `\>`, respectively.

The `\b{start-half}` and `\b{end-half}` assertions are not found in any
other regex engine (although regex engines with general look-around support
can certainly express them). They were added principally to support the
implementation of word matching in grep programs, where one generally wants to
be a bit more flexible in what is considered a word boundary.

New features:

* [FEATURE #469](https://github.com/rust-lang/regex/issues/469):
Add support for `\<` and `\>` word boundary assertions.
* [FEATURE(regex-automata) #1031](https://github.com/rust-lang/regex/pull/1031):
DFAs now have a `start_state` method that doesn't use an `Input`.

Performance improvements:

* [PERF #1051](https://github.com/rust-lang/regex/pull/1051):
Unicode character class operations have been optimized in `regex-syntax`.
* [PERF #1090](https://github.com/rust-lang/regex/issues/1090):
Make patterns containing lots of literal characters use less memory.

Bug fixes:

* [BUG #1046](https://github.com/rust-lang/regex/issues/1046):
Fix a bug that could result in incorrect match spans when using a Unicode word
boundary and searching non-ASCII strings.
* [BUG(regex-syntax) #1047](https://github.com/rust-lang/regex/issues/1047):
Fix panics that can occur in `Ast->Hir` translation (not reachable from `regex`
crate).
* [BUG(regex-syntax) #1088](https://github.com/rust-lang/regex/issues/1088):
Remove guarantees in the API that connect the `u` flag with a specific HIR
representation.

`regex-automata` breaking change release:

This release includes a `regex-automata 0.4.0` breaking change release, which
was necessary in order to support the new word boundary assertions. For
example, the `Look` enum has new variants and the `LookSet` type now uses `u32`
instead of `u16` to represent a bitset of look-around assertions. These are
overall very minor changes, and most users of `regex-automata` should be able
to move to `0.4` from `0.3` without any changes at all.

`regex-syntax` breaking change release:

This release also includes a `regex-syntax 0.8.0` breaking change release,
which, like `regex-automata`, was necessary in order to support the new word
boundary assertions. This release also includes some changes to the `Ast`
type to reduce heap usage in some cases. If you are using the `Ast` type
directly, your code may require some minor modifications. Otherwise, users of
`regex-syntax 0.7` should be able to migrate to `0.8` without any code changes.

`regex-lite` release:

The `regex-lite 0.1.1` release contains support for the new word boundary
assertions. There are no breaking changes.


1.9.6 (2023-09-30)
==================
This is a patch release that fixes a panic that can occur when the default
regex size limit is increased to a large number.

* [BUG aa4e4c71](https://github.com/rust-lang/regex/commit/aa4e4c7120b0090ce0624e3c42a2ed06dd8b918a):
Fix a bug where computing the maximum haystack length for the bounded
backtracker could result underflow and thus provoke a panic later in a search
due to a broken invariant.


1.9.5 (2023-09-02)
==================
This is a patch release that hopefully mostly fixes a performance bug that
occurs when sharing a regex across multiple threads.

Issue [#934](https://github.com/rust-lang/regex/issues/934)
explains this in more detail. It is [also noted in the crate
documentation](https://docs.rs/regex/latest/regex/#sharing-a-regex-across-threads-can-result-in-contention).
The bug can appear when sharing a regex across multiple threads simultaneously,
as might be the case when using a regex from a `OnceLock`, `lazy_static` or
similar primitive. Usually high contention only results when using many threads
to execute searches on small haystacks.

One can avoid the contention problem entirely through one of two methods.
The first is to use lower level APIs from `regex-automata` that require passing
state explicitly, such as [`meta::Regex::search_with`](https://docs.rs/regex-automata/latest/regex_automata/meta/struct.Regex.html#method.search_with).
The second is to clone a regex and send it to other threads explicitly. This
will not use any additional memory usage compared to sharing the regex. The
only downside of this approach is that it may be less convenient, for example,
it won't work with things like `OnceLock` or `lazy_static` or `once_cell`.

With that said, as of this release, the contention performance problems have
been greatly reduced. This was achieved by changing the free-list so that it
was sharded across threads, and that ensuring each sharded mutex occupies a
single cache line to mitigate false sharing. So while contention may still
impact performance in some cases, it should be a lot better now.

Because of the changes to how the free-list works, please report any issues you
find with this release. That not only includes search time regressions but also
significant regressions in memory usage. Reporting improvements is also welcome
as well! If possible, provide a reproduction.

Bug fixes:

* [BUG #934](https://github.com/rust-lang/regex/issues/934):
Fix a performance bug where high contention on a single regex led to massive
slow downs.


1.9.4 (2023-08-26)
==================
This is a patch release that fixes a bug where `RegexSet::is_match(..)` could
incorrectly return false (even when `RegexSet::matches(..).matched_any()`
returns true).

Bug fixes:

* [BUG #1070](https://github.com/rust-lang/regex/issues/1070):
Fix a bug where a prefilter was incorrectly configured for a `RegexSet`.


1.9.3 (2023-08-05)
==================
This is a patch release that fixes a bug where some searches could result in
incorrect match offsets being reported. It is difficult to characterize the
types of regexes susceptible to this bug. They generally involve patterns
that contain no prefix or suffix literals, but have an inner literal along with
a regex prefix that can conditionally match.

Bug fixes:

* [BUG #1060](https://github.com/rust-lang/regex/issues/1060):
Fix a bug with the reverse inner literal optimization reporting incorrect match
offsets.


1.9.2 (2023-08-05)
==================
This is a patch release that fixes another memory usage regression. This
particular regression occurred only when using a `RegexSet`. In some cases,
much more heap memory (by one or two orders of magnitude) was allocated than in
versions prior to 1.9.0.

Bug fixes:

* [BUG #1059](https://github.com/rust-lang/regex/issues/1059):
Fix a memory usage regression when using a `RegexSet`.


1.9.1 (2023-07-07)
==================
This is a patch release which fixes a memory usage regression. In the regex
1.9 release, one of the internal engines used a more aggressive allocation
strategy than what was done previously. This patch release reverts to the
prior on-demand strategy.

Bug fixes:

* [BUG #1027](https://github.com/rust-lang/regex/issues/1027):
Change the allocation strategy for the backtracker to be less aggressive.


1.9.0 (2023-07-05)
==================
This release marks the end of a [years long rewrite of the regex crate
internals](https://github.com/rust-lang/regex/issues/656). Since this is
such a big release, please report any issues or regressions you find. We would
also love to hear about improvements as well.

In addition to many internal improvements that should hopefully result in
"my regex searches are faster," there have also been a few API additions:

* A new `Captures::extract` method for quickly accessing the substrings
that match each capture group in a regex.
* A new inline flag, `R`, which enables CRLF mode. This makes `.` match any
Unicode scalar value except for `\r` and `\n`, and also makes `(?m:^)` and
`(?m:$)` match after and before both `\r` and `\n`, respectively, but never
between a `\r` and `\n`.
* `RegexBuilder::line_terminator` was added to further customize the line
terminator used by `(?m:^)` and `(?m:$)` to be any arbitrary byte.
* The `std` Cargo feature is now actually optional. That is, the `regex` crate
can be used without the standard library.
* Because `regex 1.9` may make binary size and compile times even worse, a
new experimental crate called `regex-lite` has been published. It prioritizes
binary size and compile times over functionality (like Unicode) and
performance. It shares no code with the `regex` crate.

New features:

* [FEATURE #244](https://github.com/rust-lang/regex/issues/244):
One can opt into CRLF mode via the `R` flag.
e.g., `(?mR:$)` matches just before `\r\n`.
* [FEATURE #259](https://github.com/rust-lang/regex/issues/259):
Multi-pattern searches with offsets can be done with `regex-automata 0.3`.
* [FEATURE #476](https://github.com/rust-lang/regex/issues/476):
`std` is now an optional feature. `regex` may be used with only `alloc`.
* [FEATURE #644](https://github.com/rust-lang/regex/issues/644):
`RegexBuilder::line_terminator` configures how `(?m:^)` and `(?m:$)` behave.
* [FEATURE #675](https://github.com/rust-lang/regex/issues/675):
Anchored search APIs are now available in `regex-automata 0.3`.
* [FEATURE #824](https://github.com/rust-lang/regex/issues/824):
Add new `Captures::extract` method for easier capture group access.
* [FEATURE #961](https://github.com/rust-lang/regex/issues/961):
Add `regex-lite` crate with smaller binary sizes and faster compile times.
* [FEATURE #1022](https://github.com/rust-lang/regex/pull/1022):
Add `TryFrom` implementations for the `Regex` type.

Performance improvements:

* [PERF #68](https://github.com/rust-lang/regex/issues/68):
Added a one-pass DFA engine for faster capture group matching.
* [PERF #510](https://github.com/rust-lang/regex/issues/510):
Inner literals are now used to accelerate searches, e.g., `\w+@\w+` will scan
for `@`.
* [PERF #787](https://github.com/rust-lang/regex/issues/787),
[PERF #891](https://github.com/rust-lang/regex/issues/891):
Makes literal optimizations apply to regexes of the form `\b(foo|bar|quux)\b`.

(There are many more performance improvements as well, but not all of them have
specific issues devoted to them.)

Bug fixes:

* [BUG #429](https://github.com/rust-lang/regex/issues/429):
Fix matching bugs related to `\B` and inconsistencies across internal engines.
* [BUG #517](https://github.com/rust-lang/regex/issues/517):
Fix matching bug with capture groups.
* [BUG #579](https://github.com/rust-lang/regex/issues/579):
Fix matching bug with word boundaries.
* [BUG #779](https://github.com/rust-lang/regex/issues/779):
Fix bug where some regexes like `(re)+` were not equivalent to `(re)(re)*`.
* [BUG #850](https://github.com/rust-lang/regex/issues/850):
Fix matching bug inconsistency between NFA and DFA engines.
* [BUG #921](https://github.com/rust-lang/regex/issues/921):
Fix matching bug where literal extraction got confused by `$`.
* [BUG #976](https://github.com/rust-lang/regex/issues/976):
Add documentation to replacement routines about dealing with fallibility.
* [BUG #1002](https://github.com/rust-lang/regex/issues/1002):
Use corpus rejection in fuzz testing.


1.8.4 (2023-06-05)
==================
This is a patch release that fixes a bug where `(?-u:\B)` was allowed in
Unicode regexes, despite the fact that the current matching engines can report
match offsets between the code units of a single UTF-8 encoded codepoint. That
in turn means that match offsets that split a codepoint could be reported,
which in turn results in panicking when one uses them to slice a `&str`.

This bug occurred in the transition to `regex 1.8` because the underlying
syntactical error that prevented this regex from compiling was intentionally
removed. That's because `(?-u:\B)` will be permitted in Unicode regexes in
`regex 1.9`, but the matching engines will guarantee to never report match
offsets that split a codepoint. When the underlying syntactical error was
removed, no code was added to ensure that `(?-u:\B)` didn't compile in the
`regex 1.8` transition release. This release, `regex 1.8.4`, adds that code
such that `Regex::new(r"(?-u:\B)")` returns to the `regex <1.8` behavior of
not compiling. (A `bytes::Regex` can still of course compile it.)

Bug fixes:

* [BUG #1006](https://github.com/rust-lang/regex/issues/1006):
Fix a bug where `(?-u:\B)` was allowed in Unicode regexes, and in turn could
lead to match offsets that split a codepoint in `&str`.


1.8.3 (2023-05-25)
==================
This is a patch release that fixes a bug where the regex would report a
match at every position even when it shouldn't. This could occur in a very
small subset of regexes, usually an alternation of simple literals that
have particular properties. (See the issue linked below for a more precise
description.)

Bug fixes:

* [BUG #999](https://github.com/rust-lang/regex/issues/999):
Fix a bug where a match at every position is erroneously reported.


1.8.2 (2023-05-22)
==================
This is a patch release that fixes a bug where regex compilation could panic
in debug mode for regexes with large counted repetitions. For example,
`a{2147483516}{2147483416}{5}` resulted in an integer overflow that wrapped
in release mode but panicking in debug mode. Despite the unintended wrapping
arithmetic in release mode, it didn't cause any other logical bugs since the
errant code was for new analysis that wasn't used yet.

Bug fixes:

* [BUG #995](https://github.com/rust-lang/regex/issues/995):
Fix a bug where regex compilation with large counted repetitions could panic.


1.8.1 (2023-04-21)
==================
This is a patch release that fixes a bug where a regex match could be reported
where none was found. Specifically, the bug occurs when a pattern contains some
literal prefixes that could be extracted _and_ an optional word boundary in the
prefix.

Bug fixes:

* [BUG #981](https://github.com/rust-lang/regex/issues/981):
Fix a bug where a word boundary could interact with prefix literal
optimizations and lead to a false positive match.


1.8.0 (2023-04-20)
==================
This is a sizeable release that will be soon followed by another sizeable
release. Both of them will combined close over 40 existing issues and PRs.

This first release, despite its size, essentially represents preparatory work
for the second release, which will be even bigger. Namely, this release:

* Increases the MSRV to Rust 1.60.0, which was released about 1 year ago.
* Upgrades its dependency on `aho-corasick` to the recently released 1.0
version.
* Upgrades its dependency on `regex-syntax` to the simultaneously released
`0.7` version. The changes to `regex-syntax` principally revolve around a
rewrite of its literal extraction code and a number of simplifications and
optimizations to its high-level intermediate representation (HIR).

The second release, which will follow ~shortly after the release above, will
contain a soup-to-nuts rewrite of every regex engine. This will be done by
bringing [`regex-automata`](https://github.com/BurntSushi/regex-automata) into
this repository, and then changing the `regex` crate to be nothing but an API
shim layer on top of `regex-automata`'s API.

These tandem releases are the culmination of about 3
years of on-and-off work that [began in earnest in March
2020](https://github.com/rust-lang/regex/issues/656).

Because of the scale of changes involved in these releases, I would love to
hear about your experience. Especially if you notice undocumented changes in
behavior or performance changes (positive *or* negative).

Most changes in the first release are listed below. For more details, please
see the commit log, which reflects a linear and decently documented history
of all changes.

New features:

* [FEATURE #501](https://github.com/rust-lang/regex/issues/501):
Permit many more characters to be escaped, even if they have no significance.
More specifically, any ASCII character except for `[0-9A-Za-z<>]` can now be
escaped. Also, a new routine, `is_escapeable_character`, has been added to
`regex-syntax` to query whether a character is escapeable or not.
* [FEATURE #547](https://github.com/rust-lang/regex/issues/547):
Add `Regex::captures_at`. This fills a hole in the API, but doesn't otherwise
introduce any new expressive power.
* [FEATURE #595](https://github.com/rust-lang/regex/issues/595):
Capture group names are now Unicode-aware. They can now begin with either a `_`
or any "alphabetic" codepoint. After the first codepoint, subsequent codepoints
can be any sequence of alpha-numeric codepoints, along with `_`, `.`, `[` and
`]`. Note that replacement syntax has not changed.
* [FEATURE #810](https://github.com/rust-lang/regex/issues/810):
Add `Match::is_empty` and `Match::len` APIs.
* [FEATURE #905](https://github.com/rust-lang/regex/issues/905):
Add an `impl Default for RegexSet`, with the default being the empty set.
* [FEATURE #908](https://github.com/rust-lang/regex/issues/908):
A new method, `Regex::static_captures_len`, has been added which returns the
number of capture groups in the pattern if and only if every possible match
always contains the same number of matching groups.
* [FEATURE #955](https://github.com/rust-lang/regex/issues/955):
Named captures can now be written as `(?<name>re)` in addition to
`(?P<name>re)`.
* FEATURE: `regex-syntax` now supports empty character classes.
* FEATURE: `regex-syntax` now has an optional `std` feature. (This will come
to `regex` in the second release.)
* FEATURE: The `Hir` type in `regex-syntax` has had a number of simplifications
made to it.
* FEATURE: `regex-syntax` has support for a new `R` flag for enabling CRLF
mode. This will be supported in `regex` proper in the second release.
* FEATURE: `regex-syntax` now has proper support for "regex that never
matches" via `Hir::fail()`.
* FEATURE: The `hir::literal` module of `regex-syntax` has been completely
re-worked. It now has more documentation, examples and advice.
* FEATURE: The `allow_invalid_utf8` option in `regex-syntax` has been renamed
to `utf8`, and the meaning of the boolean has been flipped.

Performance improvements:

* PERF: The upgrade to `aho-corasick 1.0` may improve performance in some
cases. It's difficult to characterize exactly which patterns this might impact,
but if there are a small number of longish (>= 4 bytes) prefix literals, then
it might be faster than before.

Bug fixes:

* [BUG #514](https://github.com/rust-lang/regex/issues/514):
Improve `Debug` impl for `Match` so that it doesn't show the entire haystack.
* BUGS [#516](https://github.com/rust-lang/regex/issues/516),
[#731](https://github.com/rust-lang/regex/issues/731):
Fix a number of issues with printing `Hir` values as regex patterns.
* [BUG #610](https://github.com/rust-lang/regex/issues/610):
Add explicit example of `foo|bar` in the regex syntax docs.
* [BUG #625](https://github.com/rust-lang/regex/issues/625):
Clarify that `SetMatches::len` does not (regretably) refer to the number of
matches in the set.
* [BUG #660](https://github.com/rust-lang/regex/issues/660):
Clarify "verbose mode" in regex syntax documentation.
* BUG [#738](https://github.com/rust-lang/regex/issues/738),
[#950](https://github.com/rust-lang/regex/issues/950):
Fix `CaptureLocations::get` so that it never panics.
* [BUG #747](https://github.com/rust-lang/regex/issues/747):
Clarify documentation for `Regex::shortest_match`.
* [BUG #835](https://github.com/rust-lang/regex/issues/835):
Fix `\p{Sc}` so that it is equivalent to `\p{Currency_Symbol}`.
* [BUG #846](https://github.com/rust-lang/regex/issues/846):
Add more clarifying documentation to the `CompiledTooBig` error variant.
* [BUG #854](https://github.com/rust-lang/regex/issues/854):
Clarify that `regex::Regex` searches as if the haystack is a sequence of
Unicode scalar values.
* [BUG #884](https://github.com/rust-lang/regex/issues/884):
Replace `__Nonexhaustive` variants with `#[non_exhaustive]` attribute.
* [BUG #893](https://github.com/rust-lang/regex/pull/893):
Optimize case folding since it can get quite slow in some pathological cases.
* [BUG #895](https://github.com/rust-lang/regex/issues/895):
Reject `(?-u:\W)` in `regex::Regex` APIs.
* [BUG #942](https://github.com/rust-lang/regex/issues/942):
Add a missing `void` keyword to indicate "no parameters" in C API.
* [BUG #965](https://github.com/rust-lang/regex/issues/965):
Fix `\p{Lc}` so that it is equivalent to `\p{Cased_Letter}`.
* [BUG #975](https://github.com/rust-lang/regex/issues/975):
Clarify documentation for `\pX` syntax.


1.7.3 (2023-03-24)
==================
This is a small release that fixes a bug in `Regex::shortest_match_at` that
could cause it to panic, even when the offset given is valid.

Bug fixes:

* [BUG #969](https://github.com/rust-lang/regex/issues/969):
  Fix a bug in how the reverse DFA was called for `Regex::shortest_match_at`.


1.7.2 (2023-03-21)
==================
This is a small release that fixes a failing test on FreeBSD.

Bug fixes:

* [BUG #967](https://github.com/rust-lang/regex/issues/967):
  Fix "no stack overflow" test which can fail due to the small stack size.


1.7.1 (2023-01-09)
==================
This release was done principally to try and fix the doc.rs rendering for the
regex crate.

Performance improvements:

* [PERF #930](https://github.com/rust-lang/regex/pull/930):
  Optimize `replacen`. This also applies to `replace`, but not `replace_all`.

Bug fixes:

* [BUG #945](https://github.com/rust-lang/regex/issues/945):
  Maybe fix rustdoc rendering by just bumping a new release?


1.7.0 (2022-11-05)
==================
This release principally includes an upgrade to Unicode 15.

New features:

* [FEATURE #832](https://github.com/rust-lang/regex/issues/916):
  Upgrade to Unicode 15.


1.6.0 (2022-07-05)
==================
This release principally includes an upgrade to Unicode 14.

New features:

* [FEATURE #832](https://github.com/rust-lang/regex/pull/832):
  Clarify that `Captures::len` includes all groups, not just matching groups.
* [FEATURE #857](https://github.com/rust-lang/regex/pull/857):
  Add an `ExactSizeIterator` impl for `SubCaptureMatches`.
* [FEATURE #861](https://github.com/rust-lang/regex/pull/861):
  Improve `RegexSet` documentation examples.
* [FEATURE #877](https://github.com/rust-lang/regex/issues/877):
  Upgrade to Unicode 14.

Bug fixes:

* [BUG #792](https://github.com/rust-lang/regex/issues/792):
  Fix error message rendering bug.


1.5.6 (2022-05-20)
==================
This release includes a few bug fixes, including a bug that produced incorrect
matches when a non-greedy `?` operator was used.

* [BUG #680](https://github.com/rust-lang/regex/issues/680):
  Fixes a bug where `[[:alnum:][:^ascii:]]` dropped `[:alnum:]` from the class.
* [BUG #859](https://github.com/rust-lang/regex/issues/859):
  Fixes a bug where `Hir::is_match_empty` returned `false` for `\b`.
* [BUG #862](https://github.com/rust-lang/regex/issues/862):
  Fixes a bug where 'ab??' matches 'ab' instead of 'a' in 'ab'.


1.5.5 (2022-03-08)
==================
This releases fixes a security bug in the regex compiler. This bug permits a
vector for a denial-of-service attack in cases where the regex being compiled
is untrusted. There are no known problems where the regex is itself trusted,
including in cases of untrusted haystacks.

* [SECURITY #GHSA-m5pq-gvj9-9vr8](https://github.com/rust-lang/regex/security/advisories/GHSA-m5pq-gvj9-9vr8):
  Fixes a bug in the regex compiler where empty sub-expressions subverted the
  existing mitigations in place to enforce a size limit on compiled regexes.
  The Rust Security Response WG published an advisory
sm7ked. Igexes.
  Tsblished an30n compiled atches.

* [SEChub.com/rust-lex/issues,extracted _and_ an optional word boundary in the
pug permitn/regexs/c/NcNNL1Jq7Ywin the here `code-06that produced incorrect
matches whnly when using
===========is rs thst-labTUREle to or examang/ime,
ric co #GHStrus/rust-lan`xplicit`thout the st`\r` adew featur two ludeur 
nt-latwoan30. CIorasick 1.upd://githu=====refixcmatchsome regexeen` includes all groups, not just matching xee=
This rebTUREUG #107xplicit`thout the st`\r` ad in the 3ere `code-01r. This bug permits a
vector for a denial-o=======labTUREle to or es/644):
`Rchangeoint. Ang l`
Hir` typeIt ble maues,exat lot beCIoxes bTUREle trefixccom/rusegex-syigex/issu
rd librarang/regexhsentiast-lbTUREU=====ang/edg
==========chsome regexeverse DFA was called for `Regex::shortest_mat7h_at`.


1.bTUREU has been flipped.o `rege
`Rchangeoint. Ang l`thout the st`\r` ad in the 2ere `code-01r. This bug permits a
vector for reads.

Issue [#934](httpo `re#1047](httpsx bug whereations.ad ied abouttrustation  improvemeentation U hputst wo'sRE #955](hIncreasetion====provs aborust-lang/(#969 used.Use his a sizes, suchBurntS)lly an al/regex/
rd librarne/gith in[PRgexe8n` includes all groups, not just matching x68) 

Bug fi](httasick` to t
subrntbigger.  has pro
[rips co#18n regex syntax documentx` crate to ips cod in turn8n ) in the 1ere `cod4occur when the default
regex size limit is increased to a lar
===========e in thrust-lan`xsue-more doc
hout the stantt`\r` ad in the 0ere `cod4occur when the default
regex ATURE #832]mwheggeupd://sncy on `a2018 (fntbigg)\n`.
*rints dependency
on `aho41er
  Fion `aho28). on `aho41e=====hed.

the matcwo'sRust-lades o\r` y
old

1.8.3s stra'RespoDebim/rus:
Addits of  impre flperfes a ge in some cases. g/re prefixg/reg'Reted batchk`R`, which ps://gitalgoerransg
arfav fixeally i
omatmatm#68](https://gitang/regeting -lan`atmchr.

Thesl#method.search_wiatmchr/2ew wiatmchr/atmatm/i feher thhis
w `regex-s.9.0 (2023g the free-listfist-lanttps://githu,nttpsith thg 00006ilemortleprioritizndcross multiplr not  `_`,boutg 00006ilreport any . Pstory
improvementre es:
3g the free-l If possible,fon to man429):
in th4cludingcod4ocompilation could panic
in debug one prlimit is increased to a lll chanace t'h will-s.e01-023-03- in

ns prior to occurs wu,
butPfixes:

*,lll chanace tsis #429](cs is ub.com/rue may requilan[PERF #1090](https://gi
butNex/ial/regut if tE #955](hunits oinabllled `rttps://githubis re sma):
Add `cause `(es:

*sis #a):
Add modiise
desegenes search fist-

Bein tchsome regOSS-e th#33ord boundarieixes.chromium.org/p/ex a      in turumente?id=33ordat`.
Stps://github=
Thu-langsions prior to sues/eral [BUG formct
in th4c5udingcod3n the number of valid
pc
in debug one prlimit is increased to a la
This is a prify "veill-xeallst-lang
rify "vth4c4r"(?-u:\B)P/issues/104c4,allst-lange====552 [BUG ve alloca104c4
soup-to-nigex/i 856 [BUG elease w):
Fix ma/issues/e allo` returns tollst-lang
r #644]16 [BUG ve alve an i,fy "veill-xeallst-langlease arifyttpsihregexhegex/iy (`A nea wh split ang/regex/commeill-rify "vth4c4r"(?-u:\treacksts tA-Zaes/51ed,ato misholdizndcn debug mode23-01-09)
====s/issues/89idered chsome regex5 also applies to `replace`, but not `replac75 class.
* [B23-01-09)
====s/reaclit y #969]ting i===
Thist-langleill-ng degex/c the hich will
in th4c4udingcod3n 1he number of valid
pc
in debug one prlimit is increased d boundary iny `?` operhub.cr` y-nige welcg/re prehiso miti_7-05l`t(ssuestion perform,59](htgex::nevug )The changeere sFix error message ren36en` includes all groups, not just matching 3 (2022-Mor to  inks #969]ting inw):
Fix ma/a-lang/=========een a fegex-syrrordbug with wor6n` includes all groups, not just matching 57lease A-ladeule ot conegex8](https: `UnwmanSafe/issuesRefUnwmanSafe/entation fo28n` includes all groups, not just matching x491](https:tps://gitG #893]ng/regeassertiVec<u8t fo`Shich  fo`Cow foetc
in th4c3ere `cod1iler. This bug permits a
vectebug one prlimit is increased \>`. Tle to s://gies even w===it
8](https://github.coTle tot connumber oSEChcoff worix error message rendere high contention on a single regex lhing xssivehttps:`F69]trust-lang/ssuesthub.com/rust-lang/regewhich w):
  Fiot coentation fois equivalent to `\p{Currency_Symbol}`.hing xs51](https:tps://git[#516](httpwhichoSEChcoff iot coenn th4c2ere `0nicod1he number of valid
pc
in debug one pr `?` op is increased brn r`\P{men}`y inte `(es:

*sbrn/862ce a 
://gi
bb.com/r[^\w\W]lang/retps:ef look-\P{men}`xcmatce allocafut thasiecrossprovng com` featurill comentation fo2ring bug.


1.5.6 (2022-05-20)
===============2(2022-B//gi\P{men}`x sizs to ========ack in cases where the Fs andng OSS-F   enn th4c1ere `0ni0ni3he number of valid
pc
in debug one pr `?` op is increased ctively\p{ces w ludutPfixes:

*,lWith -25)improve"g fixesyok-around "ub.comthem). `cf`debug 69):
 abbfixeall releasode
sFe frt`incipallyex/ig46):
Ftation fo1verse DFA was called for `Regex::shortest_mat71BUG #862](ht

* [BUG #6`(?-u:\By\p{ces w
  Fi ludxes a bug4 0ere `0ni0ni1r. This bug permits a
vector for a ase.)reedyo migr is a small relo a lases fora. Tle te to `0.4`
 substrings
tliteraendenremundarUG on `aho28thub.cow split ang/rode regFEATUREtimizatio sizt  inst on `aho41c1eover a ge in some cases. \>`. The minimum OSS-F   e Kudoures:[@DaregKorczynskierse DFA was called fDaregKorczynski) Incrdoregexhsens vo  iftithub.com/at!2):
  Clarify that `Captures:649ator` configures how `(?m:^)` and `(?m:$)` behdat`.
She mini`[ fo`]g/ssues.`/githu`
or any "alphabesearch APIs areub.com/rust-lang/regex/issues/891):
Makes liteeubivehttps:`ng/regex/i#6`egex/isb.cohich fixes arch APIs areu9ator` configures how `(?m:^)` and `(?m:$)` be89hub.com/https: `Caddi`x/pull/861):
  Improve `RegexSet` docu715erse DFA was called for `Regex::shortest_mat7151](https:`regex/it-lad it ssues/lang/regex/trusttatic` oc
Improve `Debug` impl fo69nator` configures how `(?m:^)` and `(?m:$)` be94at`.


1.====om/rust- is a s#893]n::ssues/945egend/entation f69e for faster capture group matching.
* [PERF #98ups.
* [FEATUearc- is as releasetch release wtps://github.entation fo1th printing `Hir` values as regex patterns.
* 11ups.
* [FEATU`ust-lang`Uearc-ang/regex/is/rust-la=
Th:^)` and
//githubues/104 a bug3.9ere `0n bug8r. This bug permits a
vector for reads.

Ienden(Med abouShe minion `aVf its )
This is a prify "bug3.8r"(?-u:\B)ed aboutlot beug3.8rwhere temeenon `aho28-nige d librar](https:
a):
Add od}` asseon `alang/reg/regex_auton `aho39Improve `Debug` impl fo68:len` does not (regretably) refer to the numbe851](htepresen about `ear_hangps:.

Thes,========
Tnport eature ):
Mulon `aho43 a bug3.8ere `0n bug8r. This bug permits a
vector for rd boundarar
=uust-lanhttmin](ht `?` oper drissu
byrt any iThe minimum regex-sublimit on comn  improveses `u32`
inste//github.com/rb|hub.com/rust-lang/ Maj.com/ankures:[@sliquinearlen` does not (regretsliquinear)imum 8](https://gie

1.9.6 (2023isg
ar[#67` impl for `SubCaptureMatches`.
* [FEATURE 67`):
Fix a bug where a pre52 it can get quite slow in some pathological52 1](https:no/isb.cthub.com/rust-ls is as/9/rust-lanregex-sU hasx` causeere a pre52`Match` so that it doesn't show the entire hay2sivehttps:The minimum regexsize limit on coator was useregexsue linked b `SetMatches::is_match_empty` returned `false` for `\b`.
*6[BUG #862]h:^)` aas mig69]ting inwregexsize limit on cetps
==========chsbug3.7ere `0n 4-17r. This bug permits a
vector for rd boundararone pr `?` op ased to a lang/rr suppomumwen ixg/reg
hout thaction code and a nce alption.)

But 1 yewt-lade/regere
========== in tsome minor mprove `Debug` impl fo66s equivalent to `\p{Currency_Symbol}`.hing 665UG #862]hhout themumwen regexion code and a nchsbug3.6ere `0n :shortest_match_at` that
couldor for rd boundararoiz:
Add(~30%)devoted to them.)

Bug fsetch  [BUG #10tsome dxedgithub=
Thi co)

Bulimit on cox/issues/68):
Added a one-pass DFA enginr` impl for `SubCaptureMatches`.
* [FEATURE 6861](htIm.)

Bug fsevoted to thng/reed in Unb=
Thi co)

Bulimit on cox/ibug3.5ere `0n :s12rtest_match_at` that
couldor for rupd://sncefixg/reg/issues/792):332):
  Clarify that `Captures:653 impl for `SubCaptureMatches`.
* [FEATURE 683t-lang/d:// `regex-syntax` priues/792):332)bug3.4ere `0n 1occur when the default
regex size one pr `?` op is increased denial-o====tps://githuyour eop upgra
eleas.` match any)ed about ):
Multive pox, occurs w.com/ru(?i)a)bhat  -25):^)` a`aB` between the code units`b`=een a fegort erust-la #895]ndaex::nevy
otherove `Debug` impl fo64lnum:][:^ascii:]]` dropped `[:alnum:]` from th40at`.


1.bT==tps://githuyour eop upgra eleas.` match any2)bug3.3ere `0n 1odoc.rs rendering for the
regsize one prmundregree-l I increased u` versiong/reg changes to
so miti_7-05l`tse:

This rxionxactliteramed abou now has pon `alang/renremunda
UG on `aho28y2)bug3.2ere `0n 1odoc.rs rendering for the
regsize one prmundregree-l I incre//githome en r rdlThe upgn`.
*r?` operh2):
  Clarify that `Captures:6ith printing `Hir` values as regex patterns.
*6311](https:/es/905):
rssuem/rust-laastomiERF </905)>://gitssuem/8](h:
Fix a bug where a pre52rs to be escaped, even if they have no signifi21ups.
*//giths `/-/. a pan("a", 2)nor cha2023-`["a"]`es fixes a s`["a", ""]`eere a pre59re high contention on a single regex lhing 594at`.
om/rust-e in this is a petch lperfesBy\p\/entation f6trategy for the backtracker to be less aggress627ups.
*//giths `/-/. a pa("a-")nor cha2023-`["a", ""]`es fixes a s`["a"]`eere a pre633 impl for `SubCaptureMatches`.
* [FEATURE 633t-lanSquashreg git=======arn thisb.com/russtd::e in ::E in ::ssues/999):m/rust-ly2)bug3.1ere 19es a the number of valid
pc
in debug mundregree-l I incre//gitno the commit s some chnts: ch lud`regex-
a [earch_wied witaggre impl for `SubCaptureMatches`.
earch_witernal e0 ) in th3 0ere 19es a 3rtest_match_at` that
couldor for r\>`. a seast-ra a sy ing/reg/hout thactBUG #g com` any chantion
sess c/10khich willit-laisomr` y-ni
  Us.9.0 (b.cogivfesBupequent cgex` crate.


(egex_auts/884):
Rnow ha)ell.
un imprATURE #244](hre tharticuernaout thac abldisr` adewng/reg changes tret- is ar suppo c/10kactio longish1xg/reg
(`regex-syntax`)/ MoithubRE #2=====ssues,exesy ing/reg/hout thacust-la
[ound =ack in earcult-in-contention).
The */#g/reg-hout tha) inb.com/rustlot betin debug nedyo migrlang/renreas achievedmed abou now has 
on `alang/ren (2023isng/reg/remundarUG `ho28y0`h2):
  Clarify that `Captures:474eature. `regex` may be used with only `alloc`.4at`.
, and an_The `Hir` tyorasick 1.eg git==-sU hafav fixeatcan be usHir` typ`.
, and an_The `Hir` tyo-syntax`regex 1gex/issues2.ts/t re e t,nd an_The ` by
b /remund se.)
*te.aisb.com/russtdusHir` typ`up names are 83s to be escaped, even if they have no signifi831](https:/e`, whaen bi(https://gig/reg/hout thac c/10kfesByrthub.enn th2.1ere 19es8a 3rtest_match_at` that
couldor for r](httso l propen r rdlThe upy)ed abothat T
shim layer onRE #644]releas if fm `regLicees.
hxesny ctA-Zarformangex 1gon onlite e te-ni
  of ev//gie
itust-lang/(hten `a/rujmct
it Teddy.

Performangex 1gon onata`'s API.

Thes

1.8.3s 644]ptioixeatca(htcy on `regex-syg/regex  [BUG cy on `regex-s'ser in pleasdusize mentatiIncrdmentedult-in-contention)y on `regex-/0.7.6)y o_ `regex-/pleasd/i feher thhiste
can ment-rssues.

Theserasick 1.eg git==-srust-laich gex` crate.

Ngex the hinom/rust  [ementssize mentation, examples and l#method.search_with).
Tes and/0.6.11 clone es and/ment/i feher thhiste
can mcd-ut r`reg changes rasick 1.e/regex,U hafav fixea8](https://gistrat  mortleprerne/giin't work `regex-syntax` A-m5pq
"my rve an i,fy n debuptioixeaes/ergorege(d.
* rtly) effminitpective many more pe
ack in cases ust-lanegex/isr chas o\=ssuesliteral single84):
se anosttatoluas 
5 (2023-0-lang/e to as yse w):
ng/regenedy `?sexamang`R` flag for e effminiis
ric 32]mwh
Ngenevfor e behindcn - ludxesnata`'y on `regex-syg/regyntac memory
bnd st-
lgoerransw.com/Teddy split oases. ng/regexTURE #10k erust- sx/istica
Uof on-lso, aase
svithub.cwen hievedpl

Beit oajoreBuperust-lang/ whig/ssues
years of on-an
g/regsrust-lang/rRE #er ng/regRust escapoprustit==-sU`, which ps://gi

lgoerransw(ght bng deeas userThe Rust84):
soper supp)

* PERF:lplici ng/regRus
ahxesre a impred. IgexeDFAisb.coms where the reyub.co-laxgeneiments ed. e foln th2.0ere 19es7ug that produced incorrect
matches whupd://snr sup'samed abou now has pon `alang/renes/1028-nick` to t
 some casemsee ased 1.0
ve ge in some cases. upd://snr sup'sas/884):
d:/a
tr` andes/12.19):
F th1.9ere 19es7u06that produced incorrect
matches whd boundarar `?` op ased ig69]tir sup'sa====ndes/is r,elease wa
he changes to 
Thunultaneoushe first ex/issue- fixes a re a pre593s to be escaped, even if they have no signifi931](htMo
Bug fixtegsegex--sty bet/issueslease includeshinom/issue- fixes a  th1.8ere 19es7u0ortest_match_at` that
couldor for rd boundarareedyone pr):
Fix marecodeoich e. Ohat wainternal en
g fixwhae thng/(?-uf sizehe first ex/a]ptioixeatca SIMDt84)::
Fix a bug where a pre5ering by just bumping a new release?


1.7.0 (5022-11-om/rustsslease includeshst-langatch relea680):
  Fiisze and compile](https:eere a pre588s to be escaped, even if they have no signifi881](htepresesn about /issue(on `)ogiconze andf Fiot c punns://gittca Teddy.rust-l:eere a pre5ons apply to regexes of the form `\b(foo|bar|q591t-lang/d:// earc- is runns://bngeh/githu1.8.3m/rust-is rs thcauss a  th1.7ere 19es6 doc.rs rendering for the
regex cratedenialAdd reedy=arn thisa la
Thions:hantittpsreg git=====s a  th1.6ere 19es4-16that produced incorrect
matches whnly whe
This is a prit680](httng i= `?` op ( is
 a pre55 This fills a hole in the API, but doesn't oth57))========[BUG #969]
 in cases ust-lan publd `\n`hubRed // loope regex beieasesubrntbigg
[r.  has pagundat  ips coregex syntax documentx` crate to ips cod in turn247) a  th1.5ere 19es4-01r. This bug permits a
vector for reads.

Ing mitir sup'sahe changes ped. Alsot a patcr](httt  `iren
genedegrlang/renhantion
- fixes split ang/x/issuehangeoin==-sU==
This isrify "bed wi.f ol `regex-n a feA-Zarform#96-langy(httpd a malang/rens.e01 split ang
s.e01-.

Peisr` adpiling was in`rssdsyg/regyA-m5pq-aded rise======
This
he changes ped. Alsot a r mprove `Debug` impl fo570n` includes all groups, not just matching 570at`.


1.tion
- fixesttpd a malang/re a  th1.4ere 19es3-31r. This bug permits a
vector for reads.

Inleawen ixgd. ot orpus 
This is a patcMulo or es10):

d.
*egrUnwmanSafe `regex-as #969]ting t difficult to haracterize e0.7-nico9]
AhoCterize eot c icode-m5pq-c meUnwmanSafe `regexrasick 1.0rord ex/aaracterize 
0.7.4-nick` tocom/rut  `ire mprove `Debug` impl fo5e8n` includes all groups, not just matching 568at`.


1.7e the
This is a patcMulo or es10):
 d.
*egrUnwmanSafe a  th1.3ere 19es3-30r. This bug permits a
vector for a denial-oeedy `?as been d.

Issue [#934](em.)

Bug fsetch atch an
. Both rust-ue linked belowps://gitx/issues/68):
Added a one-pass DFOPTfo5e6n` includes all groups, not just matching 56lease principsncy on `regex-synta0.7s bee1.8` ie_charat not al...ll of`es.
  TsblFix a bug where a pre52 This fills a hole in the API, but doesn't oth27at`.


1.7.2 (2.

* [SECUptis to that fixessues bytes) p.com/ru(?x))`eere a pre5e written as `(?<name>re)` in addition to
`(?P555at`.


1.7.2 (2.

* [SECUptis to that fixessues bytes) p.com/ru?m){1,1}`eere a pre5e This fills a hole in the API, but doesn't oth57)t`.


1.7.2 (2.

* [* FEATURE:ed chais a sizn=====
Thishat will be 1.2ere 19es2-27r. This bug permits a
vector for reads.

Ing mound =ack in co #Git680](httacke 1.1blFix a bug where a predf45e6fThis fills a hole in the API, but doehanges/edf45e6fat`.


1.bT==Git680](httack========suf(https://gi.rust-l:-rify "vth1c1ever
match be 1.1ere 19es2-27r. This bug permits a
vect #967](https://giths/644):n co #trusteas mig69]ting here are many more peblFix a bug where a pr661bf53dThis fills a hole in the API, but doehanges/661bf53d the
  existing mitigation======suf(https://gi. many more p `regex-as subrntbigg
 contains s  [agundat  ips coregex syntax documentx` crate to ips cod in turn203) a  th1.0ere 18nicoccur when the default
regex size one prs://giths/644ar
=uust-one prenhan/regexse ge in some cases.Etimizatisievedmed aalu now has pon `alang/ren(ende)nes/1024c1eron on1020.0)ce a
(cs rd8):
Ast-langfixg/reg'Reendenpolicout 1 year ago.
*rints depo migrlang/re
https:eeissues/68):
Added a one-pass DFOPTfo51ntation examples.
* [FEATURE #877](https://51n),s  [OPTfo540n` includes all groups, not just matching 540at`.
om/rust-tion====it-lad it /ren (20b=
Thi coues/ets/501):
Permit many more charact38n` includes all groups, not just matching 5381](https:Emojis bee"bizak"as/884):
g fixes:

* BUG [UNICODE.mdThUNICODE.md):
Fix a bug where a pre5s also applies to `replace`, but not `replac5_all`.
tps:s/884):
licees.
(Incrddd ntr` anhisteVa es:
3ot oseara bu `Exa  th0.6ere 18nico06that produced incorrect
masize one prs://giteeissues/68):
Added a one-pass DFOPTfo51 it can get quite slow in some pathological513at`.
om/rust-evoted to thng/reed in Unb=
Thi[PERF #10//gi
bbng 8ni0%:
Fix a bug where a pre5s3s to be escaped, even if they have no signifi33t-lan

1.=eRed /d belowps:/bheykt-lan0//gim/rust-lis iseEU has been flippea0.5`xa  th0.5ere 18ns a 6ur when the default
regex size one prs://giths/644ae the
enhan/regex/501):
Permit many more characte9it can get quite slow in some pathological50BUG #8Ge an iill-rttpwhxeatcan G #893]ng/===itxa  th0.4ere 18ns8egex would report a
match at every](https://github.co*rints dep `icks.e01-he changesxa  th0.3ere 18ns8eg4ur when the default
regex size one pr `?` op is incr:
Fix a bug where a pre50re high contention on a single regex lhing 504at`.


1.Incred wi'Re"tpd a malang/re"u now haeere a pr1e39165fThis fills a hole in the API, but doehanges/1e39165fat`.


1.====om/rustc- is tps:es.
  TsblF th0.2ere 18ns7-18r. This bug permits a
vector for rexpoi
bbhome nedy, suchlow ~shub.conust-lang/rBUG #g com
am is z upgnll-lang/rs beed borol/regexhsel-lang/rs ========aps://gitng
evoted rd ex/at escaincn)

Buway/ Mosm` any chan in cases wttps://han ot
ne/gi Fixesues/9g was isessing `):
  Clarify that `Captures:4e it can get quite slow in some pathological4931](https:/efedy, suchlow ~shub.ctrustm is z upgnll-lang/rs beeplr no-laninc siz(htrust-lang:
Fix a bug where a pr3981d2adThis fills a hole in the API, but doehanges/3981d2adups.
*//githauesd://github.com/rust-onust-lanBTURE]n::do that fes_ned_ATUR`eere a pr7ebe4ae0This fills a hole in the API, but doehanges/7ebe4ae0ups.
*//githauesd://github.com/rust-onusPtis t:: the meaning of the rify "b  `regex-syntax` g/regexre a pr24c7770bThis fills a hole in the API, but doehanges/24c7770bat`.


1.7.2 (2023 in HIRst-lan to enforWith -25ssueha
This isregex-/rusa`.
ly, any ASCinure. (This will comeF th0.1ere 18ns6-19that produced incorrect
matches whupincipsnr sup'sas/884):
tr` andes/ues/792):1

1.8.`\r` as SIMD==============
Tof on-lso, ameenon `aus:
Add(1027 ub.comer) `):
  Clarify that `Captures:486n` includes all groups, not just matching 486hub.com/https: `will_lant`-onust-lanegex/rust-  w):
  Fesearch APIs ar488n` includes all groups, not just matching 488t-lang/d:// s/884):
tr` andtrusues/792):1search APIs ar490it can get quite slow in some pathological490ups.
SIMDt=============
T.com/ru`\r` ad
Tof on-lso, amienon `aus:
Aduttruslang/regs.
1027  bee1phub.g
===========ileas. untout thacne/githtax` e0. CPUu now has.
SIMDtisahete](httTof on-lso, amust-un imp:
Fix a bug where a pre482n` includes all groups, not just matching 48(2022-P relea.7.2 any i
===========e in thrust-lan` an_The `Hir` tyoiissues/99meF th0.0ere 18nde-01r. This bug permits a
vector for r/githuy "vth0tor for rhantion
meFWot betin dtches when a non-y iny izakRust8he com, mosm` any chanoRE]nslang/regshan in cases librwh
Neen a f`. N5](huoust-/regyntath0tng h rusy principay "blang/renhttps:eiterahttmin](htthe comm fasts  of ev whereW r\>=== on `aho20sts exesy inmed abou now has plang/renhanon `a483416}{5ex  Wcases. tcom/ruvleyub>=== anpolico/rBUG #g coms principay "dmed abou now has 
 plang/renhanon `ainyo migrlang/renreas ac chantion
ang/regerlimit is incrsblisheust-srust-la rermctuse temlanasiecdtac mewhicis ist-laisom principay "b dmed aboulang/renhanon `athtax`ay izakRust8he coang/reb>=== ant-laervs, pl(htrhae tha lar
===romiatchesOctalu lippeaitir s)

Bulimit on co rasick 1.eisr` adpiyregex/ise ge i(ht#g coms p any ilease includesh/rust-bRE #` any cased brckust-l oc
mm faex/
  ava===bdd mOctalu lippeaust-lanre-`\r` ad
9](htl charratchegRustbooleanonb  `t-lanBTURE]n`eereffsets thati0):
 d.
*egrit a codepoint in `&str`.
//github.com/r========e hin69):
 UTF-8t84):
ud /x bug where.effsets bhati0)ust-lait a codepoint in 
 con
  Tsblte
can ERF <clone es and::E in >g/regex

Performangex 1essive ped tigger.reses
 cber oSEChcohe changes to `regex-syntax`blte
numbeHir` ty,nd an_The f and only if eve1.8.`\r` adpiyregex/ise Disr`  the h in cir` tyo-syntThions:ex/at
===========e in ce allocafut thasrefix ay(ht#g com undes/The mini`no_The `environone-p (w/nd thec`):ex/atnleawen i`.
ld. ot oleprasxa ently docubRE #2=====s01](iscu on cs search see
[th0tor for rleveksents preeature. `regex` may be used with only `alloc`57) a  0h2.11ere 18nde-01r. This bug permits 
regex ATURE #832]mwhegged boundar `?` operhuStps:ease, deThiicati `?as enfo
SECUptis to that fixes a :
  Clarify that `Captures:459it can get quite slow in some pathological4[BUG #8In a no C++'sRus even wcases librwh
Ns01]Boosm'swcases librwh
Nrify "b  bngeh/git ane ofsy integex8n a no D/libphobosruC++/TheruC++/boosm, On/rusuma,s  PCRE1

PCRE2, RE2Ns01]Tcl2023 in ane ofsy
Fix a bug where a pre4ering by just bumping a new release?


1.7.0 (4022-11-* [FEATUs somexea8regepsnr ues/862byithub.com/rust-  w):
  Feere a pre46ns apply to regexes of the form `\b(foo|bar|q4ithub.com/rust-lease includeshmum 8n69):
 //github.com/r[\d-a]`eere a pre464eature. `regex` may be used with only `alloc`64at`.


1.7.2 (2023 in lease includesmitttyst-lan tofixes:

* [ wasn't fixesshrus
  a cases whboundeve1tps://gi.`\n`ure. (Thiseere a pre46ring by just bumping a new release?


1.7.0 (465at`.


1.7.======ack in ptis toxhegex/imig69]ting ipusylease atch relea680):
  Fe h oeffsileas)`eere a pre466ing by just bumping a new release?


1.7.0 (466)t`.


1.7.2 (2.

* [`\pCglease otere
=gnilld se.)
*te.aisb.coy\p{Oght }`eere a pre470n` includes all groups, not just matching 470at`.


1.7.2 (2.

* [ps://gi.884](httpis #y docx/issuesenhecncluh
Ntrustgeh dod
 con
  Tsbl  0h2.10ere 18nd3-16that produced incorr
regex ATURE #832]mwheggeupd://sncin cases wttps:to the commbling hasstd::4](h`y (`nt-latwoan30.a :
  Clarify that `Captures:458n` includes all groups, not just matching 458at`.
, and* FEATURE: `regex-syntax` harelease.)st-lan tbl  0h2.9ere 18nd3-12that produced incorrect
matches whent680](hbug nedynt-latwoge
`RHir` ty,nd nus:
Ad`-nick` t`\r` as
SIMDt=============
trustation  ot conhantion
erhub.bstrings
alma):
Add `imp
boolea=
T.comecncluh
:

* PERF:cases wttps://hanTof on-lso, ameh o was i
b/issCPUuaout thac st-un `imp. A la
Thions,om/russime `(nt-latwoge
`)xg/reg
eg changes rasick 1.e/regex.a :
  Clarify that `Captures:456n` includes all groups, not just matching 456at`.
, ancases wttps:egex8n a nos AVX2t=============
character clas3 in lxn](hs.
SSSE3. many more p 
Fix a bug where a pre455n` includes all groups, not just matching 455at`.


1.7.2 (2.

* [`(?x)[ / - 9):
ng/edgps://ratch b0h2.8ere 18nd3-12that produced incorreix agbug where a pre454n` includes all groups, not just matching 454at`.


1.7.2 (2023 in  of tsory
ss.e01om pes/908o.bsgg5):
Capch b0h2.7ere 18nd3-07that produced incorrect
matches when a non-grgegex--upta`](https:/ERF:cases flippea
Thes,=======ras
ck 1.i1.egveloptps: trus09)
-gred 1.
731 :
  Clarify that Eease includeshmum 8n69):
 //githubeA-Zarformg5)as isrm/rust1esYourust-s ise
  aof on-lso, a;on todossuene/githtdsiznyihregce alracter clas3p any 
  RE #2= Rus,slease includeshs/han ow//github. y #9hanues,exes about look
  aegex-(hre thcases th0t
matches wdut 1 yewt-laesegen- is trckust-l oc
mm i`.
s fomed
tull:The minimum lan tsecgex-syhere-l oc


* Psymmehiciyhere-l oc

of`.
ly, any As://gi
butT isesust-lan69]ti9](htl c`&& fo`--g/ssues~~` binuh
`.
80):
  Fang/reinurill come
tAoint in `Low ~s1xccomE #2=68](https://gitalowp\p{..}`ure. (This will come.
,  this.com/r\p{scx:* Fa} fo`\p{ude:3.2}`u.coy\p{Che com_re t_
Cla(htted}`e.
 ow/ ludutA-lag fixesyok/regssue `__N*te.aiomm fas now has :

* Pg fixes:


  aeh sele](htt9](hl o wa7):
  Ad. e.g.fo`\p{Greek}ati0)-lang/reg i`.
`\p{G r E e K}`blte
numbe`UNICODE.mdx/issues/8 or not.
* [FEATURetin dtclayer onRttrat  /893):
Optlis is a sm. The minimum UTS#18blteEe a size limit on comT.com/ru#g com=-sU hamosm`#893]butT ust-sru`()+ati0e.
 ow/g 69):
 16}{5exte
emsee FEATUihregeex/issue- fixes#644]reURE:exwhaetrincipalas/9hub.com/rus(ht#g mE # upgn`alysiim/rust-l `iren ad it u/gi.8reit /ree ge in s0](hbuERF:cisk
  ut /i anyang/regetir s)

Bulimit on c #969 used.23-01-09)
====search APIs ar174eature. `regex` may be used with only `alloc1.4at`.
, andAstEATURE: `regex-syntax` hareled boundarypn`hubRE #2====search APIs ar42`Match` so that it doesn't show the entire ha42sivehtShe mini`\u fo`\u{...} fo`\Ug/ssues\U{...} u lippeab.coTed. AyRust84):
 `[` an .` match )

Bulimit on csearch APIs ar449it can get quite slow in some pathological4491](https:an G #893]::by_ustg/sdaphis b.co about /issu893]nd compile:exwu# upgitxa ix a bug where a pre4e6ing by just bumping a new release?


1.7.0 (446at`.
Wanre-`\r` auERF:Boyer-Moo* [ps://gi.rust-l:ee b0h2.6ere 18n02iler. This bug permits aix a bug where a pre4e6ing by just bumping a new release?


1.7.0 (446at`.
  existing mitigatiumbeBoyer-Moo* [884](htrm/rust-lionss.` matrust- is rs tex  Wca op asgex being tettmiwheggedisr`  theBoyer-Moo* ee b0h2.5ere 17-12occur when the default
rix a bug where a pre43 This fills a hole in the API, but doesn't ot43 at`.
  existing mitigatiumbeBoyer-Moo* [884](htrm/rust-lionss.` matfixes a b0h2.4ere 17-12occur when the default
r:
  Clarify that `Captures:348n` includes all groups, not just matching 348at`.
om/rust-evoted to thb.coms`
or a884](http===s0eh dod416}{5ex  (C borase fting @euesepng/erhubo kn lud!)earch APIs ar419it can get quite slow in some pathological41BUG #8Expssueps://gi.884](hregexio8n a no TudeveBoyer-Moo* [issues/8cncrsblis(C borase fting @euesepng/erhubo kn lud!)erix a bug where a pit can get quite slow in some pathological436at`.
, ancases wanace tspluginx

Performangex 1eere a pit can get quite slow in some pathological436at`.
ssime `

PerformprinEATURe`0h2.1`-nick` teads.

Ion `ant-latwobTUREUe in cere a pit can get quite slow in some pathological436at`.
Brcipay "dbngeh/git ane ofslAddthtdregex/b0h2.3ere 17-11occur when the default
r:
  Clarify that `Captures:374n` includes all groups, not just matching 37sivehttps:`regexERF </905)>://gi&whigsearch APIs ar380n` includes all groups, not just matching 3e classDeriss `Caddi`xssuesPtionalEq`-onusEeasegsearch APIs ar400n` includes all groups, not just matching 400t-lang/d:// es/ues/792):0 sFix error message ren3r `\pX` syntax.


1.7.3 (2023-03-24)
=========375at`.


1.7.2 (2[BUG #6`(?-u:\By "dbgex-ftin-01levekis bn onag conkedng:
sage ren393s to be escaped, even if they have no signif393),s  [e ren394s to be escaped, even if they have no signif394at`.


1.bT==g/regem/rust-l/rust-lsimum regexshat fesex/b0h2.2ere 17- bug1ur when the default
r:
  Clarify that `Captures:34ns apply to regexes of the form `\b(foo|bar|q34nivehtShe mini of -sU=e. (This will cou1.8.3an tsecgex-
80):
 n cse es ` 32`
inste`[\p{Greek}&&\pL]`=
This reex/ik l any ou1.8`.
s[[0-9]&&[^4]]`=
This reFEATU deg a madigom` xcepni`4`blis(Muernm/ankures @robndat-nicoed borase ftiasgexaweues/8Hir` typ)sFix error message ren32rs to be escaped, even if they have no signif321ups.


1.bT==Gieps://gi.exleve=====s01]UTF-8tdegoddng:
sage ren326s to be escaped, even if they have no signif326ivehttps:thub.com/rust-lip=ssues,exes`(?x) relea:
sage ren3s3s to be escaped, even if they have no signif333t-lanSang/strings
almm/rust-es/8 om/rust-69 usecurtwobr93]bu
sage ren3s4s to be escaped, even if they have no signif334at`.


1.bT==ge thcaiica usec FEATUREafd `\nhat willsage ren3s8s to be escaped, even if they have no signif3381](https:om/rust-ased u cou57](https:/ggex/es the
thub.com/rustllsage ren353s to be escaped, even if they have no signif353t-lan

1.thub.com/2 (2[BUG ig69]tirust- is rs t[issues/8cncrsblsage ren354n` includes all groups, not just matching 354at`.


1.======ackptis to  #107(?x) ris a bug sage ren358s to be escaped, even if they have no signif358at`.


1.ps://gi. many more p.bT==g/regthub.comg sage ren359s to be escaped, even if they have no signif35BUG #862]hom/rust-84):
sopREADMEg sage ren36s equivalent to `\p{Currency_Symbol}`.hing 365at`.


1.e offsetrs t_c FEATUR_/github,exesC binddng:
sage ren3" test which can fail due to the small stack s3ze.


1.7.1tps:e0//gim2 (2[BUG ig69]tiatfixes a b0h2.1r when
Ohatmaj.cobT==g/regem/rust-45):
xrasick 1.0rord ad.
* s/644ar
=uust-hanoght 
touer `Exa sage ren31ring bug.


1.5.6 (2022-05-20)
==============31rat`.


1.=== a small releaseNoExpssunor chae-l oc

==
Thishlife imprA. (rusiseere a pre314s to be escaped, even if they have no signif314at`.


1.7.2 (2g/regem/rust-45):
xge thcarust used.rust- st-lang/rregexsis/104 are a pre316s to be escaped, even if they have no signif3elease b.coma:tps://gi izakRust8he cogon onata`'0h2.0` CHANGELOGubld6):
is(st-lanBTURE]n::wanace gleasel oamEATURe`t-lanBTURE]n::bTURE`.)
sage ren324s to be escaped, even if they have no signif32sivehtCeed in Unar suppo c

* [ge
`R-l `ire4):n lang/renhan`atmchr.

Thes a b0h2.0
ault
regex size y inmaj.coor for rhanERF:cases wttps

1.8.3s n`hu](https://gitalows i
[cases th0tRFCs to be escaped, even if they hafcs/blob/manear/texl/1620-gex-syth0.md):
Ws of uor forlease w0h2 reirat-n1.8.3ows ies of untrmaj.cohaystackasiec by
b some casonxacto c
ratwses ` w0h2 hievedmed abou* now has *pon `alang/renis th12 a geies of ua(https://gi** izakRust8he com**ffset0h2 utT iyub.co a pahinom/rwo
ot coe
, aneiratATURE:harratcheglas3pizakRust8he comaitir s)

Bulimit on c
 fixes 
, ansecheglaURE:harratcheglas3pizakRust8he comaitievedff woriizakRust8he coma483416}{5u lippemessaPOSIXU=e. (This will coum/rut  `ire.==u` aubevekiedng:tPfixes:

*,lll cch an
.
s[:now]n:]`o that fi====ts exes`now]n`aPOSIXU=e. (This will utNex/ialfi===

  a lll che. (This will ed boundcipay "dly, any ASC`:now]n:`e
, aneixTURetin `.
ly, cogeit oa abops:/now]n:]]`es fixes. b.com/rustvariasm. .com`.
s[[/now]n:]:/bheykt-lan0os://ease w ludulte
canhe. (This `[`=
n `aalways-lanregex-sU h't woaU=e. (This will ulte
canhe. (ThisSC`& fo`-g/ssues~`=
n `alanregex-sU fementons:ease, de abl conte==-sU==nthe
nevy
otes ` 32`
inste`[&]lan`[\&]lan`[\&\&]lan`[&-&]hub.coay
b /  `ivalg fsetAdd `[&&]huex sllegal. (teramenevfor e  (2023isn
* PERF:p/iss`.
ly, cogeit oang/regex
Inleawen ixgd. ot olprA.-latrustddRust8he (This will (htruregem/rustl)lte
nwtps://github.arelease.ues/792)caus.`\r` adpiyregex/is (.com/evedmundb  `t-lanEATURE)e ge inmern r//github=d. Igexeg/regetps://github::y i`Rttrat  dossueeA-Zaevedues/792)eleasrure c

* [aps:`fset)nor chac09)
-xhsenubrntbib  bn firstworiizakRust8he coma4834ERF:cases ff messa` mang/ssues man_s://.arele**ha2023-`Mlang`U `__Nses fixes a b  `(uwill, uwill)`.**f`Mlang`U `__NseeA-Za`startg/ssuesend//rust-ls-nick` l con2023-evedmust- off/ets/f`Mlang`U `__Nseses. eA-Za//gias_whig/rust-l,s  ick` ton2023 lll ctexlrhanERF:rust-  wm5pq
"te
can 7](httpsEATURE:relege
`Rng/rege Both ngleh w):
  Fi09)
-gex-s](htt the h
This r-nick` t c

* [m/rust- u couhan`s://.assuess://_pos`e
U couhab  `s://_oamEApo c

* [g was in`c FEATU_oamEsm/rust-laonust-lang
"te
can rt`irust-laonutcan 7](httpsEATURE:

PerformanoamEATURe`ggex-n1.8.3te.
 ow/on2023 l/es/905)`e
Sny 

B
*,lll c`oamEm/rust-laonus7](httpsEA ow/on2023 
  a s/905)`e"te
can m/rust-l/rust-lsi ow/on2023o`Cow U `__Ns.e
can 7ow::Barra co`tvariasmn .`snr ues/862ge thnomm/rust-es/8omT.cobline"te
can G #893]ng/===it:

Perform=d. lusitwog9)
hx/i 1essive  c

* [ge
`n .`. oishclis/8om/rust-m/https: 23isn===it:/github. ye
Ss even wu couhab  tcan m/rust-l/rust-lsi c

* [0os://ease w lud un8he cod modin to-m/https:b  tcan G #893]ng/===its search :exwuls,exesy inthub.com/rustllsa
can qu.co`tseet- ex` cra:

PerformanoamEATURe`regex-`e"te
can G hub::g/re_will_sory
m/rust-la

Performangex 1esIt.`snr #893]dpiyb  `t-lanBTURE]n::will_sory
me"te
can G hubBTURE]n`ATURE:

Pesg/rt-la on onow/862`m5pqm/rust-latittivny caob  `&mut m5pqm/rust-latittivny / Mosm` an`regex-sos://ease w lud un8he codang/r(htres/8c792)ca`R-l `ire4oam upgn`.3an tmEAi:// varia5](huouholdifi](htURE]ne"te
can wanace glrust-laonust-lanBTURE]n`A

PerformanoamEATURe`bTURE`."te
canseet-`ust-lang`U ex` cra:

Performangex 1esIt.`snr #893]dpiy  [BUG #10t allst-langl beedal/regeoms `ust-lang`Urust-ly2te
can PtionalEq`-ssuestq](httpwhonust-lang/eA-Zarforme/regex.modin to soiod
 conutcasl-rttpw,k in co #Git oa-uf siallwrsegeFiot c aegex-ust-lang,-rttpb  `Deustg/oan al
* Pg fregexexesy cncluh
Nrttpwy2te
can ng/regex/irust-laonus7](httpsEA

Performangex 1essive always-on2023 
  `fsesd`-nsoeoms matcw. The)
==us:
y2te
can Stax` havariasmhxeatcan EeasegATURE:reled boundararohich ps fixes a b  anar sup es and::E in `.modin towies 32`
ndcipa lippeae in s#y docclosaboub  n t'han e/githt/github. y g was in`r sup es andsyg/regyntare-fi====ERF:casesy2te
can In69):
egex/variasmhxeatcan EeasegATURE:

Performangex 1g/github.ci0e.
 o d.
*egra bug saMosm`xeatcan w):
  Fiot coctA-ZarformanoamEATURerust- ttaticngs
tliodin t`.
s rt-69 usetcasl-rw):
  Fiot coc/github. ys search :exwuls,exesthub.com/rust
  RE eoms nedynamp. s ` 32`
inste`thub.ca pas`A

PerformanoamEATURe`ca pa`xa A(https://gi `?astA-Zarform0rordmessage ren15rs to be escaped, even if they have no signif15rat`.
, andG #893]ng/===it:

Perform=he cod rovng com`y "dlal//isr cd borolb  all-lang/r are a pre16ring by just bumping a new release?


1.7.0 (1651](htepresentcanseet-`ust-lang`U ex` cra are a pre166ing by just bumping a new release?


1.7.0 (166UG #8Expo-langsioknobs (ava===bddffset0h1p)

* Pangex  `g/re_will_sory
m are a pre168ing by just bumping a new release?


1.7.0 (168at`.
ow):
  FePg f0](httng s7](httpsEA ow/eA-Zaeved==
Thishlife imprA. (rusissblsage ren1r `\pX` syntax.


1.7.3 (2023-03-24)
=========175at`.


1.7.==
ner #895]ndk in ptis upgra POSIXU=e. (This will coblsage ren1r8ing by just bumping a new release?


1.7.0 (178at`.
D/reatcan PtionalEq`-ssuestq](httpwhonust-langblsage ren1r9ing by just bumping a new release?


1.7.0 (1791](htepresen ng/regex/ise:

T7](httpsEA/github.calways-on2023  fsesdblsage ren276ing by just bumping a new release?


1.7.0 (27lease PayergitalowoamEATms`
or aust-egex-syrehicex 1gon onl
T7](httpsEblsage ren296ing by just bumping a new release?


1.7.0 (2961](htepresenwntbpi/ke
nel32-sysohe changes to UNIX are a pre30 test which can fail due to the small stack s30e.


1.7.1lease ===emues/99en a b0h1.80
ault
=s DFARen292n` includes all groups, not just matching 292UG #862](ht

* n291-nick` to tprit680](httng ARen290 sF0h1.79
ault
=s DRl `ire4 been flippea0.3.8 sF0h1.78
ault
=s DFARen290n` includes all groups, not just matching 290UG #862](ht

* n289,========
69]tires/8//githubs/644ar
ation  roubin/rust
  lowps://gitTURerust- ====
This aase0h1.77
ault
=s DFARen28ntation examples.
* [FEATURE #877](https://28nUG #862](ht

* n280tng disr`  thegex-here are many more pesetch at bytes)n .`snptional amu0eh dodase0h1.76
ault
=s DTweakyg/ere ia b.co acipay "dTeddy.ps://gi.rust-l:ee 0h1.75
ault
=s DFARen27s equivalent to `\p{Currency_Symbol}`.hing 2722-11-om/rustssrust- vny Alsot a pssue [#934](eittca Teddy.SIMDt884](htr.s DFARen278 equivalent to `\p{Currency_Symbol}`.hing 2781](htep#893]b slgex`, which ploop(eittca Teddy.SIMDt884](htrbs/644Aho-Cterize .s Dom/https:exeD=u` aEx-ftIw):
  Fi0ni coues/et/rust-  w):
  Fese 0h1.74
ault
=s DRlearch  been flippea0.3.5bs/644aro migr `?` opmed
t
1.e ofn272med
t
1.e ofn277.s DFARen270n` includes all groups, not just matching 270UG #862](ht

*sen264,en268s beenThunulw has p.

* [SECU===itac ansillit- a f`.t  deri-lso, amex-f` 3i-lm==-sU haues/8cncrs (ais regexiohighmexaxge](httmpreh
`.
ulude)se 0h1.73
ault
=s DRlearch ` been flippea0.3.4EblsaBumpregex-syntax` hahe changes lang/ren (20ar suppoURe`0h3.4Ebl 0h1.72
ault
=s DFARen262n` includes all groups, not just matching 262at`.
  existihttps://gione pr `?sm#96-langy(fuzzet/isrege(AFL)se 0h1.71
ault
=s DFARen236n` includes all groups, not just matching 236at`.


1.7.2 (2023hgex`,f(https://gisowies 32leve=-srus======[BUG ais e h oe8n69):
 :^)` aae first ex/some minor mp0h1.70
ault
=s DFARen23ntation examples.
* [FEATURE #877](https://2311](https:SIMDtacclear==-sUmulsiplprA.-tes)t884](h.s DFARen228 equivalent to `\p{Currency_Symbol}`.hing 2281](htep):
ng/regegation======suf(https://gi. many more p s DFARen226n` includes all groups, not just matching 226hub.com/https:s N==istregy
===r is a prify "-tion==== s DFARen223n` includes all groups, not just matching 2231](htt(ful amu0eh dod.thub.com/ust-egex c
ra-circuitxa 0h1.69
ault
=s DFARen216n` includes all groups, not just matching 2elease Tweakyll cthr iholdi is runns://b-01levek104 are ARen217n` includes all groups, not just matching 2ebivehttps:now]ntsory
s(on onata`===)nes/ms`
or a884](h
(Incrata`N==) are ARen218 equivalent to `\p{Currency_Symbol}`.hing 2181](https:r ty,na Cdff wor0h1.68
ault
=s DFARen210n` includes all groups, not just matching 210UG #862](d

Issue [#934](e offsettps://github::m/rust-l/.

* [`32lend//o tp69]tn .` fixes a s`32lend_on o_slice` are ARen21ntation examples.
* [FEATURE #877](https://211UG #862](d

Ing mitigatihe dl upgra wordx bug wheremitigati=== s DFARen21 it can get quite slow in some pps://2131](httpsod.tE2Ns01]Tcl2as3 in bngeh/git ane ofsy Aes. if eve1 CLI ut rus 
on ol counns:////github69 usedentofang/rREf ev//gicases ust-las: PCRE1

PCRE2,l cOn/rusuma, RE2, Tcl2s01]ng/reu====on `'snow/con
  Tsbl 0h1.67
ault
=s DFARen20ntation examples.
* [FEATURE #877](https://201ups.


1.(?-uf sizehe first ex/s in`r sup!` wanace tspluginxmacro s DFARen20s equivalent to `\p{Currency_Symbol}`.hing 2051](htMor
Added a one-p2as3===iATURE #244](hCeedh relvths/644RE2* BUG ARefss`.
bngeh/gith s DFARen209 equivalent to `\p{Currency_Symbol}`.hing 2091](htepearch 0h1.66/o tptemlan ====. ot olpr/github.c-l `ired genedegrlang/re
  lowon `atesenpfixes:
 is incrsbssive ARef exis/rus.e(Asues0h1.66//o tb  nankoda)l 0h1.66
ault
=s DSge]uls, pl The minimum Ues/792)wordx bug wheremo tp [FEATURetiti===  ge i(ht c

* [m/resentcanlri-ehang c #9ithub.codisquaflagedo about gati=== s DAn. many more p.ls is =
Tnandf Fi`,f(https://giso
* PERFnerust-la ERF:cas)

Bt  /8=r is a prifon======easel gex 1giling wait:

d)wori-eh9ithquad:
 nc `imp
 m=d. luxus esIt.easel #893]dps/644aroo* [psry
/gi many more p..

* ,ogivch any
 con
  tofang/rRErmn`r $g,-rto-syntax`rust-la rifon======on onata`e01]ng/y "b  hay23-01 s DFARen202n` includes all groups, not just matching 202at`.
, aninner loop(ut gati===.easehefirtwogmany mEATURe3m/rust-tac an7-05l.


 

* Pan/regegatig9)
e prhttps://giilad it /rest-un ===eat-  w):
 /ree ge il cont releask in corsm` an a s`unsafe`
soper supp (tht/legex bug sss.e01s) are ARen200n` includes all groups, not just matching 200t-langabout gati`atmpoolsyg/regy(s=====69]tio mitin7-05listterde).easel #893]d`.
s/644arfanear lang/renhanoth r 

B the
sop@A#24ieu'snso miti_7-05l`tg/regex  Itt c

* [m//reged boicngs
setch 69 used.on
  ton onmulsiplpro mitii(ht imulsanes:

* arePCRE2 JIT/bngeh/githuwies  [FEAy A bngeh/git ==. oris c #9t-lanound s  [

* n` includes st.s all groupanonyms:
/14683c01993e91689f7206a18675901b):
is(In a non-gr==. oris c s/644PCRE1'snJIT/
* POn/rusumal)lte
n2 (2.

* [wordx bug wheremoefaex/ pes/90rust-la #=
This isrify "i===.eas
  R2](dbssive ge
`Raffe](htt an a s`tps://github. are #160ing by just