//! # Overview
//!
//! `once_cell` provides two new cell-like types, [`unsync::OnceCell`] and
//! [`sync::OnceCell`]. A `OnceCell` might store arbitrary non-`Copy` types, can
//! be assigned to at most once and provides direct access to the stored
//! contents. The core API looks *roughly* like this (and there's much more
//! inside, read on!):
//!
//! ```rust,ignore
//! impl<T> OnceCell<T> {
//!     const fn new() -> OnceCell<T> { ... }
//!     fn set(&self, value: T) -> Result<(), T> { ... }
//!     fn get(&self) -> Option<&T> { ... }
//! }
//! ```
//!
//! Note that, like with [`RefCell`] and [`Mutex`], the `set` method requires
//! only a shared reference. Because of the single assignment restriction `get`
//! can return a `&T` instead of `Ref<T>` or `MutexGuard<T>`.
//!
//! The `sync` flavor is thread-safe (that is, implements the [`Sync`] trait),
//! while the `unsync` one is not.
//!
//! [`unsync::OnceCell`]: unsync/struct.OnceCell.html
//! [`sync::OnceCell`]: sync/struct.OnceCell.html
//! [`RefCell`]: https://doc.rust-lang.org/std/cell/struct.RefCell.html
//! [`Mutex`]: https://doc.rust-lang.org/std/sync/struct.Mutex.html
//! [`Sync`]: https://doc.rust-lang.org/std/marker/trait.Sync.html
//!
//! # Recipes
//!
//! `OnceCell` might be useful for a variety of patterns.
//!
//! ## Safe Initialization of Global Data
//!
//! ```rust
//! use std::{env, io};
//!
//! use once_cell::sync::OnceCell;
//!
//! #[derive(Debug)]
//! pub struct Logger {
//!     // ...
//! }
//! static INSTANCE: OnceCell<Logger> = OnceCell::new();
//!
//! impl Logger {
//!     pub fn global() -> &'static Logger {
//!         INSTANCE.get().expect("logger is not initialized")
//!     }
//!
//!     fn from_cli(args: env::Args) -> Result<Logger, std::io::Error> {
//!        // ...
//! #      Ok(Logger {})
//!     }
//! }
//!
//! fn main() {
//!     let logger = Logger::from_cli(env::args()).unwrap();
//!     INSTANCE.set(logger).unwrap();
//!     // use `Logger::global()` from now on
//! }
//! ```
//!
//! ## Lazy Initialized Global Data
//!
//! This is essentially the `lazy_static!` macro, but without a macro.
//!
//! ```rust
//! use std::{sync::Mutex, collections::HashMap};
//!
//! use once_cell::sync::OnceCell;
//!
//! fn global_data() -> &'static Mutex<HashMap<i32, String>> {
//!     static INSTANCE: OnceCell<Mutex<HashMap<i32, String>>> = OnceCell::new();
//!     INSTANCE.get_or_init(|| {
//!         let mut m = HashMap::new();
//!         m.insert(13, "Spica".to_string());
//!         m.insert(74, "Hoyten".to_string());
//!         Mutex::new(m)
//!     })
//! }
//! ```
//!
//! There are also the [`sync::Lazy`] and [`unsync::Lazy`] convenience types to
//! streamline this pattern:
//!
//! ```rust
//! use std::{sync::Mutex, collections::HashMap};
//! use once_cell::sync::Lazy;
//!
//! static GLOBAL_DATA: Lazy<Mutex<HashMap<i32, String>>> = Lazy::new(|| {
//!     let mut m = HashMap::new();
//!     m.insert(13, "Spica".to_string());
//!     m.insert(74, "Hoyten".to_string());
//!     Mutex::new(m)
//! });
//!
//! fn main() {
//!     println!("{:?}", GLOBAL_DATA.lock().unwrap());
//! }
//! ```
//!
//! Note that the variable that holds `Lazy` is declared as `static`, *not*
//! `const`. This is important: using `const` instead compiles, but works wrong.
//!
//! [`sync::Lazy`]: sync/struct.Lazy.html
//! [`unsync::Lazy`]: unsync/struct.Lazy.html
//!
//! ## General purpose lazy evaluation
//!
//! Unlike `lazy_static!`, `Lazy` works with local variables.
//!
//! ```rust
//! use once_cell::unsync::Lazy;
//!
//! fn main() {
//!     let ctx = vec![1, 2, 3];
//!     let thunk = Lazy::new(|| {
//!         ctx.iter().sum::<i32>()
//!     });
//!     assert_eq!(*thunk, 6);
//! }
//! ```
//!
//! If you need a lazy field in a struct, you probably should use `OnceCell`
//! directly, because that will allow you to access `self` during
//! initialization.
//!
//! ```rust
//! use std::{fs, path::PathBuf};
//!
//! use once_cell::unsync::OnceCell;
//!
//! struct Ctx {
//!     config_path: PathBuf,
//!     config: OnceCell<String>,
//! }
//!
//! impl Ctx {
//!     pub fn get_config(&self) -> Result<&str, std::io::Error> {
//!         let cfg = self.config.get_or_try_init(|| {
//!             fs::read_to_string(&self.config_path)
//!         })?;
//!         Ok(cfg.as_str())
//!     }
//! }
//! ```
//!
//! ## Lazily Compiled Regex
//!
//! This is a `regex!` macro which takes a string literal and returns an
//! *expression* that evaluates to a `&'static Regex`:
//!
//! ```
//! macro_rules! regex {
//!     ($re:literal $(,)?) => {{
//!         static RE: once_cell::sync::OnceCell<regex::Regex> = once_cell::sync::OnceCell::new();
//!         RE.get_or_init(|| regex::Regex::new($re).unwrap())
//!     }};
//! }
//! ```
//!
//! This macro can be useful to avoid the "compile regex on every loop
//! iteration" problem.
//!
//! ## Runtime `include_bytes!`
//!
//! The `include_bytes` macro is useful to include test resources, but it slows
//! down test compilation a lot. An alternative is to load the resources at
//! runtime:
//!
//! ```
//! use std::path::Path;
//!
//! use once_cell::sync::OnceCell;
//!
//! pub struct TestResource {
//!     path: &'static str,
//!     cell: OnceCell<Vec<u8>>,
//! }
//!
//! impl TestResource {
//!     pub const fn new(path: &'static str) -> TestResource {
//!         TestResource { path, cell: OnceCell::new() }
//!     }
//!     pub fn bytes(&self) -> &[u8] {
//!         self.cell.get_or_init(|| {
//!             let dir = std::env::var("CARGO_MANIFEST_DIR").unwrap();
//!             let path = Path::new(dir.as_str()).join(self.path);
//!             std::fs::read(&path).unwrap_or_else(|_err| {
//!                 panic!("failed to load test resource: {}", path.display())
//!             })
//!         }).as_slice()
//!     }
//! }
//!
//! static TEST_IMAGE: TestResource = TestResource::new("test_data/lena.png");
//!
//! #[test]
//! fn test_sobel_filter() {
//!     let rgb: &[u8] = TEST_IMAGE.bytes();
//!     // ...
//! # drop(rgb);
//! }
//! ```
//!
//! ## `lateinit`
//!
//! `LateInit` type for delayed initialization. It is reminiscent of Kotlin's
//! `lateinit` keyword and allows construction of cyclic data structures:
//!
//!
//! ```
//! use once_cell::sync::OnceCell;
//!
//! pub struct LateInit<T> { cell: OnceCell<T> }
//!
//! impl<T> LateInit<T> {
//!     pub fn init(&self, value: T) {
//!         assert!(self.cell.set(value).is_ok())
//!     }
//! }
//!
//! impl<T> Default for LateInit<T> {
//!     fn default() -> Self { LateInit { cell: OnceCell::default() } }
//! }
//!
//! impl<T> std::ops::Deref for LateInit<T> {
//!     type Target = T;
//!     fn deref(&self) -> &T {
//!         self.cell.get().unwrap()
//!     }
//! }
//!
//! #[derive(Default)]
//! struct A<'a> {
//!     b: LateInit<&'a B<'a>>,
//! }
//!
//! #[derive(Default)]
//! struct B<'a> {
//!     a: LateInit<&'a A<'a>>
//! }
//!
//!
//! fn build_cycle() {
//!     let a = A::default();
//!     let b = B::default();
//!     a.b.init(&b);
//!     b.a.init(&a);
//!
//!     let _a = &a.b.a.b.a;
//! }
//! ```
//!
//! # Comparison with std
//!
//! |`!Sync` types         | Access Mode            | Drawbacks                                     |
//! |----------------------|------------------------|-----------------------------------------------|
//! |`Cell<T>`             | `T`                    | requires `T: Copy` for `get`                  |
//! |`RefCell<T>`          | `RefMut<T>` / `Ref<T>` | may panic at runtime                          |
//! |`unsync::OnceCell<T>` | `&T`                   | assignable only once                          |
//!
//! |`Sync` types          | Access Mode            | Drawbacks                                     |
//! |----------------------|------------------------|-----------------------------------------------|
//! |`AtomicT`             | `T`                    | works only with certain `Copy` types          |
//! |`Mutex<T>`            | `MutexGuard<T>`        | may deadlock at runtime, may block the thread |
//! |`sync::OnceCell<T>`   | `&T`                   | assignable only once, may block the thread    |
//!
//! Technically, calling `get_or_init` will also cause a panic or a deadlock if
//! it recursively calls itself. However, because the assignment can happen only
//! once, such cases should be more rare than equivalents with `RefCell` and
//! `Mutex`.
//!
//! # Minimum Supported `rustc` Version
//!
//! If only the `std`, `alloc`, or `race` features are enabled, MSRV will be
//! updated conservatively, supporting at least latest 8 versions of the compiler.
//! When using other features, like `parking_lot`, MSRV might be updated more
//! frequently, up to the latest stable. In both cases, increasing MSRV is *not*
//! considered a semveratic RE: once_cell:/sync::OnceCell<T>`   | `r like `pasd Note: thi5fon2! When using other features,    mp//! If only Iormation:
   is m//!sclude test reformation:
   l:/sbmven(4))] /
//! ##//!
//! ````](ml
//!
/guppub    / Recipes
-nmenery///!
-/! ```.rs/)ore arbitra//!
/OnceC](ml
//!
/guppub    /indiv0///!
c.rus)   inisore arbitraring
//   * init]idere    Onces wisync::OnceCeju
//! ::{sync:t Guaruna> {
arbitth `LaAPI;
//!
//! fToeformation| `ror Onnc`] t flaturns `NoneMutex  inisouCelleipdatea cu
/o poi    -formation:
   l flaning
//   * init pdatently, up t:sync::es, but wohis (and rocallebed, MSRently, up toed more
 d::spportebed&a);
//). P   // `Seq the ais notsam Kotlid a semveratbers if
Rently, up toebmven(`le only once,wohis (smstate,bed MSRV 16_or_in.mpile regex on  iniouCell`ssert!`! [`unsync::Ling
//   * init]html
//! [`Sync`]: https://doc.rust-lang.org inie useful for a vF.A.Q! [`unsync**S and
/I cases shror OtlisignabOnnc`] ?** [`unsync
//! canRue resourcte,e to ait),
//     //Kotliyou.val'orks ws       /nsyncaccT>`on:
//!ow younsync/sddr(p the [`Sand arate) .elf.vow younsync/siegex`: a `&T-t),
//rsiondi5fon2the [`San m
//i-t),
//rsword'orE: ySRV sSupchct accetween
struct Wifiondi5ucho    m
//i-t),
//rs*not*r! [`unsyncArs if
motion,younsync/shat Guppinie_or_w5ucnefiy, if ireutex, w{fs, path::PathBuf} callss itself.ctor obstest stabE: o:addrqueue:ny potes to lr, beca! [`unsync**Do   /// R  inionomorphiasync?** [`unsyncNd::{syn!
//e rallsnsync::async_ync::OnceC](ml
//!
/ction rather thanasync_ync::Once)::Lazy`]! [`unsync**Do   /// R  inionomorphi`n    d`?** [`unsyncYstruct.La`    av mos.rns.
//!
//!nd ree fn get_uhBuf} primi//! `or obnsync_r l, wnic or_ireli using `geta `.rns.
//!
//!    , weer bits oed
//! cosnsync`f` least l!(!calledrqesouut   `Release.e enct W/ State  flexgnmBuf} cal!
//! k if
//! it rerom
// `stsingtrucke `pamshat drqc
#[inliunsyncWs encodeundam`on:
//!! When usOSonomorph. ExgnmBuf} envigettion| use//! use slf::ags si`orrqc
#[usingorrm drqpr = st lr, becas due drqpriori//Kintures, `, MSRY
//_ that_ forceondi5drqesou!
//bng `ind//!owncodp     pinythiratbers if
//!
//! uset lhavior/! nd
//! subt `Oml
//! [`unsyncGiven
strse/! ```
   ts,nsync::OnceCell`] and
/chroo//!
 be up!
//!  [`unsync-st resed con with ell`] and
similaratbers::sencctee fn get_uhBuf} primi//! ! # Comhis and p    st     Supporn    d`. Wuppored corence. f` afeCell},
   b ! # Com(!callem
//ire s usesebed&ifion `        ratbersically,_init` wileastwiegex`: test cstle to usy.
    sync-s`c  }

  -s//!
//oed more
 dSuppoa `-orei(ar`_`)ouCell`c  }

  _s//!
//ogex`: test ormation| `geta `. [`unsync**C   I bevalumllywndetect?** [`unsynczy`] cd p[gy_stic_ync::Once](ml
//!
/ction rather thangy_stic_ync::Once)  /nsyncan.
//ju
//bits! [`unsync**S and
/I case:Ling
T> { cturns `Nonesync::OnceC updat//!
//! ````?** [`unsync shoulde rallsSRV wiatures,  (oulre_cell:/sen using 1.70ynchrooulddon'n| usensyncex`
 nservativesync::OnceCell`] and),allsSRV wi. Opdatwis willsSRync::OnceC  syncDon'n|llsSR//!
//! ````.ful for a varlversior tha [`unsync* Mo
    // / R  ini'orafeCell}:Pa//Ki/sev//!Techn    V wia    encodch is
/`: tRue r1.70.elese:Ling
T> { cturns `No5fon2thing
//   * iniLgetC  sync* [douech-e to th-Once](ml
//!
/guppub    /niklasf/douech-e to th-Once) sync* [//!
- it ](ml
//!
/ction rather than//!
- it ) sync* [//!
Once](ml
//!
/ction rather than//!
Once) sync* [mi/ochondria](ml
//!
/ction rather thanmi/ochondria) sync* [//!
//! ```](ml
//!
/ction rather than//!
//! ```) sync* [async_ync::Once](ml
//!
/ction rather thanasync_ync::Once) sync* [gy_stic_ync::Once](ml
//!
/ction rather thangy_stic_ync::Once) (btd::{fs,   oulreywndetect)

#!e() _attr(i(a(d more
 = "hin")rei(   d)]
use stdd more
 = "be
//e_ofex`ernR  iniobe
//;
use std    d more
 = "c  }

  -s//!
//"rei(a(d more
 = "hin"))_of#[!      "    cs.rs"nc::mp   ;
use std    d more
 = "hin", d more
 = "ently, up t")_of#[!      "    pl.rs"nc::mp   ;
use std    d more
 = "hin", i(a(d more
 = "ently, up t")__of#[!      "          "nc::mp   ;
ueqCsta `&T-t),
//rsitures,   flaturns `No.e` fn wiisignabOannel, thr
    #q!(size_ofe, UnwindSafe},
    sync::atomget()mn,ymem::atomget( T;
/{/!   , /!   yncc::atomget(ic::{AtomicBool, AtomicPtr, Ordering},
 <T> {
  g threto_innis an loop
/ E>(ten
sonically, cword andi(art),
//     must ensure that tiables.[:Ling
T> { cct.RefCel,B, which fillsll`] and
simre s`&`re that tction `geroughly* and thereust ensure that t[:Ling
T> { cct.RefCell.html
//! [`Mutex`]: https://doc.rust-lang.org/std/sync/st ensure that theExamre re that t type that tx {
//!     config_path: PathBuf,st ensure that t     o_infalse;

        let (txat tens, we se(Default));
             nsure that t    e).is_o&et_con|| {::env::var("CARGO_MANe that ttttt"H::ed::World!//! fn main()Ne that t}let (txat tens, w a la that i"H::ed::World!/let (txat tens, we se(Default));
             nsut type th/! impl<T> e() -> T) {
          be "anc::Lg.
/ E>(ten
sonred
//! cont.  }

    //_stSend`?
// Thread A create the wrapped stamilarlys! regeawbackbolf:sing`RefCell`]: http, called us re thats`&! [`sync::OnceCelSRV sneakregeT`rt),     `
        });`get to Iebedpath::Pat[test]
 ) -> OnR lo
    fon2ex`
 c#[test]
  statehe stare thats`    ee statfor OnceCell<T> {}
impl<T: UnwindSafe> UnwindSafe for OnceCell<T> {}
statfor Once OnceCell<T> {
    pub(crate) const fn new(: impl FnOncSelf { LateIe() -> T) {
            eault() } }
//! }
//= unsafe { f.te tes    l{
        static O: Onfor Once)mn
//!bug>e)mn
//!bugLateIe() -> T) {
            e)mnVoid {}
        )mn
/F celle) & ->e)mn
/ = sel//= unsafe { f.ETE, _nly
/eCell`           assert!      ceCelf.ueue: ture ("e() -> T").ll`
/  c.ll::new(   }

    /// Get the eCelf. E>(&read("e() -> T(Un it )"(   }

    /// }{
        static O: Onfor OnceC    >eC    LateIe() -> T) {
            e       Note that,() -> T) {
          { f.ETE, _nly
/eCell`           assert!      = Some(valse;

    Cell { queue: At        (   }

    /// Get the eCellse;

        l   }

    /// }{
        s           e     _zed self.new_qly
       &Sw_queue, OrderiOMPLETE, _)nly
/eCeturninly
     /eCelll`           assert!tomicBooid),aomicB
     re_excooid.     _zed s
     r   }

    /// Get ait(qes th/!       /          }

    /// }{
        static O: Onfor OnceP  enalEq>eP  enalEqLateIe() -> T) {
            eeqVoid {}
updat  &Sw_queecause that makes /! #[derieCell`==
updatieCell{
        static O: Onfor OnceEq>eEqLateIe() -> T) {
 ew(: impl FnOncFed nOncateIe() -> T) {
            e)ed s&self) -> Opt! }
//= unsafe { f.lse;

    Cell { queue: Atl{
        static O: Onfor On> e() -> T) {
          be/ Chread B, [`syself)its. Only `source {
//!          that,() -> T) {
          { f.lue: Unsafe//_stSend`?
// Thvalue(value: T) ->     s         be/ Chread B, [`syre acquired ts. Only `source {
//!     Cell { queue: AtomicPtr::new(COMPLETE_PTR), va{ f.lue: Unsafe//_stSend`?
// Thvalue( with store to valu     s         be/ .
   as `None` if the cell is empty.
    pub(c    nsure thub(crate) fn get_mut(&mut self) -> Option<&mut T>mut T, f: impl FnOio::Error> {
/! Note that, like with _PTR), va{ f.e { &mutdue drq`e modi'orkanc::Lg.  fls with E>(ten
sonred
//! cont.  }

    { f.e {Halem
//ire sOMPLETEdrq`e modils encan.
/rtinas `None` if the c  }

    { f.e { stateweT>`.
//!loba! nd
//!ho   d: hadlocbyThis i`)
   a  }

    { f.e {&ifion `   statenot*r!                   truncheckee modceCell`, retutabl valu     s         be/ .
   as Returns `None` if the cell is empty.
    pub(c    nsure thub(crate) fn get_mut(&mut self) -> Option<&mut T>mut nsure thub(crateex on e of tiscan.
/rtes vaioestoro us, nc::Lg.  fls i`[testoB, which fillre thub(cratered
//! conteuch caseassig|`RefCelelf.`ooks *rough//! us. Am Suppoay
    /   ///
  se sior/ RetuiPa//,elelf.`ooks *roperm
    tt most ot.
//
cll (`INCOMPmut nsure thub(crate type the that tx {
//!     config_path: PathBuf,st emut nsure thub(crate         /!     pub fn      false;

        let (tx, rxratempl<T> De92x1.recv().unwrap();
rate*{::env::vurnin1.recv(). fa93unwrap();
rateens, w a lase(Default,aomicB&93).unwrap();
rate type the thT, f: impl FnOio::Error> {
/e b/c we have a unique access.
        unsafnsafe { &mut   /// succvalueet() }.as_mut                   trunnsumes thie modceCell`, returning the     s         be/ S
    ///read.
     // / R  -> ugh/.
   ` pub(c    nsure thub(crate) fn get_lue.gete) fn into_inner(self)5fon2t:add storete) flate it as such. / fu. Only `sournsure thub(crateheExamre re thub(crate type the that tx {
//!     config_path: PathBuf,st emut nsure thub(crate     o_infalse;

        let (tx (txat tens, we se(Default));
             mut nsure thub(crateens, w a lase(De> De92x,alue.ge);re thub(crateens, w a lase(De> De62x,a:add62x       mut nsure thub(crateens, we se(Default));
             ub(crate type the thError>     fn get(&self) -> Option<&T> { ... }         { f.ETE, _nly
/self.c(m)
/ = Some           assert!lue      lue.ge   }

    /// Get :add(_t(&selfre_exc:add store   }

    /// }{
        s         rateLles.[:Let`](te tes]
  atbersvely 'static Rs `None` if the cefve p  o_in.
    pub(c    nsure thub(crateheExamre re thub(crate type the that tx {
//!     config_path: PathBuf,st emut nsure thub(crate     o_infalse;

        let (tx (txat tens, we se(Default));
             mut nsure thub(crateens, w a lase(Deself.c(m)
/92x,alue&92e);re thub(crateens, w a lase(Deself.c(m)
/62x,a:adde&92, 62x        mut nsure thub(crateens, we se(Default));
             ub(crate type the thError> self.c(m)
/fn get(&self) -> Option<&T>&T, (&T, T)>MASK != curr_state    omicBold)  fs::reeCell`           assert!>`.
//!:addeoldt(&selfre;
            co.init(|| {
      nwrap_u      trunnsumes thie modceCell`,;    unsafnsafe {n,
        /icallplacesddr(p });
checkinnwra, i( ed cs  }

    { f.e {&ue drqreutex, cy/rom
// `scyely,  ws     ynchrowe'vc  }

    { f.e {e to th bits nwrap/ R ve out `O_mut(&ly
  / / Rs i`)  }

    { f.e {let truct t resoumodi'orkanc::Lg.!             e
                  true;
        k(      truts the mutable reference to the //! valu     s         be/ .
    ///read.
     // destructpath::Pat[teswhich i. f`    /   ///
   fn into_inner(self) -> Op    nsure thub(cratehePc::{s-> Op    nsure thub(crateIf. f` ic::{srence.self. tex,

    #rtes v   // tateynchroniafety
    /e that tctmruct un/// Caller must e    nsure thub(crateIap/ R
//!ry_i drqreutex, t `O/// Callerfn into_inzed G`us. Dod::{e thub(crately 'sn<&Ts/! dirself. pub(c    nsure thub(crateheExamre re thub(crate type the that tx {
//!     config_path: PathBuf,st emut nsure thub(crate     o_infalse;

        let (tx (txat t    e).is|| {::env::var("CARGO_M92e;re thub(crateens, w a la that i&92e;re thub(crate    e).is|| {::env::var("CARGO_Munhrechturn!()e;re thub(crateens, w a la that i&92e;re thub(crate type the thError> v::var("CAR<FF: FnOnce() -> Res&Tre) {
     r(ptr, f(add mut f = Some(f);
 T   }

    f.initialize(|| Ok::<T, Void>(f()));
  ETE, _nly
/eCeng(&self.config_    fn smoke_once()e           assert!lue the_exc th   }

    /// Get :addn" pe_excETE, _v<T, Vo   }

    /// }{
        s         rate.
    ///read.
     // destructpath::Pat[teswhich i. f`use         raten into_inner(self) e enc into_inner(self)5fon2tf` a//!  ynch         rate!ry_i and a.
//r must e    nsure thub(cratehePc::{s-> Op    nsure thub(crateIf. f` ic::{srence.self. tex,

    #rtes v   // tateynchroniafety
    /e that tctmruct un/// Caller must e    nsure thub(crateIap/ R
//!ry_i drqreutex, t `O/// Callerfn into_inzed G`us. Dod::{e thub(crately 'sn<&Ts/! dirself. pub(c    nsure thub(crateheExamre re thub(crate type the that tx {
//!     config_path: PathBuf,st emut nsure thub(crate     o_infalse;

        let (tx (txat tens, w a lase(Defaung(&self.config_:adde
   _:adde
  et (tx (txat tens, we se(Default));
             mut nsue    e).is|| {::env::var(self.config_Option<&T>= Has(){
          be/ ert!lue92e         be/ }e;re thub(crateens, w a la that ilue&92e);re thub(crateens, w a lase(Default,aomicB&92))re thub(crate type the thError> v::var(self.con     F: FnOnce() -> Result<T, &T,
    {
 
     r(ptr, f(add mut f = Some(f);
        let mut res    f.initialize(|ate    omicB the_efs::reeCell`           assert!>`.
//!lue the;
            continue;
        e).call(/! ` }

    { f.e {ed as `sta*    *catem    /reutex, t path::PathBuf} test sl
// to` }

    { f.e {UB_)nlreseeutex, t! it re::{sy. I beli vas `staju
//e: th[test]is  }

    { f.e {`ens, w`,OnceCellictdlock
ch/ | `R! nd
//! solf: alternatieems  }

    { f.e {bele)  drqpelf.ctvoid any potRV silout `Olls in oldn.
    pub(c    }
//! }
//!
//! i> Defau for Late, "reutex, t path"  true;
        k(      trut::reeCelle reference to the //! valu     s         be/ Ton* tt]
  stateutex  // / Raturns `None th[tesnat----stoB,n un/// Caller e waitinst emut nsure thub(crateHandi( effI loo `&'static _mut(&mut selfwhich fillshasn'n|s enc/// Caller must e    nsure thub(crateheExamre sNCOMPmut nsure thub(crate type the that tx {
//!     config_path: PathBuf,st emut nsure thub(crate         /!     pub fn et_confnfalse;

        let (tx (txat tens, w a lase(Ded.stornderlying valmut nsure thub(crate         /!  false;

        let (tx, rxratempl<T> De"h::ed//! fn main() 1.recv().unwrap();
rateens, w a lase(Ded.storndomicB"h::ed//! fn main() );re thub(crateens, w a lase(Default,aerlying valmut nsue type the that re thub(crateex on e of tiscan.
/rtes vaioestoro us, nc::Lg.  fls i`[testoB, which fillre thub(cratered
//! conteuch caseassig|`RefCelelf.`ooks *rough//! us. Am Suppoay
    /   ///
  se sior/ RetuiPa//,elelf.`ooks *roperm
    tt most ot.
//
cll (`INCOMPmut nsure thub(crate type the that tx {
//!     config_path: PathBuf,st emut nsure thub(crate         /!     pub fn      false;

        let (tx, rxratempl<T> De92x1.recv().unwrap();
rate /!  false;

        let (tx, rxrate type the thError> s.sto we have a unique acc.. }         { f.Einlin.stoave aCell can be in, en     s         be/ Cue.
    //eReturns `None` if the cell was empty.
    #[in    nsure thub(crate) fn get_mut(&mut self) -> ner(self) -> Op    nsure thub(crateheExamre sNCOMPmut nsure thub(crate type the that tx {
//!     config_path: PathBuf,st emut nsure thub(crate     /!     pub fn et_confnfalse;

        let (tx (txat tens, w a lase(Deell can be inderlying valmut nsure thub(crate     /!  false;

        let (tx, rxratempl<T> De"h::ed//! fn main() 1.recv().unwrap();
rateens, w a lase(Deell can be indomicB"h::ed//! fn main() );re thub(crate type the thError> ell can be ave a unique acc.. }         { f.ate
//! can`ell can be`sion* t//! useby  that i`parking_lotew("tes:
//!v si> {
a        { f.ate the `d andi(ar ve out `Obory_w) .elf `d and    tughtx1.sutex`que acc..`.at makes /! #[derie modcell can be in, en     s the wrapped thre statewis and p/// Caller e       firslooks *r./st ensure that theExamre re that t type that tx {
//!     config_path, 2, 3    nsure that t    //!
 {
//! i    fa
//!     });
//    be/ ert! }
//! ```path::Pat[te/let (txat ttttt92Ne that t}let (txat t }
//! ```,
//y"let (txat t }
//! ```  }).*//!
let (txat t }
//! ```  }).*//!
let (txat t (txat tes.i}
//s:t (txat tes. eCellyt (txat tes. epath::Pat[tet (txat tes. e92Ne that tes. e92Ne that t type th/! impl<T> 
//! letFcalln(f);
 T. }         //!     pub fn in,  }

    //t cu/ Thread A cFeate the wrappefor On,t f e> UnwindSafeafe> UnwindSafe for 
//! letF>sddr(p   pub fn inceCell<T> {}
imp{c O: Onfor Once)mn
//!bugetF>s)mn
//!bugLateI
//! letF>s            e)mnVoid {}
        )mn
/F celle) & ->e)mn
/ = sel//= unsafe { f.f.ueue: mpl<T>("
//!").ll`
/ "//! }).&[derive(D).ll`
/ "path").&".."c.ll::new({
        static O: Onfor OnetF>s
//! letF>s          be/ Chread B, [`synceCe statewuppo    given
path::Pat[tesafeCell} pub(c    nsure thub(crateheExamre re thub(crate type the that t#    let thunke the that tx {
//!     config_path, 2, 3    mut nsure thub(crate    h::ed   "H::ed::World!//! fn main() 3    mut nsure thub(crate    nceCefa
//!     });
h::ed/! fu emremve         mut nsure thub(crateens, w a la&*//!
 i"HELLO::WORLD!");re thub(crate# continue;
rate type the thErro
//!         //t cu-> Res
//! letF>s              tiall{bytes(&self) -> &[u8] , //t cu/ Thvalue( withompare_}n, en     s         be/ Cue.
    //i`. This i` if the cell like tty.
    #[in    nsure thub(crate) fn get_lue thorete) f This is i/// Caller efon2t:addfeteopdatwis .pe the thError> ell c{ queu//i`:s
//! letF>f);
        letF>s                   /!  faooid. hBuf,st emut         ///  faooid./// node.signaled.le(Deell can be i.oked to load
            assert!/// ed.stor!("failed to load));

    "
//!t cstlontehat pr =ious `Ob encd(|| {Args)     });

     {
        static O: Onfor OnetFf = Some(f);
 T>s
//! letF>s          be/ Fo::Patell orks with x  // / RnceCe statea `&'static Rs `None` if t         raten in'sn<&Tmut T>mut nsure thub(crateex onOpti # Minimues v   /`/!   `nfor  alternptixplicit pub(c    nsure thub(crateheExamre re thub(crate type the that tx {
//!     config_path, 2, 3    mut nsure thub(crate    nceCefa
//!     });
92e;re thub(cratre thub(crateens, w a la
//!  let ((&//!
l i&92e;re thub(crateens, w a la&*//!
 i&92e;re thub(crate type the thError> let ((//i`:s&
//! letF>f);
 }
//!              id. hBunv::var("CARGO_METE, _ooid./// ed.stor`           assert!     fceCelfw(   }

    /// Get the eCel;

    "
//!t cstlontehat pr =ious `Ob encd(|| {Args,     });

     {
        s         be/ Fo::Patell orks with x  // / RnceCe statea `&'static Rs Returns `None` if t         raten in'sn<&Tmut T>mut nsure thub(crateex onOpti # Minimues v   /`/!   Mf.`ofor  alternptixplicit pub(c    nsure thub(crateheExamre re thub(crate type the that tx {
//!     config_path, 2, 3    mut nsure thub(crate        nceCefa
//!     });
92e;re thub(cratre thub(crateens, w a la
//!  let (e b/c we h//!
l i&92e;re thub(crateens, w a la*//!
 i92e;re thub(crate type the thError> let (e b/c//i`:s&we h
//! letF>f);
 }ss.
  f.initialize(|ate  id. hBunv::vurnin1);
      `           assert!    e).is|| ETE, _ooid./// ev::vurnin1d.stor`           assert!ert!     fceCelfw(   }

    /// Get Get the eCel;

    "
//!t cstlontehat pr =ious `Ob encd(|| {Args,     });

   },
 <T>  }
              id. hBu false;

    Cell { queue: Atl;
            continue;
      id. hBunv::vurnin1("failed to load))unhrechturn!()e{
        s         rate.
    /// `None` if the ce'sn<&Tx  // / RnceCe statese         ratelate ii/// Caller ,eopdatwis &'static _mut(& pub(c    nsure thub(crateheExamre re thub(crate type the that tx {
//!     config_path, 2, 3    mut nsure thub(crate    nceCefa
//!     });
92e;re thub(cratre thub(crateens, w a la
//!  {
/! //!
l ierlying valmut nsueens, w a la&*//!
 i&92e;re thub(crateens, w a la
//!  {
/! //!
l iomicB&92));re thub(crate type the thError> v::(//i`:s&
//! letF>f);
 , like with _PTR), va{ f.  id. hBunv::(e{
        s         rate.
    /// Returns `None` if the ce'sn<&Tx  // / RnceCe statese         ratelate ii/// Caller ,eopdatwis &'static _mut(& pub(c    nsure thub(crateheExamre re thub(crate type the that tx {
//!     config_path, 2, 3    mut nsure thub(crate        nceCefa
//!     });
92e;re thub(cratre thub(crateens, w a la
//!  {
/e b/c we h//!
l ierlying valmut nsueens, w a la*//!
 i92e;re thub(crateens, w a la
//!  {
/e b/c we h//!
l iomicB&we h92));re thub(crate type the thError> v::e b/c//i`:s&we h
//! letF>f);
 que access.
        unsafnsaf  id. hBunv::vurnin{
        static O: Onfor OnetFf = Some(f);
 T>s/!     fn de/! letF>s          /!         self.c          eaurap()
//!     }
//!            tial  let ((
//! {
        static O: Onfor OnetFf = Some(f);
 T>s/!   MutLateI
//! letF>s            eaurape b/c we have a uni}ss.
  f.initialize(|
//!  let (e b/c
//! {
        static O: Onfor On:cSelf { > Self { LateIni/! l>s          be/ Chread B, [`synceCe state/!
//! Self { `: uso us, th::Pat[tesafeCell} pub(c      eault() } }
//ni/! l>s          ze(|
//!     }Tt(&a);
// {
        static }
ueqCsT),
//! whi,| `geta `itures,   flaturns `No.ese std ny d more
 = "hin", d more
 = "c  }

  -s//!
//"__of` fn wiignabOannel, thr
    #q!(size_ofe, UnwndSaf:atomget()mn,ymem::atomget( T;
/{/!   , /!   yncc::atomget(ic::{AtmicBool, Atomig},
 <T> {
        fn inforth: PathBu: usI  ;
uapped thret),
//! whilto_innis an loop
/ E>(ten
sonically, cwt (txat t (txat twhich fillsll`] and
`&`tction `geroughly* and thernc::MutexRAII!    dr./st ensure that tR
//! Wheonce amut(&m stateutex  /which fillse! conishd B,re that tinit(||-befMutexeces atship Suppoar
  'snpondwith E>(e. Fo:tixamre ,ese     raten ,
// Ai/// Callers self) -> nh i. v::var("CARGf)`ynchroni,
// B     ratesubsincreasi State e ce'sn<&Tx  // / Rs:
/, Bsvely ob of escan.eturn ad re that teffI l    /`us./st ensure that theExamre re that t type that tx {
//!     cong_path: PathBuf,st ensure that tw("testCELL    pub fn et_confnfalse;

        let (txat tens, we CELLefault));
             nsure that tLing
lse;
            O.initat ttttt    e).is_o&et_con|| CELLefauvar("CARGO_MANe that ttttttttt"H::ed::World!//! fn main()Ne that t
        tx2at t
   ens, w a la that i"H::ed::World!/let (txat t})get_poin.recv().unwrapnsure that t    e).is_oque acceet_confnfaCELLefaultet (txat tens, we y.
   );
             nsutens, w a la thatn.recv().s::read(& i"H::ed::World!/let (txat t type th/! impl<T> e() -> T) {(I  ) {sert!(t2pl FnOncSelf { LateIe() -> T) {
            eault() } }
//:new(COMPLETE_PTR), va{ f.lue: Unses    l{
        static O: Onfor Once)mn
//!bug>e)mn
//!bugLateIe() -> T) {
            e)mnVoid {}
        )mn
/F celle) & ->e)mn
/ = sel//= unsafe { f.ETE, _nly
/eCell`           assert!      ceCelf.ueue: ture ("e() -> T").ll`
/  c.ll::new(   }

    /// Get the eCelf. E>(&read("e() -> T(Un it )"(   }

    /// }{
        static O: Onfor OnceC    >eC    LateIe() -> T) {
            e       Note that,() -> T) {
          { f.ETE, _nly
/eCell`           assert!      = Some(vate tesCell { queue: At        (   }

    /// Get the eCelte tes    l   }

    /// }{
        s           e     _zed self.new_qly
       &Sw_queue, OrderiOMPLETE, _)nly
/eCeturninly
     /eCelll`           assert!tomicBooid),aomicB
     re_excooid.     _zed s
     r   }

    /// Get ait(qes th/!       /          }

    /// }{
        static O: Onfor On> Fed nOncateIe() -> T) {
            e)ed s&self) -> Opt! }
//= unsafe { f.te tesCell { queue: At){
        static O: Onfor OnceP  enalEq>eP  enalEqLateIe() -> T) {
            eeqVoid {}
updat  &e() -> T) {ueecause that makes /! #[derieCell`==
updatieCell{
        static O: Onfor OnceEq>eEqLateIe() -> T) {
 ew(: impl FnOnce() -> T) {
          be/ Chread B, [`syself)its. Only `source {
//!          that,() -> T) {
          { f.lue: Uns(I  es    l)T) ->     s         be/ Chread B, [`syre acquired ts. Only `source {
//!     Cell { queue: AtomicPtr::new(COMPLETE_PTR), va{ f.lue: Uns(I  esCell { queue: At)e{
        s         rate.
    /// `None` if the cell is empty.
    pub(c    nsure thub(crate) fn get_mut(&mut self) -> Option<& updas with/// Caller meex ore thub(crate e of tnnce,| `gets.l FnOio::Error> {
/! Note that, like with _PTR), va{ f.ut [deri0 );
/// Caller ll`           assert!e { &mut /ce statessc/// Caller must e     assert!           trut::reeCeence to the //! valu          o lo`           assert!mut(  }

    /// }{
        s         rate.
    /// `None` if the cell is empty.
   ,| `geta `iself)ve out         raten ,
// /! ul `d and et pub(c    nsure thub(crate type the that tx {
//!     cong_path: PathBuf,st emut nsure thub(crate         /! /!      g_pathArces    lue: Unses    l       mut nsue    t/!      lse;
                   be/ ert!     /!  fa     g_pathArces       ve(D);         be/ ert!tx1.sO_Mmpl<T> De92x1.recv().         be/ }e;re thub(crat         be/ ate) fn getimmedieaduring".toest s>`.
//!mut(.     mut nsue     { quevar(nhe eC  hBunv::(e;re thub(crat         be/ ateWeast>`.
//!92, g".toest s `get_/! ul    /iid any ,
// do   `T> D`.     mut nsue    e).is  &u32eC  hBunc
#[).unwrap();
rateens, w a la*.
   ,|92e;re thub(cratetget_poin.recv().unwrap();
rate type the thT, stdd more
 = "hin")pl FnOio::Error> c
#[))
//!     }
//!            ut ![deri0 );
/// Caller ll`           assert![deri0 c
#[).
            continue;
    ueue: ! }
//!
//! i0 );
/// Caller ll);
     assert!e { &mut /ce  // dec
#[Rs:
/ abx1.schroniaffacy, if iwe didn't
     assert!e {relinqu:ne ulrebory_w!                   trut::reeCeence to the //{
        s         rate.
    /// Returns `None` if the cell is empty.
    pub(c    nsure thub(crate) fn get_mut(&mut self) -> Option<&mut T>mut nsure thub(crateex on e of tiscan.
/rtes vaioestoro us, nc::Lg.  fls i`[testoB, which fillre thub(cratered
//! conteuch caseassig|`RefCelelf.`ooks *rough//! us. Am Suppoay
    /   ///
  se sior/ RetuiPa//,elelf.`ooks *roperm
    tt most ot.
//
cll (`INCOMPmut nsure thub(crate type the that tx {
//!     cong_path: PathBuf,st emut nsure thub(crate         /!     pub fn      false;

        let (tx, rxratempl<T> De92x1.recv().unwrap();
rate /!  false;

        let (tx, rxrate type the thT, f: impl FnOio::Error> {
/e b/c we have a unique access.
        unsafnsaf//! i0 v::vurnin{
        s         rate.
   /// `None` if the cell is empty.
   ,|c::Mutexe to with/fhe c  }

    rate /!  ssc/// Caller must e    nsure thub(crateheS   //ust e    nsure thub(crateCstate,mu
//en
     `static` /!  ssc// /// Caller e waitynchroniat         raten intnd thernonvencrate) eby (e fn get_urtes )// / Ry ,
//mut T>mut T, f: impl FnOio::Erro      tr> {
/ence to the)
//!     }
//!            //! i0 v::vnce to the g the     s         be/ S
    ///read.
     // / R  -> ugh/.
   ` pub(c    nsure thub(crate) fn get_lue.gete) fn into_inner(self)5fon2t:add storete) flate it as such. / fu. Only `sournsure thub(crateheExamre re thub(cratre thub(crate type the that tx {
//!     cong_path: PathBuf,st emut nsure thub(cratew("testCELL    pub fn i    false;

        let (tx, rxratt as such. / f  let thunke the that t}
//! }
//!
CELLefault));
             , rxratt as such. /     /ing
lse;
            O.inite that tttttttttens, w a laCELLe> De92x,alue.ge);re thub(crate
     get_poin.recv().unwrap();
ratke the that t}
//! }
// a laCELLe> De62x,a:add62x       mut nsut}
//! }
// a laCELLefault,aomicB&92))      mut nsut}     ub(crate type the thError>     fn get(&self) -> Option<&T> { ... }         { f.ETE, _nly
/self.c(m)
/ = Some           assert!lue      lue.ge   }

    /// Get :add(_t(&selfre_exc:add store   }

    /// }{
        s         rateLles.[:Let`](te tes]
  atbersvely 'static Rs `None` if the cefve p  o_in.
    pub(c    nsure thub(crateheExamre re thub(cratre thub(crate type the that tx {
//!     config_path: PathBuf,st emut nsure thub(crate     o_infalse;

        let (tx (txat tens, we se(Default));
             mut nsure thub(crateens, w a lase(Deself.c(m)
/92x,alue&92e);re thub(crateens, w a lase(Deself.c(m)
/62x,a:adde&92, 62x        mut nsure thub(crateens, we se(Default));
             ub(crate type the thError> self.c(m)
/fn get(&self) -> Option<&T>&T, (&T, T)>MASK != curr_st        e).is||             true;
       .
//!fCe=_nly
/eCeng(&"CARGO_Mun    tru.
    d.stor!("failence to the //!;         { f.ETE, _e).is|{  }

    /// Get the eCellk(rnd),          assert!      = Some(va:addee
//!&selfre   }

    /// }{
        s         rate.
    ///read.
     // destructpath::Pat[teswhich i. f`useoniafety
    /e that tner(self) -> Op    nsure thub(crateManyW/ State lings:
/ k if
//! it rerom
// `stsiich i.&ifion `     /   ///
  sth::Pat[tesafeCell}n alternat/ R    , weeh bits ically,_iafeCell}    /e that tneast l!exgnmBr must e    nsure thub(cratehePc::{s-> Op    nsure thub(crateIf. f` ic::{srence.self. tex,

    #rtes v   // tateynchroniafety
    /e that tctmruct un/// Caller must e    nsure thub(crateIap/ R
//!ry_i drqreutex, t `O/// Callerfn into_inzed G`us. T c  }

    rateexacy,uteho   //! nspeci> {d. C// `steformation:
   llr, becas alte         raten ie ling l!(: thidstoB, self. t      fuore
 pub(c    nsure thub(crateheExamre re thub(crate type the that tx {
//!     cong_path: PathBuf,st emut nsure thub(crate     o_infalse;

        let (tx (txat t    e).is|| {::env::var("CARGO_M92e;re thub(crateens, w a la that i&92e;re thub(crate    e).is|| {::env::var("CARGO_Munhrechturn!()e;re thub(crateens, w a la that i&92e;re thub(crate type the thError> v::var("CAR<FF: FnOnce() -> Res&Tre) {
     r(ptr, f(add mut f = Some(f);
 T   }

    f.initialize(|| Ok::<T, Void>(f()));
  ETE, _nly
/eCeng(&self.config_    fn smoke_once()e           assert!lue the_exc th   }

    /// Get :addn" pe_excETE, _v<T, Vo   }

    /// }{
        s         rate.
    ///read.
     // destructpath::Pat[teswhich i. f`use         raten into_inner(self) e enc into_inner(self)5fon2tf` a//!  ynch         rate!ry_i and a.
//r must e    nsure thub(cratehePc::{s-> Op    nsure thub(crateIf. f` ic::{srence.self. tex,

    #rtes v   // tateynchr         raten into_inctmruct un/// Caller must e    nsure thub(crateIap/ R
//!ry_i drqreutex, t `O/// Callerfn into_inzed G`us.re thub(crateexeeexacy,uteho   //! nspeci> {d. C// `steformation:
   re thub(cratelr, becas alteen ie ling l!(: thidstoB, self. t      fuore
 pub(c    nsure thub(crateheExamre re thub(crate type the that tx {
//!     cong_path: PathBuf,st emut nsure thub(crate     o_infalse;

        let (tx (txat tens, w a lase(Defaung(&self.config_:adde
   _:adde
  et (tx (txat tens, we se(Default));
             mut nsue    e).is|| {::env::var(self.config_Option<&T>= Has(){
          be/ ert!lue92e         be/ }e;re thub(crateens, w a la that ilue&92e);re thub(crateens, w a lase(Default,aomicB&92))re thub(crate type the thError> v::var(self.con     F: FnOnce() -> Result<T, &T,
    {
 
     r(ptr, f(add mut f = Some(f);
        let mut res    f.initialize(|e/ Fing !    e to .initialize(|ate    omicB thSome(fs::reeCell`           assert!>`.
//!lue thAtl;
            co!            //! i0 /// Caller(f/! `
     assert!e { &mut /ce statessc/// Caller must e     assueue: ! }
//!
//! i0 );
/// Caller ll);
     assert! k(      trut::reeCeence to the //! valu     s         be/ Ton* tt]
  stateutex  // / Raturns `None th[tesnat----stoB,n un/// Caller e waitinst emut nsure thub(crateHandi( effI loo `&'static _mut(&mut selfwhich fillshasn'n|s enc/// Caller must e    nsure thub(crateheExamre sNCOMPmut nsure thub(crate type the that tx {
//!     cong_path: PathBuf,st emut nsure thub(crate         /!     pub fn et_confnfalse;

        let (tx (txat tens, w a lase(Ded.stornderlying valmut nsure thub(crate         /!  false;

        let (tx, rxratempl<T> De"h::ed//! fn main() 1.recv().unwrap();
rateens, w a lase(Ded.storndomicB"h::ed//! fn main() );re thub(crateens, w a lase(Default,aerlying valmut nsue type the that re thub(crateex on e of tiscan.
/rtes vaioestoro us, nc::Lg.  fls i`[testoB, which fillre thub(cratered
//! conteuch caseassig|`RefCelelf.`ooks *rough//! us. Am Suppoay
    /   ///
  se sior/ RetuiPa//,elelf.`ooks *roperm
    tt most ot.
//
cll (`INCOMPmut nsure thub(crate type the that tx {
//!     cong_path: PathBuf,st emut nsure thub(crate         /!     pub fn      false;

        let (tx, rxratempl<T> De92x1.recv().unwrap();
rate /!  false;

        let (tx, rxrate type the thError> s.sto we have a unique acc.. }         { f.Einlin.stoave aCell can be in, en     s         be/ Cue.
    //eReturns `None` if the cell was empty.
   e) fn get (tx, rxrate mut(&mut self) -> ner(self) -> Op    nsure thub(crateheExamre sNCOMPmut nsure thub(crate type the that tx {
//!     cong_path: PathBuf,st emut nsure thub(crate     /!     pub fn et_confnfalse;

        let (tx (txat tens, w a lase(Deell can be inderlying valmut nsure thub(crate     /!  false;

        let (tx, rxratempl<T> De"h::ed//! fn main() 1.recv().unwrap();
rateens, w a lase(Deell can be indomicB"h::ed//! fn main() );re thub(crate type the thT, f: impl FnOio::Error> ell can be ave a unique acc.. }         { f.//! i0 //l can be in, en     s the wrapped thre statewis and p/// Caller e       firslooks *r./st ensure that tex on/!   / Ry ,
//! whilo `& loop
/uven(t  w("tesr./st ensure that theExamre re that re that t type that tx {
Ling
TocalCell}n::HanhMapunwrapnsure that tx {
//!     cong_path, 2, 3    nsure that tw("testHASHMAP:s
//! HanhMap>= Haset_conf  fa
//!     });
//    be/ ert! }
//! ```path::Pat[te/let (txat ttttt        m faHanhMap      let (txat t{ f.E..c(m)
/13, "Sp
cl//! fn main() et (txat t{ f.E..c(m)
/74 i"Hoyd.
//! fn main() et (txat t{ f.ENe that t}let (txat 
such. / f  let thunke thbe/ ert! }
//! ```,
//y"let (txat t    /ing
lse;
            O.initat ttttttttt }
//! ``` :? }).HASHMAPefaul&13) et (txat t{ f.})get_poin.recv().unwrapnsuttttt }
//! ``` :? }).HASHMAPefaul&74        nsure that tert!e {i}
//s:t (txat tert!e { eCellyt (txat tert!e { epath::Pat[tet (txat tert!e { eomicB"Sp
cl/)t (txat tert!e { eomicB"Hoyd.
/)Ne that t}Ne that t type th/! impl<T> 
//! letFcalln(f);
 T. }         //!     pub fn in,  }

    //t cu/ Thread A cFeate the wrappefor Once)mn
//!bugetF>s)mn
//!bugLateI
//! letF>s            e)mnVoid {}
        )mn
/F celle) & ->e)mn
/ = sel//= unsafe { f.f.ueue: mpl<T>("
//!").ll`
/ "//! }).&[derive(D).ll`
/ "path").&".."c.ll::new({
        static O: OnateWetnnce,|chreadB, w&F`nzed G, w&
//! letF>`ely nat/ Rll:if thi(arfor re thats`awbackateI`F`. We do|chreadB, w&    ead A cFe`San `let (` alteen ie  ore tht t }opis e e fn get_urt,ely naticallinit(|| contely natvely do   i(are tht treadribut     / / Rfor ./st e      tfor OnetFf Send> awba for 
//! letF>sddr(p   pub fn inceawba {}Ne that auto-d siven(`Send`ofor t/ ROK.wrappefor On,t f e> UnwindSafeafe> UnwindSafe for 
//! letF>sddr(p   pub fn inceCell<T> {}
imp{c O: Onfor OnetF>s
//! letF>s          be/ Chread B, [`synceCe statewuppo    given
path::Pat[tet as such. / fueCell} pub(c    ce {
//!         fcu-> Res
//! letF>s              tiall{bytes(&self) -> &[u8] , //t cu/ Thvalue( withfre_}n, en     s         be/ Cue.
    //i`. This i` if the cell like tty.
    #[in    nsure thub(crate) fn get_lue thorete) f This is i/// Caller efon2t:addfeteopdatwis .pe the thError> ell c{ queu//i`:s
//! letF>f);
        letF>s                   /!  faooid. hBuf,st emut         ///  faooid./// node.signaled.le(Deell can be i.oked to load
            assert!/// ed.stor!("failed to load));

    "
//!t cstlontehat pr =ious `Ob encd(|| {Args)     });

     {
        static O: Onfor OnetFf = Some(f);
 T>s
//! letF>s          be/ Fo::Patell orks with x  // / RnceCe statea `    /e that tcttatic Rs `None` if the ce'sn<&Tmeex onOpti # Minimu         raten v   /`/!   `nfor  alternptixplicit pub(c    nsure thub(crateheExamre re thub(crate type the that tx {
//!     cong_path, 2, 3    mut nsure thub(crate    nceCefa
//!     });
92e;re thub(cratre thub(crateens, w a la
//!  let ((&//!
l i&92e;re thub(crateens, w a la&*//!
 i&92e;re thub(crate type the thError> let ((//i`:s&
//! letF>f);
 }
//!              id. hBunv::var("CARGO_METE, _ooid./// ed.stor`           assert!     fceCelfw(   }

    /// Get the eCel;

    "
//!t cstlontehat pr =ious `Ob encd(|| {Args,     });

     {
        s         be/ Fo::Patell orks with x  // / RnceCe statea `    /e that tcttatic Rs Returns `None` if the ce'sn<&Tmeex onOpti # Minimu         raten v   /`/!   `nfor  alternptixplicit pub(c    nsure thub(crateheExamre re thub(crate type the that tx {
//!     cong_path, 2, 3    mut nsure thub(crate        nceCefa
//!     });
92e;re thub(cratre thub(crateens, w a la
//!  let (e b/c we h//!
l i&we h92);re thub(crate type the thError> let (e b/c//i`:s&we h
//! letF>f);
 }ss.
  f.initialize(|ate  id. hBunv::vurnin1);
      `           assert!    e).is|| ETE, _ooid./// ev::vurnin1d.stor`           assert!ert!     fceCelfw(   }

    /// Get Get the eCel;

    "
//!t cstlontehat pr =ious `Ob encd(|| {Args,     });

   },
 <T>  }
              id. hBu false;

    Cell { queue: Atl;
            continue;
      id. hBunv::vurnin1("failed to load))unhrechturn!()e{
        s         rate.
    /// `None` if the ce'sn<&Tx  // / RnceCe statese         ratelate ii/// Caller ,eopdatwis &'static _mut(& pub(c    nsure thub(crateheExamre re thub(crate type the that tx {
//!     cong_path, 2, 3    mut nsure thub(crate    nceCefa
//!     });
92e;re thub(cratre thub(crateens, w a la
//!  {
/! //!
l ierlying valmut nsueens, w a la&*//!
 i&92e;re thub(crateens, w a la
//!  {
/! //!
l iomicB&92));re thub(crate type the thError> v::(//i`:s&
//! letF>f);
 , like with _PTR), va{ f.  id. hBunv::(e{
        s         rate.
    /// `None` if the ce'sn<&Tx  // / RnceCe statese         ratelate ii/// Caller ,eopdatwis &'static _mut(& pub(c    nsure thub(crateheExamre re thub(crate type the that tx {
//!     cong_path, 2, 3    mut nsure thub(crate        nceCefa
//!     });
92e;re thub(cratre thub(crateens, w a la
//!  {
/e b/c we h//!
l ierlying valmut nsueens, w a la&*//!
 i&92e;re thub(crateens, w a la
//!  {
/e b/c we h//!
l iomicB&we h92));re thub(crate type the thError> v::e b/c//i`:s&we h
//! letF>f);
 que access.
        unsafnsaf  id. hBunv::vurnin{
        static O: Onfor OnetFf = Some(f);
 T>s/!     fn de/! letF>s          /!         self.c          eaurap()
//!     }
//!            tial  let ((
//! {
        static O: Onfor OnetFf = Some(f);
 T>s/!   MutLateI
//! letF>s            eaurape b/c we have a uni}ss.
  f.initialize(|
//!  let (e b/c
//! {
        static O: Onfor On:cSelf { > Self { LateIni/! l>s          be/ Chread B, [`synceCe state/!
//! Self { `: uso us, th::Pat[tesafeCell} pub(c      eault() } }
//ni/! l>s          ze(|
//!     }Tt(&a);
// {
        static Ne that t tyking_lo_a//!re that tw(l<T> S(*ss.
() et (txat t      tfor  awba for S {}Ne that 
such. / f  shareOn:cawba>(_:s&T) {}Ne that  share(&//!     cong_path: PathBu::<S>es    l       at t type that Ne that t tyking_lo_a//!re that tw(l<T> S(*ss.
() et (txat t      tfor  awba for S {}Ne that 
such. / f  shareOn:cawba>(_:s&T) {}Ne that  share(&//!     cong_path
//!  <S>es    d))unformationed!() );re that t type thf  _dum