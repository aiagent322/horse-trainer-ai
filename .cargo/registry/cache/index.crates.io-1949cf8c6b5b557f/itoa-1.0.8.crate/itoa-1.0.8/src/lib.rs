//! [![github]](https://github.com/dtolnay/itoa)&ensp;[![crates-io]](https://crates.io/crates/itoa)&ensp;[![docs-rs]](https://docs.rs/itoa)
//!
//! [github]: https://img.shields.io/badge/github-8da0cb?style=for-the-badge&labelColor=555555&logo=github
//! [crates-io]: https://img.shields.io/badge/crates.io-fc8d62?style=for-the-badge&labelColor=555555&logo=rust
//! [docs-rs]: https://img.shields.io/badge/docs.rs-66c2a5?style=for-the-badge&labelColor=555555&logo=docs.rs
//!
//! <br>
//!
//! This crate provides a fast conversion of integer primitives to decimal
//! strings. The implementation comes straight from [libcore] but avoids the
//! performance penalty of going through [`core::fmt::Formatter`].
//!
//! See also [`ryu`] for printing floating point primitives.
//!
//! [libcore]: https://github.com/rust-lang/rust/blob/b8214dc6c6fc20d0a660fb5700dca9ebf51ebe89/src/libcore/fmt/num.rs#L201-L254
//! [`core::fmt::Formatter`]: https://doc.rust-lang.org/std/fmt/struct.Formatter.html
//! [`ryu`]: https://github.com/dtolnay/ryu
//!
//! # Example
//!
//! ```
//! fn main() {
//!     let mut buffer = itoa::Buffer::new();
//!     let printed = buffer.format(128u64);
//!     assert_eq!(printed, "128");
//! }
//! ```
//!
//! # Performance (lower is better)
//!
//! ![performance](https://raw.githubusercontent.com/dtolnay/itoa/master/performance.png)

#![doc(html_root_url = "https://docs.rs/itoa/1.0.8")]
#![no_std]
#![allow(
    clippy::cast_lossless,
    clippy::cast_possible_truncation,
    clippy::expl_impl_clone_on_copy,
    clippy::must_use_candidate,
    clippy::unreadable_literal
)]

mod udiv128;

use core::mem::{self, MaybeUninit};
use core::{ptr, slice, str};
#[cfg(feature = "no-panic")]
use no_panic::no_panic;

/// A correctly sized stack allocation for the formatted integer to be written
/// into.
///
/// # Example
///
/// ```
/// let mut buffer = itoa::Buffer::new();
/// let printed = buffer.format(1234);
/// assert_eq!(printed, "1234");
/// ```
pub struct Buffer {
    bytes: [MaybeUninit<u8>; I128_MAX_LEN],
}

impl Default for Buffer {
    #[inline]
    fn default() -> Buffer {
        Buffer::new()
    }
}

impl Copy for Buffer {}

impl Clone for Buffer {
    #[inline]
    #[allow(clippy::incorrect_clone_impl_on_copy_type)] // false positive https://github.com/rust-lang/rust-clippy/issues/11072
    fn clone(&self) -> Self {
        Buffer::new()
    }
}

impl Buffer {
    /// This is a cheap operation; you don't need to worry about reusing buffers
    /// for efficiency.
    #[inline]
    #[cfg_attr(feature = "no-panic", no_panic)]
    pub fn new() -> Buffer {
        let bytes = [MaybeUninit::<u8>::uninit(); I128_MAX_LEN];
        Buffer { bytes }
    }

    /// Print an integer into this buffer and return a reference to its string
    /// representation within the buffer.
    #[cfg_attr(feature = "no-panic", no_panic)]
    pub fn format<I: Integer>(&mut self, i: I) -> &str {
        i.write(unsafe {
            &mut *(&mut self.bytes as *mut [MaybeUninit<u8>; I128_MAX_LEN]
                as *mut <I as private::Sealed>::Buffer)
        })
    }
}

/// An integer that can be written into an [`itoa::Buffer`][Buffer].
///
/// This trait is sealed and cannot be implemented for types outside of itoa.
pub trait Integer: private::Sealed {}

// Seal to prevent downstream implementations of the Integer trait.
mod private {
    pub trait Sealed: Copy {
        type Buffer: 'static;
        fn write(self, buf        "ffer.fonew() -> Bc1ue)).
mod/e
//atenttatic;
        fn writoed, "128");
UTBc1[u8]// a"\uf     36 0   304050607080910111213141516171819\uf     2 0   2324252627282930313233343536373839\uf     40414243440  647484950515253   556575859\uf     6061626364656667686970717273747576777879\uf     8081828384858687888990919293949596979899"stack Adapton(s)
   witWork and aight from [libcaimg.lang/rust/blob/b8214dc6c6fc20d0a660fb5700dca9ebf51ebe89/src/libcore/fmt/num.rs#L201-L254
//! [`core::fmt:188rma66   ($($name:idlse pe {
    ue:expr))*    lend bentoa_$t {
   ),*fer)$miti_fn {
   )toa_fh]
        s is e {
    .
pu$townst        s is al to prevent do.
pu$tow<I as private     fn wriinit(); I128_MA      *    len]iter(|| {
     _clone_iun///d_versiri
is )]er(|| {
     _cature = "no- {
     _cnic", no_panic)]
    pub fn format<I: Integer>f        "ffer.fonew() -> Bc1ue))t(); I128_MA      *    len]te(unsafe {
        eUninit::<u8is_nonnegmay ch=eUnin >= 0;
uf = Vec::with_capacity(e }
if8is_nonnegmay ch buf.clear();
        Unin er)$miti_fn      )*
        } eub.c buf.clear();
        g.lmitives:

  negmay chnm the om/rust-lare nmmffic1presen's 2dition frombuf.clear();
        (!(Unin er)$miti_fn)).    pffi_add(1)      )*
        };
uf = Vec::with_capacity(rted// ass.lenmax(u6ir th;
uf = Vec::with_capacass_eat// ass.as_ity_eatmax(u6d>::Bu8;
uf = Vec::with_capaclty_eat// ed, "128");
UT.as_eatmaiter(|| {
          *(&mut self.bytes as        g.lng bue followi16 benta to be w4- result os-at-a-tepsuffers
k.self.bytes as        if8
use r th_ood/<$t>max>= 2  buf.clear();
            g.lea   orm,eand i4  result osue fastepswrite!(&mut buf, "{}", blae Wornx>= 1      buf.clear();
            th_capacrem// (n % 1    ax(u6ir th;
uf = Vec::with_cccccccccccccn /= 1    iter(|| {
                 th_capacd1// (rem// 1  ) << 1;er(|| {
                 th_capacd2// (rem/% 1  ) << 1;er(|| {
                 th_crted/-= 4;er(|| {
                 th_ceatn,
ive nonoivel  pffi(lty_eat.offset(d1),cass_eat.offset(rted),c2);er(|| {
                 th_ceatn,
ive nonoivel  pffi(lty_eat.offset(d2),cass_eat.offset(rted + 2),c2);er(|| {
                 }                }
    
self.bytes as        g.lif8wo.tomchcharghnm b osuergh<= 9999temsue fmoowi4  ress addemut buf = Vec::with_capacity(e }
nx(u6ir th; g.lclippy:tings of 64ben

  h
self.bytes as        g.l,eand i2ng sha resssuch > 2diressself.bytes as        if8nx>= 1    let printed = buffer.format(bd1// (n/% 1  ) << 1;er(|| {
                 n /= 1  ;er(|| {
                 rted/-= 2;er(|| {
                 eatn,
ive nonoivel  pffi(lty_eat.offset(d1),cass_eat.offset(rted),c2);er(|| {
             }
self.bytes as        g.l,eand illowi1    2diressself.bytes as        if8nx< 1   let printed = buffer.formrted/-= 1;er(|| {
                 *ass_eat.offset(rted)// (n/(u648) + b'0';er(|| {
             } eub.c buf.clear();
        format(bd1// n << 1;er(|| {
                 rted/-= 2;er(|| {
                 eatn,
ive nonoivel  pffi(lty_eat.offset(d1),cass_eat.offset(rted),c2);er(|| {
             }
self.bytes as        if8!is_nonnegmay ch buf.clear();
        formrted/-= 1;er(|| {
                 *ass_eat.offset(rted)// b'-';er(|| {
             }
 {
             }
self.bytes as    apaclen// ass.lenmax-mrted/(u64r th;
uf = Vec::with_capaca::unini *(&mut re = ":: the_raw_pears(ass_eat.offset(rted),clen) };
uf = Vec::with_c *(&mut reatn, the_utf8_un dtoled(a::un) }
 {
         }es! {
    bench)*};  fn writoI  as *mut:64r th = 4;e writoU  as *mut:64r th = 3;e writoI16 as *mut:64r th = 6;e writoU16 as *mut:64r th = 5;e writoI32 as *mut:64r th = 11;e writoU32 as *mut:64r th = 10;e writoI64 as *mut:64r th = 20;e writoU64 as *mut:64r th = 20;e
lse pe {
   !]
    I  as *muttoa_i8literaU  as *muttoa_u8literaI16 as *muttoa_i16literaU16 as *muttoa_u16literaI32 as *muttoa_i32literaU32 as *muttoa_u32"128");_u32);e
lse pe {
   !]I64 as *muttoa_i64,oU64 as *muttoa_u64x(u64::m;e
")]
usn-linu_ [liber_widthample6c;

lse pe {
   !]I16 as *muttoa_ir th,aU16 as *muttoa_ur th (u6416m;e
")]
usn-linu_ [liber_widthampl32c;

lse pe {
   !]I32 as *muttoa_ir th,aU32 as *muttoa_ur th (u6432);e
")]
usn-linu_ [liber_widthampl64c;

lse pe {
   !]I64 as *muttoa_ir th,aU64 as *muttoa_ur th (u64::m;e
  ($($name:idlse pe {
   128 ue:expr))*    lend bentoa_$t {
   ),*)toa_fh]
        s is e {
    .
pu$townst        s is al to prevent do.
pu$tow<I as private     fn wriinit(); I128_MA      *    len]iter(|| {
     _clone_iun///d_versiri
is )]er(|| {
     _cature = "no- {
     _cnic", no_panic)]
    pub fn format<I: Integer>f        "ffer.fonew() -> Bc1ue))t(); I128_MA      *    len]te(unsafe {
        eUninit::<u8is_nonnegmay ch=eUnin >= 0;
uf = Vec::with_capace }
if8is_nonnegmay ch buf.clear();
        Unin er)          )*
        } eub.c buf.clear();
        g.lmitives:

  negmay chnm the om/rust-lare nmmffic1presen's 2dition frombuf.clear();
        (!(Unin er)u128:).    pffi_add(1)      )*
        };
uf = Vec::with_capacity(rted// ass.lenmax(u6ir th;
uf = Vec::with_capacass_eat// ass.as_ity_eatmax(u6d>::Bu8;
er(|| {
          *(&mut self.bytes as        g.lDient lare10^19s) was i of gohighfeat, to   othethan 2^64.mut buf = Vec::with_capac(nbutim)// {self, ::{selmod_1e19(n);er(|| {
             apacass1// ass_eat.offset(rted -aU64 as *mutt(u6ir th); I128_MAX_LEN]
           U64 as *mut];er(|| {
             rted/-= tim   &mut *mut ass1).lenmax(u6ir th;
self.bytes as        if8nx!= 0  buf.clear();
            g.lMemsns:

  ) th1  l that tzerood prtim buf.clear();
        format(bn-linu// ass.lenmax(u6ir th -a19;er(|| {
                 eatn,  &mu_a::un(ass_eat.offset(n-linu),ca'0', (rted -an-linu)/(u64r th);er(|| {
                 rted/=an-linuiter(|| {
                 g.lDient lare10^19s by r buf.clear();
        format(b(nbutim)// {self, ::{selmod_1e19(n);er(|| {
                 apacass2// ass_eat.offset(rted -aU64 as *mutt(u6ir th); I128_MAX_LEN]
           U64 as *mut];er(|| {
                 rted/-= tim   &mut *mut ass2).lenmax(u6ir th;
self.bytes as            if8nx!= 0  buf.clear();
                g.lMemsns:

  l that tzeroo.er(|| {
                 th_capacn-linu// ass.lenmax(u6ir th -a38;er(|| {
                 th_ceatn,  &mu_a::un(ass_eat.offset(n-linu),ca'0', (rted -an-linu)/(u64r th);er(|| {
                     rted/=an-linuiter(|| {
                     g.lTharghisue fmoowilinedigiaclefter(|| {
                     g.lbeto car         // 1 ^19s/ 1 ^19sisu3.er(|| {
                 th_crted/-= 1;er(|| {
                 th_c*ass_eat.offset(rted)// (n/(u648) + b'0';er(|| {
                 }                }
    
self.bytes as        if8!is_nonnegmay ch buf.clear();
        formrted/-= 1;er(|| {
                 *ass_eat.offset(rted)// b'-';er(|| {
             }
er(|| {
             apaclen// ass.lenmax-mrted/(u64r th;
uf = Vec::with_cth_capaca::uninie = ":: the_raw_pears(ass_eat.offset(rted),clen);
uf = Vec::with_cth_ceatn, the_utf8_un dtoled(a::un)      )*
        }
    }
}

ben}es! {
    bench)*};  fn writoU    as *mut:64r th = 39;e writoI1   as *mut:64r th = 40;e
lse pe {
   1  !]I12  as *muttoa_i12 