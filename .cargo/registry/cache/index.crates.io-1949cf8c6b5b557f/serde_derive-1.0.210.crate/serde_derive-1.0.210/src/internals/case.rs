//! Code to convert the Rust-styled field/variant (e.g. `my_field`, `MyType`) to the
//! case of the source (e.g. `my-field`, `MY_FIELD`).

use self::RenameRule::*;
use std::fmt::{self, Debug, Display};

/// The different possible ways to change case of fields in a struct, or variants in an enum.
#[derive(Copy, Clone, PartialEq)]
pub enum RenameRule {
    /// Don't apply a default rename rule.
    None,
    /// Rename direct children to "lowercase" style.
    LowerCase,
    /// Rename direct children to "UPPERCASE" style.
    UpperCase,
    /// Rename direct children to "PascalCase" style, as typically used for
    /// enum variants.
    PascalCase,
    /// Rename direct children to "camelCase" style.
    CamelCase,
    /// Rename direct children to "snake_case" style, as commonly used for
    /// fields.
    SnakeCase,
    /// Rename direct children to "SCREAMING_SNAKE_CASE" style, as commonly
    /// used for constants.
    ScreamingSnakeCase,
    /// Rename direct children to "kebab-case" style.
    KebabCase,
    /// Rename direct children to "SCREAMING-KEBAB-CASE" style.
    ScreamingKebabCase,
}

static RENAME_RULES: &[(&str, RenameRule)] = &[
    ("lowercase", LowerCase),
    ("UPPERCASE", UpperCase),
    ("PascalCase", PascalCase),
    ("camelCase", CamelCase),
    ("snake_case", SnakeCase),
    ("SCREAMING_SNAKE_CASE", ScreamingSnakeCase),
    ("kebab-case", KebabCase),
    ("SCREAMING-KEBAB-CASE", ScreamingKebabCase),
];

impl RenameRule {
    pub fn from_str(rename_all_str: &str) -> Result<Self, ParseError> {
        for (name, rule) in RENAME_RULES {
            if rename_all_str == *name {
                return Ok(*rule);
            }
        }
        Err(ParseError {
            unknown: rename_all_str,
        })
    }

    /// Apply a renaming rule to an enum variant, returning the version expected in the source.
    pub fn apply_to_variant(self, variant: &str) -> String {
        match self {
            None | PascalCase => variant.to_owned(),
            LowerCase => variant.to_ascii_lowercase(),
            UpperCase => variant.to_ascii_uppercase(),
            CamelCase => variant[..1].to_ascii_lowercase() + &variant[1..],
            SnakeCase => {
                let mut snake = String::new();
                for (i, ch) in variant.char_indices() {
                    if i > 0 && ch.is_uppercase() {
                        snake.push('_');
                    }
                    snake.push(ch.to_ascii_lowercase());
                }
                snake
            }
            ScreamingSnakeCase => SnakeCase.apply_to_variant(variant).to_ascii_uppercase(),
            KebabCase => SnakeCase.apply_to_variant(variant).replace('_', "-"),
            ScreamingKebabCase => ScreamingSnakeCase
                .apply_to_variant(variant)
                .replace('_', "-"),
        }
    }

    /// Apply a renaming rule to a struct field, returning the version expected in the source.
    pub fn apply_to_field(self, field: &str) -> String {
        match self {
            None | LowerCase | SnakeCase => field.to_owned(),
            UpperCase => field.to_ascii_uppercase(),
            PascalCase => {
                let mut pascal = String::new();
                let mut capitalize = true;
                for ch in field.chars() {
                    if ch == '_' {
                        capitalize = true;
                    } else if capitalize {
                        pascal.push(ch.to_ascii_uppercase());
                        capitalize = false;
                    } else {
                        pascal.push(ch);
                    }
                }
                pascal
            }
            CamelCase => {
                let pascal = PascalCase.apply_to_field(field);
                pascal[..1].to_ascii_lowercase() + &pascal[1..]
            }
            ScreamingSnakeCase => field.to_ascii_uppercase(),
            KebabCase => field.replace('_', "-"),
            ScreamingKebabCase => ScreamingSnakeCase.apply_to_field(field).replace('_', "-"),
        }
    }

    /// |            }
   ascalCase                      pascal.push(ch.to_ascii_uppercase());
                        capitalize = falseascal.push(ch.to_ascii_uppercase());
                        capitalize = falseascal.push(ch.to_ascii_uppercase());
                        capitalize = falseascal.push(ch.to_ascii_uppercase());
                        capitalize = falseascal.push(ch.to_asci(ch.to      ///let _b`e>, ()wis{
            or(ialize_ali_b: S
    F: Srue;
         ize = true;
                      ali_b[derive(Deserializeializ.0.210/src/internalen topitaliz          
    ma=> variant.to) {
     }varian
    // Rena               
    ma=> von emone,
  ,]) {        UpF) => te         Up applyvariant: &st.writected  // oursee direct ch//lascii_upp    
fn is_impli,
   
    fault // ours,])
fn is_implit.writected  `:LitStr>> {    of  
fn is_impli),
     -> Stri     )
        match se }
     ercaeet =( not have lifetime .repla  }
    }

    ///t.writected  ,  
fn is_impliize = falseascal.p,
   
    f> Strif
fn is_implicitly_borrowe collect_ }va#[(ty)]
.name
    ren to "( not hav),
 &(original, ));
 ,         "-"), a ren, apitalize, : ren, apitalize_: ren
    esult<S })
  falseascal.p"Outaseall_"outaseall_"OUTCOMEll_"outaseall_"outaseall_"OUTCOMEll_"outaseall_"OUTCOMEll
=> Some(path),
      falseascal.p"VeryTaeba

    Ok(match "   ytaeba

    Ok(match "VERYTASTY

    Ok(match "   yTaeba

    Ok(match "   y_taeba

    Ok(match "VERY_TASTY

    Ok(match "   y-taeba

    Ok(match "VERY-TASTY

    Ok(mapath),
     "All_"all_"All_"all_"all_"All_"all_"A"path),
     "Z42ll_"z42ll_"Z42ll_"z42ll_"z42ll_"Z42ll_"z42ll_"Z42lpath),
/
// False pas    _eq!mpty uppercase(),
     originalkensriginalk;/ False pas    _eq!m} else ifuppercase(),
     originalken));
 k;/ False pas    _eq!mush(ch.touppercase(),
     originalken     k;/ False pas    _eq!m }
   ascalCase     ),
     originalkensriginalk;/ False pas    _eq!m "-"),
  lCase     ),
     originalken "-")k;/ False pas    _eq!m
        match self {
     originalkena renk;/ False pas    _eq!m
pitalize = falseascal.push( {
     originalkenapitalizek;/ False pas    _eq!m         scal.push( {
     originalken: ren
;/ False pas    _eq!mrcase());
                     scal.push( {
     originalke/ False positipitalize_: renth),
        Err_ }va#[(ty)]
.name
     &[
  ( not hav),
 &(original,                 "-"), apitalize, : ren, apitalize_: ren
    esult<S })
  falseascal.p"outaseall_"OUTCOMEll_"Outaseall_"outaseall_"OUTCOMEll_"outaseall_"OUTCOMEll
=> Some(path),
      falseascal.p"   y_taeba

    Ok(match "VERY_TASTY

    Ok(match "VeryTaeba

    Ok(match "   yTaeba

    Ok(match "VERY_TASTY

    Ok(match "   y-taeba

    Ok(match "VERY-TASTY

    Ok(mapath),
     "all_"All_"All_"all_"All_"all_"A"path),
     "z42ll_"Z42ll_"Z42ll_"z42ll_"Z42ll_"z42ll_"Z42lpath),
/
// False pas    _eq!mpty uppercase(ch.to_originalkensriginalk;/ False pas    _eq!mush(ch.touppercase(ch.to_originalken     k;/ False pas    _eq!m }
   ascalCase     ch.to_originalken      k;/ Fa