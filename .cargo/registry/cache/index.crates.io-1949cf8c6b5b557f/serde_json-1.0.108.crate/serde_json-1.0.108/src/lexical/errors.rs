// Adapted from https://github.com/Alexhuszagh/rust-lexical.

//! Estimate the error in an 80-bit approximation of a float.
//!
//! This estimates the error in a floating-point representation.
//!
//! This implementation is loosely based off the Golang implementation,
//! found here: <https://golang.org/src/strconv/atof.go>

use super::float::*;
use super::num::*;
use super::rounding::*;

pub(crate) trait FloatErrors {
    /// Get the full error scale.
    fn error_scale() -> u32;
    /// Get the half error scale.
    fn error_halfscale() -> u32;
    /// Determine if the number of errors is tolerable for float precision.
    fn error_is_accurate<F: Float>(count: u32, fp: &ExtendedFloat) -> bool;
}

/// Check if the error is accurate with a round-nearest rounding scheme.
#[inline]
fn nearest_error_is_accurate(errors: u64, fp: &ExtendedFloat, extrabits: u64) -> bool {
    // Round-to-nearest, need to use the halfway point.
    if extrabits == 65 {
        // Underflow, we have a shift larger than the mantissa.
        // Representation is valid **only** if the value is close enough
        // overflow to the next bit within errors. If it overflows,
        // the representation is **not** valid.
        !fp.mant.overflowing_add(errors).1
    } else {
        let mask: u64 = lower_n_mask(extrabits);
        let extra: u64 = fp.mant & mask;

        // Round-to-nearest, need to check if we're close to halfway.
        // IE, b10100 | 100000, where `|` signifies the truncation point.
        let halfway: u64 = lower_n_halfway(extrabits);
        let cmp1 = halfway.wrapping_sub(errors) < extra;
        let cmp2 = extra < halfway.wrapping_add(errors);

        // If both comparisons are true, we have significant rounding error,
        // and the value cannot be exactly represented. Otherwise, the
        // representation is valid.
        !(cmp1 && cmp2)
    }
}

impl FloatErrors for u64 {
    #[inline]
    fn error_scale() -> u32 {
        8
    }

    #[inline]
    fn error_halfscale() -> u32 {
        u64::error_scale() / 2
    }

    #[inline]
    fn error_is_accurate<F: Float>(count: u32, fp: &ExtendedFloat) -> bool {
        // Determine if extended-precision float is a good approximation.
        // If the error has affected too many units, the float will be
        // inaccurate, or if the representation is too close to halfway
        // that any operations could affect this halfway representation.
        // See the documentation for dtoa for more information.
        let bias = -),
    te<F: Float>(count:-ISSA_SIZE + 1;
     let cmp1 = hdeed.

u_gmant.biats_s    fp.exp =invokes tshave a ra*only** &Exte radi(deed.

u_gman-= 0x7FF) // would reqys have a rive or negatvalue caant roundid      tsh{23, 52}. let extra: u64 = em::sizepr 0x7FF;<=hdeed.

u_gman      data: Ve #[-ISSA_SIZE + 1;
    ideed.

u_gman-= 0x7FF } else {
            // Use p63[-ISSA_SIZE + 1;
   };
         // Overflow ur_hagic tshasng a ne-> 
    lermine
    // represenignifi // Overflow and the exponent r u64 duual te exact dtoadiis rcant roundinl  // that any big inte error,
       ary e error,
      e infarest roundin // inaccuratsfway point.
    if,100 | allowfast patd {
      bt in the  // would reqy//! wher...,nly
   ty e error,
      e infty e erroestat:: // inaccuratsfwfast patd {
      bt in, weef.roumin0  // See the Tineo so calculatewe'rewfaeor_dty e error,
      e+/-onent r u6 // and the v we>/<ual significhalfw    les  // See the // and the Forewfaeor_dwe use the halfant he Grssfunt he b(cre large is // and the vaalysiloasocumeates10^-10the arbiu8 couhthe mant  #[ theatErif  // that any ofloa  // See the // and the # real de tru // and the ::Orderiway.(point.
 - < extra;
       // and the ::Orderiway.halfway.(point.
 + < extra // See the // and the # Lers tE4 = em::, Le nor u64 // See the // and the : &BASE = em::siz8 // and the : &BApoint.
          =  0b00,
];
c // and the : &BASE =     // Use p=  0b00,
];1c // and the : &BASr u64   // Use p=  0b0,
];1c0 // and the : &BApoint.
 - < extrp=  0b011111c0 // and the : &BApoint.
 + < extrp=  0b1,
];1c0 // and the // and the : &BAUfunt he: // and the : &BA &BApoint.
 - < extrp= 124 // and the : &BA &BApoint.
 + < extrp= 132 // and the : &BA &BASE =     // Use p= 402,   /nd the : &BA &BAeriwa    // Use p=  } else {nd the : &BA &BAeri2a    // Use p=  } else {nd the : &BASnt he: // and the : &BA &BApoint.
 - < extrp= 124 // and the : &BA &BApoint.
 + < extrp= -124 // and the : &BA &BASE =     // Use p= -126,   /nd the : &BA &BAeriwa    // Use p=    }
lse {nd the : &BA &BAeri2a    // Use p=  } else {nd the // and the # renclu intese {nd the // and the  alrea< extrpqys have a riveut and
did   lready   lermine
  cn // inaccuratpresentation is too clos, or if thwe use the halfant**sfunt he** // that any nitifer % al de tru   // Tracka: u64 = em::siz64 = em::s
    }  let extra: u6 extrp=  i32;

    }  let extrbits == 65 {
>      // Undernderflow, we have a shift lalake_fic0.     result.iad float     is_halfw   value *=error_is_accurate(errors: u64, f,onent, ;
      
