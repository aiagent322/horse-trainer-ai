// Copyright 2015 The Rust Project Developers. See the COPYRIGHT
// file at the top-level directory of this distribution and at
// http://rust-lang.org/COPYRIGHT.
//
// Licensed under the Apache License, Version 2.0 <LICENSE-APACHE or
// http://www.apache.org/licenses/LICENSE-2.0> or the MIT license
// <LICENSE-MIT or http://opensource.org/licenses/MIT>, at your
// option. This file may not be copied, modified, or distributed
// except according to those terms.

//! A lightweight logging facade.
//!
//! The `log` crate provides a single logging API that abstracts over the
//! actual logging implementation. Libraries can use the logging API provided
//! by this crate, and the consumer of those libraries can choose the logging
//! implementation that is most suitable for its use case.
//!
//! If no logging implementation is selected, the facade falls back to a "noop"
//! implementation that ignores all log messages. The overhead in this case
//! is very small - just an integer load, comparison and jump.
//!
//! A log request consists of a _target_, a _level_, and a _body_. A target is a
//! string which defaults to the module path of the location of the log request,
//! though that default may be overridden. Logger implementations typically use
//! the target to filter requests based on some user configuration.
//!
//! # Usage
//!
//! The basic use of the log crate is through the five logging macros: [`error!`],
//! [`warn!`], [`info!`], [`debug!`] and [`trace!`]
//! where `error!` represents the highest-priority log messages
//! and `trace!` the lowest. The log messages are filtered by configuring
//! the log level to exclude messages with a lower priority.
//! Each of these macros accept format strings similarly to [`println!`].
//!
//!
//! [`error!`]: ./macro.error.html
//! [`warn!`]: ./macro.warn.html
//! [`info!`]: ./macro.info.html
//! [`debug!`]: ./macro.debug.html
//! [`trace!`]: ./macro.trace.html
//! [`println!`]: https://doc.rust-lang.org/stable/std/macro.println.html
//!
//! Avoid writing expressions with side-effects in log statements. They may not be evaluated.
//!
//! ## In libraries
//!
//! Libraries should link only to the `log` crate, and use the provided
//! macros to log whatever information will be useful to downstream consumers.
//!
//! ### Examples
//!
//! ```
//! # #[derive(Debug)] pub struct Yak(String);
//! # impl Yak { fn shave(&mut self, _: u32) {} }
//! # fn find_a_razor() -> Result<u32, u32> { Ok(1) }
//! use log::{info, warn};
//!
//! pub fn shave_the_yak(yak: &mut Yak) {
//!     info!(target: "yak_events", "Commencing yak shaving for {yak:?}");
//!
//!     loop {
//!         match find_a_razor() {
//!             Ok(razor) => {
//!                 info!("Razor located: {razor}");
//!                 yak.shave(razor);
//!                 break;
//!             }
//!             Err(err) => {
//!                 warn!("Unable to locate a razor: {err}, retrying");
//!             }
//!         }
//!     }
//! }
//! # fn main() {}
//! ```
//!
//! ## In executables
//!
//! Executables should choose a logging implementation and initialize it early in the
//! runtime of the program. Logging implementations will typically include a
//! function to do this. Any log messages generated before
//! the implementation is initialized will be ignored.
//!
//! The executable itself may use the `log` crate to log as well.
//!
//! ### Warning
//!
//! The logging system may only be initialized once.
//!
//! ## Structured logging
//!
//! If you enable the `kv` feature you can associate structured values
//! with your log records. If we take the example from before, we can include
//! some additional context besides what's in the formatted message:
//!
//! ```
//! # use serde::Serialize;
//! # #[derive(Debug, Serialize)] pub struct Yak(String);
//! # impl Yak { fn shave(&mut self, _: u32) {} }
//! # fn find_a_razor() -> Result<u32, std::io::Error> { Ok(1) }
//! # #[cfg(feature = "kv_serde")]
//! # fn main() {
//! use log::{info, warn};
//!
//! pub fn shave_the_yak(yak: &mut Yak) {
//!     info!(target: "yak_events", yak:serde; "Commencing yak shaving");
//!
//!     loop {
//!         match find_a_razor() {
//!             Ok(razor) => {
//!                 info!(razor; "Razor located");
//!                 yak.shave(razor);
//!                 break;
//!             }
//!             Err(e) => {
//!                 warn!(e:err; "Unable to locate a razor, retrying");
//!             }
//!         }
//!     }
//! }
//! # }
//! # #[cfg(not(feature = "kv_serde"))]
//! # fn main() {}
//! ```
//!
//! See the [`kv`] module documentation for more details.
//!
//! # Available logging implementations
//!
//! In order to produce log output executables have to use
//! a logger implementation compatible with the facade.
//! There are many available implementations to choose from,
//! here are some of the most popular ones:
//!
//! * Simple minimal loggers:
//!     * [env_logger]
//!     * [colog]
//!     * [simple_logger]
//!     * [simplelog]
//!     * [pretty_env_logger]
//!     * [stderrlog]
//!     * [flexi_logger]
//!     * [call_logger]
//!     * [structured-logger]
//! * Complex configurable frameworks:
//!     * [log4rs]
//!     * [fern]
//! * Adaptors for other facilities:
//!     * [syslog]
//!     * [slog-stdlog]
//!     * [systemd-journal-logger]
//!     * [android_log]
//!     * [win_dbg_logger]
//!     * [db_logger]
//!     * [log-to-defmt]
//!     * [logcontrol-log]
//! * For WebAssembly binaries:
//!     * [console_log]
//! * For dynamic libraries:
//!     * You may need to construct an FFI-safe wrapper over `log` to initialize in your libraries
//! * Utilities:
//!     * [log_err]
//!     * [log-reload]
//!
//! # Implementing a Logger
//!
//! Loggers implement the [`Log`] trait. Here's a very basic example that simply
//! logs all messages at the [`Error`][level_link], [`Warn`][level_link] or
//! [`Info`][level_link] levels to stdout:
//!
//! ```
//! use log::{Record, Level, Metadata};
//!
//! struct SimpleLogger;
//!
//! impl log::Log for SimpleLogger {
//!     fn enabled(&self, metadata: &Metadata) -> bool {
//!         metadata.level() <= Level::Info
//!     }
//!
//!     fn log(&self, record: &Record) {
//!         if self.enabled(record.metadata()) {
//!             println!("{} - {}", record.level(), record.args());
//!         }
//!     }
//!
//!     fn flush(&self) {}
//! }
//!
//! # fn main() {}
//! ```
//!
//! Loggers are installed by calling the [`set_logger`] function. The maximum
//! log level also needs to be adjusted via the [`set_max_level`] function. The
//! logging facade uses this as an optimization to improve performance of log
//! messages at levels that are disabled. It's important to set it, as it
//! defaults to [`Off`][filter_link], so no log messages will ever be captured!
//! In the case of our example logger, we'll want to set the maximum log level
//! to [`Info`][filter_link], since we ignore any [`Debug`][level_link] or
//! [`Trace`][level_link] level log messages. A logging implementation should
//! provide a function that wraps a call to [`set_logger`] and
//! [`set_max_level`], handling initialization of the logger:
//!
//! ```
//! # use log::{Level, Metadata};
//! # struct SimpleLogger;
//! # impl log::Log for SimpleLogger {
//! #   fn enabled(&self, _: &Metadata) -> bool { false }
//! #   fn log(&self, _: &log::Record) {}
//! #   fn flush(&self) {}
//! # }
//! # fn main() {}
//! use log::{SetLoggerError, LevelFilter};
//!
//! static LOGGER: SimpleLogger = SimpleLogger;
//!
//! pub fn init() -> Result<(), SetLoggerError> {
//!     log::set_logger(&LOGGER)
//!         .map(|()| log::set_max_level(LevelFilter::Info))
//! }
//! ```
//!
//! Implementations that adjust their configurations at runtime should take care
//! to adjust the maximum log level as well.
//!
//! # Use with `std`
//!
//! `set_logger` requires you to provide a `&'static Log`, which can be hard to
//! obtain if your logger depends on some runtime configuration. The
//! `set_boxed_logger` function is available with the `std` Cargo feature. It is
//! identical to `set_logger` except that it takes a `Box<Log>` rather than a
//! `&'static Log`:
//!
//! ```
//! # use log::{Level, LevelFilter, Log, SetLoggerError, Metadata};
//! # struct SimpleLogger;
//! # impl log::Log for SimpleLogger {
//! #   fn enabled(&self, _: &Metadata) -> bool { false }
//! #   fn log(&self, _: &log::Record) {}
//! #   fn flush(&self) {}
//! # }
//! # fn main() {}
//! # #[cfg(feature = "std")]
//! pub fn init() -> Result<(), SetLoggerError> {
//!     log::set_boxed_logger(Box::new(SimpleLogger))
//!         .map(|()| log::set_max_level(LevelFilter::Info))
//! }
//! ```
//!
//! # Compile time filters
//!
//! Log levels can be statically disabled at compile time by enabling one of these Cargo features:
//!
//! * `max_level_off`
//! * `max_level_error`
//! * `max_level_warn`
//! * `max_level_info`
//! * `max_level_debug`
//! * `max_level_trace`
//!
//! Log invocations at disabled levels will be skipped and will not even be present in the
//! resulting binary. These features control the value of the `STATIC_MAX_LEVEL` constant. The
//! logging macros check this value before logging a message. By default, no levels are disabled.
//!
//! It is possible to override this level for release builds only with the following features:
//!
//! * `release_max_level_off`
//! * `release_max_level_error`
//! * `release_max_level_warn`
//! * `release_max_level_info`
//! * `release_max_level_debug`
//! * `release_max_level_trace`
//!
//! Libraries should avoid using the max level features because they're global and can't be changed
//! once they're set.
//!
//! For example, a crate can disable trace level logs in debug builds and trace, debug, and info
//! level logs in release builds with the following configuration:
//!
//! ```toml
//! [dependencies]
//! log = { version = "0.4", features = ["max_level_debug", "release_max_level_warn"] }
//! ```
//! # Crate Feature Flags
//!
//! The following crate feature flags are available in addition to the filters. They are
//! configured in your `Cargo.toml`.
//!
//! * `std` allows use of `std` crate instead of the default `core`. Enables using `std::error` and
//! `set_boxed_logger` functionality.
//! * `serde` enables support for serialization and deserialization of `Level` and `LevelFilter`.
//!
//! ```toml
//! [dependencies]
//! log = { version = "0.4", features = ["std", "serde"] }
//! ```
//!
//! # Version compatibility
//!
//! The 0.3 and 0.4 versions of the `log` crate are almost entirely compatible. Log messages
//! made using `log` 0.3 will forward transparently to a logger implementation using `log` 0.4. Log
//! messages made using `log` 0.4 will forward to a logger implementation using `log` 0.3, but the
//! module path and file name information associated with the message will unfortunately be lost.
//!
//! [`Log`]: trait.Log.html
//! [level_link]: enum.Level.html
//! [filter_link]: enum.LevelFilter.html
//! [`set_logger`]: fn.set_logger.html
//! [`set_max_level`]: fn.set_max_level.html
//! [`try_set_logger_raw`]: fn.try_set_logger_raw.html
//! [`shutdown_logger_raw`]: fn.shutdown_logger_raw.html
//! [env_logger]: https://docs.rs/env_logger/*/env_logger/
//! [colog]: https://docs.rs/colog/*/colog/
//! [simple_logger]: https://github.com/borntyping/rust-simple_logger
//! [simplelog]: https://github.com/drakulix/simplelog.rs
//! [pretty_env_logger]: https://docs.rs/pretty_env_logger/*/pretty_env_logger/
//! [stderrlog]: https://docs.rs/stderrlog/*/stderrlog/
//! [flexi_logger]: https://docs.rs/flexi_logger/*/flexi_logger/
//! [call_logger]: https://docs.rs/call_logger/*/call_logger/
//! [syslog]: https://docs.rs/syslog/*/syslog/
//! [slog-stdlog]: https://docs.rs/slog-stdlog/*/slog_stdlog/
//! [log4rs]: https://docs.rs/log4rs/*/log4rs/
//! [fern]: https://docs.rs/fern/*/fern/
//! [systemd-journal-logger]: https://docs.rs/systemd-journal-logger/*/systemd_journal_logger/
//! [android_log]: https://docs.rs/android_log/*/android_log/
//! [win_dbg_logger]: https://docs.rs/win_dbg_logger/*/win_dbg_logger/
//! [db_logger]: https://docs.rs/db_logger/*/db_logger/
//! [log-to-defmt]: https://docs.rs/log-to-defmt/*/log_to_defmt/
//! [console_log]: https://docs.rs/console_log/*/console_log/
//! [structured-logger]: https://docs.rs/structured-logger/latest/structured_logger/
//! [logcontrol-log]: https://docs.rs/logcontrol-log/*/logcontrol_log/
//! [log_err]: https://docs.rs/log_err/*/log_err/
//! [log-reload]: https://docs.rs/log-reload/*/log_reload/

#![doc(
    html_logo_url = "https://www.rust-lang.org/logos/rust-logo-128x128-blk-v2.png",
    html_favicon_url = "https://www.rust-lang.org/favicon.ico",
    html_root_url = "https://docs.rs/log/0.4.22"
)]
#![warn(missing_docs)]
#![deny(missing_debug_implementations, unconditional_recursion)]
#![cfg_attr(all(not(feature = "std"), not(test)), no_std)]

#[cfg(any(
    all(feature = "max_level_off", feature = "max_level_error"),
    all(feature = "max_level_off", feature = "max_level_warn"),
    all(feature = "max_level_off", feature = "max_level_info"),
    all(feature = "max_level_off", feature = "max_level_debug"),
    all(feature = "max_level_off", feature = "max_level_trace"),
    all(feature = "max_level_error", feature = "max_level_warn"),
    all(feature = "max_level_error", feature = "max_level_info"),
    all(feature = "max_level_error", feature = "max_level_debug"),
    all(feature = "max_level_error", feature = "max_level_trace"),
    all(feature = "max_level_warn", feature = "max_level_info"),
    all(feature = "max_level_warn", feature = "max_level_debug"),
    all(feature = "max_level_warn", feature = "max_level_trace"),
    all(feature = "max_level_info", feature = "max_level_debug"),
    all(feature = "max_level_info", feature = "max_level_trace"),
    all(feature = "max_level_debug", feature = "max_level_trace"),
))]
compile_error!("multiple max_level_* features set");

#[rustfmt::skip]
#[cfg(any(
    all(feature = "release_max_level_off", feature = "release_max_level_error"),
    all(feature = "release_max_level_off", feature = "release_max_level_warn"),
    all(feature = "release_max_level_off", feature = "release_max_level_info"),
    all(feature = "release_max_level_off", feature = "release_max_level_debug"),
    all(feature = "release_max_level_off", feature = "release_max_level_trace"),
    all(feature = "release_max_level_error", feature = "release_max_level_warn"),
    all(feature = "release_max_level_error", feature = "release_max_level_info"),
    all(feature = "release_max_level_error", feature = "release_max_level_debug"),
    all(feature = "release_max_level_error", feature = "release_max_level_trace"),
    all(feature = "release_max_level_warn", feature = "release_max_level_info"),
    all(feature = "release_max_level_warn", feature = "release_max_level_debug"),
    all(feature = "release_max_level_warn", feature = "release_max_level_trace"),
    all(feature = "release_max_level_info", feature = "release_max_level_debug"),
    all(feature = "release_max_level_info", feature = "release_max_level_trace"),
    all(feature = "release_max_level_debug", feature = "release_max_level_trace"),
))]
compile_error!("multiple release_max_level_* features set");

#[cfg(all(not(feature = "std"), not(test)))]
extern crate core as std;

use std::cfg;
#[cfg(feature = "std")]
use std::error;
use std::str::FromStr;
use std::{cmp, fmt, mem};

#[macro_use]
mod macros;
mod serde;

#[cfg(feature = "kv")]
pub mod kv;

#[cfg(target_has_atomic = "ptr")]
use std::sync::atomic::{AtomicUsize, Ordering};

#[cfg(not(target_has_atomic = "ptr"))]
use std::cell::Cell;
#[cfg(not(target_has_atomic = "ptr"))]
use std::sync::atomic::Ordering;

#[cfg(not(target_has_atomic = "ptr"))]
struct AtomicUsize {
    v: Cell<usize>,
}

#[cfg(not(target_has_atomic = "ptr"))]
impl AtomicUsize {
    const fn new(v: usize) -> AtomicUsize {
        AtomicUsize { v: Cell::new(v) }
    }

    fn load(&self, _order: Ordering) -> usize {
        self.v.get()
    }

    fn store(&self, val: usize, _order: Ordering) {
        self.v.set(val)
    }

    #[cfg(target_has_atomic = "ptr")]
    fn compare_exchange(
        &self,
        current: usize,
        new: usize,
        _success: Ordering,
        _failure: Ordering,
    ) -> Result<usize, usize> {
        let prev = self.v.get();
        if current == prev {
            self.v.set(new);
        }
        Ok(prev)
    }
}

// Any platform without atomics is unlikely to have multiple cores, so
// writing via Cell will not be a race condition.
#[cfg(not(target_has_atomic = "ptr"))]
unsafe impl Sync for AtomicUsize {}

// The LOGGER static holds a pointer to the global logger. It is protected by
// the STATE static which determines whether LOGGER has been initialized yet.
static mut LOGGER: &dyn Log = &NopLogger;

static STATE: AtomicUsize = AtomicUsize::new(0);

// There are three different states that we care about: the logger's
// uninitialized, the logger's initializing (set_logger's been called but
// LOGGER hasn't actually been set yet), or the logger's active.
const UNINITIALIZED: usize = 0;
const INITIALIZING: usize = 1;
const INITIALIZED: usize = 2;

static MAX_LOG_LEVEL_FILTER: AtomicUsize = AtomicUsize::new(0);

static LOG_LEVEL_NAMES: [&str; 6] = ["OFF", "ERROR", "WARN", "INFO", "DEBUG", "TRACE"];

static SET_LOGGER_ERROR: &str = "attempted to set a logger after the logging system \
                                 was already initialized";
static LEVEL_PARSE_ERROR: &str =
    "attempted to convert a string that doesn't match an existing log level";

/// An enum representing the available verbosity levels of the logger.
///
/// Typical usage includes: checking if a certain `Level` is enabled with
/// [`log_enabled!`](macro.log_enabled.html), specifying the `Level` of
/// [`log!`](macro.log.html), and comparing a `Level` directly to a
/// [`LevelFilter`](enum.LevelFilter.html).
#[repr(usize)]
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Debug, Hash)]
pub enum Level {
    /// The "error" level.
    ///
    /// Designates very serious errors.
    // This way these line up with the discriminants for LevelFilter below
    // This works because Rust treats field-less enums the same way as C does:
    // https://doc.rust-lang.org/reference/items/enumerations.html#custom-discriminant-values-for-field-less-enumerations
    Error = 1,
    /// The "warn" level.
    ///
    /// Designates hazardous situations.
    Warn,
    /// The "info" level.
    ///
    /// Designates useful information.
    Info,
    /// The "debug" level.
    ///
    /// Designates lower priority information.
    Debug,
    /// The "trace" level.
    ///
    /// Designates very low priority, often extremely verbose, information.
    Trace,
}

impl PartialEq<LevelFilter> for Level {
    #[inline]
    fn eq(&self, other: &LevelFilter) -> bool {
        *self as usize == *other as usize
    }
}

impl PartialOrd<LevelFilter> for Level {
    #[inline]
    fn partial_cmp(&self, other: &LevelFilter) -> Option<cmp::Ordering> {
        Some((*self as usize).cmp(&(*other as usize)))
    }
}

impl FromStr for Level {
    type Err = ParseLevelError;
    fn from_str(level: &str) -> Result<Level, Self::Err> {
        LOG_LEVEL_NAMES
            .iter()
            .position(|&name| name.eq_ignore_ascii_case(level))
            .into_iter()
            .filter(|&idx| idx != 0)
            .map(|idx| Level::from_usize(idx).unwrap())
            .next()
            .ok_or(ParseLevelError(()))
    }
}

impl fmt::Display for Level {
    fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
        fmt.pad(self.as_str())
    }
}

impl Level {
    fn from_usize(u: usize) -> Option<Level> {
        match u {
            1 => Some(Level::Error),
            2 => Some(Level::Warn),
            3 => Some(Level::Info),
            4 => Some(Level::Debug),
            5 => Some(Level::Trace),
            _ => None,
        }
    }

    /// Returns the most verbose logging level.
    #[inline]
    pub fn max() -> Level {
        Level::Trace
    }

    /// Converts the `Level` to the equivalent `LevelFilter`.
    #[inline]
    pub fn to_level_filter(&self) -> LevelFilter {
        LevelFilter::from_usize(*self as usize).unwrap()
    }

    /// Returns the string representation of the `Level`.
    ///
    /// This returns the same string as the `fmt::Display` implementation.
    pub fn as_str(&self) -> &'static str {
        LOG_LEVEL_NAMES[*self as usize]
    }

    /// Iterate through all supported logging levels.
    ///
    /// The order of iteration is from more severe to less severe log messages.
    ///
    /// # Examples
    ///
    /// ```
    /// use log::Level;
    ///
    /// let mut levels = Level::iter();
    ///
    /// assert_eq!(Some(Level::Error), levels.next());
    /// assert_eq!(Some(Level::Trace), levels.last());
    /// ```
    pub fn iter() -> impl Iterator<Item = Self> {
        (1..6).map(|i| Self::from_usize(i).unwrap())
    }
}

/// An enum representing the available verbosity level filters of the logger.
///
/// A `LevelFilter` may be compared directly to a [`Level`]. Use this type
/// to get and set the maximum log level with [`max_level()`] and [`set_max_level`].
///
/// [`Level`]: enum.Level.html
/// [`max_level()`]: fn.max_level.html
/// [`set_max_level`]: fn.set_max_level.html
#[repr(usize)]
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Debug, Hash)]
pub enum LevelFilter {
    /// A level lower than all log levels.
    Off,
    /// Corresponds to the `Error` log level.
    Error,
    /// Corresponds to the `Warn` log level.
    Warn,
    /// Corresponds to the `Info` log level.
    Info,
    /// Corresponds to the `Debug` log level.
    Debug,
    /// Corresponds to the `Trace` log level.
    Trace,
}

impl PartialEq<Level> for LevelFilter {
    #[inline]
    fn eq(&self, other: &Level) -> bool {
        other.eq(self)
    }
}

impl PartialOrd<Level> for LevelFilter {
    #[inline]
    fn partial_cmp(&self, other: &Level) -> Option<cmp::Ordering> {
        Some((*self as usize).cmp(&(*other as usize)))
    }
}

impl FromStr for LevelFilter {
    type Err = ParseLevelError;
    fn from_str(level: &str) -> Result<LevelFilter, Self::Err> {
        LOG_LEVEL_NAMES
            .iter()
            .position(|&name| name.eq_ignore_ascii_case(level))
            .map(|p| LevelFilter::from_usize(p).unwrap())
            .ok_or(ParseLevelError(()))
    }
}

impl fmt::Display for LevelFilter {
    fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
        fmt.pad(self.as_str())
    }
}

impl LevelFilter {
    fn from_usize(u: usize) -> Option<LevelFilter> {
        match u {
            0 => Some(LevelFilter::Off),
            1 => Some(LevelFilter::Error),
            2 => Some(LevelFilter::Warn),
            3 => Some(LevelFilter::Info),
            4 => Some(LevelFilter::Debug),
            5 => Some(LevelFilter::Trace),
            _ => None,
        }
    }

    /// Returns the most verbose logging level filter.
    #[inline]
    pub fn max() -> LevelFilter {
        LevelFilter::Trace
    }

    /// Converts `self` to the equivalent `Level`.
    ///
    /// Returns `None` if `self` is `LevelFilter::Off`.
    #[inline]
    pub fn to_level(&self) -> Option<Level> {
        Level::from_usize(*self as usize)
    }

    /// Returns the string representation of the `LevelFilter`.
    ///
    /// This returns the same string as the `fmt::Display` implementation.
    pub fn as_str(&self) -> &'static str {
        LOG_LEVEL_NAMES[*self as usize]
    }

    /// Iterate through all supported filtering levels.
    ///
    /// The order of iteration is from less to more verbose filtering.
    ///
    /// # Examples
    ///
    /// ```
    /// use log::LevelFilter;
    ///
    /// let mut levels = LevelFilter::iter();
    ///
    /// assert_eq!(Some(LevelFilter::Off), levels.next());
    /// assert_eq!(Some(LevelFilter::Trace), levels.last());
    /// ```
    pub fn iter() -> impl Iterator<Item = Self> {
        (0..6).map(|i| Self::from_usize(i).unwrap())
    }
}

#[derive(Copy, Clone, Eq, PartialEq, Ord, PartialOrd, Hash, Debug)]
enum MaybeStaticStr<'a> {
    Static(&'static str),
    Borrowed(&'a str),
}

impl<'a> MaybeStaticStr<'a> {
    #[inline]
    fn get(&self) -> &'a str {
        match *self {
            MaybeStaticStr::Static(s) => s,
            MaybeStaticStr::Borrowed(s) => s,
        }
    }
}

/// The "payload" of a log message.
///
/// # Use
///
/// `Record` structures are passed as parameters to the [`log`][method.log]
/// method of the [`Log`] trait. Logger implementors manipulate these
/// structures in order to display log messages. `Record`s are automatically
/// created by the [`log!`] macro and so are not seen by log users.
///
/// Note that the [`level()`] and [`target()`] accessors are equivalent to
/// `self.metadata().level()` and `self.metadata().target()` respectively.
/// These methods are provided as a convenience for users of this structure.
///
/// # Example
///
/// The following example shows a simple logger that displays the level,
/// module path, and message of any `Record` that is passed to it.
///
/// ```
/// struct SimpleLogger;
///
/// impl log::Log for SimpleLogger {
///    fn enabled(&self, _metadata: &log::Metadata) -> bool {
///        true
///    }
///
///    fn log(&self, record: &log::Record) {
///        if !self.enabled(record.metadata()) {
///            return;
///        }
///
///        println!("{}:{} -- {}",
///                 record.level(),
///                 record.target(),
///                 record.args());
///    }
///    fn flush(&self) {}
/// }
/// ```
///
/// [method.log]: trait.Log.html#tymethod.log
/// [`Log`]: trait.Log.html
/// [`log!`]: macro.log.html
/// [`level()`]: struct.Record.html#method.level
/// [`target()`]: struct.Record.html#method.target
#[derive(Clone, Debug)]
pub struct Record<'a> {
    metadata: Metadata<'a>,
    args: fmt::Arguments<'a>,
    module_path: Option<MaybeStaticStr<'a>>,
    file: Option<MaybeStaticStr<'a>>,
    line: Option<u32>,
    #[cfg(feature = "kv")]
    key_values: KeyValues<'a>,
}

// This wrapper type is only needed so we can
// `#[derive(Debug)]` on `Record`. It also
// provides a useful `Debug` implementation for
// the underlying `Source`.
#[cfg(feature = "kv")]
#[derive(Clone)]
struct KeyValues<'a>(&'a dyn kv::Source);

#[cfg(feature = "kv")]
impl<'a> fmt::Debug for KeyValues<'a> {
    fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
        let mut visitor = f.debug_map();
        self.0.visit(&mut visitor).map_err(|_| fmt::Error)?;
        visitor.finish()
    }
}

impl<'a> Record<'a> {
    /// Returns a new builder.
    #[inline]
    pub fn builder() -> RecordBuilder<'a> {
        RecordBuilder::new()
    }

    /// The message body.
    #[inline]
    pub fn args(&self) -> &fmt::Arguments<'a> {
        &self.args
    }

    /// Metadata about the log directive.
    #[inline]
    pub fn metadata(&self) -> &Metadata<'a> {
        &self.metadata
    }

    /// The verbosity level of the message.
    #[inline]
    pub fn level(&self) -> Level {
        self.metadata.level()
    }

    /// The name of the target of the directive.
    #[inline]
    pub fn target(&self) -> &'a str {
        self.metadata.target()
    }

    /// The module path of the message.
    #[inline]
    pub fn module_path(&self) -> Option<&'a str> {
        self.module_path.map(|s| s.get())
    }

    /// The module path of the message, if it is a `'static` string.
    #[inline]
    pub fn module_path_static(&self) -> Option<&'static str> {
        match self.module_path {
            Some(MaybeStaticStr::Static(s)) => Some(s),
            _ => None,
        }
    }

    /// The source file containing the message.
    #[inline]
    pub fn file(&self) -> Option<&'a str> {
        self.file.map(|s| s.get())
    }

    /// The source file containing the message, if it is a `'static` string.
    #[inline]
    pub fn file_static(&self) -> Option<&'static str> {
        match self.file {
            Some(MaybeStaticStr::Static(s)) => Some(s),
            _ => None,
        }
    }

    /// The line containing the message.
    #[inline]
    pub fn line(&self) -> Option<u32> {
        self.line
    }

    /// The structured key-value pairs associated with the message.
    #[cfg(feature = "kv")]
    #[inline]
    pub fn key_values(&self) -> &dyn kv::Source {
        self.key_values.0
    }

    /// Create a new [`RecordBuilder`](struct.RecordBuilder.html) based on this record.
    #[cfg(feature = "kv")]
    #[inline]
    pub fn to_builder(&self) -> RecordBuilder {
        RecordBuilder {
            record: Record {
                metadata: Metadata {
                    level: self.metadata.level,
                    target: self.metadata.target,
                },
                args: self.args,
                module_path: self.module_path,
                file: self.file,
                line: self.line,
                key_values: self.key_values.clone(),
            },
        }
    }
}

/// Builder for [`Record`](struct.Record.html).
///
/// Typically should only be used by log library creators or for testing and "shim loggers".
/// The `RecordBuilder` can set the different parameters of `Record` object, and returns
/// the created object when `build` is called.
///
/// # Examples
///
/// ```
/// use log::{Level, Record};
///
/// let record = Record::builder()
///                 .args(format_args!("Error!"))
///                 .level(Level::Error)
///                 .target("myApp")
///                 .file(Some("server.rs"))
///                 .line(Some(144))
///                 .module_path(Some("server"))
///                 .build();
/// ```
///
/// Alternatively, use [`MetadataBuilder`](struct.MetadataBuilder.html):
///
/// ```
/// use log::{Record, Level, MetadataBuilder};
///
/// let error_metadata = MetadataBuilder::new()
///                         .target("myApp")
///                         .level(Level::Error)
///                         .build();
///
/// let record = Record::builder()
///                 .metadata(error_metadata)
///                 .args(format_args!("Error!"))
///                 .line(Some(433))
///                 .file(Some("app.rs"))
///                 .module_path(Some("server"))
///                 .build();
/// ```
#[derive(Debug)]
pub struct RecordBuilder<'a> {
    record: Record<'a>,
}

impl<'a> RecordBuilder<'a> {
    /// Construct new `RecordBuilder`.
    ///
    /// The default options are:
    ///
    /// - `args`: [`format_args!("")`]
    /// - `metadata`: [`Metadata::builder().build()`]
    /// - `module_path`: `None`
    /// - `file`: `None`
    /// - `line`: `None`
    ///
    /// [`format_args!("")`]: https://doc.rust-lang.org/std/macro.format_args.html
    /// [`Metadata::builder().build()`]: struct.MetadataBuilder.html#method.build
    #[inline]
    pub fn new() -> RecordBuilder<'a> {
        RecordBuilder {
            record: Record {
                args: format_args!(""),
                metadata: Metadata::builder().build(),
                module_path: None,
                file: None,
                line: None,
                #[cfg(feature = "kv")]
                key_values: KeyValues(&None::<(kv::Key, kv::Value)>),
            },
        }
    }

    /// Set [`args`](struct.Record.html#method.args).
    #[inline]
    pub fn args(&mut self, args: fmt::Arguments<'a>) -> &mut RecordBuilder<'a> {
        self.record.args = args;
        self
    }

    /// Set [`metadata`](struct.Record.html#method.metadata). Construct a `Metadata` object with [`MetadataBuilder`](struct.MetadataBuilder.html).
    #[inline]
    pub fn metadata(&mut self, metadata: Metadata<'a>) -> &mut RecordBuilder<'a> {
        self.record.metadata = metadata;
        self
    }

    /// Set [`Metadata::level`](struct.Metadata.html#method.level).
    #[inline]
    pub fn level(&mut self, level: Level) -> &mut RecordBuilder<'a> {
        self.record.metadata.level = level;
        self
    }

    /// Set [`Metadata::target`](struct.Metadata.html#method.target)
    #[inline]
    pub fn target(&mut self, target: &'a str) -> &mut RecordBuilder<'a> {
        self.record.metadata.target = target;
        self
    }

    /// Set [`module_path`](struct.Record.html#method.module_path)
    #[inline]
    pub fn module_path(&mut self, path: Option<&'a str>) -> &mut RecordBuilder<'a> {
        self.record.module_path = path.map(MaybeStaticStr::Borrowed);
        self
    }

    /// Set [`module_path`](struct.Record.html#method.module_path) to a `'static` string
    #[inline]
    pub fn module_path_static(&mut self, path: Option<&'static str>) -> &mut RecordBuilder<'a> {
        self.record.module_path = path.map(MaybeStaticStr::Static);
        self
    }

    /// Set [`file`](struct.Record.html#method.file)
    #[inline]
    pub fn file(&mut self, file: Option<&'a str>) -> &mut RecordBuilder<'a> {
        self.record.file = file.map(MaybeStaticStr::Borrowed);
        self
    }

    /// Set [`file`](struct.Record.html#method.file) to a `'static` string.
    #[inline]
    pub fn file_static(&mut self, file: Option<&'static str>) -> &mut RecordBuilder<'a> {
        self.record.file = file.map(MaybeStaticStr::Static);
        self
    }

    /// Set [`line`](struct.Record.html#method.line)
    #[inline]
    pub fn line(&mut self, line: Option<u32>) -> &mut RecordBuilder<'a> {
        self.record.line = line;
        self
    }

    /// Set [`key_values`](struct.Record.html#method.key_values)
    #[cfg(feature = "kv")]
    #[inline]
    pub fn key_values(&mut self, kvs: &'a dyn kv::Source) -> &mut RecordBuilder<'a> {
        self.record.key_values = KeyValues(kvs);
        self
    }

    /// Invoke the builder and return a `Record`
    #[inline]
    pub fn build(&self) -> Record<'a> {
        self.record.clone()
    }
}

impl<'a> Default for RecordBuilder<'a> {
    fn default() -> Self {
        Self::new()
    }
}

/// Metadata about a log message.
///
/// # Use
///
/// `Metadata` structs are created when users of the library use
/// logging macros.
///
/// They are consumed by implementations of the `Log` trait in the
/// `enabled` method.
///
/// `Record`s use `Metadata` to determine the log message's severity
/// and target.
///
/// Users should use the `log_enabled!` macro in their code to avoid
/// constructing expensive log messages.
///
/// # Examples
///
/// ```
/// use log::{Record, Level, Metadata};
///
/// struct MyLogger;
///
/// impl log::Log for MyLogger {
///     fn enabled(&self, metadata: &Metadata) -> bool {
///         metadata.level() <= Level::Info
///     }
///
///     fn log(&self, record: &Record) {
///         if self.enabled(record.metadata()) {
///             println!("{} - {}", record.level(), record.args());
///         }
///     }
///     fn flush(&self) {}
/// }
///
/// # fn main(){}
/// ```
#[derive(Clone, Eq, PartialEq, Ord, PartialOrd, Hash, Debug)]
pub struct Metadata<'a> {
    level: Level,
    target: &'a str,
}

impl<'a> Metadata<'a> {
    /// Returns a new builder.
    #[inline]
    pub fn builder() -> MetadataBuilder<'a> {
        MetadataBuilder::new()
    }

    /// The verbosity level of the message.
    #[inline]
    pub fn level(&self) -> Level {
        self.level
    }

    /// The name of the target of the directive.
    #[inline]
    pub fn target(&self) -> &'a str {
        self.target
    }
}

/// Builder for [`Metadata`](struct.Metadata.html).
///
/// Typically should only be used by log library creators or for testing and "shim loggers".
/// The `MetadataBuilder` can set the different parameters of a `Metadata` object, and returns
/// the created object when `build` is called.
///
/// # Example
///
/// ```
/// let target = "myApp";
/// use log::{Level, MetadataBuilder};
/// let metadata = MetadataBuilder::new()
///                     .level(Level::Debug)
///                     .target(target)
///                     .build();
/// ```
#[derive(Eq, PartialEq, Ord, PartialOrd, Hash, Debug)]
pub struct MetadataBuilder<'a> {
    metadata: Metadata<'a>,
}

impl<'a> MetadataBuilder<'a> {
    /// Construct a new `MetadataBuilder`.
    ///
    /// The default options are:
    ///
    /// - `level`: `Level::Info`
    /// - `target`: `""`
    #[inline]
    pub fn new() -> MetadataBuilder<'a> {
        MetadataBuilder {
            metadata: Metadata {
                level: Level::Info,
                target: "",
            },
        }
    }

    /// Setter for [`level`](struct.Metadata.html#method.level).
    #[inline]
    pub fn level(&mut self, arg: Level) -> &mut MetadataBuilder<'a> {
        self.metadata.level = arg;
        self
    }

    /// Setter for [`target`](struct.Metadata.html#method.target).
    #[inline]
    pub fn target(&mut self, target: &'a str) -> &mut MetadataBuilder<'a> {
        self.metadata.target = target;
        self
    }

    /// Returns a `Metadata` object.
    #[inline]
    pub fn build(&self) -> Metadata<'a> {
        self.metadata.clone()
    }
}

impl<'a> Default for MetadataBuilder<'a> {
    fn default() -> Self {
        Self::new()
    }
}

/// A trait encapsulating the operations required of a logger.
pub trait Log: Sync + Send {
    /// Determines if a log message with the specified metadata would be
    /// logged.
    ///
    /// This is used by the `log_enabled!` macro to allow callers to avoid
    /// expensive computation of log message arguments if the message would be
    /// discarded anyway.
    ///
    /// # For implementors
    ///
    /// This method isn't called automatically by the `log!` macros.
    /// It's up to an implementation of the `Log` trait to call `enabled` in its own
    /// `log` method implementation to guarantee that filtering is applied.
    fn enabled(&self, metadata: &Metadata) -> bool;

    /// Logs the `Record`.
    ///
    /// # For implementors
    ///
    /// Note that `enabled` is *not* necessarily called before this method.
    /// Implementations of `log` should perform all necessary filtering
    /// internally.
    fn log(&self, record: &Record);

    /// Flushes any buffered records.
    ///
    /// # For implementors
    ///
    /// This method isn't called automatically by the `log!` macros.
    /// It can be called manually on shut-down to ensure any in-flight records are flushed.
    fn flush(&self);
}

// Just used as a dummy initial value for LOGGER
struct NopLogger;

impl Log for NopLogger {
    fn enabled(&self, _: &Metadata) -> bool {
        false
    }

    fn log(&self, _: &Record) {}
    fn flush(&self) {}
}

impl<T> Log for &'_ T
where
    T: ?Sized + Log,
{
    fn enabled(&self, metadata: &Metadata) -> bool {
        (**self).enabled(metadata)
    }

    fn log(&self, record: &Record) {
        (**self).log(record);
    }
    fn flush(&self) {
        (**self).flush();
    }
}

#[cfg(feature = "std")]
impl<T> Log for std::boxed::Box<T>
where
    T: ?Sized + Log,
{
    fn enabled(&self, metadata: &Metadata) -> bool {
        self.as_ref().enabled(metadata)
    }

    fn log(&self, record: &Record) {
        self.as_ref().log(record);
    }
    fn flush(&self) {
        self.as_ref().flush();
    }
}

#[cfg(feature = "std")]
impl<T> Log for std::sync::Arc<T>
where
    T: ?Sized + Log,
{
    fn enabled(&self, metadata: &Metadata) -> bool {
        self.as_ref().enabled(metadata)
    }

    fn log(&self, record: &Record) {
        self.as_ref().log(record);
    }
    fn flush(&self) {
        self.as_ref().flush();
    }
}

/// Sets the global maximum log level.
///
/// Generally, this should only be called by the active logging implementation.
///
/// Note that `Trace` is the maximum level, because it provides the maximum amount of detail in the emitted logs.
#[inline]
#[cfg(target_has_atomic = "ptr")]
pub fn set_max_level(level: LevelFilter) {
    MAX_LOG_LEVEL_FILTER.store(level as usize, Ordering::Relaxed);
}

/// A thread-unsafe version of [`set_max_level`].
///
/// This function is available on all platforms, even those that do not have
/// support for atomics that is needed by [`set_max_level`].
///
/// In almost all cases, [`set_max_level`] should be preferred.
///
/// # Safety
///
/// This function is only safe to call when it cannot race with any other
/// calls to `set_max_level` or `set_max_level_racy`.
///
/// This can be upheld by (for example) making sure that **there are no other
/// threads**, and (on embedded) that **interrupts are disabled**.
///
/// It is safe to use all other logging functions while this function runs
/// (including all logging macros).
///
/// [`set_max_level`]: fn.set_max_level.html
#[inline]
pub unsafe fn set_max_level_racy(level: LevelFilter) {
    // `MAX_LOG_LEVEL_FILTER` uses a `Cell` as the underlying primitive when a
    // platform doesn't support `target_has_atomic = "ptr"`, so even though this looks the same
    // as `set_max_level` it may have different safety properties.
    MAX_LOG_LEVEL_FILTER.store(level as usize, Ordering::Relaxed);
}

/// Returns the current maximum log level.
///
/// The [`log!`], [`error!`], [`warn!`], [`info!`], [`debug!`], and [`trace!`] macros check
/// this value and discard any message logged at a higher level. The maximum
/// log level is set by the [`set_max_level`] function.
///
/// [`log!`]: macro.log.html
/// [`error!`]: macro.error.html
/// [`warn!`]: macro.warn.html
/// [`info!`]: macro.info.html
/// [`debug!`]: macro.debug.html
/// [`trace!`]: macro.trace.html
/// [`set_max_level`]: fn.set_max_level.html
#[inline(always)]
pub fn max_level() -> LevelFilter {
    // Since `LevelFilter` is `repr(usize)`,
    // this transmute is sound if and only if `MAX_LOG_LEVEL_FILTER`
    // is set to a usize that is a valid discriminant for `LevelFilter`.
    // Since `MAX_LOG_LEVEL_FILTER` is private, the only time it's set
    // is by `set_max_level` above, i.e. by casting a `LevelFilter` to `usize`.
    // So any usize stored in `MAX_LOG_LEVEL_FILTER` is a valid discriminant.
    unsafe { mem::transmute(MAX_LOG_LEVEL_FILTER.load(Ordering::Relaxed)) }
}

/// Sets the global logger t   seafetelFi as_ax_leveTER`      vel`] funcd);
}

//e set_max_level(level: Lev&which dtaks a /// ``fetelFi aracher lhan al `'static sog` .Set the `docuentation for
// /[`set_logger`]:for `ore vetail .
///
/// #Rquired the `Rtd` ceature 
///
/// # Exrors.///
/// Alnerror_ s returnsedif a log er ths already ieen set 
///
/// [`set_mogger`]: fn.set_logger.html
/[cfg(all(neature = "std") target:has_atomic = "ptr"))]
uub fn set_moxed_logger`(ogger`: feteyn Log > -> Result<L), retsogger xrors {
    fet_logger_rinnr(|&| fet:levak(ogger`))}

/// Sets the global logger t   sea'static sog` .///
/// This function iay hnly be called bo
//en the elietyie of tapropgram.Any pog
/// [ven t that iocurrbefore thi calleto `set_mogger`]compulees vill ne cgnore_d.///
/// This function ioesnnot htpically seedeto `e called manually  Logger /// impl mentations ohould peovidesan imitializetion fethod ihat isntatls toh
/// loggir imternally.
 //
/// # EAailabliliy
///
/// This fethod isnavailable oven then ahe `Rtd` ceature isnaisabled*. Howveri
///  t is aurrent y sunvailable on a`thumbv6`target:s&which dlacksupport for /// suoe otomic =perations rhich dre dsed by thes function . Een to those /// thrget:s&w`set_mogger`racy`.]vill ne cvailable 
///
/// # Exrors.///
/// Alnerror_ s returnsedif a log er ths already ieen set 
///
/// [ Examples
///
/// ```
/// use log::{Rrror_ infor&whrn,
 ecord, Level, Metadata},LevelFilter ;
///
/// strtic MAY_OGGER: &yLogger {=MyLogger;
///
/// itruct MyLogger;
///
/// impl log::Log for MyLogger {
///     fn enabled(&self, metadata: &Metadata) -> bool {
///         metadata.level() <= Level::Info
///     }
///
///     fn log(&self, record: &Record) {
///         if self.enabled(record.metadata()) {
///             println!("{} - {}", record.level(), record.args());
///         }
///     }
///     fn flush(&self) {}
/// }
///
/// # fn main(){}/// logg::et_mogger`(&AY_OGGER:.unwrap());/// logg::et_max_level()evelFilter::Info),
///
/// imfo!`("eldlologg");/// larn!`(warn"ng:");/// lrror!("moops");/// l#}
/// ```
///
/// [mset_mogger`racy`.] fn.set_logger.racy`html
/[cfg(aarget_has_atomic = "ptr")]
pub fn set_mogger`(ogger`: 'static syn Log  -> Result<L), retsogger xrors {
    fet_logger_rinnr(|&| ogger`)}

#[cfg(farget_has_atomic = "ptr")]
pn set_mogger`rinnr(<F>(akie_ogger`: F -> Result<L), retsogger xrors where
    TF: FnO
//( -> &'static syn Log 
{
    fatch sTATE:.ompare_exchange(
        &NINITIALIZED:
        }NITIALIZING:
        }rdering::RAcuired
        }rdering::Relaxed)
    ) -{        Ok(pNINITIALIZED: => S
             nsafe {                 tOGGER h= akie_ogger`);
        s   }
        O   SeATE:.tore(lNITIALIZED:
}rdering::Relaase_;
        s   }k(p))
         
        Oxro(NITIALIZING: => S
             hile teATE:.oad(Ordering::Relaxed))== *NITIALIZING:{                 ttd::shntl::epin_ogop);
        s   }
        O   Sxro(etsogger xrors()))
    }   }
        O => Nxro(etsogger xrors()))
,    }
}

/// A trread-unsafe version of [`set_mogger`]:
///
/// This function is available on all platforms, even those that do not have
/// support for atomics that is needed by [`set_mogger`]:
///
/// Tn almost all cases, [`set_mogger`]:fhould be preferred.
///
/// # Safety
///
/// This function is only safe to call when it cannot race with any other
/// calls to `set_mogger`]covel(level: Leracy`.
///
/// This can be upheld by (for example) making sure that **there are no other
/// threads**, and (on embedded) that **interrupts are disabled**.
///
/// It is safe to use ather logging functions while this function runs
/// (including all logging macros).
///
/// [`set_mogger`]: fn.set_logger.html
/ub unsafe fn set_mel: Leracy`(ogger`: 'static syn Log  -> Result<L), retsogger xrors {
    fatch sTATE:.oad(Ordering::RAcuired -{        ONINITIALIZED:=> S
             OGGER h= lgger;
/       O   SeATE:.tore(lNITIALIZED:
}rdering::Relaase_;
        s   }k(p))
         
        ONITIALIZING:{> S
             veTER`     jst ulatn tUB,vel
//e /e /e dacyng andther lmitializetion function              nseadhanled!"ser_mel: Leracy` mst uot be ased bith ather lmitializetion function s")    }   }
        O => Nxro(etsogger xrors()))
,    }
}

/// Ahe mype ieturnsediy [`set_mogger`]:if s`set_mogger`]:ihs already ieen salled.
///
/// #`set_mogger`]: fn.set_logger.html
/[cllow (misel
g_copy_mpl mentations ]
#[derive(Cebug)]
pub struct Metsogger xrors()));
impl fmt::Display for Letsogger xrors{
    fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
        fmt.pritiestr(&ET_LOGGER_ERROR:
    }
}

// Ahe mxrors{rait innnot hvailable oi linbores#[cfg(feature = "std")]
impl<lrror!:Error)for Letsogger xrors{


/// Ahe mype ieturnsediy [`srom_str(.]vien ahe `tring aoesn't match an yof the logglevels.
 //
/// #`srom_str(.] https://doc.rust-lang.org/std/mtr(/rait.LromStr html#tymethod.lrom_str(/[cllow (misel
g_copy_mpl mentations ]
#[derive(Cebug) PartialEq, Eq,]
pub struct MarseLevelError(()));
impl fmt::Display for LarseLevelError({
    fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
        fmt.pritiestr(&EVEL_PARSE_ERROR:
    }
}

// Ahe mxrors{rait innnot hvailable oi linbores#[cfg(feature = "std")]
impl<lrror!:Error)for LarseLevelError({


/// Returns ta eference/to the [ogger.
///
/// AI a log er ths aot be n set ,a neo-opimplementation ts returnsed.pub fn sogger`);-> &'static syn Log {
    // SAcuiredmem:oryorder ng auarantee  that iurrent mhreadswould bse any     // Sem:oryoritie that ihet_mnd before ttore(of the lalue     // isno `seATE:`bith aem:oryorder ng a`elaase_]covetr(ongr.
    #/
    ///Since `he lalue  `NITIALIZED: is arititn to y sfter t`OGGER_`was     // isntialized, toberveng imtsfter t`Acuired`load( ere amaks abthe    // iritieto the `TOGGER_`wtatic snd (mitializetion ff the logger.    // isnornallstates ync:h(onzed +ith aurrent mhreads
    #f sTATE:.oad(Ordering::RAcuired -!=INITIALIZED:{
        seatic sNOP:NopLogger {=NopLogger;

       &sNOP    }
 ls. {          nsafe { mOGGER h
    }
}

/// ARN"NG: utR`     ot bartiff the lcate 'spub lc sAPIsnd (m sauject wo caange(at a n time #[deoc(hidedn]
pub smod __rivate,_api;
/// Ahe meatic lly sresolvd manimum log level.
///
/// Tet the `cate level idocuentation for
information.on ahowto convfigue this 
///
/// This calue  i check
d by the aog mecros),but
aot beythe `Log` er {eturnsediy /// the c`log!er`]:fonction . Cde toat ianually oalls tunctions wo thot ialue  // suould bompare_the level, agasntathis value 
///
/// [`log!er`]: fn.sogger.html
/ub uonst ITATEIC_AX_LOVEL_ LevelFilter)h= akch afg(!(ebug_mssert_ons ]{
    fnlse
if cug(!(eature = "srlaase_max_level_roff" => SevelFilter::Off),    fnlse
if cug(!(eature = "srlaase_max_level_rrror"  => SevelFilter::Orror,
    /nlse
if cug(!(eature = "srlaase_max_level_rarn"  => SevelFilter::Oarn,
    /nlse
if cug(!(eature = "srlaase_max_level_rnfo"  => SevelFilter::Onfo,
     nlse
if cug(!(eature = "srlaase_max_level_rebug"  => SevelFilter::Oebug,
    /nlse
if cug(!(eature = "srlaase_max_level_rrace"  => SevelFilter::Orace,
}   O =f cug(!(eature = "sax_level_roff" => SevelFilter::Off),    f =f cug(!(eature = "sax_level_rrror"  => SevelFilter::Orror,
    / =f cug(!(eature = "sax_level_rarn"  => SevelFilter::Oarn,
    / =f cug(!(eature = "sax_level_rnfo"  => SevelFilter::Onfo,
      =f cug(!(eature = "sax_level_rebug"  => SevelFilter::Oebug,
    /_=> SevelFilter::Orace,
}}

#[cfg(festi]
pmod estis{
    fse asupr::OLevel, MevelFilter, SarseLevelError(,ITATEIC_AX_LOVEL_}

    /#[esti
    fn gestilevel_ilteri_rom_str(l){
        let mestis{= [             ("off",}k(pevelFilter::Off),,
            }(error" ,}k(pevelFilter::Orror)
,
            }(earn" ,}k(pevelFilter::Oarn),,
            }(enfo" ,}k(pevelFilter::Onfo),,
            }(eebug" ,}k(pevelFilter::Oebug)],
            }(erace" ,}k(pevelFilter::Orace),,
            }(eOFF",}k(pevelFilter::Off),,
            }(eRROR: ,}k(pevelFilter::Orror)
,
            }(eARN" ,}k(pevelFilter::Oarn),,
            }(eINFO ,}k(pevelFilter::Onfo),,
            }(eDEBUG ,}k(pevelFilter::Oebug)],
            }(eTRACE ,}k(pevelFilter::Orace),,
            }(easdf",}xro(arseLevelError(()))
,
         ]

       &or &'(s recfexpenctd) ti l&estis{
    f       arsert_eq!(Sxpenctd), &s.prseL));
    /   }
    }

    /#[esti
    fn gestilevel__rom_str(l){
        let mestis{= [             ("OFF",}xro(arseLevelError(()))
,
            }(error" ,}k(pevelF:Orror)
,
            }(earn" ,}k(pevelF:Oarn),,
            }(enfo" ,}k(pevelF:Onfo),,
            }(eebug" ,}k(pevelF:Oebug)],
            }(erace" ,}k(pevelF:Orace),,
            }(eRROR: ,}k(pevelF:Orror)
,
            }(eARN" ,}k(pevelF:Oarn),,
            }(eINFO ,}k(pevelF:Onfo),,
            }(eDEBUG ,}k(pevelF:Oebug)],
            }(eTRACE ,}k(pevelF:Orace),,
            }(easdf",}xro(arseLevelError(()))
,
         ]

       &or &'(s recfexpenctd) ti l&estis{
    f       arsert_eq!(Sxpenctd), &s.prseL));
    /   }
    }

    /#[esti
    fn gestilevel__s_str()){
        let mestis{= &[             (evelF:Orror), eRROR: ,
            }(evelF:Oarn), eARN" ,
            }(evelF:Onfo,
 eINFO ,
            }(evelF:Oebug) PeDEBUG ,
            }(evelF:Orace,
 eTRACE ,
         ]

       &or &(inpu ,axpenctd) ti lestis{
    f       arsert_eq!(S*xpenctd), inpu as_str())

    /   }
    }

    /#[esti
    fn gestilevel__hows)){
        lrsert_eq!(SeINFO ,}evelF:Onfo,.to_tring ))

    /   }rsert_eq!(SeRROR: ,}evelF:Orror).to_tring ))

    /}
    /#[esti
    fn gestilevel_ilteri_hows)){
        lrsert_eq!(SeOFF",}evelFilter::Off).to_tring ))

    /   }rsert_eq!(SeRROR: ,}evelFilter::Orror).to_tring ))

    /}
    /#[esti
    fn gestilros)scmp(&){
        lrsert_!(evelF:Oebug)  SevelFilter::Orror,

    /   }rsert_!pevelFilter::Oarn) <Level::Trace


    /   }rsert_!pevelFilter::Off) <Level::Trror,

    /}
    /#[esti
    fn gestilros)sceq&){
        lrsert_!(evelF:Orror({==SevelFilter::Orror,

    /   }rsert_!pevelFilter::Off) !=Level::Trror,

    /   lrsert_!(evelF:Orace
{==SevelFilter::Orace


    /}
    /#[esti
    fn gestilo_level(&){
        lrsert_eq!(Some(Level::Error), levelFilter::Orror).to_evel(&)

    /   }rsert_eq!(Sone,
}evelFilter::Off).to_evel(&)

    /   }rsert_eq!(Some(Level::Eebug),
SevelFilter::Oebug,.to_evel(&)

    /}
    /#[esti
    fn gestilo_level(filter(&){
        lrsert_eq!(SevelFilter::Orror,
}evelF:Orror).to_evel(filter(&)

    /   }rsert_eq!(SevelFilter::Orace,
Level::Trace
.to_evel(filter(&)

    /

    /#[esti
    fn gestilevel__rlteri_s_str()){
        let mestis{= &[             (evelFilter::Off), eOFF",
            }(evelFilter::Orror,
}eRROR: ,
            }(evelFilter::Oarn,
 eARN" ,
            }(evelFilter::Onfo,
 eINFO ,
            }(evelFilter::Oebug,
PeDEBUG ,
            }(evelFilter::Orace,
LeTRACE ,
         ]

       &or &(inpu ,axpenctd) ti lestis{
    f       arsert_eq!(S*xpenctd), inpu as_str())

    /   }
    }

    /#[esti
    f[cfg(_atr()not(ebug_mssert_ons ],cgnore_)
    fn gestileatic max_level_rebug")){
        lf cug(!(eature = "sax_level_roff" =
    f       arsert_eq!(STATEIC_AX_LOVEL_
}evelFilter::Off)

    /   }
 ls. {f cug(!(eature = "sax_level_rrror"  =
    f       arsert_eq!(STATEIC_AX_LOVEL_
}evelFilter::Orror,

    /   l
 ls. {f cug(!(eature = "sax_level_rarn"  =
    f       arsert_eq!(STATEIC_AX_LOVEL_
}evelFilter::Oarn),
    /   l
 ls. {f cug(!(eature = "sax_level_rnfo"  =
    f       arsert_eq!(STATEIC_AX_LOVEL_
}evelFilter::Onfo),
/   /   l
 ls. {f cug(!(eature = "sax_level_rebug"  =
    f       arsert_eq!(STATEIC_AX_LOVEL_
}evelFilter::Oebug),
/   /   l
 ls. {
    f       arsert_eq!(STATEIC_AX_LOVEL_
}evelFilter::Orace


    /   }
    }

    /#[esti
    f[cfg(_atr()ebug_mssert_ons ,cgnore_)
    fn gestileatic max_level_rrlaase_)){
        lf cug(!(eature = "srlaase_max_level_roff" =
    f       arsert_eq!(STATEIC_AX_LOVEL_
}evelFilter::Off)

    /   }
 ls. {f cug(!(eature = "srlaase_max_level_rrror"  =
    f       arsert_eq!(STATEIC_AX_LOVEL_
}evelFilter::Orror,

    /   l
 ls. {f cug(!(eature = "srlaase_max_level_rarn"  =
    f       arsert_eq!(STATEIC_AX_LOVEL_
}evelFilter::Oarn),
    /   l
 ls. {f cug(!(eature = "srlaase_max_level_rnfo"  =
    f       arsert_eq!(STATEIC_AX_LOVEL_
}evelFilter::Onfo),
/   /   l
 ls. {f cug(!(eature = "srlaase_max_level_rebug"  =
    f       arsert_eq!(STATEIC_AX_LOVEL_
}evelFilter::Oebug),
/   /   l
 ls. {f cug(!(eature = "srlaase_max_level_rrace"  =
    f       arsert_eq!(STATEIC_AX_LOVEL_
}evelFilter::Orace


    /   }
 ls. {f cug(!(eature = "sax_level_roff" =
    f       arsert_eq!(STATEIC_AX_LOVEL_
}evelFilter::Off)

    /   }
 ls. {f cug(!(eature = "sax_level_rrror"  =
    f       arsert_eq!(STATEIC_AX_LOVEL_
}evelFilter::Orror,

    /   l
 ls. {f cug(!(eature = "sax_level_rarn"  =
    f       arsert_eq!(STATEIC_AX_LOVEL_
}evelFilter::Oarn),
    /   l
 ls. {f cug(!(eature = "sax_level_rnfo"  =
    f       arsert_eq!(STATEIC_AX_LOVEL_
}evelFilter::Onfo),
/   /   l
 ls. {f cug(!(eature = "sax_level_rebug"  =
    f       arsert_eq!(STATEIC_AX_LOVEL_
}evelFilter::Oebug),
/   /   l
 ls. {
    f       arsert_eq!(STATEIC_AX_LOVEL_
}evelFilter::Orace


    /   }
    }

    /#[esti
    f[cfg(feature = "std")]
i   fn gestilrror_mrait )){
        lse asupr::Oetsogger xrors;        let me= Selsogger xrors()));
       arsert_eq!(S    f       a&e.to_tring ))
            }"ttermptdeto `et t log er tfter the loggeng suysem =\              ws already isntialized,"         

    /

    /#[esti
    fn gestiletadata(_uilder() -
        lse asupr::OetadataBuilder<;        let marget = "myApp";
/       let mutadata(_esti= MetadataBuilder::new()
/           .level(Level::Debug)
/           .target(target)
/           .build();
/       arsert_eq!(Sutadata(_estilevel(), revel::Debug)

/       arsert_eq!(Sutadata(_estilarget(),
"myApp";

    /

    /#[esti
    fn gestiletadata(_ncd);
}

//_uilder() -
        lse asupr::OetadataB;        let marget = "myApp";
/       let mutadata(_esti= MetadataB:builder()
/           .level(Level::Debug)
/           .target(target)
/           .build();
/       arsert_eq!(Sutadata(_estilevel(), revel::Debug)

/       arsert_eq!(Sutadata(_estilarget(),
"myApp";

    /

    /#[esti
    fn gestilecord._uilder() -
        lse asupr::O{etadataBuilder:,RecordBuilder<};        let marget = "myApp";
/       let mutadata(= MetadataBuilder::new()
target(target)
build();
/       aet mfm_args!= firmat_args!(""eldlo";
/       aet mecord._esti= MecordBuilder::new()
    }       .args(fom_args!
    }       .aetadata()etadata)
    }       .module_path(Some("sfoo")
    }       .mile(Some("abar")
    }       .mine(Some(430)
/           .build();
/       arsert_eq!(Secord._estimetadata().target()`
"myApp";

    /   arsert_eq!(Secord._estimedule_path(S, reme("sfoo")

    /   arsert_eq!(Secord._estimile(S, reme("sbar")

    /   arsert_eq!(Secord._estimine(S, reme("30)

    /

    /#[esti
    fn gestilecord._ncd);
}

//_uilder() -
        lse asupr::O{etadata},Lecord};
/       let marget = "myApp";
/       let mutadata(= MetadataB:builder().barget(target)
build();
/       aet mfm_args!= firmat_args!(""eldlo";
/       aet mecord._esti= MecordB:builder()
/           .lrgs(fom_args!
    }       .aetadata()etadata)
    }       .module_path(Some("sfoo")
    }       .mile(Some("abar")
    }       .mine(Some(430)
/           .build();
/       arsert_eq!(Secord._estimarget()`
"myApp";

    /   arsert_eq!(Secord._estimedule_path(S, reme("sfoo")

    /   arsert_eq!(Secord._estimile(S, reme("sbar")

    /   arsert_eq!(Secord._estimine(S, reme("30)

    /

    /#[esti
    fn gestilecord._ncpulees_uilder() -
        lse asupr::O{evel, Record};
/       let marget = "myApp";
/       let mecord._esti= MecordB:builder()
/           .lodule_path(Some("sfoo")
    }       .mile(Some("abar")
    }       .mine(Some(430)
/           .barget(target)
/           .bevel(Level::Error)
/           .build();
/       arsert_eq!(Secord._estimarget()`
"myApp";

    /   arsert_eq!(Secord._estimevel(), revel::Drror,

    /   lrsert_eq!(Secord._estimedule_path(S, reme("sfoo")

    /   arsert_eq!(Secord._estimile(S, reme("sbar")

    /   arsert_eq!(Secord._estimine(S, reme("30)

    /

    /#[esti
    f[cfg(feature = "kv")]
    #n gestilecord._ey_values _uilder() -
        lse asupr::OecordB;        lse acate ::v::S{elf, fVsitoource)}

    /   seauct MTstiVsitoource){
    f       aseen_airs :usize,     /   }
         lfpl<'akvs>fVsitoource)'akvs>for &TstiVsitoource){
    f       an gisito_airs(                tmut self,                 t_: v::Key,'akvs>                 t_: v::Kalues'akvs>               -> Result<L), rv::Kxrors {
    f   f       aself.seen_airs  += 1;    f   f       ak(p))
            }
        O
         let mvs: &'[(&tr,
 i32)]{= &[("a", 1, r"sb", 2)]
/       let mecord._esti= MecordB:builder()
.ey_values(&mvs);build();
//       let mut sisitor.= MTstiVsitoource){
aseen_airs :u0 }

    /   secord._estimey_values(&).isito&mut sisitor..unwrap());/    /   arsert_eq!(S2,sisitor..seen_airs 

    /

    /#[esti
    f[cfg(feature = "kv")]
    #n gestilecord._ey_values _et_hcoerce) -
        lse asupr::OecordB;         let mvs: &'[(&tr,
 &tr,)]{= &[("a", "1", r"sb", "2")]
/       let mecord.= MecordB:builder()
.ey_values(&mvs);build();
//       lrsert_eq!(S    f       a"2",            record:    f   f       amey_values(&)    f   f       amet("mb".sno ))
            }   amxpenct("misel
gkey_"
            }   amo_burrowed)str())            }   amxpenct("inalid dalues"
         

    /

    // Thetathia the d`mpl Log for NFoo` blocks work
    veTER`  esti=ost y oneratie wo tamype ievel, bso failurs vill ne cncpule terors./   /#[esti
    fn gestilore ign_mpl ) -
        lse asupr::Oog 
/       l[cfg(feature = "std")]
i   f   lse asd::sync::Arc<
//       ln arsert_eislogg<T:Log f+?Sized >( {}
//       lrsert_eislogg::<&yn Log >);
//       l[cfg(feature = "std")]
i   f   lrsert_eislogg::<feteyn Log >>);
//       l[cfg(feature = "std")]
i   f   lrsert_eislogg::<rc<Tyn Log >>);
//       l/ SAsert_the s meatieents ior atl nT:Log f+?Sized /       l[cllow (unsed ]
i   f   lf for
llo<T:Log f+?Sized >( {}
           #[cfg(feature = "ktd")]
i   f   l   lrsert_eislogg::<feteT>>);
//       l   lrsert_eislogg::<&T>);
//       l   l[cfg(feature = "ktd")]
i   f   l   lrsert_eislogg::<rc<T>
>(

    /   }
    }

}