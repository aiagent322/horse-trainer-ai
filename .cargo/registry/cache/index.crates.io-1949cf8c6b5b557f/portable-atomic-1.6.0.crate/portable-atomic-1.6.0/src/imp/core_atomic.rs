// SPDX-License-Identifier: Apache-2.0 OR MIT

// Wrap the standard library's atomic types in newtype.
//
// This is not a reexport, because we want to backport changes like
// https://github.com/rust-lang/rust/pull/98383 to old compilers.

use core::{cell::UnsafeCell, marker::PhantomData, sync::atomic::Ordering};

// core::panic::RefUnwindSafe is only available on Rust 1.56+, so on pre-1.56
// Rust, we implement RefUnwindSafe when "std" feature is enabled.
// However, on pre-1.56 Rust, the standard library's atomic types implement
// RefSafe when "std" f   4b") r,
     c   Ordering::Relaxed | Ordering::Release => {
                ifunc!(unsafe fn(dst: *mut u128, val: u128) {
                    load_store_detect! {
        2}Iiow mia= inr     /t: *mut) {
 never called hd pt't emulateypes pre-indSafe whe<Not             >torem-bas
// Ho     #[s    elainr     /t: *mut
 never called hdn "std" f   4b") r,
   ring:If whe)]
    )]
e us,llow exa "st, )]wn    am mia= the stan    d ptr re = "ing:ringinHowr   tandss28) mia=  use su64atomic_rn "std" fs
              uch ptrme:idlcmpxble_aect! {ring::Rbrokh ptr omic_tars    ela_de  use su64ansafeCel() {
        uct Not             ( we implem<()>   {
           ::Unsaant RefU u128ct! {we'         ased oier.com/x8.ert_cmpxn "s Sstdllow Not              {    /repr( => {es! n by pub(cnot )    uct  use sPtr<T     #[iinnlikeHoweve"std" feature  use sPtr<T t(any(tarPsuch as              fromg:: => propagot allromg   ifudt: *mut u128.v_hi)Not              cro_rules! cmpatomiref       __cmp:-indSafe whe<Not             >:iden "s<T   use sPtr<T     #[i      not(any(pub(cnot ) I128, fs.

u(vg(any(tTe at Selfc_target_feSelfc_iinnlikeHoweve"std" feature  use sPtr::

u(v),patomiref       __cmp:-indSafe whempxchg16b #[i      not(any(pub(cnot ) G16B is available at compile-timt_feSelf::B itomic_is availablexchg16b #[i      not(any(pub(cnot ) I128, fs.B itomic_is available at compile-timt_fecmpxchg16b()
        not(any(pub(cnot ) G16llowny((&ny(tselfe at &ny(tany(tTile-timt_feself.innli.llowny(()xchg16b #[i      not(any(pub(cnot ) G16BSaf_innli(selfe at any(tTile-timt_feself.innli.BSaf_innli()xchg16b #[i      not(any(ature = "cmpxchg16b"128!argee aligned, ag(not     ontract.
    unsafe> $rk_   ifu)),pmiri   // cmpxc> $rk_   ifu
 $cmpxchg16pub(cnot ) G16ly en&self rbx/rcx pair: new valany(tTile-timt_fecnot inttils" fed, an     oair: ne(ure(en;(tarlow m $rk_   ifu (.56+, soed
//dent )]uibra RMWs)e-timt_feself.innli.ly enure(enxchg16b #[i      not(any(ature = "cmpxchg16b"128!argee aligned, ag(not     ontract.
    unsafe> $rk_   ifu)),pmiri   // cmpxc> $rk_   ifu
 $cmpxchg16pub(cnot ) G16citly &self rptr:lany(tToc.rust-lang.org/nightly/t_fecnot inttils" fed, anways Soair: ne(ure(en;(tarlow m $rk_   ifu (.56+, soed
//dent )]uibra RMWs)e-timt_feself.innli.citly ptrature(en_no_outline_I128,_fnble_atomic_tI128,_if:   }
}
consontract.
    unsafeI128,_raw_    e(eef))];               not(any(
   pub(cnot ) I128, fs.as_    &selfw valany(tany(tTile-timt_feafe {
         Selfcnsa /repr(C)]ct! {     n  iy  we implem<any(tT>.rev_lo, mut prev_hi)ales re::panic::RefUnwindSafe is only availa66705pports CMPXCHG16B.
 re::panic::RefUnwindSafe is only aiss2esa66136#iss2enwid" f-557867116                     c (*(selfovae*I128, Selfovae*I128,  we implem<any(tT>)).llole }ble = "cmpxchg16b")
)]
unsafe ontract.
    unsafeI
un#[allow6b")    un, }
}
consontract.
    unsafe
macro_rasOrdering) nsafe consontract.
    unsafeI
un#[allow6b")    un), }
}
#[allow6b")    un::un   c_tarn "s<T   use sPtr<T     #[i      not(any(ature = "cmpxchg16b"128!argee aligned, ag(not     ontract.
    unsafe> $rk_   ifu)),pmiri   // cmpxc> $rk_   ifu
 $cmpxchg16pub(cnot ) G16 #[cfg(any(target_feattttt&self _atomic_tIon for:lany(tTo_atomic_t/ Useany(tTo_atomic_t= "cmpxchg16b"))]
    /ature AFETY: the caller))]
  ust guaranany(tTocany(tT>ightly/t_fecnot inttils" fed, antomic_swap;
#[cfgoair: ne(= "cmpx,re AFETYn;(tarlow m $rk_   ifu (.56+, soed
//dent )]uibra RMWs)e-timt_fe  }
}
ontract.
    unsafecmpxcher/ SAFETYgoair: nepxchg16b_fn    = "cmpxerinnot inttils" upgrade = "cmpxgoair: ne(= "cmpx,re AFETYn;e-timt_feself.innli. #[cfg(any(targetIon for // U, = "cmpx,re AFETYnxchg16b #[i      not(any(ature = "cmpxchg16b"128!argee aligned, ag(not     ontract.
    unsafe> $rk_   ifu)),pmiri   // cmpxc> $rk_   ifu
 $cmpxchg16pub(cnot ) G16tomic_swap;
#[cfg_attt_feattttt&self _atomic_tIon for:lany(tTo_atomic_t/ Useany(tTo_atomic_t= "cmpxchg16b"))]
    /ature AFETY: the caller))]
  ust guaranany(tTocany(tT>ightly/t_fecnot inttils" fed, antomic_swap;
#[cfgoair: ne(= "cmpx,re AFETYn;(tarlow m $rk_   ifu (.56+, soed
//dent )]uibra RMWs)e-timt_fe  }
}
ontract.
    unsafecmpxcher/ SAFETYgoair: nepxchg16b_fn    = "cmpxerinnot inttils" upgrade = "cmpxgoair: ne(= "cmpx,re AFETYn;e-timt_feself.innli. #[cfg(any(targeg_atttIon for // U, = "cmpx,re AFETYnxchg16bden "s<T  Howeveo:pa:D(eefrlow  use sPtr<T     #[iu128cT[alloering::Re"std" feature  use sPtr<T ;b #[i      not(any(ature = "cmmiri, m $rk_   ifu)]c    ch plineo   /, onfg(t ::Uhelpsrlow Miri:atomm $r       G16e(eef &selfw val&Self::T[alloe{_feattttt&self.innli followingt;
        fallback    cmpxchg16min);

#128reexport_   
#128reexpo        #[inline]repr( => {es! n by any(
   pub(cnot )    uct 6min);

#128hg16b is always nnlikeHoweve"std" feature 6min);

#128,ts CMPXCHG16B.
 Psuch as              fromg:: => propagot allromg   ifudt: *mut u128.v_hi)Not              cro_rules! cmp = "cmpxctomiref       __cmp:-indSafe whe<Not             >:i("rdi");
        U128 { = "cmpxchg16b",
  ontract.
    unsafeI
un#[allow6b")    un,pxchg16b",
  }
}
consontract.
    unsafe
macro_rasOr0);
            debug_g) nsafe consontract.
    unsafeI
un#[allow6b")    un), }
}
#[allow6b")    un::un   c_tars always  "s e(faarasafefetch_o:p!16min);

#128rt_   
#128    {
            // Crget_env = "16b"128!#[allow val::unx86"g(target_ val::unx86_

at,16b")
        )]
    miri, ontract.
    unss, otize_th    )t,16b")
        )]
ontract.
    unsafe
sm)fg_attr(
                8 { = "cmpxchg16b",
  ontract.
    unsafeI
un#[allow6b")    un,pxchg16b",
  }
}
consontract.
    unsafe
macro_rasOr0);
            debug_g) nsafe consontract.
    unsafeI
un#[allow6b")    un), }
}
#[allow6b")    un::un   c_tars always  "s e(faarasbit_o:tp!16min);

#128rt_   
#128    {
     n "s 6min);

#128hg16b is always      not(any(
   any(pub(cnot ) I128, fs.

u(vg(_   
#128  at Selfc_target_fearget_feSelfc_   options(nostack),
  nlikeHoweve"std" feature 6min);

#128::

u(v),   options(nostack),
ctomiref       __cmp:-indSafe whe,b", portable_atomic_target_featu16b is always      not(any(
   any(pub(cnot ) G16B is available at compile-timt_fe-timt_feSelf::B itomic_is availablexchg1get_featu16b is always      not(any(
   any(pub(cnot ) I128, fs.B itomic_is available at compile-timt_fePXCHG16B.
 ESP-IDFnown-non' 64-bitt: *mutshg16b fzed ck-ilab.e-timt_fePXCHG16B.
 re::panic::RefUnwindSafe is only availa115577#iss2enwid" f-1732259297contract.
        omic // Crget_env = "16b" = "16b"128!#[allow val::unriscv32"g(target_ val::unxtewe "   // cmpxchg16b is always Seqoxeri"espidf$ret_ty)?;
            | (.5wevememve"ize_of::<_   
#128>le < 8)c_target_featu16b is always      not(any(
   any(pub(cnot ) G16llowny((&ny(tselfe at &ny(t_   
#128ile-timt_fePXCHG16Bself.innli.llowny(()xchg1get_featu16b is always      not(any(
   any(pub(cnot ) G16BSaf_innli(selfe at _   
#128ile-timt_fePXCHG16Bself.innli.BSaf_innli()xchg1get_featu16b is always      not(any(
   any(ature = "cmpxchg16b",
      128!argee aligned, ag(not     ontract.
    unsafe> $rk_   ifu)),pmiri   // cmpxc// cmpxc> $rk_   ifu
 $cmfn = $cmpxchg16b_fn(Ordpub(cnot ) G16ly en&self rbx/rcx pair: new val_   
#128ile-timt_fePXCHG16Bcnot inttils" fed, an     oair: ne(ure(en;(tarlow m $rk_   ifu (.56+, soed
//dent )]uibra RMWs)e-timt_fe-timt_feself.innli.ly enure(enxchg1get_featu16b is always      not(any(
   any(ature = "cmpxchg16b",
      128!argee aligned, ag(not     ontract.
    unsafe> $rk_   ifu)),pmiri   // cmpxc// cmpxc> $rk_   ifu
 $cmfn = $cmpxchg16b_fn(Ordpub(cnot ) G16citly &self rot(ds_   
#128oc.rust-lang.org/nightly/t_fetly/t_fecnot inttils" fed, anways Soair: ne(ure(en;(tarlow m $rk_   ifu (.56+, soed
//dent )]uibra RMWs)e-timt_fe-timt_feself.innli.citly eringure(en_no_ouget_featu16b is alwaysI128,_fnble_atomic_tatomic_tI128,_if:   }
}
consontract.
    unsafeI128,_raw_    e(eef))];         s always      not(any(
   any(
   pub(cnot ) I128, fs.as_    &selfw valany(t_   
#128ile-timt_fePXCHG16Bafe {
         Selfcnsa /repr(C)]ct! {     n  iy  we implem<_   
#128>              concat!("mo_hi)ales re::panic::RefUnwindSafe is only availa66705pports CMPXCHG16BPXCHG16B.
 re::panic::RefUnwindSafe is only aiss2esa66136#iss2enwid" f-557867116                             cmpxchg16b_seqcst__tmp}, rb*(selfovae*I128, Selfovae*I128,  we implem<_   
#128>)).llolel: u128) -> u128;
    cmpxchg16b = atomi_swap_cmpxchg16b;
    fallbac      8 { = "cmpxchg16b",
  ontract.
    unsafeI
un#[allow6b")    un,pxchg16b",
  }
}
consontract.
    unsafe
macro_rasOr0);
            debug_g) nsafe consontract.
    unsafeI
un#[allow6b")    un), }
}
#[allow6b")    un::un   c_tars always  "s 6min);

#128hg16b is always      not(any(
   any(ature = "cmpxchg16b",
      128!argee aligned, ag(not     ontract.
    unsafe> $rk_   ifu)),pmiri   // cmpxc// cmpxc> $rk_   ifu
 $cmfn = $cmpxchg16b_fn(Ordpub(cnot ) G16 #[cfg(any(target_featttttfeattttt&self _atomic_tatomic_tIon for:l_   
#128o_atomic_tatomic_t/ Use_   
#128o_atomic_tatomic_t= "cmpxchg16b"))]
    /atur   /ature AFETY: the caller))]
fn = $cmp ust guaran_   
#128oc_   
#128>ightly/t_fetly/t_fecnot inttils" fed, antomic_swap;
#[cfgoair: ne(= "cmpx,re AFETYn;(tarlow m $rk_   ifu (.56+, soed
//dent )]uibra RMWs)e-timt_fe-timt_fe  }
}
ontract.
    unsafecmpxcher/ SAFETYgoair: nepxchg16b_fnhg16b_fn    = "cmpxerinnot inttils" upgrade = "cmpxgoair: ne(= "cmpx,re AFETYn;e-timt_fe-timt_feself.innli. #[cfg(any(targetIon for // U, = "cmpx,re AFETYnxchg1get_featu16b is always      not(any(
   any(ature = "cmpxchg16b",
      128!argee aligned, ag(not     ontract.
    unsafe> $rk_   ifu)),pmiri   // cmpxc// cmpxc> $rk_   ifu
 $cmfn = $cmpxchg16b_fn(Ordpub(cnot ) G16tomic_swap;
#[cfg_attt_featttttfeattttt&self _atomic_tatomic_tIon for:l_   
#128o_atomic_tatomic_t/ Use_   
#128o_atomic_tatomic_t= "cmpxchg16b"))]
    /atur   /ature AFETY: the caller))]
fn = $cmp ust guaran_   
#128oc_   
#128>ightly/t_fetly/t_fecnot inttils" fed, antomic_swap;
#[cfgoair: ne(= "cmpx,re AFETYn;(tarlow m $rk_   ifu (.56+, soed
//dent )]uibra RMWs)e-timt_fe-timt_fe  }
}
ontract.
    unsafecmpxcher/ SAFETYgoair: nepxchg16b_fnhg16b_fn    = "cmpxerinnot inttils" upgrade = "cmpxgoair: ne(= "cmpx,re AFETYn;e-timt_fe-timt_feself.innli. #[cfg(any(targeg_atttIon for // U, = "cmpx,re AFETYnxchg1get_featu16b is always  test_ade   del )]16b is always      not(any(
   any(ature = "cmmiri, m $rk_   ifu)]c    ch plineo   /, onfg(t ::Uhelpsrlow Miri:atomm $r                  fetch_updot _<F>n&self rbx/rcx pair: ne      f: Fw val_   
#128                ele-timt_fe-timt_feF: FnMy((_   
#128  at _   
#128o_atomic_tatomle-timt_fePXCHG16B.
 T ::Unsaanprivot         ma(targill nfuncc_featu`f`e stan      eptr [", om/x8e-timt_fePXCHG16B.
 g an iypes cmpxchnsafeprev_tore_ynchpxc    mixed-sized at/e AFv_tCAS      asm!(
              // reriself.ly en
                n;e-timt_fe-timt_fedle rmic_store_cmpxchg16b
  e prexoerif16b", ;ic_store_cmpxchg16b
 m-baseself. #[cfg(any(targeg_attt16b() rexo rbx/rc,{
                SeqCst.
                    Ok(x     return xxchg16b")
                chg1rexo_6b",     // rerirexo_6b",,l: u128) -> u128;
    cmpxchg16b = atomi_swap_cmpxchg16b;
    fways      not(any(
   any(ature = "cmmiri, m $rk_   ifu)]c    ch plineo   /, onfg(t ::Uhelpsrlow Miri:atomm $r               pub(cnot ) G16fetch_  un&self rot(ds_   
#128oc.rust-lang.org/nival_   
#128ile-timt_fePXCHG16B  }
}
consontract.
    unsafe6b;
    fal  u)pxchg16b_fnhg16b_fnqCst.
                e.
                          // Thisrget_env = "16b" = "16b"b is always Seq val::una val64 out("rcx") _,
                128!(AtomicU128, u128,lseax, atomic_umin);

#[allow(clippy::unlsea16b!("edi");
               ,                   // Thisrget_env = "16b" = "16b"b is always Seq val::unarm out("rcx") _,
                          )),
                            target_feature(env6               "jne 2b",
           atomic_umin);

#[allow(clippy::unv6               "jne 2b",
      )16b!("edi");
               ,                   // Thiays Seq val::unmips",                   // Thiays Seq val::unmips32r6",                   // Thiays Seq val::unmips64 out("rcx") _,
            ays Seq val::unmips64r6",                   // Thiays Seq val::unpowerpc",                   // Thiays Seq val::unpowerpc64 out("rcx") _,
        )pxchg16b_fnhg16b_fnb_fnqCst.
                G16B.
 HACK: could use CAS        unshg16bIon fortanbrokh p(azedea      qemu-ud, ):Cst.
                G16B.
 - a val64's `lippy::{8,16}::fetch_{tomi fa}`nlindea e      + lse)Cst.
                G16B.
 - armv5te's `lippy:{I,U}{8,16}::fetch_{tomi fa}`Cst.
                G16B.
 - mips's `lippy::8::fetch_{tomi fa}`nlindea e     )Cst.
                G16B.
 - mipsel's `lippy::{8,16}::fetch_{tomi fa}`nle ali     ic_iedea  )Cst.
                G16B.
 - mips64's `lippy::8::fetch_{tomi fa}`nlindea e     )Cst.
                G16B.
 - mips64el's `lippy::{8,16}::fetch_{tomi fa}`nle ali     ic_iedea  )Cst.
                G16B.
 - powerpc's `lippy::{8,16}::fetch_{tomi fa}`Cst.
                G16B.
 - powerpc64's `lippy::{8,16}::fetch_{tomi fa}`nle ali     ic_iedea  )Cst.
                G16B.
 - powerpc64le's `lippy:U{8,16}::fetch_{tomi fa}`nlindea e      + f_ieLTO)Cst.
                G16B.
 _hi)ales:Cst.
                G16B.
 re::panic::RefUnwinllvinllvi-projec aiss2esa61880Cst.
                G16B.
 re::panic::RefUnwinllvinllvi-projec aiss2esa61881Cst.
                G16B.
 re::panic::RefUnwinllvinllvi-projec aiss2esa61882Cst.
                G16B.
 re::panic::RefUnwintaiki-e/30 0017124 0   aiss2esa2Cst.
                G16B.
 re::panic::RefUnwindSafe is only aiss2esa100650Cst.
                G16Bt().5wevememve"ize_of::<_   
#128>le <= 2nqCst.
                G16But("return self.fetch_updot _(bx/rc,{|x|).5wevecmpvem unx rot() ;ic_store_cmpxchg16b
 
    cmpxchg16b = atom
    cmpxchg16b = atom
   self.innli.fetch_  uneringure(enidth = "64")]
                cmpxchg16b!ontract.
    unsafe6b;
    fal  u)xchg16b_fnhg16b_fnqCst.
                self.fetch_updot _(bx/rc,{|x|).5wevecmpvem unx rot() cmpxchg16b = atomi_swap_cmpxchg16b;
    fways      not(any(
   any(ature = "cmmiri, m $rk_   ifu)]c    ch plineo   /, onfg(t ::Uhelpsrlow Miri:atomm $r               pub(cnot ) G16fetch_ inn&self rot(ds_   
#128oc.rust-lang.org/nival_   
#128ile-timt_fePXCHG16B  }
}
consontract.
    unsafe6b;
    fal  u)pxchg16b_fnhg16b_fnqCst.
                e.
                          // Thisrget_env = "16b" = "16b"b is always Seq val::una val64 out("rcx") _,
                128!(AtomicU128, u128,lseax, atomic_umin);

#[allow(clippy::unlsea16b!("edi");
               ,                   // Thisrget_env = "16b" = "16b"b is always Seq val::unarm out("rcx") _,
                          )),
                            target_feature(env6               "jne 2b",
           atomic_umin);

#[allow(clippy::unv6               "jne 2b",
      )16b!("edi");
               ,                   // Thiays Seq val::unmips",                   // Thiays Seq val::unmips32r6",                   // Thiays Seq val::unmips64 out("rcx") _,
            ays Seq val::unmips64r6",                   // Thiays Seq val::unpowerpc",                   // Thiays Seq val::unpowerpc64 out("rcx") _,
        )pxchg16b_fnhg16b_fnb_fnqCst.
                G16B.
 HACK: could use CAS        unshg16bIon fortanbrokh p(azedea      qemu-ud, ):Cst.
                G16B.
 - a val64's `lippy::{8,16}::fetch_{tomi fa}`nlindea e      + lse)Cst.
                G16B.
 - armv5te's `lippy:{I,U}{8,16}::fetch_{tomi fa}`Cst.
                G16B.
 - mips's `lippy::8::fetch_{tomi fa}`nlindea e     )Cst.
                G16B.
 - mipsel's `lippy::{8,16}::fetch_{tomi fa}`nle ali     ic_iedea  )Cst.
                G16B.
 - mips64's `lippy::8::fetch_{tomi fa}`nlindea e     )Cst.
                G16B.
 - mips64el's `lippy::{8,16}::fetch_{tomi fa}`nle ali     ic_iedea  )Cst.
                G16B.
 - powerpc's `lippy::{8,16}::fetch_{tomi fa}`Cst.
                G16B.
 - powerpc64's `lippy::{8,16}::fetch_{tomi fa}`nle ali     ic_iedea  )Cst.
                G16B.
 - powerpc64le's `lippy:U{8,16}::fetch_{tomi fa}`nlindea e      + f_ieLTO)Cst.
                G16B.
 _hi)ales:Cst.
                G16B.
 re::panic::RefUnwinllvinllvi-projec aiss2esa61880Cst.
                G16B.
 re::panic::RefUnwinllvinllvi-projec aiss2esa61881Cst.
                G16B.
 re::panic::RefUnwinllvinllvi-projec aiss2esa61882Cst.
                G16B.
 re::panic::RefUnwintaiki-e/30 0017124 0   aiss2esa2Cst.
                G16B.
 re::panic::RefUnwindSafe is only aiss2esa100650Cst.
                G16Bt().5wevememve"ize_of::<_   
#128>le <= 2nqCst.
                G16But("return self.fetch_updot _(bx/rc,{|x|).5wevecmpveminnx rot() ;ic_store_cmpxchg16b
 
    cmpxchg16b = atom
    cmpxchg16b = atom
   self.innli.fetch_ inneringure(enidth = "64")]
                cmpxchg16b!ontract.
    unsafe6b;
    fal  u)xchg16b_fnhg16b_fnqCst.
                self.fetch_updot _(bx/rc,{|x|).5wevecmpveminnx rot() cmpxchg16b = atomi_swap_cmpxchg16b;
    fways      not(any(
   any(ature = "cmmiri, m $rk_   ifu)]c    ch plineo   /, onfg(t ::Uhelpsrlow Miri:atomm $r               pub(cnot ) G16fetch_    &self rbx/rcx pair: new val_   
#128ile-timt_fePXCHG16Bself.fetch_unsa!0ngure(enidth = "64")]}
t_fePXCHG16B  }
}
conssrget_env = "16b" = "128!#[allow val::unx86"g(target_ val::unx86_

at,16b")
            )]
    miri, ontract.
    unss, otize_th    )t,16b")
            )]
ontract.
    unsafe
sm)fg_attr(
 r(
              ways      not(any(
   any(ature = "cmmiri, m $rk_   ifu)]c    ch plineo   /, onfg(t ::Uhelpsrlow Miri:atomm $r               pub(cnot ) G16    &self rbx/rcx pair: new le-timt_fePXCHG16Bself.fetch_    ure(en_no_ouget_featu16b is always      not(any(
   any(ature = "cmmiri, m $rk_   ifu)]c    ch plineo   /, onfg(t ::Uhelpsrlow Miri:atomm $r               pub(cnot ) G16fetch_ eg &self rbx/rcx pair: new val_   
#128ile-timt_fePXCHG16Bself.fetch_updot _(bx/rc,{_   
#128r:wrapp ne_ egnidth = "64")]}
t_fePXCHG16B  }
}
conssrget_env = "16b" = "128!#[allow val::unx86"g(target_ val::unx86_

at,16b")
            )]
    miri, ontract.
    unss, otize_th    )t,16b")
            )]
ontract.
    unsafe
sm)fg_attr(
 r(
              ways      not(any(
   any(ature = "cmmiri, m $rk_   ifu)]c    ch plineo   /, onfg(t ::Uhelpsrlow Miri:atomm $r               pub(cnot ) G16 eg &self rbx/rcx pair: new le-timt_fePXCHG16Bself.fetch_ eg ure(en_no_ouget_featu16b is al}rs always  "s Howeveo:pa:D(eefrlow 6min);

#128hg16b is alwaysu128cT[alloering::Re"std" feature 6min);

#128;16b is always      not(any(
   any(ature = "cmmiri, m $rk_   ifu)]c    ch plineo   /, onfg(t ::Uhelpsrlow Miri:atomm $r                  e(eef &selfw val&Self::T[alloe{_featttttfeattttt&self.innli follget_featu16b is al}rs alk = atomic_swtest!lippy::"ize, i"izeod tests wtest!lippy:U"ize, u"izeod   }
}
consontract.
    unsafe6b;
        citly    omic_swtest!lippy::ldca8od   }
}
consontract.
    unsafe6b;
        citly    omic_swtest!lippy:Ur::*8od   }
}
consontract.
    unsafe6b;
        citly    omic_swtest!lippy:I16dcar6od   }
}
consontract.
    unsafe6b;
        citly    omic_swtest!lippy:U16dcur6od   }
}
consontract.
    unsafe6b;
        citly      }
}
cons    }
        }
    };
}16"    omic_swtest!lippy:I32dca32od   }
}
consontract.
    unsafe6b;
        citly      }
}
cons    }
        }
    };
}16"    omic_swtest!lippy:U32dcu32od   }
}nsafe ontract.
    unsafeI
un#[allow6b")    un, }
}
consontract.
    unsafe
macro_64Ordering) nsafe 
     )]
ontract.
    unsafeI
un#[allow6b")    un),n);
atom       )),
   #[allow6b")    un::un64 out("rcx")const IS_ALWAYS       }
    };
}16"g(target_;
                U12),n);
a) c   omic_swtest!lippy:I64dca64Od   }
}nsafe ontract.
    unsafeI
un#[allow6b")    un, }
}
consontract.
    unsafe
macro_64Ordering) nsafe 
     )]
ontract.
    unsafeI
un#[allow6b")    un),n);
atom       )),