//! A stably addressed token buffer supporting efficient traversal based on a
//! cheaply copyable cursor.

// This module is heavily commented as it contains most of the unsafe code in
// Syn, and caution should be used when editing it. The public-facing interface
// is 100% safe but the implementation is fragile internally.

use crate::Lifetime;
use proc_macro2::extra::DelimSpan;
use proc_macro2::{Delimiter, Group, Ident, Literal, Punct, Spacing, Span, TokenStream, TokenTree};
use std::cmp::Ordering;
use std::marker::PhantomData;

/// Internal type which is used instead of `TokenTree` to represent a token tree
/// within a `TokenBuffer`.ich is uxme;
1h&6ath` ockusing typeg froe pr-c_macem.
    r, Gro eserifiet contand theffseput to t   matusinE aneserpty.
  , Gro(, Groups usiw(),
  , Ide(, Idew(),
  , Punth(Punw(),
  , Liter(, Liter)te,
    nE aneserifiet contand theffsepu(negulati)ut to t  ustost of thc/buffee,
  E a(i usiw()}a;

//Aen buffes that can bg efficievilt traveured Mulampleetisupsn, li;

//e `TokenStreame whicn requisby a eply coit io:Ordut to traveuor mors tn;

//oncent.
pe) struc `TokenBuffme;
1h&6atNOTE: Does not implemens.cloed or thi-   whils theurparene(degnwe couot be
    ns.cloredohethee(degntes whice couot et despyablmay annot ns.clopyabee,
  eserifi: Box<[is ux]u8>,
}

imp `TokenBuffme;
1h&  fn e cuati_::newserifi: : &mut Veis ux>,he stre:ut TokenStream) {
      e forgit innStreol {
            matctLit {
               `TokenTr::, Ide(t.iden_) =wserifipr.pusis ux::, Ide(t.idenw(),
               `TokenTr::, Punt::punn_) =wserifipr.pusis ux::, Punt::punnw(),
               `TokenTr::, Liter(l Liter)_) =wserifipr.pusis ux::, Liter(l Liter)w(),
               `TokenTr::, Gro(g Gron") => {
                    leg Gro_ usto_indexed =serifips.len();
      ,
           serifipr.pusis ux::E a(0n()   nware rlrfaor thibelow);
      ,
          > Selfn e cuati_::newserifi,eg Gro.nnStrene());
                    leg Gro_s.e_indexed =serifips.len();
      ,
           serifipr.pusis ux::E a(-(g Gro_s.e_indexed as usiwe());
                    leg Gro_s.e_effsepu=eg Gro_s.e_indexe-eg Gro_ usto_index();
      ,
           serifi[g Gro_ usto_index[i] is ux::, Gro(g Gro,eg Gro_s.e_effsep))?;
                }
          }),
        }
    }

    //CStrtisby a `TokenBuffeet contausint alf theoTokens from th  inpng
    ///  proc_maco2::TokenStrest`.
    #[cfg(feature =  pr-c_macng")]
    #[cfg_attr(doc_cfg, doc(cfg(feature =  pr-c_macng")))]
    pub f::nee stre:u  proc_maco2::TokenStrew() -> Self {
      > Self::newe stread inne())
    }

    //CStrtisby a `TokenBuffeet contausint alf theoTokens from th  inpng
    ///  proc_mac2o2::TokenStrest`.
    pub f::n2(e stre:ut TokenStream) -> Self {
        let mueserifies = Vec::new();
      > Selfn e cuati_::ne&t mueserifi,he strew();
       serifipr.pusis ux::E a(-(=serifips.lened as usiwe());
      S self {
          wserifi: =serifipd in_boxed_r<sli(")),
        }
    }

    //CStrtisby e cursst refereusing ths.fired token if thc/buffem andyablttoo
    //o traveuountialf thendst of thc/buffee,
    pub ft begng(&self) -C curssf {
        leptrum = sel=serifipas_ptrew();
      e unsaf{-C curstd:Strti(ptr,eptr.y a(= sel=serifips.lene- 1))   }
    }
}

//Ae! cheaply copyable cursed into a `TokenBuffer`  //  /// Thie cursehold as aharized referenns into thimt mpyabl/ date which is us/  //e internale` to represent e `TokenStreayn, and can bg efficievilmanipeculus/  //, andopiured rrour`  //  //An// emp `C curs`nd can b:Strtised directet, ocloemay :Strtito a `TokenBuffe;

//objire/, ang letie curse` tigits.fired toket wit`t begnne)`.
pe) strucC cursth<'a> {
   /// Theurpareneserpte whicd theC curs`nh ipoprintinatee,
   attr*t cireis ux, {
   /// this id thenvil`is ux::E a`/objire/e whicd Thie cursethisfollowettoo
    ipoprinate// Alohethe`E a`/objireers arskippasedvther i`C curstd:Strtist`.
  , scotr*t cireis ux, {
   //C cursethico` vaatent i'a.// thi` fielokeurutes thaouripopriiters arstiaall
       vidt`.
  ::marke ::PhantomDa<b &'is ux>,t;
}

impl<'aC cursth<'a> {
   ///CStrtisby e cursst refereusine a ulac// emp  `TokenStreee,
    pub fs_empty() -> Self {
      
///ust'unsafi or thisinctuatioe fousar to tth anis ux`/objire/i oglobal {
      
//stooura,et dpwritit annoaunctnalebeusinunsafe toends macrtes Strds {
      
//(`, Ide`is is d referenns intaes Strd-locrnalpyab).// this ibecad use
      
//r thieserptnevther inclusby a, Ide`iobjire.se
      
/se
      
/// thiunwrpffer strucsfollsousar tbStreck tho_rul/, ano tth `Sync`se
      
//objire/i oglobal/stooura.se
      / struct unsaSyncis uxsis uxw();
      e unsaf

impSyncse for unsaSyncis ux {  }
        ulac/EMPTY_ENTRY:or unsaSyncis ux =ct unsaSyncis uxsis ux::E a(0n());

      C curssf {
      ,
   attr&EMPTY_ENTRY.0)?,
            scotr&EMPTY_ENTRY.0)?,
          ::marke ::PhantomDa)),
        }
    }

    /// ThieStrtitmethoded ielligcievilexigitnon-/ exffievi-mmentured
    //`= No`-f.delimid   scosed whes theurursst achfies thendst of tmte,
    //afollowine for emar tbeen trtiser(transparelpty.
  e unsafb f:Strti(t mu attr*t cireis ux, , scotr*t cireis uxy() -> Self {
      
//NOTE: Ifnwa' arlookntinatth `E a`,nwarwateninta.advanes theururs {
      
//palisttupsn, les`ptrum= , sco`le, which means thawa' arabut thedgend of
      
//ourieurursst'u sco.r" Wn shoulenvilh hav`ptru!= , sco`rabut thexigof
      
//s fro= No-f.delimid g Grohiesenturet wit`ignouire No`.0;
        whil  leis ux::E a(r(_) *ptru{0;
            iptrum= , scole {
               Stres);
            }
          ptrum ptr.y a(10');
        }

      C curssf {
      ,
   at)?,
            sco)?,
          ::marke ::PhantomDa)),
        }
    }

    //Getls theurpareneserpty.
  b fss uxs(&self) -> &'is uxsf {
      e unsaf{-&*  selftru  }
    }

    //Bumpes theururssr tooprinates thnexred tokee_aftls theurparen No.// th//
    ///soundeftainebeh hirror if eie cursethieurparevillookntinatth in
    ///is ux::E a`em.
    ///
    //I if eie cursethilookntinatth //is ux::, Grot]`, thbumpinee cursewiaall
    /tooprinates ths.fired token if thg Gro (t wito t  atime scolend)ty.
  e unsafb fbump_ignouirg Gro((&self) -C cursth<'a> {
      C curstd:Strti(  selftr.effsep(10ns, sele sco())
    }

    //W whils theurursethilookntinatth/`= No`-f.delimid g Gro,emdvtng it tlookof
    /// es ths.fired token insidd inste./I if eig Gro thie_emp,le thisiaaemdvtes
    /// theurursepalisd the= No`-f.delimid g Groem.
    ///
    //WARNING:// This mpbuteseers argumety.
  b fignouire Nots(&mut self) {
        whil  leis ux::, Gro(g Gro,er(_) = sel=serpty() {
          r ig Groee_delimite)um= :{Delimit::= Nole {
              e unsaf{-*  se_) = selbump_ignouirg Gro()   };
            } else {
               Stres);
            }
        }
    }

    //C chesde whether tie cursethieurparevilpoprintinates thendst oseer  vidte
    /// sco.e,
    pub fsof((&self) -> bool {
       /// W arabuet osfawa' arabut thendst oouri/ sco.e,
        selftrum= , sele sco }
    }

    //I if eie cursethipoprintinateh/`, Grot t wito t e give (delimiter  retuh//
    //ale cursed ints thag Gro , an Nolpoprintininto thnexref `TokenTre.e,
    pub fg Gro((&mut self (del: :{Delimitlf) -: Optio(C cursth<', ::DelimSp,-C cursth<'<()> {
       //I iwa' arannoerpntinintesent/aln No-f.delimid g Gro,nwarwatenin {
       //ignouior em.r" Wh havt so kThe savt sre t_/ignouior emed whewarwatese
      
//rntesent/f tmtst of cour.// FoobhirusaStrs ci.}

        if.delu!= :{Delimit::= Nole {
            selfgnouire Not0');
        }

        if leis ux::, Gro(g Gro,es.e_effsep)_) = sel=serpty() {
          r ig Groee_delimite)um= f.delue {
                let_span g Groee_del_r.span; {
                les.e_efrg Groan e unsaf{-  selftr.y a(*s.e_effsep)_}; {
                len insi_efrg Groan e unsaf{-C curstd:Strti(  selftr.y a(10,es.e_efrg Gro)_}; {
                lee_afteg Groan e unsaf{-C curstd:Strti(s.e_efrg Grons, sele sco(_}; {
                retur (Som(n insi_efrg Gro, n.spane_afteg Gro)ar);
            }
        }

      = No }
    }

    pub(crate) fanyrg Gro((&self) -: Optio(C cursth<', ::Delimiter::DelimSp,-C cursth<'<()> {
        if leis ux::, Gro(g Gro,es.e_effsep)_) = sel=serpty() {
            let Delimitan g Groee_delimite);
              let_span g Groee_del_r.span; {
            les.e_efrg Groan e unsaf{-  selftr.y a(*s.e_effsep)_}; {
            len insi_efrg Groan e unsaf{-C curstd:Strti(  selftr.y a(10,es.e_efrg Gro)_}; {
            lee_afteg Groan e unsaf{-C curstd:Strti(s.e_efrg Grons, sele sco(_}; {
            retur (Som(n insi_efrg Gro,  (delimitern.spane_afteg Gro)ar);
        }

      = No }
    }

    pub(crate) fanyrg Groto_tok((&self) -: Optio(, GroupC cursth<'<()> {
        if leis ux::, Gro(g Gro,es.e_effsep)_) = sel=serpty() {
            les.e_efrg Groan e unsaf{-  selftr.y a(*s.e_effsep)_}; {
            lee_afteg Groan e unsaf{-C curstd:Strti(s.e_efrg Grons, sele sco(_}; {
            retur (Som(g Groes.cloneane_afteg Gro)ar);
        }

      = No }
    }

    //I if eie cursethipoprintinateh/`, Ide`er  retuhng ia.clg t witaheururs {
    /tooprintinates thnexref `TokenTre.e,
    pub fs_iden(&mut self) -: Optio(, IdentC cursth<'<()> {
        selfgnouire Not0');
      r(match sel=serpty() {
          is ux::, Ide(t.iden") = (Som(n.idens.cloneane unsaf{-  selbump_ignouirg Gro()  )w(),
            _ == No)),
        }
    }

    //I if eie cursethipoprintinateh/`, Pun`er  retuhng ia.clg t witaheururs {
    /tooprintinates thnexref `TokenTre.e,
    pub f::punn(&mut self) -: Optio(, PunctC cursth<'<()> {
        selfgnouire Not0');
      r(match sel=serpty() {
          is ux::, Punt::punn_  ip:punpas_s chty(!= '\''") => {
               (Som(p:punps.cloneane unsaf{-  selbump_ignouirg Gro()  )w);
            }
            _ == No)),
        }
    }

    //I if eie cursethipoprintinateh/`, Liter`er  retung ia.clg t witaheururs {
    /tooprintinates thnexref `TokenTre.e,
    pub fl Litern(&mut self) -: Optio(, LiteralC cursth<'<()> {
        selfgnouire Not0');
      r(match sel=serpty() {
          is ux::, Liter(l Liter)_) = (Som(l Literns.cloneane unsaf{-  selbump_ignouirg Gro()  )w(),
            _ == No)),
        }
    }

    //I if eie cursethipoprintinateh/`::Lifeti`er  retuhng ia.clg t witaed
    ///urursepoprintinates thnexref `TokenTre.e,
    pub fl Lifetin(&mut self) -: Optio(, LifetictC cursth<'<()> {
        selfgnouire Not0');
      r(match sel=serpty() {
          is ux::, Punt::punn_  ip:punpas_s chty(== '\''"&&ip:punps Spacity(== , Spaci::Joprin) => {
                let xtan e unsaf{-  selbump_ignouirg Gro()   };
                leti Identresp)_) t xtnt.ide(:")?;
                let Lifeti_) , Lifeti=> {
                  apostrophe:ip:punps Span(),
                    Iden?;
               ; {
               (Som(l Lifetictresp)w);
            }
            _ == No)),
        }
    }

    //CopiuhisfotremntausineoTokenvisexibls from Thie curset intain
    ///::TokenStrest`.
    pub feoTok_nnStrent self) -::TokenStrelf {
        let mutties = Vec::new();
        let mut curse) = se; {
        whil  le (Som(tentresp))_) e cursoeoTok_n trty() {
          ttipr.pustp))?;
          t curse) resp?);
        }
      ttipd in_s.iter(colleunt) }
    }

    //I if eie cursethipoprintinateh/` `TokenTreer  retuhng ia.clg t witaed
    ///urursepoprintinates thnexref `TokenTre.e,
    ///
    /// Returne= No`or if eie cursehasst achfdes thendst oseere stream.
    ///
    /// Thisethodedoesrannoertrthe= No`-f.delimid g Grosed ar(transpareyn, a//
    //siaae  retunh/`, Gro(= No) (...or if eie cursethilookntinatt No.`.
    pub feoTok_n trtt self) -: Optio( `TokenTrctC cursth<'<()> {
        lettnTrctlaren= r(match sel=serpty() {
          is ux::, Gro(g Gro,es.e_effsep)_)> (g Groes.clonead inne, *s.e_effsep), {
          is ux::, Liter(l Liter)_) =(l Literns.clonead inne, 1), {
          is ux::, Ide(t.iden") =(n.idens.clonead inne, 1), {
          is ux::, Punt::punn_) =(p:punps.clonead inne, 1), {
          is ux::E a(r(_) => retur= No)),
       ();

        lerespan e unsaf{-C curstd:Strti(  selftr.y a(larens, sele sco(_}; {
       (Som(tnTrctresp)w);
    }

    /// Returns th`imSp`st of theurparen, token` orimSptd:sfo_sirate`or if thed
    ///urursepoprisar teof.`.
    pub fs Spa(&self) ->_spa{);
      r(match sel=serpty() {
          is ux::, Gro(g Gro,er(_)>eg Gro.n Span(),
          is ux::, Liter(l Liter)_) =l Liternn Span(),
          is ux::, Ide(t.iden") =).ident.span(),
          is ux::, Punt::punn_) =p:punps Span(),
          is ux::E a(r(_) =imSptd:sfo_sirate)),
        }
    }

    /// Returns th`imSp`st of thd tokenmmedirtivilprirssr ts theosiratiod of
  /
//r thi/ururset, oc of theurparen, tokor if erule inolprehirusa No.`.
    #[cfg(any(feature = "full", feature = "derive"]}

    pub(crate) fnreh_r.spa(&mut self) ->_spa{);
      if  usto_efrc/buffa(&self<   selftru) {
            selftrum e unsaf{-  selftr.effsep(-1)   };
            if leis ux::E a(r(_) h sel=serpty() {
              
//Locrtito t   matusin, Gro t begn, tok.?;
                le(&mudeppath 1)?;
               oop=> {
                    selftrum e unsaf{-  selftr.effsep(-1)   };
          ;
      r(match sel=serpty() {
          {
          is ux::, Gro(g Gro,er(_)>e) {
          {
                ppat-h 1)?;
              ;
            ideppath= 0e) {
          {
                    returg Gro.n Span)?;
              ;
          }
            ;
          }
            ;
          is ux::E a(r(_) =deppati +=,
            ;
          is ux::, Liter(r(_| is ux::, Ide(r(_| is ux::, Puntr(_)>e)}
            ;
      }?;
                }
          }),
        }
        seln Span))
    }

    ///kipedvthes thnexred toket wiouens.cliting it/ Returne= No`or if thed
    ///urursepoprisar teof.`.
    ///
    /// Thisethodeertrtrne'l Lifetis`ed aafn singn, tok.?;
    pub(crate) fnkiptt self) -: OptioC cursth<'>f) {
        let len r(match sel=serpty() {
          is ux::E a(r(_) => retur= No))
            
//Trtrthl Lifetised aafn singn,tne for e   reoseers o'nkip'. {
          is ux::, Punt::punn_  ip:punpas_s chty(== '\''"&&ip:punps Spacity(== , Spaci::Joprin) => {
              r(matce unsaf{-&*  selftr.y a(10 }e) {
          {
      is ux::, Ide(r(_) =2,
            ;
        _ ==,
            ;
    }
          }) {
          is ux::, Gro(_,es.e_effsep)_)> *s.e_effsep(),
            _ =1)),
       ();

       (Some unsaf{-C curstd:Strti(  selftr.y a(larens, sele sco(_}) }
    }
}

impl<'aC coie foC cursth<'a>}
}

impl<'aC.cloee foC cursth<'a>y.
  b fs.clon&r(self) -> See) {
      *  se }
    }
}

impl<'aEqie foC cursth<'a>}
}

impl<'aPstoialEqie foC cursth<'a>y.
  b fsqns(&selfoheth: &S&self) -> bool {
        selftrum= ohethlftr }
    }
}

impl<'aPstoialOrdie foC cursth<'a>y.
  b fpstoial_cmpns(&selfoheth: &S&self) -: Optio::Orderi()> {
        i atirc/buffa*(&self*ohethy() {
           (Som  selftr.cmpnsohethlftr)ue)
        } else {
          = No }
        }
    }
}  pub(crate) fnatire sco(a:oC curs, b:oC curslf) -> bool {
  a.t scope= ble sco }
}  pub(crate) fnatirc/buffaa:oC curs, b:oC curslf) -> bool {
   usto_efrc/buffaay(==  usto_efrc/buffab) }
}) fnusto_efrc/buffa/ururs:oC curslf) -*t cireis uxng {
    unsaf{);
      r(matc&*e curso, scole {
          is ux::E a(effsep)_)> e curso, sco.effsep(*effsep), {
            _ = "unachpyab!(")),
        }
    }
}  #[cfg(any(feature = "full", feature = "derive"]}  pub(crate) fcmpul_aumadinnatirc/buffaa:oC curs, b:oC curslf) -::Orderiol {
  a.ftr.cmpnsblftr) }
}  pub(crate) f).op_r.sp_efrg Groa/ururs:oC curslf) ->_spa{);
  r(matce curso=serpty() {
      is ux::, Gro(g Gro,er(_)>eg Gro.n Sp_).open(),
      __)> e curso, Span(),
    }
}  pub(crate) f).clo_r.sp_efrg Groa/ururs:oC curslf) ->_spa{);
  r(matce curso=serpty() {
      is ux::, Gro(g Gro,er(_)>eg Gro.n Sp_).close(),
      __)> e curso, Span(),
    }
  