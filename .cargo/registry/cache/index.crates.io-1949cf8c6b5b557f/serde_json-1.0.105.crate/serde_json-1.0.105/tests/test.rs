#![cfg(not(feature = "preserve_order"))]
#![allow(
    clippy::assertions_on_result_states,
    clippy::cast_precision_loss,
    clippy::derive_partial_eq_without_eq,
    clippy::excessive_precision,
    clippy::float_cmp,
    clippy::items_after_statements,
    clippy::let_underscore_untyped,
    clippy::shadow_unrelated,
    clippy::too_many_lines,
    clippy::unreadable_literal,
    clippy::unseparated_literal_suffix,
    clippy::vec_init_then_push,
    clippy::zero_sized_map_values
)]
#![cfg_attr(feature = "trace-macros", feature(trace_macros))]
#[cfg(feature = "trace-macros")]
trace_macros!(true);

#[macro_use]
mod macros;

#[cfg(feature = "raw_value")]
use ref_cast::RefCast;
use serde::de::{self, IgnoredAny, IntoDeserializer};
use serde::ser::{self, SerializeMap, SerializeSeq, Serializer};
use serde::{Deserialize, Serialize};
use serde_bytes::{ByteBuf, Bytes};
#[cfg(feature = "raw_value")]
use serde_json::value::RawValue;
use serde_json::{
    from_reader, from_slice, from_str, from_value, json, to_string, to_string_pretty, to_value,
    to_vec, Deserializer, Number, Value,
};
use std::collections::hash_map::DefaultHasher;
use std::collections::BTreeMap;
#[cfg(feature = "raw_value")]
use std::collections::HashMap;
use std::fmt::{self, Debug};
use std::hash::{Hash, Hasher};
use std::io;
use std::iter;
use std::marker::PhantomData;
use std::mem;
use std::str::FromStr;
use std::string::ToString;
use std::{f32, f64};
use std::{i16, i32, i64, i8};
use std::{u16, u32, u64, u8};

macro_rules! treemap {
    () => {
        BTreeMap::new()
    };
    ($($k:expr => $v:expr),+ $(,)?) => {
        {
            let mut m = BTreeMap::new();
            $(
                m.insert($k, $v);
            )+
            m
        }
    };
}

#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
enum Animal {
    Dog,
    Frog(String, Vec<isize>),
    Cat { age: usize, name: String },
    AntHive(Vec<String>),
}

#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
struct Inner {
    a: (),
    b: usize,
    c: Vec<String>,
}

#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
struct Outer {
    inner: Vec<Inner>,
}

fn test_encode_ok<T>(errors: &[(T, &str)])
where
    T: PartialEq + Debug + ser::Serialize,
{
    for &(ref value, out) in errors {
        let out = out.to_string();

        let s = to_string(value).unwrap();
        assert_eq!(s, out);

        let v = to_value(value).unwrap();
        let s = to_string(&v).unwrap();
        assert_eq!(s, out);
    }
}

fn test_pretty_encode_ok<T>(errors: &[(T, &str)])
where
    T: PartialEq + Debug + ser::Serialize,
{
    for &(ref value, out) in errors {
        let out = out.to_string();

        let s = to_string_pretty(value).unwrap();
        assert_eq!(s, out);

        let v = to_value(value).unwrap();
        let s = to_string_pretty(&v).unwrap();
        assert_eq!(s, out);
    }
}

#[test]
fn test_write_null() {
    let tests = &[((), "null")];
    test_encode_ok(tests);
    test_pretty_encode_ok(tests);
}

#[test]
fn test_write_u64() {
    let tests = &[(3u64, "3"), (u64::MAX, &u64::MAX.to_string())];
    test_encode_ok(tests);
    test_pretty_encode_ok(tests);
}

#[test]
fn test_write_i64() {
    let tests = &[
        (3i64, "3"),
        (-2i64, "-2"),
        (-1234i64, "-1234"),
        (i64::MIN, &i64::MIN.to_string()),
    ];
    test_encode_ok(tests);
    test_pretty_encode_ok(tests);
}

#[test]
fn test_write_f64() {
    let tests = &[
        (3.0, "3.0"),
        (3.1, "3.1"),
        (-1.5, "-1.5"),
        (0.5, "0.5"),
        (f64::MIN, "-1.7976931348623157e308"),
        (f64::MAX, "1.7976931348623157e308"),
        (f64::EPSILON, "2.220446049250313e-16"),
    ];
    test_encode_ok(tests);
    test_pretty_encode_ok(tests);
}

#[test]
fn test_encode_nonfinite_float_yields_null() {
    let v = to_value(::std::f64::NAN).unwrap();
    assert!(v.is_null());

    let v = to_value(::std::f64::INFINITY).unwrap();
    assert!(v.is_null());

    let v = to_value(::std::f32::NAN).unwrap();
    assert!(v.is_null());

    let v = to_value(::std::f32::INFINITY).unwrap();
    assert!(v.is_null());
}

#[test]
fn test_write_str() {
    let tests = &[("", "\"\""), ("foo", "\"foo\"")];
    test_encode_ok(tests);
    test_pretty_encode_ok(tests);
}

#[test]
fn test_write_bool() {
    let tests = &[(true, "true"), (false, "false")];
    test_encode_ok(tests);
    test_pretty_encode_ok(tests);
}

#[test]
fn test_write_char() {
    let tests = &[
        ('n', "\"n\""),
        ('"', "\"\\\"\""),
        ('\\', "\"\\\\\""),
        ('/', "\"/\""),
        ('\x08', "\"\\b\""),
        ('\x0C', "\"\\f\""),
        ('\n', "\"\\n\""),
        ('\r', "\"\\r\""),
        ('\t', "\"\\t\""),
        ('\x0B', "\"\\u000b\""),
        ('\u{3A3}', "\"\u{3A3}\""),
    ];
    test_encode_ok(tests);
    test_pretty_encode_ok(tests);
}

#[test]
fn test_write_list() {
    test_encode_ok(&[
        (vec![], "[]"),
        (vec![true], "[true]"),
        (vec![true, false], "[true,false]"),
    ]);

    test_encode_ok(&[
        (vec![vec![], vec![], vec![]], "[[],[],[]]"),
        (vec![vec![1, 2, 3], vec![], vec![]], "[[1,2,3],[],[]]"),
        (vec![vec![], vec![1, 2, 3], vec![]], "[[],[1,2,3],[]]"),
        (vec![vec![], vec![], vec![1, 2, 3]], "[[],[],[1,2,3]]"),
    ]);

    test_pretty_encode_ok(&[
        (vec![vec![], vec![], vec![]], tnz}om_str, tr, tr]),[]]"),
       )+
           (vec![vec![1, 2, 3], vec![], vec   )+
       []], tnz}om_stvec![1, 2,tr, tr])c   )+
   ,[]]"),
       )+
           (vec![vec![], vec![1, 2, 3], vec   )+
       []], tnz}om_str, tvec![1, 2,tr])c   )+
   ,[]]"),
       )+
           (vec![vec![], vec![], vec![1, 2,   )+
       []], tnz}om_str, tr, tvec![1, ])c   )+
   ,[]]"),
    ]);

    test_pretty_encode_ok(&[
        (vec![], "[]"),
        (vec![tr[]], tnz}om_svec![)rue]"),
        (vec![true, fal[]], tnz}om_svec![true, f),[]]"),
    ]);

   ivegativewritelet j = j["), (fa,"a": [", "\nbar("f3.5]
    ]);

    test_encode_    )+
   ivegativewrite.cl.is_nue]"),
   ":", json_["), (fa,"a": [", "\nbar("f3.5]
 ue]"),)
    ]);

    test_pretty_encode_    )+
   ivegativewrite,

       []], tnz}om_s"), (fa,"a": [", "\nbar("f3.5]
 ue]"),)
   ts);
}

#[test]
fn test_wv.as_objist() {
    test_encode_ok(&[
    les! tr!= &[({}, "[]"),
    les! tr!="a"::MIN.to_str(,)?ros!(,ata =a\":ros!}, "[]"),
    tor {
        es! tr!=   $(
           "a"::MIN.to_str(,)?ros!,   $(
           "b"::MIN.to_str(,)?"), (f $v);
        f $v);
       ta =a\":ros!,\"\u0:"), (}"c   )+
   ,[]]"),
    ]);

    test_encode_ok(&[
    tor {
        es! tr![   $(
           "a"::MIN.to_str(,)?ros! tr![],   $(
           "b"::MIN.to_str(,)?ros! tr![],   $(
           "c"::MIN.to_str(,)?ros! tr![],   $(
       ]f $v);
       ta =a\":{},\"\u0:{},\"cu0:{}}"c   )+
   ,[]]"),
    tor {
        es! tr![   $(
           "a"::MIN.to_str(,)?ros! tr![()? {
               "a"::MIN.to_str(,)?ros! tr!["a"(,)?![], ve],[1,,()? {
               "b"::MIN.to_str(,)?ros! tr![],   $(
               "c"::MIN.to_str(,)?ros! tr![],   $(
           ]f $v);
           "b"::MIN.to_str(,)?ros! tr![],   $(
           "c"::MIN.to_str(,)?ros! tr![],   $(
       ]f $v);
       ta =a\":{ =a\":{ =a\": ve],[1},\"\u0:{},\"cu0:{}},\"\u0:{},\"cu0:{}}"c   )+
   ,[]]"),
    tor {
        es! tr![   $(
           "a"::MIN.to_str(,)?ros! tr![]f $v);
           "b"::MIN.to_str(,)?ros! tr![()? {
               "a"::MIN.to_str(,)?ros! tr!["a"(,)?![], ve],[1,,()? {
               "b"::MIN.to_str(,)?ros! tr![],   $(
               "c"::MIN.to_str(,)?ros! tr![],   $(
           ]f $v);
           "c"::MIN.to_str(,)?ros! tr![],   $(
       ]f $v);
       ta =a\":{},\"\u0:{ =a\":{ =a\": ve],[1},\"\u0:{},\"cu0:{}},\"cu0:{}}"c   )+
   ,[]]"),
    tor {
        es! tr![   $(
           "a"::MIN.to_str(,)?ros! tr![]f $v);
           "b"::MIN.to_str(,)?ros! tr![]f $v);
           "c"::MIN.to_str(,)?ros! tr![()? {
               "a"::MIN.to_str(,)?ros! tr!["a"(,)?![], ve],[1,,()? {
               "b"::MIN.to_str(,)?ros! tr![],   $(
               "c"::MIN.to_str(,)?ros! tr![],   $(
           ]f $v);
       ]f $v);
       ta =a\":{},\"\u0:{},\"cu0:{ =a\":{ =a\": ve],[1},\"\u0:{},\"cu0:{}}}"c   )+
   ,[]]"),
    ]);

    test_encode_ les! tr!['c'(,)?()],ata =cu0:,"c":n)
    ]);

    test_pretty_encode_ok(&[
    tor {
        es! tr![   $(
           "a"::MIN.to_str(,)?ros! tr![],   $(
           "b"::MIN.to_str(,)?ros! tr![],   $(
           "c"::MIN.to_str(,)?ros! tr![],   $(
       ]f $v);
       []], tnz}om_{   $(
           "a": {},   $(
           "b": {},   $(
           "c": {} x })
        )c   )+
   ,[]]"),
    tor {
        es! tr![   $(
           "a"::MIN.to_str(,)?ros! tr![()? {
               "a"::MIN.to_str(,)?ros! tr!["a"(,)?![], ve],[1,,()? {
               "b"::MIN.to_str(,)?ros! tr![],   $(
               "c"::MIN.to_str(,)?ros! tr![],   $(
           ]f $v);
           "b"::MIN.to_str(,)?ros! tr![],   $(
           "c"::MIN.to_str(,)?ros! tr![],   $(
       ]f $v);
       []], tnz}om_{   $(
           "a": {()? {
               "a": {()? {
                   "a": [()? {
                       1,()? {
                       2,()? {
                       3()? {
                   ]()? {
               },()? {
               "b": {},   $(
               "c": {} x })
           },()? {
           "b": {},   $(
           "c": {} x })
        )c   )+
   ,[]]"),
    tor {
        es! tr![   $(
           "a"::MIN.to_str(,)?ros! tr![]f $v);
           "b"::MIN.to_str(,)?ros! tr![()? {
               "a"::MIN.to_str(,)?ros! tr!["a"(,)?![], ve],[1,,()? {
               "b"::MIN.to_str(,)?ros! tr![],   $(
               "c"::MIN.to_str(,)?ros! tr![],   $(
           ]f $v);
           "c"::MIN.to_str(,)?ros! tr![],   $(
       ]f $v);
       []], tnz}om_{   $(
           "a": {},   $(
           "b": {()? {
               "a": {()? {
                   "a": [()? {
                       1,()? {
                       2,()? {
                       3()? {
                   ]()? {
               },()? {
               "b": {},   $(
               "c": {} x })
           },()? {
           "c": {} x })
        )c   )+
   ,[]]"),
    tor {
        es! tr![   $(
           "a"::MIN.to_str(,)?ros! tr![]f $v);
           "b"::MIN.to_str(,)?ros! tr![]f $v);
           "c"::MIN.to_str(,)?ros! tr![()? {
               "a"::MIN.to_str(,)?ros! tr!["a"(,)?![], ve],[1,,()? {
               "b"::MIN.to_str(,)?ros! tr![],   $(
               "c"::MIN.to_str(,)?ros! tr![],   $(
           ]f $v);
       ]f $v);
       []], tnz}om_{   $(
           "a": {},   $(
           "b": {},   $(
           "c": {()? {
               "a": {()? {
                   "a": [()? {
                       1,()? {
                       2,()? {
                       3()? {
                   ]()? {
               },()? {
               "b": {},   $(
               "c": {} xue;
                }
       })c   )+
   ,[]]"),
    ]);

    test_pretty_encode_ok(&[
    les! tr!= &[({}, "[]"),
    tor {
        es! tr!="a"::MIN.to_str(,)?ros!(, $v);
       []], tnz}om_{   $(
           "a": ros! x })
        )c   )+
   ,[]]"),
    tor {
        es! tr!=   $(
           "a"::MIN.to_str(,)?ros!,   $(
           "b"::MIN.to_str(,)?"), (f $v);
        f $v);
       []], tnz}om_ {   $(
           "a": ros!,   $(
           "b": "), (    }
       })c   )+
   ,[]]"),
    ]);

   complexwv.alet j = js
        "b": [()? {
       {"c": "\x0c\x1f\r"},   $(
       {"d": ""     }
   ]e());
    ]);

    test_encode_    )+
   complexwv.a.cl.is_nue]"),
   ":", json_{   $(
       "b": [()? {
                {
               "c": m_st"\f "\"1f\r""#) x })
           },()? {
                {
               "d": "" xue;
                }
       ]()? {
   } ue]"),)
    ]);

    test_pretty_encode_    )+
   complexwv.a,

       []], tnz}om_{   $(
       "b": [()? {
                {
               "c": m_st"\f "\"1f\r""#) x })
           },()? {
                {
               "d": "" xue;
                }
       ]()? {
   } ue]"),)
   ts);
}

#[test]
fn test_wtuplebjist() {
    test_encode_((5, &[([5]n)
    ]);

    test_pretty_encode_((5, &[[]], tnz}om_s5]))
    ]);

    test_encode_ (5, (6&["bbc") &[([5,[6,\"bbc\"]]n)
    ]);

    test_pretty_encode_((5, (6&["bbc") &[[]], tnz}om_s5, [6&["bbc"]]))
   ts);
}

#[test]
fn test_wlize_jist() {
    test_encode_ok(&[
    enum A::
   A3}'
  u000b\""),
        }
       enum A::
    "Henry"econd.to_strin    (v f $v);
       ta =
   \": \"Henry\",2,3}"c   )+
   ,[]]"),
    tor {
       enum A::
    "Henry"econd.to_strin    (349v f $v);
       ta =
   \": \"Henry\",2349v3}"c   )+
   ,[]]"),
    tor {
       enum A::
    "Henry"econd.to_strin    (349set(2v f $v);
       ta =
   \": \"Henry\",2349,t(2v3}"c   )+
   ,[]]"),
    tor {
       enum A::
     xue;
           at { 5,()? {
           ize, n"Kate"econd.to_stri

           },()? {
       ta =
  \":{ =age\":5,\"ize,\":\"Kate\"}}"c   )+
   ,[]]"),
    tor {
       enum A::
    Ant    ("Bob"econd.to_strin"Stuart"econd.to_strv f $v);
       ta =
    An\": \"Bob\",\"Stuart\"]}"c   )+
   ,[]]"),
    ]);

    test_pretty_encode_ok(&[
    enum A::
   A3}'
  u000b\""),
        }
       enum A::
    "Henry"econd.to_strin    (v f $v);
       []], tnz}om_{   $(
           "
   ": [()? {
               "Henry",   $(
               []()? {
           ] x })
        )c   )+
   ,[]]"),
    tor {
       enum A::
    "Henry"econd.to_strin    (349v f $v);
       []], tnz}om_{   $(
           "
   ": [()? {
               "Henry",   $(
               [()? {
                   349

                   ]()? {
           ] x })
        )c   )+
   ,[]]"),
    tor {
       enum A::
    "Henry"econd.to_strin    (349set(2v f $v);
       []], tnz}om_{   $(
           "
   ": [()? {
               "Henry",   $(
               [()? {
                 349s()? {
                 t(2

                   ]()? {
           ] x })
        )c   )+
   ,[]]"),
   ts);
}

#[test]
fn test_wvpollebjist() {
    test_encode_(Nve(Cl((), "n, ( let "jodhpurs"n, 3}'jodhpurs\"foo    ]);

    test_encode_ok(&[
    Nve(Cl((), "n,ok(&[
     let     ("), ("fobar(] &[([o", "\",\"\ar\"]2,3]]"),
    ]);

    test_pretty_encode_(Nve(Cl((), "n, ( let "jodhpurs"n, 3}'jodhpurs\"foo    ]);

    test_pretty_encode_ok(&[
    Nve(Cl((), "n,ok(&[
     let     ("), ("fobar(] &[[]], tnz}om_s"), ("fobar(] ,[]]"),
   ts);
}

#[test]
fn test_wnewre_u_ze)]
sbjist() {e};

#[derive(Serialbug, Partiaize, Deb() {
pub strewre_u( m = BTr<Frog(Stri32>    ]);

   
    letrewre_u( es! tr!=Std::str:try_"
    "r(,)?123_err());
   ouct O=  es! tr!=Std::str:try_"ouct "r(,)? v = to_v&
    ct>(j).unwrap());

    test_encode_(
    , _str(
    ":123:nul
    ]);

    test_encode_ ouct , _str(ouct ":r(
    ":123::nul
   ts);
}

#[test]
fn h = "deseriaalid_n_ v untagguncaize_jist() {e};

#[dertiabug, Partiaizve(Deserialize, Deb() {e})]
#[suntaggunDeb() {a")]
enum E {{{{{N    159.1),
 4863.
    assertE::N(0 &[Eserdve(Deserie_any(Ntr:try_0)ct>(j).unwrap() }
}

fn t  v.ncode_oe_ok(inner:(&from_T)>str)])
where
  rive(ialEq + Deb  T: Partialug + ser::Seriiale seizve(DeseriOwnrelaize,
{
   t_eqalue(v out let trors {
       v: TValue = fromsty(&v).unwrap();
        assertveqalue(.cl.is_n, out);

        : TValue = from_ss$data.as_byty(&v).unwrap();
        assertveqalue(.cl.is_n, out);

   // Make s(feaw2 we
}

fn deserir("ao a `ber, `.ut);

       ":", son::vut v: Value = fromsty(&v).unwrap();
        assert":", son::,? v = to_v&alue(value).unw, out);

   // Make s(feaw2 we
}

fn deserirue = a `&ber, `.ut);

        letTserdve(Deserie&":", son::ty(&v).unwrap();
        assertveqalue(, out);

   // Make s(feaw2 we
}

fn deserirue = a `ber, `.ut);

        : TValue = = to_v":", son::.cl.is_n,y(&v).unwrap();
        assertveqalue(, out);

   // Make s(feaw2 we
}r_in_  eip back cas`ber, `.ut);

       ":", son::2vut v: Value = = to_v":", son::.cl.is_n,y(&v).unwrap();
        assert":", son::2, ":", son::, out);

   // Make s(feaw2 we
}f), y ilf, I.ut);

       twos at = seconownre_ji+ 3}n3735928559"rap();
       elf, let de = Deserializer::from&twos atwrap();
   elf, Ignorserdve(Deserie&elf, l,y(&v).unwrap();
        assert0xDEAD_BEEF, u32serdve(Deserie&elf, l,y(&v).unw, out);

   // Make s(feaevery[[]]fix is e
}EOFt) in , ppy:p  th   a[[]]fix of aut);

   // alid_n may be a[am_in alid_n.ut);

   if !":", son::.t!(v.id_number() {{{{{{{{{
   ti, _v outsecrimcaie_j.rite_inditespaces() {
           a    assson::from_str::<Va&s[..i]wrap().unwrap_err().is_eof());
           a    assson::from_self, IgnorVa&s[..i]wrap().unwrap_err().is_eof());
       }    m
        }
p() // F    let: Stree = "ntaollec th   / If
    deseria acy:p s bu  / If   deseria // never ge   lt_s. Th    do not s(fv#[d a[r_in_- eip thr_ighut v: . }
}

fn t  v.nunusualncode_oe_ok(inner:(&from_T)>str)])
where
  rive(ialEq + Deb  T: Partialug + ser::Seriiale seizve(DeseriOwnrelaize,
{
   t_eqalue(v out let trors {
       v: TValue = fromsty(&v).unwrap();
        assertveqalue(.cl.is_n, out);

        : TValue = from_ss$data.as_byty(&v).unwrap();
        assertveqalue(.cl.is_n, o   }
p() kip]
macro_rules! t  v.nwratream {
 ize, ream:_ite(xpr, $),*>($arg=> $v::expr  fn eed=> $v::exprors {
       actualbyteize, ite(xpr),*>($argwrap().unwrap_e out.to_strinp();
        assertactual,pr  fn eed"foun  fn eed {}t) in "{:?.to_sify!
 ize,n, o   }
ap() }
}

fn t  v.n) ide_ok<T>(errors&from_&'fteric (T, &str)])
where
  Eq + Deb  T: Partiale seizve(DeseriOwnrelaize,
{
   &t_eqk<T, out) in errors {
   

fn t  v.n) issson::from_sT<Enu:expk<T,;ors {
   

fn t  v.n) issson::from_m_sT<En$data.as_byt:expk<T,;ors {}p() }
}

fn t  v.nfrom_n) ide_ok<T>(errors&[u8]m_&'fteric (T, &str)])
where
  Eq + Deb  T: Partiale seizve(DeseriOwnrelaize,
{
   &t_eqk<T, out) in errors {
   

fn t  v.n) issson::from_m_sT<Ent:expk<T,;ors {}p() }
}

fn son:(T, t  v.n) ide_ok<T>(errors&from_&'fteric (T, &str)])
where
  Eq + Deb  T: Partial4> + FromStr,
    <T as FromStr>::ing::ToSlaize,
{
   &t_eqk<T, out) in errors {
       actualbyts    v.m_sT<Ewrap().unwrap_e out.to_strinp();
        assertactual,pwra"foun  fn eed    v: St) in ", out);
    }
}

#[test]
fn t  v.nelds_null() {

fn t  v.n) im_s()>de_ok(&[
    "n("foEOFtwhile    v: Staqalue(cters at line 1 co, "3.1"),
    ((),("foEOFtwhile    v: Staqalue(cters at line 1 co3 "3.1"),
    ((),la"ing(), "trailing characters at line 1 colum3]]"),
    ]);

    t  v.nco     ( ((),l"in())
   ts);
}

#[test]
fn t  v.nrite_bool() {

fn t  v.n) im_srite>de_ok(&[
    "t("foEOFtwhile    v: Staqalue(cters at line 1 co, "3.1"),
    (truz("fo  fn eed ream:cters at line 1 co"-1234"),
    "f("foEOFtwhile    v: Staqalue(cters at line 1 co, "3.1"),
    (faz("fo  fn eed ream:cters at line 1 co3 "3.1"),
    (truea"ing(), "trailing characters at line 1 colum3]]"),
    (falsea"ing(), "trailing characters at line 1 co6um3]]"),
    ]);

    t  v.nco     (.1"),
    (true",?ros!(, $v);
   ("?ros! ",?ros!(, $v);
   ("se, "frap(), f, $v);
   ("?p(),  frap(), f, $v);
   ts);
}

#[test]
fn t  v.nrite_char() {

fn t  v.n) im_srite>de_ok(&[
    tor {
       "\"bb\"",   $(
       "ream_in son::vut.to_s \"bb\",   fn eed ailing charcters at line 1 co"-c   )+
   ,[]]"),
    tor {
       "10",   $(
       "ream_in re_u:r("an int`10`,   fn eed ailing charcters at line 1 co2"c   )+
   ,[]]"),
    ]);

    t  v.nco     (.1"),
    (n', "\, 'n'f, $v);
   (""', "\"\\, '"'f, $v);
   (""', "\"\\, '\\'f, $v);
   (""'/"\\, '/'f, $v);
   (""', b"\\, '\  ('f, $v);
   (""', f"\\, '\  C'f, $v);
   (""', , "\, '\n'f, $v);
   (""', r "\, '\r'f, $v);
   (""', t "\, '\t'f, $v);
   (""', "\"\\u00, '\  B'f, $v);
   (""', "\"\Bu00, '\  B'f, $v);
   (""', "\"\u{3A, '\  ('\u{f, $v);
   ts);
}

#[test]
fn t  v.nalid_n_) in e_char() {

fn t  v.n) im_sf64>de_ok(&[
    "+("fo  fn eed alue(cters at line 1 co, "3.1"),
    (.("fo  fn eed alue(cters at line 1 co, "3.1"),
    (-("foEOFtwhile    v: Staqalue(cters at line 1 co, "3.1"),
    (00("foream_in alid_n ters at line 1 colum3.1"),
    (0x80"ing(), "trailing characters at line 1 colum, $v);
   (""\0("fo  fn eed alue(cters at line 1 co, "3.1"),
    (.0("fo  fn eed alue(cters at line 1 co, "3.1"),
    (0.("foEOFtwhile    v: Staqalue(cters at line 1 colum, $v);
   ("1.("foEOFtwhile    v: Staqalue(cters at line 1 colum, $v);
   ("1.a("foream_in alid_n ters at line 1 co3um, $v);
   ("1.e1("foream_in alid_n ters at line 1 co3um, $v);
   ("1e("foEOFtwhile    v: Staqalue(cters at line 1 colum, $v);
   ("1e+("foEOFtwhile    v: Staqalue(cters at line 1 co3 "3.1"),
    (1a"ing(), "trailing characters at line 1 colum, $v);
   (tor {
       "100e777777777777777777777777777",   $(
       "alid_n  letof rang(cters at line 1 co,"-c   )+
   ,[]]"),
    tor {
       "-100e777777777777777777777777777",   $(
       "alid_n  letof rang(cters at line 1 co,5-c   )+
   ,[]]"),
    tor {
       "1000000000000000000000000000000000000000000000000000000000000\f());
        000000000000000000000000000000000000000000000000000000000000\f());
        000000000000000000000000000000000000000000000000000000000000\f());
        000000000000000000000000000000000000000000000000000000000000\f());
        000000000000000000000000000000000000000000000000000000000000\f());
        000000000"in// 1e309   $(
       "alid_n  letof rang(cters at line 1 co310",   $(
   ,[]]"),
    tor {
       "1000000000000000000000000000000000000000000000000000000000000\f());
        000000000000000000000000000000000000000000000000000000000000\f());
        000000000000000000000000000000000000000000000000000000000000\f());
        000000000000000000000000000000000000000000000000000000000000\f());
        000000000000000000000000000000000000000000000000000000000000\f());
        .0e9"in// 1e309   $(
       "alid_n  letof rang(cters at line 1 co305-c   )+
   ,[]]"),
    tor {
       "1000000000000000000000000000000000000000000000000000000000000\f());
        000000000000000000000000000000000000000000000000000000000000\f());
        000000000000000000000000000000000000000000000000000000000000\f());
        000000000000000000000000000000000000000000000000000000000000\f());
        000000000000000000000000000000000000000000000000000000000000\f());
        e9"in// 1e309   $(
       "alid_n  letof rang(cters at line 1 co303"c   )+
   ,[]]"),
   ts);
}

#[test]
fn t  v.nrite_i64() {
    t  v.nco     (.1"),
    (-2"c -2"3.1"),
    (-4, "-c -4, "f, $v);
   ("?-4, " -c -4, "f, $v);
   (MIN, &i64::MIN.to_str, i32 &i64f, $v);
   (MIN, &i64::MAX.to_str, i32 &iAX,[]]"),
   ts);
}

#[test]
fn t  v.nuite_i64() {
    t  v.nco     (.1"),
    (0"in0u6"f, $v);
   ("3("f3u6"f, $v);
   ("4, "-c 4, "f, $v);
   (MuN, &i64::MAX.to_str, u32 &iAX,[]]"),
   ts);
}

#[test]
fn t  v.nated_neg_ppy:e_i64() {
   ated_neg_ppy: oute_ok(&[
   "-0",   $(
   "-0.0",   $(
   "-0e2",   $(
   "-0.0e2",   $(
   "-1e-400",   $(
   "-1e-4000000000000000000000000000000000000000000000000",   $(]ream| {
        assr() {{{{{{{{{
on::from_sf32>(ated_neg_ppy:next().unwrap(signcated_negat,   $(
       "should have been ated_neg: ln!("{   $(
       ated_neg_ppy:c   )+
   ,;am| {
        assr() {{{{{{{{{
on::from_sf64>dated_neg_ppy:next().unwrap(signcated_negat,   $(
       "should have been ated_neg: ln!("{   $(
       ated_neg_ppy:c   )+
   ,;am| {
    }
}

#[test]
fn t  v.nfite_i64() {
    t  v.nco     (.1"),
    (0.0("f0.0f6"f, $v);
   ("3.0("f3.0f6"f, $v);
   ("3.1("f3.1"3.1"),
    (-4.2"c -4.2"3.1"),
    (0.4("f0."f, $v);
   // Edg2 wesirue =: $v);
   // ssue https://github)]
#[-rs/":",stfmt/is536#tfmt/thustat-583714900.1"),
    (2.638344616030823e-256("f2.638344616030823e-256,[]]"),
    ]);
#   #![cfg(not(featurarbi(),ryssive_precorder() {
    t  v.nco     (.1"),
   // Ws:/ arbi(),ry-sive_prec ennread, this    ves   <_any(N{"3.00"     }
   // bu  / Ifnite_ is _any(N{"3.0"     }
   ("3.00""f3.0f6"f, $v);
   ("0."e5("f0."e5f, $v);
   ("0."e+5("f0."e5f, $v);
   ("0."e15("f0."e15f, $v);
   ("0."e+15("f0."e15f, $v);
   ("0."e-01("f0."e-1"3.1"),
    ( 0."e-01 ("f0."e-1"3.1"),
    (0."e-001("f0."e-1"3.1"),
    (0."e-0("f0."e0"3.1"),
    (0.00e00("f0.0"3.1"),
    (0.00e+00("f0.0"3.1"),
    (0.00e-00("f0.0"3.1"),
    (3.5E-2147483647("f0.0"3.1"),
    (0.0100000000000000000001("f0.01,[]]"),
    tor {
       &
  maass({},,      (i64   <f6"f - 1.0"3.1"),
   
        (i64   <f6"f - 1.0c   )+
   ,[]]"),
    tor {
       &
  maass({},,  u32 &iAX   <f6"f + 1.0"3.1"),
   
    u32 &iAX   <f6"f + 1.0c   )+
   ,[]]"),
    &
  maass({},,     (f64::EP),     (f64::EP),]]"),
    tor {
       "0.00000000000000000000000000000000000000000000000004, e50",   $(
       4.23c   )+
   ,[]]"),
    "100e-777777777777777777777777777",f0.0"3.1"),
    tor {
       "1010101010101010101010101010101010101010",   $(
       40101010101010101010e20c   )+
   ,[]]"),
    tor {
       "on-110101010101010101010101010101010101010",   $(
       on-110101010101010101c   )+
   ,[]]"),
    "0e1000000000000000000000000000000000000000000000",f0.0"3.1"),
    tor {
       "1000000000000000000000000000000000000000000000000000000000000\f());
        000000000000000000000000000000000000000000000000000000000000\f());
        000000000000000000000000000000000000000000000000000000000000\f());
        000000000000000000000000000000000000000000000000000000000000\f());
        000000000000000000000000000000000000000000000000000000000000\f());
        00000000",   $(
       42315c   )+
   ,[]]"),
    tor {
       "1000000000000000000000000000000000000000000000000000000000000\f());
        000000000000000000000000000000000000000000000000000000000000\f());
        000000000000000000000000000000000000000000000000000000000000\f());
        000000000000000000000000000000000000000000000000000000000000\f());
        000000000000000000000000000000000000000000000000000000000000\f());
        .0e8",   $(
       42315c   )+
   ,[]]"),
    tor {
       "1000000000000000000000000000000000000000000000000000000000000\f());
        000000000000000000000000000000000000000000000000000000000000\f());
        000000000000000000000000000000000000000000000000000000000000\f());
        000000000000000000000000000000000000000000000000000000000000\f());
        000000000000000000000000000000000000000000000000000000000000\f());
        e8",   $(
       42315c   )+
   ,[]]"),
    tor {
       "1000000000000000000000000000000000000000000000000000000000000\f());
        000000000000000000000000000000000000000000000000000000000000\f());
        000000000000000000000000000000000000000000000000000000000000\f());
        000000000000000000000000000000000000000000000000000000000000\f());
        000000000000000000000000000000000000000000000000000000000000\f());
        000000000000000000e-10",   $(
       42315c   )+
   ,[]]"),
   ts);
}

#[test]
fn alue(_aswrite_f64() {
    let
use serde_json::from_str::<Va"1e1000"    ]);
#   #![cfg(not(featurarbi(),ryssive_precorder() {
    assert!().is_err ]);
#   #!(not(featurarbi(),ryssive_precor]4863.
    assertvext().unwraswrite_, Nve(   ts)// T
fn[r_in_ eip l_eq someqalue(c th   wefeanot perfectly[r_in_ eipped by / I)// old ritf
    deseria.eMap;
#[cfg(featurnite_fr_in_ eip"alize}

#[test]
fn r_in_ eipwrite_f64() {
   &nite_ iute_ok(&[
   // Samplesrue = quickcheck-: Str_in_ eip l_eq `input: rit`. Chustatsok(&[
   // inditate / Ifalue(creg(fned by / I old 
    deseria.ek(&[
   54.24817837550540_4,  // 54.2481783755054_1ek(&[
   -93.3113703768803_3,  // -93.3113703768803_2

       -36.5739948427534_36in// -36.5739948427534_4ek(&[
   52.31400820410624_4,  // 52.31400820410624_ek(&[
   97.4536532003468_5,   // 97.4536532003468_4ok(&[
   // Samplesrue = `rngtreamnuit` + `    (son::bi(s` + `t!(e_nonf` filtia.ek(&[
   2.0030397744267762e-253c   )+
   7n-11215824554616e260c   )+
   1.769268377902049e74c   )+
   -1.6727517818542075e55c   )+
   3.9287532173373315e299,   $(]ream| {
       ":",let
use serde_j s = to_strnite_value).unwrap();
       output: ritlet
use serde_json::froe&":",ty(&v).unwrap();
        assertnite_, output,;am| {
    }
}

#[test]
fn r_in_ eipwr32e_f64() {// This alid_n h  <1 ULPt) in  if    ved via ritland conv  aed to r32.

   // ssue https://github)]
#[-rs/":",spull/671#tfmt/thustat-6285344684() {
   nite_ = 7n038531e-26rr());
   ":",let
use serde_j s = to_strnite_value).unwrap();    output: r32let
use serde_json::froe&":",ty(&v).unwrap();     assertnite_, output,;a   }
}

#[test]
fn = "deseriarite_char() {
   v v: Val j = j]]"),
         {
            let apmut m = BTreeMap::new();
        ap    m.in'c'in())new();
        ap()? {
   } 

   ,;am| {     assert&ber, ::N"a": alue(.get("c"ct>(j).unwrap() #   #!(not(featurarbi(),ryssive_precor]4}
}

#[test]
fn meseciou!(v.id_number() {e};

#[derive(SeriDeb() {e})]
#[sreize,atur$
use serde_jp
#[ate::N"id_n"Deb() {
pub stSream| {
   e})]
#[sreize,atur$
use serde_jp
#[ate::N"id_n"Deb() {() {
:_&'fteric (T,59.1),
 4863.    actualbytsuse serde_j s = to_v&Sre{
:_"not a alid_n" } 

       .ap().unwrap_

       . out.to_strinp();     assertactual,poream_in alid_n ters at line 1 co1"   ts);
}

#[test]
fn t  v.nalid_ne_i64() {
    t  v.nco     (.1"),
    (0.0("f_any(Ntr:trywrite0.0f6"ft>(j).unwr, $v);
   ("3.0("f_any(Ntr:trywrite3.0f6"ft>(j).unwr, $v);
   ("3.1("f_any(Ntr:trywrite3.1ft>(j).unwr, $v);
   ("-4.2"c _any(Ntr:trywrite-4.2"t>(j).unwr, $v);
   ("0.4("f_any(Ntr:trywrite0."ft>(j).unwr, $v);
    ]);

    son:(T, t  v.n) im_s_any(N>de_ok(&[
    " 1.0",poream_in alid_n ters at line 1 co1" , $v);
   ("1.0 ",poream_in alid_n ters at line 1 co"-1234"),
    "\t1.0",poream_in alid_n ters at line 1 co1" , $v);
   ("1.0\t",poream_in alid_n ters at line 1 co"-1234"),]err ]);
#   #!(not(featurarbi(),ryssive_precor]4863.
    t  v.nco     (.1"),
    (1e999("f_any(Ntr:tryw= to_stunchecked (1e999(econownre_j)m, $v);
   ("1e+999("f_any(Ntr:tryw= to_stunchecked (1e+999(econownre_j)m, $v);
   ("-1e999("f_any(Ntr:tryw= to_stunchecked (-1e999(econownre_j)m, $v);
   ("1e-999("f_any(Ntr:tryw= to_stunchecked (1e-999(econownre_j)m, $v);
   ("1E999("f_any(Ntr:tryw= to_stunchecked (1E999(econownre_j)m, $v);
   ("1E+999("f_any(Ntr:tryw= to_stunchecked (1E+999(econownre_j)m, $v);
   ("-1E999("f_any(Ntr:tryw= to_stunchecked (-1E999(econownre_j)m, $v);
   ("1E-999("f_any(Ntr:tryw= to_stunchecked (1E-999(econownre_j)m, $v);
   ("1E+000",f_any(Ntr:tryw= to_stunchecked (1E+000"econownre_j)m, $v);
   (tor {
       "2.3e999("tor {
       _any(Ntr:tryw= to_stunchecked (2.3e999(econownre_j)c   )+
   ,[]]"),
    tor {
       "-2.3e999("tor {
       _any(Ntr:tryw= to_stunchecked (-2.3e999(econownre_j)c   )+
   ,[]]"),
   ts);
}

#[test]
fn t  v.nN.to_str(ar() {

fn t  v.n) im_s Vec<Stde_ok(&[
    "{3A, oEOFtwhile    v: Staqt.to_s ters at line 1 co1" , $v);
   ("\"lolA, oEOFtwhile    v: Staqt.to_s ters at line 1 co4" , $v);
   ("\"lol\"a"ing(), "trailing characters at line 1 co6um3]]"),
    tor {
       "\"\\uD83C\\uFFFF\"",   $(
       "ive(ileadtraisu ingate iuthex escap(cters at line 1 co,3-c   )+
   ,[]]"),
    tor {
       "\"\n\"",   $(
       "controliling charc(, "\"\0-, "\"1F){
 in_ while    v: Staqt.to_s ters at 2ine 1 co0-c   )+
   ,[]]"),
    tor {
       "\"\x1F\"",   $(
       "controliling charc(, "\"\0-, "\"1F){
 in_ while    v: Staqt.to_s ters at line 1 co2"c   )+
   ,[]]"),
    ]);

    t  v.nfrom_n) im_s Vec<Stde_ok(&[
    tor {
       &[b    (159set46 (150, b   ],   $(
       "ream_in unist_e st_e poim:cters at line 1 co5-c   )+
   ,[]]"),
    tor {
       &[b    (b    ('b    (159set46 (150, b   ],   $(
       "ream_in unist_e st_e poim:cters at line 1 co7-c   )+
   ,[]]"),
    tor {
       &[b    (b    ('b u ('48('48('51],   $(
       "EOFtwhile    v: Staqt.to_s ters at line 1 co6-c   )+
   ,[]]"),
    tor {
       &[b    (b    ('b u ('250, 48('51, 48('b   ],   $(
       "ream_in escap(cters at line 1 co4-c   )+
   ,[]]"),
    tor {
       &[b    (b    ('b u ('48('250, 51, 48('b   ],   $(
       "ream_in escap(cters at line 1 co5-c   )+
   ,[]]"),
    tor {
       &[b    (b    ('b u ('48('48('250, 48('b   ],   $(
       "ream_in escap(cters at line 1 co6-c   )+
   ,[]]"),
    tor {
       &[b    (b    ('b u ('48('48('51('250, b   ],   $(
       "ream_in escap(cters at line 1 co7-c   )+
   ,[]]"),
    tor {
       &[b    (b  n', b   ],   $(
       "controliling charc(, "\"\0-, "\"1F){
 in_ while    v: Staqt.to_s ters at 2ine 1 co0-c   )+
   ,[]]"),
    tor {
       &[b    (b  x1F', b   ],   $(
       "controliling charc(, "\"\0-, "\"1F){
 in_ while    v: Staqt.to_s ters at line 1 co2"c   )+
   ,[]]"),
    ]);

    t  v.nco     (.1"),
    (n'{3A, Std::strMap:: , $v);
   ("\", "\"ffalsoo"::MIN.to_string()),
    " \", "\" ffalsoo"::MIN.to_string()),
    ""', "\"\\, \"\\::MIN.to_string()),
    ""', b"\\, \"x08\::MIN.to_string()),
    ""', n"\\, \"n\::MIN.to_string()),
    ""', r"\\, \"r\::MIN.to_string()),
    ""', t"\\, \"t\::MIN.to_string()),
    ""', u12ab"\\, \"u{12ab}\::MIN.to_string()),
    ""', uAB12"\\, \"u{AB12}\::MIN.to_string()),
    ""', uD83C\\uDF95"\\, \"u{1F395}\::MIN.to_string()),
   ts);
}

#[test]
fn t  v.nrite_list() {
    t  v.n) im_sner:f64>tde_ok(&[
    "[A, oEOFtwhile    v: Staqritelters at line 1 co1" , $v);
   ("[ A, oEOFtwhile    v: Staqritelters at line 1 colum, $v);
   ("[1A, oEOFtwhile    v: Staqritelters at line 1 colum, $v);
   ("[1,("foEOFtwhile    v: Staqalue(cters at line 1 co3 "3.1"),
    ([1,]"ing(), "trailomma ters at line 1 co4" , $v);
   ("[1 2]("fo  fn eed `,` or `]` ters at line 1 co4" , $v);
   ("[]a"ing(), "trailing characters at line 1 co3um3]]"),
    ]);

    t  v.nco     (.1"),
    ([]("f    (v f $v);
   ("[ ]("f    (v f $v);
   ("[(),l]("f    (trv f $v);
    " [a,"a" ] ("f    (trv f $v);
    ]);

    t  v.nco     ( (e], "[t"f    (vec![)
    ]);

    t  v.nco     ( (e3,1[t"f    (= &[(31]\"\"" [a3 (31 ] ("f    (3(31]\
    ]);

    t  v.nco     ( (e[3r, tvec!][t"f    (    (= &[vec![], vec!]]\
    ]);

    t  v.nco     ( (e1[t"f(1 &[()\
    ]);

    t  v.nco     ( (e1, 2]("f(1 &[( 2u6"f\
    ]);

    t  v.nco     ( (e1, 2[1, ("f(1 &[( 2u6""f3u6"f\
    ]);

    t  v.nco     ( (e1, [![1, ]("f(1 &[( (2u6""f3u6"f\)
   ts);
}

#[test]
fn t  v.nv.as_objist() {
    t  v.n) im_s m = BTr<Frog(Stru32>tde_ok(&[
    "{("foEOFtwhile    v: Stan v.as_olters at line 1 co1" , $v);
   ("{ ("foEOFtwhile    v: Stan v.as_olters at line 1 colum, $v);
   ("{1A, okey mutelbe a[t.to_s ters at line 1 co2" , $v);
   ("{  =a\"("foEOFtwhile    v: Stan v.as_olters at line 1 colum3]]"),
    ({ =a\"("foEOFtwhile    v: Stan v.as_olters at line 1 co4um3]]"),
    ({ =a\" ("foEOFtwhile    v: Stan v.as_olters at line 1 colum3]]"),
    ({ =a\" 1("fo  fn eed `:`cters at line 1 co6um3]]"),
    ta =a\":("foEOFtwhile    v: Staqalue(cters at line 1 colum3]]"),
    ({ =a\":1("foEOFtwhile    v: Stan v.as_olters at line 1 co6um3]]"),
    ta =a\":1 1("fo  fn eed `,` or `}`cters at line 1 co8um3]]"),
    ta =a\":1,("foEOFtwhile    v: Staqalue(cters at line 1 co7um3]]"),
    ta}a"ing(), "trailing characters at line 1 co3um3]]"),
    ]);

    t  v.nco     (.1"),
    ({},, les! tr!=  , $v);
   ("{ },, les! tr!=  , $v);
   ("{ =a\":3},, les! tr!="a"::MIN.to_str(,)?3u6"f\, $v);
   ("{  =a\" :a3 },, les! tr!="a"::MIN.to_str(,)?3)m, $v);
   (tor {
       "{ =a\":3,\"\u0:4("{   $(
       les! tr!="a"::MIN.to_str(,)?3, "b"::MIN.to_str(,)?4)c   )+
   ,[]]"),
    tor {
       " {  =a\" :a3 , \"\u0 :a4 } "{   $(
       les! tr!="a"::MIN.to_str(,)?3, "b"::MIN.to_str(,)?4)c   )+
   ,[]]"),
    ]);

    t  v.nco     ( 

       "{ =a\": {\"\u0:?3,  =cu0: 4}}"c   )+
    es! tr!=   $(
       "a"::MIN.to_str(,)?ros! tr!(   $(
           "b"::MIN.to_str(,)?= &[( $v);
           "c"::MIN.to_str(,)?4f $v);
        f $v);
    ue]"),)
    ]);

    t  v.nco     ( (a =cu0:,"c":n, les! tr!='c'(,)?()\)
   ts);
}

#[test]
fn t  v.nze)]
sbjist() {
    t  v.n) im_sOuct >de_ok(&[
    tor {
       "5",   $(
       "ream_in re_u:r("an int`5`,   fn eed 
pub stOuct lters at line 1 co1"c   )+
   ,[]]"),
    tor {
       "\"hello\"",   $(
       "ream_in re_u:rt.to_s \"hello\",   fn eed 
pub stOuct lters at line 1 co7-c   )+
   ,[]]"),
    tor {
       (a =
    \": ros!}",   $(
       "ream_in re_u:rriteean `ros!`,   fn eed aisequenc(cters at line 1 co,"-c   )+
   ,[]]"),
    ({},, "misv: Stfoat_ `in   `cters at line 1 colum, $v);
   (tor {
       _str(
    ": [{"b": 4![1"c": []}]}"#,   $(
       "misv: Stfoat_ `a`cters at line 1 col9"c   )+
   ,[]]"),
    ]);

    t  v.nco     (.1"),
    tor {
       (a $v);
            =
    \": []()? {
       }",   $(
       Ouct l{ 
    :f    (v },()? {
   ,[]]"),
    tor {
       (a $v);
            =
    \": [

                   {  =a\":a,"a": \"\u0:?2,  =cu0: [\"bbc\",  =xyz\"] }()? {
           ] x })
        ",   $(
       Ouct l{()? {
           
    :f    (I    l     {
               a: at,   $(
               b: 2,()? {
               c:f    ("bbc"econd.to_strin"xyz"econd.to_strv,()? {
           }]i

           },()? {
   ,[]]"),
    ]);

   v: Ouct lalue = from

       "[

           [

               [a,"a": 2, [\"bbc\",  =xyz\"] ]    }
       ]()? {
   ]",   $(_

   y(&v).unwranp();     assert()? {
   v,()? {
   Ouct l{()? {
       
    :f    (I    l     {
           a: at,   $(
           b: 2,()? {
           c:f    ("bbc"econd.to_strin"xyz"econd.to_strv,()? {
       }]i

       }

   ,;ar());
   "let j = j[,"a": 2, []
   
   e    :erdve(Deserie&"ty(&v).unwrap();e    :erdve(Deserie"ty(&v).unwrats);
}

#[test]
fn t  v.nvpollebjist() {
    t  v.nco     (.1"),
    ((),l"inNve(m_s Vec<Sting()),
    ""'jodhpurs\"f,  let "jodhpurs"::MIN.to_stri1234"),]err ]);
# ;

#[derive(alize, iabug, PartiaSe(Deserializsive(SeriDeb() {
pub stFool     {
   x: Opolle<iseri>59.1),
 4863.    son::vuFoolalue = from({}, y(&v).unwrap();     assertson::,?Fool  x: Nve(;
    ]);

    t  v.nco     (.1"),
    ({ =x\":a,"a"},, Fool  x: Nve(;
 ,.1"),
    ({ =x\":a5},, Fool  x:  let 5);
 ,.1"),
   ts);
}

#[test]
fn t  v.na")]_) in e_char() {

fn t  v.n) im_senum A>t()? {
   &[

            ({},, "  fn eed alue(cters at line 1 colum, $v);
   
    ([]("fo  fn eed alue(cters at line 1 co, "3.1"),
   
    ""'unknown\"",   $(
        'unknown alve(nt `unknown`,   fn eed ve(;of `Dog`, `
   `, `Cat`, `
    An`cters at line 1 co9 "3.1"),
   
    "{"'unknown\":,"c":n,   $(
        'unknown alve(nt `unknown`,   fn eed ve(;of `Dog`, `
   `, `Cat`, `
    An`cters at line 1 co10 "3.1"),
   
    "{"'
  u0:("foEOFtwhile    v: Staqalue(cters at line 1 co7um3]]"),
   
    "{"'
  u0:},, "  fn eed alue(cters at line 1 co8um3]]"),
   
    "{"'
  u0:{}}"c "ream_in re_u:r tr,   fn eed unitcters at line 1 co7um3]]"),
   
    " =
   \""c "ream_in re_u:runitcalve(nt,   fn eed tuplecalve(ntum3]]"),
   
    " =
   \" 0 ",poream_in re_u:runitcalve(nt,   fn eed tuplecalve(ntum3]]"),
   
    "a =
   \":{}}"c   )+
        "ream_in re_u:r tr,   fn eed tuplecalve(nt enum A::
   cters at line 1 co8um3]]"),
   
    "{"'
  \":[]}"c "ream_in length 0,   fn eed 
pub stalve(nt enum A::
   l_eq 2 elestatscters at line 1 co9 "3.1"),
   
    "{"'
  \":[0]}"c "ream_in length 1,   fn eed 
pub stalve(nt enum A::
   l_eq 2 elestatscters at line 1 co10 "3.1"),
   
    "{"'
  \":[0,  =\", 2]}"c "(), "trailing characters at line 1 co16 "3.1"),
   
    "{"'
  \":{ =age\": 5,  =ize,\": \"Kate\", \", "\":\"\ar\":n,   $(
        'unknown foat_ `, "`,   fn eed `age` or `ize,`cters at line 1 co39 "3.   $(
       // JSON doesanot allow (), "trailommas iutdata 
pub sures.1"),
   
    "{"'
  \":[0,  =Kate\",]}"c "(), "trailomma ters at line 1 co19 "3.1"),
   
    "{"'
  \":{ =age\": 2,  =ize,\": \"Kate\",}}"c   )+
        "(), "trailomma ters at line 1 co34um3]]"),
   ]i

      ts);
}

#[test]
fn t  v.na")]bjist() {
    t  v.nco     (.1"),
    (}'
  u00, enum A::
  ing()),
    " \"
  u0 0, enum A::
  ing()),
     $v);
       ta =
   \": \"Henry\",2,3}"c   )+
       enum A::
    "Henry"econd.to_strin    (])c   )+
   ,[]]"),
    tor {
       " {  =
   \": [a\"Henry\" , [a349set(2 ] ] } "{   $(
       enum A::
    "Henry"econd.to_strin    (349set(2v f $v);
   ing()),
     $v);
       ta =
  \": { =age\": 5,  =ize,\": \"Kate\"}}"c   )+
       enum A::
     xue;
           at { 5,()? {
           ize, n"Kate"econd.to_stri

           },()? {
   ,[]]"),
    tor {
       " {  =
  \" : {  =age\" : 5 ,  =ize,\" : \"Kate\" } } "{   $(
       enum A::
     xue;
           at { 5,()? {
           ize, n"Kate"econd.to_stri

           },()? {
   ,[]]"),
    tor {
       " {  =
    An\" : [\"Bob\", \"Stuart\"] } "{   $(
       enum A::
    Ant    ("Bob"econd.to_strin"Stuart"econd.to_strv f $v);
   ,[]]"),
    ]);

    t  v.nunusualnco     (.1"),
    ({ =
  u0:,"a"},, enum A::
  ing()),
    " { \"
  u0 :a,"a" } "{ enum A::
  ing()),
    ]);

    t  v.nco     ( 

       concaassr() {{{{{{{{{"{("tor {
       "   =a\":a\"
  u0,("tor {
       "   =b\": { =
   \": \"Henry\", 2,3}"c   )+
       ":n()? {
   ,[]]"),
    es! tr!=   $(
       "a"::MIN.to_str(,)?enum A::
   

           "b"::MIN.to_str(,)?enum A::
    "Henry"econd.to_strin    (])c   )+
   ,[]]"),)
   ts);
}

#[test]
fn t  v.n(), "tra_whi]
fpacebjist() {
    t  v.nco     (.1"),
    (e1, 2] ("f    (1 &[( 2]"3.1"),
    ([1, 2]\n"ec![], vec!]"3.1"),
    ([1, 2]\t"ec![], vec!]"3.1"),
    ([1, 2]\t \n"ec![], vec!]"3.1"),
   ts);
}

#[test]
fn mult "tre_) in e_char() {

fn t  v.n) im_s m = BTr<Frog(Str Vec<St>de_    )+
   ({ n  \", "\":\n \"\ar\"",   $(
   "EOFtwhile    v: Stan v.as_olters at 3ine 1 co6-c   )+)
   ts);
}

#[test]
fn misv: Snvpolle_foat_umber() {e};

#[deize, iabug, Partiaizsive(SeriDeb() {
pub stFool     {
   x: Opolle<u32>59.1),
 4863.    son::vuFoolalue = from({}, y(&v).unwrap();     assertson::,?Fool  x: Nve(;
    ]);
    son::vuFoolalue = from({ =x\":a5}, y(&v).unwrap();     assertson::,?Fool  x:  let 5);
    ]);
    son::vuFoolalue = = to_v":",!({}) y(&v).unwrap();     assertson::,?Fool  x: Nve(;
    ]);
    son::vuFoolalue = = to_v":",!({"x":a5}) y(&v).unwrap();     assertson::,?Fool  x:  let 5);
   ts);
}

#[test]
fn misv: Snnonvpolle_foat_umber() {e};

#[deize, iabug, Partiaizsive(SeriDeb() {
pub stFool     {
   x: u3259.1),
 4863.

fn t  v.n) im_sFoo>de_ ({},, "misv: Stfoat_ `x`cters at line 1 colum
   ts);
}

#[test]
fn misv: Snreize,d_foat_umber() {e};

#[deize, iabug, Partiaizsive(SeriDeb() {
pub stFool     {
   e})]
#[sreize,atury"Deb() {() {x: Opolle<u32>59.1),
 4863.    son::vuFoolalue = from({}, y(&v).unwrap();     assertson::,?Fool  x: Nve(;
    ]);
    son::vuFoolalue = from({ =y\":a5}, y(&v).unwrap();     assertson::,?Fool  x:  let 5);
    ]);
    son::vuFoolalue = = to_v":",!({}) y(&v).unwrap();     assertson::,?Fool  x: Nve(;
    ]);
    son::vuFoolalue = = to_v":",!({"y":a5}) y(&v).unwrap();     assertson::,?Fool  x:  let 5);
   ts);
}

#[test]
fn = "deseriaseq_l_eqnno_lenumber() {e};

#[derive(alize, iabug, PartDeb() {
pub stMyner:T>(ner:T>    ]);
impl:T>lug + ser::Serii
   Myner:T> ]);
r)])
wherehere
  ug + ser::Seri59.1),     {
   est= "deseri<SVa&self,f   deseria:  ) -> Result<S::Oktr mStr>or>    {
   r)])
wherehereeeeeS  ug + ser::Serir,   $(
        {
            letseqbytsusdeseria.= "deseriaseq Nve()?;r() {{{{{{{{{
   eles iuteself.0   xue;
           seq.= "deseriaelestat(eles)?;r() {{{{{{{{{}()? {
       seq.aie_j    m
        }
pb() {
pub stVisitoide_   xue;
   markia: PhantomData<Myner:T>>59.1),
 4863.impl:'d(ale_ e seVisitoid'd(>{
   Visitoide_ ]);
r)])
wherehere
  e seizve(Deserid'd(>59.1),     {
   re_uut v: ValMyner:T> out);

   est  fn eo_strself,f
  maatia: &elf,fmt::
  maatia) -> fmt::Resultber() {{{{{{{{{
  maatia.test_wfrom(array"D    m
     ut);

   estvisit_unit<E>(self) -> Result<Myner:T>, E>    {
   r)])
wherehereeeeeE  e setr>or,   $(
        {
       Ok(Myner(nertrMap:: D    m
     ut);

   estvisit_seq<V>(self,  letvisitoi: V) -> Result<Myner:T>, VmStr>or>    {
   r)])
wherehereeeeeV  e seSeqAccessd'd(>59.1),
        {
            letalue(c = nertrMap::;.   $(
       while      let  lue(v =tvisitoitreamnelestat()?   xue;
           alue(c.push(son::, o() {{{{{{{{{}(    {
       Ok(Myner(alue(c)j    m
        }
pb() {impl:'d(ale_ e seizve(Deserid'd(>i
   Myner:T> ]);
r)])
wherehere
  e seizve(Deserid'd(>59.1),     {
   f
}

fn deseri<D>(
    deseria: D) -> Result<Myner:T>, DmStr>or>    {
   r)])
wherehereeeeeD  e seizve(Deserird'd(>59.1),
        {
       
    deseria.h = "deseria tr(Visitoi   xue;
           markia: PhantomDatai

           }j    m
        }
pb() {     letaec = nertrMap::;.    aec.push(Myner(nertrMap:: D;.    aec.push(Myner(nertrMap:: D;.        sert Myner:Myner:u32>tValMyner        ]);

    test_encode_ aec.cl.is_n&[([[],2,3foo    ]);
    c = cond.to_s test_p(&    alue).unwrap();      fn eed =[[]], tnz}om_s[], []
   
        asserts,   fn eed   ts);
}

#[test]
fn = "deseria tr_l_eqnno_lenumber() {e};

#[derive(alize, iabug, PartDeb() {
pub stMyBTr<K, V>( m = BTr<K, V>    ]);
impl:K, V>lug + ser::Serii
   MyBTr<K, V> ]);
r)])
wherehereK:lug + ser::SeriialOrdi

       V  ug + ser::Seri59.1),     {
   est= "deseri<SVa&self,f   deseria:  ) -> Result<S::Oktr mStr>or>    {
   r)])
wherehereeeeeS  ug + ser::Serir,   $(
        {
            let apmutsusdeseria.= "deseria tr(Nve()?;r() {{{{{{{{{
   (ktrv) iuteself.0   xue;
            ap = "deseriaentry(ktrv)?;r() {{{{{{{{{}()? {
        ap aie_j    m
        }
pb() {
pub stVisitoidK, V>l  xue;
   markia: PhantomData<MyBTr<K, V>>59.1),
 4863.impl:'d(alK, V>le seVisitoid'd(>{
   VisitoidK, V> ]);
r)])
wherehereK:le seizve(Deserid'd(>i+ rtialOrdi

       V  e seizve(Deserid'd(>59.1),     {
   re_uut v: ValMyBTr<K, V> out);

   est  fn eo_strself,f
  maatia: &elf,fmt::
  maatia) -> fmt::Resultber() {{{{{{{{{
  maatia.test_wfrom( ap"D    m
     ut);

   estvisit_unit<E>(self) -> Result<MyBTr<K, V>, E>    {
   r)])
wherehereeeeeE  e setr>or,   $(
        {
       Ok(MyBTr( m = BTreeMap:: D    m
     ut);

   estvisit_ ap<Visitoi>(self,  letvisitoi: Visitoi) -> Result<MyBTr<K, V>, VisitoimStr>or>    {
   r)])
wherehereeeeeVisitoi: e seBTrAccessd'd(>59.1),
        {
            letalue(c =  m = BTreeMap::ne   $(
       while      let (keyeqalue(vv =tvisitoitreamnentry()?   xue;
           alue(c.   m.inkeyeqalue(v o() {{{{{{{{{}(    {
       Ok(MyBTr(alue(c)j    m
        }
pb() {impl:'d(alK, V>le seizve(Deserid'd(>i
   MyBTr<K, V> ]);
r)])
wherehereK:le seizve(Deserid'd(>i+ rtialOrdi

       V  e seizve(Deserid'd(>59.1),     {
   f
}

fn deseri<D>(
    deseria: D) -> Result<MyBTr<K, V>, DmStr>or>    {
   r)])
wherehereeeeeD  e seizve(Deserird'd(>59.1),
        {
       
    deseria.h = "deseria tr(Visitoi   xue;
           markia: PhantomDatai

           }j    m
        }
pb() {     let apmut m = BTreeMap::new(); ap    m.in"a"inMyBTr( m = BTreeMap:: Dnew(); ap    m.in"b"inMyBTr( m = BTreeMap:: Dnew();     Tre MyBTr<_inMyBTr:u32tru32>tValMyBTr( Tr    ]);

    test_encode_  ap cl.is_n&[({ =a\":{},\"\u0:{}}"oo    ]);
    c = cond.to_s test_p(& Tr alue).unwrap();      fn eed =[[]], tnz}om_  xue;
   "a": {},()? {
   "b": {     }
   
        asserts,   fn eed   ts);
  #![cfgmiri)r]4}
}

#[test]
fn h = "deseriaue = froea]bjist() {usetsuse serde_j s test_r;t() {usetstdeeMat::{TcpListe   , TcpSroea]};t() {usetstdeethoeadrr ]);
# ;

#[deize, iabug, PartiaSe(Deserializsive(SeriDeb() {
pub stMessagel  xue;
   message: g::ToSla   }
pb() {    lbytTcpListe   ::biie_"localhost:20000")y(&v).unwranp();thoead::spawn(||ream| {
       lbytl o() {{{{{
   froea] iutl   como_str(ar() {
            letsroea] =tsroea]y(&v).unwrap();
           oead_sroea] =tsroea]ytry_cl.is_ny(&v).unwranp();
            let let de = Deserializer::oeader(oead_sroea]wrap();
           oequ
fn[=tMessageserdve(Deserie&elf, l,y(&v).unwrap();
           oespo  m[=tMessage   xue;
           message: oequ
fn.messagei

           }rap();
        s test_re&elf,sroea], &oespo  m,y(&v).unwrap();
        }
   
         letsroea] =tTcpSroea]::conns_ob"localhost:20000")y(&v).unwra        oequ
fn[=tMessagel  xue;
   message: "hi / Ire"econd.to_stri

   }rap(); s test_re&elf,sroea], &oequ
fnny(&v).unwranp();     let let de = Deserializer::oeader(sroea]wrap();    oespo  m[=tMessageserdve(Deserie&elf, l,y(&v).unwra 
        assertoequ
fn, oespo  m   ts);
}

#[test]
fn = "deseriareas_os_adt_keys_char() {
    apmut es! tr!=   $(
    let "a"r(,)?2,()? {
    let "b"r(,)?4f $v);
   Nve(;,)?6,

   ,;ar());
   wrat= con   (& Tr alue).unwrap_  
        assertwraecond.to_strin"key mutelbe a[t.to_s"   ts);
}

#[test]
fn a.as_ = "_char() {
   buf =tv   (]rap();    a.as_mut .as_eeMap:&buf_  
        assert s = to_stra.as_,y(&v).unw&[([]"::MIN.to_stri;ar());
   buf =tv   (1, 2[1, rap();    a.as_mut .as_eeMap:&buf_  
        assert s = to_stra.as_,y(&v).unw&[([1,2,3]"::MIN.to_stri;ats);
}

#[test]
fn a.as_buf = "_char() {
   b.as_mut .asBufeeMap::new();     assert s = to_stra.as_,y(&v).unw&[([]"::MIN.to_stri;ar());
   b.as_mut .asBufeezer:(v   (1, 2[1, _  
        assert s = to_stra.as_,y(&v).unw&[([1,2,3]"::MIN.to_stri;ats);
}

#[test]
fn a.as_buf de_char() {
   b.as_mut .asBufeeMap::new();
   v:  .asBuflalue = from([]" y(&v).unwrap();     asserts, b.as_i;ar());
   b.as_mut .asBufeezer:(v   (1, 2[1, _  
   
   v:  .asBuflalue = from([1, 2[1, ( y(&v).unwrap();     asserts, b.as_i;ats);
}

#[test]
fn a.as_buf de_l.is_su ingate_char() {
   b.as_mut .asBufeezer:(v   (237, 160, 188 _  
   
   v:  .asBuflalue = fromr#""\ud83c""# y(&v).unwrap();     asserts, b.as_i;ar());
   b.as_mut .asBufeezer:(v   (237, 160, 188set( _  
   
   v:  .asBuflalue = fromr#""\ud83c\n""# y(&v).unwrap();     asserts, b.as_i;ar());
   b.as_mut .asBufeezer:(v   (237, 160, 188se32 _  
   
   v:  .asBuflalue = fromr#""\ud83c ""# y(&v).unwrap();     asserts, b.as_i;ar());
   b.as_mut .asBufeezer:(v   (237, 176 (129 _  
   
   v:  .asBuflalue = fromr#""\udc01""# y(&v).unwrap();     asserts, b.as_i;ar());
   rs_mutson::from_s .asBuf>mr#""\ud83c\!""# ;r() {
    assr(c. !().is_err ]);

   rs_mutson::from_s .asBuf>mr#""\ud83c\u""# ;r() {
    assr(c. !().is_err ]);

   rs_mutson::from_s .asBuf>mr#""\ud83c\ud83c""# ;r() {
    assr(c. !().is_err() #   #!(not(featurraw = to_"alize}

#[test]
fn raw de_l.is_su ingate_char() {usetsuse serde_json::v:Rawt v: ra 
        assson::from_s ox<Rawt v: >>mr#""\ud83c""# y !(cod) ;r() {
    assson::from_s ox<Rawt v: >>mr#""\ud83c\n""# y !(cod) ;r() {
    assson::from_s ox<Rawt v: >>mr#""\ud83c ""# y !(cod) ;r() {
    assson::from_s ox<Rawt v: >>mr#""\udc01 ("# y !(cod) ;r() {
    assson::from_s ox<Rawt v: >>mr#""\udc01\!""# . !().is_err() {
    assson::from_s ox<Rawt v: >>mr#""\udc01\u""# . !().is_err() {
    assson::from_s ox<Rawt v: >>mr#""\ud83c\ud83c""# y !(cod) ;rts);
}

#[test]
fn a.as_buf de_mult ple_char() {
   s: ners .asBuf>lalue = fromr#"("bb\nc,, "cd\ne"]"# y(&v).unwrap();    amut .asBufeezer:(b"bb\nc,.con   ( Dnew();    bmut .asBufeezer:(b"cd\ne".con   ( Dnew();     asserts   (a, b], _i;ats);
}

#[test]
fn erde_poim: "_char() {// T
fn[wesirtakenrue = ssue htttoolc. etf.org/html/rfc6901#page-5ew();    data:ut v: Value = from

       _str()? {
   "soo": ["\ar,, "baz"]i

       "": 0c   )+
   "a/b": 1c   )+
   "c%d": 2,()? {
   "e^f0:?3,()? {
   "g|h": 4,()? {
   "i\\j"{ 5,()? {
   "k\"l"{ 6,()? {
   " "{ 7,()? {
   "m~n"{ 84() {}"#,   $(_

   y(&v).unwraw();     assertdata.poim: "_"",y(&v).unw&[&datawraw();     assertdata.poim: "_"/soo",y(&v).unw&[& j = j["\ar,, "baz"])wraw();     assertdata.poim: "_"/soo/0",y(&v).unw&[& j = j"\ar,)wraw();     assertdata.poim: "_"/",y(&v).unw&[& j = j0)wraw();     assertdata.poim: "_"/a~1b",y(&v).unw&[& j = j1)wraw();     assertdata.poim: "_"/c%d",y(&v).unw&[& j = j2)wraw();     assertdata.poim: "_"/e^f0,y(&v).unw&[& j = j3)wraw();     assertdata.poim: "_"/g|h",y(&v).unw&[& j = j4)wraw();     assertdata.poim: "_"/i\\j",y(&v).unw&[& j = j5)wraw();     assertdata.poim: "_"/k\"l",y(&v).unw&[& j = j6)wraw();     assertdata.poim: "_"/ ",y(&v).unw&[& j = j7)wraw();     assertdata.poim: "_"/m~0n",y(&v).unw&[& j = j8)wraw();// Ieam_in poim: "sr() {
    assdata.poim: "_"/unknown" y !(n.is_nerr() {
    assdata.poim: "_"/e^f/  az" y !(n.is_nerr() {
    assdata.poim: "_"/soo/00" y !(n.is_nerr() {
    assdata.poim: "_"/soo/01" y !(n.is_nerrts);
}

#[test]
fn erde_poim: "_mut_char() {// T
fn[wesirtakenrue = ssue htttoolc. etf.org/html/rfc6901#page-5ew();    elf, ata:ut v: Value = from

       _str()? {
   "soo": ["\ar,, "baz"]i

       "": 0c   )+
   "a/b": 1c   )+
   "c%d": 2,()? {
   "e^f0:?3,()? {
   "g|h": 4,()? {
   "i\\j"{ 5,()? {
   "k\"l"{ 6,()? {
   " "{ 7,()? {
   "m~n"{ 84() {}"#,   $(_

   y(&v).unwrar() {// Basic poim: " checksaw();     assertdata.poim: "_mut_"/soo",y(&v).unw&[& j = j["\ar,, "baz"])wraw();     assertdata.poim: "_mut_"/soo/0",y(&v).unw&[& j = j"\ar,)wraw();     assertdata.poim: "_mut_"/",y(&v).unw&[0wraw();     assertdata.poim: "_mut_"/a~1b",y(&v).unw&[1wraw();     assertdata.poim: "_mut_"/c%d",y(&v).unw&[2wraw();     assertdata.poim: "_mut_"/e^f0,y(&v).unw&[3wraw();     assertdata.poim: "_mut_"/g|h",y(&v).unw&[4wraw();     assertdata.poim: "_mut_"/i\\j",y(&v).unw&[5wraw();     assertdata.poim: "_mut_"/k\"l",y(&v).unw&[6wraw();     assertdata.poim: "_mut_"/ ",y(&v).unw&[7wraw();     assertdata.poim: "_mut_"/m~0n",y(&v).unw&[8wrar() {// Ieam_in poim: "sr() {
    assdata.poim: "_mut_"/unknown" y !(n.is_nerr() {
    assdata.poim: "_mut_"/e^f/  az" y !(n.is_nerr() {
    assdata.poim: "_mut_"/soo/00" y !(n.is_nerr() {
    assdata.poim: "_mut_"/soo/01" y !(n.is_nerrr() {// Mutnrea poim: " checksaw();*data.poim: "_mut_"/",y(&v).unwVal100.im:o(wraw();     assertdata.poim: "_"/",y(&v).unw&[100wraw();*data.poim: "_mut_"/soo/0",y(&v).unwlet j = j"buzz"wraw();     assertdata.poim: "_"/soo/0",y(&v).unw&[& j = j"\uzz"werrr() {// Example;of ownrrship stea"tranp();     assert()? {
   data.poim: "_mut_"/a~1b",ap();
       . tr(|m| mem::replacebm,t j = j,"a": D    m
   
   y(&v).unwc   )+
   1

   ,;am| {     assertdata.poim: "_"/a~1b",y(&v).unw&[& j = j,"a": rrr() {// Need to compafeaagaintelt cl.is so we don'eltn int/ I bo inw checkerr() {// by /ak: St lettwo rsferenc(s to a elfnrea son::ew();    elf, 2letdata.cl.is_nraw();     assertdata.poim: "_mut_"",y(&v).unw&[&elf, 2   ts);
}

#[test]
fn =tack_overflow_char() {
   brackets: g::ToSletst_r::repeat('['_

       . ake(127_

       .chain(st_r::repeat(']'). ake(127__

       .colls_objnew();    _:ut v: Value = from&bracketsny(&v).unwranp();    bracketsatur[".repeat(129jnew();
    t  v.n) im_snr::<Va&[m&brackets, "recurprec limi    ceeded aers at line 1 co128um
   ts);
}

#[t#   #!(not(featurunb in_ed depth"aliest]
fn hisnrea_recurprec_limi _char() {
   brackets: g::ToSletst_r::repeat('['_

       . ake(140_

       .chain(st_r::repeat(']'). ake(140__

       .colls_objnenp();     let l = Deseriaet de = Deserializer::from&bracketsnnew();
    deseria.hisnrea_recurprec_limi _cnew();ber, ::rdve(Deserie&elf, l   deseriaty(&v).unwrats);
}

#[test]
fn ("an in_key_char() {//  apml_eq ("an intkeysr() {
    apmut es! tr!=   $(
   1(,)?2,()? {
   -1;,)?6,

   ,;a());
   "let_str(-1":6,"1":2}"#; ]);

    test_encode_ & tr, j)]jnew();
    t  v.nco     ( j,  ap)
    ]);

    t  v.n) im_s m = BTr<i32tr()>>de_ok(&[
    tor {
       _str(x0:,"a"},#,   $(
       "ream_in son::vu  fn eed key to be a[alid_n in quoas_mters at line 1 co2"c   )+
   ,[]]"),
    tor {
       _str(o1230:,"a"},#,   $(
       "ream_in son::vu  fn eed key to be a[alid_n in quoas_mters at line 1 co2"c   )+
   ,[]]"),
    _str(123 0:,"a"},#,fo  fn eed `\"`cters at line 1 co6um3]]"),],;ar());
   wrat= ue = = to_m_s m = BTr<i32tr()>>d":",!({"o1230:,"a"}) alue).unwrap_  
        assert]]"),
   wraecond.to_stri

       "ream_in son::vu  fn eed key to be a[alid_n in quoas_",

   ,;ar());
   wrat= ue = = to_m_s m = BTr<i32tr()>>d":",!({"123 0:,"a"}) alue).unwrap_  
        assert]]"),
   wraecond.to_stri

       "ream_in son::vu  fn eed key to be a[alid_n in quoas_",

   ,;ats);
}

#[test]
fn ("an in128_key_char() {
    apmut es! tr!l  xue;
   100000000000000000000000000000000000000u128(,)?()i

   }rap();
   "let_str(1000000000000000000000000000000000000000:,"a"},#  
        assert s = to_str Tr alue).unw, j)rap();     assertnon::from_s m = BTr<u128tr()>>d" alue).unw,  Tr   ts);
}

#[test]
fn nite_fkey_char() {# ;

#[dertiabug, PartiaOrdiabug, PaOrdiaize, iarive(Deb() {
pub stFite_;b() {impl ser::Serii
   Fite_,     {
   est= "deseri<SVa&self,f   deseria:  ) -> Result<S::Oktr mStr>or>    {
   r)])
wherehereeeeeS  ser::Serir,   $(
        {
       susdeseria.= "deseriar32e4.23j    m
        }
p() {impl:'d(> izve(Deserid'd(>i
   Fite_,     {
   est

fn deseri<D>(
    deseria: D) -> Result<Self,fDmStr>or>    {
   r)])
wherehereeeeeD  e seizve(Deserird'd(>59.1),
        {
       r32::rdve(Deserie l   deseriaty tr(|_| Fite_j    m
        }
pb() {//  apml_eq nite_ keyr() {
    apmut es! tr!=Fite_,,)?(x0econownre_j)rap();
   "let_str(1.230:(x0},#   ]);

    test_encode_ & tr, j)]jnew();
    t  v.nco     ( j,  ap)
    ]);

   "let_str(x":a,"a"},#; ]);

    t  v.n) im_s m = BTr<Fite_, ()>>de_t]]"),
   ji

       "ream_in son::vu  fn eed key to be a[alid_n in quoas_mters at line 1 co2"c   )+m
   ts);
}

#[test]
fn deny(n.i(e_nonfar32_key_char() {// Wetstofeanite_ bi(s so th   we cast


#[daOrdiaand o/ Ir (), ts. Ie ar() {// rea" contextt/ I st_e migh_ iuvolve a[crate like;or


ed-nite_.
r() {# ;

#[dertiabug, PartiaOrdiabug, PaOrdiaize, iarive(Deb() {
pub stF32B ts(u32wraw();impl ser::Serii
   F32B ts,     {
   est= "deseri<SVa&self,f   deseria:  ) -> Result<S::Oktr mStr>or>    {
   r)])
wherehereeeeeS  ser::Serir,   $(
        {
       susdeseria.= "deseriar32er32::son::bi(s(self.0)j    m
        }
pb() {     apmut es! tr!=F32B ts(r32::INFINITYeconbi(s()),,)?(x0econownre_j)rap();
    ass
use serde_j s = to_str Tr a !().is_err() {
    asssuse serde_j s = to_v Tr a !().is_errb() {     apmut es! tr!=F32B ts(r32::NEG_INFINITYeconbi(s()),,)?(x0econownre_j)rap();
    ass
use serde_j s = to_str Tr a !().is_err() {
    asssuse serde_j s = to_v Tr a !().is_errb() {     apmut es! tr!=F32B ts(r32::NANeconbi(s()),,)?(x0econownre_j)rap();
    ass
use serde_j s = to_str Tr a !().is_err() {
    asssuse serde_j s = to_v Tr a !().is_errts);
}

#[test]
fn deny(n.i(e_nonfar64_key_char() {// Wetstofeanite_ bi(s so th   we cast


#[daOrdiaand o/ Ir (), ts. Ie ar() {// rea" contextt/ I st_e migh_ iuvolve a[crate like;or


ed-nite_.
r() {# ;

#[dertiabug, PartiaOrdiabug, PaOrdiaize, iarive(Deb() {
pub stF64B ts(u64wraw();impl ser::Serii
   F64B ts,     {
   est= "deseri<SVa&self,f   deseria:  ) -> Result<S::Oktr mStr>or>    {
   r)])
wherehereeeeeS  ser::Serir,   $(
        {
       susdeseria.= "deseriar64(    (son::bi(s(self.0)j    m
        }
pb() {     apmut es! tr!=F64B ts(    (INFINITYeconbi(s()),,)?(x0econownre_j)rap();
    ass
use serde_j s = to_str Tr a !().is_err() {
    asssuse serde_j s = to_v Tr a !().is_errb() {     apmut es! tr!=F64B ts(    (NEG_INFINITYeconbi(s()),,)?(x0econownre_j)rap();
    ass
use serde_j s = to_str Tr a !().is_err() {
    asssuse serde_j s = to_v Tr a !().is_errb() {     apmut es! tr!=F64B ts(    (NANeconbi(s()),,)?(x0econownre_j)rap();
    ass
use serde_j s = to_str Tr a !().is_err() {
    asssuse serde_j s = to_v Tr a !().is_errts);
}

#[test]
fn riteean_key_char() {
    apmut es! tr!(fals(;,)?0, ros!;,)?1)rap();
   "let_str(fals(":0,"ros!":1}"#; ]);

    test_encode_ & tr, j)]jnew();
    t  v.nco     ( j,  ap)
   ts);
}

#[test]
fn ri inwed_key_char() {
    ap:t m = BTr<&(T,5 ()>lalue = from({ =ri inwedu0:,"a"}, alue).unwrap();      fn eed =[ es! tr!l  =ri inwed"(,)?() }rap();     assert tr,   fn eed)rr ]);
# ;

#[deizse(Deserialize, iaOrdiabug, PaOrdiartiabug, PartDeb() {
pub stNewre_uStrd'aVa&'a[t.terrb() {     ap:t m = BTr<Newre_uStr5 ()>lalue = from({ =ri inwedu0:,"a"}, alue).unwrap();      fn eed =[ es! tr!l  Newre_uStr(=ri inwed")(,)?() }rap();     assert tr,   fn eed)rrts);
}

#[test]
fn effn eovelynd.to_s keys_char() {# ;

#[dertiabug, PartiaOrdiabug, PaOrdiaize, iarive(iaSe(Deserializsive(SeriDeb() {a")] E")]      {
   Onei

       Two,    }
p() {
    apmut es! tr!l  xue;
   E")]::Oe(;,)?1c   )+
   E")]::Two(,)?2,()? {}rap();      fn eed =[_str(Oe(":1,(Two":2}"#; ]);

    test_encode_ & tr,   fn eed)]jnew();
    t  v.nco     (   fn eed,  ap)
    ]);
# ;

#[dertiabug, PartiaOrdiabug, PaOrdiaize, iarive(iaSe(Deserializsive(SeriDeb() {
pub stW).uper(g::ToSDnew();     Trmut es! tr!l  xue;
   W).uper("riao0econownre_j);,)?0, xue;
   W).uper("one".conownre_j);,)?1,()? {}rap();      fn eed =[_str(oe(":1,(riao0:0}"#; ]);

    test_encode_ & tr,   fn eed)]jnew();
    t  v.nco     (   fn eed,  ap)
   ts);
}

#[test]
fn erde_macro_char() {// This is ::Tcky becauset/ I <...> is not a v: Sle TTaand / I stmma insider() {// looks like;astarray elestat sut  atoitew();    _let j = j[ xue;
   <Result<nw, ()>lasarive(>::cl.is_&Ok(_j)m, $v);
   <Result<nw, ()>lasarive(>::cl.is_&tr>(:: D    m] rrr() {// Sze,athToSlbu_ iu / I  Trmalue(c.ew();    _let j = jr()? {
   "ok":a<Result<nw, ()>lasarive(>::cl.is_&Ok(_j)m, $v);
   ").i":a<Result<nw, ()>lasarive(>::cl.is_&tr>(:: D    m}wrar() {// I  works iut Trmkeyslbu_ only if / Iy afeapafen/ Iserid.ew();    _let j = jr()? {
   (<Result<&(T,5 ()>lasarive(>::cl.is_&Ok("") y(&v).unw): "ok",()? {
   (<Result<nw&[&(T,>lasarive(>::cl.is_&tr>("") y(&v).u().is_e: ").i"    m}wrar() {# ;
ny(unused_resultsDeb() {    _let j = jrurarchi]
 sure": [ros!,a,"a"];
   ts);
}

#[testissue_220umber() {e};

#[deize, iabug, Partiartiaizsive(SeriDeb() {a")] El  xue;
   V(u8)la   }
pb() {
    assson::from_sE>mr#" "V"0 "# . !().is_errap();     assertnon::from_sE>mr#"{"V": 0}"# alue).unw, E::Vj0)wra
pbmacro_rules![alid_n t  , Paeqncol  xue;($($n:  fr)*);,)?  xue;
   $(ap();
           v v: Val s = to_v$n,y(&v).unwrap();
           satu$necond.to_strrap();
            assertson::,?$n,rap();
            assert$neqalue(v o() {{{{{{{{{     asnertson::,?sv o() {{{{{)*a   }
pts);
}

#[test]
fn t  , Paeqnalid_number() {alid_n t  , Paeqnco!(0 1 100o() {{{{{i8::MIN{i8::MAX i16::MIN{i16::MAX i32::MIN{i32::MAX i   (MIN{i   (MAXo() {{{{{u8::MIN{u8::MAX u16::MIN{u16::MAX u32::MIN{u32::MAX u   (MIN{u   (MAXo() {{{{{f32::MIN{f32::MAX f32::MIN_EXP{f32::MAX_EXP{f32::MIN_POSITIVEo() {{{{{f   (MIN{f   (MAX{f   (MIN_EXP{f   (MAX_EXP{f   (MIN_POSITIVEo() {{{{{f32::constsmSt{f32::constsmSPI{f32::constsmSLN_2{f32::constsmSLOG2_Eo() {{{{{f   (constsmSt{f   (constsmSPI{f   (constsmSLN_2{f   (constsmSLOG2_Eo() {   ts);
}

#[t#   #!("an in128)[t#   #!(not(featurarbi(rary tesciprec"aliest]
fn t  , Paeqn("an in128umber() {alid_n t  , Paeqnco!(i128::MIN{i128::MAX u128::MIN{u128::MAX)pts);
}

#[test]
fn t  , PaeqnN.to_str(ar() {    vVal s = to_v"42( y(&v).unwrap();     asserts, "42( rap();     assert"42(trv)rap();     asnerts, 42wrap();     asserts, Std::strzer:("42( wrap();     assertStd::strzer:("42( trv)rats);
}

#[test]
fn t  , Paeqnritetr(ar() {    vVal s = to_vros! y(&v).unwrap();     asserts, ros!   
        assert os!,av)rap();     asnerts, fals()rap();     asnerts, "ros!")rap();     asnerts, 1)rap();     asnerts, 0)rats)
pub stFailReader(iomStr>orKind)rr impl iomSReadi
   FailReader(ar() {estoeade&elf,self,f_: &elf,[u8]) -> iomSResult<useri>l  xue;
   Err(iomStr>oreeMap:self.0, "oh no!" D    m}ats);
}

#[test]
fn caan ory_char() {
    assson::from_s Vec<Std"123" y(&v).u().is_. !(datas_errap();     assson::from_s Vec<Std"]" y(&v).u().is_. !(syntaxs_errap();     assson::from_s Vec<Std"" y(&v).u().is_. !(eofs_err() {
    assson::from_s Vec<Std"\"" y(&v).u().is_. !(eofs_err() {
    assson::from_s Vec<Std"\"\\" y(&v).u().is_. !(eofs_err() {
    assson::from_s Vec<Std"\"\\u" y(&v).u().is_. !(eofs_err() {
    assson::from_s Vec<Std"\"\\u0" y(&v).u().is_. !(eofs_err() {
    assson::from_s Vec<Std"\"\\u00" y(&v).u().is_. !(eofs_err() {
    assson::from_s Vec<Std"\"\\u000" y(&v).u().is_. !(eofs_errr() {
    assson::from_sner:useri>> "[A y(&v).u().is_. !(eofs_err() {
    assson::from_sner:useri>> "[0A y(&v).u().is_. !(eofs_err() {
    assson::from_sner:useri>> "[0," y(&v).u().is_. !(eofs_errr() {
    assson::from_s m = BTr<Frog(Struseri>> "{",ap();
   y(&v).u().is_ap();
   y !(eofs_err() {
    assson::from_s m = BTr<Frog(Struseri>> "{\"k\"",ap();
   y(&v).u().is_ap();
   y !(eofs_err() {
    assson::from_s m = BTr<Frog(Struseri>> "{\"k\":",ap();
   y(&v).u().is_ap();
   y !(eofs_err() {
    assson::from_s m = BTr<Frog(Struseri>> "{\"k\":0",ap();
   y(&v).u().is_ap();
   y !(eofs_err() {
    assson::from_s m = BTr<Frog(Struseri>> "{\"k\":0,",ap();
   y(&v).u().is_ap();
   y !(eofs_errr() {    failValFailReader(iomStr>orKind::NotConns_oed)rr() {
    assson::oeaderm_s_tr Vec<St(fail y(&v).u().is_. !(ios_errts);
}

#[t// Clippy fals( posieove: ssue httgithub.stm/Manishe  ,h/rust-clippy/issues/292);
allow(clippyeeMaedless_lifetimes)[test]
fn ("ao(io_) in _char() {estio_) in :'d(ale: izve(Deserid'd(>i+ ize, >(j: &'static[t.te -> iomStr>or,     {
   eon::from_sT>d" alue).u().is_. m:o(wa   }
pb() {
    assert]]"),
   io_) in m_s Vec<Std"\"\\u" ykiie_m, $v);
   iomStr>orKind::Un  fn eedEof

   ,;am| {     assertio_) in m_s Vec<Std"0" ykiie_m, iomStr>orKind::Ieam_inDatawraw();     assertio_) in m_s Vec<Std"]" ykiie_m, iomStr>orKind::Ieam_inDatawrar() {    failValFailReader(iomStr>orKind::NotConns_oed)rr() {    io_) i: iomStr>or,alue = oeaderm_s_tru8t(fail y(&v).u().is_. m:o(wraw();     assertio_) iykiie_m, iomStr>orKind::NotConns_oed)rrts);
}

#[test]
fn ri inw_char() {
   s: &(T,lalue = from( =ri inwedu0( y(&v).unwrap();     assert=ri inwed",?sv or() {
   s: &(T,lalue = flice(b( =ri inwedu0( y(&v).unwrap();     assert=ri inwed",?sv ots);
}

#[test,"a"_ream_in_re_u_char() {
   wrat= suse serde_json::from_s Vec<Std"(),l" alue).unwrap_  
        assert]]"),
   
  maa! ({},, wram, $v);
   Std::strzer:("ream_in re_u:r,"a":   fn eed ais.to_s ters at line 1 co4",ap();,;ats);
}

#[test]
fn ("an in128_char() {
   signed =[&[i128::min = to_vm, -1,?0, 1,?i128::max = to_vm rap();    unsigned =[&[0, 1,?u128::max = to_vm ra
{{{{
   ("an in128 iutsigned eam| {
         fn eed =[("an in128econd.to_strrap();
        assert s = to_st("an in128)alue).unw,   fn eed)rrp();
        assertson::from_si128>(&  fn eed)alue).unw, *("an in128);a   }
pb() {
   ("an in128 iutunsigned eam| {
         fn eed =[("an in128econd.to_strrap();
        assert s = to_st("an in128)alue).unw,   fn eed)rrp();
        assertson::from_su128>(&  fn eed)alue).unw, *("an in128);a   }
pb() {
    t  v.n) im_si128>(&(.1"),
    tor {
       (-1701411834604692317316873037158841057l9"c   )+
       (alid_n  letof rtn i ters at line 1 co40-c   )+
   ,[]]"),
    tor {
       (1701411834604692317316873037158841057l8"c   )+
       (alid_n  letof rtn i ters at line 1 co39"c   )+
   ,[]]"),
    ]);

    t  v.n) im_su128>(&(.1"),
    (-1", (alid_n  letof rtn i ters at line 1 co1um, $v);
   (tor {
       "340282366920938463463374607431768211456"c   )+
       (alid_n  letof rtn i ters at line 1 co39"c   )+
   ,[]]"),
   ts);
}

#[test]
fn ("an in128_ s = to_vchar() {
   signed =[&[i128::zer:(i   (min = to_vm),?i128::zer:(u   (max = to_vmm rap();    unsigned =[&[0, u128::zer:(u   (max = to_vmm ra
{{{{
   ("an in128 iutsigned eam| {
         fn eed =[("an in128econd.to_strrap();
        assert s = to_v("an in128)alue).unwecond.to_strin  fn eed)rrp();
pb() {
   ("an in128 iutunsigned eam| {
         fn eed =[("an in128econd.to_strrap();
        assert s = to_v("an in128)alue).unwecond.to_strin  fn eed)rrp();
pb() {if !cfg!!(not(featurarbi(rary tesciprec"a eam| {
        rat= con  to_vu128::zer:(u   (max = to_vmmi+ 1 alue).unwrap_  
   
        assertwraecond.to_strin"alid_n  letof rtn i")rrp();
p() #   #!(not(featurraw = to_"alize}

#[test]
fn ri inwed_raw = to_umber() {e};

#[deSe(Deserializsive(SeriDeb() {
pub stW).uperd'aV eam| {
   a: i8,    {
   e})]
#[sri inwDeb() {() {b: &'a Rawt v: ,    {
   c: i8,    {
pb() {    w).uperaue = fro:tW).uper =

       suse serde_json::fromr#"{"a": 1c "b": {"soo": 2}[1"c": 3}"# y(&v).unwrap();     assert_str(foo": 2},#,fw).uperaue = fro.b.gets_errr() {    w).uperacond.to_st= suse serde_j s = to_strw).uperaue = fro y(&v).unwrap();     assert_str(a":1,(b":{"soo": 2}["c":3},#,fw).upera s = to_serrr() {    w).uperaconv v: Valsuse serde_j s = to_vrw).uperaue = fro y(&v).unwrap();     assert":",!({"a": 1c "b": {"soo": 2}[1"c": 3}), w).uperaconv v: errr() {    arrayaue = fro:tner:&Rawt v: > =

       suse serde_json::fromr#"["a"in4![1{"soo": "\ar,},a,"a"]"# y(&v).unwrap();     assert_st"a",#,farrayaue = fro[0].gets_errp();     assert_st42,#,farrayaue = fro[1].gets_errp();     assert_st{"soo": "\ar,},#,farrayaue = fro[2].gets_errp();     assert_st(),l"#,farrayaue = fro[3].gets_errr() {    arrayacond.to_st= suse serde_j s = to_strarrayaue = fro y(&v).unwrap();     assert_st["a"i4![{"soo": "\ar,},,"a"]"#, arrayacond.to_serr() #   #!(not(featurraw = to_"alize}

#[test]
fn raw = to_ ("a tr_key_char() {# ;

#[deRefCastDeb() {#[repr((ranspafen/Deb() {
pub stRawMapKey_Rawt v:     ]);
impl:'d(> izve(Deserid'd(>i
   &'d(tRawMapKey,     {
   est

fn deseri<D>(
    deseria: D) -> Result<Self,fDmStr>or>    {
   r)])
wherehereeeeeD  suse seizve(Deserird'd(>59.1),
        {
       
   raw = to_atu:&Rawt v: >::rdve(Deserie l   deseriat?;r() {{{{{{{{{Ok(RawMapKey::ref_cast(raw = to_)j    m
        }
pb() {implabug, Parti
   RawMapKey,     {
   esteqa&self,fo/ Ir: &Self) -> rite      {
       sulf.0.gets_ ==fo/ Ir.0.gets_    m
        }
pb() {implarti
   RawMapKey, 
pb() {implaHashi
   RawMapKey,     {
   esthash<H:aHasherVa&self,fhasher: &elf,H)      {
       sulf.0.gets_.hash(hasherwrap();
        }
rb() {     apaue = fro:tHashBTr<&RawMapKey, &Rawt v: > =

       suse serde_json::fromr#"1{"\\k":"\\v"} "# y(&v).unwrap();    ( tr_k,  ap_vwlet apaue = fro.("ao(i: "_ctream( y(&v).unwrap();     assert=\"\\\\ku00,  tr_k.0.gets_wrap();     assert=\"\\\\vu00,  tr_v.gets_wra() #   #!(not(featurraw = to_"alize}

#[test]
fn rixed_raw = to_umber() {e};

#[deSe(Deserializsive(SeriDeb() {
pub stW).uper eam| {
   a: i8,    {
   b:  ox<Rawt v: >,    {
   c: i8,    {
pb() {    w).uperaue = fro:tW).uper =

       suse serde_json::fromr#"{"a": 1c "b": {"soo": 2}[1"c": 3}"# y(&v).unwrap();     assert_str(foo": 2},#,fw).uperaue = fro.b.gets_errr() {    w).uperaue = oeadermtW).uper =

       suse serde_json::oeader(br#"{"a": 1c "b": {"soo": 2}[1"c": 3}"#.as:oefs_ey(&v).unwrap();     assert_str(foo": 2},#,fw).uperaue = oeader.b.gets_errr() {    w).uperaue = son::vuW).uper =

       suse serde_json::= to_v":",!({"a": 1c "b": {"soo": 2}[1"c": 3})ey(&v).unwrap();     assert_str(foo":2},#,fw).uperaue = = to_.b.gets_errr() {    w).uperacond.to_st= suse serde_j s = to_strw).uperaue = fro y(&v).unwrap();     assert_str(a":1,(b":{"soo": 2}["c":3},#,fw).upera s = to_serrr() {    w).uperaconv v: Valsuse serde_j s = to_vrw).uperaue = fro y(&v).unwrap();     assert":",!({"a": 1c "b": {"soo": 2}[1"c": 3}), w).uperaconv v: errr() {    arrayaue = fro:tner: ox<Rawt v: >> =

       suse serde_json::fromr#"["a"in4![1{"soo": "\ar,},a,"a"]"# y(&v).unwrap();     assert_st"a",#,farrayaue = fro[0].gets_errp();     assert_st42,#,farrayaue = fro[1].gets_errp();     assert_st{"soo": "\ar,},#,farrayaue = fro[2].gets_errp();     assert_st(),l"#,farrayaue = fro[3].gets_errr() {    arrayaue = oeadermtner: ox<Rawt v: >> =

       suse serde_json::oeader(br#"["a"in4![1{"soo": "\ar,},a,"a"]"#.as:oefs_ey(&v).unwrap();     assert_st"a",#,farrayaue = oeader[0].gets_errp();     assert_st42,#,farrayaue = oeader[1].gets_errp();     assert_st{"soo": "\ar,},#,farrayaue = oeader[2].gets_errp();     assert_st(),l"#,farrayaue = oeader[3].gets_errr() {    arrayacond.to_st= suse serde_j s = to_strarrayaue = fro y(&v).unwrap();     assert_st["a"i4![{"soo": "\ar,},,"a"]"#, arrayacond.to_serr() #   #!(not(featurraw = to_"alize}

#[test]
fn raw ream_in_utf8_char() {
   j =[&[b'"', b'\xCE', b'\xF8', b'"' rap();    = to_ wrat= suse serde_json::flicem_snr::<Vaj alue).unwrap_  
   
   raw = to_ wrat= suse serde_json::flicem_s ox<Rawt v: >>mj alue).unwrap_   
        assert]]"),
   = to_ wraecond.to_stri

       "ream_in unist_e st_e poim: ters at line 1 co4",

   ,;am| {     assert

       _aw = to_ wraecond.to_stri

       "ream_in unist_e st_e poim: ters at line 1 co4",

   ,;a() #   #!(not(featurraw = to_"alize}

#[test]
fn = "deseriaunsized_= to_ conraw = to_umber() {     assert

       suse serde_json::v:conraw = to_u"soo\ar,)alue).unwegets_,

       _st"soo\ar,"#,   $(_rrts);
}

#[test]
fn ri inw ("a tr_key_char() {# ;

#[deizse(Deserialize, Deb() {
pub stOuter eam| {
   ;
allow(dead_st_eDeb() {() { ap:t m = BTr<MyBTrKey, ()>59.1),
 4863.# ;

#[deOrdiabug, PaOrdiartiabug, Partalize, Deb() {
pub stMyBTrKey(useri    ]);
impl:'d(> izve(Deserid'd(>i
   MyBTrKey,     {
   est

fn deseri<D>(
    deseria: D) -> Result<Self,fDmStr>or>    {
   r)])
wherehereeeeeD  e seizve(Deserird'd(>59.1),
        {
           satu<&(T,>::rdve(Deserie l   deseriat?;r() {{{{{{{{{    nt= s.t  v.(ty trnwrape setr>or::customt?;r() {{{{{{{{{Ok(MyBTrKey(n)j    m
        }
pb() {    v v: Val j = jrur ap":l  =1":a,"a" } 
   
   Outer::rdve(Deserie&v v: ey(&v).unwrats);
}

#[test]
fn = to_ ("con l   deseria_char() {# ;

#[deizse(DeseriDeb() {
pub stOuter eam| {
   in   : In   59.1),
 4863.# ;

#[deizse(DeseriDeb() {
pub stIn    eam| {
   d.to_s: g::ToSla   }
pb() {     let apmut m = BTreeMap::new(); ap    m.in"in   ",l j = jrurt.to_s": "Hello World" 
 errr() {    outer = Outer::rdve(Deseriesuse see seson::v:BTrde = DeserialiMap:b() {() { ap.i: "_ct tr(|(ktrv)| (*ktrv)_,

   )_

   y(&v).unwraw();     assertouter.in   .srog(Str"Hello World"errr() {    outer = Outer::rdve(Deserie ap   con l   deseria_c)y(&v).unwraw();     assertouter.in   .srog(Str"Hello World"errts);
}

#[testhash_posieove_and_negaeove_riao_char() {esthash(obj:{implaHash) -> u64 eam| {
        lethasheret defaultHashereeMap::new();;;;;obj.hash(& lethasher:new();;;;;hasher.e_nosh()a   }
pb() {    k1t= suse serde_json::from_sNlid_ntd"0.0")y(&v).unwra        k2t= suse serde_json::from_sNlid_ntd"-0.0")y(&v).unwra    if cfg!!(not(featurarbi(rary tesciprec"a eam| {
        asnertk1c k2_  
   
        asnerthash(k1),fhash(k2)wraw();} els( { 
   
        assertk1c k2_  
   
        asserthash(k1),fhash(k2)wraw();}rts     