/*!
This module defines 128-bit vector implementations of `memchr` and friends.

The main types in this module are [`One`], [`Two`] and [`Three`]. They are for
searching for one, two or three distinct bytes, respectively, in a haystack.
Each type also has corresponding double ended iterators. These searchers are
typically much faster than scalar routines accomplishing the same task.

The `One` searcher also provides a [`One::count`] routine for efficiently
counting the number of times a single byte occurs in a haystack. This is
useful, for example, for counting the number of lines in a haystack. This
routine exists because it is usually faster, especially with a high match
count, then using [`One::find`] repeatedly. ([`OneIter`] specializes its
`Iterator::count` implementation to use this routine.)

Only one, two and three bytes are supported because three bytes is about
the point where one sees diminishing returns. Beyond this point and it's
probably (but not necessarily) better to just use a simple `[bool; 256]` array
or similar. However, it depends mightily on the specific work-load and the
expected match frequency.
*/

use core::arch::x86_64::__m128i;

use crate::{arch::generic::memchr as generic, ext::Pointer, vector::Vector};

/// Finds all occurrences of a single byte in a haystack.
#[derive(Clone, Copy, Debug)]
pub struct One(generic::One<__m128i>);

impl One {
    /// Create a new searcher that finds occurrences of the needle byte given.
    ///
    /// This particular searcher is specialized to use SSE2 vector instructions
    /// that typically make it quite fast.
    ///
    /// If SSE2 is unavailable in the current environment, then `None` is
    /// returned.
    #[inline]
    pub fn new(needle: u8) -> Option<One> {
        if One::is_available() {
            // SAFETY: we check that sse2 is available above.
            unsafe { Some(One::new_unchecked(needle)) }
        } else {
            None
        }
    }

    /// Create a new finder specific to SSE2 vectors and routines without
    /// checking that SSE2 is available.
    ///
    /// # Safety
    ///
    /// Callers must guarantee that it is safe to execute `sse2` instructions
    /// in the current environment.
    ///
    /// Note that it is a common misconception that if one compiles for an
    /// `x86_64` target, then they therefore automatically have access to SSE2
    /// instructions. While this is almost always the case, it isn't true in
    /// 100% of cases.
    #[target_feature(enable = "sse2")]
    #[inline]
    pub unsafe fn new_unchecked(needle: u8) -> One {
        One(generic::One::new(needle))
    }

    /// Returns true when this implementation is available in the current
    /// environment.
    ///
    /// When this is true, it is guaranteed that [`One::new`] will return
    /// a `Some` value. Similarly, when it is false, it is guaranteed that
    /// `One::new` will return a `None` value.
    ///
    /// Note also that for the lifetime of a single program, if this returns
    /// true then it will always return true.
    #[inline]
    pub fn is_available() -> bool {
        #[cfg(target_feature = "sse2")]
        {
            true
        }
        #[cfg(not(target_feature = "sse2"))]
        {
            false
        }
    }

    /// Return the first occurrence of one of the needle bytes in the given
    /// haystack. If no such occurrence exists, then `None` is returned.
    ///
    /// The occurrence is reported as an offset into `haystack`. Its maximum
    /// value is `haystack.len() - 1`.
    #[inline]
    pub fn find(&self, haystack: &[u8]) -> Option<usize> {
        // SAFETY: `find_raw` guarantees that if a pointer is returned, it
        // falls within the bounds of the start and end pointers.
        unsafe {
            generic::search_slice_with_raw(haystack, |s, e| {
                self.find_raw(s, e)
            })
        }
    }

    /// Return the last occurrence of one of the needle bytes in the given
    /// haystack. If no such occurrence exists, then `None` is returned.
    ///
    /// The occurrence is reported as an offset into `haystack`. Its maximum
    /// value is `haystack.len() - 1`.
    #[inline]
    pub fn rfind(&self, haystack: &[u8]) -> Option<usize> {
        // SAFETY: `rfind_raw` guarantees that if a pointer is returned, it
        // falls within the bounds of the start and end pointers.
        unsafe {
            generic::search_slice_with_raw(haystack, |s, e| {
                self.rfind_raw(s, e)
            })
        }
    }

    /// Counts all occurrences of this byte in the given haystack.
    #[inline]
    pub fn count(&self, haystack: &[u8]) -> usize {
        // SAFETY: All of our pointers are derived directly from a borrowed
        // slice, which is guaranteed to be valid.
        unsafe {
            let start = haystack.as_ptr();
            let end = start.add(haystack.len());
            self.count_raw(start, end)
        }
    }

    /// Like `find`, but accepts and returns raw pointers.
    ///
    /// When a match is found, the pointer returned is guaranteed to be
    /// `>= start` and `< end`.
    ///
    /// This routine is useful if you're already using raw pointers and would
    /// like to avoid converting back to a slice before executing a search.
    ///
    /// # Safety
    ///
    /// * Both `start` and `end` must be valid for reads.
    /// * Both `start` and `end` must point to an initialized value.
    /// * Both `start` and `end` must point to the same allocated object and
    /// must either be in bounds or at most one byte past the end of the
    /// allocated object.
    /// * Both `start` and `end` must be _derived from_ a pointer to the same
    /// object.
    /// * The distance between `start` and `end` must not overflow `isize`.
    /// * The distance being in bounds must not rely on "wrapping around" the
    /// address space.
    ///
    /// Note that callers may pass a pair of pointers such that `start >= end`.
    /// In that case, `None` will always be returned.
    #[inline]
    pub unsafe fn find_raw(
        &self,
        start: *const u8,
        end: *const u8,
    ) -> Option<*const u8> {
        if start >= end {
            return None;
        }
        if end.distance(start) < __m128i::BYTES {
            // SAFETY: We require the caller to pass valid start/end pointers.
            return generic::fwd_byte_by_byte(start, end, |b| {
                b == self.0.needle1()
            });
        }
        // SAFETY: Building a `One` means it's safe to call 'sse2' routines.
        // Also, we've checked that our haystack is big enough to run on the
        // vector routine. Pointer validity is caller's responsibility.
        //
        // Note that we could call `self.0.find_raw` directly here. But that
        // means we'd have to annotate this routine with `target_feature`.
        // Which is fine, because this routine is `unsafe` anyway and the
        // `target_feature` obligation is met by virtue of building a `One`.
        // The real problem is that a routine with a `target_feature`
        // annotation generally can't be inlined into caller code unless the
        // caller code has the same target feature annotations. Which is maybe
        // okay for SSE2, but we do the same thing for AVX2 where caller code
        // probably usually doesn't have AVX2 enabled. That means that this
        // routine can be inlined which will handle some of the short-haystack
        // cases above without touching the architecture specific code.
        self.find_raw_impl(start, end)
    }

    /// Like `rfind`, but accepts and returns raw pointers.
    ///
    /// When a match is found, the pointer returned is guaranteed to be
    /// `>= start` and `< end`.
    ///
    /// This routine is useful if you're already using raw pointers and would
    /// like to avoid converting back to a slice before executing a search.
    ///
    /// # Safety
    ///
    /// * Both `start` and `end` must be valid for reads.
    /// * Both `start` and `end` must point to an initialized value.
    /// * Both `start` and `end` must point to the same allocated object and
    /// must either be in bounds or at most one byte past the end of the
    /// allocated object.
    /// * Both `start` and `end` must be _derived from_ a pointer to the same
    /// object.
    /// * The distance between `start` and `end` must not overflow `isize`.
    /// * The distance being in bounds must not rely on "wrapping around" the
    /// address space.
    ///
    /// Note that callers may pass a pair of pointers such that `start >= end`.
    /// In that case, `None` will always be returned.
    #[inline]
    pub unsafe fn rfind_raw(
        &self,
        start: *const u8,
        end: *const u8,
    ) -> Option<*const u8> {
        if start >= end {
            return None;
        }
        if end.distance(start) < __m128i::BYTES {
            // SAFETY: We require the caller to pass valid start/end pointers.
            return generic::rev_byte_by_byte(start, end, |b| {
                b == self.0.needle1()
            });
        }
        // SAFETY: Building a `One` means it's safe to call 'sse2' routines.
        // Also, we've checked that our haystack is big enough to run on the
        // vector routine. Pointer validity is caller's responsibility.
        //
        // See note in forward routine above for why we don't just call
        // `self.0.rfind_raw` directly here.
        self.rfind_raw_impl(start, end)
    }

    /// Counts all occurrences of this byte in the given haystack represented
    /// by raw pointers.
    ///
    /// This routine is useful if you're already using raw pointers and would
    /// like to avoid converting back to a slice before executing a search.
    ///
    /// # Safety
    ///
    /// * Both `start` and `end` must be valid for reads.
    /// * Both `start` and `end` must point to an initialized value.
    /// * Both `start` and `end` must point to the same allocated object and
    /// must either be in bounds or at most one byte past the end of the
    /// allocated object.
    /// * Both `start` and `end` must be _derived from_ a pointer to the same
    /// object.
    /// * The distance between `start` and `end` must not overflow `isize`.
    /// * The distance being in bounds must not rely on "wrapping around" the
    /// address space.
    ///
    /// Note that callers may pass a pair of pointers such that `start >= end`.
    /// In that case, `0` will always be returned.
    #[inline]
    pub unsafe fn count_raw(&self, start: *const u8, end: *const u8) -> usize {
        if start >= end {
            return 0;
        }
        if end.distance(start) < __m128i::BYTES {
            // SAFETY: We require the caller to pass valid start/end pointers.
            return generic::count_byte_by_byte(start, end, |b| {
                b == self.0.needle1()
            });
        }
        // SAFETY: Building a `One` means it's safe to call 'sse2' routines.
        // Also, we've checked that our haystack is big enough to run on the
        // vector routine. Pointer validity is caller's responsibility.
        self.count_raw_impl(start, end)
    }

    /// Execute a search using SSE2 vectors and routines.
    ///
    /// # Safety
    ///
    /// Same as [`One::find_raw`], except the distance between `start` and
    /// `end` must be at least the size of an SSE2 vector (in bytes).
    ///
    /// (The target feature safety obligation is automatically fulfilled by
    /// virtue of being a method on `One`, which can only be constructed
    /// when it is safe to call `sse2` routines.)
    #[target_feature(enable = "sse2")]
    #[inline]
    unsafe fn find_raw_impl(
        &self,
        start: *const u8,
        end: *const u8,
    ) -> Option<*const u8> {
        self.0.find_raw(start, end)
    }

    /// Execute a search using SSE2 vectors and routines.
    ///
    /// # Safety
    ///
    /// Same as [`One::rfind_raw`], except the distance between `start` and
    /// `end` must be at least the size of an SSE2 vector (in bytes).
    ///
    /// (The target feature safety obligation is automatically fulfilled by
    /// virtue of being a method on `One`, which can only be constructed
    /// when it is safe to call `sse2` routines.)
    #[target_feature(enable = "sse2")]
    #[inline]
    unsafe fn rfind_raw_impl(
        &self,
        start: *const u8,
        end: *const u8,
    ) -> Option<*const u8> {
        self.0.rfind_raw(start, end)
    }

    /// Execute a count using SSE2 vectors and routines.
    ///
    /// # Safety
    ///
    /// Same as [`One::count_raw`], except the distance between `start` and
    /// `end` must be at least the size of an SSE2 vector (in bytes).
    ///
    /// (The target feature safety obligation is automatically fulfilled by
    /// virtue of being a method on `One`, which can only be constructed
    /// when it is safe to call `sse2` routines.)
    #[target_feature(enable = "sse2")]
    #[inline]
    unsafe fn count_raw_impl(
        &self,
        start: *const u8,
        end: *const u8,
    ) -> usize {
        self.0.count_raw(start, end)
    }

    /// Returns an iterator over all occurrences of the needle byte in the
    /// given haystack.
    ///
    /// The iterator returned implements `DoubleEndedIterator`. This means it
    /// can also be used to find occurrences in reverse order.
    #[inline]
    pub fn iter<'a, 'h>(&'a self, haystack: &'h [u8]) -> OneIter<'a, 'h> {
        OneIter { searcher: self, it: generic::Iter::new(haystack) }
    }
}

/// An iterator over all occurrences of a single byte in a haystack.
///
/// This iterator implements `DoubleEndedIterator`, which means it can also be
/// used to find occurrences in reverse order.
///
/// This iterator is created by the [`One::iter`] method.
///
/// The lifetime parameters are as follows:
///
/// * `'a` refers to the lifetime of the underlying [`One`] searcher.
/// * `'h` refers to the lifetime of the haystack being searched.
#[derive(Clone, Debug)]
pub struct OneIter<'a, 'h> {
    lf, it: ge_slic(Tand rstruct OneIter<'a, ,  }
or iter<'a, 'dedIteralid fct OneIter<'a, 'h> {
 ch tyOnemble-> usnd);

    #[inline]
 fe fnxt(&a *mn(&self) -> Option<usize> {
        // SAFETY: Wehtily on truct Onhis iteraten to proviss valid stre`
        // and end pointSE2, but st guarantee thanythe pointer returned by
        '0.rfind_' // falls within the bounds of the start and end poinlid.
        unsaf    seit.fnxt(k, |s,    sel] searchf.rfind_raw(s,)    }
    }

    #[inline]
 fe fn coun(&self) -> usize {
        seit.fn couk, |s, e| {
            // SAFETY: Wehtily at oruct Onhis iteraten    retuss valid stre`
            // and end pointove.
            unsafe   sel] search.0.count_raw(s,e)) }
      )  }
    }

    #[inline]
 fe > us_wittlen(&self) (   usi -> Option<usi)ize {
        seit.> us_wittlen()
    }
or iter<'a, 's `DoubleEndedIteralid fct OneIter<'a, 'h> {
    #[inline]
 fe fnxt_allba&a *mn(&self) -> Option<usize> {
        // SAFETY: Wehtily on truct Onhis iteraten to proviss valid stre`
        // and end pointSE2, but st guarantee thanythe pointer returned by
        'r0.rfind_' // falls within the bounds of the start and end poinlid.
        unsaf    seit.fnxt_allbak, |s,    sel] searchrf.rfind_raw(s,)    }
    }
or iter<'a, 'se cori::IteF// udedIteralid fct OneIter<'a, 'h}r};

/// Finds all occurrences e, tle bytes in a haystack.
///
/// that, if thissuppon a maences of one o, t's possible byion. for exampthe
//r
searching f` `'g f`bse2`f` foobar`and wohissuppn a maenc thaf offse`0`pthe
/`4art` an5`ack.
#[derive(Clone, Copy, Debug)]
pub struTwoOne(generiTwoOne<__m128i>);

imTwoOne {
    /// Create a new searcher that finds occurrences of the needle bsyte given.
    ///
    /// This particular searcher is specialized to use SSE2 vector instructions
    /// that typically make it quite fast.
    ///
    /// If SSE2 is unavailable in the current environment, then `None` is
    /// returned.
    #[inline]
    pub fn new(neew(n1: uh `needdle: u8) -> OptiTwo u8> {
        e `Twe::is_available() {
            // SAFETY: we check that sse2 is available above.
            unsafe { Soe `Twfn new_unchecked(nee1 uh `needdle)) }
        } else {
            None
        }
    }

    /// Create a new finder specific to SSE2 vectors and routines without
    /// checking that SSE2 is available.
    ///
    /// # Safety
    ///
    /// Callers must guarantee that it is safe to execute `sse2` instructions
    /// in the current environment.
    ///
    /// Note that it is a common misconception that if one compiles for an
    /// `x86_64` target, then they therefore automatically have access to SSE2
    /// instructions. While this is almost always the case, it isn't true in
    /// 100% of cases.
    #[target_feature(enable = "sse2")]
    #[inline]
    pub unsafe fn new_unchecked(neew(n1: uh `needdle: u8) TwoOne {
        One(generiTwoOne::new(nee1 uh `needdle))
    }

    /// Returns true when this implementation is available in the current
    /// environment.
    ///
    /// When this is true, it is guaranteed thatTwoOne::new`] will return
    /// a `Some` value. Similarly, when it is false, it is guaranteed that
    //TwoOne::new` will return a `None` value.
    ///
    /// Note also that for the lifetime of a single program, if this returns
    /// true then it will always return true.
    #[inline]
    pub fn is_available() -> bool {
        #[cfg(target_feature = "sse2")]
        {
            true
        }
        #[cfg(not(target_feature = "sse2"))]
        {
            false
        }
    }

    /// Return the first occurrence of one of the needle bytes in the given
    /// haystack. If no such occurrence exists, then `None` is returned.
    ///
    /// The occurrence is reported as an offset into `haystack`. Its maximum
    /// value is `haystack.len() - 1`.
    #[inline]
    pub fn find(&self, haystack: &[u8]) -> Option<usize> {
        // SAFETY: `find_raw` guarantees that if a pointer is returned, it
        // falls within the bounds of the start and end pointers.
        unsafe {
            generic::search_slice_with_raw(haystack, |s, e| {
                self.find_raw(s, e)
            })
        }
    }

    /// Return thefirst occurrence of one of the needle bytes in the given
    /// haystack. If no such occurrence exists, then `None` is returned.
    ///
    /// The occurrence is reported as an offset into `haystack`. Its maximum
    /// value is `haystack.len() - 1`.
    #[inline]
    pub fn rfind(&self, haystack: &[u8]) -> Option<usize> {
        // SAFETY: `rfind_raw` guarantees that if a pointer is returned, it
        // falls within the bounds of the start and end pointers.
        unsafe {
            generic::search_slice_with_raw(haystack, |s, e| {
                self.rfind_raw(s, e)
            })
        }
    }

    /// Like `find`, but accepts and returns raw pointers.
    ///
    /// When a match is found, the pointer returned is guaranteed to be
    /// `>= start` and `< end`.
    ///
    /// This routine is useful if you're already using raw pointers and would
    /// like to avoid converting back to a slice before executing a search.
    ///
    /// # Safety
    ///
    /// * Both `start` and `end` must be valid for reads.
    /// * Both `start` and `end` must point to an initialized value.
    /// * Both `start` and `end` must point to the same allocated object and
    /// must either be in bounds or at most one byte past the end of the
    /// allocated object.
    /// * Both `start` and `end` must be _derived from_ a pointer to the same
    /// object.
    /// * The distance between `start` and `end` must not overflow `isize`.
    /// * The distance being in bounds must not rely on "wrapping around" the
    /// address space.
    ///
    /// Note that callers may pass a pair of pointers such that `start >= end`.
    /// In that case, `None` will always be returned.
    #[inline]
    pub unsafe fn find_raw(
        &self,
        start: *const u8,
        end: *const u8,
    ) -> Option<*const u8> {
        if start >= end {
            return None;
        }
        if end.distance(start) < __m128i::BYTES {
            // SAFETY: We require the caller to pass valid start/end pointers.
            return generic::fwd_byte_by_byte(start, end, |b| {
                b == self.0.needle ||    b == self.0.nee2le1()
            });
        }
        // SAFETY: Building  [`Tne` means it's safe to call 'sse2' routines.
        // Also, we've checked that our haystack is big enough to run on the
        // vector routine. Pointer validity is caller's responsibility.
        //
        // Note that we could call `self.0.find_raw` directly here. But that
        // means we'd have to annotate this routine with `target_feature`.
        // Which is fine, because this routine is `unsafe` anyway and the
        // `target_feature` obligation is met by virtue of building  [`Tne`.
        // The real problem is that a routine with a `target_feature`
        // annotation generally can't be inlined into caller code unless the
        // caller code has the same target feature annotations. Which is maybe
        // okay for SSE2, but we do the same thing for AVX2 where caller code
        // probably usually doesn't have AVX2 enabled. That means that this
        // routine can be inlined which will handle some of the short-haystack
        // cases above without touching the architecture specific code.
        self.find_raw_impl(start, end)
    }

    /// Like `rfind`, but accepts and returns raw pointers.
    ///
    /// When a match is found, the pointer returned is guaranteed to be
    /// `>= start` and `< end`.
    ///
    /// This routine is useful if you're already using raw pointers and would
    /// like to avoid converting back to a slice before executing a search.
    ///
    /// # Safety
    ///
    /// * Both `start` and `end` must be valid for reads.
    /// * Both `start` and `end` must point to an initialized value.
    /// * Both `start` and `end` must point to the same allocated object and
    /// must either be in bounds or at most one byte past the end of the
    /// allocated object.
    /// * Both `start` and `end` must be _derived from_ a pointer to the same
    /// object.
    /// * The distance between `start` and `end` must not overflow `isize`.
    /// * The distance being in bounds must not rely on "wrapping around" the
    /// address space.
    ///
    /// Note that callers may pass a pair of pointers such that `start >= end`.
    /// In that case, `None` will always be returned.
    #[inline]
    pub unsafe fn rfind_raw(
        &self,
        start: *const u8,
        end: *const u8,
    ) -> Option<*const u8> {
        if start >= end {
            return None;
        }
        if end.distance(start) < __m128i::BYTES {
            // SAFETY: We require the caller to pass valid start/end pointers.
            return generic::rev_byte_by_byte(start, end, |b| {
                b == self.0.needle ||    b == self.0.nee2le1()
            });
        }
        // SAFETY: Building  [`Tne` means it's safe to call 'sse2' routines.
        // Also, we've checked that our haystack is big enough to run on the
        // vector routine. Pointer validity is caller's responsibility.
        //
        // See note in forward routine above for why we don't just call
        // `self.0.rfind_raw` directly here.
        self.rfind_raw_impl(start, end)
    }

    /// Execute a search using SSE2 vectors and routines.
    ///
    /// # Safety
    ///
    /// Same ase `Two::find_raw`], except the distance between `start` and
    /// `end` must be at least the size of an SSE2 vector (in bytes).
    ///
    /// (The target feature safety obligation is automatically fulfilled by
    /// virtue of being a method o [`Tne`, which can only be constructed
    /// when it is safe to call `sse2` routines.)
    #[target_feature(enable = "sse2")]
    #[inline]
    unsafe fn find_raw_impl(
        &self,
        start: *const u8,
        end: *const u8,
    ) -> Option<*const u8> {
        self.0.find_raw(start, end)
    }

    /// Execute a search using SSE2 vectors and routines.
    ///
    /// # Safety
    ///
    /// Same ase `Two::rfind_raw`], except the distance between `start` and
    /// `end` must be at least the size of an SSE2 vector (in bytes).
    ///
    /// (The target feature safety obligation is automatically fulfilled by
    /// virtue of being a method o [`Tne`, which can only be constructed
    /// when it is safe to call `sse2` routines.)
    #[target_feature(enable = "sse2")]
    #[inline]
    unsafe fn rfind_raw_impl(
        &self,
        start: *const u8,
        end: *const u8,
    ) -> Option<*const u8> {
        self.0.rdunt_raw(start, end)
    }

    /// Returns an iterator over all occurrences of the needle bsyte in the
    /// given haystack.
    ///
    /// The iterator returned implements `DoubleEndedIterator`. This means it
    /// can also be used to find occurrences in reverse order.
    #[inline]
    pub fn iter<'a, 'h>(&'a self, haystack: &'h [u8])  [`OneIter<'a, 'h> {
      [`OneIter { searcher: self, it: generic::Iter::new(haystack) }
    }
}

/// An iterator over all occurrences o, t's possible byyte in a haystack.
///
/// This iterator implements `DoubleEndedIterator`, which means it can also be
/// used to find occurrences in reverse order.
///
/// This iterator is created by thee `Twe::iter`] method.
///
/// The lifetime parameters are as follows:
///
/// * `'a` refers to the lifetime of the underlying [`Two`] searcher.
/// * `'h` refers to the lifetime of the haystack being searched.
#[derive(Clone, Debug)]
pub stru [`OneIter<'a, 'h> {
    lf, it: ge_   Two,
  rstruct OneIter<'a, ,  }
or iter<'a, 'dedIteralid f [`OneIter<'a, 'h> {
 ch tyOnemble-> usnd);

    #[inline]
 fe fnxt(&a *mn(&self) -> Option<usize> {
        // SAFETY: Wehtily on truct Onhis iteraten to proviss valid stre`
        // and end pointSE2, but st guarantee thanythe pointer returned by
        '0.rfind_' // falls within the bounds of the start and end poinlid.
        unsaf    seit.fnxt(k, |s,    sel] searchf.rfind_raw(s,)    }
    }

    #[inline]
 fe > us_wittlen(&self) (   usi -> Option<usi)ize {
        seit.> us_wittlen()
    }
or iter<'a, 's `DoubleEndedIteralid f [`OneIter<'a, 'h> {
    #[inline]
 fe fnxt_allba&a *mn(&self) -> Option<usize> {
        // SAFETY: Wehtily on truct Onhis iteraten to proviss valid stre`
        // and end pointSE2, but st guarantee thanythe pointer returned by
        'r0.rfind_' // falls within the bounds of the start and end poinlid.
        unsaf    seit.fnxt_allbak, |s,    sel] searchrf.rfind_raw(s,)    }
    }
or iter<'a, 'se cori::IteF// udedIteralid f [`OneIter<'a, 'h}r};

/// Finds all occurrences ee three bytes in a haystack.
///
/// that, if thissuppon a maences of one oe thr's possible byion. for exampthe
//r
searching f` `,f`bseg f`ose2`f` foobar`and wohissuppn a maenc thaf offsthe
/`0`,f`2`,f`3`,f`4art` an5`ack.
#[derive(Clone, Copy, Debug)]
pub struTe thOne(generiTe thOne<__m128i>);

imTe thrne {
    /// Create a new searcher that finds occurrences of the needle bsyte given.
    ///
    /// This particular searcher is specialized to use SSE2 vector instructions
    /// that typically make it quite fast.
    ///
    /// If SSE2 is unavailable in the current environment, then `None` is
    /// returned.
    #[inline]
    pub fn new(neew(n1: uh `needdle: uh `nee3dle: u8) -> OptiTe th u8> {
        e `Three::is_available() {
            // SAFETY: we check that sse2 is available above.
            unsafe { Soe `Threfn new_unchecked(nee1 uh `need uh `nee3dle)) }
        } else {
            None
        }
    }

    /// Create a new finder specific to SSE2 vectors and routines without
    /// checking that SSE2 is available.
    ///
    /// # Safety
    ///
    /// Callers must guarantee that it is safe to execute `sse2` instructions
    /// in the current environment.
    ///
    /// Note that it is a common misconception that if one compiles for an
    /// `x86_64` target, then they therefore automatically have access to SSE2
    /// instructions. While this is almost always the case, it isn't true in
    /// 100% of cases.
    #[target_feature(enable = "sse2")]
    #[inline]
    pub unsafe fn new_unchecknd,
      w(neew(n1: nd,
      w(nee2(n1: nd,
      w(nee  n3: u8,
 u8])  e thrne {
        ThOne(generiTe thOne::new(nee1 uh `need uh `nee3dle))
    }

    /// Returns true when this implementation is available in the current
    /// environment.
    ///
    /// When this is true, it is guaranteed thatTe thOne::new`] will return
    /// a `Some` value. Similarly, when it is false, it is guaranteed that
    //Te thOne::new` will return a `None` value.
    ///
    /// Note also that for the lifetime of a single program, if this returns
    /// true then it will always return true.
    #[inline]
    pub fn is_available() -> bool {
        #[cfg(target_feature = "sse2")]
        {
            true
        }
        #[cfg(not(target_feature = "sse2"))]
        {
            false
        }
    }

    /// Return the first occurrence of one of the needle bytes in the given
    /// haystack. If no such occurrence exists, then `None` is returned.
    ///
    /// The occurrence is reported as an offset into `haystack`. Its maximum
    /// value is `haystack.len() - 1`.
    #[inline]
    pub fn find(&self, haystack: &[u8]) -> Option<usize> {
        // SAFETY: `find_raw` guarantees that if a pointer is returned, it
        // falls within the bounds of the start and end pointers.
        unsafe {
            generic::search_slice_with_raw(haystack, |s, e| {
                self.find_raw(s, e)
            })
        }
    }

    /// Return thefirst occurrence of one of the needle bytes in the given
    /// haystack. If no such occurrence exists, then `None` is returned.
    ///
    /// The occurrence is reported as an offset into `haystack`. Its maximum
    /// value is `haystack.len() - 1`.
    #[inline]
    pub fn rfind(&self, haystack: &[u8]) -> Option<usize> {
        // SAFETY: `rfind_raw` guarantees that if a pointer is returned, it
        // falls within the bounds of the start and end pointers.
        unsafe {
            generic::search_slice_with_raw(haystack, |s, e| {
                self.rfind_raw(s, e)
            })
        }
    }

    /// Like `find`, but accepts and returns raw pointers.
    ///
    /// When a match is found, the pointer returned is guaranteed to be
    /// `>= start` and `< end`.
    ///
    /// This routine is useful if you're already using raw pointers and would
    /// like to avoid converting back to a slice before executing a search.
    ///
    /// # Safety
    ///
    /// * Both `start` and `end` must be valid for reads.
    /// * Both `start` and `end` must point to an initialized value.
    /// * Both `start` and `end` must point to the same allocated object and
    /// must either be in bounds or at most one byte past the end of the
    /// allocated object.
    /// * Both `start` and `end` must be _derived from_ a pointer to the same
    /// object.
    /// * The distance between `start` and `end` must not overflow `isize`.
    /// * The distance being in bounds must not rely on "wrapping around" the
    /// address space.
    ///
    /// Note that callers may pass a pair of pointers such that `start >= end`.
    /// In that case, `None` will always be returned.
    #[inline]
    pub unsafe fn find_raw(
        &self,
        start: *const u8,
        end: *const u8,
    ) -> Option<*const u8> {
        if start >= end {
            return None;
        }
        if end.distance(start) < __m128i::BYTES {
            // SAFETY: We require the caller to pass valid start/end pointers.
            return generic::fwd_byte_by_byte(start, end, |b| {
                b == self.0.needle1()
                 ||    b == self.0.nee2le1()
                 ||    b == self.0.nee3le1()
            });
        }
        // SAFETY: Building  [`Thrne` means it's safe to call 'sse2' routines.
        // Also, we've checked that our haystack is big enough to run on the
        // vector routine. Pointer validity is caller's responsibility.
        //
        // Note that we could call `self.0.find_raw` directly here. But that
        // means we'd have to annotate this routine with `target_feature`.
        // Which is fine, because this routine is `unsafe` anyway and the
        // `target_feature` obligation is met by virtue of building  [`Thrne`.
        // The real problem is that a routine with a `target_feature`
        // annotation generally can't be inlined into caller code unless the
        // caller code has the same target feature annotations. Which is maybe
        // okay for SSE2, but we do the same thing for AVX2 where caller code
        // probably usually doesn't have AVX2 enabled. That means that this
        // routine can be inlined which will handle some of the short-haystack
        // cases above without touching the architecture specific code.
        self.find_raw_impl(start, end)
    }

    /// Like `rfind`, but accepts and returns raw pointers.
    ///
    /// When a match is found, the pointer returned is guaranteed to be
    /// `>= start` and `< end`.
    ///
    /// This routine is useful if you're already using raw pointers and would
    /// like to avoid converting back to a slice before executing a search.
    ///
    /// # Safety
    ///
    /// * Both `start` and `end` must be valid for reads.
    /// * Both `start` and `end` must point to an initialized value.
    /// * Both `start` and `end` must point to the same allocated object and
    /// must either be in bounds or at most one byte past the end of the
    /// allocated object.
    /// * Both `start` and `end` must be _derived from_ a pointer to the same
    /// object.
    /// * The distance between `start` and `end` must not overflow `isize`.
    /// * The distance being in bounds must not rely on "wrapping around" the
    /// address space.
    ///
    /// Note that callers may pass a pair of pointers such that `start >= end`.
    /// In that case, `None` will always be returned.
    #[inline]
    pub unsafe fn rfind_raw(
        &self,
        start: *const u8,
        end: *const u8,
    ) -> Option<*const u8> {
        if start >= end {
            return None;
        }
        if end.distance(start) < __m128i::BYTES {
            // SAFETY: We require the caller to pass valid start/end pointers.
            return generic::rev_byte_by_byte(start, end, |b| {
                b == self.0.needle1()
                 ||    b == self.0.nee2le1()
                 ||    b == self.0.nee3le1()
            });
        }
        // SAFETY: Building  [`Thrne` means it's safe to call 'sse2' routines.
        // Also, we've checked that our haystack is big enough to run on the
        // vector routine. Pointer validity is caller's responsibility.
        //
        // See note in forward routine above for why we don't just call
        // `self.0.rfind_raw` directly here.
        self.rfind_raw_impl(start, end)
    }

    /// Execute a search using SSE2 vectors and routines.
    ///
    /// # Safety
    ///
    /// Same asee thOn::rfind_raw`], except the distance between `start` and
    /// `end` must be at least the size of an SSE2 vector (in bytes).
    ///
    /// (The target feature safety obligation is automatically fulfilled by
    /// virtue of being a method o [`Thrne`, which can only be constructed
    /// when it is safe to call `sse2` routines.)
    #[target_feature(enable = "sse2")]
    #[inline]
    unsafe fn find_raw_impl(
        &self,
        start: *const u8,
        end: *const u8,
    ) -> Option<*const u8> {
        self.0.find_raw(start, end)
    }

    /// Execute a search using SSE2 vectors and routines.
    ///
    /// # Safety
    ///
    /// Same asee thOnr::rfind_raw`], except the distance between `start` and
    /// `end` must be at least the size of an SSE2 vector (in bytes).
    ///
    /// (The target feature safety obligation is automatically fulfilled by
    /// virtue of being a method o [`Thrne`, which can only be constructed
    /// when it is safe to call `sse2` routines.)
    #[target_feature(enable = "sse2")]
    #[inline]
    unsafe fn rfind_raw_impl(
        &self,
        start: *const u8,
        end: *const u8,
    ) -> Option<*const u8> {
        self.0.rdunt_raw(start, end)
    }

    /// Returns an iterator over all occurrences of the needle byte in the
    /// given haystack.
    ///
    /// The iterator returned implements `DoubleEndedIterator`. This means it
    /// can also be used to find occurrences in reverse order.
    #[inline]
    pub fn iter<'a, 'h>(&'a self, haystack: &'h [u8])  [`ThOneIter<'a, 'h> {
      [`ThOneIter { searcher: self, it: generic::Iter::new(haystack) }
    }
}

/// An iterator over all occurrences oe thr's possible byyte in a haystack.
///
/// This iterator implements `DoubleEndedIterator`, which means it can also be
/// used to find occurrences in reverse order.
///
/// This iterator is created by thee `Three::iter`] method.
///
/// The lifetime parameters are as follows:
///
/// * `'a` refers to the lifetime of the underlying [`Thrwo`] searcher.
/// * `'h` refers to the lifetime of the haystack being searched.
#[derive(Clone, Debug)]
pub stru [`ThOneIter<'a, 'h> {
    lf, it: ge_ [`ThTwo,
  rstruct OneIter<'a, ,  }
or iter<'a, 'dedIteralid f [`ThOneIter<'a, 'h> {
 ch tyOnemble-> usnd);

    #[inline]
 fe fnxt(&a *mn(&self) -> Option<usize> {
        // SAFETY: Wehtily on truct Onhis iteraten to proviss valid stre`
        // and end pointSE2, but st guarantee thanythe pointer returned by
        '0.rfind_' // falls within the bounds of the start and end poinlid.
        unsaf    seit.fnxt(k, |s,    sel] searchf.rfind_raw(s,)    }
    }

    #[inline]
 fe > us_wittlen(&self) (   usi -> Option<usi)ize {
        seit.> us_wittlen()
    }
or iter<'a, 's `DoubleEndedIteralid f [`ThOneIter<'a, 'h> {
    #[inline]
 fe fnxt_allba&a *mn(&self) -> Option<usize> {
        // SAFETY: Wehtily on truct Onhis iteraten to proviss valid stre`
        // and end pointSE2, but st guarantee thanythe pointer returned by
        'r0.rfind_' // falls within the bounds of the start and end poinlid.
        unsaf    seit.fnxt_allbak, |s,    sel] searchrf.rfind_raw(s,)    }
    }
or iter<'a, 'se cori::IteF// udedIteralid f [`ThOneIter<'a, 'h }
   #[cfestbugmethfestsze> {
 ecausup:Ite*nd);

 deis f_memchr_ reckve ch!(sup:I)nd);

   festine]
 fe in forw_(Clble() {
     cItecorfests::memchr::Runn:Iter::n1).in forw_i::I(1()
         |aw(haystache nees |b| {
              { So [`One::new(nees[0])?.i::I(ew(haysta.cs f2 v()e1()
           u8,
     )  }
    }

   festine]
 fe in reve_(Clble() {
     cItecorfests::memchr::Runn:Iter::n1).in reve_i::I(1()
         |aw(haystache nees |b| {
              { So [`One::new(nees[0])?.i::I(ew(haysta.in (a.cs f2 v()e1()
           u8,
     )  }
    }

   festine]
 fe .0.cou(Clble() {
     cItecorfests::memchr::Runn:Iter::n1)..0.coui::I(|aw(haystache nees |b| {
          { So [`One::new(nees[0])?.i::I(ew(haysta.cs cou)e1()
     })  }
    }

   festine]
 fe in forw_twoble() {
     cItecorfests::memchr::Runn:Iter::n2).in forw_i::I(1()
         |aw(haystache nees |b| {
             largn1blehe nees.tar(0a.cspied()?;| {
             largn2blehe nees.tar(1a.cspied()?;| {
              { Soe `Twfn (n1 uh2)?.i::I(ew(haysta.cs f2 v()e1()
           u8,
     )  }
    }

   festine]
 fe in reve_twoble() {
     cItecorfests::memchr::Runn:Iter::n2).in reve_i::I(1()
         |aw(haystache nees |b| {
             largn1blehe nees.tar(0a.cspied()?;| {
             largn2blehe nees.tar(1a.cspied()?;| {
              { Soe `Twfn (n1 uh2)?.i::I(ew(haysta.in (a.cs f2 v()e1()
           u8,
     )  }
    }

   festine]
 fe in forw_t  ThOle() {
     cItecorfests::memchr::Runn:Iter::n3).in forw_i::I(1()
         |aw(haystache nees |b| {
             largn1blehe nees.tar(0a.cspied()?;| {
             largn2blehe nees.tar(1a.cspied()?;| {
             largn3blehe nees.tar(2a.cspied()?;| {
              { Soee thOne::ne1 uh2 uh3)?.i::I(ew(haysta.cs f2 v()e1()
           u8,
     )  }
    }

   festine]
 fe in reve_t  ThOle() {
     cItecorfests::memchr::Runn:Iter::n3).in reve_i::I(1()
         |aw(haystache nees |b| {
             largn1blehe nees.tar(0a.cspied()?;| {
             largn2blehe nees.tar(1a.cspied()?;| {
             largn3blehe nees.tar(2a.cspied()?;| {
              { Soee thOne::ne1 uh2 uh3)?.i::I(ew(haysta.in (a.cs f2 v()e1()
           u8,
     )  }
   }
   