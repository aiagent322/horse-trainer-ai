use proc_macro2::{Literal, Span, TokenStream};
use quote::ToTokens;
use syn::punctuated::Punctuated;
use syn::spanned::Spanned;
use syn::{self, Ident, Index, Member};

use bound;
use dummy;
use fragment::{Expr, Fragment, Match, Stmts};
use internals::ast::{Container, Data, Field, Style, Variant};
use internals::{attr, replace_receiver, ungroup, Ctxt, Derive};
use pretend;
use this;

use std::collections::BTreeSet;
use std::ptr;

pub fn expand_derive_deserialize(input: &mut syn::DeriveInput) -> syn::Result<TokenStream> {
    replace_receiver(input);

    let ctxt = Ctxt::new();
    let cont = match Container::from_ast(&ctxt, input, Derive::Deserialize) {
        Some(cont) => cont,
        None => return Err(ctxt.check().unwrap_err()),
    };
    precondition(&ctxt, &cont);
    ctxt.check()?;

    let ident = &cont.ident;
    let params = Parameters::new(&cont);
    let (de_impl_generics, _, ty_generics, where_clause) = split_with_de_lifetime(&params);
    let body = Stmts(deserialize_body(&cont, &params));
    let delife = params.borrowed.de_lifetime();
    let serde = cont.attrs.serde_path();

    let impl_block = if let Some(remote) = cont.attrs.remote() {
        let vis = &input.vis;
        let used = pretend::pretend_used(&cont, params.is_packed);
        quote! {
            impl #de_impl_generics #ident #ty_generics #where_clause {
                #vis fn deserialize<__D>(__deserializer: __D) -> #serde::__private::Result<#remote #ty_generics, __D::Error>
                where
                    __D: #serde::Deserializer<#delife>,
                {
                    #used
                    #body
                }
            }
        }
    } else {
        let fn_deserialize_in_place = deserialize_in_place_body(&cont, &params);

        quote! {
            #[automatically_derived]
            impl #de_impl_generics #serde::Deserialize<#delife> for #ident #ty_generics #where_clause {
                fn deserialize<__D>(__deserializer: __D) -> #serde::__private::Result<Self, __D::Error>
                where
                    __D: #serde::Deserializer<#delife>,
                {
                    #body
                }

                #fn_deserialize_in_place
            }
        }
    };

    Ok(dummy::wrap_in_const(
        cont.attrs.custom_serde_path(),
        impl_block,
    ))
}

fn precondition(cx: &Ctxt, cont: &Container) {
    precondition_sized(cx, cont);
    precondition_no_de_lifetime(cx, cont);
}

fn precondition_sized(cx: &Ctxt, cont: &Container) {
    if let Data::Struct(_, fields) = &cont.data {
        if let Some(last) = fields.last() {
            if let syn::Type::Slice(_) = ungroup(last.ty) {
                cx.error_spanned_by(
                    cont.original,
                    "cannot deserialize a dynamically sized struct",
                );
            }
        }
    }
}

fn precondition_no_de_lifetime(cx: &Ctxt, cont: &Container) {
    if let BorrowedLifetimes::Borrowed(_) = borrowed_lifetimes(cont) {
        for param in cont.generics.lifetimes() {
            if param.lifetime.to_string() == "'de" {
                cx.error_spanned_by(
                    &param.lifetime,
                    "cannot deserialize when there is a lifetime parameter called 'de",
                );
                return;
            }
        }
    }
}

struct Parameters {
    /// Name of the type the `derive` is on.
    local: syn::Ident,

    /// Path to the type the impl is for. Either a single `Ident` for local
    /// types (does not include generic parameters) or `some::remote::Path` for
    /// remote types.
    this_type: syn::Path,

    /// Same as `this_type` but using `::<T>` for generic parameters for use in
    /// expression position.
    this_value: syn::Path,

    /// Generics including any explicit and inferred bounds for the impl.
    generics: syn::Generics,

    /// Lifetimes borrowed from the deserializer. These will become bounds on
    /// the `'de` lifetime of the deserializer.
    borrowed: BorrowedLifetimes,

    /// At least one field has a serde(getter) attribute, implying that the
    /// remote type has a private field.
    has_getter: bool,

    /// Type has a repr(packed) attribute.
    is_packed: bool,
}

impl Parameters {
    fn new(cont: &Container) -> Self {
        let local = cont.ident.clone();
        let this_type = this::this_type(cont);
        let this_value = this::this_value(cont);
        let borrowed = borrowed_lifetimes(cont);
        let generics = build_generics(cont, &borrowed);
        let has_getter = cont.data.has_getter();
        let is_packed = cont.attrs.is_packed();

        Parameters {
            local,
            this_type,
            this_value,
            generics,
            borrowed,
            has_getter,
            is_packed,
        }
    }

    /// Type name to use in error messages and `&'static str` arguments to
    /// various Deserializer methods.
    fn type_name(&self) -> String {
        self.this_type.segments.last().unwrap().ident.to_string()
    }
}

// All the generics in the input, plus a bound `T: Deserialize` for each generic
// field type that will be deserialized by us, plus a bound `T: Default` for
// each generic field type that will be set to a default value.
fn build_generics(cont: &Container, borrowed: &BorrowedLifetimes) -> syn::Generics {
    let generics = bound::without_defaults(cont.generics);

    let generics = bound::with_where_predicates_from_fields(cont, &generics, attr::Field::de_bound);

    let generics =
        bound::with_where_predicates_from_variants(cont, &generics, attr::Variant::de_bound);

    match cont.attrs.de_bound() {
        Some(predicates) => bound::with_where_predicates(&generics, predicates),
        None => {
            let generics = match *cont.attrs.default() {
                attr::Default::Default => bound::with_self_bound(
                    cont,
                    &generics,
                    &parse_quote!(_serde::__private::Default),
                ),
                attr::Default::None | attr::Default::Path(_) => generics,
            };

            let delife = borrowed.de_lifetime();
            let generics = bound::with_bound(
                cont,
                &generics,
                needs_deserialize_bound,
                &parse_quote!(_serde::Deserialize<#delife>),
            );

            bound::with_bound(
                cont,
                &generics,
                requires_default,
                &parse_quote!(_serde::__private::Default),
            )
        }
    }
}

// Fields with a `skip_deserializing` or `deserialize_with` attribute, or which
// belong to a variant with a `skip_deserializing` or `deserialize_with`
// attribute, are not deserialized by us so we do not generate a bound. Fields
// with a `bound` attribute specify their own bound so we do not generate one.
// All other fields may need a `T: Deserialize` bound where T is the type of the
// field.
fn needs_deserialize_bound(field: &attr::Field, variant: Option<&attr::Variant>) -> bool {
    !field.skip_deserializing()
        && field.deserialize_with().is_none()
        && field.de_bound().is_none()
        && variant.map_or(true, |variant| {
            !variant.skip_deserializing()
                && variant.deserialize_with().is_none()
                && variant.de_bound().is_none()
        })
}

// Fields with a `default` attribute (not `default=...`), and fields with a
// `skip_deserializing` attribute that do not also have `default=...`.
fn requires_default(field: &attr::Field, _variant: Option<&attr::Variant>) -> bool {
    if let attr::Default::Default = *field.default() {
        true
    } else {
        false
    }
}

enum BorrowedLifetimes {
    Borrowed(BTreeSet<syn::Lifetime>),
    Static,
}

impl BorrowedLifetimes {
    fn de_lifetime(&self) -> syn::Lifetime {
        match *self {
            BorrowedLifetimes::Borrowed(_) => syn::Lifetime::new("'de", Span::call_site()),
            BorrowedLifetimes::Static => syn::Lifetime::new("'static", Span::call_site()),
        }
    }

    fn de_lifetime_param(&self) -> Option<syn::LifetimeParam> {
        match self {
            BorrowedLifetimes::Borrowed(bounds) => Some(syn::LifetimeParam {
                attrs: Vec::new(),
                lifetime: syn::Lifetime::new("'de", Span::call_site()),
                colon_token: None,
                bounds: bounds.iter().cloned().collect(),
            }),
            BorrowedLifetimes::Static => None,
        }
    }
}

// The union of lifetimes borrowed by each field of the container.
//
// These turn into bounds on the `'de` lifetime of the Deserialize impl. If
// lifetimes `'a` and `'b` are borrowed but `'c` is not, the impl is:
//
//     impl<'de: 'a + 'b, 'a, 'b, 'c> Deserialize<'de> for S<'a, 'b, 'c>
//
// If any borrowed lifetime is `'static`, then `'de: 'static` would be redundant
// and we use plain `'static` instead of `'de`.
fn borrowed_lifetimes(cont: &Container) -> BorrowedLifetimes {
    let mut lifetimes = BTreeSet::new();
    for field in cont.data.all_fields() {
        if !field.attrs.skip_deserializing() {
            lifetimes.extend(field.attrs.borrowed_lifetimes().iter().cloned());
        }
    }
    if lifetimes.iter().any(|b| b.to_string() == "'static") {
        BorrowedLifetimes::Static
    } else {
        BorrowedLifetimes::Borrowed(lifetimes)
    }
}

fn deserialize_body(cont: &Container, params: &Parameters) -> Fragment {
    if cont.attrs.transparent() {
        deserialize_transparent(cont, params)
    } else if let Some(type_from) = cont.attrs.type_from() {
        deserialize_from(type_from)
    } else if let Some(type_try_from) = cont.attrs.type_try_from() {
        deserialize_try_from(type_try_from)
    } else if let attr::Identifier::No = cont.attrs.identifier() {
        match &cont.data {
            Data::Enum(variants) => deserialize_enum(params, variants, &cont.attrs),
            Data::Struct(Style::Struct, fields) => {
                deserialize_struct(params, fields, &cont.attrs, StructForm::Struct)
            }
            Data::Struct(Style::Tuple, fields) | Data::Struct(Style::Newtype, fields) => {
                deserialize_tuple(params, fields, &cont.attrs, TupleForm::Tuple)
            }
            Data::Struct(Style::Unit, _) => deserialize_unit_struct(params, &cont.attrs),
        }
    } else {
        match &cont.data {
            Data::Enum(variants) => deserialize_custom_identifier(params, variants, &cont.attrs),
            Data::Struct(_, _) => unreachable!("checked in serde_derive_internals"),
        }
    }
}

#[cfg(feature = "deserialize_in_place")]
fn deserialize_in_place_body(cont: &Container, params: &Parameters) -> Option<Stmts> {
    // Only remote derives have getters, and we do not generate
    // deserialize_in_place for remote derives.
    assert!(!params.has_getter);

    if cont.attrs.transparent()
        || cont.attrs.type_from().is_some()
        || cont.attrs.type_try_from().is_some()
        || cont.attrs.identifier().is_some()
        || cont
            .data
            .all_fields()
            .all(|f| f.attrs.deserialize_with().is_some())
    {
        return None;
    }

    let code = match &cont.data {
        Data::Struct(Style::Struct, fields) => {
            deserialize_struct_in_place(None, params, fields, &cont.attrs, None)?
        }
        Data::Struct(Style::Tuple, fields) | Data::Struct(Style::Newtype, fields) => {
            deserialize_tuple_in_place(None, params, fields, &cont.attrs, None)
        }
        Data::Enum(_) | Data::Struct(Style::Unit, _) => {
            return None;
        }
    };

    let delife = params.borrowed.de_lifetime();
    let stmts = Stmts(code);

    let fn_deserialize_in_place = quote_block! {
        fn deserialize_in_place<__D>(__deserializer: __D, __place: &mut Self) -> _serde::__private::Result<(), __D::Error>
        where
            __D: _serde::Deserializer<#delife>,
        {
            #stmts
        }
    };

    Some(Stmts(fn_deserialize_in_place))
}

#[cfg(not(feature = "deserialize_in_place"))]
fn deserialize_in_place_body(_cont: &Container, _params: &Parameters) -> Option<Stmts> {
    None
}

fn deserialize_transparent(cont: &Container, params: &Parameters) -> Fragment {
    let fields = match &cont.data {
        Data::Struct(_, fields) => fields,
        Data::Enum(_) => unreachable!(),
    };

    let this_value = &params.this_value;
    let transparent_field = fields.iter().find(|f| f.attrs.transparent()).unwrap();

    let path = match transparent_field.attrs.deserialize_with() {
        Some(path) => quote!(#path),
        None => {
            let span = transparent_field.original.span();
            quote_spanned!(span=> _serde::Deserialize::deserialize)
        }
    };

    let assign = fields.iter().map(|field| {
        let member = &field.member;
        if ptr::eq(field, transparent_field) {
            quote!(#member: __transparent)
        } else {
            let value = match field.attrs.default() {
                attr::Default::Default => quote!(_serde::__private::Default::default()),
                attr::Default::Path(path) => quote!(#path()),
                attr::Default::None => quote!(_serde::__private::PhantomData),
            };
            quote!(#member: #value)
        }
    });

    quote_block! {
        _serde::__private::Result::map(
            #path(__deserializer),
            |__transparent| #this_value { #(#assign),* })
    }
}

fn deserialize_from(type_from: &syn::Type) -> Fragment {
    quote_block! {
        _serde::__private::Result::map(
            <#type_from as _serde::Deserialize>::deserialize(__deserializer),
            _serde::__private::From::from)
    }
}

fn deserialize_try_from(type_try_from: &syn::Type) -> Fragment {
    quote_block! {
        _serde::__private::Result::and_then(
            <#type_try_from as _serde::Deserialize>::deserialize(__deserializer),
            |v| _serde::__private::TryFrom::try_from(v).map_err(_serde::de::Error::custom))
    }
}

fn deserialize_unit_struct(params: &Parameters, cattrs: &attr::Container) -> Fragment {
    let this_type = &params.this_type;
    let this_value = &params.this_value;
    let type_name = cattrs.name().deserialize_name();
    let (de_impl_generics, de_ty_generics, ty_generics, where_clause) =
        split_with_de_lifetime(params);
    let delife = params.borrowed.de_lifetime();

    let expecting = format!("unit struct {}", params.type_name());
    let expecting = cattrs.expecting().unwrap_or(&expecting);

    quote_block! {
        #[doc(hidden)]
        struct __Visitor #de_impl_generics #where_clause {
            marker: _serde::__private::PhantomData<#this_type #ty_generics>,
            lifetime: _serde::__private::PhantomData<&#delife ()>,
        }

        impl #de_impl_generics _serde::de::Visitor<#delife> for __Visitor #de_ty_generics #where_clause {
            type Value = #this_type #ty_generics;

            fn expecting(&self, __formatter: &mut _serde::__private::Formatter) -> _serde::__private::fmt::Result {
                _serde::__private::Formatter::write_str(__formatter, #expecting)
            }

            #[inline]
            fn visit_unit<__E>(self) -> _serde::__private::Result<Self::Value, __E>
            where
                __E: _serde::de::Error,
            {
                _serde::__private::Ok(#this_value)
            }
        }

        _serde::Deserializer::deserialize_unit_struct(
            __deserializer,
            #type_name,
            __Visitor {
                marker: _serde::__private::PhantomData::<#this_type #ty_generics>,
                lifetime: _serde::__private::PhantomData,
            },
        )
    }
}

enum TupleForm<'a> {
    Tuple,
    /// Contains a variant name
    ExternallyTagged(&'a syn::Ident),
    /// Contains a variant name and an intermediate deserializer from which actual
    /// deserialization will be performed
    Untagged(&'a syn::Ident, TokenStream),
}

fn deserialize_tuple(
    params: &Parameters,
    fields: &[Field],
    cattrs: &attr::Container,
    form: TupleForm,
) -> Fragment {
    assert!(!cattrs.has_flatten());

    let field_count = fields
        .iter()
        .filter(|field| !field.attrs.skip_deserializing())
        .count();

    let this_type = &params.this_type;
    let this_value = &params.this_value;
    let (de_impl_generics, de_ty_generics, ty_generics, where_clause) =
        split_with_de_lifetime(params);
    let delife = params.borrowed.de_lifetime();

    // If there are getters (implying private fields), construct the local type
    // and use an `Into` conversion to get the remote type. If there are no
    // getters then construct the target type directly.
    let construct = if params.has_getter {
        let local = &params.local;
        quote!(#local)
    } else {
        quote!(#this_value)
    };

    let type_path = match form {
        TupleForm::Tuple => construct,
        TupleForm::ExternallyTagged(variant_ident) | TupleForm::Untagged(variant_ident, _) => {
            quote!(#construct::#variant_ident)
        }
    };
    let expecting = match form {
        TupleForm::Tuple => format!("tuple struct {}", params.type_name()),
        TupleForm::ExternallyTagged(variant_ident) | TupleForm::Untagged(variant_ident, _) => {
            format!("tuple variant {}::{}", params.type_name(), variant_ident)
        }
    };
    let expecting = cattrs.expecting().unwrap_or(&expecting);

    let nfields = fields.len();

    let visit_newtype_struct = match form {
        TupleForm::Tuple if nfields == 1 => {
            Some(deserialize_newtype_struct(&type_path, params, &fields[0]))
        }
        _ => None,
    };

    let visit_seq = Stmts(deserialize_seq(
        &type_path, params, fields, false, cattrs, expecting,
    ));

    let visitor_expr = quote! {
        __Visitor {
            marker: _serde::__private::PhantomData::<#this_type #ty_generics>,
            lifetime: _serde::__private::PhantomData,
        }
    };
    let dispatch = match form {
        TupleForm::Tuple if nfields == 1 => {
            let type_name = cattrs.name().deserialize_name();
            quote! {
                _serde::Deserializer::deserialize_newtype_struct(__deserializer, #type_name, #visitor_expr)
            }
        }
        TupleForm::Tuple => {
            let type_name = cattrs.name().deserialize_name();
            quote! {
                _serde::Deserializer::deserialize_tuple_struct(__deserializer, #type_name, #field_count, #visitor_expr)
            }
        }
        TupleForm::ExternallyTagged(_) => quote! {
            _serde::de::VariantAccess::tuple_variant(__variant, #field_count, #visitor_expr)
        },
        TupleForm::Untagged(_, deserializer) => quote! {
            _serde::Deserializer::deserialize_tuple(#deserializer, #field_count, #visitor_expr)
        },
    };

    let visitor_var = if field_count == 0 {
        quote!(_)
    } else {
        quote!(mut __seq)
    };

    quote_block! {
        #[doc(hidden)]
        struct __Visitor #de_impl_generics #where_clause {
            marker: _serde::__private::PhantomData<#this_type #ty_generics>,
            lifetime: _serde::__private::PhantomData<&#delife ()>,
        }

        impl #de_impl_generics _serde::de::Visitor<#delife> for __Visitor #de_ty_generics #where_clause {
            type Value = #this_type #ty_generics;

            fn expecting(&self, __formatter: &mut _serde::__private::Formatter) -> _serde::__private::fmt::Result {
                _serde::__private::Formatter::write_str(__formatter, #expecting)
            }

            #visit_newtype_struct

            #[inline]
            fn visit_seq<__A>(self, #visitor_var: __A) -> _serde::__private::Result<Self::Value, __A::Error>
            where
                __A: _serde::de::SeqAccess<#delife>,
            {
                #visit_seq
            }
        }

        #dispatch
    }
}

#[cfg(feature = "deserialize_in_place")]
fn deserialize_tuple_in_place(
    variant_ident: Option<syn::Ident>,
    params: &Parameters,
    fields: &[Field],
    cattrs: &attr::Container,
    deserializer: Option<TokenStream>,
) -> Fragment {
    assert!(!cattrs.has_flatten());

    let field_count = fields
        .iter()
        .filter(|field| !field.attrs.skip_deserializing())
        .count();

    let this_type = &params.this_type;
    let (de_impl_generics, de_ty_generics, ty_generics, where_clause) =
        split_with_de_lifetime(params);
    let delife = params.borrowed.de_lifetime();

    let is_enum = variant_ident.is_some();
    let expecting = match variant_ident {
        Some(variant_ident) => format!("tuple variant {}::{}", params.type_name(), variant_ident),
        None => format!("tuple struct {}", params.type_name()),
    };
    let expecting = cattrs.expecting().unwrap_or(&expecting);

    let nfields = fields.len();

    let visit_newtype_struct = if !is_enum && nfields == 1 {
        Some(deserialize_newtype_struct_in_place(params, &fields[0]))
    } else {
        None
    };

    let visit_seq = Stmts(deserialize_seq_in_place(params, fields, cattrs, expecting));

    let visitor_expr = quote! {
        __Visitor {
            place: __place,
            lifetime: _serde::__private::PhantomData,
        }
    };

    let dispatch = if let Some(deserializer) = deserializer {
        quote!(_serde::Deserializer::deserialize_tuple(#deserializer, #field_count, #visitor_expr))
    } else if is_enum {
        quote!(_serde::de::VariantAccess::tuple_variant(__variant, #field_count, #visitor_expr))
    } else if nfields == 1 {
        let type_name = cattrs.name().deserialize_name();
        quote!(_serde::Deserializer::deserialize_newtype_struct(__deserializer, #type_name, #visitor_expr))
    } else {
        let type_name = cattrs.name().deserialize_name();
        quote!(_serde::Deserializer::deserialize_tuple_struct(__deserializer, #type_name, #field_count, #visitor_expr))
    };

    let visitor_var = if field_count == 0 {
        quote!(_)
    } else {
        quote!(mut __seq)
    };

    let in_place_impl_generics = de_impl_generics.in_place();
    let in_place_ty_generics = de_ty_generics.in_place();
    let place_life = place_lifetime();

    quote_block! {
        #[doc(hidden)]
        struct __Visitor #in_place_impl_generics #where_clause {
            place: &#place_life mut #this_type #ty_generics,
            lifetime: _serde::__private::PhantomData<&#delife ()>,
        }

        impl #in_place_impl_generics _serde::de::Visitor<#delife> for __Visitor #in_place_ty_generics #where_clause {
            type Value = ();

            fn expecting(&self, __formatter: &mut _serde::__private::Formatter) -> _serde::__private::fmt::Result {
                _serde::__private::Formatter::write_str(__formatter, #expecting)
            }

            #visit_newtype_struct

            #[inline]
            fn visit_seq<__A>(self, #visitor_var: __A) -> _serde::__private::Result<Self::Value, __A::Error>
            where
                __A: _serde::de::SeqAccess<#delife>,
            {
                #visit_seq
            }
        }

        #dispatch
    }
}

fn deserialize_seq(
    type_path: &TokenStream,
    params: &Parameters,
    fields: &[Field],
    is_struct: bool,
    cattrs: &attr::Container,
    expecting: &str,
) -> Fragment {
    let vars = (0..fields.len()).map(field_i as fn(_) -> _);

    let deserialized_count = fields
        .iter()
        .filter(|field| !field.attrs.skip_deserializing())
        .count();
    let expecting = if deserialized_count == 1 {
        format!("{} with 1 element", expecting)
    } else {
        format!("{} with {} elements", expecting, deserialized_count)
    };
    let expecting = cattrs.expecting().unwrap_or(&expecting);

    let mut index_in_seq = 0_usize;
    let let_values = vars.clone().zip(fields).map(|(var, field)| {
        if field.attrs.skip_deserializing() {
            let default = Expr(expr_is_missing(field, cattrs));
            quote! {
                let #var = #default;
            }
        } else {
            let visit = match field.attrs.deserialize_with() {
                None => {
                    let field_ty = field.ty;
                    let span = field.original.span();
                    let func =
                        quote_spanned!(span=> _serde::de::SeqAccess::next_element::<#field_ty>);
                    quote!(try!(#func(&mut __seq)))
                }
                Some(path) => {
                    let (wrapper, wrapper_ty) = wrap_deserialize_field_with(params, field.ty, path);
                    quote!({
                        #wrapper
                        _serde::__private::Option::map(
                            try!(_serde::de::SeqAccess::next_element::<#wrapper_ty>(&mut __seq)),
                            |__wrap| __wrap.value)
                    })
                }
            };
            let value_if_none = match field.attrs.default() {
                attr::Default::Default => quote!(_serde::__private::Default::default()),
                attr::Default::Path(path) => quote!(#path()),
                attr::Default::None => quote!(
                    return _serde::__private::Err(_serde::de::Error::invalid_length(#index_in_seq, &#expecting));
                ),
            };
            let assign = quote! {
                let #var = match #visit {
                    _serde::__private::Some(__value) => __value,
                    _serde::__private::None => {
                        #value_if_none
                    }
                };
            };
            index_in_seq += 1;
            assign
        }
    });

    let mut result = if is_struct {
        let names = fields.iter().map(|f| &f.member);
        quote! {
            #type_path { #( #names: #vars ),* }
        }
    } else {
        quote! {
            #type_path ( #(#vars),* )
        }
    };

    if params.has_getter {
        let this_type = &params.this_type;
        let (_, ty_generics, _) = params.generics.split_for_impl();
        result = quote! {
            _serde::__private::Into::<#this_type #ty_generics>::into(#result)
        };
    }

    let let_default = match cattrs.default() {
        attr::Default::Default => Some(quote!(
            let __default: Self::Value = _serde::__private::Default::default();
        )),
        attr::Default::Path(path) => Some(quote!(
            let __default: Self::Value = #path();
        )),
        attr::Default::None => {
            // We don't need the default value, to prevent an unused variable warning
            // we'll leave the line empty.
            None
        }
    };

    quote_block! {
        #let_default
        #(#let_values)*
        _serde::__private::Ok(#result)
    }
}

#[cfg(feature = "deserialize_in_place")]
fn deserialize_seq_in_place(
    params: &Parameters,
    fields: &[Field],
    cattrs: &attr::Container,
    expecting: &str,
) -> Fragment {
    let deserialized_count = fields
        .iter()
        .filter(|field| !field.attrs.skip_deserializing())
        .count();
    let expecting = if deserialized_count == 1 {
        format!("{} with 1 element", expecting)
    } else {
        format!("{} with {} elements", expecting, deserialized_count)
    };
    let expecting = cattrs.expecting().unwrap_or(&expecting);

    let mut index_in_seq = 0usize;
    let write_values = fields.iter().map(|field| {
        let member = &field.member;

        if field.attrs.skip_deserializing() {
            let default = Expr(expr_is_missing(field, cattrs));
            quote! {
                self.place.#member = #default;
            }
        } else {
            let value_if_none = match field.attrs.default() {
                attr::Default::Default => quote!(
                    self.place.#member = _serde::__private::Default::default();
                ),
                attr::Default::Path(path) => quote!(
                    self.place.#member = #path();
                ),
                attr::Default::None => quote!(
                    return _serde::__private::Err(_serde::de::Error::invalid_length(#index_in_seq, &#expecting));
                ),
            };
            let write = match field.attrs.deserialize_with() {
                None => {
                    quote! {
                        if let _serde::__private::None = try!(_serde::de::SeqAccess::next_element_seed(&mut __seq,
                            _serde::__private::de::InPlaceSeed(&mut self.place.#member)))
                        {
                            #value_if_none
                        }
                    }
                }
                Some(path) => {
                    let (wrapper, wrapper_ty) = wrap_deserialize_field_with(params, field.ty, path);
                    quote!({
                        #wrapper
                        match try!(_serde::de::SeqAccess::next_element::<#wrapper_ty>(&mut __seq)) {
                            _serde::__private::Some(__wrap) => {
                                self.place.#member = __wrap.value;
                            }
                            _serde::__private::None => {
                                #value_if_none
                            }
                        }
                    })
                }
            };
            index_in_seq += 1;
            write
        }
    });

    let this_type = &params.this_type;
    let (_, ty_generics, _) = params.generics.split_for_impl();
    let let_default = match cattrs.default() {
        attr::Default::Default => Some(quote!(
            let __default: #this_type #ty_generics = _serde::__private::Default::default();
        )),
        attr::Default::Path(path) => Some(quote!(
            let __default: #this_type #ty_generics = #path();
        )),
        attr::Default::None => {
            // We don't need the default value, to prevent an unused variable warning
            // we'll leave the line empty.
            None
        }
    };

    quote_block! {
        #let_default
        #(#write_values)*
        _serde::__private::Ok(())
    }
}

fn deserialize_newtype_struct(
    type_path: &TokenStream,
    params: &Parameters,
    field: &Field,
) -> TokenStream {
    let delife = params.borrowed.de_lifetime();
    let field_ty = field.ty;

    let value = match field.attrs.deserialize_with() {
        None => {
            let span = field.original.span();
            let func = quote_spanned!(span=> <#field_ty as _serde::Deserialize>::deserialize);
            quote! {
                try!(#func(__e))
            }
        }
        Some(path) => {
            quote! {
                try!(#path(__e))
            }
        }
    };

    let mut result = quote!(#type_path(__field0));
    if params.has_getter {
        let this_type = &params.this_type;
        let (_, ty_generics, _) = params.generics.split_for_impl();
        result = quote! {
            _serde::__private::Into::<#this_type #ty_generics>::into(#result)
        };
    }

    quote! {
        #[inline]
        fn visit_newtype_struct<__E>(self, __e: __E) -> _serde::__private::Result<Self::Value, __E::Error>
        where
            __E: _serde::Deserializer<#delife>,
        {
            let __field0: #field_ty = #value;
            _serde::__private::Ok(#result)
        }
    }
}

#[cfg(feature = "deserialize_in_place")]
fn deserialize_newtype_struct_in_place(params: &Parameters, field: &Field) -> TokenStream {
    // We do not generate deserialize_in_place if every field has a
    // deserialize_with.
    assert!(field.attrs.deserialize_with().is_none());

    let delife = params.borrowed.de_lifetime();

    quote! {
        #[inline]
        fn visit_newtype_struct<__E>(self, __e: __E) -> _serde::__private::Result<Self::Value, __E::Error>
        where
            __E: _serde::Deserializer<#delife>,
        {
            _serde::Deserialize::deserialize_in_place(__e, &mut self.place.0)
        }
    }
}

enum StructForm<'a> {
    Struct,
    /// Contains a variant name
    ExternallyTagged(&'a syn::Ident),
    /// Contains a variant name and an intermediate deserializer from which actual
    /// deserialization will be performed
    InternallyTagged(&'a syn::Ident, TokenStream),
    /// Contains a variant name and an intermediate deserializer from which actual
    /// deserialization will be performed
    Untagged(&'a syn::Ident, TokenStream),
}

fn deserialize_struct(
    params: &Parameters,
    fields: &[Field],
    cattrs: &attr::Container,
    form: StructForm,
) -> Fragment {
    let this_type = &params.this_type;
    let this_value = &params.this_value;
    let (de_impl_generics, de_ty_generics, ty_generics, where_clause) =
        split_with_de_lifetime(params);
    let delife = params.borrowed.de_lifetime();

    // If there are getters (implying private fields), construct the local type
    // and use an `Into` conversion to get the remote type. If there are no
    // getters then construct the target type directly.
    let construct = if params.has_getter {
        let local = &params.local;
        quote!(#local)
    } else {
        quote!(#this_value)
    };

    let type_path = match form {
        StructForm::Struct => construct,
        StructForm::ExternallyTagged(variant_ident)
        | StructForm::InternallyTagged(variant_ident, _)
        | StructForm::Untagged(variant_ident, _) => quote!(#construct::#variant_ident),
    };
    let expecting = match form {
        StructForm::Struct => format!("struct {}", params.type_name()),
        StructForm::ExternallyTagged(variant_ident)
        | StructForm::InternallyTagged(variant_ident, _)
        | StructForm::Untagged(variant_ident, _) => {
            format!("struct variant {}::{}", params.type_name(), variant_ident)
        }
    };
    let expecting = cattrs.expecting().unwrap_or(&expecting);

    let field_names_idents: Vec<_> = fields
        .iter()
        .enumerate()
        // Skip fields that shouldn't be deserialized or that were flattened,
        // so they don't appear in the storage in their literal form
        .filter(|&(_, field)| !field.attrs.skip_deserializing() && !field.attrs.flatten())
        .map(|(i, field)| {
            (
                field.attrs.name().deserialize_name(),
                field_i(i),
                field.attrs.aliases(),
            )
        })
        .collect();
    let field_visitor = Stmts(deserialize_generated_identifier(
        &field_names_idents,
        cattrs,
        false,
        None,
    ));

    // untagged struct variants do not get a visit_seq method. The same applies to
    // structs that only have a map representation.
    let visit_seq = match form {
        StructForm::Untagged(..) => None,
        _ if cattrs.has_flatten() => None,
        _ => {
            let mut_seq = if field_names_idents.is_empty() {
                quote!(_)
            } else {
                quote!(mut __seq)
            };

            let visit_seq = Stmts(deserialize_seq(
                &type_path, params, fields, true, cattrs, expecting,
            ));

            Some(quote! {
                #[inline]
                fn visit_seq<__A>(self, #mut_seq: __A) -> _serde::__private::Result<Self::Value, __A::Error>
                where
                    __A: _serde::de::SeqAccess<#delife>,
                {
                    #visit_seq
                }
            })
        }
    };
    let visit_map = Stmts(deserialize_map(&type_path, params, fields, cattrs));

    let visitor_seed = match form {
        StructForm::ExternallyTagged(..) if cattrs.has_flatten() => Some(quote! {
            impl #de_impl_generics _serde::de::DeserializeSeed<#delife> for __Visitor #de_ty_generics #where_clause {
                type Value = #this_type #ty_generics;

                fn deserialize<__D>(self, __deserializer: __D) -> _serde::__private::Result<Self::Value, __D::Error>
                where
                    __D: _serde::Deserializer<#delife>,
                {
                    _serde::Deserializer::deserialize_map(__deserializer, self)
                }
            }
        }),
        _ => None,
    };

    let fields_stmt = if cattrs.has_flatten() {
        None
    } else {
        let field_names = field_names_idents
            .iter()
            .flat_map(|(_, _, aliases)| aliases);

        Some(quote! {
            #[doc(hidden)]
            const FIELDS: &'static [&'static str] = &[ #(#field_names),* ];
        })
    };

    let visitor_expr = quote! {
        __Visitor {
            marker: _serde::__private::PhantomData::<#this_type #ty_generics>,
            lifetime: _serde::__private::PhantomData,
        }
    };
    let dispatch = match form {
        StructForm::Struct if cattrs.has_flatten() => quote! {
            _serde::Deserializer::deserialize_map(__deserializer, #visitor_expr)
        },
        StructForm::Struct => {
            let type_name = cattrs.name().deserialize_name();
            quote! {
                _serde::Deserializer::deserialize_struct(__deserializer, #type_name, FIELDS, #visitor_expr)
            }
        }
        StructForm::ExternallyTagged(_) if cattrs.has_flatten() => quote! {
            _serde::de::VariantAccess::newtype_variant_seed(__variant, #visitor_expr)
        },
        StructForm::ExternallyTagged(_) => quote! {
            _serde::de::VariantAccess::struct_variant(__variant, FIELDS, #visitor_expr)
        },
        StructForm::InternallyTagged(_, deserializer) => quote! {
            _serde::Deserializer::deserialize_any(#deserializer, #visitor_expr)
        },
        StructForm::Untagged(_, deserializer) => quote! {
            _serde::Deserializer::deserialize_any(#deserializer, #visitor_expr)
        },
    };

    quote_block! {
        #field_visitor

        #[doc(hidden)]
        struct __Visitor #de_impl_generics #where_clause {
            marker: _serde::__private::PhantomData<#this_type #ty_generics>,
            lifetime: _serde::__private::PhantomData<&#delife ()>,
        }

        impl #de_impl_generics _serde::de::Visitor<#delife> for __Visitor #de_ty_generics #where_clause {
            type Value = #this_type #ty_generics;

            fn expecting(&self, __formatter: &mut _serde::__private::Formatter) -> _serde::__private::fmt::Result {
                _serde::__private::Formatter::write_str(__formatter, #expecting)
            }

            #visit_seq

            #[inline]
            fn visit_map<__A>(self, mut __map: __A) -> _serde::__private::Result<Self::Value, __A::Error>
            where
                __A: _serde::de::MapAccess<#delife>,
            {
                #visit_map
            }
        }

        #visitor_seed

        #fields_stmt

        #dispatch
    }
}

#[cfg(feature = "deserialize_in_place")]
fn deserialize_struct_in_place(
    variant_ident: Option<syn::Ident>,
    params: &Parameters,
    fields: &[Field],
    cattrs: &attr::Container,
    deserializer: Option<TokenStream>,
) -> Option<Fragment> {
    let   }
}

#[rhis_type;
    let this_value = &paramu
   t local = &params.local;
        quote!(#

   ccess::next_element_seed(&mut __seq,
 y_mapat this_    #[me();
    l = qu, #mut_seq: __A) -> _serde::__private:a(f>erde::__private:a(f>er.trs.type_          .iter()
            s) => {
            deserialause) =
        split_with_de_lifetime(params);
    let delife = params.borrowed.de_lifetime();

    let is_enum = variant_ident.is_some();
    let expecting = match variant_ident {
        Some(varia, params.type_name(), variant_ident),
        None => format!("tuple struc cattrs.expecting().unwrap_or(&expecting);

    let field_ttrs.expecting().unwrap_or(ting);

    let nfields = fields.len();

    let visit_newtype_struct = if !is_enum && nfields == 1 {
        Sr_expr = quote! {
        __Visitor {
            place: __place,
            lifetime: _({
           ,eld_names_id,         w  let is_enu  fields: &[Field],as[Field],
    cat                place: __place, Skip fields that         false,
  that        
        cattrs,mes_identlse,
  thatmes_id)tor_seed = match form {
            w lifetime: _serde::__private::PhantomData,
        }
    };

    let dispatch = if let Some(deserializer) = deserializer {
        quote!(_serde::Deserialier::deserialize_tuple(#deserializer, #field_count, #visitor_expr))
    } els   };

    quote_block! {
        #field_visitor

        #[doc(hidden)]
        struct __Vield_count, #visitor_expr))
    } else i    },
        StructForm::InternallyTagged(_, deserializer) => quote! {
            _serde::DeseriaDeserializer::deserialize_tuple_struct(__deserializer, #type_name, #field_count, #visi   };

    quote_block! {
        #field_visitor
tForm::ExternallyTagged(_) if cattrs.has_flatten() => quote! {
       if ptr::eq(fielll_    peield.attrs.deseriamatch       = 1 {
        format!("{} with 1 ;__seq)
    };

    let in_lll_    peiecs = de_impl_generics.in_place();
    let in_place_ty_generics = de_ty_gener_expr = quoivate::Result<Self::Value, __E::Error>
          where
                __A: _serde::de::SeqAccess<#delife>,
            {
                #v::deserialize_in_pla     }
            })
        }
    };
    {
mts(deserialize_map(&type_path,}rics = de_ty_generics.in_place();
    let place_life = place_lifetime();

    quote_block! {
        #[doc(hidden)]
        struct __Visitor #in_place_impl_generics #where_c #(#field_rics #where_clause {
            marker: _serde::__private::PhantomData<#this_type ics,
            lifetime: _serde::__private::PhantomData<&#delife ()>,
        }

        impl #in_place_impl_generics _serde::de::Visitor<#delife> for __Visitor #in_place_ty_generics #where_clause {
            type Value = ();

            fn expecting(&self, __formatter: &mut _serde::__private::Formatter) -> _serde::__private::fmt::Result {
                _serde::__private::Formatter::write_str(__formatter, #expecting)
            }

            #visit_newtype_struct

            #[inline]
            fn vA>(self, mut __map: __A) -> _serde::__private::Result<Self::Value, __A::Error>
            where
                __A: _serde::de::MapAccess<#delife>,
            {
                #visit_map
            }
        }

        #visitor_seed

        #fields_stmt

        #dispatch
    }
}

#[cfg(feature = "deserialize_in__struct_in_place(
    variant_ident:)ntainer,
    form: r_exForm,
) -> Fragment {
    let t represeagmeInterna
    let   }
}

#[rhis_type;
    
    let (de_impl_ge(f>ch f represen None,lcaldy beocal
fn des(in:a(t.,
  ged(.lllt only hav represenerializaams.loen
    fe_name(), vars.deseriapo
  A) (|(),|e(),
       only ha())dent),
        None => forx)          _serde::Dese(nly ha,t only ha)s::next_el#ty_geneatNone => forx);
            quotnly ha_fet r = #def,
    form: homoter:outor_ex        pnly ha,t     } else {
        tor {
        nly ha_r_ex_afeser       p  nly ha__place,
     Nnly ha_fet e_path, params, fieldting().u,
    form: homoter:outor_ex        pnext_el#,t     } ,    field: &Field,
) -> Thomoter:outor_ex orm,
) -> Fragment {
    let t represeagmeInterna
    let   }
}

#[rhis_type;
    
    let (de_impl_gelt: #this_typnlyenerics = _serde::_Tag <#tnt, FIELDS().u,
    form: e FIELDS, _nly ha_r_ex        pnext_el#,t     } ,    f _serde::_Tag <#tnt(#deseri {pnlyn_p        Data::Enum(_) | Data:inFIELDS, _nly ha_r_ex        pnext_el#,t     } pnly_path, params, fieldrde::_Tag <#tntAdj_foe_impnly are toe_i_p        Data::Enum(_) | Data:adj_foe_, _nly ha_r_ex        pnext_el#,t     } pnly are toe__path, params, fieldrde::_Tag <#tntting().u,
    form:   nly ha_r_ex        pnext_el#,t     } ,    field: &Fpreagme_r_ex_one => fr_ex orm,
 represeagmeInterna
    let   }
}

#[rhis_type;
    
    (rams.borrowe {
   ) quote!(#

    et mut index_ represen::next_el#that were flattened,
        // so they don't (|(i, field)| next_el    next_el
        format!("{} with 1 ;_lds
         => fshouldn't be deserializet mut index_ represeield_names_   let),
                next_el   i),
                field.attrs.next_el
                 )
        })
        .collect();
    let field_visitor = Stmnext_el
      ze_generated_identifier(
        &field_names_idents,
  lds
     oams.forxlizet mut index_ represeapo
  A) (|d)| next_el   next_el
      oams. 1 ;_lds
         => mes_ident::deserialize_    => fshouls::next_ele(mut __seq)
  ing() {
   ( cattrIELD    cat    quote! {
            #type_pa   })
    };

    let visitor_exVARIANTquote! {
        __Visitor {
      next_ele(mut r: _serde::__prirics = de_ty_generext_ele        false,
        None,
    ));

    // untagged strucnext_ele(mut __seq)
get a visit_seq method. Th     ethod. Thoams.forx   // structs t(    => mes_id,erext_ele       )ntainer,
    form: r FIELDS, _nly ha_r_ex orm,
) -> Fragment {
    let t represeagmeInterna
    let   }
}

#[rhis_type;
    
    let (de_impl_gerialause) =
        split_with_de_lifetime(params);
    let delife = params.borrowed.de_lifetime();

    let is_enum = variant_ident.is_some();
    let expecting = match variant_ident {
        Some(variaerics, where_clause) =
        split_with_de_lifetime(().unwrap_or(&expectir_exprte_block! {
        #[doc(hidden)]
        struct __Visitor #de_impl_generics #where_clause ime(p    => mes_id,erext_ele       ) = mreagme_r_ex_one => fr_ex next_el#,t     } __seq,
 y_Mt: #tarm   S)]
tract be performryFromsitock! {
  generext_elearm  ::next_el#that were flattened,
        // so they don't (|(i, field)| next_el    next_el
        format!("{} with 1 ),
                next_el   i),
          ize_    => fshou      Somet fs, true, cattrs, exics #   Mt: #(,
    form: r FIELDS, _nly ha_serializeld_visitor = Stm       pnext_el,it_seq method. Thself, #mut_seq: __A) IELDS, #visitor_expr)
   e]
nt> {!("struct { cattrI_seriali)    #ics #en() {
        None
    }ptr::eq(fielll_    peieldnext_el#that were flattened,
     matchnext_el  next_el
        format!("{} with 1 ;__seq)
  lt: #_serialiet in_lll_    peiecs = de_im(f>chis is anrite_v r_explike `r_expImpo
siuote{}`    anri_expin:),
}
s = de_im(f>lllt represen None`#[

   (  format!("{} with)]`.  quote! {
            #type_p(f>FIXME: Once n::Iden(exh

 tivrnallFIEL ) is   _uot:      #type_p(f>                     _s    }s: &)(quote!(
       _exllyTagge repres::<]
nt> {>:Extataelse {
        (f>                 _s    }s: &)place")]
fn deserialize_newtype_elife> __seq)),
             ote!(
       _exllyTagge repres::<]
nt> {>:Extataeield_visitor = Stm|d)ams)o
siuotELD   lt: #t)ams)o
siuote{})

    if params.has_getter {
        let this_type =           _serde::__pri _exllyTagge repres:Extatae  };

            le   next_elearm kenStream,
tter {
        let this_typeield_rics #where_clause rext_ele        marker: _serde::__private::PhantomData<#this_type #ty_generics>,
            lifetime: _serde::__private::PhantomData<&#delife ()>,
        }

        impl #de_impl_generics _serde::de::Visitor<#delife> for __Visitor #de_ty_generics #where_clause {
            type Value = #this_type #ty_generics;

            fn expecting(&self, __formatter: &mut _serde::__private::Formatter) -> _serde::__private::fmt::Result {
                _serde::__private::Formatter::write_str(__formatter, #expecting)
            }

            #visit_newtype_struct

            #[inline]
            fn vA>(self, mut __map: __A) -> _serde         i_exhere
       Extata__A: _serde::de::MapAccess<#delife>,
            {
                #visit_map
            }
        }

        # _exllyTageed

        #fields_stmt

        #dispatlt: #_seriali}

#[cfg(feature = "deserialize_in_p   => mes_id  #type_name,
            __Visitor {
      r_ex orm,
   }
     _private::PhantomData::<#this_type #ty_generics>,
VARIANTqty_generics>,
                lifetime: _serde::__private::PhantomData,
            },
        )
    }
}

enum TupleForm<'a> {
    Tuple,
    /// Contains a variant name
    ExternallyTagged(&'a syn::Iner,
    form: inFIELDS, _nly ha_r_ex orm,
) -> Fragment {
    let t represeagmeInterna
    let   }
}

#[rhis_type;
    erde:aield| !field.attrs.skip_deserialip    => mes_id,erext_ele       ) = mreagme_r_ex_one => fr_ex next_el#,t     } __seq,
 y_Mt: #tarm   S)]
tract be performryFromsitock! {
  generext_elearm  ::next_el#that were flattened,
        // so they don't (|(i, field)| next_el    next_el
        format!("{} with 1 ),
                next_el   i),
          ize_    => fshou      Somet fs, true, cattrs, exics #   Mt: #(,
    form: inFIELDS, _nly ha_serializeld_visitor = Stm       eld_visitor = Stmnext_el eld_visitor = Stmt_seq method. Thselfe_impl_gener _private::Ph)method. Thself, #mut_seq: __A) IELDS, #visitor_expr)
   ]
nt> {!("struct { cat    #ics #en() {
        None
    }ptr::eq(fie().unwrap_or(&expectiinFIELDS, pnly ha r_exprte_block! {
        #[doc(hidden)]
        struct __Visitor #de_impl_generics #where_clause ield_rics #where_clause rext_ele        marker: _sp   => mes_id  #type_na   _se_nly a__re toe__::__private::de: {
        #field_visitor

   orm,
   }
     _private::PhantomData::<#t                     #vizer, Ce toe_       ::<]
nt> {>d(_) (#nly aialize_with()
            _  _private::Ph(quote!(
            l(
  Ce toe_ {
        #fi<           d(_) (__re toe__#mut_seq: _lt: #t)anlyn       #type_pa  next_elearm kenStream,
}&'a syn::Iner,
    form: adj_foe_, _nly ha_r_ex orm,
) -> Fragment {
    let t represeagmeInterna
    let   }
}

#[rhis_type;
    erde:aield| !fivisitortainerd| !field.attrs.skip_deserialics, de_ty_generics, ty_generics, where_clause) =
        split_with_de_lifetime(params);
    let delife = params.borrowed.de_lifetime();

    // If there are getters (implying private fields), construct the local type
    // and use an `ialip    => mes_id,erext_ele       ) = mreagme_r_ex_one => fr_ex next_el#,t     } __seq,
generext_elearm erdeserializ&next_el#that were flattened,
        // so they don't (|(i, field)| next_el    next_el
        format!("{} with 1 ),
                next_el   i),
          ize_    => f    l      Somet fs, true, cattrs, exics #   Mt: #(,
    form:   nly ha_serializeld_visitor = Stm       eld_visitor = Stmnext_el eld_visitor = Stmt_seq method. Thselfe_impl_gener _private::Ph)method. Thself, #mut_seq: __A) IELDS, #visitor_expr)
   ]
nt> {!("struct {    l    #ics #en() {
        None
    }ield_names_idents,
  lds
     ().unwrap_or(&expectiadj_foe_, pnly ha r_exprte_block! {
        #[doc(hidden)]
        struct __Visitor #de_impl_generics #where_clme(variaerics, where_clause) =
        split_with_de_lifetime(priy   known_me(deserihis_type iy   known_me(des use an `Into`   knownin the serdeDS, typ,his_pi # s.lo        ged(.cansitep ov_seq)) Intthose. Oams.witteis_pi # s.lo        ged(.fails on   knownikeys.ip fields that        serial   foiy   known_me(desetter {
        lett                     #vizeOrCe toe_nt> {        params.has_getter {
        lett                     #vizeCe toe_Oams.nt> {        params. Some(variaeagene_re toe_quoivate::Result<Self that        serir: &mut _serde:aiel#nly 
    let visitortainer#tortain,{
        let this_type = &para       _re toe_quoivate::Result<Sel                 _s    <{
                   }       le d(       _ that(#tortain)q = 0usize;
    lpara       _re toe__fDS,throughs_type;
   ;__seq)
  l      _re toe__arm  ::next_el#that were flattened,
        // so they don't (|(i, field)| next_el    next_el
        format!("{} with 1 ),
       |(i, f_         next_el   i),
          ize_    => f    l      Somet fs,,
          ize_    => f doe_quo&next_el. doe_s, true, cattrs, exarmtype_name(), var.stylself, __deserializerStylsrialit      },
    };

    quot")]
fn deserialize_newtype_struit_with_de!("struct {}", paf cattrs.has_flatt,f, __deserializerStylsriN) => ql   next_el
             #[inline]
        fn .ty, path);
                  ::Desernext_el
serde::de::SeqAccess::next_element::<#field_ty>uote!(try!(#func(&mut __seq)))
             #v       _ thattry!(_serde::de::SeqAccess::n};
            index_in_seq  try!#tortain)     uit_with_de!("struct {}", paf cattrs.has_flater_ty) = wrap_deserialize_field_with(par_.ty, path);
                     _re toe__fDS,throughs_type;
  _.ty,#       _re toe_try!(_serde::de::SeqAccs) => {
         

    let this_type = &params.this_type;
-> _serde::__private::Result<S]
nt> {!("struct {    l    #arm,fields, cattrs));

    le}ield_names_identsfi<eseria>(erics, _) !l      _re toe__arm             };

             _re toe_quoivate::Result<Selq: _lt: #t)a  let };

            le   l      _re toe__arm kenStream,
tterispatl      _re toe__fDS,throughen() {
        None
             deseIntAdvance s.lo forby ing(key,cs) =>     ear, pin.ca_geof e  le.ip fields__wrakeyquoivate::Result<Sel    _serde::__privisitor_se(__wrakeye.#member)))
 fo,l#nlyene_re toe_uote!(mut __seqsertlocaDS, t      knownin the ,his_wformtol  ansagmee_, pitep throughskeys
  #let_dekip_descerdeDbor))  nil_dekf    `nly`, `re toe_`,    run or))of keys.ip fields__wrarelevct {keyquo   foiy   known_me(desetter {
   __wrakeycs.in_place();
    let in_pla      } else {
      ))
rk :lement::<#wrapper_ty>(&mut<                     #vizeOrCe toe_nt> {>(quote!(
            l
         

    lewhilse                     _s       k) = #__wrakeyq      lifetime: _ser: #t)ak   };

    quot")]
fn deserialize_newtype_  #vizeCe toe_Oams.nt> {ty>ams.            }
                     ::__private::de::InPvisitor_se(__wrath_de!(<ate::de::InPIgnoredAn            w )                          re tin                        }, };

    quot")]
fn deserialize_newtype_  #vizeCe toe_Oams.nt> {tyTt r           }
                )
rk =                  _s                          #vizeOrCe toe_nt> {#vize)                          break;f cattrs.has_flater_ty) = wrap_deserialfn deserialize_newtype_  #vizeCe toe_Oams.nt> {tyCe toe_qu          }
                )
rk =                  _s                          #vizeOrCe toe_nt> {#vCe toe_try!(_serde::de::SeqAcc    break;f cattrs.has_flater_ty) = wrap_deserial}f, mut __map: __A) -> _serde)
rkrde::__private::PhantomDappetep throughsremai     keys, look    

  duplihises)of     iously-.#mnntomDappkeys.rtloca  knownin the serdefoiiyp,hanypkey ged(.is_dese duplihiseams: ate:a(f>ee_clau poie_qim'a syn:, pproduce tare  le.ip fields      remai    akeysquoivate::Result<Sel     _s__wrarelevct {keyq}

    quote! {
        #[inline]                          #vizeOrCe toe_nt> {#vize)qu          }
                         _s    <{
                   }       le d(duplihise_ that(#tt e_path, parrial}f, mut __map:                 _s                          #vizeOrCe toe_nt> {#vCe toe_tqu          }
                         _s    <{
                   }       le d(duplihise_ that(#re toe_uote!(m parrial}f, mut __map:                 _sting().ueserialize_newtype_str)
red_ttrs.expec}field_names = fieldnish_re toe__ locanlyn=l   next_el_arm             };

           let this_type =           _serde::__privisitor_se(__wrath_de!(<a
nt> {>:         w ) {;

    if params.has_getter {
        let this_type =    _  red::__priv          _serde::__privisitor_se(__wrath_de:         w ) {       }
        (f> {
         s.lobufferedare toe_it th   .fil kt th   f repres.;

            le   next_elearm kenStream,
tter else {
        (f>     sremai     keys, look    

  duplihises._A) -> _serde::__priremai    akeys{
        let this_typeield_rics #where_clause rext_ele        marker: _sp   => mes_id  #type_naserde::__private::PhantomData<#ttypee #ty_generics>,
            lifetime: _serde::as a
  a
nt> {,ime: _serde::__private::PhantomData<&#delife ()>,
        }

        impl #de_impl_generics _serde::de::Visitor<#delife> for __Visitor #de_ty_generics #where_clause {
            type Value = #this_tue = #this_type #ty_generics;

typee #tyxpecting(&self, __formatter: &mut _serde::__private::Formatter) -> _serde::__private::fmt::Resr>
                where
                    __D: _serde::Deserializer<#delife>,
                {
           _map
            }
     eserialize_map(__deserializer, self)
               lifetime: _ser: #tame
   let };

            le  le   next_elearm kenStream,
tterflatten() {
        None
     marker: _serde::__private::PhantomData<#this_type #ty_generics>,
            lifetime: _serde::__private::PhantomData<&#delife ()>,
        }

        impl #de_impl_generics _serde::de::Visitor<#delife> for __Visitor #de_ty_generics #where_clause {
            type Value = #this_type #ty_generics;

            fn expecting(&self, __formatter: &mut _serde::__private::Formatter) -> _serde::__private::fmt::Result {
                _serde::__private::Formatter::write_str(__formatter, #expecting)
            }

            #visit_newtype_struct

            #[inline]
            fn vA>(self, mut __map: __A) -> _serde           where
                __A: _serde::de::MapAccess<#delife>,
            {
                #visit_map
            }
        }

        #visitor_seed

        #fields_stmt

        #dispa(f>     s   ffirs srelevct  key.     lifetime: _ser: #ts__wrarelevct {keyq}

    quote!  #type_p(f>Firs skeyqisms.locag._private::None => {
                        #v                    #vizeOrCe toe_nt> {#vize)qu          }
         #type_p(f>Parsems.locag._private::None => {
 e =    _    let =     _serde::__privisitor_se(__wrath_de:         w );       }
         #type_p(f>     s   fsere d key.     lifetime: _stime: _ser: #ts__wrarelevct {keyq}

    quote!  #type_p #type_p(f>Sere d key is a duplihiseaofms.locag._private::None => {
 e =  {
                        #v                    #vizeOrCe toe_nt> {#vize)qu          }
         #type_p                         _s    <{
                   }       le d(duplihise_ that(#tt e_path, parrialtrs.has_flater_ty) = wrap_deserialfn d #type_p(f>Sere d key is s.lore toe_._private::None => {
 e =  {
                        #v                    #vizeOrCe toe_nt> {#vCe toe_tqu          }
        :None => {
 e =    _  red::__privserde::__privisitor_se(__wrath_dee.#member)))
 fo,       }
        :None => {
 e = 
     typee{       }
        :None => {
 e = 
   de::as a
  a
ft> {,ime: _serde::::::::::::::::::::::::::::::__private::PhantomData<&#delife ()>,
 ,ime: _serde::::::::::::::::::::::::::::::{
    Tuple,
    /// Contains a variant name
    Exter parrialtrs.has_flater_ty );       }
         #type_p        (f>     sremai     keys, look    

  duplihises._A) -> _serde

            le  le :__priremai    akeys{
       rialtrs.has_flater_ty) = wrap_deserialfn d #type_p(f>Tms.hais nofsere d key; mighir liokayl   s.loil  None,
ulit  repres.;

            le, mut __map:                 _sting().utl      _re toe_> {
                    let (wrapper, wrapper_ty) = wrap_deserialpe_p(f>Firs skeyqisms.lore toe_._private::None => {
                        #v                    #vizeOrCe toe_nt> {#vCe toe_tqu          }
        :None =>(f>Buffer up s.lore toe_._private::None => {
 e =    _  re toe_quo_private::de::InPvisitor_se(__wrath_de!(<ate::de:          l(
  Ce toe_>:         w );       }
         #type_p(f>     s   fsere d key.     lifetime: _stime: _ser: #ts__wrarelevct {keyq}

    quote!  #type_p #type_p(f>Sere d key is s.locag._private::None => {
 e =  {
                        #v                    #vizeOrCe toe_nt> {#vize)qu          }
         #type_p           _  _private::Ph(quote!(
            l(
  Ce toe_ {
        #fi<  A        d(_) (__re toe__#mA) -> _serde

            le  le ldnish_re toe__ locanlypath, parrialtrs.has_flater_ty) = wrap_deserialfn d #type_p(f>Sere d key is a duplihiseaofms.lore toe_._private::None => {
 e =  {
                        #v                    #vizeOrCe toe_nt> {#vCe toe_tqu          }
        :None => {
 e =                  _s    <{
                   }       le d(duplihise_ that(#re toe_uote!(m parrialtrs.has_flater_ty) = wrap_deserialfn d #type_p(f>Tms.hais nofsere d key.e_if_none
                            }
                        }
                    })
                  _s    <{
                   }       le d(       _ that(#tt e_path, parrialtrs.has_flater_ty) = wrap_deserialfn d #tyet (wrapper, wrapper_ty) = wrap_deserialpe_p(f>Tms.hais noffirs skey._private::None => {
                                    }
                                 _s    <{
                   }       le d(       _ that(#tt e_path, parrialtrs.has_y) = wrap_deserial}f, mut __map: __A) -> _serdeor>
          where
    ce_ty_gen__A: _serde::de::MapAccess<#delife>,
            {
                #visit_map
            }
        }

        #    })
        }
    };
    let mt

        #dispa(f>     s   ffirs sp) => { - s.locag._private::None =>          _serde::__private::Some(__wrap) => {                  self.place.#member                 _s        thattqu          }
        :None =>(f>     s   fsere d p) => { - s.lore toe_._private::None => {
 e =           _serde::__private::Some(__wrap) => {e.#mempath, parrialtrs.has_flater_t          name
    Exter parrialtrs.has_  typee{       }
        :None => {
 e = as a
  a
ft> {,ime: _serde::::::::::::::::::::::__private::PhantomData<&#delife ()>,
 ,ime: _serde::::::::::::::::::::::{
    Tuple,
    /// Contains a variant name
    Exter parrialtrs.has_}name
    Exter parrialtrs.       self.place.#member = __wrap.value;
                 red_().ueserialize_newtype_str)
red_ttrs.expecdeserialfn d #type_p(f>Tms.hais nofsere d p) => {.e_if_none
                            }
                        }
                    })
                  _s           }       let<__th_id_length(1,      e_path, parrialtrs.has_flater_ty) = wrap_deserialfn d #tyet (wrapper, wrapper_ty) = wrap_deserialpe_p(f>Tms.hais noffirs sp) => {.e_if_none
                                              }
                                 _s           }       let<__th_id_length(0,      e_path, parrialtrs.has_}nStream,
tterflatten() {
        None
     marker: _serde::__private::Phanttor_expr = quote! {
        __Visitor {
  #nly aire toe_serde::__pre_block! {
        #field_visitor
tForm::orm,
   }
     _private::PhantomData::<#this_type #ty_generics>,
s.has_fy_generics>,
                lifetime: _serde::__private::PhantomData,
            },
        )
    }
}

enum TupleForm<'a> {
    Tuple,
    /// Contains a variant name
    ExternallyTagged(&'a syn::Iner,
    form:   nly ha_r_ex orm,
) -> Fragment {
    let t represeagmeInterna
    let   }
}

#[rhis_type;
    
    let (de_impl_gerialfirs _    mp_quo
         tor {
        nly ha_r_ex_afeser       pnext_el#,t     } pfirs _    mp_)n::Iner,
    form:   nly ha_r_ex_afeserorm,
) -> Fragment {
    let t represeagmeInterna
    let   }
}

#[rhis_type;
    erdefirs _    mp_ &paramu
 #de>  
    let (de_impl_gerial    mp_  ::next_el#that were flattened,
     |(i, fienext_el   next_el
        format!("{} with 1 ),
            next_el        lifetime #def,
    form:   nly ha_serializeld_visitor = Stm       eld_visitor = Stmnext_el eld_visitor = Stmt_seq method. Thselfe_impl_gener _private::Ph)method. Thself, 
am,
tter else {
rial    mp_  ::firs _    mp_.__E>_ ing() che;
(    mp_ else {
(f>TODO_clau mSomieldcin tr libthis_vby sav    s.loe  lesmryFro   ffail,
    f(f>ee  mp_ atch fheuris_Visuspeeby TOML wa   S)cinn s   f_exbs_vofzed or that (f>pro:Sompeebefore tare  le,ruct the s.loe  leh   .fheriante:afese s.lthat (f>lal;
_ex_exbs_vofzed or . I'm  #[me(re Iplike    .. May li  swin tr lthat (f>bthis_v S)sNone,ll s.loe  lesmuct comb;
  s.lxpin S)    mSomieldprivate:a(f>explwill why    faofms.lo represen     ed.ip fields DS,through_msp_or(&expect
am,
tter"tata did  #[m      anyp performoft only havr_exprte_
or = Stm      {
        #[  // s;ip fields DS,through_msp_orruct __Visitor #de_impl_generi DS,through_msp_clause ield_rics #where_clause   _  re toe_quo_priv<ate::de:          l(
  Ce toe_           } {
        >field_visitorer _private::Ph))
            _  _private::Ph(quote!(
            l(
  Ce toe_Ref {
        #fi<           d(_) (&__re toe__#mut_seq: _#zeld_visitor =le(#deseserialize_newtype_str)
ok) = #    mp_        lifetime: _ss) => {eserialize_newtype_str)
ok);en() {
        None
   )*

                         _s           }       let<cusari(# DS,through_msp_(&'a syn::Iner,
    form: r FIELDS, _nly ha_serializeld_v) -> Fragment {
    let t represerdeext_el eld_vt   }
}

#[rhis_type;
    
    let (de_impl_gele(#deserialally)s::next_el
             #[inline]
 here_clause   _(pl_gp    pl_gp      p  pl_gefn)s::pl_ge       #[inlnext_eleine]
       pnext_el,ially);         s) => {ield_rics #where_clauseq: _#pl_gp  place")]
fn deserialize_newtype_elife> __seq)),
             ote!(
      ternallyTagged(_) => quote! {
    pl_gp     >zer) => qu) ai  pl_gefn) None
             deseize_    => f doe_quo&next_el. doe_s, truee_name(), var.stylself, __deseStylsrialit          _serde::Deserlause) =
        split_with_de_lifetselfe_impl_gerics #where_clauseq: _<Sel    _serde::__priternallyTagged(uliteserializer) => qu );       }
        eserialize_newtype_struit_with_de!("struct {}", paf cattrs.has_     _serde::de::VariaylsriN) => ql).u,
    form: e FIELDS, _nly ha__) => quote! {
q)),
         _ident)
      
isitor = Stm       eld_visitor =&next_el.ed or [0] 
    let visit_seq method. Thariant_ident,ylsriTuplql).u,
    form: tuplq(
isitor = Stm       eld_visitor =&next_el.ed or  
    let visit_seq method. ThhhhhTuplq        | StructForm::Untagged(varianmethod. Thariant_ident,ylsri          eld_visitor
tForm::orm,
   }
          eld_visitor =&next_el.ed or  
    let visit_seq method. Thhhhht, _)
        | StructForm::Untagged(varianmethod. Thariant_yn::I(f>G    ));s significform   taofms.lo _expr = quct  match forbodies)of        s
 y_mapas.lo represenof inFIELDS, pnly ha r_ex.Iner,
    form: inFIELDS, _nly ha_serializeld_v) -> Fragment {
    let t represerdeext_el eld_vt   }
}

#[rhis_type;
        tor {
     :__rams.borrowe 
    let (de_impl_gele(next_el
             #[inline]
     (&mut            s) => {,
    form:   nly ha_serializ       pnext_el,it_seq msitor_expr)
           deseize_    => f doe_quo&next_el. doe_s, truee_nameeffitorvr
tFyls(seriali) lf, __deseStylsrialit          _serde::Deserlause) =
        split_with_de_lifetselfe_imariaerics, where      {
        #[;),
          ize_    => fshou   next_el. doe_.E>_itock!#[;),
          ize_defa      next_el.ed or .get(0) {
          ere_clauseq: _<Selize_defa       #def> qu__wi         that,t     } else {
        e_impl_gene    fa   uote!(m parrial})_lifetselfe_impl_gerics #where_clauseq: _<Sel    _serde::_ {
        #field_visitor

        #[doc(hiddote!(
            l(
  (#deserializer, alit       ::_) (#n) if cattr"struct { cat) );       }
        eserialize_newtype_struit_with_de!("struct {}", p    fa   uf cattrs.has_     _serde::de::VariaylsriN) => ql).u,
    form:   nly ha__) => quote! {
q)),
         _ident)
      
isitor = Stm       eld_visitor =&next_el.ed or [0] 
    let visi&_private::PhantomData:ariant_ident,ylsri          eld_visitor
tForm::orm,
   }
          eld_visitor =&next_el.ed or  
    let visit_seq method. Thhhhht, _)
      (#deserializer, #_ident)
       _private::Ph)method. Thariant_ident,ylsriTuplql).uunrroch_uot!("l
fn desin seriae  rrvr
inFIELDSs" ,    field: &Field,
) -> T  nly ha_serializeld_v) -> Fragment {
    let t represerdeext_el eld_vt   }
}

#[rhis_type;
        tor {
     :__rams.borrowe 
    let (de_impl_gele(#deserialally)s::next_el
             #[inline]
 here_clause   _  pl_gefns::  pl_geE>__ident)
cloe(rez       pnext_el,i DSse);         s) => {ield_rics #where_clauseq: _eserialize_newtype_elife> __seq#ally      #[doc(hi) ai  pl_gefn) None
             deseize_    => f doe_quo&next_el. doe_s, truee_nameeffitorvr
tFyls(seriali) lf, __deseStylsrialit          _serde::Deserlause) =
        split_with_de_lifetselfe_imariaerics, where      {
        #[;),
          ize_    => fshou   next_el. doe_.E>_itock!#[;),
          ize_defa      next_el.ed or .get(0) {
          ere_clauseq: _<Selize_defa       #def> qu__wi         that,t     } else {
        e_impl_gene    fa   uote!(m parrial})_lifetselfe_impl_ger> qu!q      lifetime: _ser: #t)te::de: {
        #field_visitor

   orm,
   }
   auseq: _#_private::PhantomData::<#trialfn deserialize_newtype_  #valizer, alit       ::_) (#n) if cattr"struct { cat)ntomData::<#trial)   };

    quot")]
fn deserialize_newtype_str())d).ueserialize_newtype_struit_with_de!("struct {}", p    fa   uantomData::<#trialfn deserialize_newtype_    }s: &)(q>deserialize_newtype_    }s: &),nStream,
tterflatten() {
        None
     :de::VariaylsriN) => ql).u,
    form:   nly ha__) => quote! {
q)),
         _ident)
      
isitor = Stm       eld_visitor =&next_el.ed or [0] 
    let visi&_private::PhantomData:ariant_ident,ylsriTuplql).u,
    form: tuplq(
isitor = Stm       eld_visitor =&next_el.ed or  
    let visit_seq method. ThhhhhTuplq      alizer, #_ident)
       _private::Ph)method. Thariant_ident,ylsri          eld_visitor
tForm::orm,
   }
          eld_visitor =&next_el.ed or  
    let visit_seq method. Thhhhht, _)
      alizer, #_ident)
       _private::Ph)method. Thariant_yn::Iner,
    form: r FIELDS, _nly ha__) => quote! {
q)),
 attr::Container&eserialize: Option<TokenStream>,
) -> Option<FenSnt> {,ime: t   }
}

#[rhis_type;
    
    let (de_impl_gerialause)e) =
        split_with_de_lpl_gele(= 1 {
        format!("{} with 1here_clause   _defa       #def> qu__wi         that,t     } else {
    s) => {ield_rics #where_clauseq: _    _serde::__priternallyTagged(uliteserializer) => qu );       }
    eserialize_newtype_struit_with_de!("struct {}", p    fa   uote!(m par          deseer: #t= 1 {
             #[inline]
 here_clause                }
    elds that erial= 1 {
ty;),
          ize_::Deser= 1 {
serde::de::SeqAccess::next_el#field_ty>se {
        e_impl_getry!(#func(&mut __seq)))
    ternallyTagged(_) => quote! {
     that er>)_lifetselfe_impl_ger> qu!q      lifetime: _seserialize_newtype_elife> __seq# try!er) => qu) aiit_with_de!("struct {}", paf cattrs.has_     _serde::de::Varirialally)s:        _serde::Dese(pl_gp    pl_gp     )s::pl_ge       #[inl that ine]
       p= 1 {
ty,ially);         e_impl_gerics #where_clauseq: _<Sel#pl_gp  place")]
fn dfn deserialize_newtype_elife> __seq)),
                 ote!(
      ternallyTagged(_) => quote! {
    pl_gp     >zer) => qu) )),
                 |__pl_gp  |aiit_with_de!("struct {}", p(__pl_gp  .th_de)af cattrs.has_     _serde::de:ield: &Field,
) -> T  nly ha__) => quote! {
q)),
 attr::Container&eserialize: Option<TokenStream>,
) -> Option<FenSnt> {,ime: tor {
     :__&rams.borrowe 
    let (de_impl_geere_clause) =
        split_with_de_lifetime( that erial= 1 {
ty;),
  er: #t= 1 {
             #[inline]
 here_clause                }
    elds::Deser= 1 {
serde::de::SeqAccess::next_el#field_ty>mpl_getry!(#func(&mut _   that er           } {
        >field_visitor)_lifetselfe_impl_ger> qu!q      lifetime: _seserialize_newtype_elife> __seq# try!     #[doc(hi) aiit_with_de!("struct {}", paf cattrs.has_     _serde::de::Varirialally)s:        _serde::pl_gerics #where_clauseq: _<Sel   _  th_de!de::de::MapAccess<#delife>,  that er, ializ#ally      #[doc(hi);     lifetime: _seserialize_newtype_elife> __seq  th_de aiit_with_de!("struct {}", paf cattrs.has_     _serde::de:ield: &Field,
) -> T
    ));

    // untagged ion<Fragme(Stock!, alize:deserStock!>)
    let   }
}

#[rhis_type;
    erde_withepreserbool  erdeoams.forx &paramu
us   >e 
    let (de_impl_geere_clause) =
   pl_gener Fthattry!(_sime( that n't be ddeserializ&.attrs.deseria      _,        D   }", pas_idents,
  lds
     (ignore_next_el,i DS,through)n=l   !_withepres &&e_          .iter()
               qugnore_next_el   pl_gener oams. ote!(
            l(
  Ce toe_<'de>),)
            _fDS,throughs_type;
  _serialize_newtype_str)
nt> {#vr oams. o_th_de)a)
         (irialugnore_next_el)
     N DS,through))eld_count, #vis#deserialoams.forx)n=loams.forxl             qugnore_next_el   ed or [oams.forx].1s_   let
            _fDS,throughs_type;
  _serialize_newtype_str)
nt> {#v#ugnore_next_el))
         (    
     N DS,through))eld_count, #vis_withepres ||ihis_type iy   known_me(des ul          (    
     )Deserializer::deserialize_ugnore_next_el   pl_gener ugnore,)
            _fDS,throughs_type;
  _serialize_newtype_str)
nt> {#vr ugnorea)
         (irialugnore_next_el)
     N DS,through))eld_colifetime: _serde::_ {
  false,
        None,    // untagged strucclause) =
 )),
     ed or  
    let _withepres )),
     eDS,through,re_clause    ,re_clause!_withepres &&e_          .iter()
 ,re_clause    ,re_cl1 ;_lds
     {
    Tun=l   !_withepres &&e_          .iter()
            -> _serde::(<'de>))Deserializer::deserial    let this_typeield_rics #where_clause [DS, t(non_cam>l_ca_g     svate::Phantserde::__private::Phantr_exp)
nt> { #{
    Tun       #type_pa   that n't be,kenStream,
tter#ugnore_next_el None
     marker: _serde::__private::PhantomData<#tnt> {       ;ere_clause {
 <'de>lue = #this_type #ty_'de>l

    nt> {        r: &mut _serde::__private::)
nt> { #{
    Tu;__A) -> _serde::__pr::_ {
 nerics #where_clause {
 <'de>lue = #th {
        _'de>l

    nt> { #{
    Tun       #type_pa:Value, __A::Error>
    r>
              e
                    __D: _serde::Deserializer<#delif             {
           _map
            }
     eserialize_map(__deseria'de>   };
    let mt

        #dispa)te::de: {
        #field_visitor
    // unta  _private::Pha   nt> {       af cattrs.has_     _serde::de:ield:(f>G    ));s ` {
        field_visitor`rbodyl

  anri_expine]:(f>`

   ( that n't b/ unt)`    `

   (struct {}", p/ unt)`     ibute.Iner,
    form: cusari,    // untagged ) -> Fragment {
    let t represeagmeInterna
    let   }
}

#[rhis_type;
    
    let (de_impl_gerial_withepres =elt: #this_typ    // untanerics = _serde::_I   // unt  ternalls:       ethod. Thrde::_I   // unt  nt> { :   DSse ethod. Thrde::_I   // unt  Nol).uunrroch_uot!(ariant_y Some(variaes, de_ty_geerics, ty_generi.E>_tams.
tForow  ;__seq)
  clause) =
       split_with_de.E>_tams.
tForow  ;_lds
     (orde::ry,i DS,through,i DS,through_ocal typ)n=l   #deseriallast)s::next_el#tlast
               qlastf doe_quo&last. doe_s,isitor =le(#ast.      oams. 1        #type_p(f>Pro:Som `

   (oams.)`     ibute. I swin tralwaysr lifound on s.lthat  #type_p(f>#astp perform(l
fn desin `l
fn ,    // unt`)
 soe,ll precedck! {
   #type_p(f>erdeorde::ry:next_el#tcess::next_el#fieorde::ry:iz&next_el#[..next_el#tl()
  - 1]ccess::next_el#fielDS,throughs_type;
  _serialize_newtype_striit_with_de!("lastf doe_ );       }
    (orde::ry,i    N DS,through)
     )Deserld_count, #vis#deseaylsriN) => ql)(#ast.stylself, __deserial#fieorde::ry:iz&next_el#[..next_el#tl()
  - 1]ccess::next_el#fielDS,throughs_t|th_de  ere_clauseq: _<Sel  },
    };

    quot")]
fn deserialize_newtype_elife> __seq)),
                 ispa)te::de: {
        field_visitoree_if_none
                            }
        (
  (   // unt {
        #firyFr  ne_de)ame
    Exter parrialtrs. ttrs.expecdeserialfn d #tyiit_with_de!("lastf doe_      

    let this_type = &params.this_type;
ee_if_none
       orde::ry,f, __deserializerS   N DS,through(pl_gener th_de)a),f, __deserializerS   N DS,through(pl_gener        }
        (
  Bcal typq)),
                 o th_dentomData::<#trial))a),f, __deserial)Deserld_count, #i),
           next_el#,t    
     )Deserserde::de:iunt, #i),
       next_el#,t    
     )Desery Some(variashouldn't be deserializorde::rythat were flattened,
          next_el        lifetime      field.attrs.next_el
                 )
        })
        .collect();next_el. doe_._   letield_visitor = Stmnext_el
      ze_generated_identifier(
        &field_names_idents,
  lds
     shouls::(mut __seq)
  ing() {
   ( cattrIELD    cat   ome(variashouldtor_ex=l    DS,through    (&mut                let thunt, #vis_withepres ::deserialize_    => squoivate::Result<Selq: _a   })
    };

    let visitor_exVARIANTquote! {
        __Visitor {
      (mut r: _serde::__pri;         -> _s    => s)Deserializer::deserialize_me(deseriivate::Result<Selq: _a   })
    };

    let visitor_expr = quote! {
        __Visitor {
      (mut r: _serde::__pri;         -> _sme(des)Desery Some(variaparams);
    let delife = params.borrowed.de_lifetime();

    // If there are getters (implying private fields), construct the local type
    // and useetime: _serde::_ {
  false,
        None,    // untagged strucclause) =
 )),
     &(mut __seq)
get a visi_withepres )),
     eDS,through,re_clause DS,through_ocal typ,re_clause DSse ethod. Thruct __Visitor #de,re_cl1 ;_lds
 ield_rics #where_clause shouldtor_e marker: _serde::__private::PhantomData<#tnt> {       e #ty_generics>,
            lifetime: _serde::__private::PhantomData<&#delife ()>,
        }

        impl #de_impl_generics _serde::de::Visitor<#delife> for __Visitor #de_ty_generics #where_clause {
            type Value = #this_type #ty_generics;

    nt> {       e #tyxpecting(&self, __formatter: &mut _serde::__private::Formatter) -> _serde::__private::fmt::::__pr::_ {
 nerics #where_clause   _  t      e=   nt> {        r: &mut _serdeerde::__private::PhantomData,
            },
        )
    }
}

enum TupleForm<{
    Tuple,
    /// Contains a variant name
    E}erde::__pre_block! {
        #field_visitor
    // unta  _private::Pha   v      af catyn::Iner,
    form: i   // untagged it_with_de!_&rams.borrowe ged ion<Fragme(Stock!, alize:deserStock!>)
    le_withepreserbool  erde DS,through &paramu
rams.borrow>  erde DS,through_ocal typ &paramu
rams.borrow>  erde_idents oams._ion<Fragbool  erdeVisitor # &paramu
d| !>e 
    let (de_impl_geere_    .ite_me(deseriese::_) (useetim

   _,        ze_gene)sin me(desetter {
   .ite_me(des.r FInd(ze_gene  ing() {
   ze_ge| (ze_ge,      )a)
     }
y!(_sime( that s }
}

eserializ&.ite_me(des. ing() {
   ( cattrI    cat s_idents,
  !(_sime( that byte
}

eserializ&.ite_me(desthat were flattened,
          ( cattrI   Lflatal::byte_itock!# cat.as byte
())field_names_idents,
  lds
     tor_eDataor
}

eserializ&.ite_me(desthat were flattened,
          (_,         pl_geneiit_with_de!("     )aield_names_idents,
  l_geere_ ain_tor_eDataor
}

eserializ&.e(desthat were flattened,
          (_,      trI   pl_geneiit_with_de!("     )aield_names_idents,
  c(hidden)]
        st]
       _impl_genervis_withepres ::deserial"thepres i   // unt"Deserializer::deserial"  let i   // unt"Deseri
  c(hidden)    l_]
        stvis_withepres :l"thepres"rializer:l"  let"ry Some(variabyte
_E>_itox=l    DS,through    (&mut  ||ihidents oams._ion<Fr               let thunt, #          -> _serde::et this_type =    _  e) =
    atter, #expecting)
 yFr_utf8_lossyer th_de);rde::__private::PhantomDariap
or = Stmne_deeames_e_re toe_,
or = Stmne_deeameocal types_e_re toe_,
or = Stmne_deeameoyte
_re toe_,
or = Stmne_deeameocal typeoyte
_re toe_,
or =)n=l   hidents oams._ion<Fr           (s.this_type;
-> _serde::__private::Result<S   _  e) =
   ote!(
            l(
  Ce toe_ri   ck!#ote!(
            lTo   ck!::E>_itock!#r th_de)a;en() {
       ated_identifier-> _serde::__private::Result<S   _  e) =
   ote!(
            l(
  Ce toe_ri   er th_de);rde::__pr     ated_identifier-> _serde::__private::Result<S   _  e) =
   ote!(
            l(
  Ce toe_riByteBufer th_de.E>_vec());rde::__pr     ated_identifier-> _serde::__private::Result<S   _  e) =
   ote!(
            l(
  Ce toe_riByteser th_de);rde::__pr     ated_identi)Deserializer::deserial(    
     ,t    
     )Desery Some(varia DS,through_arm_tams.s;ome(varia DS,through_armn=l   #deserial DS,through)n=li DS,throughetter {
   .DS,throughen() hunt, #vis_withepres ::deserial DS,through_arm_tams.seriivate::Result<Selq: _                 _s           }       let<  known_serializer) _de aVARIANTquote!(m par           & DS,through_arm_tams.sDeserializer::deserial DS,through_arm_tams.seriivate::Result<Selq: _                 _s           }       let<  known_ that(er) _de apr = quote!(m par           & DS,through_arm_tams.sDeseri Some(variau64_ DS,through_arm_tams.s;ome(variau64_ DS,through_armn=l   #deserial DS,through)n=li DS,throughetter {
   .DS,throughen() hunt, #{            _fDS,through_msp_or(&expect"{})    l 0 <=l  <prte_b    l_]
       ,zed or .l()
 );rde::__pru64_ DS,through_arm_tams.seriivate::Result<Selq: _                 _s           }       let<__th_id_th_de:)),
             ote!(
      Un]
    yp  Unsignet(er) _detield_visitor = Stm&# DS,through_mspmethod. Thself, 
am,
tter           &u64_ DS,through_arm_tams.seld_colifetime: _struct {   iculs::0_u64..seetime: _serde oams.n=l   hidents oams._ion<Fr           ivate::Result<Selq: _or>
     bool<__E    where
th_de!_bool_serde::de::MapAccess<#delife>,
            {
E {
           _map
            }
     E:        }       le   };
    let mt

        #dispa)te::de:ze_newtype_str)
nt> {#vr oams. ote!(
            l(
  Ce toe_riBooler th_de)a)f, mut __map: __A) -> _serdeor>
     i8<__E    where
th_de!_i8_serde::de::MapAccess<#delife>,
            {
E {
           _map
            }
     E:        }       le   };
    let mt

        #dispa)te::de:ze_newtype_str)
nt> {#vr oams. ote!(
            l(
  Ce toe_riI8er th_de)a)f, mut __map: __A) -> _serdeor>
     i16<__E    where
th_de!_i16_serde::de::MapAccess<#delife>,
            {
E {
           _map
            }
     E:        }       le   };
    let mt

        #dispa)te::de:ze_newtype_str)
nt> {#vr oams. ote!(
            l(
  Ce toe_riI16er th_de)a)f, mut __map: __A) -> _serdeor>
     i32<__E    where
th_de!_i32_serde::de::MapAccess<#delife>,
            {
E {
           _map
            }
     E:        }       le   };
    let mt

        #dispa)te::de:ze_newtype_str)
nt> {#vr oams. ote!(
            l(
  Ce toe_riI32er th_de)a)f, mut __map: __A) -> _serdeor>
     i64<__E    where
th_de!_i64_serde::de::MapAccess<#delife>,
            {
E {
           _map
            }
     E:        }       le   };
    let mt

        #dispa)te::de:ze_newtype_str)
nt> {#vr oams. ote!(
            l(
  Ce toe_riI64er th_de)a)f, mut __map: __A) -> _serdeor>
     u8<__E    where
th_de!_u8_serde::de::MapAccess<#delife>,
            {
E {
           _map
            }
     E:        }       le   };
    let mt

        #dispa)te::de:ze_newtype_str)
nt> {#vr oams. ote!(
            l(
  Ce toe_riU8er th_de)a)f, mut __map: __A) -> _serdeor>
     u16<__E    where
th_de!_u16_serde::de::MapAccess<#delife>,
            {
E {
           _map
            }
     E:        }       le   };
    let mt

        #dispa)te::de:ze_newtype_str)
nt> {#vr oams. ote!(
            l(
  Ce toe_riU16er th_de)a)f, mut __map: __A) -> _serdeor>
     u32<__E    where
th_de!_u32_serde::de::MapAccess<#delife>,
            {
E {
           _map
            }
     E:        }       le   };
    let mt

        #dispa)te::de:ze_newtype_str)
nt> {#vr oams. ote!(
            l(
  Ce toe_riU32er th_de)a)f, mut __map: __A) -> _serdeor>
     u64<__E    where
th_de!_u64_serde::de::MapAccess<#delife>,
            {
E {
           _map
            }
     E:        }       le   };
    let mt

        #dispa)te::de:ze_newtype_str)
nt> {#vr oams. ote!(
            l(
  Ce toe_riU64er th_de)a)f, mut __map: __A) -> _serdeor>
     f32<__E    where
th_de!_f32_serde::de::MapAccess<#delife>,
            {
E {
           _map
            }
     E:        }       le   };
    let mt

        #dispa)te::de:ze_newtype_str)
nt> {#vr oams. ote!(
            l(
  Ce toe_riF32er th_de)a)f, mut __map: __A) -> _serdeor>
     f64<__E    where
th_de!_f64_serde::de::MapAccess<#delife>,
            {
E {
           _map
            }
     E:        }       le   };
    let mt

        #dispa)te::de:ze_newtype_str)
nt> {#vr oams. ote!(
            l(
  Ce toe_riF64er th_de)a)f, mut __map: __A) -> _serdeor>
     char<__E    where
th_de!_char_serde::de::MapAccess<#delife>,
            {
E {
           _map
            }
     E:        }       le   };
    let mt

        #dispa)te::de:ze_newtype_str)
nt> {#vr oams. ote!(
            l(
  Ce toe_riCharer th_de)a)f, mut __map: __A) -> _serdeor>
     unit<__E    wh_serde::de::MapAccess<#delife>,
            {
E {
           _map
            }
     E:        }       le   };
    let mt

        #dispa)te::de:ze_newtype_str)
nt> {#vr oams. ote!(
            l(
  Ce toe_riUnit)af cattrs.has_     _serde::de:ihas_getter {
        let this_type = or>
     u64<__E    where
th_de!_u64_serde::de::MapAccess<#delife>,
            {
E {
           _map
            }
     E:        }       le   };
    let mt

        #dispaer: #t)ae) =
 };

            le  le  trs.expecdeserialfn d #tyistruct {   iculs:.ueserialize_newtype_stru ain_tor_eDataor
 ttrs.expecdeserialfn dkenStream,
tterflat
    ().utu64_ DS,through_arm,nStream,
tterflatten() {
        None
     :de:olifetime: _serdeeocal typx=l    DS,througheocal typ    (&mut  ||ihidents oams._ion<Fr              _fDS,through_ocal typearmn=l DS,througheocal typ as_refde_impl_gener DS,through_arm);         -> _serde::et this_type = or>
     boal types_e<__E    where
th_de!_&'detomD_serde::de::MapAccess<#delife>,
            {
E {
           _map
            }
     E:        }       le   };
    let mt

        #dispaer: #t)ae) =
 };

            le  le  trs.expecdeserialfn d #tyi that s }
s:.ueserialize_newtype_strutor_eDataor
 ttrs.expecdeserialfn dkenStream,
tterflat
    ().u{trs.expecdeserialfn d #tyist_deeameocal types_e_re toe_trs.expecdeserialfn d #tyi DS,through_ocal typearmpath, parrialtrs.has_y) = wrap_deserial}f, mut __map: __A) -> _serdeor>
     ocal typeoyte
<__E    where
th_de!_&'det[u8]_serde::de::MapAccess<#delife>,
            {
E {
           _map
            }
     E:        }       le   };
    let mt

        #dispaer: #t)ae) =
 };

            le  le  trs.expecdeserialfn d #tyi that oyte
s:.ueserialize_newtype_strutor_eDataor
 ttrs.expecdeserialfn dkenStream,
tterflat
    ().u{trs.expecdeserialfn d #tyibyte
_E>_itotrs.expecdeserialfn d #tyist_deeameocal typeoyte
_re toe_trs.expecdeserialfn d #tyi DS,through_ocal typearmpath, parrialtrs.has_y) = wrap_deserial}f, mut __map: _de::__private::Palizer::deserial    let this_typeield_rics #where_clauseResult {
                _serde::__private::Formatter::write_str(__formatter, #expecting)
            }

           sit_newtype_struct

            #[inline]
            fn vA>(self, mut __  marker: _sserde oams.

> _serdeor>
     s_e<__E    where
th_de!_&omD_serde::de::MapAccess<#delife>,
            {
E {
       _map
            }  E:        }       le   };
    t this_type =       )ae) =
 };

            le  trs.expecdeserialfn di that s }
s:.ueserialize_newtype_strutor_eDataor
 ttrs.expecdeserialkenStream,
tterflat ().u{trs.expecdeserialfn d#ne_deeames_e_re toe_
xpecdeserialfn d #tyi DS,through_armpath, parrialtrs.ten() {
        None
     marker: _or>
     oyte
<__E    where
th_de!_&[u8]_serde::de::MapAccess<#delife>,
            {
E {
       _map
            }  E:        }       le   };
    t this_type =       )ae) =
 };

            le  trs.expecdeserialfn di that oyte
s:.ueserialize_newtype_strutor_eDataor
 ttrs.expecdeserialkenStream,
tterflat ().u{trs.expecdeserialfn d#byte
_E>_itotrs.expecdeserialfn d#ne_deeameoyte
_re toe_
xpecdeserialfn d #tyi DS,through_armpath, parrialtrs.ten() {
        None
     marker: _#
     ocal typf catyn::Iner,
    form: _seq)),
 _eData_ally!_&rams.borrowe ged on<TokenStream>,
) -> Option<Fragment> {
    let   }
}

#[rhis_type;
    
    let (de_impl_ge// Crrotes   ffilet shoulsmapas.loed or . !(_sime( thats   })e deserializ.e(desthat were flattened,
     i_ex  ));tened,
          (i,zed or)|   that,t that n(i))field_names_idents,
  lds
 // Declerderochffilet    .fwillr li,
    form:d.ip fieldseldae) =
sliz.e(des   })ethat were flattened,
     |(i, fie&&  that,tI   != 1 {
        format!("{} with 1h&& != 1 {
      .iter()
 ened,
          ( that,t cat |         }
    elds that erial= 1 {
ty;),
          erde::__private::Result<S   __pri shouple,
    /// Containsparamu
  that er>   ote!(
            l
         t __map: _de::__priv  lds
 // Cidentsore toe_lsmapa.iter() me(desein S)a bufferip fieldselda_identsn=l   h          .iter()
            -> _serde::         }
    elds      _identsn=lote!(
            lese::<e,
    /// Containsparamu
(t

        #dispa)te::de:ze_newtype_(
  Ce toe_,t

        #dispa)te::de:ze_newtype_(
  Ce toe_ethod. Thself,>>::_) (useetim__private::Palizer::deserial    let this_type// M     arm   S)extratsnamne_del

  al= 1 {
fetime: _st_deearm  iz.e(des   })ethat were flattened,
     |(i, fie&&  that,tI   != 1 {
        format!("{} with 1h&& != 1 {
      .iter()
 ened,
          ( that,t cat |         }
    eldsmat!(fshou   = 1 {
                 )
        })
 _private::fmt::e: _serde =elt: #t= 1 {
             #[inline]
 here_clausee_clause                }
      }
    elds that erial= 1 {
ty;),
            }
    elds::Deser= 1 {
serde::de::SeqAccess::next_el:next_el#field_ty>trs.expecdeserialfn d #typl_getry!(#func(&mut __seq)))
    visitor_se(__wrath_de!(<  that er>)_lifetselfe_imq: _<Sel  },
    };

    quot")]
fn dged i   _# try!         w )path, parrialtrs.has_y) = wrap_deserial}f, mut __map::Varirialally)s:        _serde:::next_el#fie(pl_gp    pl_gp     )s::pl_ge       #[inl that ine]
       p= 1 {
ty,ially);         e_imq: _<Sel  },
 ({trs.expecdeserialfn d #tyipl_gp  place")]
fn dfn d_type =       )seq)))
    visitor_se(__wrath_de!(< pl_gp     >z         w      self.place.#member = __wrap.value;
          str)
pl_gp  )(q>de_pl_gp  .th_de,   self.place.#member = __wrap.value;
              }s: &)(q>d        }
                    })
 s) => {eserialize_newtype_    }s: &);path, parrialtrs.has_flater_ty) = wrap_deserialfn d #tyet (wrapper, wrapper_ty      

    let this_type = &params.this_type;
  },
    };

    quot")]
)
nt> {#v#shou  >d        }
               e,
    /// Containsparamu::   (&mut&#shou      self.place.#member = _s) => {eserialize_newtype_    <{
                   }       le d(duplihise_ that(#mat!(fshou );       }
         #tyet (wrapper, wrapper_t#shou  ap.value;
               #
    );       }
        }     t __map: _de::__priv  lds
 //      sugnored e) =
sl S)cinsex  s.lxc(hidden) gnored_armn=l   h          .iter()
            -> _serde::         }
    )
nt> {#vr oams. o_shou   >d        }
          _idents.push(p.value;
               q)),
                 o pe #ty_generics>,
fn dged i   _)seq)))
    visitor_se(__wrath_de!         w )) );       }
     _de::__private::Palizer   h      e iy   known_me(des ul              let thunt, #          -> _serde::et this_type =  ().u{S   _ quo_private::de::InPvisitor_se(__wrath_de!(<ate::de:(
  (gnoredAny>:         w );  _de::__private::Plifetime: _DS,_  fopypx=lme(des. ing() DS,         = 1 {
        format!("{} with 1
  l_geere_ a   akeysn=l   h      e iy   known_me(des ul&& DS,_  fopypxtter {
        let this_type = (f>FIXME: Oncel
rot(rezexhausorvr
p     ne)sis _e_uot:that  #type_p(f>#deseserialize_newtype_    fi<  nt> {>quo_private::de::InPvisitor_se(__wrakey:         w );       }
    e,
    /// Containsparamu::_seq)),
             _private::de::InPvisitor_se(__wrakeyfi<  nt> {>:         w )ty_generics>,
fn d|__ {
ossiuot|       )a {
ossiuot {})_lifetselfe::de:ihas_getter {
        let this_type = whiot #deseserialize_newtype_       key)quo_private::de::InPvisitor_se(__wrakeyfi<  nt> {>:         w ) mt

        #dispaer: #t)akeyq}

    quote!  #type_p#(#st_deearm kenStream,
tterflat
   # gnored_armnStream,
tterflatten() {
        None
     :de:olifetime: _extratsae) =
sliz.e(des   })ethat were flattened,
     |(i, fie&&  that,tI   != 1 {
        format!("{} with 1h&& != 1 {
      .iter()
 ened,
          ( that,t cat |         }
    elds       _> qulizM    f> qu__wi         that,t     } els),
          erde::__private::Result<S   _#shou  aer: #t#shou     self.place.#member                 _s     #shou   >d#pe #ty_generics>,
fn dged                            #       _> qunStream,
tterflatt      t __map: _de::__priv  lds
 e: _extratsa_identsypx=lme(des   })ethat were flattened,
     |(i, fie&&  that,tI   = 1 {
      .iter()
 h&& != 1 {
        format!("{} with 1 ),
            ( that,t cat |         }
    elds that erial= 1 {
ty;),
          #field_ty>mlt: #t= 1 {
             #[inline]
 here_clausee_clause                }
      }
    elds::Deser= 1 {
serde::de::SeqAccess::next_el:next_elpl_getry!(#func(&mut __seq)))
     {
        field_visitor)) = wrap_deserial}f, mut __map::Varirialally)s:  pl_geneially),s_type = &params.this_type;
  },
    };

    quot")]
   _#shou: # that eriali   _# try!ntomData::<#trialfn deserialize_newtype_  #vFitevis {
        # trs.expecdeserialfn d #ty&      _idents,       }
                                 _s a variant ) );       }
     _de::__priv  lds
     todentsyp_e iy   known_me(desn=l   h          .iter()
  &&e_      e iy   known_me(des ul          -> _serde::et this_type = le(#deseserialize_newtype_      .value;
               q)akey,tI ))y>trs.expecdeserial  _idents.__E>_ ing() |(i, fie,
    /// Containsparamu::   (&mu).__wr()  };
    let mt

        #dispale(#deseserialize_newtype_       key)quo  key.ames_e(      self.place.#members) => {eserialize_newtype_           }
                               let<cusari(      _args!("  knownffilet `{}`", &  key) );       }
        ount, #i),
          .#members) => {eserialize_newtype_           }
                               let<cusari(      _args!("  ]
    yp  forkey") );       }
        of, mut __map: _de::__private::Palizer::deserial    let this_type#desr      =lme(des   })e. ing() {
   ( that,t cat |         }
elds exbs_viz&.e(de. exbs_s,isitor =le(= 1 {
        format!("{} with 1here_clauseetime: _st_de    #def> qu__wi         that,t     } else {
        pl_genei exbs_:  ne_de)ame
    Eount, #i),
          pl_genei exbs_:   cat)ntomData:}Deseri
  c(hidden)eldadefa      lt: #this_typdefa   anerics = _serde::_Defa   :_Defa   s:  -> _serde::( this_type =    _  defa   : 
            ap.value;
          Defa   :_defa   anlse {
     )ty_genericrde::_Defa   :_Pae]
  ly)s:  -> _serde::( this_type =    _  defa   : 
            a#ally nlse {
     )ty_genericrde::_Defa   :_                }
    (f>We don't needas.lodefa    ) _de a S)prevoe_  n unuspeestrucuot warnck! {
   #type_p(f>we'll   Nones.lolue,  mp_ytcess::next_el    let t
     :de:olifetime: _    r      =lpl_genei_eData_allyu{S#(#r     r: _})_lifetle(t the l    gthis_v        }
eldses, de_ty_ge&erics, ty_generi
            _(_, rrowed.de_lif_)ruct the lwed.de_l.e are f::_ {
 (else {
    s)     =lpl_gen }

           sit_newtype_struct
I_E>    },
        )
    }
}

et<__to(#r     rte!(m par          deseield_rics #where_clause (#eldae) =
s)*

        #elda_idents

        # a   akeys

        #eldadefa   mut_seq: _#z#extratsae) =
s)*

        #z#extratsatodentsyp)*

        #todentsyp_e iy   known_me(des

                         _sstrur     rte!(myn::I#[cf   rot(re =l",
    form: in_place")]Iner,
    form: _eData_ames_eata_in_place v      ( ged on<TokenStream>,
) -> Option<Fragment> {
    let   }
}

#[rhis_type;
    
    (let (de_, let (de_, let (de_nerics =as   t!(!h          .iter()
 
  c(hidden) that shouldn't be deserializ.e(desthat were flattened,
     i_ex  ));tened,
     |(i, fie&(_, ed or)| != 1 {
        format!("{} with 1 ),
            (i,zed or)|       lifetime      field.attrs.= 1 {
                 )
        })
 ,     field.attrs.= 1 { n(i),     field.attrs.= 1 {
      ze_generated_identifier(
        &field_names_idents,
  lds
     me(des stm  =l::deserialize_me(de_shouls:: that shouldn't be  ing() {
   ( cattrIELD    cat   :next_elpl_getics #where_clauseq: _#   })
    };

    let visitor_expr = quote! {
        __Visitor {
       that shoulr: _serde::__priDesery Some(varia that t      e= ield,
) -> T
    ));

    // unta& that shouldn't be,it_seq ms DSse      )lifetime: _serdee for=r,
    form: _se_in_place
       p= 1 {e,it_seq )lifetim( that t      , me(des stm ,_serdee fo)n::I#[cf   rot(re =l",
    form: in_place")]Iner,
    form: _se_in_place
 ged on<TokenStream>,
) -> Option<Fragment> {
    let   }
}

#[rhis_type;
    
    let (de_impl_geas   t!(!h          .iter()
 
  c(hid// Crrotes   ffilet shoulsmapas.loed or . !(_sime( thats   })e deserializ.e(desthat were flattened,
     i_ex  ));tened,
          (i,zed or)|   that,t that n(i))field_names_idents,
  lds
 // Fapa,
    form: in_placedeliclerdebooleanlsmaparochffilet    .fwillr llds
 // ,
    form:d.ip fieldselda.itgsliz.e(des   })ethat were flattened,
     |(i, fie&&  that,tI   != 1 {
        format!("{} with 1ened,
          (_,  cat |         }
    erde::__private::Result<S   __pri shouplbooln=l DSs       t __map: _de::__priv  lds
 // M     arm   S)extratsnamne_del

  al= 1 {
fetime: _st_deearm _ yFrliz.e(des   })ethat were flattened,
     |(i, fie&&  that,tI   != 1 {
        format!("{} with 1ened,
          ( that,t cat |         }
    eldsmat!(fshou   = 1 {
                 )
        })
 _pte::Result<S   __exbs_viz&.e(de. exbs_s,rivate::fmt::e: _serde =elt: #t= 1 {
             #[inline]
 here_clausee_clause                }
      }
      },
    };

    quot")]
fn dged i   _ate::de::InPvisitor_se(__wrath_deateed:         wddote!(
            l(
  (#PlaceSeed:       wh.place.i exbs_) )path, parrialtrs.has_y) = wrap_deserial}f, mut __map::Varirialally)s:        _serde:::next_el#fie(pl_gp    pl_gp     )s::pl_ge       #[inl that ine]
       p= 1 {
ty,ially);         e_imq: _<Sel  },
 ({trs.expecdeserialfn d #tyipl_gp  place")]
fn dfn d_typ),
 _ wh.place.i exbs_ =elt: #t)seq)))
    visitor_se(__wrath_de!(< pl_gp     >z         w      self.place.#member = __wrap.value;
          str)
pl_gp  )(q>de_pl_gp  .th_de,   self.place.#member = __wrap.value;
              }s: &)(q>d        }
                    })
 s) => {eserialize_newtype_    }s: &);path, parrialtrs.has_flater_ty) = wrap_deserialfn d #tye;t (wrapper, wrapper_ty      

    let this_type = &params.this_type;
  },
    };

    quot")]
)
nt> {#v#shou  >d        }
               #shou     self.place.#member = _s) => {eserialize_newtype_    <{
                   }       le d(duplihise_ that(#mat!(fshou );       }
         #tyet (wrapper, wrapper_t#serde;t (wrapper, wrapper_t#shou  a    ;       }
        }     t __map: _de::__priv  lds
 //      sugnored e) =
sl S)cinsex  s.lxc(hidden) gnored_armn=l   h      e iy   known_me(des ul              let thunt, #          -> _serde::et this_type =  ().u{S   _ quo_private::de::InPvisitor_se(__wrath_de!(<ate::de:(
  (gnoredAny>:         w );  _de::__private::Plifetime: _DS,_  fopypx=lme(des. ing() DS,         = 1 {
        format!("{} with 1
   l_geere_ a   akeysn=l   h      e iy   known_me(des ul&& DS,_  fopypxtter {
        let this_type = (f>FIXME: Oncel
rot(rezexhausorvr
p     ne)sis _e_uot:that  #type_p(f>#deseserialize_newtype_    fi<  nt> {>quo_private::de::InPvisitor_se(__wrakey:         w );       }
    e,
    /// Containsparamu::_seq)),
             _private::de::InPvisitor_se(__wrakeyfi<  nt> {>:         w )ty_generics>,
fn d|__ {
ossiuot|       )a {
ossiuot {})_lifetselfe::de:ihas_getter {
        let this_type = whiot #deseserialize_newtype_       key)quo_private::de::InPvisitor_se(__wrakeyfi<  nt> {>:         w ) mt

        #dispaer: #t)akeyq}

    quote!  #type_p#(#st_deearm _ yFrkenStream,
tterflat
   # gnored_armnStream,
tterflatten() {
        None
     :de:olifetime: _l
fn ,.itgsliz.e(des   })ethat were flattened,
     |(i, fie&&  that,tI   != 1 {
        format!("{} with 1ened,
          ( that,t cat |         }
    elds       _> quliz> qu__wi         that,t     } ;that  #type_p(f>Ifs       _> quluncindiramuDS, _s) => s anri  le  don't trythat werepe_p(f> S)assign itsmne_del S)_ wh.place. this_type = le(= 1 {
        fa   an    n  leteld_visitor = Stm&&this_typdefa   an    n  leteld_visitor = Stm&&t= 1 {
             #[inline]
     (&mut   };
    let mt

        #dispaelds       _> qulizlse,
        _> quelse {
        e_impl_gend        }
               !#shou     self.place.#member = _#       _> qu;path, parrialtrs.has_y) = wrap_deserial}f, mut __map: unt, #i),
          .#meelds exbs_viz&.e(de. exbs_s,isitor =  #dispaelds       _> quliz #def       _> quelse {
        e_impl_gend        }
               !#shou     self.place.#member = __ wh.place.i exbs_ =e#       _> qu;path, parrialtrs.has_y;       }
        }     t __map: _de::__priv  lds
 eldses, de_ty_ge&erics, ty_generi
        _(_, _, rrowed.de_lif_)ruce are getters (implying private c(hidden)eldadefa      lt: #this_typdefa   anerics = _serde::_Defa   :_Defa   s:  -> _serde::( this_type =    _  defa   :  },
        )
    }
}

  ap.value;
          Defa   :_defa   anlse {
     )ty_genericrde::_Defa   :_Pae]
  ly)s:  -> _serde::( this_type =    _  defa   :  },
        )
    }
}

  a#ally nlse {
     )ty_genericrde::_Defa   :_                }
    (f>We don't needas.lodefa    ) _de a S)prevoe_  n unuspeestrucuot warnck! {
   #type_p(f>we'll   Nones.lolue,  mp_ytcess::next_el    let t
     :de:olifetimield_rics #where_clause (#elda.itgs)*

        # a   akeys

        #eldadefa   mut_seq: _#z#l
fn ,.itgs)*

        p.value;
          str 1ened,
yn::Iner that n(i: us   
    alizehere_clalize::_) (&(&expect"__me(derte_b )
  pau::cDS,_ i);te)eld:(f/ T,
 eld_tramu:pl_gses.lo> qur_samu:in `#[

   (       #[inline] =l"...")]`:(f/ in a tra  s S)prevoe_   s yFrlator_s    s.loinFIELDS ` {
        ` _e_te.Inerpl_ge       #[inline]
gged ) -> Fragment {
    let t r_deety!_&rams.borrowe ged        #[inline]er&eseri #dePae]  
    (rams.borrowe rams.borrow)impl_geere_clause_ty_ge&erics, ty_generi
        _(arams);
    let delife = params.borrowed.de_lifetime();

    // If there are getters (implying private fields), construct the local type
    // and use fields),pl_gp   =lpl_gen }

       serde::__private::PhantomData<#t {
        Wne]  #ty_generics>,
            lifetime: _serde::th_de!_# r_deetyty_generics>,
pa variate::PhantomData<&#delife ()>,
        }

        impl #de_impl_generics _serde::de::Visitor<#delife> for __Visitor #de_ty_generics #where_clause {
            type Value = #th {
        _generics;

     {
        Wne]  #tyxpecting(&self, __formatter: &mut _serde   r>
              e
                    __D: _serde::Deserializer<#delif             {
           _map
            }
     eserialize_map(__deseriagenerics   };
    let mt

        #dispa)te::de:ze_newtype_str)
 {
        Wne]     self.place.#memberth_de!_i   _#       #[inline]
e
            ) ttrs.expecdeserialfn dpa variate::PhantomData<&#delife ()>,
 ttrs.expecdeserialfn d{
    Tuple,
    /// Contains a variant name
    Erapper_ty      

    le  None
     :de:olifetime: _pl_gp        pl_gener  {
        Wne]  #tyxpecting(&s)lifetim(pl_gp    pl_gp     )n::Inerpl_ge       #[inl that ine]
 ged on<TokenStream>,
) -> Option<Fety!_&eseriT

 e ged        #[inline]er&eseri #dePae]  
    (rams.borrowe rams.borrow)impl_gepl_ge       #[inline]
       p&pl_geneiion<Fety),        #[inline])n::Inerpl_ge       #[inlstruct {ine]
gged ) -> Fragment {
    let t represer&Vhepres )),
        #[inline]er&eseri #dePae]  
    (rams.borrowe rams.borrowe rams.borrow)impl_geere_ion<Fetyss::next_el.me(des. ing() {
          = 1 {
ty)
        _(pl_gp    pl_gp     )s:{
       _l_ge       #[inline]
       p&pl_gene(#eiion<Fetylr: )),        #[inline]) Some(variaumpl_gefeserumpl_geE>_vtruct {clos(rez       pnext_el,i    )lifetim(pl_gp    pl_gp     ,aumpl_gefe)eld:(f>G    ));s clos(re    .fcinvertsms   lloinput ) -> {
  s S)s.loedLDS th_de.Inerumpl_geE>_vtruct {clos(rezgged ) -> Fragment {
    let t represer&Vhepres )),
 gettepl_gp  agbool  
    rams.borrowimpl_geere_clause) =
   &    split_with_de;fetime: _struct { doe_quo&next_el. doe_hantomDariaparg  pl_gp  )n=l   gettepl_gp  r::deserial(pl_gen }de_pl_g }, pl_gen }de_pl_g.th_derivate::Palizer::deserialere_ion<Fetyss::next_el.me(des. ing() {
          = 1 {
ty)
     rial(pl_gen }de_pl_g: (#eiion<Fetylr: ) }, pl_gen }de_pl_grivate::Plifetime: _ion<Feator_ss::(0..next_el.ed or .l()
 ) {
   n|         }
Mexbs_::Unshoud(I   l t this_type = l   l: n    u32name
    Erapp(&mu:  pau::cDS,_ i);te,_de::__private::P)lifetimlt: #tnext_el.stylself, __deseeaylsriSmData<   next_el.ed or .l()
  == 1            }
    elds exbs_viz&next_el.ed or [0]. exbs_s,isitor =  #dpl_gend        }
        |#arg|yiit_with_de!("struct { doe_q{ i exbs_:  pl_gp  rten() {
        None
     :de:deseeaylsriSmData<           }
    elds exbs_ss::next_el.me(des. ing() {
          &.e(de. exbs_)s,isitor =  #dpl_gend        }
        |#arg|yiit_with_de!("struct { doe_q{ iei exbs_s:  pl_gp  .#ion<Feator_sr: _}en() {
        None
     :de:deseeaylsriTuples:  pl_gend        }
    |#arg|yiit_with_de!("struct { doe_(#eipl_gp  .#ion<Feator_sr: (
        &, :de:deseeaylsriN) => ql)  pl_gend        }
    |#arg|yiit_with_de!("struct { doe_(#pl_gp  )
        &, :de:deseeaylsriUnitl)  pl_gend        }
    |#arg|yiit_with_de!("struct { doe_
        &, :de:yn::Iner> qu__wi         thater&Fthat,t     }}

#[rhis_type;
  
    let (de_impl_gelt: #t= 1 {
        fa   anerics = _serde::_Defa   :_Defa   s:          }
    elds::Deser= 1 {
serde::de::SeqAccess::next_el#field_ty>mpl_getry!(#func(&mut __seq)))

          Defa   :_defa   Access::next_els) => {pl_get> qu _# try!))_lifetselfe::de:ericrde::_Defa   :_Pae]
  ly)s:  {cess::next_els) => {pl_get> qu _#ally n)_lifetselfe::de:ericrde::_Defa   :_          /* below */de::de:iepl_gelt: #t*his_typdefa   anerics = _serde::_Defa   :_Defa   s|crde::_Defa   :_Pae]
_)            }
    elds exbs_viz&.e(de. exbs_s,isitor =  #ds) => {pl_get> qu _  defa   .i exbs_)_lifetselfe::de:ericrde::_Defa   :_          /* below */de::de:iepl_geariashou   = 1 {
                 )
        })
 _pte::lt: #t= 1 {
             #[inline]
 here_clause                }
    elds::Deser= 1 {
serde::de::SeqAccess::next_el#field_ty>mpl_getry!(#func(&mut __seq)))

          )))
       _ed or)s,isitor =  #dpl_get> qu d        }
        i   _# try!  cat))en() {
        None
     :de:desee     )            }
    pl_get> qu d        }
        s) => {eserialize_newtype_    <{
                   }       le d(       _ed or!  cat))en() {
        None
     :de:yn::Iner>ffvA>(v: _eyls( represer&Vhepres
    Stylself, __lt: #tnext_el.stylself, __deseeaylsriN) => ql   next_el.ed or [0].        format!("{} with 1h=>eeaylsriUnit, :de:deseoams.n=>eoams., :de:yn::IomData<DeImplGting(&s<'a>(&'a ment {
   )s,#[cf   rot(re =l",
    form: in_place")]IomData<(#PlaceImplGting(&s<'a>(&'a ment {
   )s,
    <'a> raTams.se

  DeImplGting(&s<'a>elf, __nerE>_tams.s        tams.s::__prirams.borrow)impl_gelt<S   __pri   }
}

  a_ wh.0lwed.de_l._   lets,isitor =le(#deserial
    // and)  a_ wh.0local type
    // and_    s
 here_clausee_clwed.de_l.    splizlrialeseriGting(&ment ::L // and 
    // and)teld_visitor = Stm.__E>_ ing()eld_visitor = Stm.che;
(wed.de_l.    sp)eld_visitor = Stm.cidents,
  l_ge      None
   ariapms);
    let de_if_)rucwed.de_l.e are f::_ {
 (else {
    ms);
    let .E>_tams.s tams.s)
     }
::I#[cf   rot(re =l",
    form: in_place")]I    <'a> raTams.se

  (#PlaceImplGting(&s<'a>elf, __nerE>_tams.s        tams.s::__prirams.borrow)impl_gelt<S   _place   // andructlace   // and(else {
       __pri   }
}

  a_ wh.0lwed.de_l._   lets,
 #type_p(f>Addd{
    Tue

  `&'tlace__prielif  and `'a: 'tlace`marker: _o
      s in &_pri   }
}

.    splt this_type =           s         }
        eseriGting(&ment ::L // and     s)(q>d        }
                slocunes.push(tlace   // and.  // and._   let);       }
        of, mut __map:    eseriGting(&ment ::T

      s)(q>d        }
                slocunes.push(eseriT

 ment Bcune::L // and    self.place.#member = _tlace   // and.  // and._   letttrs.expecdeserialfn dk);       }
        of, mut __map:    eseriGting(&ment ::Cor_e  )     }en() {
        None
     :de:desewed.de_l.    splizlrialeseriGting(&ment ::L // and tlace   // and)teld_visitor =.__E>_ ing()eld_visitor =.che;
(wed.de_l.    sp)eld_visitor =.cidents,
  l_ge    le(#deserial
    // and)  a_ wh.0local type
    // and_    s
 here_clausee_clwed.de_l.    splizlrialeseriGting(&ment ::L // and 
    // and)teld_visitor = Stm.__E>_ ing()eld_visitor = Stm.che;
(wed.de_l.    sp)eld_visitor = Stm.cidents,
  l_ge      None
   ariapms);
    let de_if_)rucwed.de_l.e are f::_ {
 (else {
    ms);
    let .E>_tams.s tams.s)
     }
::I#[cf   rot(re =l",
    form: in_place")]I    <'a> DeImplGting(&s<'a>elf, __nerin_place
  wh_serd(#PlaceImplGting(&s<'a>elf, __e_cla#PlaceImplGting(&s(_ wh.0) :de:yn::IomData<DeT

 Gting(&s<'a>(&'a ment {
   )s,#[cf   rot(re =l",
    form: in_place")]IomData<(#PlaceT

 Gting(&s<'a>(&'a ment {
   )s,Iner,
 }

 
    let _E>_tams.s f, __lpri   }
}

: eseriGting(&  let tocal typ &&Bcal typL // and  let ttams.s::__prirams.borrow  
 {lifetle(ocal type
    // and_    s
     (&mut  mpl_gelt<S   _def  a_seriL // andP   s         }
        }}
ese::_) (ue_impl_generics _serde::_seriL // and::_) ("'de"
  pau::cDS,_ i);te),
    let visito   _tams.:t    

    let visiocunes: Pd_trua yp  _) (ue_impl_geny;       }
(f>Prepend 'det{
    Tuetot{
st ofi   }
}


ausee_clwed.de_l.    splizlrialeseriGting(&ment ::L // and 
 f)teld_visitor =.__E>_ ing()eld_visitor =.che;
(wed.de_l.    sp)eld_visitor =.cidents,
  l_ge}
       _(_, rrowed.de_lif_)rucwed.de_l.e are f::_ {
 (else {
rrowed.de_l.E>_tams.s tams.s)
 },
    <'a> raTams.se

  DeT

 Gting(&s<'a>elf, __nerE>_tams.s        tams.s::__prirams.borrow)impl_gelt<S,
 }

 
    let _E>_tams.s _ wh.0lwed.de_l._   let, &_ wh.0local typ  tams.s)
     }
::I#[cf   rot(re =l",
    form: in_place")]I    <'a> raTams.se

  (#PlaceT

 Gting(&s<'a>elf, __nerE>_tams.s        tams.s::__prirams.borrow)impl_gelt<S   __pri   }
}

  a_ wh.0lwed.de_l._   lets,isitor =wed.de_l.    splizlrialeseriGting(&ment ::L // and tlace   // and())teld_visitor =.__E>_ ing()eld_visitor =.che;
(wed.de_l.    sp)eld_visitor =.cidents,
  pl_gelt<S,
 }

 
    let _E>_tams.s wed.de_lif&_ wh.0local typ  tams.s)
     }
::I#[cf   rot(re =l",
    form: in_place")]I    <'a> DeT

 Gting(&s<'a>elf, __nerin_place
  wh_serd(#PlaceT

 Gting(&s<'a>elf, __e_cla#PlaceT

 Gting(&s(_ wh.0) :de:yn::I#[cf   rot(re =l",
    form: in_place")]Inertlace   // and()serd_seriL // andP   s       _seriL // andP   s         }
    }}
ese::_) (ue_impl_gens _serde::_seriL // and::_) ("'place"
  pau::cDS,_ i);te),
    let to   _tams.:t    

    let ocunes: Pd_trua yp  _) (ue_implyn::Inere are getters (implyinggged ) -> Fragment {
    l
    (gged DeImplGting(&s,gged DeT

 Gting(&s,     _seriT

 Gting(&s,     paramu
&eseriWmap
Crmatt>  
 {lifet   _de       type Val= DeImplGting(&sg private fields), c_)
    }
}

  aDeT

 Gting(&sg private fields),(_, rrowed.de_lifetime();

    /ct the l