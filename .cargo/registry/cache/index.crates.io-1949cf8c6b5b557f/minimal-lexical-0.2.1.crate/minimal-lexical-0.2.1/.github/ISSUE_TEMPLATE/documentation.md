---
name: Documentation
about: Update the project's documentation.
title: "[DOC]"
labels: documentation
assignees: Alexhuszagh

---

## Description
Please include a clear and concise description of the issue.

Ex: Documentation for `parse_float` contains a typo.

## Additional Context
Add any other context or screenshots about the issue here.
