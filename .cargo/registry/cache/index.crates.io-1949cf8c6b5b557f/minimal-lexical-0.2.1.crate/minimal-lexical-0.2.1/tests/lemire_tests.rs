//! These tests are adapted from the Rust core library's unittests.

#![cfg(not(feature = "compact"))]

use minimal_lexical::lemire;
use minimal_lexical::num::Float;

fn compute_error             0000 ire;17:nimal_lexical\x00006"qoatet fp = bellerophon::<f32>(& minimal_lexicalp.mant)
}

pub fn compute_float64(q: i32, w 0000 ire;17:nimal_lexical\x00006"qoatet fp = bellerophon::<f32>(& minimal_lexical_sxiced::num::Float;

fn, lzm::Fl compute_float64(q: i32, w 0000 ire;17:nimal_lexical_sxiced\x00006"qoat, lzet fp = bellerophon::<f32>(& minimal_lexical_sxicedp.mant)
}

pub fn, lzm::Fl compute_float64(q: i32, w 0000 ire;17:nimal_lexical_sxiced\x00006"qoat, lzet fp = bellerophon::<f32>(& minimal_le yfp);
    }
}

pub fn compute_float32(q: i32, w 0000 ire;17:nimal_le"\x00\x00006"qoatet fp = bellerophon::<f32>(& minimal_lexp, fp.mant)
}

pub fn compute_float64(q: i32, w 0000 ire;17:nimal_le"\x00\x00006"qoatet fp = bellerophon::<f32>(&72200000000000), (1xical::}

#[test]
fn compute_float_f32_test() {
    // These test near-halfway cases for single-precision xical::n    assert_eq!(c167772170000000000),
        206232721, -(0, 9007199254740996), (107xical::n    assert_eq!(compute_float32(0, 16777217), (111 + f32::INVALID_FP, 922337258661058xical::n    assert8eq!(compute_float32(0, 16777219), 136366est:84INVALID_FP, 922337258661058xical::n    assert_eq!(compute_float32(0, 16777219), (111 + f32::INVALID_FP, 922337368612221xical::n    assert_eq!(compute_float32(0, 16777219),42315620 13600, 18014398509481992), (1077, 2));

    // These are examples of the above tests, with
    // digits from the exponent shifted t0), (1076, 1));
 xical::n    assert_eq!(compute_float32(-10, 167772170000000000),
        206232721, -(NVALID_FP, 9223372036850), (1076, 1));
 xical::n    assert_e   compute_float32(-10, 167772170000000000),
        (111 + f32::INVALID_FP, 9223372586610), (1076, 1));
 xical::n    assert_e8  compute_float32(-10, 167772190000000000),
        136366est:84INVALID_FP, 92180000000000), (151, 1));
    // Let's check the lines to see if anything is different in table...
 xical::n    assert_e   compute_float32(-10, 167772190000000000),
        (111 + f32::INVALID_FP, 922337368612ent in table...
 xical::n    assert_eq!(compute_float32(-10, 167772190000000000),
       42315620 13600467440737095516150\x00nimal_lexicalp.}

#[test]
fn compute_float_f64_test() {
    // These test near-halfway cases for double-precision xicalp.m    assert_eq!(compute_fl07199254740995000),
        (1065 + f1, -(0, 9007199254740996), (107xical);
    assert_eq!(compute_float64(0, 9007199254740993), (1065 + f64::INVALID_FP, 922337203685477xical);
    assert_eq!(com4ute_float64(0, 9007199254740993), (1065 + fhon_INVALID_FP, 922337203685477xical);
    assert_eq!(compute_float64(0, 9007199254740995), (1065 + f64::INVALID_FP, 922337203685477xical);
    assert_eq!(com6ute_float64(0, 9007199254740995), (1065 + fhon_)D_FP, 922337368612ent in table...
 xical);
    assert_eq!(compute_float64(0, 18014398509481990),
        (1066 + f1, -(NVALID_FP, 9223372036850), (1076, 1));
 xicalsert_eq!(
        compute_float64(0, 18014398509481986),
        (1066 + f64::INVALID_FP, 9223372036850), (1076, 1));
 xicalsert_eq!(
        comp8te_float64(0, 18014398509481986),
        (1066 + fhon_INVALID_FP, 9223372036850), (1076, 1));
 xicalsert_eq!(
        compute_float64(0, 18014398509481990),
        (1066 + f64::INVALID_FP, 9223372036850), (1076, 1));
 xicalsert_eq!(
        comp2te_float64(0, 18014398509481990),
        (1066 + fhon_)NVALID_F]
fn compoat_a muchfalse,hese ---- (1077, .FP, 9223372036850), (1076, 1));
 xicalsert_e assert_eq!(com1te_float64(0, 18446744073709551608,25073858507200642956-(NVALID_FP, 9223372036850), (1076, 1));
 xicalsert_e      (1066 + f64:1te_float64(0, 7at64(0, 9007199254740993), (1065 + f64:0(NVALID_FP, 9223372036850), (1076, 1));
 xicalsert_e      (1066 + f64:2te_float64(0, 7at64(0, 9007199254740993), (1065 + f64:2(NVALID_FP, 9223372036850), (1076, 1));
 xicalsert_e      (1066 + f64:3te_float64(0, 7at64(0, 9007199254740993), (1065 + f64:2(NVALID_FP, 9223372036850), (1076, 1));
 xicalser-n_te9123456727292927te_float64(0t_e446744073709551608,25302
  2563531497894(NVALID_FP, 9223372036850), (1076, 1));
 xicalser-n3te91234567272929275te_float64(0t_e446744073709551608,25302
  2563531498606(NVALID_FP, 9223372036850), (1076, 1));
 xicalser-n_te9123456727292928te_float64(0t_e446744073709551608,25302
  2563531499320)NVALID_F]
fn comp9481992), (1077, 2));

    // These are examples of the above tests, with
    // digits from the exponent shifted t0), (1076, 1));
 xicala.
    assert_eq!(compute_float64(-3, 9007199254740995000),
        (1065 + f1, -(NVALID_FP, 9223372036850), (1076, 1));
 xicalsert_eq!(
        compute_float64(-3, 9007199254740993000),
        (1065 + f64::INVALID_FP, 9223372036850), (1076, 1));
 xicalsert_eq!(
        comp4te_float64(-3, 9007199254740993000),
        (1065 + fhon_INVALID_FP, 9223372036850), (1076, 1));
 xicalsert_eq!(
        compute_float64(-3, 9007199254740995000),
        (1065 + f64::INVALID_FP, 9223372036850), (1076, 1));
 xicalser    assert_eq!(compute_float64(-3, 9007199254740995000),
        (1065 + fhon_)NVALID_F]
fn compoat_ as i3icalsto satofxponent shifted t0), (1076, 1));
 xicala.
  1e14       f641393410a4eoat64(-3, 9012199254740995000),
         (111 + f32:0)NVALID_F]
fn com0359962dge-    // as i neviousi3icalsxponent shifted t0), (1076, 1));
 xicala.
  287402erophon_test::<f64eoat64(-3, -18446744073709551608,2507385850720064 fals0467440737095516150\x00nimal_lexical_sxiced::}

#[test]
fn compute_fats do noam), (1077, 2  // , jse tue-comp             xiced      s.
]
fn compute_float_f32_test() {
    // These test near-halfway cases for single-pr0), (1076, 1));
 xical_sxiced::n00142,1(11    27387on_te39float32(-10, 167772170000000000),
        206232721, -(NVALID_FP, 9223372036850), (1076, 1));
 xical_sxiced::n00142,1(112933052:<f68te39float32(-10, 167772170000000000),
        (111 + f32::INVALID_FP, 9223372586610), (1076, 1));
 xical_sxiced::n00142,1(1156-14::  fest:39float32(-10, 167772170000000000),
        136366est:84INVALID_FP, 9223372586610), (1076, 1));
 xical_sxiced::n00142,1(1184302,108  (t:39float32(-10, 167772170000000000),
        (111 + f32::INVALID_FP, 922337368612ent in table...
 xical_sxiced::n00142,1(171::<f6476880t:39float32(-10, 167772170000000000),
       42315620 1360046744073FP, 922337368612ent in table...
 xical_sxiced::n    a0328229206232721, -346float32(-10, 167772170000000000),
        206232721, -(NVALID_FP, 9223372036850), (1076, 1));
 xical_sxiced::n    a0328229(111 + f32::346float32(-10, 167772170000000000),
        (111 + f32::INVALID_FP, 9223372586610), (1076, 1));
 xical_sxiced::n    a032822 136366est:84346float32(-10, 167772170000000000),
        136366est:84INVALID_FP, 9223372586610), (1076, 1));
 xical_sxiced::n    a032822 (111 + f32::346float32(-10, 167772170000000000),
        (111 + f32::INVALID_FP, 922337368612ent in table...
 xical_sxiced::n    a03282242315620 1360346float32(-10, 167772170000000000),
       42315620 13600467440737095516150\x00nimal_lexical_sxicedp.}

#[test]
fn compute_fats do noam), (1077, 2  // , jse tue-comp             xiced      s.
]
fn compute_float_f32_test() {
    // These test near-halfway cases for double-prent in table...
 xical_sxicedsert_e42,1(11    27387on_te1_float64(-3, 9007199254740995000),
        (1065 + f1, -(NVALID_FP, 9223372036850), (1076, 1));
 xical_sxicedsert_e42,1(11    27388416te1_float64(-3, 9007199254740995000),
        (1065 + f64::INVALID_FP, 9223372036850), (1076, 1));
 xical_sxicedsert_e42,1(11    27388928te1_float64(-3, 9007199254740995000),
        (1065 + fhon_INVALID_FP, 9223372036850), (1076, 1));
 xical_sxicedsert_e42,1(11    27389, // 1_float64(-3, 9007199254740995000),
        (1065 + f64::INVALID_FP, 9223372036850), (1076, 1));
 xical_sxicedsert_e42,1(11    27389952/ 1_float64(-3, 9007199254740995000),
        (1065 + fhon_)NVALID_Fs for double-prent in table...
 xical_sxicedsert_e42,1(11    27387on_te9te_float64(0, 18014398509481990),
        (1066 + f1, -(NVALID_FP, 9223372036850), (1076, 1));
 xical_sxicedsert_e42,1(11    27388416te9te_float64(0, 18014398509481986),
        (1066 + f64::INVALID_FP, 9223372036850), (1076, 1));
 xical_sxicedsert_e42,1(11    27388928te9te_float64(0, 18014398509481986),
        (1066 + fhon_INVALID_FP, 9223372036850), (1076, 1));
 xical_sxicedsert_e42,1(11    27389, // 9te_float64(0, 18014398509481990),
        (1066 + f64::INVALID_FP, 9223372036850), (1076, 1));
 xical_sxicedsert_e42,1(11    27389952/ 9te_float64(0, 18014398509481990),
        (1066 + fhon_)NVALID_F]
fn compoat_a muchfalse,hese ---- (1077, .FP, 9223372036850), (1076, 1));
 xical_sxicedsert_e      (1066 + f47843411te_float64(0, 18446744073709551608,25073858507200642956-(NVALID_FP, 9223372036850), (1076, 1));
 xical_sxicedsert_e42,1(11    27388415, -3e_float64(0, 7at64(0, 9007199254740993), (1065 + f64:0(NVALID_FP, 9223372036850), (1076, 1));
 xical_sxicedsert_e42,1(11    27388416te0te_float64(0, 7at64(0, 9007199254740993), (1065 + f64:2(NVALID_FP, 9223372036850), (1076, 1));
 xical_sxicedsert_e42,1(11    27388416te0te_float64(0, 7at64(0, 9007199254740993), (1065 + f64:2(NVALID_FP, 9223372036850), (1076, 1));
 xical_sxicedser-n_te65337562817657489,7/ 1_float64(-3, t_e446744073709551608,25302
  2563531497894(NVALID_FP, 9223372036850), (1076, 1));
 xical_sxicedser-n3te6533756281765749303te7te_float64(0t_e446744073709551608,25302
  2563531498606(NVALID_FP, 9223372036850), (1076, 1));
 xical_sxicedser-n_te6533756281765749660/ 1_float64(-3, t_e446744073709551608,25302
  2563531499320)NVALID_F]
fn comp9481992), (1077, 2));

    // These are examples of the above tests, with
    // digits from the exponent shifted t0), (1076, 1));
 xical_sxicedser-3 a0328229206232721, -341float64(-3, 9007199254740995000),
        (1065 + f1, -(NVALID_FP, 9223372036850), (1076, 1));
 xical_sxicedser-3 a032822920623272  tru41float64(-3, 9007199254740995000),
        (1065 + f64:2(NVALID_FP, 9223372036850), (1076, 1));
 xical_sxicedser-3        (1066 + fhon_u41float64(-3, 9007199254740995000),
        (1065 + fhon_INVALID_FP, 9223372036850), (1076, 1));
 xical_sxicedser-3        (1066 + f fals41float64(-3, 9007199254740995000),
        (1065 + f64::INVALID_FP, 9223372036850), (1076, 1));
 xical_sxicedser-3        (1066 + fhon_te1float64(-3, 9007199254740995000),
        (1065 + fhon_)NVALID_F]
fn compoat_ as i3icalsto satofxponent shifted t0), (1076, 1));
 xical_sxicedser- 1e1       (111 + f32:0_e44eoat64(-3, 9012199254740995000),
         (111 + f32:0)NVALID_F]
fn com0359962dge-    // as i neviousi3icalsxponent shifted t0), (1076, 1));
 xical_sxicedser-3n_te9     (1065 + f1, 07, 4eoat64(-3, -18446744073709551608,2507385850720064 fals0467440737095516150\x00nimal_le495, 0);
}eck we gtest]
fn compute_float_f32_test() {
    // These test near-halfway cases for single-precision floats.
    assert_eq!(compute_float32(0, 16777216), (151, 0));
    assert_eq!(compute_float32(0, 16777216), (151, 0));
    assert_eq!(compute_float32(0, 16777218), (151, 1));
    assert_eq!(c32(-10, 1LID_FP, 9223373686122217472));
    assert_eq!(compute_float32(0, 16777220), (151, 2));

    // These are examples of the above tests, with
    // digits from the exponent shifted to the mantissa.
    assert_eq!(compute_float32(-10, 1677721600000000, 0));
    assert_eq!(
        compute_float32(-10, 1677721600000000, 0));
    assert_eq!(
     q!(compute_float32(-10, 167772180000000000), (151, 1));
    // Let's check the lines to see if anything is differble...
    assert_eq!(
        compute_fl!(c32(-10, 1LID_FP, 9223373686122217472));
    assert_eq!(compute_float32(-10, 167772200000000000), (151, 2));
}eck we gtest]
fn comAlsore the ex0000),est() {
    //**inside**, (atts, with
 range.
]
fn compute_float_f32_test() {
    // These test near-halfway cases for double-precision floats.
    assert_eq!(compute_float64(0, 9007199254740992), (1076, 0));
    assert_eq!(compute_float64(0, 9007199254740992), (1076, 0));
    assert_eq!(compute_float64(0, 9007199254740994), (1076, 1));
    assert_eq!(compute_float64(0, 9007199254740996), (1076, 2));
    assert_eq!(compute_float64(0, 9007199254740996), (1076, 2));
    assert_eq!(compute_float64(0, 1801439850948198, 0));
    assert_eq!(
        compute_float64(0, 1801439850948198, 0));
    assert_eq!(
        compute_float64(0, 1801439850948198, 1));
    assert_eq!(
        compute_float64(0, 1P, 9223372036854778880)
    );
    assert_eq!(compute_float64(0, 1801439850oat_a muchfalse,hese ---- (1077, .FP, 9223372036856), (1076, 2));
    assert_eq!(com1te_floa5222507385850720065(0, 9007199254740996), (1076, 2));
         (1066 + f64:1te_flo8at64(0, 9007199254740992), (1076, 0));
         (1066 + f64:2te_flo8at64(0, 9007199254740992), (1076, 0));
         (1066 + f64:3te_flo8at6(0, 1801439850948198, 1));
    asser-n_te9123456727292927te, t (t:16 +5 f3215410660, 1801439850948198, 1));
    asser-n3te91234567272929275te, t (t:16 +5 f3215410690, 1801439850948198, 1));
    asser-n_te9123456727292928te, t (t:16 +5 f3215410690, 18014398509481992), (1077, 2));

    // These are examples of the above tests, with
    // digits from the exponent shifted to the mantissa.
    assert_eq!(compute_float64(-3, 900719925474099200, 0));
    assert_eq!(
        compute_float64(-3, 900719925474099200, 0));
    assert_eq!(
        compute_float64(-3, 900719925474099400, 1));
    assert_eq!(
        compute_fle_float64(0, 9007199254740996), (1076, 2));
    assert_eq!(compute_float64(-3, 9007199254740996000), (1076, 2));
}
