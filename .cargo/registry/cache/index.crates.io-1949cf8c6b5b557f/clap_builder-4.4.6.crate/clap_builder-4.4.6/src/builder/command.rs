#![cfg_attr(not(feature = "usage"), allow(unused_mut))]

// Std
use std::env;
use std::ffi::OsString;
use std::fmt;
use std::io;
use std::ops::Index;
use std::path::Path;

// Internal
use crate::builder::app_settings::{AppFlags, AppSettings};
use crate::builder::arg_settings::ArgSettings;
use crate::builder::ext::Extensions;
use crate::builder::ArgAction;
use crate::builder::IntoResettable;
use crate::builder::PossibleValue;
use crate::builder::Str;
use crate::builder::StyledStr;
use crate::builder::Styles;
use crate::builder::{Arg, ArgGroup, ArgPredicate};
use crate::error::ErrorKind;
use crate::error::Result as ClapResult;
use crate::mkeymap::MKeyMap;
use crate::output::fmt::Stream;
use crate::output::{fmt::Colorizer, write_help, Usage};
use crate::parser::{ArgMatcher, ArgMatches, Parser};
use crate::util::ChildGraph;
use crate::util::{color::ColorChoice, Id};
use crate::{Error, INTERNAL_ERROR_MSG};

#[cfg(debug_assertions)]
use crate::builder::debug_asserts::assert_app;

/// Build a command-line interface.
///
/// This includes defining arguments, subcommands, parser behavior, and help output.
/// Once all configuration is complete,
/// the [`Command::get_matches`] family of methods starts the runtime-parsing
/// process. These methods then return information about the user supplied
/// arguments (or lack thereof).
///
/// When deriving a [`Parser`][crate::Parser], you can use
/// [`CommandFactory::command`][crate::CommandFactory::command] to access the
/// `Command`.
///
/// - [Basic API][crate::Command#basic-api]
/// - [Application-wide Settings][crate::Command#application-wide-settings]
/// - [Command-specific Settings][crate::Command#command-specific-settings]
/// - [Subcommand-specific Settings][crate::Command#subcommand-specific-settings]
/// - [Reflection][crate::Command#reflection]
///
/// # Examples
///
/// ```no_run
/// # use clap_builder as clap;
/// # use clap::{Command, Arg};
/// let m = Command::new("My Program")
///     .author("Me, me@mail.com")
///     .version("1.0.2")
///     .about("Explains in brief what the program does")
///     .arg(
///         Arg::new("in_file")
///     )
///     .after_help("Longer explanation to appear after the options when \
///                  displaying the help information from --help or -h")
///     .get_matches();
///
/// // Your program logic starts here...
/// ```
/// [`Command::get_matches`]: Command::get_matches()
#[derive(Debug, Clone)]
pub struct Command {
    name: Str,
    long_flag: Option<Str>,
    short_flag: Option<char>,
    display_name: Option<String>,
    bin_name: Option<String>,
    author: Option<Str>,
    version: Option<Str>,
    long_version: Option<Str>,
    about: Option<StyledStr>,
    long_about: Option<StyledStr>,
    before_help: Option<StyledStr>,
    before_long_help: Option<StyledStr>,
    after_help: Option<StyledStr>,
    after_long_help: Option<StyledStr>,
    aliases: Vec<(Str, bool)>,             // (name, visible)
    short_flag_aliases: Vec<(char, bool)>, // (name, visible)
    long_flag_aliases: Vec<(Str, bool)>,   // (name, visible)
    usage_str: Option<StyledStr>,
    usage_name: Option<String>,
    help_str: Option<StyledStr>,
    disp_ord: Option<usize>,
    #[cfg(feature = "help")]
    template: Option<StyledStr>,
    settings: AppFlags,
    g_settings: AppFlags,
    args: MKeyMap,
    subcommands: Vec<Command>,
    groups: Vec<ArgGroup>,
    current_help_heading: Option<Str>,
    current_disp_ord: Option<usize>,
    subcommand_value_name: Option<Str>,
    subcommand_heading: Option<Str>,
    external_value_parser: Option<super::ValueParser>,
    long_help_exists: bool,
    deferred: Option<fn(Command) -> Command>,
    app_ext: Extensions,
}

/// # Basic API
impl Command {
    /// Creates a new instance of an `Command`.
    ///
    /// It is common, but not required, to use binary name as the `name`. This
    /// name will only be displayed to the user when they request to print
    /// version or help and usage information.
    ///
    /// See also [`command!`](crate::command!) and [`crate_name!`](crate::crate_name!).
    ///
    /// # Examples
    ///
    /// ```rust
    /// # use clap_builder as clap;
    /// # use clap::Command;
    /// Command::new("My Program")
    /// # ;
    /// ```
    pub fn new(name: impl Into<Str>) -> Self {
        /// The actual implementation of `new`, non-generic to save code size.
        ///
        /// If we don't do this rustc will unnecessarily generate multiple versions
        /// of this code.
        fn new_inner(name: Str) -> Command {
            Command {
                name,
                ..Default::default()
            }
        }

        new_inner(name.into())
    }

    /// Adds an [argument] to the list of valid possibilities.
    ///
    /// # Examples
    ///
    /// ```rust
    /// # use clap_builder as clap;
    /// # use clap::{Command, arg, Arg};
    /// Command::new("myprog")
    ///     // Adding a single "flag" argument with a short and help text, using Arg::new()
    ///     .arg(
    ///         Arg::new("debug")
    ///            .short('d')
    ///            .help("turns on debugging mode")
    ///     )
    ///     // Adding a single "option" argument with a short, a long, and help text using the less
    ///     // verbose Arg::from()
    ///     .arg(
    ///         arg!(-c --config <CONFIG> "Optionally sets a config file to use")
    ///     )
    /// # ;
    /// ```
    /// [argument]: Arg
    #[must_use]
    pub fn arg(mut self, a: impl Into<Arg>) -> Self {
        let arg = a.into();
        self.arg_internal(arg);
        self
    }

    fn arg_internal(&mut self, mut arg: Arg) {
        if let Some(current_disp_ord) = self.current_disp_ord.as_mut() {
            if !arg.is_positional() {
                let current = *current_disp_ord;
                arg.disp_ord.get_or_insert(current);
                *current_disp_ord = current + 1;
            }
        }

        arg.help_heading
            .get_or_insert_with(|| self.current_help_heading.clone());
        self.args.push(arg);
    }

    /// Adds multiple [arguments] to the list of valid possibilities.
    ///
    /// # Examples
    ///
    /// ```rust
    /// # use clap_builder as clap;
    /// # use clap::{Command, arg, Arg};
    /// Command::new("myprog")
    ///     .args([
    ///         arg!(-d --debug "turns on debugging info"),
    ///         Arg::new("input").help("the input file to use")
    ///     ])
    /// # ;
    /// ```
    /// [arguments]: Arg
    #[must_use]
    pub fn args(mut self, args: impl IntoIterator<Item = impl Into<Arg>>) -> Self {
        for arg in args {
            self = self.arg(arg);
        }
        self
    }

    /// Allows one to mutate an [`Arg`] after it's been added to a [`Command`].
    ///
    /// # Panics
    ///
    /// If the argument is undefined
    ///
    /// # Examples
    ///
    /// ```rust
    /// # use clap_builder as clap;
    /// # use clap::{Command, Arg, ArgAction};
    ///
    /// let mut cmd = Command::new("foo")
    ///     .arg(Arg::new("bar")
    ///         .short('b')
    ///         .action(ArgAction::SetTrue))
    ///     .mut_arg("bar", |a| a.short('B'));
    ///
    /// let res = cmd.try_get_matches_from_mut(vec!["foo", "-b"]);
    ///
    /// // Since we changed `bar`'s short to "B" this should err as there
    /// // is no `-b` anymore, only `-B`
    ///
    /// assert!(res.is_err());
    ///
    /// let res = cmd.try_get_matches_from_mut(vec!["foo", "-B"]);
    /// assert!(res.is_ok());
    /// ```
    #[must_use]
    #[cfg_attr(debug_assertions, track_caller)]
    pub fn mut_arg<F>(mut self, arg_id: impl AsRef<str>, f: F) -> Self
    where
        F: FnOnce(Arg) -> Arg,
    {
        let id = arg_id.as_ref();
        let a = self
            .args
            .remove_by_name(id)
            .unwrap_or_else(|| panic!("Argument `{id}` is undefined"));

        self.args.push(f(a));
        self
    }

    /// Allows one to mutate all [`Arg`]s after they've been added to a [`Command`].
    ///
    /// This does not affect the built-in `--help` or `--version` arguments.
    ///
    /// # Examples
    ///
    #[cfg_attr(feature = "string", doc = "```")]
    #[cfg_attr(not(feature = "string"), doc = "```ignore")]
    /// # use clap_builder as clap;
    /// # use clap::{Command, Arg, ArgAction};
    ///
    /// let mut cmd = Command::new("foo")
    ///     .arg(Arg::new("bar")
    ///         .long("bar")
    ///         .action(ArgAction::SetTrue))
    ///     .arg(Arg::new("baz")
    ///         .long("baz")
    ///         .action(ArgAction::SetTrue))
    ///     .mut_args(|a| {
    ///         if let Some(l) = a.get_long().map(|l| format!("prefix-{l}")) {
    ///             a.long(l)
    ///         } else {
    ///             a
    ///         }
    ///     });
    ///
    /// let res = cmd.try_get_matches_from_mut(vec!["foo", "--bar"]);
    ///
    /// // Since we changed `bar`'s long to "prefix-bar" this should err as there
    /// // is no `--bar` anymore, only `--prefix-bar`.
    ///
    /// assert!(res.is_err());
    ///
    /// let res = cmd.try_get_matches_from_mut(vec!["foo", "--prefix-bar"]);
    /// assert!(res.is_ok());
    /// ```
    #[must_use]
    #[cfg_attr(debug_assertions, track_caller)]
    pub fn mut_args<F>(mut self, f: F) -> Self
    where
        F: FnMut(Arg) -> Arg,
    {
        self.args.mut_args(f);
        self
    }

    /// Allows one to mutate a [`Command`] after it's been added as a subcommand.
    ///
    /// This can be useful for modifying auto-generated arguments of nested subcommands with
    /// [`Command::mut_arg`].
    ///
    /// # Panics
    ///
    /// If the subcommand is undefined
    ///
    /// # Examples
    ///
    /// ```rust
    /// # use clap_builder as clap;
    /// # use clap::Command;
    ///
    /// let mut cmd = Command::new("foo")
    ///         .subcommand(Command::new("bar"))
    ///         .mut_subcommand("bar", |subcmd| subcmd.disable_help_flag(true));
    ///
    /// let res = cmd.try_get_matches_from_mut(vec!["foo", "bar", "--help"]);
    ///
    /// // Since we disabled the help flag on the "bar" subcommand, this should err.
    ///
    /// assert!(res.is_err());
    ///
    /// let res = cmd.try_get_matches_from_mut(vec!["foo", "bar"]);
    /// assert!(res.is_ok());
    /// ```
    #[must_use]
    pub fn mut_subcommand<F>(mut self, name: impl AsRef<str>, f: F) -> Self
    where
        F: FnOnce(Self) -> Self,
    {
        let name = name.as_ref();
        let pos = self.subcommands.iter().position(|s| s.name == name);

        let subcmd = if let Some(idx) = pos {
            self.subcommands.remove(idx)
        } else {
            panic!("Command `{name}` is undefined")
        };

        self.subcommands.push(f(subcmd));
        self
    }

    /// Adds an [`ArgGroup`] to the application.
    ///
    /// [`ArgGroup`]s are a family of related arguments.
    /// By placing them in a logical group, you can build easier requirement and exclusion rules.
    ///
    /// Example use cases:
    /// - Make an entire [`ArgGroup`] required, meaning that one (and *only*
    ///   one) argument from that group must be present at runtime.
    /// - Name an [`ArgGroup`] as a conflict to another argument.
    ///   Meaning any of the arguments that belong to that group will cause a failure if present with
    ///   the conflicting argument.
    /// - Ensure exclusion between arguments.
    /// - Extract a value from a group instead of determining exactly which argument was used.
    ///
    /// # Examples
    ///
    /// The following example demonstrates using an [`ArgGroup`] to ensure that one, and only one,
    /// of the arguments from the specified group is present at runtime.
    ///
    /// ```rust
    /// # use clap_builder as clap;
    /// # use clap::{Command, arg, ArgGroup};
    /// Command::new("cmd")
    ///     .arg(arg!(--"set-ver" <ver> "set the version manually").required(false))
    ///     .arg(arg!(--major "auto increase major"))
    ///     .arg(arg!(--minor "auto increase minor"))
    ///     .arg(arg!(--patch "auto increase patch"))
    ///     .group(ArgGroup::new("vers")
    ///          .args(["set-ver", "major", "minor","patch"])
    ///          .required(true))
    /// # ;
    /// ```
    #[inline]
    #[must_use]
    pub fn group(mut self, group: impl Into<ArgGroup>) -> Self {
        self.groups.push(group.into());
        self
    }

    /// Adds multiple [`ArgGroup`]s to the [`Command`] at once.
    ///
    /// # Examples
    ///
    /// ```rust
    /// # use clap_builder as clap;
    /// # use clap::{Command, arg, ArgGroup};
    /// Command::new("cmd")
    ///     .arg(arg!(--"set-ver" <ver> "set the version manually").required(false))
    ///     .arg(arg!(--major         "auto increase major"))
    ///     .arg(arg!(--minor         "auto increase minor"))
    ///     .arg(arg!(--patch         "auto increase patch"))
    ///     .arg(arg!(-c <FILE>       "a config file").required(false))
    ///     .arg(arg!(-i <IFACE>      "an interface").required(false))
    ///     .groups([
    ///         ArgGroup::new("vers")
    ///             .args(["set-ver", "major", "minor","patch"])
    ///             .required(true),
    ///         ArgGroup::new("input")
    ///             .args(["c", "i"])
    ///     ])
    /// # ;
    /// ```
    #[must_use]
    pub fn groups(mut self, groups: impl IntoIterator<Item = impl Into<ArgGroup>>) -> Self {
        for g in groups.into_iter() {
            self = self.group(g.into());
        }
        self
    }

    /// Adds a subcommand to the list of valid possibilities.
    ///
    /// Subcommands are effectively sub-[`Command`]s, because they can contain their own arguments,
    /// subcommands, version, usage, etc. They also function just like [`Command`]s, in that they get
    /// their own auto generated help, version, and usage.
    ///
    /// A subcommand's [`Command::name`] will be used for:
    /// - The argument the user passes in
    /// - Programmatically looking up the subcommand
    ///
    /// # Examples
    ///
    /// ```rust
    /// # use clap_builder as clap;
    /// # use clap::{Command, arg};
    /// Command::new("myprog")
    ///     .subcommand(Command::new("config")
    ///         .about("Controls configuration features")
    ///         .arg(arg!(<config> "Required configuration file to use")))
    /// # ;
    /// ```
    #[inline]
    #[must_use]
    pub fn subcommand(self, subcmd: impl Into<Command>) -> Self {
        let subcmd = subcmd.into();
        self.subcommand_internal(subcmd)
    }

    fn subcommand_internal(mut self, mut subcmd: Self) -> Self {
        if let Some(current_disp_ord) = self.current_disp_ord.as_mut() {
            let current = *current_disp_ord;
            subcmd.disp_ord.get_or_insert(current);
            *current_disp_ord = current + 1;
        }
        self.subcommands.push(subcmd);
        self
    }

    /// Adds multiple subcommands to the list of valid possibilities.
    ///
    /// # Examples
    ///
    /// ```rust
    /// # use clap_builder as clap;
    /// # use clap::{Command, Arg, };
    /// # Command::new("myprog")
    /// .subcommands( [
    ///        Command::new("config").about("Controls configuration functionality")
    ///                                 .arg(Arg::new("config_file")),
    ///        Command::new("debug").about("Controls debug functionality")])
    /// # ;
    /// ```
    /// [`IntoIterator`]: std::iter::IntoIterator
    #[must_use]
    pub fn subcommands(mut self, subcmds: impl IntoIterator<Item = impl Into<Self>>) -> Self {
        for subcmd in subcmds {
            self = self.subcommand(subcmd);
        }
        self
    }

    /// Delay initialization for parts of the `Command`
    ///
    /// This is useful for large applications to delay definitions of subcommands until they are
    /// being invoked.
    ///
    /// # Examples
    ///
    /// ```rust
    /// # use clap_builder as clap;
    /// # use clap::{Command, arg};
    /// Command::new("myprog")
    ///     .subcommand(Command::new("config")
    ///         .about("Controls configuration features")
    ///         .defer(|cmd| {
    ///             cmd.arg(arg!(<config> "Required configuration file to use"))
    ///         })
    ///     )
    /// # ;
    /// ```
    pub fn defer(mut self, deferred: fn(Command) -> Command) -> Self {
        self.deferred = Some(deferred);
        self
    }

    /// Catch problems earlier in the development cycle.
    ///
    /// Most error states are handled as asserts under the assumption they are programming mistake
    /// and not something to handle at runtime.  Rather than relying on tests (manual or automated)
    /// that exhaustively test your CLI to ensure the asserts are evaluated, this will run those
    /// asserts in a way convenient for running as a test.
    ///
    /// **Note::** This will not help with asserts in [`ArgMatches`], those will need exhaustive
    /// testing of your CLI.
    ///
    /// # Examples
    ///
    /// ```rust
    /// # use clap_builder as clap;
    /// # use clap::{Command, Arg, ArgAction};
    /// fn cmd() -> Command {
    ///     Command::new("foo")
    ///         .arg(
    ///             Arg::new("bar").short('b').action(ArgAction::SetTrue)
    ///         )
    /// }
    ///
    /// #[test]
    /// fn verify_app() {
    ///     cmd().debug_assert();
    /// }
    ///
    /// fn main() {
    ///     let m = cmd().get_matches_from(vec!["foo", "-b"]);
    ///     println!("{}", m.get_flag("bar"));
    /// }
    /// ```
    pub fn debug_assert(mut self) {
        self.build();
    }

    /// Custom error message for post-parsing validation
    ///
    /// # Examples
    ///
    /// ```rust
    /// # use clap_builder as clap;
    /// # use clap::{Command, error::ErrorKind};
    /// let mut cmd = Command::new("myprog");
    /// let err = cmd.error(ErrorKind::InvalidValue, "Some failure case");
    /// ```
    pub fn error(&mut self, kind: ErrorKind, message: impl std::fmt::Display) -> Error {
        Error::raw(kind, message).format(self)
    }

    /// Parse [`env::args_os`], exiting on failure.
    ///
    /// # Panics
    ///
    /// If contradictory arguments or settings exist (debug builds).
    ///
    /// # Examples
    ///
    /// ```no_run
    /// # use clap_builder as clap;
    /// # use clap::{Command, Arg};
    /// let matches = Command::new("myprog")
    ///     // Args and options go here...
    ///     .get_matches();
    /// ```
    /// [`env::args_os`]: std::env::args_os()
    /// [`Command::try_get_matches_from_mut`]: Command::try_get_matches_from_mut()
    #[inline]
    pub fn get_matches(self) -> ArgMatches {
        self.get_matches_from(env::args_os())
    }

    /// Parse [`env::args_os`], exiting on failure.
    ///
    /// Like [`Command::get_matches`] but doesn't consume the `Command`.
    ///
    /// # Panics
    ///
    /// If contradictory arguments or settings exist (debug builds).
    ///
    /// # Examples
    ///
    /// ```no_run
    /// # use clap_builder as clap;
    /// # use clap::{Command, Arg};
    /// let mut cmd = Command::new("myprog")
    ///     // Args and options go here...
    ///     ;
    /// let matches = cmd.get_matches_mut();
    /// ```
    /// [`env::args_os`]: std::env::args_os()
    /// [`Command::get_matches`]: Command::get_matches()
    pub fn get_matches_mut(&mut self) -> ArgMatches {
        self.try_get_matches_from_mut(&mut env::args_os())
            .unwrap_or_else(|e| e.exit())
    }

    /// Parse [`env::args_os`], returning a [`clap::Result`] on failure.
    ///
    /// **NOTE:** This method WILL NOT exit when `--help` or `--version` (or short versions) are
    /// used. It will return a [`clap::Error`], where the [`kind`] is a
    /// [`ErrorKind::DisplayHelp`] or [`ErrorKind::DisplayVersion`] respectively. You must call
    /// [`Error::exit`] or perform a [`std::process::exit`].
    ///
    /// # Panics
    ///
    /// If contradictory arguments or settings exist (debug builds).
    ///
    /// # Examples
    ///
    /// ```no_run
    /// # use clap_builder as clap;
    /// # use clap::{Command, Arg};
    /// let matches = Command::new("myprog")
    ///     // Args and options go here...
    ///     .try_get_matches()
    ///     .unwrap_or_else(|e| e.exit());
    /// ```
    /// [`env::args_os`]: std::env::args_os()
    /// [`Error::exit`]: crate::Error::exit()
    /// [`std::process::exit`]: std::process::exit()
    /// [`clap::Result`]: Result
    /// [`clap::Error`]: crate::Error
    /// [`kind`]: crate::Error
    /// [`ErrorKind::DisplayHelp`]: crate::error::ErrorKind::DisplayHelp
    /// [`ErrorKind::DisplayVersion`]: crate::error::ErrorKind::DisplayVersion
    #[inline]
    pub fn try_get_matches(self) -> ClapResult<ArgMatches> {
        // Start the parsing
        self.try_get_matches_from(env::args_os())
    }

    /// Parse the specified arguments, exiting on failure.
    ///
    /// **NOTE:** The first argument will be parsed as the binary name unless
    /// [`Command::no_binary_name`] is used.
    ///
    /// # Panics
    ///
    /// If contradictory arguments or settings exist (debug builds).
    ///
    /// # Examples
    ///
    /// ```no_run
    /// # use clap_builder as clap;
    /// # use clap::{Command, Arg};
    /// let arg_vec = vec!["my_prog", "some", "args", "to", "parse"];
    ///
    /// let matches = Command::new("myprog")
    ///     // Args and options go here...
    ///     .get_matches_from(arg_vec);
    /// ```
    /// [`Command::get_matches`]: Command::get_matches()
    /// [`clap::Result`]: Result
    /// [`Vec`]: std::vec::Vec
    pub fn get_matches_from<I, T>(mut self, itr: I) -> ArgMatches
    where
        I: IntoIterator<Item = T>,
        T: Into<OsString> + Clone,
    {
        self.try_get_matches_from_mut(itr).unwrap_or_else(|e| {
            drop(self);
            e.exit()
        })
    }

    /// Parse the specified arguments, returning a [`clap::Result`] on failure.
    ///
    /// **NOTE:** This method WILL NOT exit when `--help` or `--version` (or short versions) are
    /// used. It will return a [`clap::Error`], where the [`kind`] is a [`ErrorKind::DisplayHelp`]
    /// or [`ErrorKind::DisplayVersion`] respectively. You must call [`Error::exit`] or
    /// perform a [`std::process::exit`] yourself.
    ///
    /// **NOTE:** The first argument will be parsed as the binary name unless
    /// [`Command::no_binary_name`] is used.
    ///
    /// # Panics
    ///
    /// If contradictory arguments or settings exist (debug builds).
    ///
    /// # Examples
    ///
    /// ```no_run
    /// # use clap_builder as clap;
    /// # use clap::{Command, Arg};
    /// let arg_vec = vec!["my_prog", "some", "args", "to", "parse"];
    ///
    /// let matches = Command::new("myprog")
    ///     // Args and options go here...
    ///     .try_get_matches_from(arg_vec)
    ///     .unwrap_or_else(|e| e.exit());
    /// ```
    /// [`Command::get_matches_from`]: Command::get_matches_from()
    /// [`Command::try_get_matches`]: Command::try_get_matches()
    /// [`Error::exit`]: crate::Error::exit()
    /// [`std::process::exit`]: std::process::exit()
    /// [`clap::Error`]: crate::Error
    /// [`Error::exit`]: crate::Error::exit()
    /// [`kind`]: crate::Error
    /// [`ErrorKind::DisplayHelp`]: crate::error::ErrorKind::DisplayHelp
    /// [`ErrorKind::DisplayVersion`]: crate::error::ErrorKind::DisplayVersion
    /// [`clap::Result`]: Result
    pub fn try_get_matches_from<I, T>(mut self, itr: I) -> ClapResult<ArgMatches>
    where
        I: IntoIterator<Item = T>,
        T: Into<OsString> + Clone,
    {
        self.try_get_matches_from_mut(itr)
    }

    /// Parse the specified arguments, returning a [`clap::Result`] on failure.
    ///
    /// Like [`Command::try_get_matches_from`] but doesn't consume the `Command`.
    ///
    /// **NOTE:** This method WILL NOT exit when `--help` or `--version` (or short versions) are
    /// used. It will return a [`clap::Error`], where the [`kind`] is a [`ErrorKind::DisplayHelp`]
    /// or [`ErrorKind::DisplayVersion`] respectively. You must call [`Error::exit`] or
    /// perform a [`std::process::exit`] yourself.
    ///
    /// **NOTE:** The first argument will be parsed as the binary name unless
    /// [`Command::no_binary_name`] is used.
    ///
    /// # Panics
    ///
    /// If contradictory arguments or settings exist (debug builds).
    ///
    /// # Examples
    ///
    /// ```no_run
    /// # use clap_builder as clap;
    /// # use clap::{Command, Arg};
    /// let arg_vec = vec!["my_prog", "some", "args", "to", "parse"];
    ///
    /// let mut cmd = Command::new("myprog");
    ///     // Args and options go here...
    /// let matches = cmd.try_get_matches_from_mut(arg_vec)
    ///     .unwrap_or_else(|e| e.exit());
    /// ```
    /// [`Command::try_get_matches_from`]: Command::try_get_matches_from()
    /// [`clap::Result`]: Result
    /// [`clap::Error`]: crate::Error
    /// [`kind`]: crate::Error
    pub fn try_get_matches_from_mut<I, T>(&mut self, itr: I) -> ClapResult<ArgMatches>
    where
        I: IntoIterator<Item = T>,
        T: Into<OsString> + Clone,
    {
        let mut raw_args = clap_lex::RawArgs::new(itr.into_iter());
        let mut cursor = raw_args.cursor();

        if self.settings.is_set(AppSettings::Multicall) {
            if let Some(argv0) = raw_args.next_os(&mut cursor) {
                let argv0 = Path::new(&argv0);
                if let Some(command) = argv0.file_stem().and_then(|f| f.to_str()) {
                    // Stop borrowing command so we can get another mut ref to it.
                    let command = command.to_owned();
                    debug!("Command::try_get_matches_from_mut: Parsed command {command} from argv");

                    debug!("Command::try_get_matches_from_mut: Reinserting command into arguments so subcommand parser matches it");
                    raw_args.insert(&cursor, [&command]);
                    debug!("Command::try_get_matches_from_mut: Clearing name and bin_name so that displayed command name starts with applet name");
                    self.name = "".into();
                    self.bin_name = None;
                    return self._do_parse(&mut raw_args, cursor);
                }
            }
        };

        // Get the name of the program (argument 1 of env::args()) and determine the
        // actual file
        // that was used to execute the program. This is because a program called
        // ./target/release/my_prog -a
        // will have two arguments, './target/release/my_prog', '-a' but we don't want
        // to display
        // the full path when displaying help messages and such
        if !self.settings.is_set(AppSettings::NoBinaryName) {
            if let Some(name) = raw_args.next_os(&mut cursor) {
                let p = Path::new(name);

                if let Some(f) = p.file_name() {
                    if let Some(s) = f.to_str() {
                        if self.bin_name.is_none() {
                            self.bin_name = Some(s.to_owned());
                        }
                    }
                }
            }
        }

        self._do_parse(&mut raw_args, cursor)
    }

    /// Prints the short help message (`-h`) to [`io::stdout()`].
    ///
    /// See also [`Command::print_long_help`].
    ///
    /// # Examples
    ///
    /// ```rust
    /// # use clap_builder as clap;
    /// # use clap::Command;
    /// let mut cmd = Command::new("myprog");
    /// cmd.print_help();
    /// ```
    /// [`io::stdout()`]: std::io::stdout()
    pub fn print_help(&mut self) -> io::Result<()> {
        self._build_self(false);
        let color = self.color_help();

        let mut styled = StyledStr::new();
        let usage = Usage::new(self);
        write_help(&mut styled, self, &usage, false);

        let c = Colorizer::new(Stream::Stdout, color).with_content(styled);
        c.print()
    }

    /// Prints the long help message (`--help`) to [`io::stdout()`].
    ///
    /// See also [`Command::print_help`].
    ///
    /// # Examples
    ///
    /// ```rust
    /// # use clap_builder as clap;
    /// # use clap::Command;
    /// let mut cmd = Command::new("myprog");
    /// cmd.print_long_help();
    /// ```
    /// [`io::stdout()`]: std::io::stdout()
    /// [`BufWriter`]: std::io::BufWriter
    /// [`-h` (short)]: Arg::help()
    /// [`--help` (long)]: Arg::long_help()
    pub fn print_long_help(&mut self) -> io::Result<()> {
        self._build_self(false);
        let color = self.color_help();

        let mut styled = StyledStr::new();
        let usage = Usage::new(self);
        write_help(&mut styled, self, &usage, true);

        let c = Colorizer::new(Stream::Stdout, color).with_content(styled);
        c.print()
    }

    /// Render the short help message (`-h`) to a [`StyledStr`]
    ///
    /// See also [`Command::render_long_help`].
    ///
    /// # Examples
    ///
    /// ```rust
    /// # use clap_builder as clap;
    /// # use clap::Command;
    /// use std::io;
    /// let mut cmd = Command::new("myprog");
    /// let mut out = io::stdout();
    /// let help = cmd.render_help();
    /// println!("{help}");
    /// ```
    /// [`io::Write`]: std::io::Write
    /// [`-h` (short)]: Arg::help()
    /// [`--help` (long)]: Arg::long_help()
    pub fn render_help(&mut self) -> StyledStr {
        self._build_self(false);

        let mut styled = StyledStr::new();
        let usage = Usage::new(self);
        write_help(&mut styled, self, &usage, false);
        styled
    }

    /// Render the long help message (`--help`) to a [`StyledStr`].
    ///
    /// See also [`Command::render_help`].
    ///
    /// # Examples
    ///
    /// ```rust
    /// # use clap_builder as clap;
    /// # use clap::Command;
    /// use std::io;
    /// let mut cmd = Command::new("myprog");
    /// let mut out = io::stdout();
    /// let help = cmd.render_long_help();
    /// println!("{help}");
    /// ```
    /// [`io::Write`]: std::io::Write
    /// [`-h` (short)]: Arg::help()
    /// [`--help` (long)]: Arg::long_help()
    pub fn render_long_help(&mut self) -> StyledStr {
        self._build_self(false);

        let mut styled = StyledStr::new();
        let usage = Usage::new(self);
        write_help(&mut styled, self, &usage, true);
        styled
    }

    #[doc(hidden)]
    #[cfg_attr(
        feature = "deprecated",
        deprecated(since = "4.0.0", note = "Replaced with `Command::render_help`")
    )]
    pub fn write_help<W: io::Write>(&mut self, w: &mut W) -> io::Result<()> {
        self._build_self(false);

        let mut styled = StyledStr::new();
        let usage = Usage::new(self);
        write_help(&mut styled, self, &usage, false);
        ok!(write!(w, "{styled}"));
        w.flush()
    }

    #[doc(hidden)]
    #[cfg_attr(
        feature = "deprecated",
        deprecated(since = "4.0.0", note = "Replaced with `Command::render_long_help`")
    )]
    pub fn write_long_help<W: io::Write>(&mut self, w: &mut W) -> io::Result<()> {
        self._build_self(false);

        let mut styled = StyledStr::new();
        let usage = Usage::new(self);
        write_help(&mut styled, self, &usage, true);
        ok!(write!(w, "{styled}"));
        w.flush()
    }

    /// Version message rendered as if the user ran `-V`.
    ///
    /// See also [`Command::render_long_version`].
    ///
    /// ### Coloring
    ///
    /// This function does not try to color the message nor it inserts any [ANSI escape codes].
    ///
    /// ### Examples
    ///
    /// ```rust
    /// # use clap_builder as clap;
    /// # use clap::Command;
    /// use std::io;
    /// let cmd = Command::new("myprog");
    /// println!("{}", cmd.render_version());
    /// ```
    /// [`io::Write`]: std::io::Write
    /// [`-V` (short)]: Command::version()
    /// [`--version` (long)]: Command::long_version()
    /// [ANSI escape codes]: https://en.wikipedia.org/wiki/ANSI_escape_code
    pub fn render_version(&self) -> String {
        self._render_version(false)
    }

    /// Version message rendered as if the user ran `--version`.
    ///
    /// See also [`Command::render_version`].
    ///
    /// ### Coloring
    ///
    /// This function does not try to color the message nor it inserts any [ANSI escape codes].
    ///
    /// ### Examples
    ///
    /// ```rust
    /// # use clap_builder as clap;
    /// # use clap::Command;
    /// use std::io;
    /// let cmd = Command::new("myprog");
    /// println!("{}", cmd.render_long_version());
    /// ```
    /// [`io::Write`]: std::io::Write
    /// [`-V` (short)]: Command::version()
    /// [`--version` (long)]: Command::long_version()
    /// [ANSI escape codes]: https://en.wikipedia.org/wiki/ANSI_escape_code
    pub fn render_long_version(&self) -> String {
        self._render_version(true)
    }

    /// Usage statement
    ///
    /// ### Examples
    ///
    /// ```rust
    /// # use clap_builder as clap;
    /// # use clap::Command;
    /// use std::io;
    /// let mut cmd = Command::new("myprog");
    /// println!("{}", cmd.render_usage());
    /// ```
    pub fn render_usage(&mut self) -> StyledStr {
        self.render_usage_().unwrap_or_default()
    }

    pub(crate) fn render_usage_(&mut self) -> Option<StyledStr> {
        // If there are global arguments, or settings we need to propagate them down to subcommands
        // before parsing incase we run into a subcommand
        self._build_self(false);

        Usage::new(self).create_usage_with_title(&[])
    }
}

/// # Application-wide Settings
///
/// These settings will apply to the top-level command and all subcommands, by default.  Some
/// settings can be overridden in subcommands.
impl Command {
    /// Specifies that the parser should not assume the first argument passed is the binary name.
    ///
    /// This is normally the case when using a "daemon" style mode.  For shells / REPLs, see
    /// [`Command::multicall`][Command::multicall].
    ///
    /// # Examples
    ///
    /// ```rust
    /// # use clap_builder as clap;
    /// # use clap::{Command, arg};
    /// let m = Command::new("myprog")
    ///     .no_binary_name(true)
    ///     .arg(arg!(<cmd> ... "commands to run"))
    ///     .get_matches_from(vec!["command", "set"]);
    ///
    /// let cmds: Vec<_> = m.get_many::<String>("cmd").unwrap().collect();
    /// assert_eq!(cmds, ["command", "set"]);
    /// ```
    /// [`try_get_matches_from_mut`]: crate::Command::try_get_matches_from_mut()
    #[inline]
    pub fn no_binary_name(self, yes: bool) -> Self {
        if yes {
            self.global_setting(AppSettings::NoBinaryName)
        } else {
            self.unset_global_setting(AppSettings::NoBinaryName)
        }
    }

    /// Try not to fail on parse errors, like missing option values.
    ///
    /// **NOTE:** This choice is propagated to all child subcommands.
    ///
    /// # Examples
    ///
    /// ```rust
    /// # use clap_builder as clap;
    /// # use clap::{Command, arg};
    /// let cmd = Command::new("cmd")
    ///   .ignore_errors(true)
    ///   .arg(arg!(-c --config <FILE> "Sets a custom config file"))
    ///   .arg(arg!(-x --stuff <FILE> "Sets a custom stuff file"))
    ///   .arg(arg!(f: -f "Flag"));
    ///
    /// let r = cmd.try_get_matches_from(vec!["cmd", "-c", "file", "-f", "-x"]);
    ///
    /// assert!(r.is_ok(), "unexpected error: {r:?}");
    /// let m = r.unwrap();
    /// assert_eq!(m.get_one::<String>("config").unwrap(), "file");
    /// assert!(m.get_flag("f"));
    /// assert_eq!(m.get_one::<String>("stuff"), None);
    /// ```
    #[inline]
    pub fn ignore_errors(self, yes: bool) -> Self {
        if yes {
            self.global_setting(AppSettings::IgnoreErrors)
        } else {
            self.unset_global_setting(AppSettings::IgnoreErrors)
        }
    }

    /// Replace prior occurrences of arguments rather than error
    ///
    /// For any argument that would conflict with itself by default (e.g.
    /// [`ArgAction::Set`][ArgAction::Set], it will now override itself.
    ///
    /// This is the equivalent to saying the `foo` arg using [`Arg::overrides_with("foo")`] for all
    /// defined arguments.
    ///
    /// **NOTE:** This choice is propagated to all child subcommands.
    ///
    /// [`Arg::overrides_with("foo")`]: crate::Arg::overrides_with()
    #[inline]
    pub fn args_override_self(self, yes: bool) -> Self {
        if yes {
            self.global_setting(AppSettings::AllArgsOverrideSelf)
        } else {
            self.unset_global_setting(AppSettings::AllArgsOverrideSelf)
        }
    }

    /// Disables the automatic delimiting of values after `--` or when [`Command::trailing_var_arg`]
    /// was used.
    ///
    /// **NOTE:** The same thing can be done manually by setting the final positional argument to
    /// [`Arg::value_delimiter(None)`]. Using this setting is safer, because it's easier to locate
    /// when making changes.
    ///
    /// **NOTE:** This choice is propagated to all child subcommands.
    ///
    /// # Examples
    ///
    /// ```no_run
    /// # use clap_builder as clap;
    /// # use clap::{Command, Arg};
    /// Command::new("myprog")
    ///     .dont_delimit_trailing_values(true)
    ///     .get_matches();
    /// ```
    ///
    /// [`Arg::value_delimiter(None)`]: crate::Arg::value_delimiter()
    #[inline]
    pub fn dont_delimit_trailing_values(self, yes: bool) -> Self {
        if yes {
            self.global_setting(AppSettings::DontDelimitTrailingValues)
        } else {
            self.unset_global_setting(AppSettings::DontDelimitTrailingValues)
        }
    }

    /// Sets when to color output.
    ///
    /// **NOTE:** This choice is propagated to all child subcommands.
    ///
    /// **NOTE:** Default behaviour is [`ColorChoice::Auto`].
    ///
    /// # Examples
    ///
    /// ```no_run
    /// # use clap_builder as clap;
    /// # use clap::{Command, ColorChoice};
    /// Command::new("myprog")
    ///     .color(ColorChoice::Never)
    ///     .get_matches();
    /// ```
    /// [`ColorChoice::Auto`]: crate::ColorChoice::Auto
    #[cfg(feature = "color")]
    #[inline]
    #[must_use]
    pub fn color(self, color: ColorChoice) -> Self {
        let cmd = self
            .unset_global_setting(AppSettings::ColorAuto)
            .unset_global_setting(AppSettings::ColorAlways)
            .unset_global_setting(AppSettings::ColorNever);
        match color {
            ColorChoice::Auto => cmd.global_setting(AppSettings::ColorAuto),
            ColorChoice::Always => cmd.global_setting(AppSettings::ColorAlways),
            ColorChoice::Never => cmd.global_setting(AppSettings::ColorNever),
        }
    }

    /// Sets the [`Styles`] for terminal output
    ///
    /// **NOTE:** This choice is propagated to all child subcommands.
    ///
    /// **NOTE:** Default behaviour is [`Styles::default`].
    ///
    /// # Examples
    ///
    /// ```no_run
    /// # use clap_builder as clap;
    /// # use clap::{Command, ColorChoice, builder::styling};
    /// let styles = styling::Styles::styled()
    ///     .header(styling::AnsiColor::Green.on_default() | styling::Effects::BOLD)
    ///     .usage(styling::AnsiColor::Green.on_default() | styling::Effects::BOLD)
    ///     .literal(styling::AnsiColor::Blue.on_default() | styling::Effects::BOLD)
    ///     .placeholder(styling::AnsiColor::Cyan.on_default());
    /// Command::new("myprog")
    ///     .styles(styles)
    ///     .get_matches();
    /// ```
    #[cfg(feature = "color")]
    #[inline]
    #[must_use]
    pub fn styles(mut self, styles: Styles) -> Self {
        self.app_ext.set(styles);
        self
    }

    /// Sets the terminal width at which to wrap help messages.
    ///
    /// Using `0` will ignore terminal widths and use source formatting.
    ///
    /// Defaults to current terminal width when `wrap_help` feature flag is enabled.  If current
    /// width cannot be determined, the default is 100.
    ///
    /// **`unstable-v5` feature**: Defaults to unbound, being subject to
    /// [`Command::max_term_width`].
    ///
    /// **NOTE:** This setting applies globally and *not* on a per-command basis.
    ///
    /// **NOTE:** This requires the `wrap_help` feature
    ///
    /// # Examples
    ///
    /// ```rust
    /// # use clap_builder as clap;
    /// # use clap::Command;
    /// Command::new("myprog")
    ///     .term_width(80)
    /// # ;
    /// ```
    #[inline]
    #[must_use]
    #[cfg(any(not(feature = "unstable-v5"), feature = "wrap_help"))]
    pub fn term_width(mut self, width: usize) -> Self {
        self.app_ext.set(TermWidth(width));
        self
    }

    /// Limit the line length for wrapping help when using the current terminal's width.
    ///
    /// This only applies when [`term_width`][Command::term_width] is unset so that the current
    /// terminal's width will be used.  See [`Command::term_width`] for more details.
    ///
    /// Using `0` will ignore this, always respecting [`Command::term_width`] (default).
    ///
    /// **`unstable-v5` feature**: Defaults to 100.
    ///
    /// **NOTE:** This setting applies globally and *not* on a per-command basis.
    ///
    /// **NOTE:** This requires the `wrap_help` feature
    ///
    /// # Examples
    ///
    /// ```rust
    /// # use clap_builder as clap;
    /// # use clap::Command;
    /// Command::new("myprog")
    ///     .max_term_width(100)
    /// # ;
    /// ```
    #[inline]
    #[must_use]
    #[cfg(any(not(feature = "unstable-v5"), feature = "wrap_help"))]
    pub fn max_term_width(mut self, width: usize) -> Self {
        self.app_ext.set(MaxTermWidth(width));
        self
    }

    /// Disables `-V` and `--version` flag.
    ///
    /// # Examples
    ///
    /// ```rust
    /// # use clap_builder as clap;
    /// # use clap::{Command, error::ErrorKind};
    /// let res = Command::new("myprog")
    ///     .disable_version_flag(true)
    ///     .try_get_matches_from(vec![
    ///         "myprog", "-V"
    ///     ]);
    /// assert!(res.is_err());
    /// assert_eq!(res.unwrap_err().kind(), ErrorKind::UnknownArgument);
    /// ```
    #[inline]
    pub fn disable_version_flag(self, yes: bool) -> Self {
        if yes {
            self.global_setting(AppSettings::DisableVersionFlag)
        } else {
            self.unset_global_setting(AppSettings::DisableVersionFlag)
        }
    }

    /// Specifies to use the version of the current command for all [`subcommands`].
    ///
    /// Defaults to `false`; subcommands have independent version strings from their parents.
    ///
    /// **NOTE:** This choice is propagated to all child subcommands.
    ///
    /// # Examples
    ///
    /// ```no_run
    /// # use clap_builder as clap;
    /// # use clap::{Command, Arg};
    /// Command::new("myprog")
    ///     .version("v1.1")
    ///     .propagate_version(true)
    ///     .subcommand(Command::new("test"))
    ///     .get_matches();
    /// // running `$ myprog test --version` will display
    /// // "myprog-test v1.1"
    /// ```
    ///
    /// [`subcommands`]: crate::Command::subcommand()
    #[inline]
    pub fn propagate_version(self, yes: bool) -> Self {
        if yes {
            self.global_setting(AppSettings::PropagateVersion)
        } else {
            self.unset_global_setting(AppSettings::PropagateVersion)
        }
    }

    /// Places the help string for all arguments and subcommands on the line after them.
    ///
    /// **NOTE:** This choice is propagated to all child subcommands.
    ///
    /// # Examples
    ///
    /// ```no_run
    /// # use clap_builder as clap;
    /// # use clap::{Command, Arg};
    /// Command::new("myprog")
    ///     .next_line_help(true)
    ///     .get_matches();
    /// ```
    #[inline]
    pub fn next_line_help(self, yes: bool) -> Self {
        if yes {
            self.global_setting(AppSettings::NextLineHelp)
        } else {
            self.unset_global_setting(AppSettings::NextLineHelp)
        }
    }

    /// Disables `-h` and `--help` flag.
    ///
    /// **NOTE:** This choice is propagated to all child subcommands.
    ///
    /// # Examples
    ///
    /// ```rust
    /// # use clap_builder as clap;
    /// # use clap::{Command, error::ErrorKind};
    /// let res = Command::new("myprog")
    ///     .disable_help_flag(true)
    ///     .try_get_matches_from(vec![
    ///         "myprog", "-h"
    ///     ]);
    /// assert!(res.is_err());
    /// assert_eq!(res.unwrap_err().kind(), ErrorKind::UnknownArgument);
    /// ```
    #[inline]
    pub fn disable_help_flag(self, yes: bool) -> Self {
        if yes {
            self.global_setting(AppSettings::DisableHelpFlag)
        } else {
            self.unset_global_setting(AppSettings::DisableHelpFlag)
        }
    }

    /// Disables the `help` [`subcommand`].
    ///
    /// **NOTE:** This choice is propagated to all child subcommands.
    ///
    /// # Examples
    ///
    /// ```rust
    /// # use clap_builder as clap;
    /// # use clap::{Command, error::ErrorKind};
    /// let res = Command::new("myprog")
    ///     .disable_help_subcommand(true)
    ///     // Normally, creating a subcommand causes a `help` subcommand to automatically
    ///     // be generated as well
    ///     .subcommand(Command::new("test"))
    ///     .try_get_matches_from(vec![
    ///         "myprog", "help"
    ///     ]);
    /// assert!(res.is_err());
    /// assert_eq!(res.unwrap_err().kind(), ErrorKind::InvalidSubcommand);
    /// ```
    ///
    /// [`subcommand`]: crate::Command::subcommand()
    #[inline]
    pub fn disable_help_subcommand(self, yes: bool) -> Self {
        if yes {
            self.global_setting(AppSettings::DisableHelpSubcommand)
        } else {
            self.unset_global_setting(AppSettings::DisableHelpSubcommand)
        }
    }

    /// Disables colorized help messages.
    ///
    /// **NOTE:** This choice is propagated to all child subcommands.
    ///
    /// # Examples
    ///
    /// ```no_run
    /// # use clap_builder as clap;
    /// # use clap::Command;
    /// Command::new("myprog")
    ///     .disable_colored_help(true)
    ///     .get_matches();
    /// ```
    #[inline]
    pub fn disable_colored_help(self, yes: bool) -> Self {
        if yes {
            self.global_setting(AppSettings::DisableColoredHelp)
        } else {
            self.unset_global_setting(AppSettings::DisableColoredHelp)
        }
    }

    /// Panic if help descriptions are omitted.
    ///
    /// **NOTE:** When deriving [`Parser`][crate::Parser], you could instead check this at
    /// compile-time with `#![deny(missing_docs)]`
    ///
    /// **NOTE:** This choice is propagated to all child subcommands.
    ///
    /// # Examples
    ///
    /// ```rust
    /// # use clap_builder as clap;
    /// # use clap::{Command, Arg};
    /// Command::new("myprog")
    ///     .help_expected(true)
    ///     .arg(
    ///         Arg::new("foo").help("It does foo stuff")
    ///         // As required via `help_expected`, a help message was supplied
    ///      )
    /// #    .get_matches();
    /// ```
    ///
    /// # Panics
    ///
    /// On debug builds:
    /// ```rust,no_run
    /// # use clap_builder as clap;
    /// # use clap::{Command, Arg};
    /// Command::new("myapp")
    ///     .help_expected(true)
    ///     .arg(
    ///         Arg::new("foo")
    ///         // Someone forgot to put .about("...") here
    ///         // Since the setting `help_expected` is activated, this will lead to
    ///         // a panic (if you are in debug mode)
    ///     )
    /// #   .get_matches();
    ///```
    #[inline]
    pub fn help_expected(self, yes: bool) -> Self {
        if yes {
            self.global_setting(AppSettings::HelpExpected)
        } else {
            self.unset_global_setting(AppSettings::HelpExpected)
        }
    }

    #[doc(hidden)]
    #[cfg_attr(
        feature = "deprecated",
        deprecated(since = "4.0.0", note = "This is now the default")
    )]
    pub fn dont_collapse_args_in_usage(self, _yes: bool) -> Self {
        self
    }

    /// Tells `clap` *not* to print possible values when displaying help information.
    ///
    /// This can be useful if there are many values, or they are explained elsewhere.
    ///
    /// To set this per argument, see
    /// [`Arg::hide_possible_values`][crate::Arg::hide_possible_values].
    ///
    /// **NOTE:** This choice is propagated to all child subcommands.
    #[inline]
    pub fn hide_possible_values(self, yes: bool) -> Self {
        if yes {
            self.global_setting(AppSettings::HidePossibleValues)
        } else {
            self.unset_global_setting(AppSettings::HidePossibleValues)
        }
    }

    /// Allow partial matches of long arguments or their [aliases].
    ///
    /// For example, to match an argument named `--test`, one could use `--t`, `--te`, `--tes`, and
    /// `--test`.
    ///
    /// **NOTE:** The match *must not* be ambiguous at all in order to succeed. i.e. to match
    /// `--te` to `--test` there could not also be another argument or alias `--temp` because both
    /// start with `--te`
    ///
    /// **NOTE:** This choice is propagated to all child subcommands.
    ///
    /// [aliases]: crate::Command::aliases()
    #[inline]
    pub fn infer_long_args(self, yes: bool) -> Self {
        if yes {
            self.global_setting(AppSettings::InferLongArgs)
        } else {
            self.unset_global_setting(AppSettings::InferLongArgs)
        }
    }

    /// Allow partial matches of [subcommand] names and their [aliases].
    ///
    /// For example, to match a subcommand named `test`, one could use `t`, `te`, `tes`, and
    /// `test`.
    ///
    /// **NOTE:** The match *must not* be ambiguous at all in order to succeed. i.e. to match `te`
    /// to `test` there could not also be a subcommand or alias `temp` because both start with `te`
    ///
    /// **CAUTION:** This setting can interfere with [positional/free arguments], take care when
    /// designing CLIs which allow inferred subcommands and have potential positional/free
    /// arguments whose values could start with the same characters as subcommands. If this is the
    /// case, it's recommended to use settings such as [`Command::args_conflicts_with_subcommands`] in
    /// conjunction with this setting.
    ///
    /// **NOTE:** This choice is propagated to all child subcommands.
    ///
    /// # Examples
    ///
    /// ```no_run
    /// # use clap_builder as clap;
    /// # use clap::{Command, Arg};
    /// let m = Command::new("prog")
    ///     .infer_subcommands(true)
    ///     .subcommand(Command::new("test"))
    ///     .get_matches_from(vec![
    ///         "prog", "te"
    ///     ]);
    /// assert_eq!(m.subcommand_name(), Some("test"));
    /// ```
    ///
    /// [subcommand]: crate::Command::subcommand()
    /// [positional/free arguments]: crate::Arg::index()
    /// [aliases]: crate::Command::aliases()
    #[inline]
    pub fn infer_subcommands(self, yes: bool) -> Self {
        if yes {
            self.global_setting(AppSettings::InferSubcommands)
        } else {
            self.unset_global_setting(AppSettings::InferSubcommands)
        }
    }
}

/// # Command-specific Settings
///
/// These apply only to the current command and are not inherited by subcommands.
impl Command {
    /// (Re)Sets the program's name.
    ///
    /// See [`Command::new`] for more details.
    ///
    /// # Examples
    ///
    /// ```ignore
    /// let cmd = clap::command!()
    ///     .name("foo");
    ///
    /// // continued logic goes here, such as `cmd.get_matches()` etc.
    /// ```
    #[must_use]
    pub fn name(mut self, name: impl Into<Str>) -> Self {
        self.name = name.into();
        self
    }

    /// Overrides the runtime-determined name of the binary for help and error messages.
    ///
    /// This should only be used when absolutely necessary, such as when the binary name for your
    /// application is misleading, or perhaps *not* how the user should invoke your program.
    ///
    /// **Pro-tip:** When building things such as third party `cargo`
    /// subcommands, this setting **should** be used!
    ///
    /// **NOTE:** This *does not* change or set the name of the binary file on
    /// disk. It only changes what clap thinks the name is for the purposes of
    /// error or help messages.
    ///
    /// # Examples
    ///
    /// ```rust
    /// # use clap_builder as clap;
    /// # use clap::Command;
    /// Command::new("My Program")
    ///      .bin_name("my_binary")
    /// # ;
    /// ```
    #[must_use]
    pub fn bin_name(mut self, name: impl IntoResettable<String>) -> Self {
        self.bin_name = name.into_resettable().into_option();
        self
    }

    /// Overrides the runtime-determined display name of the program for help and error messages.
    ///
    /// # Examples
    ///
    /// ```rust
    /// # use clap_builder as clap;
    /// # use clap::Command;
    /// Command::new("My Program")
    ///      .display_name("my_program")
    /// # ;
    /// ```
    #[must_use]
    pub fn display_name(mut self, name: impl IntoResettable<String>) -> Self {
        self.display_name = name.into_resettable().into_option();
        self
    }

    /// Sets the author(s) for the help message.
    ///
    /// **Pro-tip:** Use `clap`s convenience macro [`crate_authors!`] to
    /// automatically set your application's author(s) to the same thing as your
    /// crate at compile time.
    ///
    /// **NOTE:** A custom [`help_template`][Command::help_template] is needed for author to show
    /// up.
    ///
    /// # Examples
    ///
    /// ```rust
    /// # use clap_builder as clap;
    /// # use clap::Command;
    /// Command::new("myprog")
    ///      .author("Me, me@mymain.com")
    /// # ;
    /// ```
    #[must_use]
    pub fn author(mut self, author: impl IntoResettable<Str>) -> Self {
        self.author = author.into_resettable().into_option();
        self
    }

    /// Sets the program's description for the short help (`-h`).
    ///
    /// If [`Command::long_about`] is not specified, this message will be displayed for `--help`.
    ///
    /// **NOTE:** Only `Command::about` (short format) is used in completion
    /// script generation in order to be concise.
    ///
    /// See also [`crate_description!`](crate::crate_description!).
    ///
    /// # Examples
    ///
    /// ```rust
    /// # use clap_builder as clap;
    /// # use clap::Command;
    /// Command::new("myprog")
    ///     .about("Does really amazing things for great people")
    /// # ;
    /// ```
    #[must_use]
    pub fn about(mut self, about: impl IntoResettable<StyledStr>) -> Self {
        self.about = about.into_resettable().into_option();
        self
    }

    /// Sets the program's description for the long help (`--help`).
    ///
    /// If [`Command::about`] is not specified, this message will be displayed for `-h`.
    ///
    /// **NOTE:** Only [`Command::about`] (short format) is used in completion
    /// script generation in order to be concise.
    ///
    /// # Examples
    ///
    /// ```rust
    /// # use clap_builder as clap;
    /// # use clap::Command;
    /// Command::new("myprog")
    ///     .long_about(
    /// "Does really amazing things to great people. Now let's talk a little
    ///  more in depth about how this subcommand really works. It may take about
    ///  a few lines of text, but that's ok!")
    /// # ;
    /// ```
    /// [`Command::about`]: Command::about()
    #[must_use]
    pub fn long_about(mut self, long_about: impl IntoResettable<StyledStr>) -> Self {
        self.long_about = long_about.into_resettable().into_option();
        self
    }

    /// Free-form help text for after auto-generated short help (`-h`).
    ///
    /// This is often used to describe how to use the arguments, caveats to be noted, or license
    /// and contact information.
    ///
    /// If [`Command::after_long_help`] is not specified, this message will be displayed for `--help`.
    ///
    /// # Examples
    ///
    /// ```rust
    /// # use clap_builder as clap;
    /// # use clap::Command;
    /// Command::new("myprog")
    ///     .after_help("Does really amazing things for great people... but be careful with -R!")
    /// # ;
    /// ```
    ///
    #[must_use]
    pub fn after_help(mut self, help: impl IntoResettable<StyledStr>) -> Self {
        self.after_help = help.into_resettable().into_option();
        self
    }

    /// Free-form help text for after auto-generated long help (`--help`).
    ///
    /// This is often used to describe how to use the arguments, caveats to be noted, or license
    /// and contact information.
    ///
    /// If [`Command::after_help`] is not specified, this message will be displayed for `-h`.
    ///
    /// # Examples
    ///
    /// ```rust
    /// # use clap_builder as clap;
    /// # use clap::Command;
    /// Command::new("myprog")
    ///     .after_long_help("Does really amazing things to great people... but be careful with -R, \
    ///                      like, for real, be careful with this!")
    /// # ;
    /// ```
    #[must_use]
    pub fn after_long_help(mut self, help: impl IntoResettable<StyledStr>) -> Self {
        self.after_long_help = help.into_resettable().into_option();
        self
    }

    /// Free-form help text for before auto-generated short help (`-h`).
    ///
    /// This is often used for header, copyright, or license information.
    ///
    /// If [`Command::before_long_help`] is not specified, this message will be displayed for `--help`.
    ///
    /// # Examples
    ///
    /// ```rust
    /// # use clap_builder as clap;
    /// # use clap::Command;
    /// Command::new("myprog")
    ///     .before_help("Some info I'd like to appear before the help info")
    /// # ;
    /// ```
    #[must_use]
    pub fn before_help(mut self, help: impl IntoResettable<StyledStr>) -> Self {
        self.before_help = help.into_resettable().into_option();
        self
    }

    /// Free-form help text for before auto-generated long help (`--help`).
    ///
    /// This is often used for header, copyright, or license information.
    ///
    /// If [`Command::before_help`] is not specified, this message will be displayed for `-h`.
    ///
    /// # Examples
    ///
    /// ```rust
    /// # use clap_builder as clap;
    /// # use clap::Command;
    /// Command::new("myprog")
    ///     .before_long_help("Some verbose and long info I'd like to appear before the help info")
    /// # ;
    /// ```
    #[must_use]
    pub fn before_long_help(mut self, help: impl IntoResettable<StyledStr>) -> Self {
        self.before_long_help = help.into_resettable().into_option();
        self
    }

    /// Sets the version for the short version (`-V`) and help messages.
    ///
    /// If [`Command::long_version`] is not specified, this message will be displayed for `--version`.
    ///
    /// **Pro-tip:** Use `clap`s convenience macro [`crate_version!`] to
    /// automatically set your application's version to the same thing as your
    /// crate at compile time.
    ///
    /// # Examples
    ///
    /// ```rust
    /// # use clap_builder as clap;
    /// # use clap::Command;
    /// Command::new("myprog")
    ///     .version("v0.1.24")
    /// # ;
    /// ```
    #[must_use]
    pub fn version(mut self, ver: impl IntoResettable<Str>) -> Self {
        self.version = ver.into_resettable().into_option();
        self
    }

    /// Sets the version for the long version (`--version`) and help messages.
    ///
    /// If [`Command::version`] is not specified, this message will be displayed for `-V`.
    ///
    /// **Pro-tip:** Use `clap`s convenience macro [`crate_version!`] to
    /// automatically set your application's version to the same thing as your
    /// crate at compile time.
    ///
    /// # Examples
    ///
    /// ```rust
    /// # use clap_builder as clap;
    /// # use clap::Command;
    /// Command::new("myprog")
    ///     .long_version(
    /// "v0.1.24
    ///  commit: abcdef89726d
    ///  revision: 123
    ///  release: 2
    ///  binary: myprog")
    /// # ;
    /// ```
    #[must_use]
    pub fn long_version(mut self, ver: impl IntoResettable<Str>) -> Self {
        self.long_version = ver.into_resettable().into_option();
        self
    }

    /// Overrides the `clap` generated usage string for help and error messages.
    ///
    /// **NOTE:** Using this setting disables `clap`s "context-aware" usage
    /// strings. After this setting is set, this will be *the only* usage string
    /// displayed to the user!
    ///
    /// **NOTE:** Multiple usage lines may be present in the usage argument, but
    /// some rules need to be followed to ensure the usage lines are formatted
    /// correctly by the default help formatter:
    ///
    /// - Do not indent the first usage line.
    /// - Indent all subsequent usage lines with seven spaces.
    /// - The last line must not end with a newline.
    ///
    /// # Examples
    ///
    /// ```rust
    /// # use clap_builder as clap;
    /// # use clap::{Command, Arg};
    /// Command::new("myprog")
    ///     .override_usage("myapp [-clDas] <some_file>")
    /// # ;
    /// ```
    ///
    /// Or for multiple usage lines:
    ///
    /// ```rust
    /// # use clap_builder as clap;
    /// # use clap::{Command, Arg};
    /// Command::new("myprog")
    ///     .override_usage(
    ///         "myapp -X [-a] [-b] <file>\n       \
    ///          myapp -Y [-c] <file1> <file2>\n       \
    ///          myapp -Z [-d|-e]"
    ///     )
    /// # ;
    /// ```
    ///
    /// [`ArgMatches::usage`]: ArgMatches::usage()
    #[must_use]
    pub fn override_usage(mut self, usage: impl IntoResettable<StyledStr>) -> Self {
        self.usage_str = usage.into_resettable().into_option();
        self
    }

    /// Overrides the `clap` generated help message (both `-h` and `--help`).
    ///
    /// This should only be used when the auto-generated message does not suffice.
    ///
    /// **NOTE:** This **only** replaces the help message for the current
    /// command, meaning if you are using subcommands, those help messages will
    /// still be auto-generated unless you specify a [`Command::override_help`] for
    /// them as well.
    ///
    /// # Examples
    ///
    /// ```rust
    /// # use clap_builder as clap;
    /// # use clap::{Command, Arg};
    /// Command::new("myapp")
    ///     .override_help("myapp v1.0\n\
    ///            Does awesome things\n\
    ///            (C) me@mail.com\n\n\
    ///
    ///            Usage: myapp <opts> <command>\n\n\
    ///
    ///            Options:\n\
    ///            -h, --help       Display this message\n\
    ///            -V, --version    Display version info\n\
    ///            -s <stuff>       Do something with stuff\n\
    ///            -v               Be verbose\n\n\
    ///
    ///            Commands:\n\
    ///            help             Print this message\n\
    ///            work             Do some work")
    /// # ;
    /// ```
    #[must_use]
    pub fn override_help(mut self, help: impl IntoResettable<StyledStr>) -> Self {
        self.help_str = help.into_resettable().into_option();
        self
    }

    /// Sets the help template to be used, overriding the default format.
    ///
    /// **NOTE:** The template system is by design very simple. Therefore, the
    /// tags have to be written in the lowercase and without spacing.
    ///
    /// Tags are given inside curly brackets.
    ///
    /// Valid tags are:
    ///
    ///   * `{name}`                - Display name for the (sub-)command.
    ///   * `{bin}`                 - Binary name.(deprecated)
    ///   * `{version}`             - Version number.
    ///   * `{author}`              - Author information.
    ///   * `{author-with-newline}` - Author followed by `\n`.
    ///   * `{author-section}`      - Author preceded and followed by `\n`.
    ///   * `{about}`               - General description (from [`Command::about`] or
    ///                               [`Command::long_about`]).
    ///   * `{about-with-newline}`  - About followed by `\n`.
    ///   * `{about-section}`       - About preceded and followed by '\n'.
    ///   * `{usage-heading}`       - Automatically generated usage heading.
    ///   * `{usage}`               - Automatically generated or given usage string.
    ///   * `{all-args}`            - Help for all arguments (options, flags, positional
    ///                               arguments, and subcommands) including titles.
    ///   * `{options}`             - Help for options.
    ///   * `{positionals}`         - Help for positional arguments.
    ///   * `{subcommands}`         - Help for subcommands.
    ///   * `{tab}`                 - Standard tab sized used within clap
    ///   * `{after-help}`          - Help from [`Command::after_help`] or [`Command::after_long_help`].
    ///   * `{before-help}`         - Help from [`Command::before_help`] or [`Command::before_long_help`].
    ///
    /// # Examples
    ///
    /// For a very brief help:
    ///
    /// ```rust
    /// # use clap_builder as clap;
    /// # use clap::Command;
    /// Command::new("myprog")
    ///     .version("1.0")
    ///     .help_template("{name} ({version}) - {usage}")
    /// # ;
    /// ```
    ///
    /// For showing more application context:
    ///
    /// ```rust
    /// # use clap_builder as clap;
    /// # use clap::Command;
    /// Command::new("myprog")
    ///     .version("1.0")
    ///     .help_template("\
    /// {before-help}{name} {version}
    /// {author-with-newline}{about-with-newline}
    /// {usage-heading} {usage}
    ///
    /// {all-args}{after-help}
    /// ")
    /// # ;
    /// ```
    /// [`Command::about`]: Command::about()
    /// [`Command::long_about`]: Command::long_about()
    /// [`Command::after_help`]: Command::after_help()
    /// [`Command::after_long_help`]: Command::after_long_help()
    /// [`Command::before_help`]: Command::before_help()
    /// [`Command::before_long_help`]: Command::before_long_help()
    #[must_use]
    #[cfg(feature = "help")]
    pub fn help_template(mut self, s: impl IntoResettable<StyledStr>) -> Self {
        self.template = s.into_resettable().into_option();
        self
    }

    #[inline]
    #[must_use]
    pub(crate) fn setting(mut self, setting: AppSettings) -> Self {
        self.settings.set(setting);
        self
    }

    #[inline]
    #[must_use]
    pub(crate) fn unset_setting(mut self, setting: AppSettings) -> Self {
        self.settings.unset(setting);
        self
    }

    #[inline]
    #[must_use]
    pub(crate) fn global_setting(mut self, setting: AppSettings) -> Self {
        self.settings.set(setting);
        self.g_settings.set(setting);
        self
    }

    #[inline]
    #[must_use]
    pub(crate) fn unset_global_setting(mut self, setting: AppSettings) -> Self {
        self.settings.unset(setting);
        self.g_settings.unset(setting);
        self
    }

    /// Set the default section heading for future args.
    ///
    /// This will be used for any arg that hasn't had [`Arg::help_heading`] called.
    ///
    /// This is useful if the default `Options` or `Arguments` headings are
    /// not specific enough for one's use case.
    ///
    /// For subcommands, see [`Command::subcommand_help_heading`]
    ///
    /// [`Command::arg`]: Command::arg()
    /// [`Arg::help_heading`]: crate::Arg::help_heading()
    #[inline]
    #[must_use]
    pub fn next_help_heading(mut self, heading: impl IntoResettable<Str>) -> Self {
        self.current_help_heading = heading.into_resettable().into_option();
        self
    }

    /// Change the starting value for assigning future display orders for args.
    ///
    /// This will be used for any arg that hasn't had [`Arg::display_order`] called.
    #[inline]
    #[must_use]
    pub fn next_display_order(mut self, disp_ord: impl IntoResettable<usize>) -> Self {
        self.current_disp_ord = disp_ord.into_resettable().into_option();
        self
    }

    /// Exit gracefully if no arguments are present (e.g. `$ myprog`).
    ///
    /// **NOTE:** [`subcommands`] count as arguments
    ///
    /// # Examples
    ///
    /// ```rust
    /// # use clap_builder as clap;
    /// # use clap::{Command};
    /// Command::new("myprog")
    ///     .arg_required_else_help(true);
    /// ```
    ///
    /// [`subcommands`]: crate::Command::subcommand()
    /// [`Arg::default_value`]: crate::Arg::default_value()
    #[inline]
    pub fn arg_required_else_help(self, yes: bool) -> Self {
        if yes {
            self.setting(AppSettings::ArgRequiredElseHelp)
        } else {
            self.unset_setting(AppSettings::ArgRequiredElseHelp)
        }
    }

    #[doc(hidden)]
    #[cfg_attr(
        feature = "deprecated",
        deprecated(since = "4.0.0", note = "Replaced with `Arg::allow_hyphen_values`")
    )]
    pub fn allow_hyphen_values(self, yes: bool) -> Self {
        if yes {
            self.setting(AppSettings::AllowHyphenValues)
        } else {
            self.unset_setting(AppSettings::AllowHyphenValues)
        }
    }

    #[doc(hidden)]
    #[cfg_attr(
        feature = "deprecated",
        deprecated(since = "4.0.0", note = "Replaced with `Arg::allow_negative_numbers`")
    )]
    pub fn allow_negative_numbers(self, yes: bool) -> Self {
        if yes {
            self.setting(AppSettings::AllowNegativeNumbers)
        } else {
            self.unset_setting(AppSettings::AllowNegativeNumbers)
        }
    }

    #[doc(hidden)]
    #[cfg_attr(
        feature = "deprecated",
        deprecated(since = "4.0.0", note = "Replaced with `Arg::trailing_var_arg`")
    )]
    pub fn trailing_var_arg(self, yes: bool) -> Self {
        if yes {
            self.setting(AppSettings::TrailingVarArg)
        } else {
            self.unset_setting(AppSettings::TrailingVarArg)
        }
    }

    /// Allows one to implement two styles of CLIs where positionals can be used out of order.
    ///
    /// The first example is a CLI where the second to last positional argument is optional, but
    /// the final positional argument is required. Such as `$ prog [optional] <required>` where one
    /// of the two following usages is allowed:
    ///
    /// * `$ prog [optional] <required>`
    /// * `$ prog <required>`
    ///
    /// This would otherwise not be allowed. This is useful when `[optional]` has a default value.
    ///
    /// **Note:** when using this style of "missing positionals" the final positional *must* be
    /// [required] if `--` will not be used to skip to the final positional argument.
    ///
    /// **Note:** This style also only allows a single positional argument to be "skipped" without
    /// the use of `--`. To skip more than one, see the second example.
    ///
    /// The second example is when one wants to skip multiple optional positional arguments, and use
    /// of the `--` operator is OK (but not required if all arguments will be specified anyways).
    ///
    /// For example, imagine a CLI which has three positional arguments `[foo] [bar] [baz]...` where
    /// `baz` accepts multiple values (similar to man `ARGS...` style training arguments).
    ///
    /// With this setting the following invocations are posisble:
    ///
    /// * `$ prog foo bar baz1 baz2 baz3`
    /// * `$ prog foo -- baz1 baz2 baz3`
    /// * `$ prog -- baz1 baz2 baz3`
    ///
    /// # Examples
    ///
    /// Style number one from above:
    ///
    /// ```rust
    /// # use clap_builder as clap;
    /// # use clap::{Command, Arg};
    /// // Assume there is an external subcommand named "subcmd"
    /// let m = Command::new("myprog")
    ///     .allow_missing_positional(true)
    ///     .arg(Arg::new("arg1"))
    ///     .arg(Arg::new("arg2")
    ///         .required(true))
    ///     .get_matches_from(vec![
    ///         "prog", "other"
    ///     ]);
    ///
    /// assert_eq!(m.get_one::<String>("arg1"), None);
    /// assert_eq!(m.get_one::<String>("arg2").unwrap(), "other");
    /// ```
    ///
    /// Now the same example, but using a default value for the first optional positional argument
    ///
    /// ```rust
    /// # use clap_builder as clap;
    /// # use clap::{Command, Arg};
    /// // Assume there is an external subcommand named "subcmd"
    /// let m = Command::new("myprog")
    ///     .allow_missing_positional(true)
    ///     .arg(Arg::new("arg1")
    ///         .default_value("something"))
    ///     .arg(Arg::new("arg2")
    ///         .required(true))
    ///     .get_matches_from(vec![
    ///         "prog", "other"
    ///     ]);
    ///
    /// assert_eq!(m.get_one::<String>("arg1").unwrap(), "something");
    /// assert_eq!(m.get_one::<String>("arg2").unwrap(), "other");
    /// ```
    ///
    /// Style number two from above:
    ///
    /// ```rust
    /// # use clap_builder as clap;
    /// # use clap::{Command, Arg, ArgAction};
    /// // Assume there is an external subcommand named "subcmd"
    /// let m = Command::new("myprog")
    ///     .allow_missing_positional(true)
    ///     .arg(Arg::new("foo"))
    ///     .arg(Arg::new("bar"))
    ///     .arg(Arg::new("baz").action(ArgAction::Set).num_args(1..))
    ///     .get_matches_from(vec![
    ///         "prog", "foo", "bar", "baz1", "baz2", "baz3"
    ///     ]);
    ///
    /// assert_eq!(m.get_one::<String>("foo").unwrap(), "foo");
    /// assert_eq!(m.get_one::<String>("bar").unwrap(), "bar");
    /// assert_eq!(m.get_many::<String>("baz").unwrap().collect::<Vec<_>>(), &["baz1", "baz2", "baz3"]);
    /// ```
    ///
    /// Now nofice if we don't specify `foo` or `baz` but use the `--` operator.
    ///
    /// ```rust
    /// # use clap_builder as clap;
    /// # use clap::{Command, Arg, ArgAction};
    /// // Assume there is an external subcommand named "subcmd"
    /// let m = Command::new("myprog")
    ///     .allow_missing_positional(true)
    ///     .arg(Arg::new("foo"))
    ///     .arg(Arg::new("bar"))
    ///     .arg(Arg::new("baz").action(ArgAction::Set).num_args(1..))
    ///     .get_matches_from(vec![
    ///         "prog", "--", "baz1", "baz2", "baz3"
    ///     ]);
    ///
    /// assert_eq!(m.get_one::<String>("foo"), None);
    /// assert_eq!(m.get_one::<String>("bar"), None);
    /// assert_eq!(m.get_many::<String>("baz").unwrap().collect::<Vec<_>>(), &["baz1", "baz2", "baz3"]);
    /// ```
    ///
    /// [required]: crate::Arg::required()
    #[inline]
    pub fn allow_missing_positional(self, yes: bool) -> Self {
        if yes {
            self.setting(AppSettings::AllowMissingPositional)
        } else {
            self.unset_setting(AppSettings::AllowMissingPositional)
        }
    }
}

/// # Subcommand-specific Settings
impl Command {
    /// Sets the short version of the subcommand flag without the preceding `-`.
    ///
    /// Allows the subcommand to be used as if it were an [`Arg::short`].
    ///
    /// # Examples
    ///
    /// ```
    /// # use clap_builder as clap;
    /// # use clap::{Command, Arg, ArgAction};
    /// let matches = Command::new("pacman")
    ///     .subcommand(
    ///         Command::new("sync").short_flag('S').arg(
    ///             Arg::new("search")
    ///                 .short('s')
    ///                 .long("search")
    ///                 .action(ArgAction::SetTrue)
    ///                 .help("search remote repositories for matching strings"),
    ///         ),
    ///     )
    ///     .get_matches_from(vec!["pacman", "-Ss"]);
    ///
    /// assert_eq!(matches.subcommand_name().unwrap(), "sync");
    /// let sync_matches = matches.subcommand_matches("sync").unwrap();
    /// assert!(sync_matches.get_flag("search"));
    /// ```
    /// [`Arg::short`]: Arg::short()
    #[must_use]
    pub fn short_flag(mut self, short: impl IntoResettable<char>) -> Self {
        self.short_flag = short.into_resettable().into_option();
        self
    }

    /// Sets the long version of the subcommand flag without the preceding `--`.
    ///
    /// Allows the subcommand to be used as if it were an [`Arg::long`].
    ///
    /// **NOTE:** Any leading `-` characters will be stripped.
    ///
    /// # Examples
    ///
    /// To set `long_flag` use a word containing valid UTF-8 codepoints. If you supply a double leading
    /// `--` such as `--sync` they will be stripped. Hyphens in the middle of the word; however,
    /// will *not* be stripped (i.e. `sync-file` is allowed).
    ///
    /// ```rust
    /// # use clap_builder as clap;
    /// # use clap::{Command, Arg, ArgAction};
    /// let matches = Command::new("pacman")
    ///     .subcommand(
    ///         Command::new("sync").long_flag("sync").arg(
    ///             Arg::new("search")
    ///                 .short('s')
    ///                 .long("search")
    ///                 .action(ArgAction::SetTrue)
    ///                 .help("search remote repositories for matching strings"),
    ///         ),
    ///     )
    ///     .get_matches_from(vec!["pacman", "--sync", "--search"]);
    ///
    /// assert_eq!(matches.subcommand_name().unwrap(), "sync");
    /// let sync_matches = matches.subcommand_matches("sync").unwrap();
    /// assert!(sync_matches.get_flag("search"));
    /// ```
    ///
    /// [`Arg::long`]: Arg::long()
    #[must_use]
    pub fn long_flag(mut self, long: impl Into<Str>) -> Self {
        self.long_flag = Some(long.into());
        self
    }

    /// Sets a hidden alias to this subcommand.
    ///
    /// This allows the subcommand to be accessed via *either* the original name, or this given
    /// alias. This is more efficient and easier than creating multiple hidden subcommands as one
    /// only needs to check for the existence of this command, and not all aliased variants.
    ///
    /// **NOTE:** Aliases defined with this method are *hidden* from the help
    /// message. If you're looking for aliases that will be displayed in the help
    /// message, see [`Command::visible_alias`].
    ///
    /// **NOTE:** When using aliases and checking for the existence of a
    /// particular subcommand within an [`ArgMatches`] struct, one only needs to
    /// search for the original name and not all aliases.
    ///
    /// # Examples
    ///
    /// ```rust
    /// # use clap_builder as clap;
    /// # use clap::{Command, Arg, };
    /// let m = Command::new("myprog")
    ///     .subcommand(Command::new("test")
    ///         .alias("do-stuff"))
    ///     .get_matches_from(vec!["myprog", "do-stuff"]);
    /// assert_eq!(m.subcommand_name(), Some("test"));
    /// ```
    /// [`Command::visible_alias`]: Command::visible_alias()
    #[must_use]
    pub fn alias(mut self, name: impl IntoResettable<Str>) -> Self {
        if let Some(name) = name.into_resettable().into_option() {
            self.aliases.push((name, false));
        } else {
            self.aliases.clear();
        }
        self
    }

    /// Add an alias, which functions as  "hidden" short flag subcommand
    ///
    /// This will automatically dispatch as if this subcommand was used. This is more efficient,
    /// and easier than creating multiple hidden subcommands as one only needs to check for the
    /// existence of this command, and not all variants.
    ///
    /// # Examples
    ///
    /// ```rust
    /// # use clap_builder as clap;
    /// # use clap::{Command, Arg, };
    /// let m = Command::new("myprog")
    ///             .subcommand(Command::new("test").short_flag('t')
    ///                 .short_flag_alias('d'))
    ///             .get_matches_from(vec!["myprog", "-d"]);
    /// assert_eq!(m.subcommand_name(), Some("test"));
    /// ```
    #[must_use]
    pub fn short_flag_alias(mut self, name: impl IntoResettable<char>) -> Self {
        if let Some(name) = name.into_resettable().into_option() {
            debug_assert!(name != '-', "short alias name cannot be `-`");
            self.short_flag_aliases.push((name, false));
        } else {
            self.short_flag_aliases.clear();
        }
        self
    }

    /// Add an alias, which functions as a "hidden" long flag subcommand.
    ///
    /// This will automatically dispatch as if this subcommand was used. This is more efficient,
    /// and easier than creating multiple hidden subcommands as one only needs to check for the
    /// existence of this command, and not all variants.
    ///
    /// # Examples
    ///
    /// ```rust
    /// # use clap_builder as clap;
    /// # use clap::{Command, Arg, };
    /// let m = Command::new("myprog")
    ///             .subcommand(Command::new("test").long_flag("test")
    ///                 .long_flag_alias("testing"))
    ///             .get_matches_from(vec!["myprog", "--testing"]);
    /// assert_eq!(m.subcommand_name(), Some("test"));
    /// ```
    #[must_use]
    pub fn long_flag_alias(mut self, name: impl IntoResettable<Str>) -> Self {
        if let Some(name) = name.into_resettable().into_option() {
            self.long_flag_aliases.push((name, false));
        } else {
            self.long_flag_aliases.clear();
        }
        self
    }

    /// Sets multiple hidden aliases to this subcommand.
    ///
    /// This allows the subcommand to be accessed via *either* the original name or any of the
    /// given aliases. This is more efficient, and easier than creating multiple hidden subcommands
    /// as one only needs to check for the existence of this command and not all aliased variants.
    ///
    /// **NOTE:** Aliases defined with this method are *hidden* from the help
    /// message. If looking for aliases that will be displayed in the help
    /// message, see [`Command::visible_aliases`].
    ///
    /// **NOTE:** When using aliases and checking for the existence of a
    /// particular subcommand within an [`ArgMatches`] struct, one only needs to
    /// search for the original name and not all aliases.
    ///
    /// # Examples
    ///
    /// ```rust
    /// # use clap_builder as clap;
    /// # use clap::{Command, Arg};
    /// let m = Command::new("myprog")
    ///     .subcommand(Command::new("test")
    ///         .aliases(["do-stuff", "do-tests", "tests"]))
    ///         .arg(Arg::new("input")
    ///             .help("the file to add")
    ///             .required(false))
    ///     .get_matches_from(vec!["myprog", "do-tests"]);
    /// assert_eq!(m.subcommand_name(), Some("test"));
    /// ```
    /// [`Command::visible_aliases`]: Command::visible_aliases()
    #[must_use]
    pub fn aliases(mut self, names: impl IntoIterator<Item = impl Into<Str>>) -> Self {
        self.aliases
            .extend(names.into_iter().map(|n| (n.into(), false)));
        self
    }

    /// Add aliases, which function as "hidden" short flag subcommands.
    ///
    /// These will automatically dispatch as if this subcommand was used. This is more efficient,
    /// and easier than creating multiple hidden subcommands as one only needs to check for the
    /// existence of this command, and not all variants.
    ///
    /// # Examples
    ///
    /// ```rust
    /// # use clap_builder as clap;
    /// # use clap::{Command, Arg, };
    /// let m = Command::new("myprog")
    ///     .subcommand(Command::new("test").short_flag('t')
    ///         .short_flag_aliases(['a', 'b', 'c']))
    ///         .arg(Arg::new("input")
    ///             .help("the file to add")
    ///             .required(false))
    ///     .get_matches_from(vec!["myprog", "-a"]);
    /// assert_eq!(m.subcommand_name(), Some("test"));
    /// ```
    #[must_use]
    pub fn short_flag_aliases(mut self, names: impl IntoIterator<Item = char>) -> Self {
        for s in names {
            debug_assert!(s != '-', "short alias name cannot be `-`");
            self.short_flag_aliases.push((s, false));
        }
        self
    }

    /// Add aliases, which function as "hidden" long flag subcommands.
    ///
    /// These will automatically dispatch as if this subcommand was used. This is more efficient,
    /// and easier than creating multiple hidden subcommands as one only needs to check for the
    /// existence of this command, and not all variants.
    ///
    /// # Examples
    ///
    /// ```rust
    /// # use clap_builder as clap;
    /// # use clap::{Command, Arg, };
    /// let m = Command::new("myprog")
    ///             .subcommand(Command::new("test").long_flag("test")
    ///                 .long_flag_aliases(["testing", "testall", "test_all"]))
    ///                 .arg(Arg::new("input")
    ///                             .help("the file to add")
    ///                             .required(false))
    ///             .get_matches_from(vec!["myprog", "--testing"]);
    /// assert_eq!(m.subcommand_name(), Some("test"));
    /// ```
    #[must_use]
    pub fn long_flag_aliases(mut self, names: impl IntoIterator<Item = impl Into<Str>>) -> Self {
        for s in names {
            self = self.long_flag_alias(s)
        }
        self
    }

    /// Sets a visible alias to this subcommand.
    ///
    /// This allows the subcommand to be accessed via *either* the
    /// original name or the given alias. This is more efficient and easier
    /// than creating hidden subcommands as one only needs to check for
    /// the existence of this command and not all aliased variants.
    ///
    /// **NOTE:** The alias defined with this method is *visible* from the help
    /// message and displayed as if it were just another regular subcommand. If
    /// looking for an alias that will not be displayed in the help message, see
    /// [`Command::alias`].
    ///
    /// **NOTE:** When using aliases and checking for the existence of a
    /// particular subcommand within an [`ArgMatches`] struct, one only needs to
    /// search for the original name and not all aliases.
    ///
    /// # Examples
    ///
    /// ```rust
    /// # use clap_builder as clap;
    /// # use clap::{Command, Arg};
    /// let m = Command::new("myprog")
    ///     .subcommand(Command::new("test")
    ///         .visible_alias("do-stuff"))
    ///     .get_matches_from(vec!["myprog", "do-stuff"]);
    /// assert_eq!(m.subcommand_name(), Some("test"));
    /// ```
    /// [`Command::alias`]: Command::alias()
    #[must_use]
    pub fn visible_alias(mut self, name: impl IntoResettable<Str>) -> Self {
        if let Some(name) = name.into_resettable().into_option() {
            self.aliases.push((name, true));
        } else {
            self.aliases.clear();
        }
        self
    }

    /// Add an alias, which functions as  "visible" short flag subcommand
    ///
    /// This will automatically dispatch as if this subcommand was used. This is more efficient,
    /// and easier than creating multiple hidden subcommands as one only needs to check for the
    /// existence of this command, and not all variants.
    ///
    /// See also [`Command::short_flag_alias`].
    ///
    /// # Examples
    ///
    /// ```rust
    /// # use clap_builder as clap;
    /// # use clap::{Command, Arg, };
    /// let m = Command::new("myprog")
    ///             .subcommand(Command::new("test").short_flag('t')
    ///                 .visible_short_flag_alias('d'))
    ///             .get_matches_from(vec!["myprog", "-d"]);
    /// assert_eq!(m.subcommand_name(), Some("test"));
    /// ```
    /// [`Command::short_flag_alias`]: Command::short_flag_alias()
    #[must_use]
    pub fn visible_short_flag_alias(mut self, name: impl IntoResettable<char>) -> Self {
        if let Some(name) = name.into_resettable().into_option() {
            debug_assert!(name != '-', "short alias name cannot be `-`");
            self.short_flag_aliases.push((name, true));
        } else {
            self.short_flag_aliases.clear();
        }
        self
    }

    /// Add an alias, which functions as a "visible" long flag subcommand.
    ///
    /// This will automatically dispatch as if this subcommand was used. This is more efficient,
    /// and easier than creating multiple hidden subcommands as one only needs to check for the
    /// existence of this command, and not all variants.
    ///
    /// See also [`Command::long_flag_alias`].
    ///
    /// # Examples
    ///
    /// ```rust
    /// # use clap_builder as clap;
    /// # use clap::{Command, Arg, };
    /// let m = Command::new("myprog")
    ///             .subcommand(Command::new("test").long_flag("test")
    ///                 .visible_long_flag_alias("testing"))
    ///             .get_matches_from(vec!["myprog", "--testing"]);
    /// assert_eq!(m.subcommand_name(), Some("test"));
    /// ```
    /// [`Command::long_flag_alias`]: Command::long_flag_alias()
    #[must_use]
    pub fn visible_long_flag_alias(mut self, name: impl IntoResettable<Str>) -> Self {
        if let Some(name) = name.into_resettable().into_option() {
            self.long_flag_aliases.push((name, true));
        } else {
            self.long_flag_aliases.clear();
        }
        self
    }

    /// Sets multiple visible aliases to this subcommand.
    ///
    /// This allows the subcommand to be accessed via *either* the
    /// original name or any of the given aliases. This is more efficient and easier
    /// than creating multiple hidden subcommands as one only needs to check for
    /// the existence of this command and not all aliased variants.
    ///
    /// **NOTE:** The alias defined with this method is *visible* from the help
    /// message and displayed as if it were just another regular subcommand. If
    /// looking for an alias that will not be displayed in the help message, see
    /// [`Command::alias`].
    ///
    /// **NOTE:** When using aliases, and checking for the existence of a
    /// particular subcommand within an [`ArgMatches`] struct, one only needs to
    /// search for the original name and not all aliases.
    ///
    /// # Examples
    ///
    /// ```rust
    /// # use clap_builder as clap;
    /// # use clap::{Command, Arg, };
    /// let m = Command::new("myprog")
    ///     .subcommand(Command::new("test")
    ///         .visible_aliases(["do-stuff", "tests"]))
    ///     .get_matches_from(vec!["myprog", "do-stuff"]);
    /// assert_eq!(m.subcommand_name(), Some("test"));
    /// ```
    /// [`Command::alias`]: Command::alias()
    #[must_use]
    pub fn visible_aliases(mut self, names: impl IntoIterator<Item = impl Into<Str>>) -> Self {
        self.aliases
            .extend(names.into_iter().map(|n| (n.into(), true)));
        self
    }

    /// Add aliases, which function as *visible* short flag subcommands.
    ///
    /// See [`Command::short_flag_aliases`].
    ///
    /// # Examples
    ///
    /// ```rust
    /// # use clap_builder as clap;
    /// # use clap::{Command, Arg, };
    /// let m = Command::new("myprog")
    ///             .subcommand(Command::new("test").short_flag('b')
    ///                 .visible_short_flag_aliases(['t']))
    ///             .get_matches_from(vec!["myprog", "-t"]);
    /// assert_eq!(m.subcommand_name(), Some("test"));
    /// ```
    /// [`Command::short_flag_aliases`]: Command::short_flag_aliases()
    #[must_use]
    pub fn visible_short_flag_aliases(mut self, names: impl IntoIterator<Item = char>) -> Self {
        for s in names {
            debug_assert!(s != '-', "short alias name cannot be `-`");
            self.short_flag_aliases.push((s, true));
        }
        self
    }

    /// Add aliases, which function as *visible* long flag subcommands.
    ///
    /// See [`Command::long_flag_aliases`].
    ///
    /// # Examples
    ///
    /// ```rust
    /// # use clap_builder as clap;
    /// # use clap::{Command, Arg, };
    /// let m = Command::new("myprog")
    ///             .subcommand(Command::new("test").long_flag("test")
    ///                 .visible_long_flag_aliases(["testing", "testall", "test_all"]))
    ///             .get_matches_from(vec!["myprog", "--testing"]);
    /// assert_eq!(m.subcommand_name(), Some("test"));
    /// ```
    /// [`Command::long_flag_aliases`]: Command::long_flag_aliases()
    #[must_use]
    pub fn visible_long_flag_aliases(
        mut self,
        names: impl IntoIterator<Item = impl Into<Str>>,
    ) -> Self {
        for s in names {
            self = self.visible_long_flag_alias(s);
        }
        self
    }

    /// Set the placement of this subcommand within the help.
    ///
    /// Subcommands with a lower value will be displayed first in the help message.
    /// Those with the same display order will be sorted.
    ///
    /// `Command`s are automatically assigned a display order based on the order they are added to
    /// their parent [`Command`].
    /// Overriding this is helpful when the order commands are added in isn't the same as the
    /// display order, whether in one-off cases or to automatically sort commands.
    ///
    /// # Examples
    ///
    /// ```rust
    /// # #[cfg(feature = "help")] {
    /// # use clap_builder as clap;
    /// # use clap::{Command, };
    /// let m = Command::new("cust-ord")
    ///     .subcommand(Command::new("beta")
    ///         .display_order(0)  // Sort
    ///         .about("Some help and text"))
    ///     .subcommand(Command::new("alpha")
    ///         .display_order(0)  // Sort
    ///         .about("I should be first!"))
    ///     .get_matches_from(vec![
    ///         "cust-ord", "--help"
    ///     ]);
    /// # }
    /// ```
    ///
    /// The above example displays the following help message
    ///
    /// ```text
    /// cust-ord
    ///
    /// Usage: cust-ord [OPTIONS]
    ///
    /// Commands:
    ///     alpha    I should be first!
    ///     beta     Some help and text
    ///     help     Print help for the subcommand(s)
    ///
    /// Options:
    ///     -h, --help       Print help
    ///     -V, --version    Print version
    /// ```
    #[inline]
    #[must_use]
    pub fn display_order(mut self, ord: impl IntoResettable<usize>) -> Self {
        self.disp_ord = ord.into_resettable().into_option();
        self
    }

    /// Specifies that this [`subcommand`] should be hidden from help messages
    ///
    /// # Examples
    ///
    /// ```rust
    /// # use clap_builder as clap;
    /// # use clap::{Command, Arg};
    /// Command::new("myprog")
    ///     .subcommand(
    ///         Command::new("test").hide(true)
    ///     )
    /// # ;
    /// ```
    ///
    /// [`subcommand`]first!"))rate::Arg::required()      allow_missing_positional(self, yes: bool) -> Self {
        if yes {
            H      s::AllowMissingPositional)
        } else {
            self.uH      s::AllowMinto_option();
  I
      /// Specifies
  fully if   runtilongnt mand.
       self
    mmand::long_flag_aliases`].
    ///
    /// # Examples
    ///
    /// ```rust
    /// # use clap_builder as clap;
    nt ma::Et maKi    /// # uselap:nt and, Arg, };
    /// let m = Command::new("myprog_("arg2")
    /m = Command::new("myprog")
    ///     .subco/m = Command::ntry_be first!"))
    ///     .get_matches_fr  .get_m      "cust-ord", "--helpnames {
nt .is_nt ()ec!["myprog", "--testint .ubcomm_nt ().kifirs, Et maKi  ::settingthe help.
d", "--help"
)
    ///     )
    /// # ;
    /// ```
    ///
    /// [`subcommand`]first!"))/ ```
  w("myprog_("arg2")
 allow_missing_positional(self, yes: bool) -> Self {
        if yes {
            the help.
t_settin s::AllowMissingPositional)
        } else {
            self.uthe help.
t_settin s::AllowMi));
        }
   , ArgAunex       ine a CLI which has tl whe   /// ```
    without the precedi(but not required    s that wil`""`  /// the fat wilular subcomman   /// [`Command::alias`].
Uecify).
    ///
lp mecer  CL,ultiple hiddahortff unex        /// the // wil  }
      deflia*    /// // Assume there)ddle of the worrd; h*ecersnd tont mand.
 instea thist and   ///a intthei Assume there/ their parnes that tands as onuble order,heru/ `Com.
 in`    "skipper/
  roprind   mmand::long_flag_avariants.
  ``rut-in Set the placequiredre ows the   /// // Assume there verriescap **NOTEou supply a dmmand::long_flag_aliases`].
    ///
    /// # Examples
    ///
    /// ```rust
    /// # use clap_buildstubcffi::Os/ asse# use clap_builder as clap;
    /// # u Arg, ArgAction};
    /// // Assume there is an external subcommand named "subcmd"
    /// let m = Command::new("my/// // A_on as *visi
    /m = Command::nbe first!"))
    ///     .get_matches_fr  .get_m external    /rd.intl    Subcl    f .visi-- sel--", "baz1", "baz2", "baz3"
    //cedingr_arg`")
K (but not required    s tunplay orssume there'/ Set-"sync");//
      /mpty3"
    //cedreposi  /// the is ais *visiblis wing"]);
    /o_resettabaz1", "_eq!((/// // A, ///_m)) =>resettabaz1", """"""lap:n//_ctio: "baz")med///_mone);
    //Os/ asse>("(m.get_many::<Strinand_matches( ///      , "--testin// // A, externalnd_matches( ///      , "--testin//_ctio, [  /rd.intl    Subcl    f .visi-- sel-]nd_matches( ///}m      "cust-o_ =>re}m      "cu}
    ///     )
    /// # ;
    /// ```
    ///
    /// [`subcommand`]first!"));
    ///subcomman    ///
    subcommt!"));
    Et maKi  ::Unknowni(but noan    ///
 nt ma::Et maKi  ::Unknowni(but no::required()
    #/// // A_on as *visi
 allow_missing_positional(self, yes: bool) -> Self {
        if yes {
            self.E// // Athe help.
 gs::AllowMissingPositional)
        } else {
            self.unset_E// // Athe help.
 gs::AllowMinto_option();
        selfh ///odre ow /// // Assume there  (but notne, see the second exasame exare ow   //s on`Os/ asse`.  any oof CLIs wherexamNOT wii sing`/ asse` the
 ayed he order typemmand::long_flag_avariants.
S   ///
  final posisst"));
    ///   #/// // A_on as *visian   /// [`Command:commands.
    ///
    /// # Examples
    ///
    //unix/ # #[cfg(feature = "help")] {
    /// # use clap_buildstubcffi::Os/ asse# use clap_builder as clap;
    /// # u_builder as  Subc_re ow    /// # u Arg, ArgAction};
    /// // Assume there is an external subcommand named "subcmd"
    /// let m = Command::new("my/// // A_on as *visi
    /m = Command::nbe first!"))
    ///     .get_matches_fr  .get_m external    /rd.intl    Subcl    f .visi-- sel--", "baz1", "baz2", "baz3"
    //cedingr_arg`")
K (but not required    s tunplay orssume there'/ Set-"sync");//
      /mpty3"
    //cedreposi  /// the is ais *visiblis wing"]);
    /o_resettabaz1", "_eq!((/// // A, ///_m)) =>resettabaz1", """"""lap:n//_ctio: "baz")med///_mone);
    //Os/ asse>("(m.get_many::<Strinand_matches( ///      , "--testin// // A, externalnd_matches( ///      , "--testin//_ctio, [  /rd.intl    Subcl    f .visi-- sel-]nd_matches( ///}m      "cust-o_ =>re}m      "cu}
    /// "
    ///     ]);
    /// # }
   Examples
    ///
    /// ```rust
    /// # use clap_builder as clap;
    /// # u_builder as  Subc_re ow    /// # u Arg, ArgAction};
    /// // Assume there is an external subcommand named "subcmd"
    /// let m = Command::n/// // A_on as *vis_ Subc_re ow ( Subc_re ow !(/ asse)/m = Command::nbe first!"))
    ///     .get_matches_fr  .get_m external    /rd.intl    Subcl    f .visi-- sel--", "baz1", "baz2", "baz3"
    //cedingr_arg`")
K (but not required    s tunplay orssume there'/ Set-"sync");//
      /mpty3"
    //cedreposi  /// the is ais *visiblis wing"]);
    /o_resettabaz1", "_eq!((/// // A, ///_m)) =>resettabaz1", """"""lap:n//_ctio: "baz")med///_mone);
    /// asse>("(m.get_many::<Strinand_matches( ///      , "--testin// // A, externalnd_matches( ///      , "--testin//_ctio, [  /rd.intl    Subcl    f .visi-- sel-]nd_matches( ///}m      "cust-o_ =>re}m      "cu}
    ///     )
    /// # ;
    /// ```
  s  ///
    /// [`subcommand`]first!"))/ ```
 /// // A_on as *vis_ Subc_re ow (visible_long_flag_aliases(
re ow isplay_order(mut self,supw i:g(AppPe ow ator<Item = impl Into<Str>>     /// // A_ Subc_re ow medre ow        self.disp_ord = ord.into_resettable().into_option();
        self
    pped" wan  /// the prev not "skipped" w  /// ```
  s  mmand::long_flag_aByasame exa`er a`te:** Thi(but not betwehan creating muubleultiple hidd`<rna> [rna_ctio] <xterna> [xterna_ctio] <xtexterna> [xtexterna_ctio]`aliases to this subcomm    ///
disdisplf
       /// AalitCom.
 s// The   i(but not of  hidden subcombove e "ski*ot be* were just ananywinstand c//
    /// *   ///is *visibliker, bcom    /// With this setting pos     g invocations are pos<rna> <xterna> <xtexterna> [xtexterna_ctio]`ions are pos<rna> <xterna> [xterna_ctio]`ions are pos<rna> [rna_ctio]`ions areng_flag_aliases`].
    ///
    /// # Examples
    ///
    /// ```rust
    /// # use clap_builder as clap;
    /// # u clap::{Command};
    /// Command::new(s_conflicts_NOTE_on as *visi
    /;
    ///     )
    /// # ;
    /// ```
  s  ///
    /// [`subcommand`]first!"))/ ```
 ew(s_conflicts_NOTE_on as *visi
fn arg_required_else_help(self, yes: bool) -> Self {
        if yes {
            selssettiethe help.
 gs::AllowMissingPositional)
        } else {
            self.unelssettiethe help.
 gs::AllowMinto_option();
  Prev non creating muommanbeth tcon Args the   i(but not [optional]` has a defauByasame ex,or isnefault  tak easier
    /// `baz //s ped (i b8 co creating ,added in isn'Set the placequiredre ows the  ayed a[optional]` has a defaup message
    ///md -- ooa[op1a[op2s as  "visible" shotional)
   --------- ----------, "testall", "test_al// `baz e  ayed a[opti   ///     ]);
    /// # }
    omm    ///
instithit "skire ow mexamtop verriencoun/ /w the Set the plainstea tother regulgreedicomcon Ar")
K (but notonal]` has a defaup message
    ///md -- ooa[op1a[op2s as  "visible" shotional)
   --------- ----------, "testall", "test_al// `baz e as  "visible" shot  ]);
    /// # }
  liases`].
    ///
    /// # Examples
    ///
    /// ```rust
    /// # use clap_builder as clap;
    /// # use clap::{Command, Arg/md Command, };
    /nalnnew("myprog")
    ///     ew(")w("sync").long_flagthing"))
    ommand(Command::new(
    /   ommand(Command::new(").action(Arg.display_order(0)      .arg(Arg::new("bam      "cuaz2", "baz3"
    // Arg, ArgActio/na/// Command::nc
  e(/m = Command::ntry_be first!"))
    &["rnal    /   o   ollec<Vec<3_m exte-]nm = Command::nubcommand_matches("sync"testim = Command::p();
    ///
    /// asse>("   om.get_many::<String>("baz").unwm = Command::&["ollec<Vec<3_m exte-]      "cuaz2", "bazpnames {
   /// let sync_matches = matw(").is_n  e(/az2", "baz3"
    // Arg, ArgActio/na/// Command::net sync_matbcommaand _overacti
    /m = Command::ntry_be first!"))
    &["rnal    /   o   ollec<Vec<3_m exte-]nm = Command::nubcommand_matches("sync"testim = Command::p();
    ///
    /// asse>("   om.get_many::<String>("baz").unwm = Command::&["ollec<Vec<3_]      "cuaz2", "bazpnames {
   /// let sync_matches = matw(").is_trin(ommand_name(), Some(/ ```
  w("myprog_bcommaand _overacti
 allow_missing_positional(self, yes: bool) -> Self {
        if yes {
            the help.
Pcommaand rentrg( s::AllowMissingPositional)
        } else {
            self.uthe help.
Pcommaand rentrg( s::AllowMi));
        }
   :** Th  /// ```
  s  mexaoent [`e the al posit not  /// orre addeisible aliases to this suanyways).
     validhadhe Set the pla whetp/ Avel/
  licettin   ///
 ` operatofirst optional p
      de bcom` operatofshich fe addeon};
 no Set the plafully iwm = Comma//
    /// *   /// what te:** validtExamplthe hei(but not to   /// `("arg2")
    /an   /// [om.
 ymplcommive no nt mansohich fe addeipper/u **NOlag` usSet the plainstea d not all aliased variants.
  isasame ext to       (//
   Set the plado**Nrd; honettie al posit not)aracters will be stripped.
    ///
    /// #  isar valu    ///
sh.
        t};
    /t manto '-',   ///` operatofirst optional p    /// # Examples
    ///
    /// ```rust
    /// # use clap_builder as clap;
    /// #nt ma::Et maKi    /// # uselap:nt and, Arg, };
    /// let m = Command::new("myprog_netties_("as .allow_missing_positional(true)
 fau").("arg2")
    ///         .reqew("myprog")
    ///     .subco/m = Command::ntry_be first!"))
    ///     .get_matches_fr  .get_      "cust-ord", "--helpnames {
nt .is_nt ()ec!["myprog", "--testint .ubcomm_nt ().kifirs, Et maKi  ::settingt_settini(but nod", "--help"
)
    ///     )
    /// # ;
    isanssau    ///
sh.
        t};
 nohich t
 /t manto '-',   ///` operatofirst opor is// # ;
  ag` usSet the plaih as iftional p    /// # Examples
    ///
    /// ```rust
    /// # use clap_builder as clap;
    /// #nt ma::Et maKi    /// # uselap:nont and, Arg, };
    /// let m = Command::new("myprog_netties_("as .allow_missing_positional(true)
 fau").("arg2")
    ///         .reqew("myprog")
    ///     .subco/m = Command::ntry_be first!"))
    ///     .get_matches_fr  .get_ases(["_      "cust-ord", "--helpnames {
nont .is_ok()ec!["myprog"
)
    ///     )
    /// # ;
    /// `("arg2")
    /an    ///
    /// [required]: c;
    /// ```
  s  ///
    /// [`subcommand`]first!"))/ ```
 ew("myprog_netties_("as  allow_missing_positional(self, yes: bool) -> Self {
        if yes {
            the help.
ssettiet_ss s::AllowMissingPositional)
        } else {
            self.uthe help.
ssettiet_ss s::AllowMi));
        }
  Mer
    -pers AalitCo.getram// This wsigned a dbinaryrt!(s (`tiov[0]`)aracters will be Afr er
 e-of"u  ecu.disp};
   tingleu  ecu.disptional p
     et `lon*NOlagriet   //
  letsed. This is modec[`es   }

 
  letnto runy assigned a dher* t/// or    .he second exa  ecu.disp}of CLIse-ofowermmandifferthe is as b8 t and easiard links accessed v symbolic linksnto italiases to this subcommisasasirdisp}fma:o this su- Eas/// T asbr  CL,   tingleubinaryr     ef Cinstahe iardlinksnto lows t// ordifferthe      "custpers Aalitinal name anu- Minimalubinaryrord: b8 siarth tcommnedrd c (e.g. standard library,der a) name anu- Cmplmanshellr, whREPLs   eon}ddeon};
r co  tingleuetp- Avel/  "visible" short flag sS   ///
` er
 e-of`acequicersn name anu- `tiov[0]`This aler,
    / multey ass// search re ows the/ or  valufirst op, /// m      "custt"));
    /no_binary// as`][));
    /no_binary// as]atch  {
l name anu- H   ///  nt masnto     rtn creating multiautom/ `-eon}ddeuetp- Avel/  "visible" short flag sWerridingSet the plaih '-',fully iw}ddeon}l whshe m Asst
   gselfalidmay /mploy,ddepenIf you supplynedalirMatche:o this su- L     se/t manper:<Stie up '-rm/ `Co this su-  ///    t    alize  nt mable* from//
    /e      "custt"Et ma::et `ssa`][/
    /Et ma::et `ssa]o this su-  ///   wilud`] ][));
    /write_d`] ] bu  }

  migh', "sambiguouso this su- Disdisp
` er
 e-of`a plar -pe ow ito this su- Disdisp
` er
 e-of`a plar -pe ow it   ///
     }
}

 as  "visible" short flag sWerridetrin
    /e nt mabet di  CL,  wilulEt maKi  ies
 r cosuen aliasesshe Set- as  "visible" shotmigh',    rtnmmands arnt ma.  Endisptional p
[`//   #/// // A_on as *visian[));
    ///   #/// // A_on as *visi]   validwantnto     }
}
/ `Co this sug     seuncomognize  binaryrt!(sd not all aliased variants.
Mer
 e-of ef 'tCLIs wher  ///[`no_binary// as`] tincetom/ `in/ /fultne only needse there is ae ordne this
    waynd not all aliased variants.
    mer
 e-of e there != '-',haveK (but notonal]` has a defauvariants.
   lets}l whsligh'ff ceher/
    /// fferthe rmmanon as *visied. This iso it'inalas *enI  / muuildt"));
    //w("myprog_d`] _d` If y`] isible" shott"));
    //w("myprog_ Subc_/ as`] ommanah t// ordesc,
 tive `ssaesshe ```mmand::long_flag_aliases`].
    ///
    /// # he t/ as`};
    //  ///
 //
 mer
 e-of   ecu.displ name anuBo/// he t/ as`}ere `dnsdomlon/ as`}ersubcovid(i b8 mmands arn ecu.disptional p
ere ve}

 behavilirM muuild;
  assigned a d  ecu.disp}     t!(sd not all aliased bcommisasasirdisp}verriding  ecu.disp}h///a irimaryrpurposn name anubu  }
eon};
 relnd      /// AalitCo /// lhat thiset venliase/odrcovid(tional p
ere play   }

i singbe fat wilds arn ecu.dispne, see the second exaher* t/// or/md ;
 s thhei Aff un whetional p
ere may beommands are addeaher* t//ale visible aliases to this subce is as t/// ori *edind n creating mut/// orC "visible" shotersumis wsigaglon*tultey assher* t/// or  valufirst op,ddle of the}

    // ven// Aalcom    hish t/// orn ecu.dispne, see the second eisaso**Nfor the e "ski/
    /// This alpasows the/ or  valunon-hish first op.    ///
    /// # Examples
    ///
    /// ```rust
    /// # use clap_builder as clap;
    nt ma::Et maKi    /// # uselap:ong_/md Command, };
    he t/ ast m = Command::nmer
 e-of
    /m = Command::new("myprog")
    ///     he t/ ast /m = Command::new("myprog")
    ///     dnsdomlon/ ascommand_name(nd named/mdntry_be first!"))
   _ong &["/usr/bin/he t/ astmatcnsdomlon/ ascrd", "--helpnames {
m.is_nt ()ec!["myprog", "--testim.ubcomm_nt ().kifirs, Et maKi  ::Unknowni(but nommand_name(nd named/mdnbe first!"))
    &["/usr/bin/cnsdomlon/ ascrd", "--helpnames testing"]);
    /// assert_eq!(mdnsdomlon/ ascommand_name(    )
    /// # ;
  Busybox};
   ayed acommned//  ///
 //
 mer
 e-of   ecu.dispddle of the///
  ]);
  /// Ts onea

 
  letnt    ef C alrunydiala'ff,ddle of te.g. lp messag`cat` 
  letnbeth truny ytrunn///
`busybox}cat`, accessed v lp me`cat` 
//a link/ multey`busybox` binaryd not all aliased bcommisasasirdisp}verridingla  /ed a.getram/h///add a CLI wfault s accessed v  t};
 uil// Oto runyding
  letnlp moutCinstahew the Symlinkddle of te.g.  mule*tultey
  letnlp moutCinstahew thito this su     hrsumiy th andy beoa e there t/// at is ae ostahe iftional p    /// #Toblikee   i  letnusdisp
///bo///
 mer
 e-of link/ere  e as  "visible" shot"ski/
    ///    ss for a /// **bo///fat wiletp- Avel/C "visible" shotens the creating mut/// or"mlon" i  let.    ///
    /// # Examples
    ///
    /// ```rust
    /// # use clap_builder as clap;
    /// # uf  i  let_as *visi
posit[));
   ; 2]resettabaz1", "[)
    ///     .   "ert)
    ///          ")]      "cu}
    /// lap:ong_/md Command, };
    busyboxt m = Command::nmer
 e-of
    /m = Command::new("myprog")
    ///     .subcommand(
    busyboxt m = Command::new("myprog")
    /_ Subc_/ as("APPLETt m = Command::new("myprog")
    /_d`] _d` If y("APPLETSt m = Command::new("myprog")
    /s(i  let_as *visi
pnwm = Command::/m = Command::new("myprogs(i  let_as *visi
pn   /// # u ArWerrie-ofowermman/ orn ecu.disp't of on e-o is ais *visibsibits}l  lets}ef C almis wsigasion as *visible* long(nd named/mdntry_be first!"))
   _ong &["/usr/bin/busyboxtases   "])nubcommand_matches("sync"testing"]);
    /// assert_eq!(mbusyboxt nd_matches("sync"testing"]);
    /(m.get_many:1g"]);
    /// assert_eq!(m.   "en   /// # u ArWerrie-ofowermmana link/is an aftere   i  letnhe   i  letn
  mis wsi.and_name(nd named/mdnbe first!"))
    &["/usr/bin/s   "])c!["myprog", "--testing"]);
    /// assert_eq!(m.   "en   /// # u    )
    /// # ;
    no_binary// as`]///
    /// [`subcno_binary// asble" shott"));
    //w("myprog_ Subc_/ as`]///
    /// [`subcommand`]fi_ Subc_/ asble" shott"));
    //w("myprog_d`] _d` If y`]///
    /// [`subcommand`]fi_d`] _d` If yt!"))rate::Arg::required()mer
 e-of
 allow_missing_positional(self, yes: bool) -> Self {
        if yes {
            Mer
 e-of s::AllowMissingPositional)
        } else {
            self.uMer
 e-of s::AllowMi();
        }
       / or Subcois ae whers onube help.
   errip/// w thu from thehis subcommand within Byasame ex,oand`].
 "COMMAND"mand, and not all variants.
    ///
   w("myprog_d`] _d` If y`] hidden from help messages
    ///
    /// # Examples
    ///
    /// ```rust
    /// # use clap_builder as clap;
    /// # use clap::{Command, Arg};
    /// Command::new("myprog")
    ///     ew(1t /m = Command::np/// _d`] (").hide(true)
    ///     )
    /// # ;
  cequi;
 duc the following help message
    //g};
  / ```text
    /// cust-og};
  "[)OMMAND/ Usage: cust-ord [OPTIONS]
    ///
    ptions:
 ///   w The * from     heption /// originallp     Print help for)
    w(1help for the subcommand(s)
    ///
    /// Options:
    ///     -h, --help       Print help
    ///     -V, --version    Prinfor the subcbu  u from //`/w("myprog_ Subc_/ as`    ///
    /// # Examples
    ///
    /// ```rust
    /// # use clap_builder as clap;
    /// # use clap::{Command, Arg};
    /// Command::new("myprog")
    ///     ew(1t /m = Command::nog")
    /_ Subc_/ as("THING"/m = Command::np/// _d`] (").hide(true)
    ///     )
    /// # ;
  cequi;
 duc the following help message
    //g};
  / ```text
    /// cust-og};
  "[THING/ Usage: cust-ord [OPTIONS]
    ///
    ptions:
 ///   w The * from     heption /// originallp     Print help for)
    w(1help for the subcommand(s)
    ///
    /// Options:
    ///     -h, --help       Print help
    ///     -V, --version    Prin"test"));
    /// ```
  g")
    /_ Subc_/ as(
    pub f Subc_/ as_flag_alias(mut self, name: impl IntoResettabl     ig")
    /_ Subc_/ asmed Subc_/ as       self.disp_ord = ord.into_resettable().into_option();
       / orptiond` If ye whers onube help.
   errip/// w thu from thehis subcommand within Byasame ex,oand`].
 "Chelp.
 "mand, and not all variants.
    ///
   w("myprog_ Subc_/ as`] hidden from help messages
    ///
    /// # Examples
    ///
    /// ```rust
    /// # use clap_builder as clap;
    /// # use clap::{Command, Arg};
    /// Command::new("myprog")
    ///     ew(1t /m = Command::np/// _d`] (").hide(true)
    ///     )
    /// # ;
  cequi;
 duc the following help message
    //g};
  / ```text
    /// cust-og};
  "[)OMMAND/ Usage: cust-ord [OPTIONS]
    ///
    ptions:
 ///   w The * from     heption /// originallp     Print help for)
    w(1help for the subcommand(s)
    ///
    /// Options:
    ///     -h, --help       Print help
    ///     -V, --version    Prinfor the subcbu  u from //`/w("myprog_d`] _d` If y`    ///
    /// # Examples
    ///
    /// ```rust
    /// # use clap_builder as clap;
    /// # use clap::{Command, Arg};
    /// Command::new("myprog")
    ///     ew(1t /m = Command::nog")
    /_d`] _d` If y("Thself"/m = Command::np/// _d`] (").hide(true)
    ///     )
    /// # ;
  cequi;
 duc the following help message
    //g};
  / ```text
    /// cust-og};
  "[)OMMAND/ Usage: cust-ord Thself]
    ///
    ptions:
 ///   w The * from     heption /// originallp     Print help for)
    w(1help for the subcommand(s)
    ///
    /// Options:
    ///     -h, --help       Print help
    ///     -V, --version    Prin"test"));
    /// ```
  g")
    /_d`] _d` If y(
    pub fd` If y_flag_alias(mut self, name: impl IntoResettabl     ig")
    /_d` If ye=fd` If y       self.disp_ord = ord.into_resettable().into_optptie(trueReftrinV, -lag_a)
    /toResett version
    //  /// ```rust
 u fro")]     / `(/
   )``
 be fu fro_/ as(&().i: impommand<&sametoResettabl     u fro_/ as.as_st
ef(").hidption();
  G     seher* t/// orbinaryd not rate::Arg::required()be f   #[mus/ as(&().i: impommand<&sametoResettabl        #[mus/ as.as_st
ef(").hidption();
  G     seher* t/// orbinaryd not rate::Arg::required()be fbins/ as(&().i: impommand<&sametoResettabl     bins/ as.as_st
ef(").hidption();
      binaryrt!(sd
Uecs `&
    pub`ainstea tot/`/pub`.   /// ```
  e fbins/ as(&n visible_long_flag_alias// asse>)toResettabl     bins/ asst
 -> Self mes.int_resettption();
  G     seher* t/// or/mdn not rate::Arg::required()be f/ as(&().i: imp&samtoResettabl     / as.as_sam(").hidption()t version
    //  // s in names and()]     / `(/
   )``
 be f/ as_sam(&().i: imp&SamtoResettabl&     / asesettption();
  G     sent help
t/// or/mdn not rate::Arg::required()be fnt help(&().i: impommand<&sametoResettabl     nt help.as_st
ef(").hidption();
  G     seich fnt help
t/// or/mdn not rate::Arg::required()be f     nt help(&().i: impommand<&sametoResettabl          nt help.as_st
ef(").hidption();
  G     seauthmasnt/// or/mdn not rate::Arg::required()be fauthma(&().i: impommand<&sametoResettabl     authma.as_st
ef(").hidption();
  G     seich functiot/// ore visible aliaserate::Arg::required()be fmand(Comman&().i: impommand< impltoResettabl     iand(Comma).hidption();
  G     seich fnctiot/// ore visible aliaserate::Arg::required()be fmand(Comma&().i: impommand<&sametoResettabl          Comm.as_st
ef(").hidption();
  G     sed`] should b     }
}he subct"));
    //// S  mmand::long_flag_at"));
    //// S      /// [`Co// So) not rate::Arg::required()be fa// So&().i: impommand<&StyledSametoResettabl     a// S.as_
ef(").hidption();
  G     sed`] should b     }
}he subct"));
    /     /// S  mmand::long_flag_at"));
    /     /// S  mmand::long_flago// So) not rate::Arg::required()be f_flago// So&().i: impommand<&StyledSametoResettabl     _flago// S.as_
ef(").hidption();
  G     secmplmansrinV, nd` If ye    }
}he subct"));
    /nssa_d`] _d` If y`]mmand::long_flag_at"));
    /d`] _d` If y`]//));
    /d`] _d` If yo) not rate::Arg::required()be fnssa_d`] _d` If ya&().i: impommand<&sametoResettabl     currthe_d`] _d` If y.as_st
ef(").hidption();
  ,
    eommrougmessagliases, wh/// Sets/     iple visible aliaserate::Arg::required()be fn  #[must_use]
 &().i: implag_al
        names:&samet+ '_= impl Into<Str>>) -> Self {
              elf {
        fil    |(_,    )|glias elf {
        .extea| a.0.as_sam("").hidption();
  ,
    eommrougmessagliases, wh debug_asseets/     iple visible aliaserate::Arg::required()be fn  #[must_use]
    pub fn v&().i: implag_al
        names: implt+ '_= impl Into<Str>t_use]
    pub fn elf {
              elf {
        fil    |(_,    )|glias elf {
        .extea| a.0").hidption();
  ,
    eommrougmessagliases, which feasseets/     iple visible aliaserate::Arg::required()be fn  #[must_use]
    pub fn &().i: implag_al
        names:&samet+ '_= impl Into<Str>t_use]
    pub fnelf {
              elf {
        fil    |(_,    )|glias elf {
        .extea| a.0.as_sam("").hidption();
  ,
    eommrougmessagamplt//*all*   seaasseets/     iple visible ,*bo/// }

    /theh     n not rate::Arg::required()be fallst_use]
 &().i: implag_al
        names:&samet+ '_= impl Into<Str>>) -> S.       .extea| a.0.as_sam("").hidption();
  ,
    eommrougmessagamplt//*all*   se debug_asseets/     iple visible ,*bo/// }

    /theh     n not rate::Arg::required()be fallst_use]
    pub fn v&().i: implag_al
        names: implt+ '_= impl Into<Str>t_use]
    pub fn .       .extea| a.0").hidption();
  ,
    eommrougmessagamplt//*all*   seich feasseets/     iple visible ,*bo/// }

    /theh     n not rate::Arg::required()be fallst_use]
    pub fn &().i: implag_al
        names:&samet+ '_= impl Into<Str>t_use]
    pub fn.       .extea| a.0.as_sam("").hidption()rate::Arg::requir(/
   )``
 is_teSo&().i, s:        self: imping_= impl Into<Str>t   self.is_teSof: ||o<Str>g_t   self.is_teSof:).hidption();
   that twisetl needs tutput?::required()be fetl n &().i: impCtl nChoicgPositional) s in!("));
    /etl n:pCtl n *   ///...lnd_self, yes: b  /!// ```rust
 etl n"_resettable().in: b<Str>is_teSo       self.uCtl nNhe m_resettable().innal) s in!("Nhe mt alias name can .subcl nChoicg::Nhe mlias name canissingP: b<Str>is_teSo       self.uCtl nAlwayn_resettable().innal) s in!("Alwaynt alias name can .subcl nChoicg::Alwaynlias name canissingPesettable().innal) s in!("Autot alias name can .subcl nChoicg::Au the orsible_long_flag_alissingPesettable().inbcl nChoicg::Nhe mlias namei();
        }
  Re``rn   secmrrtheg`/ yles`//     he to
    /liaserate::Arg::required()be fm yles(&().i: imp&Sayles= impl Into<Str>>pp#///nbe (m.get_ma_or_same ex(").hidption();
  ,
    eommrougmessagamplt//on as *visie)be tw the 
eferthcetoonea

aliaserate::Arg::required()be fmw("myprogs(&().i: implag_al
        names:&to
    >toResettabl     ig")
    /s       elf {ption();
  ,
    eommrougmessagamplt//on as *visie)be tw the mu.disp}
eferthcetoonea

aliaserate::Arg::required()be fmw("myprogs_ong &n visibl: implag_al
        names:&n vito
    >toResettabl     ig")
    /s     _ong )();
        }
  Re``rns `.   ` automati to
    //h///on as *visible* lrate::Arg::required() as_sw("myprogs(&().i: imping_= impl Into!     ig")
    /s  s_/mpty )();
        }
  Re``rns / orptiond` If ye/   li_from/on as *visible* lrate::Arg::required()be fmw("myprog_d`] _d` If ya&().i: impommand<&sametoResettabl     ig")
    /_d` If y.as_st
ef(").hidption();
  Re``rns / or/
    /// T Subcois able* lrate::Arg::required()be fmw("myprog_ Subc_/ as(&().i: impommand<&sametoResettabl     ig")
    /_ Subc_/ as as_st
ef(").hidption();
  Re``rns / orptiond` If ye/   li_from/on as *visible* lrate::Arg::required()be fbe/  e_d`] o&().i: impommand<&StyledSametoResettabl     be/  e_d`] .as_
ef(").hidption();
  Re``rns / orptiond` If ye/   li_from/on as *visible* lrate::Arg::required()be fbe/  e_t_used`] o&().i: impommand<&StyledSametoResettabl     be/  e_t_used`] .as_
ef(").hidption();
  Re``rns / orptiond` If ye/   li_from/on as *visible* lrate::Arg::required()be faftered`] o&().i: impommand<&StyledSametoResettabl     aftered`] .as_
ef(").hidption();
  Re``rns / orptiond` If ye/   li_from/on as *visible* lrate::Arg::required()be fafteret_used`] o&().i: impommand<&StyledSametoResettabl     afteret_used`] .as_
ef(").hidption();
  FinusSet the plauble       tsther* thean [`ffeasseetsequalti / as`ne, see the second eisaso**Nfor recmrseommrougme creating mut//on as *visible* lrate::Arg::required()finufmw("myprogo&().i, long_flag_aAsRef<stubcffi::Os/ a>: impommand<&to
    >toResettabllap:n asst
/ as as_
ef("resettable().i.be fmw("myprogs().finu(|s|o<>>) -> S_toSelf )").hidption();
  FinusSet the plauble       tsther* thean [`ffeasseetsequalti / as`, re``rnf you supplye mu.disp}
eferthcetoon/ ore visible aliasee the second eisaso**Nfor recmrseommrougme creating mut//on as *visible* lrate::Arg::required()finufmw("myprog_ong Resettabl&ong_flag_aliases(
    _flag_aAsRef<stubcffi::Os/ a>tor<Item = ommand<&n vito
    >toResettabllap:n asst
/ as as_
ef("resettable().i.be fmw("myprogs_ong ).finu(|s|o<>>) -> S_toSelf )").hidption();
  ,
    eommrougmessagamplt//groupible* lrate::Arg::required()be fgroupi(&().i: implag_al
        names:&ArgGroupetoResettabl     groupib      elf {ption();
  ,
    eommrougmessagamplt// (but notonal]`rate::Arg::required()be fa(but not(&().i: implag_al
        names:&ArgetoResettabl     arlf.ction").hidption();
  ,
    eommrougmessagline a CLI s*/ (but notonal]`rate::Arg::required()be fine a CLI s(&().i: implag_al
        names:&ArgetoResettabl     be fa(but not() fil    |a| a. s_ine a CLI ("").hidption();
  ,
    eommrougmessaglfault s*.::required()be ffaus(&().i: implag_al
        names:&ArgetoResettabl     be fa(but not()elf {
        fil    |a| a. s_tiker_ Subc_teSo) && !a. s_ine a CLI ("").hidption();
  G   a li_f[`ffea which has t/ originalfirst opoconflictsnlp maliasee the secondI/// orrcovid(i first oporsasaclaratofshglob A, eedse nflictsnlpands wie   m// * the subcbassigned a d ropagettin rulas t//glob AK (but notonal]` has a defau### Panicsliasee the secondI/// originalfir et `lon*NOle nflictthe///
alfirst opo      deunknownn the order thati to
    /.::required()be fa(b_conflicts_NOTEo&().i, a(b::&Arg: imp"baz&Arget
  FIXME: any oohat t robdisy,haveKbehanf Ci
      ::req(self, yes: ba(b. s_glob A_teSo) ositional)
        be fglob A_a(b_conflicts_NOTEoag( s::AllowMissingPositional)
   lap:ong_res exa=p"ba//     alias name can/   i thata(b.blackli_fb      Pesettable().innal): blap: -> Sag( n names finu(id Pesettable().innal)))))res ex   selag( alias name can .suissingP: blap: -> Sgroup n names finufgroup(id Pesettable().innal)))))res ex /// og")
                            } rolA_a(bs_infgroup(&group.id))
                                  elf {
                        .exteid|names finu(id .ex    (INTERNAL_ERROR_MSGpnwm = CCCCCCCCCCCCCCCCC alias name can .suissingPesettable().innal)))))panic!("));
    /be fa(b_conflicts_NOTE:ubce pasows tir et flictsnlp m/
alfireunknownn t// or/mdt alias name can .su}
name can .su}
name can .sures exlias namei();
        }
 G   a uniqbcoli_f[`ffea which has t`ffea weating mulre !o/ w uouse creating mu/ originalfirst opoconflictsnlp maliasee      }
 any obehavilr/s ped sd a d ropagettin rulas t//glob AK (but notonal]` hal
};
 uil// O/   finuth tconflictsn/   hich has tsaclaratofshglob Aaliasee      }
 ### Panicsliasee nal]` hal/// originalfir et `lon*NOle nflictthe///
alfirst opo      deunknownn the orde thati to
    /.::reqd()be fglob A_a(b_conflicts_NOTEo&().i, a(b::&Arg: imp"baz&Arget
  FIXME: any oohat t robdisy,haveKbehanf Ci
      ::req(self, yesa(b.blackli_felf {
              elf {
        .exteid|nesettable().innal)     arlfsettable().innal))))).ction").hidble().innal))))).chlon")
                            be fmw("myprogs_et `lonf yaag( s::AllowM                           elf {
                        fla firxtex| x arlf.ction"nwm = CCCCCCCCCCCCCCCCC ).hidble().innal))))).finu(|cti|sa(b.be fi/o_r== id))
                   .ex    (elf {
                   "));
    /be fa(b_conflicts_NOTE:u\elf {
               bce pasows tir et flictsnlp m/
alfireunknownn t// or/mdtwm = CCCCCCCCCCCCCCCCC ).hidble().in} elf {
        :<Strinan();
        }
 G   a li_f[`ffube help.
   e}

 et `lon// orrcovid(i Airst optional      }
 any o the placequi bcomincludki/
    ///    ordtsnli_f[/    e}

 "ski/
    ///       }
 re addeants.et `lon*N"skiAirst op.    ///     }
 any osear

 s ped sd a d ropagettin rulas t//glob AK (but notonal]` hal
};
 uil// Oto  inuth ton as *visie)     haveKinheritee  eglob AK (but no.    ///     }
 variants.
In thatiordei bcomSu"myprog_1nlpands wincludk* the su, "_w("myprog_1 (et `lon*Nrg( s::Alaz1", "_w("myprog_1.1 (so** 'tCet `lon/rg( s::Alaz1", " "_w("myprog_1.1.1 (et `lon*Nrg( s::Alaz::reqd()be fmw("myprogs_et `lonf ya&().i, a(b::&Arg: imp"baz&l In>toResettabllap:ong_vecn natubcvba//"ba//     alias name/   i x  or0..     ig")
    /s len(_resettable().in: b<Str>ig")
    /s[i x]
ble().innal))))).ctio
ble().innal))))).ction").hidble().innal).any(|ct|sa(.be fi/o_r== a(b.be fi/o_").hidble().inesettable().innal)vba   sel&<Str>ig")
    /s[i x] alias name can .suvba appenI &n visibl>ig")
    /s[i x] be fmw("myprogs_et `lonf yaag(  alias name can}
name can}
name canvba).hidption();
  Re  rtnwheyed at"));
    /no_binary// as`] // *  ::required()is_n _binary// as_teSo&().i: imping_= impl Into<Str>is_teSo       self.uNoBinaryNlf )).hidption();
  Re  rtnwheyed at"));
    /ign  e_nt mas`] // *  ::requir(/
   )``
 is_ign  e_nt mas_teSo&().i: imping_= impl Into<Str>is_teSo       self.uIgn  eEt mas)).hidption();
  Re  rtnwheyed at"));
    /dt `_delimit__arg`")
_ Subcs`] // *  ::required()is_dt `_delimit__arg`")
_ Subcs_teSo&().i: imping_= impl Into<Str>is_teSo       self.uDt `DelimitTarg`")
g(Apps)).hidption();
  Re  rtnwheyed at"));
    /disdisp nt helpe]
  `] // *  ::required()is_disdisp nt helpe]
  _teSo&().i: imping_= impl Into<Str>is_teSo       self.uDisdispVt helpF
  ").hidble().in|| (     nt help.is_n  e(/ &&           nt help.is_n  e(/a).hidption();
  Re  rtnwheyed at"));
    / ropagetp nt help`] // *  ::required()is_ ropagetp nt help_teSo&().i: imping_= impl Into<Str>is_teSo       self.uPropagetpVt helpa).hidption();
  Re  rtnwheyed at"));
    /nssa_::Ared`] `] // *  ::required()is_nssa_::Ared`] _teSo&().i: imping_= impl Into<Str>is_teSo       self.uNssaL:ArH   )).hidption();
  Re  rtnwheyed at"));
    /disdisp d`] _]
  `] // *  ::required()is_disdisp d`] _]
  _teSo&().i: imping_= impl Into<Str>is_teSo       self.uDisdispH   F
  ").hidption();
  Re  rtnwheyed at"));
    /disdisp d`] _/// ```
     // *  ::required()is_disdisp d`] _mw("myprog_teSo&().i: imping_= impl Into<Str>is_teSo       self.uDisdispH   Sume there)ddle ption();
  Re  rtnwheyed at"));
    /disdisp etl neded`] `] // *  ::required()is_disdisp etl neded`] _teSo&().i: imping_= impl Into<Str>is_teSo       self.uDisdispCtl nedH   )).hidption();
  Re  rtnwheyed at"));
    /d`] _ex      `] // *  ::req//  // s in names and()]     / `(/
   )``
 is_d`] _ex      _teSo&().i: imping_= impl Into<Str>is_teSo       self.uH   Ex      ").hidption()radoc(h     )n
    //  /_att (visible_l/ ```rust
 debcomnd  twm = CCCCCdebcomnd  (tincett
 4.0.0",Nforett
 bcommisan e "skisame ex"/m = C)]::required()is_dt `_:<Stapse_a(bs_infu fro_teSo&().i: imping_= impl Into.   ).hidption();
  Re  rtnwheyed at"));
    /inferet_usea(bs`] // *  ::requir(/
   )``
 is_inferet_usea(bs_teSo&().i: imping_= impl Into<Str>is_teSo       self.uInferL_usnels)).hidption();
  Re  rtnwheyed at"));
    /infere/// ```
  s  m// *  ::requir(/
   )``
 is_inferemw("myprogs_teSo&().i: imping_= impl Into<Str>is_teSo       self.uInferthe help.
 gs::Alption();
  Re  rtnwheyed at"));
    /a(b_/ [requi_singed`] `] // *  ::required()is_a(b_/ [requi_singed`] _teSo&().i: imping_= impl Into<Str>is_teSo       self.unelt_settinEingH   )).hidption()radoc(h     )n
    //  /_att (visible_l/ ```rust
 debcomnd  twm = CCCCCdebcomnd  (sitional)
    incett
 4.0.0",sitional)
   forett
 Re lacher  /// /// `is_a/   #hyphen_ Subcs_teS`"
CCCCCCCC ).hid)]     / `(/
   )``
 is_a/   #hyphen_ Subcs_teSo&().i: imping_= impl Into<Str>is_teSo       self.un/   Hypheng(Apps)).hidption()radoc(h     )n
    //  /_att (visible_l/ ```rust
 debcomnd  twm = CCCCCdebcomnd  (sitional)
    incett
 4.0.0",sitional)
   forett
 Re lacher  /// /// `is_a/   #nettiive_numbers_teS`"
CCCCCCCC ).hid)]     / ```
 is_a/   #nettiive_numbers_teSo&().i: imping_= impl Into<Str>is_teSo       self.un/   NettiiveNumbers").hidption()radoc(h     )n
    //  /_att (visible_l/ ```rust
 debcomnd  twm = CCCCCdebcomnd  (tincett
 4.0.0",Nforett
 Re lacher  /// /// `is__arg`")
_ Sracti_teS`" ).hid)]     / ```
 is__arg`")
_ Sracti_teSo&().i: imping_= impl Into<Str>is_teSo       self.uTarg`")
g(trg( s::Alption();
  Re  rtnwheyed at"));
    /a/   #metting_ine a CLI `] // *  ::required()is_a/   #metting_ine a CLI _teSo&().i: imping_= impl Into<Str>is_teSo       self.un/   settingPne a CLI )).hidption();
  Re  rtnwheyed at"));
    /dids`] // *  ::required()is_dids_teSo&().i: imping_= impl Into<Str>is_teSo       self.uH     )).hidption();
  Re  rtnwheyed at"));
    /mw("myprog_/ [requi`] // *  ::required()is_mw("myprog_/ [requi_teSo&().i: imping_= impl Into<Str>is_teSo       self.uthe help.
t_settin s::Alption();
  Re  rtnwheyed at"));
    /a/   #/// // A_on as *visian // *  ::required()is_a/   #/// // A_on as *visi_teSo&().i: imping_= impl Into<Str>is_teSo       self.un/   E// // Athe help.
 gs::Alption();
  Configuratore ow m/   // `bazpasows to l  /// // Assume there hidden from help messages    ///
    /// # Examples
    ///
    /// ```rust
    /// # use clap Arg/md Coer as clap;
 //     rawt m = Command::n/// // A_on as *vis_ Subc_re ow (er as  Subc_re ow !(/ asse)/# use clap Arg Subc_re ow med/mdnbe f/// // A_on as *vis_ Subc_re ow (/# use clapp/// ln!("{ Subc_re ow :?}"mmand_name(), Some(/ ```
 be f/// // A_on as *vis_ Subc_re ow (&().i: impommand<&supw i:g(AppPe ow aq(self, yes: b!<Str>is_a/   #/// // A_on as *visi_teSo_resettable().inN  es::AllowMissingPositional)
    ttiic DEFAULT: supw i:g(AppPe ow n naupw i:g(AppPe ow ::os_samf yo)alias name can -> S     /// // A_ Subc_re ow  as_
ef(".get_ma_or(&DEFAULT))lias namei();
        }
  Re  rtnwheyed at"));
    /a(bs_conflicts_NOTE_on as *visi`] // *  ::required()is_a(bs_conflicts_NOTE_on as *visi_teSo&().i: imping_= impl Into<Str>is_teSo       self.unelssettiethe help.
 gs::Alption()radoc(h     )n
    uired()is_a(bs_oent [`e_<Stro&().i: imping_= impl Into<Str>is_teSo       self.un/ nelsOent [`el In)).hidption();
  Re  rtnwheyed at"));
    /mw("myprog_bcommaand _overacti`] // *  ::required()is_mw("myprog_bcommaand _overacti_teSo&().i: imping_= impl Into<Str>is_teSo       self.uthe help.
Pcommaand rentrg( s::Alption();
  Re  rtnwheyed at"));
    /mw("myprog_netties_("as`] // *  ::required()is_mw("myprog_netties_("as_teSo&().i: imping_= impl Into<Str>is_teSo       self.uthe help.
ssettiet_ss s::Alption();
  Re  rtnwheyed at"));
    / er
 e-of`] // *  ::required()is_ er
 e-of_teSo&().i: imping_= impl Into<Str>is_teSo       self.uMer
 e-of s::Alptptie(alia // Aff ussignely-lag_a)
    /toReset/ `(/
   )``
 be foent [`e_u froo&().i: impommand<&StyledSametoResettabl     u fro_ttr.as_
ef(").hidption()/ `(/
   )``
 be foent [`e_d`] o&().i: impommand<&StyledSametoResettabl     d`] _ttr.as_
ef(").hidption()//  /// ```rust
 d`] ")]     / `(/
   )``
 be fd`] _t/mpl   o&().i: impommand<&StyledSametoResettabl     t/mpl   .as_
ef(").hidption()//  /// ```rust
 d`] ")]     / `(/
   )``
 be f   m_NOdTEo&().i: impommand<uord:>= impl Into<Str>>pp#///nbe ::<T  mWOdTE>   .extee| e.0").hidption()//  /// ```rust
 d`] ")]     / `(/
   )``
 be fmaxf   m_NOdTEo&().i: impommand<uord:>= impl Into<Str>>pp#///nbe ::<MaxT  mWOdTE>   .extee| e.0").hidption()/ `(/
   )``
 be fkey.ext&().i: imp&MKeyMaptoResettabl&     ctio
ble(ption()`
 be fu ui_glob A_a(bsa&().i, irst!")::&ArgMrst!"), glob A_a(b_vba/l&ong_"bazId>)toResettablglob A_a(b_vba /// og")
                arlfsettable().innal).ction").hidble().innal).fil    |a| a. s_glob A_teSo)").hidble().innal)..extega| ga. dnc
  e(/nwm = CCCCC)alias name: blap: -> S(id, irst!")) n n   /// let sync_ma(_resettable().in: blap: -> Su ui_et  n names finufet sync_ma(id Pesettable().innal)u ui_et .be fu ui_glob A_a(bsamrst!"), glob A_a(b_vba alias name can}
name can}
nameption()`
 _do_re ow Resettabl&ong_flag_aliases(
raw_a(bs/l&ong_/// `lex::Rawnels,self, yesa(bs_curs n:p/// `lex::nelCurs ntor<Item = C// Res ex<ArgMrst!")>Positional) s in!("));
    /_do_re owlnd_self, yes hal/// oon}l whglob AK (but not,  n *   ///stwisatche/odrcopagetp// om downn t//
    ///        yes habe/  eore o///
iniordeiwalrunyes.i  e as  "visible"          ```rus_<Stro     nd_self, yeslap:ong_mrst!" n nArgMrst!"r//    ().i:d_self, yes hadt// orre AKre o///self, yeslap:ong_re ow medPe ow ::    ().i:d_ble().in: blap:Err(nt ma n nre ow  be first!"))NOTEo&ong_mrst!" ,
raw_a(bs,sa(bs_curs n_resettable().in: b<Str>is_teSo       self.uIgn  eEt mas) && nt ma.u u_ttdnt ()Pesettable().innal) s in!("));
    /_do_re ow: ign  ///
nt ma: {nt ma}t alias name canissingPesettable().innal)re``rn:Err(nt ma alias name can}
name can}
self, yeslap:ong_glob A_a(b_vban nDame ex::same ex("resettable().i.be fu ui_glob A_a(bsa&mrst!" ,
&ong_glob A_a(b_vba:d_self, yesmrst!" . ropagetp glob Asa&glob A_a(b_vba:d_self, yesOk(mrst!" .d = oinnem("").hidption();
  Pcore ae/   intro    from/onfea wincludk*at"));
   `]sliasee the secondCea wthatioat wiletp- Avel/t"));
   `]  erridan [``rusw thendabe/  eor` If ye tetp/f  ::reqcondcseetslikdse t letand(,ecmplmanption utput, etc.::required()``rus &n visibl: {ble"          ```rus_recmrsive
    /;ble"          ```rus_bins/ ass_ina // A(_resettption()/ `(/
   )``
 ```rus_recmrsive
&n visible_exprog_d`] _treessing_po{ble"          ```rus_<Stroexprog_d`] _tree alias name/    as m that().i.be fmw("myprogs_ong )Positional)
    as m  ```rus_recmrsive
exprog_d`] _tree alias name}esettption()/ `(/
   )``
 ```rus_<Stro&n visible_exprog_d`] _treessing_po{ble"      s in!("));
    /_``rus:
/ as={:?}",t().i.be f/ asse:d_ble().in: b!<Str>t   self.is_teSo       self.uB`rut_resettable().in: blap: -> Sdefertin n names defertin.tike()Pesettable().innal)*amesn nSdefertin (atubcmem::tike(sibl: alias name can}
lias name can
  Mikees`rusea wthwhglob Aff cefunctis}l  lyM muui    well-> Self {
        if yes sn names if yes sn|o<Str>g_t   self;
settable().in: b<Str>is_ er
 e-of_teSo)nesettable().innal)     t   self.teSo       self.uthe help.
t_settin ;settable().innal)     t   self.teSo       self.uDisdispH   F
  ";settable().innal)     t   self.teSo       self.uDisdispVt helpF
  ";
name can .su}
name can .su: b!  /!// ```rust
 d`] ") &&      be foent [`e_d`] o).is_n  e(/ {settable().innal)     t   self.teSo       self.uDisdispH   F
  ";settable().innal)     t   self.teSo       self.uDisdispH   Sume there);
name can .su}
name can .su: b<Str>is_teSo       self.unelssettiethe help.
 gnesettable().innal)     t   self.teSo       self.uthe help.
ssettiet_ss ;
name can .su}
name can .su: b<Str>/// // A_ Subc_re ow  is_t-> Sgnesettable().innal)     t   self.teSo       self.un/   E// // Athe help.
 g;
name can .su}
name can .su: b!     das_sw("myprogs(/ {settable().innal)     t   self.teSo       self.uDisdispH   Sume there);
name can .su}
-> Self {
        _ ropagetpo)alias name can     _t!"ck_d`] _vis_ t help(exprog_d`] _tree alias name
        _ ropagetp_glob A_a(bsa);
settable().inlap:ong_ros_couna /st
1;settable().inlap:dids_pvn names is_teSo       self.uH  ePos

   g(Apps)alias name can/   athat().i.arlf.ctio_ong )Positional)
    can
  Fia winwthwhgroupisitional)
    can/   /
ini&a groupiPesettable().innal))))): blap: -> Sa( n names groupib    _ong ).finu(|grp| grp.idr== *g Pesettable().innal))))) yesag.arlf.  sela.be fi/o_nc
  e(/n;settable().innal)))))issingPesettable().innal)))))).inlap:ong_agn nArgGroup::    gn;settable().innal))))) yesag.arlf.  sela.be fi/o_nc
  e(/n;settable().innal)))))tabl     groupib  selagn;settable().innal)))))}lias name can .su}
sitional)
    can
  Figura outCit l}he t   selfsitional)
    cana ```rus(n;settable().innal): bdids_pvn&& a. s_tiker_ Subc_teSo) esettable().innal)))))a t   self.teSo rg    self.uH  ePos

   g(Apps)alias name can))))}lias name can .su: ba. s_ine a CLI ("n&& a. ndex.is_n  e(/ {settable().innal)))))a  ndexst
 -> Sros_couna /n;settable().innal)))))ros_couna /s+t
1;settable().in .su}
name can .su}
)
                arlf ```rus(n;s)
           #[a/   (debcomnd  )]).hidble().inesettable().innal)lap:dig!") fi/xn names)
                   .be fkey.ext))
                   .keyon").hidble().innal))))).fil   firxtex| esettable().innal)))))).in: blap:/
    /mkey.ex::KeyTyp  /Pne a CL(n n nx esettable().innal)))))).in can -> S*n elf {
                   issingPesettable().innal)))))).in).inN  es::AllowMias name can))))}lias name can .su).in} elf {
       ).innal)..exn").hidble().innal))))).get_ma_or(0n;settable().innal)letn
 __arg`")
_ Sracti_teSn names is__arg`")
_ Sracti_teSon;settable().innal)letn
 _a/   #hyphen_ Subcs_teSn names is_a/   #hyphen_ Subcs_teSon;settable().innal)letn
 _a/   #nettiive_numbers_teSn names is_a/   #nettiive_numbers_teSon;settable().innal)/   hicthat().i.arlf.ctio_ong )Positional)
    can).in: b
 _a/   #hyphen_ Subcs_teSn&& a(b. s_tiker_ Subc_teSo) esettable().innal))))) yesa(b.t   self.teSo rg    self.un/   Hypheng(Apps);settable().innal)))))}lias name can .su).in: b
 _a/   #nettiive_numbers_teSn&& a(b. s_tiker_ Subc_teSo) esettable().innal))))) yesa(b.t   self.teSo rg    self.un/   NettiiveNumbers";settable().innal)))))}lias name can .su).in: b
 __arg`")
_ Sracti_teSn&& a(b.be findexo_r==  -> Sdig!") fi/x) esettable().innal))))) yesa(b.t   self.teSo rg    self.uTarg`")
g(trg( ;settable().innal)))))}lias name can .su}
name can .su}
)
           //  // s in names and()]     )))) yesa, "--tl   ().i:d_ble().innal)     t   self.teSo       self.uB`rut_;s::AllowMissingPositional)
    s in!("));
    /_``rus:
th andy b`rut" alias name}esettption()/ `(/
   )``
 ```rus_<w("myprogo&n visible_long_f&samem = ommand<&n vil In>toResettabl    stubcfmt::Writed_self, yeslap:ong_mid_samf yst
 amf ybcf    " " alias name//  /// ```rust
 u fro")]      yes: b!<Str>is_mw("myprog_netties_("as_teSo) && !ames is_a(bs_conflicts_NOTE_on as *visi_teSo").hidble(ositional)
   lap:("asst
 cust-:    ().i:.be f/ [requi_u fro_
    &[],nN  e,     /;n
  maybe  -> Sm)
lias name can/      or&("assesettable().innal)mid_samf yb  se_sam(&(.to_samf yo) ;settable().innal)mid_samf yb  se(' ' alias name can}
name can}
name canletn
 _ er
 e-of_teSn names is_ er
 e-of_teSo)d_self, yeslap:scn na-> !(     ig")
    /s     _ong ).finu(|s|o<>n asstt
/ as):d_self, yes haD  #[musSet the pla/ as,e debug_plaich f oru froself, yeslap:ong_scs/ assst
 amf ybc     alias namescs/ assb  se_sam(sc / as.as_sam(" alias namelap:ong_]
  _tas m t=      alias name: blap: -> Sl n nac.be fmand(Comma) esettable().inwrite!( cs/ ass, "|--{l}")nubcommand_matcname can/
  _tas m t=     ;
name can}
name can: blap: -> Ss n nac.be fmand(Comman) esettable().inwrite!( cs/ ass, "|-{s}")nubcommand_matcname can/
  _tas m t=     ;
name can}

name can: b/
  _tas m tositional)
    cs/ assst
/  mat!("{{{ cs/ ass}}}" alias name}elias namelap:u fro_/ asn names)
            bins/ as)
            as_
ef(").hid).innal)..extebins/ as|
/  mat!("{bins/ as}{mid_samf y}{ cs/ ass}")").hidble().in.get_ma_or( cs/ ass alias namesc.u fro_/ asn n -> Su fro_/ as:d_self, yes habins/ asssthat t alpa add'sabins/ ass+ [<("as>]s+ "ski/c'sther* sore nd   byself, yes haa spacoself, yeslap:bins/ asst
/  mat!().hidble().in"{}{}{}",sitional)
        bins/ as.as_st
ef(".get_ma_or_same ex(",
name can .su: b<Str>bins/ as.is_t-> Sgne " "MissingPo ""Mi,
name can .su&*sc / asm = CCCCC)alias name s in!(
            "));
    /```rus_<w("myprog     sel:bins/ assof {}M mu{:?}",sitional)
    c./ as,ebins/ as)
        alias namesc.bins/ asst
 -> Sbins/ asnd_self, yes: bsc.   #[mus/ as.is_n  e(/ {settable().inlap:sStrf   #[mus/ asst
: b
 _ er
 e-of_teSn{settable().innal)        #[mus/ as.as_st
ef(".get_ma_or("")lias name canissingPesettable().innal)        #[mus/ as.as_st
ef(".get_ma_or(&     / as)lias name cani;settable().inlap:   #[mus/ asst
/  mat!().hidble().in).in"{}{}{}",sitional)
   nal)    f   #[mus/ as,lias name can .su: b!    f   #[mus/ as  s_/mpty ) esettable().innal)))))"-"lias name can .suissingPesettable().innal)))))""lias name can .sui,lias name can .su&*sc / asm = CCCCCCCCC alias name can s in!(
                "));
    /```rus_<w("myprog     sel:   #[mus/ assof {}M mu{:?}",sitional)
   
    c./ as,e   #[mus/ asm = CCCCCCCCC alias name cansc.   #[mus/ asst
 -> S   #[mus/ as alias name}elias name haEns`rusea wa(bs}l whb`rutg_pla andy /odre owlias namesc.```rus_<Stro     nd_self, yes -> Ssc)
nameption()`
 _``rus_bins/ ass_ina // A(&n visibl: {ble"      s in!("));
    /_``rus_bins/ asslnd_self, yes: b!ames is_teSo       self.uBinNlf B`rut_resettable().inlap:ong_mid_samf yst
 amf ybcf    " " alias namename//  /// ```rust
 u fro")]      yes yes: b!<Str>is_mw("myprog_netties_("as_teSo)lias name can .su&& !ames is_a(bs_conflicts_NOTE_on as *visi_teSo").hidble().inesettable().innal)lap:("asst
 cust-:    ().i:.be f/ [requi_u fro_
    &[],nN  e,     /;n
  maybe  -> Sm)
lias name can can/      or&("assesettable().innal)nal)mid_samf yb  se_sam(&(.to_samf yo) ;settable().innal)nal)mid_samf yb  se(' ' alias name can .su}
name can .su}
name can .suletn
 _ er
 e-of_teSn names is_ er
 e-of_teSo)d_self, yes).inlap:sStrfbins/ asst
: b
 _ er
 e-of_teSn{settable().innal)     bins/ as.as_st
ef(".get_ma_or("")lias name canissingPesettable().innal)     bins/ as.as_st
ef(".get_ma_or(&     / as)lias name cani).hidble().in.= orwnes(n;s)
           /    c  or&n visibl>ig")
    /sPesettable().innal) s in!("));
    /_``rus_bins/ ass:    :abins/ assset...lnd_self, yeself, yes: bsc.u fro_/ as.is_n  e(/ {settable().innal)))))    stubcfmt::Writed_ettable().innal))))) haD  #[musSet the pla/ as,e debug_plaich f oru froself, yesettable().inlap:ong_scs/ assst
 amf ybc     alias nameitional)
    cs/ assb  se_sam(sc / as.as_sam(" alias nameettable().inlap:ong_]
  _tas m t=      alias name).innal))))): blap: -> Sl n nac.be fmand(Comma) esettable().inettable().inwrite!( cs/ ass, "|--{l}")nubcommand_matcname canmatcname can/
  _tas m t=     ;
name can).innal)))))}lias name can .su).in: blap: -> Ss n nac.be fmand(Comman) esettable().inettable().inwrite!( cs/ ass, "|-{s}")nubcommand_matcname canmatcname can/
  _tas m t=     ;
name can).innal)))))}llias name can .su).in: b/
  _tas m tositional)
   itional)
    cs/ assst
/  mat!("{{{ cs/ ass}}}" alias name).innal)))))}llias name can .su).inlap:u fro_/ asn n/  mat!("{sStrfbins/ as}{mid_samf y}{ cs/ ass}")alias name).innal))))) s in!(
                        "));
    /```rus_bins/ ass:    :a    sel:u fro_/ asnof {}M mu{:?}",sitional)
   
   
   
    c./ as,eu fro_/ asm = CCCCCCCCCCCCCCCCC alias name can .sunamesc.u fro_/ asn n -> Su fro_/ as:d_ias name can .suissingPesettable().innal))))) s in!(
                        "));
    /```rus_bins/ ass::    :aUo///
exi_from/u fro_/ asnof {}M({:?})",sitional)
   
   
   
    c./ as,esc.u fro_/ asm = CCCCCCCCCCCCCCCCC alias name can .sui_self, yeself, yes: bsc.bins/ as.is_n  e(/ {settable().innal)))))lap:bins/ asst
/  mat!().hidble().inble().in).in"{}{}{}",sitional)
   nal)
   nal)    fbins/ as,settable().innal)))))).in: b!    fbins/ as  s_/mpty ) e " "MissingPo ""Mi,
name can .suname can .su&*sc / asm = CCCCCCCCCCCCCCCCC alias name can .suname s in!(
                        "));
    /```rus_bins/ ass:    :a    sel:bins/ assof {}M mu{:?}",sitional)
   itional)
    c./ as,ebins/ as)
       CCCCCCCCCCCC alias name can .sunamesc.bins/ asst
 -> Sbins/ asnd_ias name can .suissingPesettable().innal))))) s in!(
                        "));
    /```rus_bins/ ass::    :aUo///
exi_from/bins/ assof {}M({:?})",sitional)
   
   
   
    c./ as,esc.bins/ as)
       CCCCCCCCCCCC alias name can .sui_self, yeself, yes: bsc.   #[mus/ as.is_n  e(/ {settable().inble().inlap:sStrf   #[mus/ asst
: b
 _ er
 e-of_teSn{settable().innal)).innal)        #[mus/ as.as_st
ef(".get_ma_or("")lias name can        issingPesettable().innal)))))).in        #[mus/ as.as_st
ef(".get_ma_or(&     / as)lias name canname cani;settable().inble().inlap:   #[mus/ asst
/  mat!().hidble().in).in).in).in"{}{}{}",sitional)
   nal)
   nal)    f   #[mus/ as,lias name can .su can .su: b!    f   #[mus/ as  s_/mpty ) esettable().innal)))))nal)))))"-"lias name can .su        issingPesettable().innal)))))).in).in""lias name can .su        i,
name can .suname can .su&*sc / asm = CCCCCCCCCCCCCCCCC alias name can .suname s in!(
                        "));
    /```rus_bins/ ass:    :a    sel:   #[mus/ assof {}M mu{:?}",sitional)
   
   
   
    c./ as,e   #[mus/ asm = CCCCCCCCCCCCCCCCC alias name can .sunamesc.   #[mus/ asst
 -> S   #[mus/ as alias name can .suissingPesettable().innal))))) s in!(
                        "));
    /```rus_bins/ ass::    :aUo///
exi_from/   #[mus/ assof {}M({:?})",sitional)
   
   
   
    c./ as,esc.   #[mus/ asm = CCCCCCCCCCCCCCCCC alias name can .sui_self, yeself, yessc.```rus_bins/ ass_ina // A(_resettnal)))))}lias name can     t  o       self.uBinNlf B`rut_;s::AllowMissingPositional)
    s in!("));
    /_``rus_bins/ ass:
th andy b`rut" alias name}esettption()/ `(/
   )``
 `panic_on#metting_d`] o&().i,nptiof/ [requi_glob Affssing_po{ble"     : b<Str>is_teSo       self.uH   Ex      "n|| ptiof/ [requi_glob Affresettable().inlap:ctio_oetting_d`] :_"bazId>n names)
                arlfsettable().innal).ction").hidble().innal).fil    |ati|sa(b.be fd`] o).is_n  e(/ && a(b.be ft_used`] o).is_n  e(/a).hid.hid).innal)..extecti|sa(b.be fi/o_nc
  e(/n).hid.hid).innal).:<Strinand_self, yeself, s in names !(ctio_oetting_d`]   s_/mpty ),sitional)
   
   
   "));
    /d`] _ex       // endispd//     he)
    /to},ebng_atnlaa_f[`n [`ffdtsnhich has tso**Nfor haveKeiyed a`d`] `  n `t_used`] `sset. Li_f[`ffubchnhich has : {}",sitional)
   nal)
        / as,sitional)
   nal)
   ctio_oetting_d`]  join(", "n).hid.hid).innal) alias name}elias name/    astl    or&sibl>ig")
    /sPesettable().in astl  .`panic_on#metting_d`] optiof/ [requi_glob Aff alias name}esettption()//  // s in names and()]     / `(/
   )``
 two_a(bs_of<F>o&().i,ncond a CL: Fem = ommand<(&Arg,:&Arg:>     w oonlias nameF: Fn(&Arg: imping_,::req(self, yestwo_ele has _of(     arlf.ction".fil    |a: &&Ati|scond a CL(a)"").hidption();
 ju_f[iniorde
    #[a/   (unu ui)]     `
 two_groupi_of<F>o&().i,ncond a CL: Fem = ommand<(&ArgGroup,:&ArgGroup:>     w oonlias nameF: Fn(&ArgGroup: imping_,::req(self, yestwo_ele has _of(     groupib      .fil    |a| cond a CL(a)"").hidption();
  Pcopagetp/glob AK (bsion()/ `(/
   )``
 `propagetp_glob A_a(bsa&n visibl: {ble"      s in!("));
    /_propagetp_glob A_a(bs:{}",t().i./ asnd_self, yeslap:cutogen    ed d`] _mw("myprogn n!ames is_disdisp d`] _mw("myprog_teSond_self, yes/    c  or&n visibl>ig")
    /sPesettable().in: bsc.be f/ assestt
 d`] " && autogen    ed d`] _mw("myprognositional)
    can
  Avoidd ropagett the(bs} t// orautogen    ednptionmw(trees ussiginio t letand.sitional)
    can
  bcommprevhas te(bs}
   e dewrom/up dumf ysptione t letand(slikdsitional)
    can
  `myl   ptionmw( m t<TAB>`,  e}

 sthat t bcomsugge_f[ig")
    /sP pla/op:ctio,sitional)
    can
   e}l  stia wa/   t the(bs} t/ dew/up  ropercomoat wilgen    ednptionhould b.sitional)
    can!o/ w ue;
name can .su}
-> Self {
   /   athat().i.arlf.ctio() fil    |a| a. s_glob A_teSo)"Pesettable().innal): bsc.finu(&a. d) is_t-> Sgnesettable().innal))))) s in!(
                        "));
    /`rcopagetp/skippt th{:?}M mu{},eth andy exi_fs",sitional)
   
   
   
   a. d,sitional)
   
   
   
    c.be f/ asse,m = CCCCCCCCCCCCCCCCC alias name can .suname!o/ w ue;
name can .su .sui_self, yeself, yes s in!(
                    "));
    /`rcopagetp/  set th{:?}M mu{}",sitional)
   
   
   a. d,sitional)
   
   
    c.be f/ asse,m = CCCCCCCCCCCCC";settable().innal) c.arlf.  sela.c
  e(/n;settable().in}lias namei();
        }
  Pcopagetp/t   selfsitio/ `(/
   )``
 `propagetpa&n visibl: {ble"      s in!("));
    /_propagetp:{}",t().i./ asnd_ble().inlap:ong_sg")
    /sP natubcmem::tike(&n visibl>ig")
    /s alias name/    c  or&n visg")
    /sPesettable().in     _ ropagetp_<w("myprogosc);
name can}
name cansibl>ig")
    /sP=isg")
    /s;
nameption()`
 _ ropagetp_<w("myprogo&().i, sa/l&ong_Sibl: {ble"     
  We haveK muc antp/a new saope  ororst
  t//ea wamplct wilborrew/`ff`sc` //self, yes hadtn  /the t/recmrsivecomcea wthatimethod).hidble(ositional)
   : b<Str>i   self.is_teSo       self.uPropagetpVt helpaPesettable().innal): blap: -> Svt helpaP names nt help.as_
ef("nesettable().innal))))) c.nt help.be for_in "--tNOTEo|| nt help.c
  e(/n;settable().innal)}settable().innal): blap: -> S     nt helpaP names      nt help.as_
ef("nesettable().innal))))) c.     nt help.be for_in "--tNOTEo||      nt help.c
  e(/n;settable().innal)}settable().in}
)
            c if yes sn nac if yes sn|o<Str>g_t   self;

   
   
    c.b_if yes sn nac b_if yes sn|o<Str>g_t   self;

   
   
    c.>pp#///nupd   o&().i.>pp#/// alias name}esettption()/ `(/
   )``
 `t!"ck_d`] _vis_ t help(&n visible_exprog_d`] _treessing_po{ble"      s in!(
            "));
    /`t!"ck_d`] _vis_ t help:{}_exprog_d`] _tree={}",sitional)
        / as,eexprog_d`] _tree)
        alimpl Into<Str>t_used`] _exi_fsP names      d`] _exi_fs_(nd_self, yes: b!ames is_disdisp d`] _]
  _teSo)Positional)
    s in!("));
    /_t!"ck_d`] _vis_ t help: B`rusw thsame ex --d`] ");settable().inlap:ong_hict nArgbc    I  /HELPn).hid.hid).innal).mand(('h'n).hid.hid).innal).    ( d`] ")settable().innal).cca CL(ArgAca CL.uH   );settable().in: b<Str>t_used`] _exi_fsPesettable().innal)hict nhic).hidble().innal))))).d`] o"P/// nption(  e m  eo  ///'--d`] ')")lias name can        >t_used`] o"P/// nption(  e  e a;
 ryo  ///'-h')")alias name canissingPesettable().innal)hict nhic.d`] o"P/// nptio"_resettnal)))))}lias name can
  Avoidw th`cti_ina // A`e t//op:bp/t ne a veK mu`nssa_d`] _d` If y` /lias name can
  `nssa_   #[musorst
`)
                arlf   selag( alias name}self, yes: b!ames is_disdisp nt helpe]
  _teSo)Positional)
    s in!("));
    /_t!"ck_d`] _vis_ t help: B`rusw thsame ex -- t help");settable().inlap:hict nArgbc    I  /VERSIONn).hid.hid).innal).mand(('V'n).hid.hid).innal).    (  t help")settable().innal).cca CL(ArgAca CL.uVt helpa).hid).innal))))).d`] o"P/// n t help");settable().in
  Avoidw th`cti_ina // A`e t//op:bp/t ne a veK mu`nssa_d`] _d` If y` /lias name can
  `nssa_   #[musorst
`)
                arlf   selag( alias name}sself, yes: b!ames is_teSo       self.uDisdispH   Sume there)Positional)
    s in!("));
    /_t!"ck_d`] _vis_ t help: B`rusw thptionmw( );
   ");settable().inlap:d`] _vboutCt
 P/// nthatimeuld b      heption /// original<w("myprogos)";
settable().inlap:ong_d`] _mw("m t= : bexprog_d`] _treenositional)
    can
  S   e!odalpa/// t/recmrsivecomcltn  /qui yed aSet the plaub(trees unst
 d`] settable().innal)lap:d`] _mw("m t= clap;
 //     d`] ")settable().innal)nal).cbout(d`] _vbout)settable().innal)nal).glob A_teS selo       self.uDisdispH   Sume there)ddle .hid.hid).innal).mw("myprogs(().i.be fmw("myprogs()..ext));
    /_topy_ub(tree_/  _d`] )nd_self, yeself, yeslap:ong_d`] _d`] _mw("m t= clap;
 //     d`] ").cbout(d`] _vbout);settable().innal)d`] _d`] _mw("m .nt helpt= N  e;settable().innal)d`] _d`] _mw("m .     nt helpt= N  e;settable().innal)d`] _d`] _mw("m t= d`] _d`] _mw("m ddle .hid.hid).innal).meS selo       self.uDisdispH   F
  ").hidble().in).innal).meS selo       self.uDisdispVt helpF
  ";
settable().innal)d`] _mw("m .<w("myprogod`] _d`] _mw("m )lias name canissingPesettable().innal)clap;
 //     d`] ").cbout(d`] _vbout) arl(
                    Argbc    "mw( );
   ")sitional)
   
   
   
   .cca CL(ArgAca CL.uAppenI)sitional)
   
   
   
   .num_a(bsa..)sitional)
   
   
   
   . Subc_/ ass"COMMAND")sitional)
   
   
   
   .d`] o"P/// nption/     he<w("myprogos)"e,m = CCCCCCCCCCCCC"lias name cani;settable().in     _ ropagetp_<w("myprogo&ong_d`] _mw("m ";
settable().in
  bce_re ow macttslikdstcommisameS, soslap'sameS it sosweadtn't      lysettable().in
  adves angP:t} t// oruow 
ble().innal)d`] _mw("m .nt helpt= N  e;settable().ind`] _mw("m .     nt helpt= N  e;settable().ind`] _mw("m t= d`] _mw("m ddle .hid.hid).in.meS selo       self.uDisdispH   F
  ").hidble().in).in.meS selo       self.uDisdispVt helpF
  ").hidble().in).in.un "t_glob A_teS selo       self.uPropagetpVt helpa;
)
                ig")
    /s   seld`] _mw("m ";
ias name}esettption()`
 `topy_ub(tree_/  _d`] t&().i: impCmyprognositional)lap:ong_"m t= clap;
 //         / asnc
  e(/n).hid.hid).in.dids(ames is_dids_teSo/n).hid.hid).in.glob A_teS selo       self.uDisdispH   F
  ").hidble().in.glob A_teS selo       self.uDisdispVt helpF
  ").hidble().in.mw("myprogs(().i.be fmw("myprogs()..ext));
    /_topy_ub(tree_/  _d`] )nd_ble().in: b<Str>be fabout() is_t-> Sgnesettable().in/md Coem .about(<Str>be fabout() ubcomman.c
  e(/n;settable(}self, yes"m ddle ption()/ `(/
   )``
 `renst
_ t help(&sible_u u_    ssing_poimp amf y {ble"      s in!("));
    /_renst
_ t help"nd_self, yeslap:v /st
: bu u_    Pesettable().in          nt helpsettable().innal).cs_st
ef("settable().innal).or( mes nt help.as_st
ef("").hidble().in).in.unt_ma_or_same ex("s::AllowMissingPositional)
    mes nt helpsettable().innal).cs_st
ef("settable().innal).or( mes      nt help.as_st
ef("").hidble().in).in.unt_ma_or_same ex("s::AllowMid_ble().inlap:   #[mus/ asst
<Str>be f   #[mus/ as(".get_ma_or_singo|| ().i.be f/ asse:d_ble().in/  mat!("{   #[mus/ as} {nt }\p")settaption()/ `(/
   )``
 /  matfgroup(&sible_b::&Idpoimp ayledSamnositional)lap:g_samf yst
ames)
            } rolA_a(bs_infgroup( ").hidble().in.      elf {
        fil   firxtex| ames finu(x)").hid).innal)..extex| esettable().innal): bx. s_ine a CLI ("n{_ettable().innal))))) haP/// n  A_/ ass/   ine a CLI K (but noto e.g. <filc_/ as>_ettable().innal)))))x / as_n _bracketon").hidble().innal)issingPesettable().innal))))) haP/// nu fro samf ys/   fctis}l(but not, e.g. <--d`] >_ettable().innal)))))x to_samf yo)settable().innal)}settable().in} elf {
        :<Strin::<"baz_>>  elf {
        join("|"nd_ble().inlap:ong_sayledst
 ayledSambc     alias namesayledb  se_sam("<" alias namesayledb  se_samf yog_samf y alias namesayledb  se_sam(">" alias namesayleds::Alptptie(  A workarou   ie(  <https://github :<m/ampl-lang/ampl/issues/34511#issue"myp no-373423999>
/ `(/
   )`_argt Cap``rus<'a> {}-lag_<'a, T> Cap``rus<'a> /   T {}-ie(alia // A Query Methods-lag_a)
    /toReset/ hal
    e// roug
 "ski*fctis* & *ommands*  (but notonal]`//  //any(/ ```rust
 u fro", / ```rust
 d`] "))]     / `(/
   )``
 be fnon_ine a CLI st&().i: implag_aI
      <I
 mst
&Arget{esettable().i.be f (but not() fil    |a| !a. s_ine a CLI (")settaption()/ `(/
   )``
 /iogo&().i, cti_id::&Idpoimpommand<&Arget{esettable().i.arlf.ctio() finu(|c| a.be fi/o_r== a(b_i ").hidption()rain::Ar]     / `(/
   )``
 et `lon*fmand(o&().i, s: char: imping_= impl Into s in names !(sitional)
    mes is_teSo       self.uB`rut_,m = CCCCCCCCC"If ));
    /_``rus ha* 'tCbehancea ed, irnu Aff cear

 / roug
 Arge debus")
        alimpl Into<Str>arlf.et `lon*(s").hidption()rain::Ar]     / `(/
   )``
 teSo&n visible_s:        selfpo{ble"          t   self.teSos").hidption()rain::Ar]     / `(/
   )``
 das_ine a CLI st&().i: imping_= impl Into<Str>be fine a CLI st).nssa() is_t-> Sgesettption()//  //any(/ ```rust
 u fro", / ```rust
 d`] "))]     / `(/
   )``
 das_vi

   fmw("myprogs(&().i: imping_= impl Into<Str>/
    ///        yes).in.      elf {
        any(|sc|  c./ as !t
 d`] " && ! c.is_teSo       self.uH     )gs::Alption();
  C!"ck): btcommSet the placan:bp/refertin to ls `/ as`.
In  yed awordo,sitiocondc!"ck): b`/ as`misa"ski/ assof tcommSet the pla   is[`n [`ffdtsnhliseet.ion()rain::Ar]     / `(/
   )``
 hliseet_too&().i, long_flag_aAsRef<stubcffi::OsSame: imping_= impl Intolap:/ asst
/ as.as_
ef("resettable().i.be f/ assestt
/ ass|| ().i.be f-of_hliseet() any(|clise| hlisestt
/ as)s::Alption();
  C!"ck): btcommSet the placan:bp/refertin to ls `/ as`.
In  yed awordo,sitiocondc!"ck): b`/ as`misa"ski/ assof tcommSdebugfctimSet the pla   is[`n [`ffdtsnSdebugfctimhliseet.ion()rain::Ar]     / `(/
   )``
 mand(Comma_hliseet_too&().i, omma: char: imping_= impl Into -> Sommaestt
<Str>/and(Comma).hidble().in|| ().i.be f-of_mand(Comma_hliseet() any(|clise| fctim== alise)s::Alption();
  C!"ck): btcommSet the placan:bp/refertin to ls `/ as`.
In  yed awordo,sitiocondc!"ck): b`/ as`misa"ski/ assof tcomm    PfctimSet the pla   is[`n [`ffdtsn    Pfctimhliseet.ion()rain::Ar]     / `(/
   )``
 mand(Comm_hliseet_too&().i, omma: &samem = ing_= impl Intomrst!n          omma.as_
ef("nesettable().in -> S     ommaest>nesettable().innal)l    ommam== ommam|| ().i.be f-of_mand(Comm_hliseet() any(|clise| hlisestt
f
  ").hidble().in}settable().inN  est>n().i.be f-of_mand(Comm_hliseet() any(|clise| hlisestt
f
  ",lias name}esettption()//  // s in names and()]     / `(/
   )``
 id_exi_fso&().i, id::&Idpoimping_= impl Into<Str>arlf.ctio() any(|x| x.be fi/o_r== i "n||      groupib      .any(|x| x.idr== *in s::Alption();
  l
    e// roug
 "skigroupiPtcommhicthtimember[`f.     / `(/
   )``
 broupi_/  _hic<'a>(&'a ().i, cti::&Idpoimplag_aI
      <I
 mst
Id>n+ 'a {ble"      s in!("));
    /broupi_/  _hic_fld={hic_?}"nd_ble().inlap:hict nhic.c
  e(/resettable().i.broupisitional)
   .      elf {
        fil   (movss|grp| grp.arlf.      .any(|c| ar== &ag( ").hid).innal)..extegrp| grp.idnc
  e(/n).hidption()/ `(/
   )``
 /iogfgroup(&sible_broup_id::&Idpoimpommand<&ArgGroupet{esettable().i.broupib      .finu(|g| g.idr== *group_id s::Alption();
  l
    e// roug
 ea wthwh/ asss`ffea wig")
    /sP(/op:recmrsiveco),wincludt theliseet.ion();
  Uspd//   sugge_fand(.     / `(/
   )``
 hlA_on as *vis_/ asst&().i: implag_aI
      <I
 mst
&samet+ Cap``rus= impl Into<Str>be fmw("myprogs().f
 tfirxtesc| esettable().inlap:/ asst
<c.be f/ asse;settable().inlap:hliseetst
<c.be f-of_hliseet();settable().in tubc    ::once(/ as).chain(hliseet"s::AllowMin).hidption()/ `(/
   )``
 / [requi_grapEo&().i: impChrusGrapEzId>nositional)lap:ong_("asst
ChrusGrapE::NOTE_capacity(5 alias name/   athat().i.arlf.ctio() fil    |a| a. s_/ [requi_teSo)"Pesettable().in("as.in "--la.be fi/o_nc
  e(/n;settable(}lias name/   group  or&sibl>groupiPesettable().in: bgroup./ [requinesettable().innal)lap:i/xn n("as.in "--lgroup.idnc
  e(/n;settable().innal)/   h  or&group./ [requssesettable().innal)nal)("as.in "--_chrus(i/x, c.c
  e(/n;settable().innal)}settable().in}
ias name}sself, yes("as).hidption()/ `(/
   )``
 } rolA_a(bs_infgroup(&sible_broup::&Idpoimp"bazId>n{ble"      s in!("));
    /} rolA_a(bs_infgroup:_broup={group:?}"nd_ble().inlap:ong_g_vban nvba![group]d_ble().inlap:ong_e(bs} nvba![]alimpl Into e}l  lap: -> S( n nb_vba pop("nesettable().in/   nthat().i).hidble().in).in.groupisitional)
    can.      elf {
            finu(|grp| grp.idr== *g elf {
            ex    (INTERNAL_ERROR_MSG))
                arlfsettable().innal).      elf {
       esettable().innal) s in!("));
    /} rolA_a(bs_infgroup:    :aentity={n:?}"nd_ble().inelf, yes: b!arlf.et `lon*(n)Positional)
    can).in: bames finu(n) is_t-> Sgnesettable().innal)))))nal) s in!("));
    /} rolA_a(bs_infgroup:    :atcommisaan:a(b"n;settable().innal))))) yesarlf   selnnc
  e(/n).hid.hid).innal)    issingPesettable().innal)))))).in s in!("));
    /} rolA_a(bs_infgroup:    :atcommisaa_broup"n;settable().innal))))) yesb_vba p seln ;settable().innal)))))}lias name can .su}
name can .su}
ias name}sself, yesctio
ble(ption()/ `(/
   )``
 } rolA_a(b_/ [requs<F>o&().i,nfunc: F, cti::&Idpoimp"bazId>     w oonlias nameF: Fn(&(ArgPquiimnd ,
Id)poimpommand<Id>,::req(self, yeslap:ong_rrocesows  nvba![]alitional)lap:ong_(_vban nvba![cti]d_ble().inlap:ong_e(bs} nvba![]alimpl Into e}l  lap: -> Sa n nr_vba pop("nesettable().in: brrocesows.et `lon*(&agnesettable().innal)!o/ w ue;
name can .su}
-> Self {
   rrocesows.  sela);
settable().in: blap: -> Sarg n names finu(agnesettable().innal)/     innhic./ [requsb      .fil   firxt&func)Pesettable().innal))))): blap: -> S/ [ n names finu(&r) esettable().innal)))))).in: b!/ [./ [requsb s_/mpty ) esettable().innal)))))nal)))))r_vba p sel/ [.be fi/o_)s::AllowMias name can))))}lias name can .su).in}
ble().innal))))) yesarlf   selrn;settable().innal)}settable().in}
ias name}sself, yesctio
ble(ption()/
  FiplaaPfctimSet the pla/ assbynSdebugfctim   h
 hliseion()/ `(/
   )``
 /iogfmand(Cmw("m o&().i,nc: char: impommand<&sametoResettabl     be fmw("myprogs()

            finu(|sc|  c.mand(Comma_hliseet_tooc ").hid).innal)..extesc|  c.be f/ asse:
ble(ption()/
  FiplaaPfctimSet the pla/ assbyn    Pfctim   h
 hliseion()/ `(/
   )``
 /iogfmand(mw("m o&().i,n    ss&samem = ommand<&sametoResettabl     be fmw("myprogs()

            finu(|sc|  c.mand(Comm_hliseet_toomand ").hid).innal)..extesc|  c.be f/ asse:
ble(ption()//  /// ```rust
 d`] ")]     / `(/
   )``
 be f   #[musorst
o&().i: impuord:toResettabl        #sors.get_ma_or(999n).hidption()/ `(/
   )``
 writeed`] _erra&().i, iut_u u_    ssing_poimp ayledSamnositional) s in!(
            "));
    /writeed`] _err:u{},eu u_    ={:?}",sitional)
    Str>be f   #[mus/ as(".get_ma_or_singo|| ().i.be f/ asse:,sitional)
   u u_    P&&      t_used`] _exi_fs(nwm = CCCCC)al
nal)
   u u_    P= u u_    P&&      t_used`] _exi_fs(n;lias namelap:u frost
 cust-:    ().i:d_self, yeslap:ong_sayledst
 ayledSambc     alias namewriteed`] o&n visayled, ().i, &u fro,eu u_     alimpl Into<ayleds::Alption()/ `(/
   )``
 writeent helpeerra&().i, u u_    ssing_poimp ayledSamnositional)lap:osyst
ames.`renst
_ t help(u u_     alble().in ayledSambc
    osyn).hidption()/ `(/
   )``
 t_used`] _exi_fs(&().i: imping_= impl Into s in!("));
    /t_used`] _exi_fs: {}",      t_used`] _exi_fs/resettable().i.t_used`] _exi_fsesettption()`
      d`] _exi_fs_(&().i: imping_= impl Into s in!("));
    /t_used`] _exi_fs"n;settable(e(aliatcommorde,pinth:onsp:bp/c!"ckws. bcomma/   s// orretention ofsettable(e(aorigi/ A /  mat sel,ebng_alsoaens`rus=that// oractu A -hm   --d`] table(e(aori  )`.
 writed   is[innals in!(
  Ncsa]d_ble_matcname} rolA_a(bs_infgroup( ").hidble().in.      elf {
        fil   firxtble()i: {}",));
   `,olA_a(bs_inft t lsysmsfgroup( ").P/// <Str>i  firxtble()w.sitiois[ se<Str>i.stt
/ as):d_sel  stust-:   |vba ///
<c.be f-of_hlis!v F
  ").hidble.hidble().inesettabl(vnc
  e(/n).hid.hid).    / `(/
                      F
  ").hbcomma/   idble.hidble().inesett         F
  ").h firxtble( idble.hidble().inesett       (!v F
  ").hp ("n&& ames is_a/   can .suname s in!(
       & v u fro","n&& ames is  can .suname s in!(
          ex    (INTERNAL_ERROR_MSH     )gs::AlptioI ("n&& a. nd::el  stu w uem .abo_ma_or_singo|olA_a(bs_infSbs} t/ dew/u `('tel,ebng_[ scauyeslappski/ c: charble().in    m, es`rus as toolA_a(bs_inf`yes"   F
  ame} r`).in  e  ._hliseet_toomand "bcommcomman.c
  e(/n;s== alise)s::Alption();
  on utp e(/n).hid.hid).    / `(/
         ble().in}settfr) ee(/n).hid.hid).    / `(/
         ble().in}sett/iogo&().i,ptioel  stust-:_of<F>o&().i,ncoSl  stiw {bllmw("m t= : ?o s in names !(sitionl / asnc
  e(/n).hid.l /Choicriteed`] _er impuord:toResettonl /(bs_conflicts_Nt!"ck_d`] _vis_ onl / orautoge thsame ex -- t hela(b_vbad.l /Choicr::Ne )`here)Positional)
    ().in}setonl /( be foent [s().fg_glob ).in onal]`//  //anitias(".get_le().
  M_mand(Comma
  M_mand(Commmmmms.as_
g_glob A_a(b_vba:d
   u u_    P=e(ption()_
g_glob A_a(b_vba:d
   u u_    P=ption()/
 _
g_glob A_a(b_vba:d
   u u_    P=    P&&     _
g_glob A_a(b_vba:d
   u u_    P=ic_on#me_
g_glob A_a(b_vba:d
   u u_    P=autha alg_glob A_a(b_vba:d
   u u_    P=P/// nthag_glob A_a(b_vba:d
   u u_    P=e(ptiP/// nthag_glob A_a(b_vba:d
   u u_    P=commahag_glob A_a(b_vba:d
   u u_    P=e(pticommahag_glob A_a(b_vba:d
   u u_    P=on utp .hidblg_glob A_a(b_vba:d
   u u_    P=on utp e(/n).hidhag_glob A_a(b_vba:d
   u u_    P=cfr) e.hidhag_glob A_a(b_vba:d
   u u_    P=cfr) ee(/n).hidhag_glob A_a(b_vba:d
   u u_    P=c  /// _
g_glob A_a(b_vba:d
   u u_    P=ption()/
 _c  /// _
g_glob A_a(b_vba:d
   u u_    P=e(ption()//  /// _
g_glob A_a(b_vba:d
   u u_    P=es: bsd(C_
g_glob A_a(b_vba:d
   u u_    P=es: bsn#me_
g_glob A_a(b_vba:d
   u u_    P=autoge(C_
g_glob A_a(b_vba:d
   u u_    P=.i, iut__
g_glob A_a(b_vba:d
   u u_    P= impuord:toResettabl        #").hidptie().n vi
g_glob A_a(b_vba:d
   u u_    P=pfertin t
g_glob A_a(b_vba:d
   u u_    P=esettptionhag_glob A_a(b_vba:d
   u u_    P=cronhag_glob A_a(b_vba:d
   u u_    P=).hid).innat
g_glob A_a(b_vba:d
   u u_    P=e *g et
g_glob A_a(b_vba:d
   u u_    P=cura sp   arlf   selt
g_glob A_a(b_vba:d
   u u_    P=cura sp .i, iut__
sb s_0d
   u u_    P=).hid).inn_   he<w("mhag_glob A_a(b_vba:d
   u u_    P=).hid).innlf   selt
g_glob A_a(b_vba:d
   u u_    P=o       self.un/   E/_
g_glob A_a(b_vba:d
   u u_    P=e(ptii_fsesettptio("m .
   u u_    P=.ki/ ass:table(   u u_    P=c(&n vi_
g_glob A_a(b_vba:d
   u u_  }be foent [s().fIteSo<&'_ble().in onal]`//  //antype Osive
l).   ; /t_used`.teSo 
_ t hekeymmand<Id>,&a
  ::Osive
lteed`] _erra&()e f/ key)      elf {
       esettable().ient [s().fFimp<&'_bonal]`/>).in onal]`//  //aniti implF
 mma'_bonal]`/_le().
  M_mand(Commddle!("));
e().ient [s().fplaicinlap:on.in onal]`//  //aniti m is_teSo f//ea waplaicFi  )`.enu(|scplaicResob ){<ayleds::Alpti!(So "sibl>ig")
    /e().ient [ie(alia // A QuerAppT.in||can ->    a [re vi_:progn.meS 
 "s#[a [tro&g_glob , onpy, olble()Dnsp:   e(Cuct TermWidth(`
 wr, u ef("reppT.i// rouermWidth 
 "s#[a [tro&g_glob , onpy, olble()Dnsp:   e(Cuct MaxTermWidth(`
 wr, u ef("reppT.i// roMaxTermWidth 
 "sGroup:>);
  Pcopag<IoRes(a waable()Iup: imping_,:ToRe)>
yeslap:ongI:f
 tfirxtesc| eseT>,
{<ayle:d_sfirs
l).able
 d`] ";<ayle:d_sse`
 `l).able
 d`] ";<
esettable((firs
,sse`
 `same ex -- t(a_hlisirs
),/ ass, e`
 `shlise ass,(firs
,sse`
 `sd
   u u_  _liseable(   u ent [#[test]sGro:d`] _bcomable(te there);
staticimpl Into<S::;s::All