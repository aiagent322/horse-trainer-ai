//! Zero-capacity channel.
//!
//! This kind of channel is also known as *rendezvous* channel.

use std::cell::UnsafeCell;
use std::marker::PhantomData;
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::Mutex;
use std::time::Instant;
use std::{fmt, ptr};

use crossbeam_utils::Backoff;

use crate::context::Context;
use crate::err::{RecvTimeoutError, SendTimeoutError, TryRecvError, TrySendError};
use crate::select::{Operation, SelectHandle, Selected, Token};
use crate::waker::Waker;

/// A pointer to a packet.
pub(crate) struct ZeroToken(*mut ());

impl Default for ZeroToken {
    fn default() -> Self {
        Self(ptr::null_mut())
    }
}

impl fmt::Debug for ZeroToken {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&(self.0 as usize), f)
    }
}

/// A slot for passing one message from a sender to a receiver.
struct Packet<T> {
    /// Equals `true` if the packet is allocated on the stack.
    on_stack: bool,

    /// Equals `true` once the packet is ready for reading or writing.
    ready: AtomicBool,

    /// The message.
    msg: UnsafeCell<Option<T>>,
}

impl<T> Packet<T> {
    /// Creates an empty packet on the stack.
    fn empty_on_stack() -> Packet<T> {
        Packet {
            on_stack: true,
            ready: AtomicBool::new(false),
            msg: UnsafeCell::new(None),
        }
    }

    /// Creates an empty packet on the heap.
    fn empty_on_heap() -> Box<Packet<T>> {
        Box::new(Packet {
            on_stack: false,
            ready: AtomicBool::new(false),
            msg: UnsafeCell::new(None),
        })
    }

    /// Creates a packet on the stack, containing a message.
    fn message_on_stack(msg: T) -> Packet<T> {
        Packet {
            on_stack: true,
            ready: AtomicBool::new(false),
            msg: UnsafeCell::new(Some(msg)),
        }
    }

    /// Waits until the packet becomes ready for reading or writing.
    fn wait_ready(&self) {
        let backoff = Backoff::new();
        while !self.ready.load(Ordering::Acquire) {
            backoff.snooze();
        }
    }
}

/// Inner representation of a zero-capacity channel.
struct Inner {
    /// Senders waiting to pair up with a receive operation.
    senders: Waker,

    /// Receivers waiting to pair up with a send operation.
    receivers: Waker,

    /// Equals `true` when the channel is disconnected.
    is_disconnected: bool,
}

/// Zero-capacity channel.
pub(crate) struct Channel<T> {
    /// Inner representation of the channel.
    inner: Mutex<Inner>,

    /// Indicates that dropping a `Channel<T>` may drop values of type `T`.
    _marker: PhantomData<T>,
}

impl<T> Channel<T> {
    /// Constructs a new zero-capacity channel.
    pub(crate) fn new() -> Self {
        Channel {
            inner: Mutex::new(Inner {
                senders: Waker::new(),
                receivers: Waker::new(),
                is_disconnected: false,
            }),
            _marker: PhantomData,
        }
    }

    /// Returns a receiver handle to the channel.
    pub(crate) fn receiver(&self) -> Receiver<'_, T> {
        Receiver(self)
    }

    /// Returns a sender handle to the channel.
    pub(crate) fn sender(&self) -> Sender<'_, T> {
        Sender(self)
    }

    /// Attempts to reserve a slot for sending a message.
    fn start_send(&self, token: &mut Token) -> bool {
        let mut inner = self.inner.lock().unwrap();

        // If there's a waiting receiver, pair up with it.
        if let Some(operation) = inner.receivers.try_select() {
            token.zero.0 = operation.packet;
            true
        } else if inner.is_disconnected {
            token.zero.0 = ptr::null_mut();
            true
        } else {
            false
        }
    }

    /// Writes a message into the packet.
    pub(crate) unsafe fn write(&self, token: &mut Token, msg: T) -> Result<(), T> {
        // If there is no packet, the channel is disconnected.
        if token.zero.0.is_null() {
            return Err(msg);
        }

        let packet = &*(token.zero.0 as *const Packet<T>);
        packet.msg.get().write(Some(msg));
        packet.ready.store(true, Ordering::Release);
        Ok(())
    }

    /// Attempts to pair up with a sender.
    fn start_recv(&self, token: &mut Token) -> bool {
        let mut inner = self.inner.lock().unwrap();

        // If there's a waiting sender, pair up with it.
        if let Some(operation) = inner.senders.try_select() {
            token.zero.0 = operation.packet;
            true
        } else if inner.is_disconnected {
            token.zero.0 = ptr::null_mut();
            true
        } else {
            false
        }
    }

    /// Reads a message from the packet.
    pub(crate) unsafe fn read(&self, token: &mut Token) -> Result<T, ()> {
        // If there is no packet, the channel is disconnected.
        if token.zero.0.is_null() {
            return Err(());
        }

        let packet = &*(token.zero.0 as *const Packet<T>);

        if packet.on_stack {
            // The message has been in the packet from the beginning, so there is no need to wait
            // for it. However, after reading the message, we need to set `ready` to `true` in
            // order to signal that the packet can be destroyed.
            let msg = packet.msg.get().replace(None).unwrap();
            packet.ready.store(true, Ordering::Release);
            Ok(msg)
        } else {
            // Wait until the message becomes available, then read it and destroy the
            // heap-allocated packet.
            packet.wait_ready();
            let msg = packet.msg.get().replace(None).unwrap();
            drop(Box::from_raw(token.zero.0.cast::<Packet<T>>()));
            Ok(msg)
        }
    }

    /// Attempts to send a message into the channel.
    pub(crate) fn try_send(&self, msg: T) -> Result<(), TrySendError<T>> {
        let token = &mut Token::default();
        let mut inner = self.inner.lock().unwrap();

        // If there's a waiting receiver, pair up with it.
        if let Some(operation) = inner.receivers.try_select() {
            token.zero.0 = operation.packet;
            drop(inner);
            unsafe {
                self.write(token, msg).ok().unwrap();
            }
            Ok(())
        } else if inner.is_disconnected {
            Err(TrySendError::Disconnected(msg))
        } else {
            Err(TrySendError::Full(msg))
        }
    }

    /// Sends a message into the channel.
    pub(crate) fn send(
        &self,
        msg: T,
        deadline: Option<Instant>,
    ) -> Result<(), SendTimeoutError<T>> {
        let token = &mut Token::default();
        let mut inner = self.inner.lock().unwrap();

        // If there's a waiting receiver, pair up with it.
        if let Some(operation) = inner.receivers.try_select() {
            token.zero.0 = operation.packet;
            drop(inner);
            unsafe {
                self.write(token, msg).ok().unwrap();
            }
            return Ok(());
        }

        if inner.is_disconnected {
            return Err(ect() {
  inner.is_di         f lceiver(self).
   : Crner.iceiver(seleak(()Disconlon.pack     //! Z::lse),
            msr.iceiver(selea          if self
     nner =      if self
       #[inli_    _onlon.pty() |&Disconlon.pe channeeCell::newe channemess| self.0.is_delea     ner = self.notifye
            // heaph it.
  
f !self.is_empty() || self.is_disconnected() {
                let _ = cx.try_select(Selected::Aborte                }

            // Block the current thread.
                let s cx.wait_until(deamatch sel {
             ine: Option<Instant>,
    inner = siting => unreachable!(),
                    Se becomes aecv(&selfvailable, then read it and destroy the
 }                    Seoken, msg).ok().unwrap|err| malse if inner.i    .is_ok()
            {ine);

                match sel {
             ine: Option<Instant>,
    inner = siting => unreachable!(),
                    Se becomes aecv(&selfvailable, then read it and destroy the
 }                    Seoken, msg).ok().unwraptoken, msg).ok().unwrap();
    .is_ok()
            {ine);

   cted, we still haset);
                  eplace(None).unwrap();
cket<T>t.readydhead !=        } else {
    e {
            // Wait until the messageation.packet;
                            threa  Box::new(Packet {
            unsafe {
            self.write(token, msg)
                .map_err(SendTimeoutError::Disconnected)
        }
    }

    /// Attempts to receive a g::Release);
        Ok(())
    }

    /// Attempts to pair up with a sender.
    fn start_recv(&self, token: &mut Token) -> bool {
        let mut inner = self.inner.lock().unwrap();

        // If there's a waiting sender, pairp with it.
        if let Some(opf) -> Result<T, TryRecvError> {
        let token = &mut Token::default();
(inner);
            unsafe {
                       let token = &mut ken::default();

        if self.start_recv(token) {
            unsafe { self.read(token).map_err(|_| TryRecvError::Disconnected) }
        } else {
            Err(TryRecvError::Empty)
        }
    }

    /// Receives a message from the channel.
    pub(cse);
        Ok(())
    }

    /// Attempts to pair up with a sender.
    fn start_recv(&self, token: &mut Token) -> bool {
        let mut inner = self.inner.lock().unwrap();

        // If there's a waiting sender, pairp with it.
        if let Some(opk()
            {
      ::new();
            loop {
                if self.start_recv(token) {
  }    drop(inner);
            unsafe {
                self.write(token               if self.start_recv(token)   return Ok(());
        }

        if inner.is_disconnected {
            r                return Err(RecvT      f lceiver(self).
   : Crner.iceiver(seleak(()Disconlon.pack     //! Z::,

    /// The melf.0.is_delea     ner = self.  #[inli_    _onlon.pk()
            {ty() k()
            {&Disconlon.pe channeeCell::newe channemesk()
            {cxsk()
         melf.0.is_delea     nnner = snotifye
            // heaph it.
  
f !self.is_empty() || self.is_disconnected() {
                let _ = cx.try_select(Selected::Aborte                }

            // Block the current thread.
                let s cx.wait_until(deamatch sel {
             ine: Optiow = Instant::now();

    
    //w = Instant::now();

    
 Attemptw = Instant::now();

    
er = selfw = Instant::now();

    
 Aing => unreachw = Instant::now();

    
 Attempt                    Seokencrate) fn recv(&self, deadline:er.i    .is_ok()
            {ine);

                match sel {
             ine: Optiow = Instant::now();

    
    //w = Instant::now();

    
 Attemptw = Instant::now();

    
er = selfw = Instant::now();

    
 Aing => unreachw = Instant::now();

    
 Attempt                    Seokencrate) fn recv(&setoken = &mut ken::defa    .is_ok()
            {ine);

   cted, we still haset);
                  eplace(None).unwrap();
ckeprovidedt.ready.store( } else {
    e {
            // Wait until the messageation.pa Some(opfckevailable, then read it and destroy the
) }                            threa  Box::new(Packet {
      RK_BIT == 0 ssage from ts the capacity of the cha/ Returns th{
            self.receivers.disconnect();
            true
        } else {
            false
        }
    .tail.index.load(Ordering::Seq
        Ok(())
    }

    /// Attempts to pair u          unsafe {
                self.      unsafe {
       =operaelf.0.is_delea     nnner = s     let tail = self.tail.     ner = self.     let tail = self.tail.index.fetch_or(MARK_BIT, Ordering::SeqCst);

        if tail & MA.
                    }
                    Selected::Operation(_) => {}
                }
            });
0ifference minus the number of blocks between tail and head.
                return tail - head - tail / LAP;
        0
    }

  sconnected.
    pub(crate) fn is_disconnected(&self) -> bool {
        self.tail.index.load(Ordering:   Err(())
    }

    /// Returns `true` if the channel is empte]
    pub(crate) fn is_empty(&self) -> bool {
        true last remaining block.
            if !block.is_null() {
                drop(Box::from_raw(block));
            }
        }
    }
}

/// Receiver handle to a channel.
pub(crate) struct Receiver<'a, T>(&'a Channel<T>);

/// Sender handle to a channel.
pub(crate) struct Sender<'a, T>(&'a Channel<T>);

impl<T> SelectHandle for Receiver<'_, T> {
    fn try_select(&self, token: &mut Token) -> bool {
        self.0.start_recv(token)
    }

    there is no p-alloTrySd pack     //! Z::,

    //::new(ts to pair u:Seq
        Ok(())
 0    }

    /// Attempts er(selea          if self

er = selfw = Instant::   #[inli_    _onlon.pty() |vailabl    pac()>mess| self.0.is_d     nnner = snotifye
               nnner = scan.inner.loc||.      unsafe {
          fn register(&self, oper: Operation, cx: &Context) -> booen) -> bool {
        let())
 0    }

    /// Attempt      self.0.receivers.regi_BIT, Ordering: Some(opk()
            { heap-allocated pacthere's a waitin     packet.wait_ready();
          e {
                   : &Context) -> bool {
        self.i.0.start_recv(token)
    }

    
        // If let _ = onlon.p.get_mut();
(&self, token: &muinline]
    fn accept(&self, token ->      Ok(())
 0    }

    /// Attempts er(selea     nnner = scan.inner.loc||.      unsafe {
          fn registerself.try_select(token)
    }

    fn is_ready(&self) -> bool {:Seq
        Ok(())
 0    }

    /// Attempts er(selea        !self.0.is_empty() || self.0.is_d     nnner = scan.inner.loc||.      unsafe {
          fn register(&h(&self, oper: Operation, cx: &Context) :Seq
        Ok(())
 0    }

    /// Attempts er(selea        !self.0. self.0.receivers.watch(oper, cx);
        self.is_ready()
    }

    fn unwatch(&self, oper: Operation) {
        self.0.receivers.unwatch(oper);
    }
}

impl<T> SelectHandle for Sender<'_, T> {
    fn try_select(&self, token: &mut Token) -> bool {
        self.0.start_recv(token)
    }

    there is no p-alloTrySd pack     //! Z::,

    //::new(ts to pair u:Seq
        Ok(())
 0    }

    /// Attempts er(selea          if self

nner =      if self
   #[inli_    _onlon.pty() |vailabl    pac()>mess| self.0.is_d     ner = self.notifye
               ner = self.can.inner.loc||.      unsafe {
          fn register(&self, oper: Operation, cx: &Context) -> booen) -> bool {
        let())
 0    }

    /// Attempt nner = siting => unreach_BIT, Ordering: Some(opk()
            { heap-allocated pacthere's a waitin     packet.wait_ready();
          e {
                   : &Context) -> bool {
        self.i.0.start_recv(token)
    }

    
        // If let _ = onlon.p.get_mut();
(&self, token: &muinline]
    fn accept(&self, token ->      Ok(())
 0    }

    /// Attempts er(selea     ner = self.can.inner.loc||.      unsafe {
          fn registerself.try_select(token)
    }

    fn is_ready(&self) -> bool {:Seq
        Ok(())
 0    }

    /// Attempts er(selea      nner = sis_empty() || self.0.is_d     ner = self.can.inner.loc||.      unsafe {
          fn register(&h(&self, oper: Operation, cx: &Context) :Seq
        Ok(())
 0    }

    /// Attempts er(selea      nner = sitelf.0.receivers.watch                                                                                                                                    