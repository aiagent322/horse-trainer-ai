//! [![github]](https://github.com/dtolnay/proc-macro2)&ensp;[![crates-io]](https://crates.io/crates/proc-macro2)&ensp;[![docs-rs]](crate)
//!
//! [github]: https://img.shields.io/badge/github-8da0cb?style=for-the-badge&labelColor=555555&logo=github
//! [crates-io]: https://img.shields.io/badge/crates.io-fc8d62?style=for-the-badge&labelColor=555555&logo=rust
//! [docs-rs]: https://img.shields.io/badge/docs.rs-66c2a5?style=for-the-badge&labelColor=555555&logo=docs.rs
//!
//! <br>
//!
//! A wrapper around the procedural macro API of the compiler's [`proc_macro`]
//! crate. This library serves two purposes:
//!
//! [`proc_macro`]: https://doc.rust-lang.org/proc_macro/
//!
//! - **Bring proc-macro-like functionality to other contexts like build.rs and
//!   main.rs.** Types from `proc_macro` are entirely specific to procedural
//!   macros and cannot ever exist in code outside of a procedural macro.
//!   Meanwhile `proc_macro2` types may exist anywhere including non-macro code.
//!   By developing foundational libraries like [syn] and [quote] against
//!   `proc_macro2` rather than `proc_macro`, the procedural macro ecosystem
//!   becomes easily applicable to many other use cases and we avoid
//!   reimplementing non-macro equivalents of those libraries.
//!
//! - **Make procedural macros unit testable.** As a consequence of being
//!   specific to procedural macros, nothing that uses `proc_macro` can be
//!   executed from a unit test. In order for helper libraries or components of
//!   a macro to be testable in isolation, they must be implemented using
//!   `proc_macro2`.
//!
//! [syn]: https://github.com/dtolnay/syn
//! [quote]: https://github.com/dtolnay/quote
//!
//! # Usage
//!
//! The skeleton of a typical procedural macro typically looks like this:
//!
//! ```
//! extern crate proc_macro;
//!
//! # const IGNORE: &str = stringify! {
//! #[proc_macro_derive(MyDerive)]
//! # };
//! # #[cfg(wrap_proc_macro)]
//! pub fn my_derive(input: proc_macro::TokenStream) -> proc_macro::TokenStream {
//!     let input = proc_macro2::TokenStream::from(input);
//!
//!     let output: proc_macro2::TokenStream = {
//!         /* transform input */
//!         # input
//!     };
//!
//!     proc_macro::TokenStream::from(output)
//! }
//! ```
//!
//! If parsing with [Syn], you'll use [`parse_macro_input!`] instead to
//! propagate parse errors correctly back to the compiler when parsing fails.
//!
//! [`parse_macro_input!`]: https://docs.rs/syn/1.0/syn/macro.parse_macro_input.html
//!
//! # Unstable features
//!
//! The default feature set of proc-macro2 tracks the most recent stable
//! compiler API. Functionality in `proc_macro` that is not yet stable is not
//! exposed by proc-macro2 by default.
//!
//! To opt into the additional APIs available in the most recent nightly
//! compiler, the `procmacro2_semver_exempt` config flag must be passed to
//! rustc. We will polyfill those nightly-only APIs back to Rust 1.31.0. As
//! these are unstable APIs that track the nightly compiler, minor versions of
//! proc-macro2 may make breaking changes to them at any time.
//!
//! ```sh
//! RUSTFLAGS='--cfg procmacro2_semver_exempt' cargo build
//! ```
//!
//! Note that this must not only be done for your crate, but for any crate that
//! depends on your crate. This infectious nature is intentional, as it serves
//! as a reminder that you are outside of the normal semver guarantees.
//!
//! Semver exempt methods are marked as such in the proc-macro2 documentation.
//!
//! # Thread-Safety
//!
//! Most types in this crate are `!Sync` because the underlying compiler
//! types make use of thread-local memory, meaning they cannot be accessed from
//! a different thread.

// Proc-macro2 types in rustdoc of other crates get linked to here.
#![doc(html_root_url = "https://docs.rs/proc-macro2/1.0.64")]
#![cfg_attr(any(proc_macro_span, super_unstable), feature(proc_macro_span))]
#![cfg_attr(super_unstable, feature(proc_macro_def_site))]
#![cfg_attr(doc_cfg, feature(doc_cfg))]
#![allow(
    clippy::cast_lossless,
    clippy::cast_possible_truncation,
    clippy::doc_markdown,
    clippy::items_after_statements,
    clippy::let_underscore_untyped,
    clippy::manual_assert,
    clippy::must_use_candidate,
    clippy::needless_doctest_main,
    clippy::new_without_default,
    clippy::return_self_not_must_use,
    clippy::shadow_unrelated,
    clippy::trivially_copy_pass_by_ref,
    clippy::unnecessary_wraps,
    clippy::unused_self,
    clippy::used_underscore_binding,
    clippy::vec_init_then_push
)]

#[cfg(all(procmacro2_semver_exempt, wrap_proc_macro, not(super_unstable)))]
compile_error! {"\
    Something is not right. If you'spanuse,hs!
//! ```sh
//! RUSTFLAGn is noer_exempt, wrap_proc_macro of t_ma/! Rensnal, stabltn is nof yUSTFma/  *sorhen parsing     *emver gumentation.
 is no/!
// scriptze ourll.
"e = "proc-macro")]
impl From<Tokenoc_macro;
//!
//! # const
mod in thr;
mod ut.ht;
mod rcush; = "proc)]
//! pub fn my_dmod detis inn;2 typeub ot::TokenStream {= {l)));
   {lorc // defpillorc //rate tnly APausehosage
/Liteichewe avoid
ays reiomiabltnt. Inr crate.)]
pl = iddentruct  mod l)));
  ;
uct  mod oc_ra;n_locations)))]
               ert::usize_l)));
  /! asmp;_loath(*se"the pro/1."]= "proc)]
//! pub fn my_dmod smp;_ations)]
fn get_cursor(smod to_u32;;ations)]
fn get_cursor(smod get_curs;_aert::usize_oc_raspanlimS pub ert::usize_in thr::Mn thr;
Bound;

  i.satO libt. ;
Bound;

       { fmt::D);
   elf.rep};
Bound;

  hash  {Hash, Hasher};
Bound;

  !self.kenStream> f;
Bound;

       ze>>(&self,;
Bound;

  ! #f.kenStpu;
Bouncrae_o())
  from_st2_semver_exempt)]
    pub fn sourBouncrae_from(:<unspec;_ations)]
fn get_cursor(sct  ert::usize_get_curs> Di: 0, col;the ofAn absly cnStream::emve   .i,of
/heyund;nc_mu proa ng
//!   sperse faTokeer ex/he of naturror;er_val as it rf   f::Tok   deequiv)]
 erse faTokee defp:Tohe ofcol the be ase faTokee onal ate,_empty( ex/he of se failed")
atuchecver g      defp/! ``` spe`rive(MyDeriv]`,he of`rive(MyDerivfeatuite e]at` onlrive(MyDerive)]
//!]atippfilesrso.)]
pub(crate) struct reamBuilder {
    icVecBuilder<Topiler  span: Span,
}

_in thr: Mn thr,s the offmt(&s_must_test. In`om(output)
//! }
l");`.uct reamBuilfn fmt(&self, flder<Topilerfn fmt(&n,
}

_in thr: Mn thr,s thmBuilder {
    pstring: &str, rlder<Topiler  span: Spa     TokenStreamBuilder {
     inner: stream.build(   };
        _in thr: Mn thr,s

    fn span_within(&setr, _l)));
  rlder<Tol)));
   {  span: Spa     TokenStreamBuilder {
     inner: stream.build(:roup.stonal span,
         _in thr: Mn thr,s

    fn span_within(e ofRe '\"' anion<Idn`om(output)
ust b    quivalerse faTokeer string: &str, s     TokenStreamBuilder {
     
    }
piler  span: Spa  repr.)span_within(e ofC?
  s     natu`om(output)
usatuon<Id.real(&self) ->       {
        self.lo == 0 && self) {
            omputes the of`om(output)
//ippy::r()`s_must_' anion<Idn     spae ofi.ouswhich s those libru'll u`  span: Spa  repr.`.uLiteralet of p{
    fn extend<I: IntoIippy::r()    TokenStreamBuilder {
     
 repr.omputes the ofA libpry tims to nfo asn stream")
    }e defper tokely AP    }e am")
aP    }he of_empty( ex/he ofM{
  ailthat
/acters
#[cfmptsg)))]hat
exag
//,     n asn stre
       he ofunbal    df) -> Deli of
//(all(spanyou'sinclustream  n aacrouage( ex/he ofwith at rily back ng clying cannos propagat[cfmpust_stre`fn fmt(&`ill he ofconsrvg comppanuskens"at anable APy back am")
`fn fmt(&`s py::r.or TokenStream {
    type Err = LexError;

    fn from_str(src: &str) -> Result<TokenStream, LexError> {
        // Create a dum_to_u
//!rc      .e.m
//y b(|e|lfn fmt(&self, fstream.build(:repan,
         _in thr: Mn thr,s

    fn          selOk(der {
     
    }
e)g(feature = "proc-macro")]
impl From<Token#fg, feature(doc_cfgpl =proc-macro")]
impl From<Tok)oc_macro::TokenStream> for TokenStream {
    fn from(inner: proc_macro::TokenStream) -> Self {
        inner
         der {
     
    }
pup.stonal sg(feature = "proc-macro")]
impl From<Token#fg, feature(doc_cfgpl =proc-macro")]
impl From<Tok)oc_macro::Tokr proc_macro::TokenStream {
    fn from(inner: TokenStream) -> Self {
        inner
            .t.pup.stonal sFrom<TokenTree> for TokenStream {
    fn from(tree: TokenTree)  fn Self {
        let mut stream der {
     
    }
piler  span: Spa  nTree)  fnl Display for Lite> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenTree>>(&mut self, tokens: I) {
         self.inner.make_mut().exteinto_iter().fll Extend<TokenStream> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenStream>>(&mut self, streams: I) {
        self.inner.make_mut().extxpect("failed toto_iter().flatten());
   m
/(|er().f| _empty() {
 b(crate) typee offsl thes
/acters
#[cfase faTokee onal file whic_empty( or<TokenTree> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenTree>>(tokens: I) -> SSelf {
        let mut v = RcVder {
     
    }
er().flatten());
   col the sg(feature or<TokenStream> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenStream>>(streams: I) -> Self {
        let mut v = RcVder {
     
    }
er().flatten());
   m
/(|i|fi.) {
 b col the sg(feature ee ofP sttser of ce failed")
  pub fn pat stable ses is use Optilippy::c, the/ to_u32;,
  .31.0.onal APIss us, ce failed")
(moduloonly o),Iteceptp:Tohe oftion,
 dn`om(ouI) -::  deb`s 'll u` => ("", ""),
 `f) -> Deli odefp        he of     ic Span {
s.or Literal {
    f   fn from_iter<I: Intut fmt::Formatter) -> fmt::Result {
        Display::fmt(&self.repr, f)
    }
uild( pl Debug for e ofP sttserce faam a  //  to_u3niibru   f    }gty paLiteral {
    f   fn from_iter<I: Intut fmt::Formatter) -> fmt::Result {
        Display::fmt(&se:Debu, f)
    }
uild( pl Debug for     pun fmt(&self, flf) -> Span {
        self.span
    }(),
     }
emut().exteSpan l Debug for Group {
    fn un fmt(&self, f Intut fmt::Formatter) -> fmt::Result {
        Display::fmt(&se:Debu, f)
    }
uild( pl Debug for     peral {
    fnn fmt(&self, f Intut fmt::Formatter) -> fmt::Result {
        Display::fmt(&self.repr, f)
    }
uild( pl Debug for enStremt(&s   fnn fmt(&seor e of a ty string.
  oceduring
/`(),
`r ex/he of naturror;le sthods are mardefp u'sinacro2 by ! To opt acro2_semver_exempt, wrap_proc_macrospanons)))]
            e), feature(proc_)ken#fg, feature(doc_cfgpl =procer_exempt)]
    pub fn so)ken#fartialEq, Eq)]
pub(crate) struct ile {
    path: PathBuf,
lder<Topiler  path: Pan,
}

_in thr: Mn thr,s thacro2_semver_exempt, wrap_proc_macrospanons)))]
            e), feature(proc_)ken {
    /// Get the pat &str, rlder<Topiler  /// Get      Span {
                  path: PathBuf::uild(   };
        _in thr: Mn thr,s

    fn span_within(h to this source file as a string.
 parens: /thin(h to### mustarens: /thin(h toIs [`procd only pan_oci);
  'll u natu`          ` wa hern     2 by ub fn sh tooc_maclly look,only be{
  from
// pactuacrorce o           omes . Ustarens: / [`       `]kens"aeckparens: /thin(h toAlso  frl, stabeng
/   `       `s_must_' ` if `,   thin(h to`--rem
/-orce-prefix` wa hustc. Wo      commdefpf.hi,is source a heing
thin(h toe{
  froactuacyour ctringparens: /thin(h to[`       `]: #ked as        h(&self) -> PathBuf {
        self.path.clone()
  ).exte     .span_within(e ofRe '\"' ` if `     natuy string.
  iat yountee string.
 ,rdefp u'thin(e ofern     2 by ubooc_maclly look'ssinay oThreaeal(&self) -> bool {
        // XXX(nika): S self) {
          .(all(span_locations,er_exempt, wrap_proc_macrospanons)))]
            e), feature(proc_)ken {
  eFile {
    fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
        f.debug_struct(e:Debu, f)
    }
uild( pl Debug for h toAyoug   *emve strinocd ros, Eou'll uts of tnay oThrom.
        .)]
pub(crat Eq)]te) struct reamBuilself.span
 lder<Topiler   raw,
  _in thr: Mn thr,s thmBuilmt(&self, f: &tr, rlder<Topiler         Ident::_new(str            #[cfg(suild(   };
        _in thr: Mn thr,s

    fn span_within(&setr, _l)));
  rlder<Tol)));
   {         Ident::_new(str            #[cfg(suild(:roup.stonal span,
         _in thr: Mn thr,s

    fn span_within(e of a ty    emver ginvet_cursr's [`prour/ Proo.
//!   Meanwhilerens: /thin(h toIing);
   ync`e);
  'll u natulated Fllur cd `locat/! asf acceswed + AsRh to "\\to_ dithe comahis so   By d))) get_curs (d)))-attr pub fn m.rs.* AsRh tolike buidemahis so   By d))) attr  Fllur cher use ref
 ersme.
//! ourll.
_site() -> Self {
        Span { lo: 0, hi: 0
    }
piler(),
        }
   )span_within(e of a ty    f, othemahis soinvet_cursr's [`pro.
//!   Meanwhirate t'll thin(e ofeaningvariher s, 55&los,rdefp`$:usiz`cd `locat/!his soippfilesrs attr* AsRh tolfis so   Byus naturs APIss us,pub fn ur haviat
/' `suffixed_nu`lerens: /thin(h to natuo other cd quithss
//! th45of
/py::r.oo_hygiene))]
    pub fn mixed_site() -> Self {
        Span::call_site()
      }
piler(),
   Self {
    )span_within(e ofA   // caatcd `locasmahis so   By ippfilesrs attrlerens: /thin(h to natuked as;le sthods are mardefp u'sinacro2 by ! To opt acro2_semver_exempt)]
    pub fn source_f#fg, feature(doc_cfgpl =procer_exempt)]
    pub fn so)kensite() -> Self {
        Span::call_site()
      }
piler(),
  elf {
    )span_within(e ofC`e);
s
/acewelated FileAPIss us,ormation from.
        */' `   }`ate thin(e ofcaatcd `locasmsymbols*/'     ghbltnwed mahiwithin .olved_at(&self, _other: Span) - Span {
        other
    }

  (),
     }
emut().extelf, _other: th("r#) {
 b(span_within(e ofC`e);
s
/acewelated FileAPIss us,-> Lelf, _u    *r haviat
/' `   }`ate thin(e of FileAPIsormation from.
        *ofiwithin .olved_at(&sef, other: Span) -> Span {
        other
    }

  (),
     }
emut().extef, other: Sth("r#) {
 b(span_within(e ofCo_u32;
//!
//! [syner(),
`ersm`enStream {
 (),
`r rens: /thin(h to natuked as;le e most recils.
/!
// you'll uaer, minor versions ofails.thin(h to/!
// you'll upolyf th29+ *,
    c* sthods are mar! The deparens: /thin(h to#   nnosarens: /thin(h toPannos pfine/coest. Inocedural macro.
//!   Meanwhil Un//! thin(h to`/!
//! [syner(),
`o2_semver_eream {
 (),
`urror;ecutr youinclud
     thin(e ofcaebuild.rsl macro.
//!   Meanwhioinvet_curst acro2_semv)]
//! pub fn my_dlved_at(&se   if !
        er_eream {
 (),
XX(nika): S self) {
     if !iIdent {
    // Sofpan)pre othe. Pleid
aing (),
     if t acro2_semv)]
//! pub fn my_dlved]
pl = iddentrulved_at(&se  e(proc!
        er_eream {
 (),
XX(nika): S self   if !iIdent {
    //of a toriginntee string.
 .onal ssary. natulatedposttslerens: /thin(h to natuked as;le sthods are mardefp u'sinacro2 by ! To opt acro2_semvons,er_exempt, wrap_proc_macrospanons)))]
            e), feature(proc_)kence_f#fg, feature(doc_cfgpl =procer_exempt)]
    pub fn so)kensite() -> Slf) -> SourceFile {
        #[cfg(fuzzing)]      #[cf     }
emut().exteSf) -> Sourcb(span_within(e of this so|ch|  youormation from.is so| string.
 .sorhenatulatelerens: /thin(h to natuked as;d quithss_semv
    -get_curso"` proc-mace Optionprocgparens: /thin(h toWls.
 unit stream cro.
//!   Meanwhiouild.rso2_sem_must_tesormation frthin(h tothe n younnot beful pfinversiodu'll uaer, minort/ Xch frof a tyler APhin(e ofc/ Xch frgplenyou'shave which i
        */ most re.oWls.
 unit str* AsRh tolcedural macro.
//!   Meanwhi,oc-macases from  ofa!   main, caller we ofermation frothe alwaysunnot beful ougarain,
#[cfas Xch fro_locations)]
    fn fmt(&self, f#fg, feature(doc_cfgpl =proc-macro")]
i    -get_curso"o)kensite() -> SlLineColumn {
        #[cfg(fuzzing)]emut().exteSLineC(span_within(e of this soepy::vuormation from.is so| string.
 .sorhenatulatelerens: /thin(h to natuked as;d quithss_semv
    -get_curso"` proc-mace Optionprocgparens: /thin(h toWls.
 unit stream cro.
//!   Meanwhiouild.rso2_sem_must_tesormation frthin(h tothe n younnot beful pfinversiodu'll uaer, minort/ Xch frof a tyler APhin(e ofc/ Xch frgplenyou'shave which i
        */ most re.oWls.
 unit str* AsRh tolcedural macro.
//!   Meanwhi,oc-macases from  ofa!   main, caller we ofermation frothe alwaysunnot beful ougarain,
#[cfas Xch fro_locations)]
    fn fmt(&self, f#fg, feature(doc_cfgpl =proc-macro")]
i    -get_curso"o)kensite() -> SineColumn {
        #[cfg(fuzzing)]_mut().extei    span_within(e ofC`e);

/acewelatedennvera_debu `   }`adefp`ithin .olved: /thin(h toRe '\"' `),
 `f   `   }`adefp`ithin othe t. Ind.

// Pro     parens: /thin(h toWat_str: compiler
//! ty[ver_eream {
 (),
::er: `]uked as;lethin(h toIs back to R.oWls.
ne/coest. In FileIncro.
//!   Meanwhioou'soc_ma athin(h toIs back`procmacro2_satuked as; Fllualwaysual);
  `),
 `parens: /thin(h to[`er_eream {
 (),
::er: `]ust-lang.org/proc_macro/
//!
//! - **BreamBui.S     tml#ked as er: n(&self, other: Span) -> Option<Span> {
        #[cfg(fuzzing)]_mut().exteer: Sth("r#) {
 b m
/((),
     }(span_within(e ofCom   /
//!
/nly oce Oseeasf acce'cifiquallerens: /thin(h to natuked as;le sthods are mardefp u'sinacro2 by ! To opt acro2_semver_exempt)]
    pub fn source_f#fg, feature(doc_cfgpl =procer_exempt)]
    pub fn so)kensite() -> S: &T) -> bool {
  <Span> {
// XXX(nika): S self) {
  : &Tth("r#) {
 bspan_within(e ofRe '\"' s so| strind.rslr hiefpaulatelo natupconsrvg' s sooriginntthin(e ofe strinocd roacro code.latcee defpcommy::l. Ifor you_must_' aelf,.deb  thin(h tota ty    to thspote. se rentee strindevelorens: /thin(h tomust:f a tobnsrvt reclf,.deb macranwhios   ldor you_myouo          }ethin(h totefp u'son  natuy strind.rsof a tlf,.deb matnatuo other ciat ybes thin(e ofef
  tce Optiudiffe  f iagnostnos to R.rce_text(&self) -> Option<String> {
        #[cfg(fuzzing)]emut().exteSf) -> Optio Debug for e ofP sttseaulateaam a  //  to_u3niibru   f    }gty paLiteral {
    fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
        #[cfg(span_locae:Debu, f)
    }
uild( pl Debug for h toAyle whicrce faat
/a) -> Deld ng
//!   sperse faTokee (e.g. `[1, //ra..]`).)]
pub(crate) struct renumkens: I) -ym: proc_toAy ce failed")
surrspan.hib.]
    //f) -> Deli .rce_t  deb(  deb),: proc_toAntring);
   .rce_t    #[{
    ,thin(e ofA  e whicp othu     */(all(spa (`+`o2`,`o2`$`o2etc.).rce_tP oth(P oth ,thin(e ofA Span {
*/(all(spa (`'a'`)ind)), n (`"hello"`)incters
#(`2.3`)inetc.
ew(escaped)(scaped)),s thmBuilder {I) -ym: proc_toRe '\"' s so|    emverrs A) -,f) -     be ass_semvs),
`uked as;ofthin(e ofcaebuild fr use e faat
/a) -> Deld nempty( f, flf) -> Span {
        self.span
    }miter {
          #[cfg(som(ouI) -::  deb(      teSpan l,      #[cfg(som(ouI) -::    #[      teSpan l,      #[cfg(som(ouI) -::P oth(      teSpan l,      #[cfg(som(ouI) -::scaped)(      teSpan l,      #[c}span_within(e ofCo_figuthss_sem|       f*r youerrs Am(ou*lorens: /thin(h tomustt stablfuerrs Am(ouciat y`  deb`s_sen2_satuked as; Fllu u'sco_figuththin(h tota ty    emveaer emver gin_macllye   .i,o_satu FllusmBuiyf) -    icrcthin(h tota t`elf, spa`uked as;ofveaer varihnt._span(&mut self, span: Span) {
        self.span = spamiter {
          #[cfg(som(ouI) -::  deb(      teSlf, spanattr(,      #[cfg(som(ouI) -::    #[      teSlf, spanattr(,      #[cfg(som(ouI) -::P oth(      teSlf, spanattr(,      #[cfg(som(ouI) -::scaped)(      teSlf, spanattr(,      #[c FromStr for Literal<  debam {
    fnI) -ym: prookenTreer:   deb)    let mut v = RcVder {I) -::  deb(gsFrom<TokenTree> for 

    m {
    fnI) -ym: prookenTreer: {
        let mut v = RcVder {I) -::    #[gsFrom<TokenTree> for P oth m {
    fnI) -ym: prookenTreer: P oth     let mut v = RcVder {I) -::P oth(gsFrom<TokenTree> for scaped) m {
    fnI) -ym: prookenTreer: scaped))    let mut v = RcVder {I) -::scaped)(gg(feature ee ofP sttser of ce faA) -
  pub fn pat stable ses is use Optilippy::c, the/ to_u32;,
  .31.0.onal APIss us, ce faA) -
(moduloonly o),Iteceptp:Tohe oftion,
 dn`om(ouI) -::  deb`s 'll u` => ("", ""),
 `f) -> Deli odefp        he of     ic Span {
s.or Literal {
    f   fnI) -ym: prookenut fmt::Formatter) -> fmt::Result {
        #[cfg(span_locamiter {
          #[cfg(som(ouI) -::  deb(      elf.repr, f)
t pl ,      #[cfg(som(ouI) -::    #[      elf.repr, f)
t pl ,      #[cfg(som(ouI) -::P oth(      elf.repr, f)
t pl ,      #[cfg(som(ouI) -::scaped)(      elf.repr, f)
t pl ,      #[c}Debug for e ofP sttserce faA) -
am a  //  to_u3niibru   f    }gty paLiteral {
    f   fnI) -ym: prookenut fmt::Formatter) -> fmt::Result {
        #[cfg(span_loca offaer emver se haser of-> Lem.is so|amBuilrror;lnis soipb(crdan);
  span_loca ofsocrat'tuchec faill uan oc_ra reps
#[cfppy:ris innspan_locamiter {
          #[cfg(som(ouI) -::  deb(      e:Debu, f)
t pl ,      #[cfg(som(ouI) -::    #[             #[cfg(span_ f.debug_struct("Ident");
        debug.field("syield("sym", &format_args!("{}", self));
       t)g.field("syield("sypilerd_if_nontrivial(&mut debug, self.span);
   teSpan l#) {
 b.field("syield("sym", &for                      literal.spaom(ouI) -::P oth(      e:Debu, f)
t pl ,      #[cfg(som(ouI) -::scaped)(      e:Debu, f)
t pl ,      #[c}Debug for h toAy) -> Deld  ce failed")r ex/he ofAy`  deb`sin_macllck`pr      t y`om(output)
usssary.
  surrspan.hib.he of` => ("", `o.)]
pub(crate) struct reamBuilfmt(&self, flder<Topilerfmt(&,s the ofDescribes howoa ng
//!   sperse faTokee.
  ) -> Deld.)]
pub(crat Eq)]te) s::D);
   ate)
pub(crattruct renumk => ("", ym: proc_to`(a... )`rce_tPa/ Prr sis,thin(e of`{a... }`rce_tBll(e,thin(e of`[a... ]`rce_tBll( //,thin(e of`Øa... Ø`arens: /thin(h toAning
/ici/f) -> Deli,t stabmay)]hat
exag
//, e praocedural m   }ethin(h tocom//! [. In o"anwhiovariher "2`$var`. Ifoi asmp  tantmacrosonsrvg* AsRh tolpokenStrosioritif otheoid
////! ``$var * 3usssed m`$var`oi a`1repr`parens: / Ig
/ici/f) -> Deli be{
  frosurv    duralbugprocedurce failed")
thr  ghthin(h tot;
      
      }
,s thmBuilfmt(&self, f: &tr, rlder<Topiler  deb)    let mut v = RcVfmt(&seflder<n span_within(&setr, _l)));
  rlder<Tol)));
   {  deb)    let mut v = RcVfmt(&se      #[cfg(suild(:roup.stonal span,
     }span_within(e ofC`e);
s
/acewe`  deb`s FileAPIsring
/) -> Deliodefp ce failed")r rens: /thin(h to natustr =mBuiofaiFllusthis so|       f_satugmt(&srcthin(h to`(),
        }
   `. Tns"at anableo|     of ecuting comp`elf, spa`thin(h toeed as;belowr string: &str, s) -> Deli:k => ("", 
       -> Self {
        inner
         fmt(&se      #[cfg(suild(:roiler  deb
 reprd=> ("", 
       #) {
 b,s

    fn span_within(e ofRe '\"' [`pro othu     *udiffaser of) -> Delio   f_satugmt(&:oa ngt;ofthin(e ofpa/ Prr s s, squthe 
    //i,of
/curl.]
   eer string: &st) -> Deli {
         => ("", ym: prong)]emut().exte) -> Deli bspan_within(e ofRe '\"' s so`om(output)
usemve   .it stabthe ) -> Deld re `!Syn`  deb`lorens: /thin(h tomustt stab_sem_must_tesrce failed")
plenyou'sacro ceer of) -> Delithin(h to_must_tesabove.ing(t: &str) ->d") {
        der {
     inner: streder {
     
    }
emut().exteSL>d") )bspan_within(e ofRe '\"' s so|       f_sef) -> Deli offuerrs Am(ouc     spo|   t be accthin(e ofec to n`  deb`lorens: /thin(h to```Optithin(e ofpf) -> Span {
        self.span
 /tes(1288888888^^^^^^^thin(h to```lf, flf) -> Span {
        self.span
    }(),
     }
emut().exteSpan l Debug fthin(e ofRe '\"' s so|    postt be ass_semlpot be ) -> Delioffuerrs gmt(&lorens: /thin(h to```Optithin(e ofpf) -> Span_lpot {
        self.span
 /tes(128888888888888^thin(h to```lf, flf) -> Span_lpot {
        self.span
    }(),
     }
emut().exteSpan_lpot l Debug fthin(e ofRe '\"' s so|    postt be ass_semclip be ) -> Delioffuerrs gmt(&lorens: /thin(h to```Optithin(e ofpf) -> Span_clipe {
        self.span
 /tes(1288888888888888888888^thin(h to```lf, flf) -> Span_clipe {
        self.span
    }(),
     }
emut().exteSpan_clipe l Debug fthin(e ofRe '\"'    ebjeuilrstabholdsuerrs gmt(&'smvs),
_lpot l`.rs.* AsRh to`Span_clipe l`ersgeec fa(am a heyund;mp cnS deb s ! # Thrro`, tholdstr* AsRh toely AP2/nly ocppy:viduacyo)r string: &st) -> _Span {
        anlimS pug(span_locae:limS pu
 repr    }
uild()span_within(e ofCo_figuthss_sem|       f`!Syn`  deb`'sf) -> Deli rate tou'satssin_macllPhin(e ofc/  .ilerens: /thin(h to natuked as;iFllu**ou'**usthis so|    ocedy-onl gin_macllye   .io|   te.* AsRh tobyuerrs gmt(&rate toc_macrltnwFllur yousthis so|    ocer of) -> Delithin(h to    }e dhis solatio ocer of`  deb`lorens(&mut self, span: Span) {
        self.span = span;
  ).exteSlf, spanattr#) {
 b.fieldure ee ofP sttser ofgmt(&s  pub fn pat stabs   ldoptilippy::c,  to_u32;,
  .31.0ae ofinal APIss us,gmt(&s(moduloonly o),Iteceptp:Toftion,
 dn`om(ouI) -::  deb`s
e of File` => ("", ""),
 `f) -> Deli .or Literal {
    ffmt(&self, f: &nut fmt::Fort::Resulmatter) -> fmt::Result {
        Display::fmt(&self.repr, f)
    }
uild( plt::ResultDebug for Group {
    fn fmt(&self, f: &nut fmt::Fort::Resulmatter) -> fmt::Result {
        Display::fmt(&se:Debu, f)
    }
uild( plt::ResultDebug for e ofAy`P oth`ciat y e whicp othu     */(all(spa //! ``+`o2`-`of
/`#`r ex/he ofMispi/(all(spa lpokenSt////! ``+= othe  deb s ! iffaserwo prop    acro2 m/y`P oth`c Filed.

// Pro t:: offu`(),ce w`o_must_te.)]
pub(crate) struct reamBuilP othlay::fmchral {
,s

  s),ce w   sec::vec_ini       sel,s the ofWheec faay`P oth`ciatfoy::cld rmmedi);
l.]
y ubhec fa`P oth`c(&s  y::cld b.he ofubhec fae e faat
whDellatce.)]
pub(crat Eq)]te) s::D);
   ate)
pub(crattruct renumk sec::v.span
 /tesE.g. `+`oi a`Al,
 `f n `+ =`o2`+ring)`of
/`+r.`.uan
 Al,
 ,pan
 /tesE.g. `+`oi a`Jostt`f n `+=`of
/`'`oi a`Jostt`f n `'#`lorens: /thin(h toAavailablelq)] e whic Usag/`'`oecuter: c Fileiing);
   ynal  t::ler we oferfe``sh a`'ring)`lorensJostt,s thmBuilP othlay::fme ofC`e);
s
/acewe`P oth`c[. InAPIsring
//(all(spa defps),ce wlerens: /thin(h to ng/`ch othg
//!  to
//! ractringcp othu     */(all(spa pokm\\todobyuerller we ofecrouage bool {wing compo other chose nannolerens: /thin(h to ng/_must_tes`P oth`c Fse have whre set of |    oce`(),
        }
   `thin(e of sary.ecutedpo rike builfiguthds FileAPIs`elf, spa`uked as;belowr string: &str, schral {
, s),ce w   sec::v     inner
         P othlay::fm= cursor.h,      #[cfg(sssec::vec_ini #[cfg(ssse    sel        }
   ,s

    fn span_within(e ofRe '\"' [`prtriueoffuerrs p othu     */(all(spa /' `/(al`lorens(&mut sas     i{
            .span = span;
  chDebug fthin(e ofRe '\"' s so|  c::v.ffuerrs p othu     */(all(spa,cppy:c   be wheec fthin(e ofit's rmmedi);
l.]  y::cld b. ubhec fa`P oth`ciner of ce failed"), scthin(h tota essedftit seracyour cd;mbfr usonal fimispi/(all(spa lpokenStthin(h to(`Jostt`),of
/it's   y::cld b. s rilhec fae e faat
whDellatceo(`Al,
 `)thin(e ofe s_semlpokenStrhasec32;ai youian.h( f, flf) -> Spac::v {
        selc::v.span
 o.checked_adcstr* AsRwithin(e ofRe '\"' s so|       f_srs p othu     */(all(spa.n(&self) -> Span {
        self.span
    }

    pub fn set_spane ofCo_figuth s so|       f_srs p othu     */(all(spa.n(&self) -> Slf, span: Span) {
        self.span = span;
    }

    pub fn sube ee ofP sttser ofp othu     */(all(spa /' ub fn pat stabs   ldoptilippy::c, the/ to_u32;,
  .31.0.onal APIss us,/(all(spa.nr Literal {
    fP othlay::fm Intut fmt::Formatter) -> fmt::Result {
        Display::fmt(&self.repr, f)
    }
.h,pl Debug for Literal {
    fP othlay::fm Intut fmt::Forormatter) -> fmt::Result {
        let mut debug = fmt.debug_struct("Literal");
    P othug.field("lit", &format_a/(al!("{   }
.hg.field("lit", &format_a_adcstr!("{   }
_adcstregative {
  ilerd_if_nontrivial(&mut debug, self.span);
             ) {
 b.field("sy    }
}
                e ofAywors;ofv
//! ocd ro sary.e{
 ! rackeywors;oa /egingvariher f-> Lr ex/he ofAntring);
   ustr israriestableidt ate,Unnoidemoidempostt,       rstcro2 m/y sary.haser ofXID_S_u32( err32;yodefp a tlf,eb ma sary.have whreXID_Co_  bu he of err32;yr ex/he of-o ng/on<Idn   t. If you'santring);
   . Ust `{
     

    `r ex/f-oAferfe``shIf you'santring);
   . Ust `sys> Dife``sh` propagar ex/he ofAntring);
   ustr );
  hds File`

   
 rep`oi apokm\\todoe Optiav
//!he ofkeywors,     ghb//!
//! ate,thr  ghsatss[`P    /! pg
//!   aher cd jeuis
e of
//! keyworss. Ust `//! #     (

   
 ut.htmany)`ails.
//!
//! se catry. n he ofr haviauioffu`

   
 rep`r ex/he of[`P    /!rs/syn/1.0/syn/macro.parse_macut.ht/trait.P     Unstabl/he of# Exag
//s ex/he ofAycewering).ecutedpc`e);
  [. In o   t. Ioc_ma APIs`

   
 rep`oo other .
e ofA   // to
//! rur_val d oc
/ici/you sary.g)]
 nser of-> Lelf, _u    he ofr haviar ocer oflf,.det. Ifing);
   .rex/he ofe that/ting /!
//! [syner{

   ,  selproc_/he of -> ai      /tes(128 fmt     ring).= 

   
 rep_a/   igraphy",  sel        }
   )roc_/he ofs noersttln
            ring))roc_///! Iofe that/he ofAntring).ecutedpin_mapopy::t am")
aP    }ailed")
oc_ma APIs` Usag!`eanwhile `/he ofe that/ting /!
//! [syner{

   ,  selproc_/ting  Usag:: Usagroc_/he of -> ai      /tes(128 fmtring).= 

   
 rep_ademo",  sel        }
   )roc_/he ofs no ofC`e);

/avariher fippy::vu sy APIashIf ywhich 
   . /tes(128 fmttnay n.hi,  Usag!    fmt#ring).= 10; }roc_/he ofs no ofC`e);

/avariher fippy::vu ll uaesls back`d.

// Pro-> Lr ex/s(128 fmtlibp ring).= 

   
 rep_{}", se
  r, _     ring)),  sel        }
   )roc_/s(128 fmttnay n.hi,  Usag!    fmt#libp ring).= 10; }roc_///! Iofe that/he ofAo   t. I deb s ! # Thrremver giing).le e most recthr  ghsAPIs`to_   t.   `th toeed asle `/he ofe that/t#ting /!
//! [syner{

   ,  selproc_/t#hat/t#t fmtring).= 

   
 rep_aubhec f_fing);
   ",  sel        }
   )roc_/t#hat/ttesExaginever giing)./' ub fn par ex/s fmtring)_   t. .=  
   .to_   t.   roc_/tiftring)_   t. .lot l > 60   /tes(128ersttln
  Veris:
. Ifing);
   :      ring)_   t. )oc_///! Iofe th]
pub(crate) struct reamBuil

   self, flder<Topiler

   ,w,
  _in thr: Mn thr,s thmBuil

   self, f: &tr, rlder<Topiler{
        let mut v = RcV

   self, fathBuf::uild(   };
        _in thr: Mn thr,s

    fn span_within(h toC`e);
s
/acewe`Iing)`o FileAPIsring
/`   t. `/! ourllfaser ofcedurale.* AsRh to`Span`lerens: /thin(h to ng/`   t. `/!hg
//!  to
//! ractringcring);
   upokm\\todobyuerller we ofecrouage bool {wing compo other chose nannolerens: /thin(h tomustt stab`Span`,rour/ Prlyother crc,builfiguthser ofpub fn u i
        thin(h to   f_srs ring);
   .rce_t: /thin(h toA offuerrs A`shI`(),
        }
   ` oc
/ici/youopts-inero "d)))-attr"thin(h topub fn unnot be acateiing);
   ync`e);
  'll u natulated Fllur cd `locatthin(h tot asf acceswed o "\\to_ dithe comahis solet_cursr's [`pr   By d))),.rs.* AsRh tolike buidemahis so   By d))) attr  Fllur cher use ref
 ersme.
//! ourll.
_sit: /thin(h toLy::r/nly oc//! ``(),
  elf {
    `; Fllual::cxts lpt-inerothin(h to"ippfilesrs-attr"opub fn unnot be acateiing);
   ync`e);
  'll u natthin(e ofeated Fllur cd `locat/!his solet_cursr's [`pr   By ippfilesrs defp/ec fthin(e ofuidemahis so   By d))) attr  Fllu from
//er use ref
 ersme.
/.
_sit: /thin(h toDue ass_semcur/ Prosmp  tan   spepub fn utnatustr =mBuiof, un//! p/ec fthin(e ofe   .i,od quithssa/`(),
`oe Opticedurale.mahistr =mBuiurst acro: /thin(h to#   nnosarens: /thin(h toPannos pfier g         t. If yoeiec faaykeywors;nat
/a/egingvariher thin(h toI> Lr,hs!
//othe  frosure wheec f  n asn stre
       santring);
   .rs.* AsRh tot_ma/! Rhrs.l
// py baceoid
,ting* AsRh to<a href="/syn/1.0/syn/macro.parse_macfnput.htmsn  Unst"><uidepan
 /tes(1adge&l"p avang-panus:0;">sys> ut.htmsn </uide></a><uidepan
 /tes(1adge&l"p avang-lefs:0;">::&lt;Iing)&gt;</uide>thin(h to_c_macro`, th

   
 rep`r string: &str, ssn strlt<Tok
        self.   let mut v = RcV

        }
piler

   
 rep_sn str
     #) {
 b(span_within(e ofSashI/' `

   
 rep`rate tc`e);
s
/arawtring);
   .(`r#ring)`)of a * AsRh to`S  t. `/!hg
//!  to
//! ractringcring);
   upokm\\todobyuerlfecrouagethin(h to(acro code.keyworss, e.g. `fn`)ofKeyworssu sary.Is thst recent    thin(e ofeegmy::l (e.g. `   }`, `  fea`)othe  frosupp  ted,rdefp Fllulying athin(e ofpannolerensng: &str, _rawssn strlt<Tok
        self.   let mut v = RcV

        }_rawssn str
     )span_within(&setr, _rawssn strlt<Tok
        self.   let mut v = RcV

        }
piler

   
 rep_rawssn str
     #) {
 b(span_within(e ofRe '\"' s so|    emverrs `Iing)`.lf, flf) -> Span {
        self.span
    }(),
     }
emut().exteSpan l Debug fthin(e ofCo_figuthss_sem|    emverrs `Iing)`,ftion,
 dn"at at. If:l pub fn thin(e ofuild.rslorens(&mut self, span: Span) {
        self.span = span;
  ).exteSlf, spanattr#) {
 b.fieldure emBuilPpub(crato   f

   self, f: &: &T) -> bool {
  {
        // XXX(nika): S self) {
  == th("r#) {
 fieldure emBui<T>lPpub(crat<T>l   f

   
ssed fieldT: ?Sizodo+oA Ref<sn >,
elf, f: &: &T) -> bool {
  T     // XXX(nika): S self) {
  == th("rDebug for enStreto   f

   see emBuilPpub(crOrdo   f

   self, f: &ppub(cr_cmp&T) -> bool {
  {
        {
     O libt. >g(fuzzing)]  mc!
   .cmp&ool {l Debug for GroupOrdo   f

   self, f: &cmp&T) -> bool {
  {
        { libt. XX(nika): S selfto_   t.   .cmp&Tth("r#to_   t.    Debug for GroupHasho   f

   self, f: &hash<H: Hasher>&T) -> bhashermatter)H)XX(nika): S selfto_   t.   .hash(hasherb.fieldure ee ofP sttser ofring);
   .r pub fn pat stabs   ldoptilippy::c,  to_u32;,
  .31.0ae ofinal APIss us,ring);
   .rr Literal {
    f

   self, f: &tut fmt::Formatter) -> fmt::Result {
        Display::fmt(&self.repr, f)
    }
uild( pl Debug for enStral {
    f

   self, f: &tut fmt::Formatter) -> fmt::Result {
        Display::fmt(&se:Debu, f)
    }
uild( pl Debug for h toAySpan {
*d)), n (`"hello"`)inbyte*d)), n (`b"hello"`)in/(all(spa (`'a'`)ihe ofryte*/(all(spa (`b'a'`)inteaamtegpa lr flo   be posttncters
#'ll uo
#'ll ou!he ofub uffix (`1`, `1u8`, `2.3`, `2.3f32`).) `/he ofB/ Xe   fpan {
sc//! `` if ` defp`f{
s `f)ou from
:
. Ised implemethe! IofeIing)`o.)]
pub(crate) struct reamBuilscaped)self, flder<Topilerfcaped),w,
  _in thr: Mn thr,s thsuffixed_nu!b uffixed_stt_fpan {
scelf, f($($I> L:ring).=> $kind:ring),)*     ($(span_loca oofC`e);
s
/aceweluffixedaamtegpa Span {
* FileAPIssedurale.mtriue.span_loca oospan_loca oof natuo other c Fllul`e);

/naamtegpa Sp! ``1u32`sssed mnl gin_mgxtxpect("fa ooftriueosedurale.mrs APIs  rstcppubr's [`pr    }adefp a tin_mg {
*atthin(hin(h totlso luffixedaahis soepy.lscaped)spc`e);
  [. In        ncters
 be{
thin(hin(h to frosurv    duralbugpscthr  ghs`om(output)
user*d)), n odefpe{
 ! thin(hin(h tobrce faamal Aw)
    }e (`-`odefpeoatt    Span {
).span_loca oospan_loca oofscaped)spc`e);
  thr  ghsAPatuked as;have whre`(),
        }
   `thin(hin(e ofeatedby ! To op,f sary.ecutedpuilfiguthds FileAPIs`elf, spa`uked asthin(hin(h tobelowr strirens(&mut s$I> L(   $kind {
    aped)self, fffffffff  aped)     }
piler  aped)  $I> L( ))s

    fn span_)* s thsuffixed_nu!bun uffixed_stt_fpan {
scelf, f($($I> L:ring).=> $kind:ring),)*     ($(span_loca oofC`e);
s
/aceweun uffixedaamtegpa Span {
* FileAPIssedurale.mtriue.span_loca oospan_loca oof natuo other c Fllul`e);

/naamtegpa Sp! ``1`sssed mnl gin_mgxtxpect("fa ooftriueosedurale.mrs APIs  rstcppubr's [`pr    }. No luffix*atthin(hin(h tosedurale.mon  natu    },unnot be acateinvet_curssc//! thin(hin(h to`  aped)  i8_un uffixed(1) othe those librurothin(hin(h to`  aped)  u32_un uffixed(1) .lscaped)spc`e);
  [. In        ncters
 thin(hin(h toe{
  frosurv    duralbugpscthr  ghs`om(output)
user*d)), n odefpe{
thin(hin(h tobeobrce faamal Aw)
    }e (`-`odefpeoatt    Span {
).span_loca oospan_loca oofscaped)spc`e);
  thr  ghsAPatuked as;have whre`(),
        }
   `thin(hin(e ofeatedby ! To op,f sary.ecutedpuilfiguthds FileAPIs`elf, spa`uked asthin(hin(h tobelowr strirens(&mut s$I> L(   $kind {
    aped)self, fffffffff  aped)     }
piler  aped)  $I> L( ))s

    fn span_)* s th    pu aped)self, f: &tr, rlder<Topilerscaped))    let mut v = RcV  aped)self, fffffffffuild(   };
        _in thr: Mn thr,s

    fn span_within(&setr, _l)));
  rlder<Tol)));
   {scaped))    let mut v = RcV  aped)self, fffffffffuild(:roup.stonal span,
         _in thr: Mn thr,s

    fn span_within( uffixed_stt_fpan {
s!self, fffffu8_ uffixeda   u8,s

    fnu16_ uffixeda   u16,s

    fnu32_ uffixeda   u32,s

    fnu64_ uffixeda   u64,s

    fnu128_ uffixeda   u128,s

    fnusizo_ uffixeda   usizo,s

    fni8_ uffixeda   i8,s

    fni16_ uffixeda   i16,s

    fni32_ uffixeda   i32,s

    fni64_ uffixeda   i64,s

    fni128_ uffixeda   i128,s

    fnisizo_ uffixeda   isizo,s

  within(un uffixed_stt_fpan {
s!self, fffffu8_un uffixeda   u8,s

    fnu16_un uffixeda   u16,s

    fnu32_un uffixeda   u32,s

    fnu64_un uffixeda   u64,s

    fnu128_un uffixeda   u128,s

    fnusizo_un uffixeda   usizo,s

    fni8_un uffixeda   i8,s

    fni16_un uffixeda   i16,s

    fni32_un uffixeda   i32,s

    fni64_un uffixeda   i64,s

    fni128_un uffixeda   i128,s

    fnisizo_un uffixeda   isizo,s

  within( oofC`e);
s
/aceweun uffixedaflo   be-posttnfpan {
r rens: /thin(h to natustr =mBuiofaatulimila ersme.y APSp! ``  aped)  i8_un uffixed`sssed thin(h tota tflo  'sftriueoatuon\\tododithe cominal APIs    }ate tou luffix*atthin(c_/tingd, scrltne{
 ! rinferrodoe Optiav`f64`/py::rciner ofprocmacrparens: / scaped)spc`e);
  [. In        ncters
 be{
  frosurv    dural-bugpsthin(h totar  ghs`om(output)
user*d)), n odefpe{
 ! obrce faamal Aw)
    }e (`-`thin(h totefpeoatt    Span {
).span_: /thin(h to#   nnosarens: /thin(h to natuo other cd quithss stab_semsedurale.mflo  ciatffilee)]hat
exag
//thin(e ofifrltnich i
fileyser*NaNatnatuo other chose nannolerens(&mut sf64_un uffixed(rmaf64 {
    aped)self, fffffstc.rt!(f    ffilee()g.field("sy  aped)     }
piler  aped)  f64_un uffixed(rb(span_within(e ofC`e);
s
/aceweluffixedaflo   be-posttnfpan {
r rens: /thin(h to natustr =mBuiofa Fllul`e);

/ Span {
*Sp! ``1.0f64`/ssed mnl gtriue
hin(h tosedurale.mrs APIspre ecode.ppubr's [`pr    }adefp`f64`/rs APIssuffix*ofthin(e ofcaeb    }. Trrs Am(ouc Fllualwaysu! rinferrodoe Optianp`f64`/rnuerller we ofprocmacrp scaped)spc`e);
  [. In        ncters
 be{
  frosurv   thin(h to_ural-bugpsotar  ghs`om(output)
user*d)), n odefpe{
 ! obrce faamal Aw)thin(h to    }e (`-`odefpeoatt    Span {
).span_: /thin(h to#   nnosarens: /thin(h to natuo other cd quithss stab_semsedurale.mflo  ciatffilee)]hat
exag
//thin(e ofifrltnich i
fileyser*NaNatnatuo other chose nannolerens(&mut sf64_ uffixed(rmaf64 {
    aped)self, fffffstc.rt!(f    ffilee()g.field("sy  aped)     }
piler  aped)  f64_ uffixed(rb(span_within(e ofC`e);
s
/aceweun uffixedaflo   be-posttnfpan {
r rens: /thin(h to natustr =mBuiofaatulimila ersme.y APSp! ``  aped)  i8_un uffixed`sssed thin(h tota tflo  'sftriueoatuon\\tododithe cominal APIs    }ate tou luffix*atthin(c_/tingd, scrltne{
 ! rinferrodoe Optiav`f64`/py::rciner ofprocmacrparens: / scaped)spc`e);
  [. In        ncters
 be{
  frosurv    dural-bugpsthin(h totar  ghs`om(output)
user*d)), n odefpe{
 ! obrce faamal Aw)
    }e (`-`thin(h totefpeoatt    Span {
).span_: /thin(h to#   nnosarens: /thin(h to natuo other cd quithss stab_semsedurale.mflo  ciatffilee)]hat
exag
//thin(e ofifrltnich i
fileyser*NaNatnatuo other chose nannolerens(&mut sf32_un uffixed(rmaf32 {
    aped)self, fffffstc.rt!(f    ffilee()g.field("sy  aped)     }
piler  aped)  f32_un uffixed(rb(span_within(e ofC`e);
s
/aceweluffixedaflo   be-posttnfpan {
r rens: /thin(h to natustr =mBuiofa Fllul`e);

/ Span {
*Sp! ``1.0f32`sssed mnl gtriue
hin(h tosedurale.mrs APIspre ecode.ppubr's [`pr    }adefp`f32`srs APIssuffix*ofthin(e ofcaeb    }. Trrs Am(ouc Fllualwaysu! rinferrodoe Optianp`f32`srnuerller we ofprocmacrp scaped)spc`e);
  [. In        ncters
 be{
  frosurv   thin(h to_ural-bugpsotar  ghs`om(output)
user*d)), n odefpe{
 ! obrce faamal Aw)thin(h to    }e (`-`odefpeoatt    Span {
).span_: /thin(h to#   nnosarens: /thin(h to natuo other cd quithss stab_semsedurale.mflo  ciatffilee)]hat
exag
//thin(e ofifrltnich i
fileyser*NaNatnatuo other chose nannolerens(&mut sf32_ uffixed(rmaf32 {
    aped)self, fffffstc.rt!(f    ffilee()g.field("sy  aped)     }
piler  aped)  f32_ uffixed(rb(span_within(e of   #[cnfpan {
r rens: &str) ->t.  sn strlt<Tok {
    aped)self, fffff  aped)     }
piler  aped)   ->t.  sn strb(span_within(e ofC(all(spa //an {
r rens: &str)/(all(spaschral {
 {
    aped)self, fffff  aped)     }
piler  aped)  /(all(spaschb(span_within(e ofByte*d)), n //an {
r rens: &str)ryte_   t.  slt<[u8] {
    aped)self, fffff  aped)     }
piler  aped)  ryte_   t.  sb(span_within(e ofRe '\"' s so|    ennvera_debu tnatufpan {
r rens: &str) pan {
        self.span
    }(),
     }
emut().exteSpan l Debug fthin(e ofCo_figuthss_sem|    an_oci);
     f_srs fpan {
r rens: &str) lf, span: Span) {
        self.span = span;
  ).exteSlf, spanattr#) {
 b.fieldurthin(e ofRe '\"'  /`(),
`oestable ub ubngt;of `   }eSpan l`e
      //! atlythin(h tota ty strinryte othert ana`rt an`.oRe '\"' `),
 `f   ta tw  ld-b thin(h totrrmmedulateaasolceduralta tburals;of `   }`parens: /thin(h toWat_str: compiler
//! ty[ver_eream {
   aped)   ubn),
`]uked as;lethin(h toIs back to R.oWls.
ne/coest. In FileIncro.
//!   Meanwhioou'soc_ma athin(h toIs back`procmacro2_satuked as; Fllualwaysual);
  `),
 `parens: /thin(h to[`er_eream {
   aped)   ubn),
`]ust-lang.org/proc_macro/
//!
//! - **BreamBui.  aped)  tml#ked as  ubn),
 rens: &str) ubn),
<R: Rt anBurals<usizo>>&T) -> brt an: Rn> {
        #[cfg(fuzzing)]_mut().exte ubn),
(rt anb m
/((),
     }(span_within(e tem ian.h    f_sef` Usag!`eanwhioe Oing ils.
str =mBuiuma aro.
/-! [synthin(e te e faaueb macranwhixed_nu $:Span {
*    },ussary.
  alut)dy knownoe Optthin(e tactringcfpan {
ro natuavoidsual//!
//!/tring   be ah  Span {
'sf   t. thin(e t deb s ! # Thrus naturs ou's: &lic APIlhec faeh      f Usag.dlved]
pl = iddentrulved_at(un afeookenTre_   _un"aecked( deblt<Tok {
  let mut v = RcV  aped)     }
piler  aped)  fTre_   _un"aecked( deb)sFrom<TokenTree> for   s   fn aped)self, frror;Err =fnn fmt(&;
: prookenTre_   ( deblt<Tok {
    Disp<S -> bnn fmt(&fg(fuzzing)] debput.ht(b m
/(  aped)     }b m
/_err(|).ext|fnn fmt(&self, fffffffffuild(   };
        _in thr: Mn thr,s

    fn  Debug for Group {
    fn u aped)self, f: &tut fmt::Formatter) -> fmt::Result {
        Display::fmt(&se:Debu, f)
    }
uild( pl Debug for     peral {
    fn aped)self, f: &tut fmt::Formatter) -> fmt::Result {
        Display::fmt(&self.repr, f)
    }
uild( pl Debug for e ofP &lic pg
//!   aher cde   ls    f_sef`om(output)
usrror,oc-macase apednSt/.uct rmoesrce f_s     inner: ing :usiz::in thr::Mn thr;ner: ing :usiz::{pg
,som(ouI) -};ner: ing :orer, f)::{mt::Foe:Deb};
: pro_at(ung :usiz::om(output)
;
thin(h toAninapednSt )]
 f`om(output)
u'smvom(ouI) -`slerens: /thin(h to ng/napedner ciat"shal::c", e.g. tng/napedn  f oest'ture u.htaamalthin(h to) -> Deld gmt(&s,rdefp_must_' whols,gmt(&s*/'  se faTokee.dlved]
pub(crate) stru pro_at(eamBuil
malI", ym: prong)]lder<Topilerom(ouI) -I", ,s

    fn_in thr: Mn thr,s

  within(mBuil
apedn  f   f
malI", ym: prong)]rror;I",m =fom(ouI) -;
thin(f, f: &nption Span) {n> {
       om(ouI) -         #[cfg(s_mut().extenptio Debug

  within(f, f: &sizo_leIion<String> (usizo,
       usizo>)        #[cfg(s_mut().extesizo_leIio)s

    fn span_within(enStral {
    f
malI", ym: prong)]: &tut fmt::Formatter) -> fmt::Result {
        Display::fmt(&sng)]:. "\\e_   ("der {
     i")?;y::fmt(&sng)]:.d_if_nlisio).eebuges!
   .ce) s l for                span_within(enStr
malI", dn  f   fder {
     inner: strerror;I",m =fom(ouI) -;
er: strerror;ImalI", y=;ImalI", ;
thin(f, f: &amal_Deli <String> 
malI", ym: prong)] RcV
malI", ym: prong)] RcVng)]lder<To self) {
   mal_Deli span,
             _in thr: Mn thr,s

    fn       li