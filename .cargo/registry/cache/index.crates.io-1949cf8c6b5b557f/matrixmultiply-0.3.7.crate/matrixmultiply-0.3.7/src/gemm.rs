// Copyright 2016 - 2018 Ulrik Sverdrup "bluss"
//
// Licensed under the Apache License, Version 2.0 <LICENSE-APACHE or
// http://www.apache.org/licenses/LICENSE-2.0> or the MIT license
// <LICENSE-MIT or http://opensource.org/licenses/MIT>, at your
// option. This file may not be copied, modified, or distributed
// except according to those terms.

#[cfg(feature="std")]
use core::cell::UnsafeCell;
use core::cmp::min;
use core::mem::size_of;
use core::slice;

use crate::aligned_alloc::Alloc;

use crate::ptr::Ptr;
use crate::util::range_chunk;
use crate::util::round_up_to;

use crate::kernel::Element;
use crate::kernel::GemmKernel;
use crate::kernel::GemmSelect;
#[cfg(feature = "cgemm")]
use crate::kernel::{c32, c64};
use crate::threading::{get_thread_pool, ThreadPoolCtx, LoopThreadConfig};
use crate::sgemm_kernel;
use crate::dgemm_kernel;
#[cfg(feature = "cgemm")]
use crate::cgemm_kernel;
#[cfg(feature = "cgemm")]
use crate::zgemm_kernel;
use rawpointer::PointerExt;

/// General matrix multiplication (f32)
///
/// C ← α A B + β C
///
/// + m, k, n: dimensions
/// + a, b, c: pointer to the first element in the matrix
/// + A: m by k matrix
/// + B: k by n matrix
/// + C: m by n matrix
/// + rs<em>x</em>: row stride of *x*
/// + cs<em>x</em>: col stride of *x*
///
/// Strides for A and B may be arbitrary. Strides for C must not result in
/// elements that alias each other, for example they can not be zero.
///
/// If β is zero, then C does not need to be initialized.
pub unsafe fn sgemm(
    m: usize, k: usize, n: usize,
    alpha: f32,
    a: *const f32, rsa: isize, csa: isize,
    b: *const f32, rsb: isize, csb: isize,
    beta: f32,
    c: *mut f32, rsc: isize, csc: isize)
{
    sgemm_kernel::detect(GemmParameters { m, k, n,
                alpha,
                a, rsa, csa,
                b, rsb, csb,
                beta,
                c, rsc, csc})
}

/// General matrix multiplication (f64)
///
/// C ← α A B + β C
///
/// + m, k, n: dimensions
/// + a, b, c: pointer to the first element in the matrix
/// + A: m by k matrix
/// + B: k by n matrix
/// + C: m by n matrix
/// + rs<em>x</em>: row stride of *x*
/// + cs<em>x</em>: col stride of *x*
///
/// Strides for A and B may be arbitrary. Strides for C must not result in
/// elements that alias each other, for example they can not be zero.
///
/// If β is zero, then C does not need to be initialized.
pub unsafe fn dgemm(
    m: usize, k: usize, n: usize,
    alpha: f64,
    a: *const f64, rsa: isize, csa: isize,
    b: *const f64, rsb: isize, csb: isize,
    beta: f64,
    c: *mut f64, rsc: isize, csc: isize)
{
    dgemm_kernel::detect(GemmParameters { m, k, n,
                alpha,
                a, rsa, csa,
                b, rsb, csb,
                beta,
                c, rsc, csc})
}

/// cgemm/zgemm per-operand options
///
/// TBD.
#[cfg(feature = "cgemm")]
#[non_exhaustive]
#[derive(Copy, Clone, Debug)]
pub enum CGemmOption {
    /// Standard
    Standard,
}

#[cfg(feature = "cgemm")]
/// General matrix multiplication (complex f32)
///
/// C ← α A B + β C
///
/// + m, k, n: dimensions
/// + a, b, c: pointer to the first element in the matrix
/// + A: m by k matrix
/// + B: k by n matrix
/// + C: m by n matrix
/// + rs<em>x</em>: row stride of *x*
/// + cs<em>x</em>: col stride of *x*
///
/// Strides for A and B may be arbitrary. Strides for C must not result in
/// elements that alias each other, for example they can not be zero.
///
/// If β is zero, then C does not need to be initialized.
///
/// Requires crate feature `"cgemm"`
pub unsafe fn cgemm(
    flaga: CGemmOption, flagb: CGemmOption,
    m: usize, k: usize, n: usize,
    alpha: c32,
    a: *const c32, rsa: isize, csa: isize,
    b: *const c32, rsb: isize, csb: isize,
    beta: c32,
    c: *mut c32, rsc: isize, csc: isize)
{
    let _ = (flaga, flagb);
    cgemm_kernel::detect(GemmParameters { m, k, n,
                alpha,
                a, rsa, csa,
                b, rsb, csb,
                beta,
                c, rsc, csc})
}

#[cfg(feature = "cgemm")]
/// General matrix multiplication (complex f64)
///
/// C ← α A B + β C
///
/// + m, k, n: dimensions
/// + a, b, c: pointer to the first element in the matrix
/// + A: m by k matrix
/// + B: k by n matrix
/// + C: m by n matrix
/// + rs<em>x</em>: row stride of *x*
/// + cs<em>x</em>: col stride of *x*
///
/// Strides for A and B may be arbitrary. Strides for C must not result in
/// elements that alias each other, for example they can not be zero.
///
/// If β is zero, then C does not need to be initialized.
///
/// Requires crate feature `"cgemm"`
pub unsafe fn zgemm(
    flaga: CGemmOption, flagb: CGemmOption,
    m: usize, k: usize, n: usize,
    alpha: c64,
    a: *const c64, rsa: isize, csa: isize,
    b: *const c64, rsb: isize, csb: isize,
    beta: c64,
    c: *mut c64, rsc: isize, csc: isize)
{
    let _ = (flaga, flagb);
    zgemm_kernel::detect(GemmParameters { m, k, n,
                alpha,
                a, rsa, csa,
                b, rsb, csb,
                beta,
                c, rsc, csc})
}

struct GemmParameters<T> {
    // Parameters grouped logically in rows
    m: usize, k: usize, n: usize,
    alpha: T,
    a: *const T, rsa: isize, csa: isize,
    beta: T,
    b: *const T, rsb: isize, csb: isize,
    c:   *mut T, rsc: isize, csc: isize,
}

impl<T> GemmSelect<T> for GemmParameters<T> {
    fn select<K>(self, _kernel: K)
       where K: GemmKernel<Elem=T>,
             T: Element,
    {
        // This is where we enter with the configuration specific kernel
        // We could cache kernel specific function pointers here, if we
        // needed to support more constly configuration detection.
        let GemmParameters {
            m, k, n,
            alpha,
            a, rsa, csa,
            b, rsb, csb,
            beta,
            c, rsc, csc} = self;

        unsafe {
            gemm_loop::<K>(
                m, k, n,
                alpha,
                a, rsa, csa,
                b, rsb, csb,
                beta,
                c, rsc, csc)
        }
    }
}


/// Ensure that GemmKernel parameters are supported
/// (alignment, microkernel size).
///
/// This function is optimized out for a supported configuration.
#[inline(always)]
fn ensure_kernel_params<K>()
    where K: GemmKernel
{
    let mr = K::MR;
    let nr = K::NR;
    // These are current limitations,
    // can change if corresponding code in gemm_loop is updated.
    assert!(mr > 0 && mr <= 8);
    assert!(nr > 0 && nr <= 8);
    assert!(mr * nr * size_of::<K::Elem>() <= 8 * 4 * 8);
    assert!(K::align_to() <= 32);
    // one row/col of the kernel is limiting the max align we can provide
    let max_align = size_of::<K::Elem>() * min(mr, nr);
    assert!(K::align_to() <= max_align);

    assert!(K::MR <= K::mc());
    assert!(K::mc() <= K::kc());
    assert!(K::kc() <= K::nc());
    assert!(K::nc() <= 65536);
}

/// Implement matrix multiply using packed buffers and a microkernel
/// strategy, the type parameter `K` is the gemm microkernel.
// no inline is best for the default case, where we support many K per
// gemm entry point. FIXME: make this conditional on feature detection
#[inline(never)]
unsafe fn gemm_loop<K>(
    m: usize, k: usize, n: usize,
    alpha: K::Elem,
    a: *const K::Elem, rsa: isize, csa: isize,
    b: *const K::Elem, rsb: isize, csb: isize,
    beta: K::Elem,
    c: *mut K::Elem, rsc: isize, csc: isize)
    where K: GemmKernel
{
    debug_assert!(m <= 1 || n == 0 || rsc != 0);
    debug_assert!(m == 0 || n|| n == 0crre1     a,  csb  csb  csb  p00(m . elemente, Compute C ← �Cs andreatun)
    if(m == 0 ||km == 0 || n == 0 {
       reatun cn_t_ betac(mk, n  beta  c, rsc, csc);
    }

    letknc <= K::nc(R;
    letkkc <= K:knc(R;
    letkmc <= K:mnc(R;
    ensure_kernel_paramp::<K>)R;

    let a =Ptr4(a);
    let a =Ptr4ba);
    letca =Ptr4c)R;

    let(n_threate,tpb) ={get_thread_pooc(R;
    let_thread confi) = LoopThreadConfiK::ewp::<K> m, k, n n_threat(R;
    letnap) =_thread confi.num_ pac_a>)R;

    let (mut pacsin_ buffe, ap_isize,bp_isizb) = mak_ pacsin_ buffep::<K> m, k, n nap(R;
    letappa =Ptr4 pacsin_ buffe.ptr_(muc());
    let ppa =appb.addap_isizr * ap(R;a,  csb LOOP 5:l slietnn intonc _pants(B,� C)
    for(l5n nc)y in range_chun( n knc)y {
       d prin!("LOOP 5, {}n nc={?}",l5n nc));
        let b = b strid_.offset csbtknc *,l5));
        letca =cb strid_.offset ccbtknc *,l5));e
        //LOOP 4:l slietky inkc _pants(A,A B)
        // This_panicular, looe ca'ot be_parllealize) because the
        //C _chun (wrmitblzb)hissharze) btwehenitperation.;
        for(l64,kc)y in range_chun( k,kkce) {
           d prin!("LOOP 4, {}n kc={?}",l64,kc);0
            let b = b strid_.offset rsb,kkc *,l4);0
            let a = a strid_.offset cab,kkc *,l4);0;
            //Ppacsb -> B~;
            K: pac_nr(kcn nc, :slic::_fromraw__pant_(muc pp.ptr()e,bp_isizbT,
                      b.ptr()e, csbt rs);0;
            //Ffirstptire rmiting o C,  use usr's ` bet`a, elseaccu muate0
            let betpa = ifl4n == 0 f beta } else  <_>:: onc()};0;
            //LOOP 3:l slietmn intomc _pants(A,AC);
            range_chun( m, mc),
               ._parllea(_thread confi. loo3e,tpb,
               ._threadlocal(mo00(|(i, nt|e {
                    // t pacsind buffe A~ aper threa{
                    debug_assert!i < nap(R;
   
                ppb.addap_isizr *ib,
               }b,
               . fo_ eac(mo00(|tp, & mut pp, l3e,mc|e {
                   d prin!("LOOP 3, {}n mc={?}",l3e,mc(R;
   
                let a = a strid_.offset rsa,kmc *,l3(R;
   
                letca =cb strid_.offset rsc,kmc *,l3(R;{
                    //PpacsA -> A~{
                    K: pac_mr(kcn mc, :slic::_fromraw__pant_(mucapp.ptr()e,ap_isizbT,
                               .ptr()e, rsa, cs(R;{
                    //LOOP 20 and {
                    gemm packep::<K>nc, kcn mc,,
                                     alpha,
                
   
                ppb_t_*cons()e,bppb_t_*cons()e,
                
   
                betpe,
                
   
                c, rsc, cse,
                
   
               tp, _thread confi(R;
   
           }1);
        }
    }
}

// setupd buffe  for maske (rzeirtected ouhputof)c kernel*const ERNEL_MAX_SIZER: usize = 8 * 8 * ;l*const ERNEL_MAX_ALIGNR: usize =32;l*constMASK_BUF_SIZER: usize = ERNEL_MAX_SIZE +t ERNEL_MAX_ALIGN - 1t;

/ Ppointers into buffe willt be maucally:aligne0 aywagy,dute t

/ ebuse we p00(sehen oncsera inpuat forts(macos)e that loks lkse
// we don'tgert more thn 16-:aligne0 Allorationsoputof TLS

#[cf_attr(noty(targetose = macos")e, epr (alig( 32)")]
#[cf_attr((targetose = macos"e, epr (alig(162)")]
structMmasBbuffe  {
    buffep [u8;tMASK_BUF_SIZE],}
}

//Uuse threa locale if we ca;e thishis aseternevnt in theusinlse threated cas) becaus

//iethis_ossiblte toskips zersindoput thearrayD.
#[cfg(feature = "std")]_threadlocal6! {
   sitatctMASK_BUF: :UnsafeCel<MmasBbuffe> =;
       :UnsafeCelK::ew(MmasBbuffe    buffep [0;tMASK_BUF_SIZE] }1);
}

/// Loows 1 and20 :rount theµ-okernel
//s
/// + pp:g packedAs(A~)s
/// +bpp:g packedBs(B~)s
/// +nc:t columns fg packedBs
/// +kc:t columns fg packedA // rows fg packedBs
/// +mc:/ rows fg packedA]
unsafe fn gemm packe:<K>ncm: usize, cm: usize,mcn: usize,
                         alpha: K::Elem,
    
   
                pp:=Ptr< *const K::Ele>,+bpp:gPtr< *const K::Ele>,
                          beta: K::Elem,
    
   
               c:gPtr< *mut K::Ele>T, rsc: isize, csc: isize,     
   
               tp:, ThreadPoolCtx,_thread confi:= LoopThreadConfie)
    where K: GemmKerne,l
{
    let mr = K::MR;
    let nr = K::NR;
    //cheacs for the maso buffe  thatfints 8 x8x f31 and 8 x 4f64c kerners and alignmen;
    assert!(mr * nr * size_of::<K::Elem>() <= ERNEL_MAX_SIZE && (K::align_to() <= ERNEL_MAX_ALIGN);}

    #[cfgnoty(feature = "std"")]
    let mut mas_ bu] = masBbuffe    buffep [0;tMASK_BUF_SIZE] }R;a,  csb LOOP 2:d througm micrparners inppacked`b`s(B~,AC);
    range_chun( cr, nr
        ._parllea(_thread confi. loo2e,tpb,
       ._threadlocal(|_(i, nt|e {
            let mutpPtr;             #[cfgnoty(feature = "std"")]
            {
                debug_assert_eq!_ntv, 1);
               pPt) = mas_ bu. buffe.at_(mu_ptr());
            }
            #[cfg(feature = "std")]
           {;
               pPt) =MASK_BUF. wit(| bu| (* bu.rge()). buffe.at_(mu_ptr()));
            }
           pPt) =:alignptr((K::align_to(, pPt));
           :slic::_fromraw__pant_(mucpPt)as: *mut K::Elem, ERNEL_MAX_SIZE /* size_of::<K::Elem>(c)
        b,
       . fo_ eac(mo00(|_tp,  mas_ bu",l2r, n_|e {
            let ppa =bppb strid_.offset1e, cr * nr *l2);0
            letca =cb strid_.offset ccbt nr *l2);0;
            //LOOP 1:d througm micrparners inppacked`a`/ whlte`b`shis cositnts(A~,AC);
            for(l1e,mr_)y in range_chun(mc, mr)  {
                letappa =appb strid_.offset1e, cr *(mr *l10);
                letca =cb strid_.offset rsc,(mr *l10);
                 //GEMM, ERNEL
                 //NOTER:Ffor thermust kerner,/ietape forts benter tos
impy
                 //(alway ause thr maske  kernel functio!
                 if(K::alway_ maskeo() || r_ < nr) ||mr_ < mre {
                    maskea_kernel::_m, >(kcn  alpha app.ptr()e,bpp.ptr()e,
                
   
                     beta=cbptr()e, rsc, cse,
                
   
                     r_r, n_,  mas_ bu(R;
   
                cotinueR;
   
           }} else {
                   Ke::kerne(kcn  alpha app.ptr()e,bpp.ptr()e  beta=cbptr()e, rsc, cs(R;
   
           }*
            }
        1);
}

///AAlloraheae vector fgun initialize datad to beunsed forbotht pacsind buffes.l
//s
/// +A~/ neets b KC8 xMCx
/// + ~/ neets b KC8 xNCx
/// but we can make tem smrlleor in the matri)hissmrlleor thn  this(jmust ensurx
/// we p00(:rounsed pm to x multipel of the kernel size).
///
///nta:Numbeor fg buffers to Allos for .
///
/// Ratun  pacsind buffe  and size fgA~/(Tthe offses to ~/hisA~/ sizeptirs `na`a), size fgB~.]
unsafe fn mak_ pacsin_ buffe:<K> m: usize, k: usize, n: usize/nta:uisize)
   ->s(AAllo< K::Ele>T, usize/uisize)
    where K: GemmKerne,l
{
   /// max aligementrRequirement so x multipel of minMR, NR)r * sizofl<Ele>{
   /// becausea pac_ size so x multipel ofMR, ustautof bx aligis fnde
    let ) = min(,= K::mc());
    letk) = mink,= K::kc());
    let ) = minn,= K::nc());
   //(:round pm k, s to multipews fg(mr, n;
   //(:round pm to multipes fgkc;
    debug_assertne!(na,= 0);
    debug_assert!nan|| n28(R;
    letappac_ size=tk)* :round_up_tn(,= K:(MR);
    let ppac_ size=tk)* :round_up_tnn,= K:NMR);
    letn elea =appac_ size * a/ +bppac_ siz);
    d prin!("ppackedn ele={}n appac={}n bppac={}n;
   
        e={} c={} n={}n na={?}";
   
        n ele,=appac_ siz,+bppac_ sizn;
   
        e,k, n na0);
    (AAlloK::ew(n ele,=(K::align_to(),=appac_ siz,+bppac_ siz})
}

/// offses thepPt) fowardrs to Align to x specificbytWe coen;
/// safty: :align_ta must bea poweor fg two andpPt)v:alds for the pointerarwitmetic

#[inline]
unsafe fn:alignptr<T>(:align_tm: usize,mmutpPtc: *mut e) -> *mut e {
    in:align_ta!== 0 {
        letcurx_align =pPt)as: usize%n:align_t;

        if urx_align!== 0 {
           pPt) =*ptr.offset((:align_t -f urx_alig) /* size_of::Tm>(cR as isize);
        }
    }    pPt)
}

///C all theGEMM, kernel witha= maaskedd ouhputC).
// ;
/// 
impy rzeirtecr the Rm byNR, kernel ouhput to thep_assed
/// in` mas_ bu`,o andcopyo thenonr maske regtion to thehreel
///C.l
//s
/// + rows/ rows fg kernelun maske*
/// + ols:t cows fg kernelun maske*
#[inline(never)]
unsafe fn maskea_kerne<Tm, >(kk: usize, alpha: T,
                
   
        ab: *const T,
                              b: *const T,
                              beta: T,
    
    
   
               c:g *mut T, rsc: isize, csc: isize,
    
    
   
                rows/ usize, ols:tuisize,
    
    
   
                mas_ bu: & mut[T]e)
    where K: GemmKernel<Elem=T>  T: Element,
{
   ///
use colum  mjtor ordes for` mas_ bu`
    Ke::kerne(kn  alpha aa, b,T:: zer()e, mas_ bu.at_(mu_ptr()v, ,= K:(MR as isize);
   cn_t_ maskeaab_ betacl::_m, >( beta  c, rsc, cs,  rowe, ols, &* mas_ bu(R;
}

///Copyo ouhput in` mas_ bu`n to theactualtca matrix
///
/// C ←MB + �C   whereM` is the` mas_ bu`

#[inline]
unsafe fncn_t_ maskeaab_ betac<Tm, >( beta: T,
    
    
   
                       c:g *mut T, rsc: isize, csc: isize,
    
    
   
                        rows/ usize, ols:tuisize,
    
    
   
                        mas_ bu: &[T]e)
    where K: GemmKernel<Elem=T>  T: Element,
{
   ///note:  use e_parate functionwhere with`&T`rarguement for masd bus,
    //so  that the cmpileorseets that`c`o and` mas_ bu`n(nevet alia.{
    let mr = K::MR;
    let nr = K::NR;
    let mut a) = mas_ bu.at_ptr());
    forj_ in 0.nre {
        fori_ in 0.mre {
            if  <  rows&&rj_<t cows {
                letcpPt) =cb strid_.offset rsc,ib,
                           . strid_.offset ccbtj(R;
   
            if bet.is_ zer()e {
                   *cpPt) =*ab;csb  initializ;
   
           }} else {
                   (*cpPt)._mul_aslig(&beta);
                   (*cpPt)._add_aslig(*ab(R;
   
           }*
            }
            a.i:nc(R;
        }
    }
}

// Computejmust C ← �C*
#[inline(never)]
unsafe fncn_t_ betac:Tm>mk: usize, n: usize/ beta: T,
    
    
   
           c: *mut T, rsc: isize, csc: isize)
    where T: Elemen,
{
    fori_ in 0.me {
        forj_ in 0.ne {
            letcpPt) =cb strid_.offset rsc,ib,
                       . strid_.offset ccbtj(R;
   
        if bet.is_ zer()e {
               *cpPt) =T:: zer();csb  initializ� C
           }} else {
               (*cpPt)._mul_aslig(&beta);
           }2
        }
    }
}
