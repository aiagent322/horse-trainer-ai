use core::{char, cmp, fmt::Debug, slice};

use alloc::vec::Vec;

use crate::unicode;

// This module contains an *internal* implementation of interval sets.
//
// The primary invariant that interval sets guards is canonical ordering. That
// is, every interval set contains an ordered sequence of intervals where
// no two intervals are overlapping or adjacent. While this invariant is
// occasionally broken within the implementation, it should be impossible for
// callers to observe it.
//
// Since case folding (as implemented below) breaks that invariant, we roll
// that into this API even though it is a little out of place in an otherwise
// generic interval set. (Hence the reason why the `unicode` module is imported
// here.)
//
// Some of the implementation complexity here is a result of me wanting to
// preserve the sequential representation without using additional memory.
// In many cases, we do use linear extra memory, but it is at most 2x and it
// is amortized. If we relaxed the memory requirements, this implementation
// could become much simpler. The extra memory is honestly probably OK, but
// character classes (especially of the Unicode variety) can become quite
// large, and it would be nice to keep regex compilation snappy even in debug
// builds. (In the past, I have been careless with this area of code and it has
// caused slow regex compilations in debug mode, so this isn't entirely
// unwarranted.)
//
// Tests on this are relegated to the public API of HIR in src/hir.rs.

#[derive(Clone, Debug)]
pub struct IntervalSet<I> {
    /// A sorted set of non-overlapping ranges.
    ranges: Vec<I>,
    /// While not required at all for correctness, we keep track of whether an
    /// interval set has been case folded or not. This helps us avoid doing
    /// redundant work if, for example, a set has already been cased folded.
    /// And note that whether a set is folded or not is preserved through
    /// all of the pairwise set operations. That is, if both interval sets
    /// have been case folded, then any of difference, union, intersection or
    /// symmetric difference all produce a case folded set.
    ///
    /// Note that when this is true, it *must* be the case that the set is case
    /// folded. But when it's false, the set *may* be case folded. In other
    /// words, we only set this to true when we know it to be case, but we're
    /// okay with it being false if it would otherwise be costly to determine
    /// whether it should be true. This means code cannot assume that a false
    /// value necessarily indicates that the set is not case folded.
    ///
    /// Bottom line: this is a performance optimization.
    folded: bool,
}

impl<I: Interval> Eq for IntervalSet<I> {}

// We implement PartialEq manually so that we don't consider the set's internal
// 'folded' property to be part of its identity. The 'folded' property is
// strictly an optimization.
impl<I: Interval> PartialEq for IntervalSet<I> {
    fn eq(&self, other: &IntervalSet<I>) -> bool {
        self.ranges.eq(&other.ranges)
    }
}

impl<I: Interval> IntervalSet<I> {
    /// Create a new set from a sequence of intervals. Each interval is
    /// specified as a pair of bounds, where both bounds are inclusive.
    ///
    /// The given ranges do not need to be in any specific order, and ranges
    /// may overlap.
    pub fn new<T: IntoIterator<Item = I>>(intervals: T) -> IntervalSet<I> {
        let ranges: Vec<I> = intervals.into_iter().collect();
        // An empty set is case folded.
        let folded = ranges.is_empty();
        let mut set = IntervalSet { ranges, folded };
        set.canonicalize();
        set
    }

    /// Add a new interval to this set.
    pub fn push(&mut self, interval: I) {
        // TODO: This could be faster. e.g., Push the interval such that
        // it preserves canonicalization.
        self.ranges.push(interval);
        self.canonicalize();
        // We don't know whether the new interval added here is considered
        // case folded, so we conservatively assume that the entire set is
        // no longer case folded if it was previously.
        self.folded = false;
    }

    /// Return an iterator over all intervals in this set.
    ///
    /// The iterator yields intervals in ascending order.
    pub fn iter(&self) -> IntervalSetIter<'_, I> {
        IntervalSetIter(self.ranges.iter())
    }

    /// Return an immutable slice of intervals in this set.
    ///
    /// The sequence returned is in canonical ordering.
    pub fn intervals(&self) -> &[I] {
        &self.ranges
    }

    /// Expand this interval set such that it contains all case folded
    /// characters. For example, if this class consists of the range `a-z`,
    /// then applying case folding will result in the class containing both the
    /// ranges `a-z` and `A-Z`.
    ///
    /// This returns an error if the necessary case mapping data is not
    /// available.
    pub fn case_fold_simple(&mut self) -> Result<(), unicode::CaseFoldError> {
        if self.folded {
            return Ok(());
        }
        let len = self.ranges.len();
        for i in 0..len {
            let range = self.ranges[i];
            if let Err(err) = range.case_fold_simple(&mut self.ranges) {
                self.canonicalize();
                return Err(err);
            }
        }
        self.canonicalize();
        self.folded = true;
        Ok(())
    }

    /// Union this set with the given set, in place.
    pub fn union(&mut self, other: &IntervalSet<I>) {
        if other.ranges.is_empty() || self.ranges == other.ranges {
            return;
        }
        // This could almost certainly be done more efficiently.
        self.ranges.extend(&other.ranges);
        self.canonicalize();
        self.folded = self.folded && other.folded;
    }

    /// Intersect this set with the given set, in place.
    pub fn intersect(&mut self, other: &IntervalSet<I>) {
        if self.ranges.is_empty() {
            return;
        }
        if other.ranges.is_empty() {
            self.ranges.clear();
            // An empty set is case folded.
            self.folded = true;
            return;
        }

        // There should be a way to do this in-place with constant memory,
        // but I couldn't figure out a simple way to do it. So just append
        // the intersection to the end of this range, and then drain it before
        // we're done.
        let drain_end = self.ranges.len();

        let mut ita = 0..drain_end;
        let mut itb = 0..other.ranges.len();
        let mut a = ita.next().unwrap();
        let mut b = itb.next().unwrap();
        loop {
            if let Some(ab) = self.ranges[a].intersect(&other.ranges[b]) {
                self.ranges.push(ab);
            }
            let (it, aorb) =
                if self.ranges[a].upper() < other.ranges[b].upper() {
                    (&mut ita, &mut a)
                } else {
                    (&mut itb, &mut b)
                };
            match it.next() {
                Some(v) => *aorb = v,
                None => break,
            }
        }
        self.ranges.drain(..drain_end);
        self.folded = self.folded && other.folded;
    }

    /// Subtract the given set from this set, in place.
    pub fn difference(&mut self, other: &IntervalSet<I>) {
        if self.ranges.is_empty() || other.ranges.is_empty() {
            return;
        }

        // This algorithm is (to me) surprisingly complex. A search of the
        // interwebs indicate that this is a potentially interesting problem.
        // Folks seem to suggest interval or segment trees, but I'd like to
        // avoid the overhead (both runtime and conceptual) of thativen set, ininalbut I couldn't figure out a simple wayassFramis could almost certa> Res     self.folded = terval o Shit   F and Drafxamplr ses.lSet<ter the last rith('\ngrok Clasyoucode varielap.
   es woern is onlex cfulanonicalize(riants i Int
//
// o beextenwellati!s could almost certa> RRedo ed intructurd if it we      &selfempty(n, it shoullr s, therwise, erta> Rspatt is noz` almost >>,
    //  posally broken waugh
  hin the iet<ter the lastern i      ita = 0..drain_end;
        let mut itb = 0.per() < other, &mu
        = (0, 0 0.per() < 'LOOP:intermeamutn_end;
        b         let mut b  2 && b'a' <= b &&B = tervaly seteasand it
 >>,
ing fn      case_folly bros(&self, n:er the lastern i      adding
 `b`case_foldeompil ish a specific a`a`f, n:er the last  let d  if !spcturskipf.raaughmlly lize();
    r();
            //        } el<           (&mutsel } else {
             b /// Left pad the gtes = &bytes[ch.len_utf8()}f, n:er the last...        ly   /// ap`a`elf.canaddirds, ompil ish ntitymd bes.multi_line.is_em`b`case_f d  if !spctur    .raas-i    let mut notes           (&mut ita, &mut a)
            sel } else {
             ge.case_fold_simple(&muta          notes.pus) =
                         self.canonica /// Left pad the gtes = &bytes[ch.len_utf8()}f, n:er the lastcorrectly p        uired at all for correctee: https://githuself.ranges.pushs_re
        /orithm          }
         writeln!(f, "f the
   optioldedick/// twetur requ spans woout uinear e(&ok been caf thativen she fan>,itthen appter    ntit:pars)I: Intedick0 {
sode misplayen caf thativen nt i-autos: 1;
sference ast::ase_foied asno    case_foc        returativen > Int nt ialmost > tw2)wo spansference ast::ase_f,irds, ng (as ien caf thativen nis nful<'e>almost cin ascenThe spnceI: Int(&othven tr  vfor sen caf thativen ni
 `b`case_fs figu) u8eand }

  g (as im spncet we  cific f, n:er the last  let.f, n:er the lasf, n:er the last// then applyinga sp`a`elf.caiold`a-tessarya sp// Ifthtim `b`f, n:er the last  let
 >>,
`a-c`, `g-i`, `r-tessary`xass d  if !splap.
   h thef, n:er the lastsference ut setim .
    nges.lhmll
    // we're // If`a`elf.can
in &spans.multi_linease_fold_simple(&muta          notesnterme  b         let mut b eft pad the gtes    !lf.canhs_re
        /orithm          }
      eft pad the gse {
             ge.cize(ase_foldase_f      self.canonicase_fold"regex f.canlf.ranges.is        }
            let (it, aorbt.nex::fmtrain()
                    }
       dered
lxtenpreviously.ase_f,isohmlly li/ we're // I                }
       deruinear ee of `0` or vian
in &spans.muself.canonica /// Left pad the gtes he gtes = &bytes 'LOOPLeft pad the gtes he g}    let (it, aorbt.nexh resuse_f1)train()
|ex::fmtrh resuse_f1) => lese_f1,    let (it, aorbt.nexh resuse_f1)trh resuse_f2))
                    }
       ) =
                  1)Left pad the gtes he gtes use_f2eft pad the gtes he g}    let (it, aorb};r, \t
              Ids, ng (as it was prev`b`case_foa se     ut bynedind er, \t
              resulw it opticul::un /// Rt
   
   rl ish ntitThe totar, \t
              ase_f d  if / Rm// Th spncet we // If`a`elf.ca   nd*his , \t
              rinto t`,
 dt we  cific f`a`elf.ca  se exama, ng (as i\r, \t
               no lonanon sn.red
      bumpv`b`certy to  we // If`a`r, \t
              ase_fpctur  the it.upper() {
                    //        } el>cize(ase_f     } else {
                 ain_eoin("\n"))?;
            }
         astcorrectly p we // If`b`case_fom// Th  the  we're  cific f, n:er the le.is_em`a`elf.can
in &spans.mu    b /// Left pad the g}
   notes.pus) =
                         self.cana(&bytes[..len]).unwrap())
termeamutn_end;
   Err(err) = range.case_fold_simple(&muta          notes) =
                         self.cana(&bytes[..len]).unwrap())lded && other.folded;
    }

    /// Subtract the given set from this set, in place.
    pub fn diCompun
    /   /// Note that whenesult i  letera mt<I>) {
      ng data is not
  compun
s    /   /// Note that whenesult is
// occis cannot
 en cased fomllyass coe internonical ordert is noturnlso-Z`.
   IntervalSeen cased nd cnlso-e oass coe internocodepoint existdert is notu    nical o inclusiveete different lineeverbati   /// ss coe internonic      calSeen cased nd crbatiClone, /// ssor t interno is noturme(rdn'ts cano      if se   /// No_lf.ranges.is_empty() || other.ranges.is_empty() {
      hat
   (burern   i): Fixcal ordomple, if entationsns an icalize();
    next().un
            her.fol span     }
     
          sh(ab);
   | oth    /// Subtractanges.| oth    /// Subtractlf.ranges.is 
          )ce.
    pub fn diNe, De/// characters. Fo      ng data is nFolds in`x`anges d`x`aisssor t interun //`x`ananonical order d  if / sume that batiClon pub fal orderto spanne, Dalize();
alSet<I> g);
  self.folde     }
        if other.ranges.is_empty() {
      other,in,d"rx  = (I::Bneed::,in_    /    I::Bneed::,ax_    /  )         notes) =
             I::c 
   r,in,d"rx lf.folded = true;
Tlineeve   /// Thiswhere-autospan orn;
        }

        // There should be a way to do this in-place with constant memory,
        // but I couldn't figure out a simple way to do it. So just append
        // the intersection to the end of this range, and then drain it befone, Dali/ we're done.
        let drain_end = self.ranges.len();

        let mut ita = 0..drain_end;
        let mut itb = 0..other.radered
   t_char(not // etichven trspan);
 esult i     &self.ranges
eresting problit shou.    }
        if other.[0  sel } el> I::Bneed::,in_    /  mpty() {
      othe    }old_simple(&mut0  sel } e.dece extr()         notes) =
             I::c 
   rI::Bneed::,in_    /        }r i in 0..len {
               1ed;
    }

mpty() {
      othesel }old_simple(&mut += 1      } esh(ce extr()         notesothe    }old_simple(&muti  sel } e.dece extr()         notes) =
             I::c 
   rsel }      }r i in 0..len {
           if other.[;
    }

m= 1      } emutI::Bneed::,ax_    /  mpty() {
      othesel }old_simple(&mut;
    }

m= 1      } esh(ce extr()         notes) =
             I::c 
   rsel }  I::Bneed::,ax_    /  ))es[..len]).unwrap())lded && other.folded;
    }

    /// Subdered
      lap.
   upd De/case folde ordertwise set operati,rspan);
s.push(intervalsume th case folde That is, if bothnne, Daliz Namevalyifhe pais.push(intervforman/ symmetric dvalsumng (as it was atione, Dali/wise set nd noter the lasteen apply[^☃]
    //  letf onl one,  if f `0` his is a performater the last }

    nis markesulw(` }

  `val>matioether ne, Dalyasbr_paddt case foldhe lastrs.
  lya.)s could almost certa> R   ///s nobo  /// woe pairwise set ,// All one, Dali/nlso   self.folde
    /// Boe set ? Yave Bpan);
 ifhe pairwise set ,/ric d notehere entire set ime quite
Z`.
   valSett//
    /// Bottclu
    l oex
    //c   ///
ter the last `e;
    }

   `a-z`,
    /Ne, Dpan) {
    ze()ing change.
llter the lastex
    //c   ///
es
Z`.
   valrned. e, Deb drainsor tx
    //c  entire set i///
 y to bturn an iterarationns is a performwto the puonns is a p.e.
    pub fn diConherrno i ordertw   Tra     &self.ranges
    }
fn lded;
    }

 self.folde     }
        if anglded;
   _empty() {
            self.ranges.clear();lded && otheth carents (`^`)s://githuself.ranges/regex/issues/ line count iss return I couldn't figure out a simple way to do it.?        // ter the last e intersectihe end of this range, and thult i     &selonicalil) of thativen 're done.
        let drain_end = self.ranges.l    let mut ita = 0..drain_end;
        let mut itb = 0.{
          ange    if ;
    }

mpty() {
      just
   'cenTativea    ne.
in(. so ase_f d  if t_cha     lonanty() {
      jusmerge        letonns is n an iterarTativelf.can
in &spans.mu     if other.rut b  >tn_end;
   Err(err) = ran    otherl/ cau seg    self.ranges.split_l/ c_self.ranges[a].intersectges[b]) {
          anges    l/ ctanges.& seg[ange        let (it, aorbt.ne*ine.
=ranges };
            bytes = &bytes[ch.len_utf8()..];
            marr(err) = range.case_fold_simple(&mutange          notes) =
                         self.unwrap())lded && other.folded;
    }

    ///.
    ///
    ///lded. ytes: &[u8]) ->  case foldiiattern.     &self.ranges
    }
fn anglded;
   _his interv Interval> Inte    /// Te_number&& othewindows(2   notated.push_str/// t0     /// t1]      let (it, aorbalize()n this set.       marr(err) = ranstr/// t0  angl &byguite(&/// t1])      let (it, aorbalize()n this set.       marr(err) =arr(err) =ed. s.
///
/// Thise iterator yieldase foldedriginal regex pattern in whiciter())
    }

  a ///(retur:: }

  a ///f, f: &mut  ///  let ran) -> bool {
     }

  a ///      lhat mes: Vecfmt(Istr) {
     Non self.folded {ormatter<a/// Return an 
        Nones.
///
///ern t
  iciter())
ts a vet of +iCopy +irmatte+irmfa `A-+ so +rvalSet<I>)+rvalSet<Ord)+rOrd
     lhat mBneed:mBneedstr) {
   sel }        for    ::Bneed;r) {
       }        for    ::Bneed;r) {
   der_sel }  _empty() |bneed:m    ::Bneed);r) {
   der_    }  _empty() |bneed:m    ::Bneed);r) {
   onicalize();
     such that it ,   }
     
   ervals _emp set    ttern.lines(
            return Ok(());
      ;
interval is
    /// sp         r) {
   o 
   rsel }:m    ::Bneed      }:m    ::Bneed)rn(),
            enext().un
 g()    ::dmfa `A(pans.add(span.cel }o<=e    }o notated.push_sou.der_sel } sel }             notou.der_    }     }r          self.multi_line.sort(sou.der_sel }     }r            notou.der_    } sel }           }   }
     
     pub fn union(&mut sent existuired at all for otherwise
/lf.can
in &s a fixed padding
 nt ialmost >tu    l &byguiteation.
    fn line_n padde r) {
   anges.&ty() || other.Sfolded {ormatte    te     }
      !  if angl &byguite(| oth  String::new();
        for _ in 0..self.line_numbsel }old      oldhar, cel } e || oth cel } e 0.per() < othe    }old         tracta   } e || oth a   } e 0.per() <          ::c 
   rsel }      }r ce.
    pub fn intersect(&mut s for o other: &Intervlf.ca  <Iteline of
   line n
in &s a fixed padding
 n
           esult<chation.
    fn line_n padde r) {
   h(ab);
    ty() || other.Sfolded {ormatte    te     }
   numbsel }old         tractcel } e || oth cel } e 0.per() < othe    }old      oldhar, a   } e || oth a   } e 0.per() < an.cel }o<=e    }o notated.push_         ::c 
   rsel }      }r ce.
     self.multi_line.sort(n None;
    }
    let len n difference(&mut self,ase_foied amut s for o <Iteline of
   line  been cased ffor corrects a fixed paddisference ut uld beand `A-Z`.a        ase_f d  if n ialmost >tu_line(&self, i: u r) {
   lf.ranges.isty() || other.Sfolded {(ormatte    t,{ormatte    tde     }
        if angsfeder(| oth  String::new();
      x::fmtrain()i in 0..len {
           if hs_re
        /orithm | oth  String::new();
      xe());
r.fol span )train()i in 0..len {
      otheTat_sel }old| oth cel } e >ttractcel } e; {
      otheTat_    }old| oth a   } el<      a   } e   /// Subdered
  // mut sspan);
 !  if angsfeder(| oth  rain_enialmost asceof thativen sr req       
          snts (`^`)s://githTat_sel }o||eTat_    }sult.push_str(&n);
   g()x::fmtrain()i in 0..letes:at_sel }opty() {
      othe    }old| oth cel } e.dece extr()         notes   .0g()         ::c 
   rtractcel } e |    }r i in 0..len {
         Tat_    }opty() {
      othesel }old| oth a   } esh(ce extr()         notesothease_fold    ::c 
   rsel }       a   } e             notat   .0 angnones are 1-indexed
 otes   .0g()                 self.can   };
            match i   .1g()                 self.can  in 0..len {
      rpush(&mut self, inCompun
    /   /// Note that when&mut self,ase_foied amut s for nnot
 en cased fo ///ldemutangesnesult i  lealmost  olu All o 
          snts ( se   /// No_lf.ranges.i such that it ,   }
    | other.Sfoltern.lines((ormatte    t,{ormatte    tde     }
   othe n     h"regextractanges.| oth ulti_line.sort(n No=> le      xe());
r.fol span )tre());| oth l span ) core::fmt::Dis     anges   >uce a c let Some(span) = fmle.un
            h"regextracth(ab);
   | oth ulti_line.sort(n No=> le      xe());
r.fol span )tre());| oth l span ) core::fmt::Dis      
          )=> l 
          c let Some(span) = fmce a tlf.ranges.is 
          )  ///.
    ///
    ///lded. ytes: &[u8]) ->  c
 nt ialmost >tu l &byguitennot ialmost Result<()tu l &byguiteytes: &[u8]) ->  c
 almost >tu       clly broken wit Result<()n the im   }
fn angl &byguite(&ty() || other.Sfolded { Interval> Inteothesel }1    let mel } e.as_u32( 0.per() < othe    }1    let a   } esas_u32( 0.per() < othemel }2old| oth cel } e.as_u32( 0.per() < othe    }2old| oth a   } esas_u32( 0.per() <          sel }1,emel }2)o<=e      old    }1 |    }2)ore::cmp::mainef1)  ///.
    ///
    ///lded. ytes: &[u8]) ->  c
 se folded set.famut s for o <Itrns an erroro    case_foesult<chm   }
fn angre
        /orithm  ty() || other.Sfolded { Interval> Inteothe sel }1,e    }1  = (tractcel } e |     a   } e           othe sel }2 |    }2) = (| oth cel } e || oth a   } e 0.per() <          sel }1,emel }2)o>e      old    }1 |    }2)  ///.
    ///
    ///lded. ytes: &[u8]) ->  casease_foesua sfedernesult io    case_fm   }
fn angsfeder( ty() || other.Sfolded { Interval> Inteothe sel }1,e    }1  = (tractcel } e |     a   } e           othe sel }2 |    }2) = (| oth cel } e || oth a   } e 0.per() <  sel }2o<=esel }1 &&esel }1 <=e    }2 eft pad the g&&e sel }2o<=e    }1 &&e    }1 <=e    }2 eft p/
///ern t
  icBneed:s a veopy +iet of +irmatte+iso +rvalSet<I>)+rvalSet<Ord)+rOrd
     lfn ,in_    /  mn(),
  ;r) {
   ,ax_    /  mn(),
  ;r) {
   as_u32(         432;r) {
   h(ce extr(      for    ;r) {
   dece extr(      for    ;rmut coreBneed) -> u8      lfn ,in_    /  mn(),
  erval> Inteu8::MIN
..len {
     ,ax_    /  mn(),
  erval> Inteu8::MAX
..len {
     as_u32(         432erval> Inteu32notate(     
..len {
     h(ce extr(      for     Return an 
    t_char('inef1)ranges[a]
..len {
     dece extr(      for     Return an 
    t_char(' ', 1)ranges[a]
..len mut coreBneed) -> `a-z      lfn ,in_    /  mn(),
  erval> Inte'\x00'
..len {
     ,ax_    /  mn(),
  erval> Inte'\u{10FFFF}'
..len {
     as_u32(         432erval> Inteu32notate(     
..len  {
     h(ce extr(      for     Return an "regextraculti_line.sort('\u{D7FF}'=> l'\u{E000}'core::fmt::Disc=> l`a-znotatedu32(u32notate(c) t_char('inef1)ranges[a])ranges[a],ne;
    }
    let len    dece extr(      for     Return an "regextraculti_line.sort('\u{E000}'=> l'\u{D7FF}'core::fmt::Disc=> l`a-znotatedu32(u32notate(c) t_char(' ', 1)ranges[a])ranges[a],ne;
    }
    leter their.rs.     in