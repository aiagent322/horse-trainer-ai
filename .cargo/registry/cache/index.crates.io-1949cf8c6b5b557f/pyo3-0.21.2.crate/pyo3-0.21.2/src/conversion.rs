//! Defines conversions between Rust and Python types.
use crate::err::{self, PyDowncastError, PyResult};
#[cfg(feature = "experimental-inspect")]
use crate::inspect::types::TypeInfo;
use crate::pyclass::boolean_struct::False;
use crate::type_object::PyTypeInfo;
use crate::types::any::PyAnyMethods;
use crate::types::PyTuple;
use crate::{
    ffi, gil, Borrowed, Bound, Py, PyAny, PyClass, PyNativeType, PyObject, PyRef, PyRefMut, Python,
};
use std::ptr::NonNull;

/// Returns a borrowed pointer to a Python object.
///
/// The returned pointer will be valid for as long as `self` is. It may be null depending on the
/// implementation.
///
/// # Examples
///
/// ```rust
/// use pyo3::prelude::*;
/// use pyo3::types::PyString;
/// use pyo3::ffi;
///
/// Python::with_gil(|py| {
///     let s: Py<PyString> = "foo".into_py(py);
///     let ptr = s.as_ptr();
///
///     let is_really_a_pystring = unsafe { ffi::PyUnicode_CheckExact(ptr) };
///     assert_eq!(is_really_a_pystring, 1);
/// });
/// ```
///
/// # Safety
///
/// For callers, it is your responsibility to make sure that the underlying Python object is not dropped too
/// early. For example, the following code will cause undefined behavior:
///
/// ```rust,no_run
/// # use pyo3::prelude::*;
/// # use pyo3::ffi;
/// #
/// Python::with_gil(|py| {
///     let ptr: *mut ffi::PyObject = 0xabad1dea_u32.into_py(py).as_ptr();
///
///     let isnt_a_pystring = unsafe {
///         // `ptr` is dangling, this is UB
///         ffi::PyUnicode_CheckExact(ptr)
///     };
/// #    assert_eq!(isnt_a_pystring, 0);
/// });
/// ```
///
/// This happens because the pointer returned by `as_ptr` does not carry any lifetime information
/// and the Python object is dropped immediately after the `0xabad1dea_u32.into_py(py).as_ptr()`
/// expression is evaluated. To fix the problem, bind Python object to a local variable like earlier
/// to keep the Python object alive until the end of its scope.
///
/// Implementors must ensure this returns a valid pointer to a Python object, which borrows a reference count from `&self`.
pub unsafe trait AsPyPointer {
    /// Returns the underlying FFI pointer as a borrowed pointer.
    fn as_ptr(&self) -> *mut ffi::PyObject;
}

/// Conversion trait that allows various objects to be converted into `PyObject`.
pub trait ToPyObject {
    /// Converts self into a Python object.
    fn to_object(&self, py: Python<'_>) -> PyObject;
}

/// Defines a conversion from a Rust type to a Python object.
///
/// It functions similarly to std's [`Into`] trait, but requires a [GIL token](Python)
/// as an argument. Many functions and traits internal to PyO3 require this trait as a bound,
/// so a lack of this trait can manifest itself in different error messages.
///
/// # Examples
/// ## With `#[pyclass]`
/// The easiest way to implement `IntoPy` is by exposing a struct as a native Python object
/// by annotating it with [`#[pyclass]`](crate::prelude::pyclass).
///
/// ```rust
/// use pyo3::prelude::*;
///
/// #[pyclass]
/// struct Number {
///     #[pyo3(get, set)]
///     value: i32,
/// }
/// ```
/// Python code will see this as an instance of the `Number` class with a `value` attribute.
///
/// ## Conversion to a Python object
///
/// However, it may not be desirable to expose the existence of `Number` to Python code.
/// `IntoPy` allows us to define a conversion to an appropriate Python object.
/// ```rust
/// use pyo3::prelude::*;
///
/// # #[allow(dead_code)]
/// struct Number {
///     value: i32,
/// }
///
/// impl IntoPy<PyObject> for Number {
///     fn into_py(self, py: Python<'_>) -> PyObject {
///         // delegates to i32's IntoPy implementation.
///         self.value.into_py(py)
///     }
/// }
/// ```
/// Python code will see this as an `int` object.
///
/// ## Dynamic conversion into Python objects.
/// It is also possible to return a different Python object depending on some condition.
/// This is useful for types like enums that can carry different types.
///
/// ```rust
/// use pyo3::prelude::*;
///
/// enum Value {
///     Integer(i32),
///     String(String),
///     None,
/// }
///
/// impl IntoPy<PyObject> for Value {
///     fn into_py(self, py: Python<'_>) -> PyObject {
///         match self {
///             Self::Integer(val) => val.into_py(py),
///             Self::String(val) => val.into_py(py),
///             Self::None => py.None(),
///         }
///     }
/// }
/// # fn main() {
/// #     Python::with_gil(|py| {
/// #         let v = Value::Integer(73).into_py(py);
/// #         let v = v.extract::<i32>(py).unwrap();
/// #
/// #         let v = Value::String("foo".into()).into_py(py);
/// #         let v = v.extract::<String>(py).unwrap();
/// #
/// #         let v = Value::None.into_py(py);
/// #         let v = v.extract::<Option<Vec<i32>>>(py).unwrap();
/// #     });
/// # }
/// ```
/// Python code will see this as any of the `int`, `string` or `None` objects.
#[doc(alias = "IntoPyCallbackOutput")]
pub trait IntoPy<T>: Sized {
    /// Performs the conversion.
    fn into_py(self, py: Python<'_>) -> T;

    /// Extracts the type hint information for this type when it appears as a return value.
    ///
    /// For example, `Vec<u32>` would return `List[int]`.
    /// The default implementation returns `Any`, which is correct for any type.
    ///
    /// For most types, the return value for this method will be identical to that of [`FromPyObject::type_input`].
    /// It may be different for some types, such as `Dict`, to allow duck-typing: functions return `Dict` but take `Mapping` as argument.
    #[cfg(feature = "experimental-inspect")]
    fn type_output() -> TypeInfo {
        TypeInfo::Any
    }
}

/// Extract a type from a Python object.
///
///
/// Normal usage is through the `extract` methods on [`Bound`] and [`Py`], which forward to this trait.
///
/// # Examples
///
/// ```rust
/// use pyo3::prelude::*;
/// use pyo3::types::PyString;
///
/// # fn main() -> PyResult<()> {
/// Python::with_gil(|py| {
///     // Calling `.extract()` on a `Bound` smart pointer
///     let obj: Bound<'_, PyString> = PyString::new_bound(py, "blah");
///     let s: String = obj.extract()?;
/// #   assert_eq!(s, "blah");
///
///     // Calling `.extract(py)` on a `Py` smart pointer
///     let obj: Py<PyString> = obj.unbind();
///     let s: String = obj.extract(py)?;
/// #   assert_eq!(s, "blah");
/// #   Ok(())
/// })
/// # }
/// ```
///
// /// FIXME: until `FromPyObject` can pick up a second lifetime, the below commentary is no longer
// /// true. Update and restore this documentation at that time.
// ///
// /// Note: depending on the implementation, the lifetime of the extracted result may
// /// depend on the lifetime of the `obj` or the `prepared` variable.
// ///
// /// For example, when extracting `&str` from a Python byte string, the resulting string slice will
// /// point to the existing string data (lifetime: `'py`).
// /// On the other hand, when extracting `&str` from a Python Unicode string, the preparation step
// /// will convert the string to UTF-8, and the resulting string slice will have lifetime `'prepared`.
// /// Since which case applies depends on the runtime type of the Python object,
// /// both the `obj` and `prepared` variables must outlive the resulting string slice.
///
/// During the migration of PyO3 from the "GIL Refs" API to the `Bound<T>` smart pointer, this trait
/// has two methods `extract` and `extract_bound` which are defaulted to call each other. To avoid
/// infinite recursion, implementors must implement at least one of these methods. The recommendation
/// is to implement `extract_bound` and leave `extract` as the default implementation.
pub trait FromPyObject<'py>: Sized {
    /// Extracts `Self` from the source GIL Ref `obj`.
    ///
    /// Implementors are encouraged to implement `extract_bound` and leave this method as the
    /// default implementation, which will forward calls to `extract_bound`.
    fn extract(ob: &'py PyAny) -> PyResult<Self> {
        Self::extract_bound(&ob.as_borrowed())
    }

    /// Extracts `Self` from the bound smart pointer `obj`.
    ///
    /// Implementors are encouraged to implement this method and leave `extract` defaulted, as
    /// this will be most compatible with PyO3's future API.
    fn extract_bound(ob: &Bound<'py, PyAny>) -> PyResult<Self> {
        Self::extract(ob.clone().into_gil_ref())
    }

    /// Extracts the type hint information for this type when it appears as an argument.
    ///
    /// For example, `Vec<u32>` would return `Sequence[int]`.
    /// The default implementation returns `Any`, which is correct for any type.
    ///
    /// For most types, the return value for this method will be identical to that of [`IntoPy::type_output`].
    /// It may be different for some types, such as `Dict`, to allow duck-typing: functions return `Dict` but take `Mapping` as argument.
    #[cfg(feature = "experimental-inspect")]
    fn type_input() -> TypeInfo {
        TypeInfo::Any
    }
}

mod from_py_object_bound_sealed {
    /// Private seal for the `FromPyObjectBound` trait.
    ///
    /// This prevents downstream types from implementing the trait before
    /// PyO3 is ready to declare the trait as public API.
    pub trait Sealed {}

    // This generic implementation is why the seal is separate from
    // `crate::sealed::Sealed`.
    impl<'py, T> Sealed for T where T: super::FromPyObject<'py> {}
    #[cfg(not(feature = "gil-refs"))]
    impl Sealed for &'_ str {}
    #[cfg(not(feature = "gil-refs"))]
    impl Sealed for std::borrow::Cow<'_, str> {}
    #[cfg(not(feature = "gil-refs"))]
    impl Sealed for &'_ [u8] {}
    #[cfg(not(feature = "gil-refs"))]
    impl Sealed for std::borrow::Cow<'_, [u8]> {}
}

/// Expected form of [`FromPyObject`] to be used in a future PyO3 release.
///
/// The difference between this and `FromPyObject` is that this trait takes an
/// additional lifetime `'a`, which is the lifetime of the input `Bound`.
///
/// This allows implementations for `&'a str` and `&'a [u8]`, which could not
/// be expressed by the existing `FromPyObject` trait once the GIL Refs API was
/// removed.
///
/// # Usage
///
/// Users are prevented from implementing this trait, instead they should implement
/// the normal `FromPyObject` trait. This trait has a blanket implementation
/// for `T: FromPyObject`.
///
/// The only case where this trait may have a use case to be implemented is when the
/// lifetime of the extracted value is tied to the lifetime `'a` of the input `Bound`
/// instead of the GIL lifetime `py`, as is the case for the `&'a str` implementation.
///
/// Please contact the PyO3 maintainers if you believe you have a use case for implementing
/// this trait before PyO3 is ready to change the main `FromPyObject` trait to take an
/// additional lifetime.
///
/// Similarly, users should typically not call these trait methods and should instead
/// use this via the `extract` method on `Bound` and `Py`.
pub trait FromPyObjectBound<'a, 'py>: Sized + from_py_object_bound_sealed::Sealed {
    /// Extracts `Self` from the bound smart pointer `obj`.
    ///
    /// Users are advised against calling this method directly: instead, use this via
    /// [`Bound<'_, PyAny>::extract`] or [`Py::extract`].
    fn from_py_object_bound(ob: Borrowed<'a, 'py, PyAny>) -> PyResult<Self>;

    /// Extracts the type hint information for this type when it appears as an argument.
    ///
    /// For example, `Vec<u32>` would return `Sequence[int]`.
    /// The default implementation returns `Any`, which is correct for any type.
    ///
    /// For most types, the return value for this method will be identical to that of [`IntoPy::type_output`].
    /// It may be different for some types, such as `Dict`, to allow duck-typing: functions return `Dict` but take `Mapping` as argument.
    #[cfg(feature = "experimental-inspect")]
    fn type_input() -> TypeInfo {
        TypeInfo::Any
    }
}

impl<'py, T> FromPyObjectBound<'_, 'py> for T
where
    T: FromPyObject<'py>,
{
    fn from_py_object_bound(ob: Borrowed<'_, 'py, PyAny>) -> PyResult<Self> {
        Self::extract_bound(&ob)
    }

    #[cfg(feature = "experimental-inspect")]
    fn type_input() -> TypeInfo {
        <T as FromPyObject>::type_input()
    }
}

/// Identity conversion: allows using existing `PyObject` instances where
/// `T: ToPyObject` is expected.
impl<T: ?Sized + ToPyObject> ToPyObject for &'_ T {
    #[inline]
    fn to_object(&self, py: Python<'_>) -> PyObject {
        <T as         {
/ imd to implemek(self)
    }
}

impl IntoPy<PyObjectt fo 'py, &'_ T {
    #[inline]
    fn into_py(self, py: Python<'_>) -> PyObj> T {
        uns[`FromPyObCStr::(ob: Bo fn aslice    y(py).as)       }
    }
}

impl<T> IntoPy<PyObjectt fo> for T
where
 Ase G< 'py, ash_t>,
{
    #[inline]
    fn into_py(self, py: Python<'_>) -> PyObj> T {
        uns[`FromPyObCStr::(ob: Bo fn aslice    y(po_gil y(py).as)       }
   /// # #[als ac evaspe }
}

impl<'py, T> FromPy<d<'_, 'pyt(ob:  use craadOnlyC for T
where
 yAny, Py<'py>,
{
 Self::extrjact(ob: &'py PyAny) -> PyResult<Self> {
  ing df, PyDoy_into().mapl<T cratok(self)
    }
}

imy, T> FromPy<d__, 'py> for T
where
 yAny, P?SiCl     {e API.
    fn extract_bojund(ob: &B__, 'py, PyAny>) -> PyResult<Self> {
        the = ing df, PyDoxtrasultxtracut> {
       the  sel:(ob: xtract(ob.c)o::Any
    }
}

impl<'py, T> FromPy<d<'_, 'pyyRef,

impl<' for T
where
 yAny, Py<'py>,
{
 Self::extract_bojund(ob: &B<'_, 'py, PyAny>) -> PyResult<Self> {
  ing df, PyDoxtrTtxtr  sel:(ob: xtinto().mapl<T cratok(self)
    }
}

impl<'py, T> FromPy<d<'_, 'pyyRef,Mut

impl<' for T
where
 yAny, P<y, zype= ruct:>y<'py>,
{
 Self::extract_bojund(ob: &B<'_, 'py, PyAny>) -> PyResult<Self> {
  ing df, PyDoxtrTtxtr  sel:(ob: ::nullinto().mapl<T cratok(self)
   .
   
pub to be implemby, bind Python obream trait thatdeficodelemdf, PyDobjects.fh ty to be impsistiTryy, Ts `Ag if we ill co`& 'py,Numbe`&T`Bound`.
///
///.
pub inctions sumbe`Like [ ill c::Tryy, Tsjectls ac eva(s /// atu pyo30Output")]
pub tiTryy, T<'va, 'py>: Silass, PyNatiObject {
    at &str` f    tioe, bind Python obreaternal thon objectectls ac eva(e_t> {
    /// atu pyo30Onto()),
  cal/ atu  ///eturn df, PyDoxtrTtxt`d`
/// instee
/: sel&str(eturn)`"to())spect")]
  sel&str<V
    E:&'v, 'py, >(/     vVPyAny -> PyR&'v,Srr::{self, PyDowncas<'vat<Self>;

    at &str` f    tioe, bind Python obreaternal thon o/// ##exan obreaticodeobjectectls ac eva(e_t> {
    /// atu pyo30Onto()),
  cal/ atu  ///eturn df, PyDo_exan xtrTtxt`d`
/// instee
/: sel&str_exan (eturn)`"to())spect")]
  sel&str_exan <V
    E:&'v, 'py, >(/     vVPyAny -> PyR&'v,Srr::{self, PyDowncas<'vat<Self>;

    at ao 'py, rsiontal-ificuntime tyal thon o/Tn if th pontorelf>;

  e you lO3 is ll be modifing the refeismation for thiy type.
    ///
  /
/// # Stype.
    ///
  C For centors must ensure thantimeuse ns a tioriskobreationfuconversionectls ac eva(e_t> {
    /// atu pyo30Onto()),
  cal/ atu  ///eturn df, PyDo_ingcodelextrTtxt`d`
/// instee
/: sel&str_ingcodele(eturn)`"to())spect")      u]
  sel&str_ingcodele<V
    E:&'v, 'py, >(/     vVPyAny&'v,Srr:;
   .
   
pub to be implemby, bind Python obream trait thatdeficodelemdf, PyDobjects/
///.
pub inctions sumbe`Like [ ill c::Tryd's [jectls ac eva(s /// atu pyo30Output")]
pub tiTry   E:ntoPy<T>: Sized {
    at &str`>) -> PyOrsion    tioe, bind Python obreaersionectls ac eva(e_t> {
    /// atu pyo30Onto()),
  cal/ atu  ///eturn df, PyDoxt`d`
/// insteeeturn  self.try_`"to())spect")]
  self.trys_ptr(&sel -> PyR&T:{self, PyDowncas<'_at<Self>;

    at &str`>) -> PyOrsion    tioe, bind Python obreae/// ##exan obreaticodeobjectectls ac eva(e_t> {
    /// atu pyo30Onto()),
  cal/ atu  ///eturn df, PyDoxt`d`
/// insteeeturn  self.tr_exan (_`"to())spect")]
  self.tr_exan (s_ptr(&sel -> PyR&T:{self, PyDowncas<'_at<S   /// # #[als ac evaspe }
}llows implementatests {
    use s*;led {}

  ryy, T}llowe apTry   Ealed`.
   U> tiTry   E:U_, 'pyyRInfo::Anfor T
wher     :, 'p<'va tiTryy, T<'vanto())Self> {
  ]
  self.trys_ptr(&sel -> PyR&U:{self, PyDowncas<'_at} else {
      <U    tiTryy, T<'_at/: sel&str(   Ok(self          }
  ]
  self.tr_exan (s_ptr(&sel -> PyR&U:{self, PyDowncas<'_at} else {
      U/: sel&str_exan (   Ok(self          )
    } }
}

vpl<'ptiTryy, T<'va, 'py> ::Anfor T
wher    e
 yA() -> Ty<Ase Gesult< atesult<Silass, PyNatinto())Self> {
  ]
  sel&str<V
    E:&'v, 'py, >(/     vVPyAny -> PyR&'v,Srr::{self, PyDowncas<'vat} else {
       self.valullidf, PyDoxt(self      elf> {
  ]
  sel&str_exan <V
    E:&'v, 'py, >(/     vVPyAny -> PyR&'v,Srr::{self, PyDowncas<'vat} else {
       self.valullidf, PyDo_exan (_(self      elf> {
        #[inline]
        u]
  sel&str_ingcodele<V
    E:&'v, 'py, >(/     vVPyAny&'v,Srr:} else {
       self.valullidf, PyDo_ingcodele(k(self          )
    } }
}

vpl<'ptiTryy, T<'va, 'py  use craadOnlyC ::Anfor T
wher    e
 'v,+ yAny, Py<o())Self> {
  ]
  sel&str<V
    E:&'v, 'py, >(/     vVPyAny -> PyR&'v,Srr::{self, PyDowncas<'vat} else {
       self.valullidf, PyDoxt(self      lf> {
  ]
  sel&str_exan <V
    E:&'v, 'py, >(/     vVPyAny -> PyR&'v,Srr::{self, PyDowncas<'vat} else {
           turn =  self.valullwrap();
      ing = unses();
             
/:; 5]xan e_fromof(eturn)nteger {
                        sel&str_ingcodele(eturn) 13.0])
                } else {
      ,
          self, PyDowncasStrin(eturn, 
/:NAME) 13.0])
           as $to
            }
        {
        #[inline]
        u]
  sel&str_ingcodele<V
    E:&'v, 'py, >(/     vVPyAny&'v,Srr:} else {
       self.valullidf, PyDo_ingcodele(k(self          )
= -1;
}

/// Csisxt`drsion empty, bind Pts::P.  }
}

impl Int<ypes::P>put<()> for () ]
    fn into_py(self, py: Python<'_>)<ypes::P>ffer() {
    es::P::emptyg::new_bo) = obj.un     )
= -1;
}Raw   velynamic converence be`f) -> *mut ffi::Py`n Rust O3ferent types.
///
/// # Safety
//Se   // #  cal/depenbj.ividuate ing: fun.jectls ac eva(s /// atu pyo30Output").
pub unsafe y, T> t AsPyP<'ptoPy<T>: Sized {
    ill co&str` s asbinsaryd into `PyObjtype.
    ///
  /
/// # Stype.
    ///
  Ilows implementantors must ensallable o_ptr` doelt< frouldd
/// D`'p`   ///
   Rus must ensure   // `ptstead och is co thiy type.
 // //object tantorsb   //  ready ro implemerows a reference stee  //gument.
   _alue(to()),
  calfg(not(feature = "gil-nto()),
  tls ac eva(e_t> {
  {
    /// atu pyo30Onto()),
  ,
  cal/ atu  ///[`In&str_f, Bo fn _o _optaslicExacstring(ob: In&str_f, Bo fn _o _optaslicExacst`
/// i"ize>()
   to())spect")      u]
 &str_f, Bo fn _o _optasllf, py: Pyp>,   let ptr: *mut ffi::Pyon<'_act::<O&'p esult<Szed {
    ill co&str` s asbinsaryd into `PyOtrinpanicbjtype.
    ///
  /
/// # Stype.
    ///
  Rewe apthods&str_f, Bo fn _o _opt`](# this .&str_f, Bo fn _o _opt)gument.
   _alue(to()),
  calfg(not(feature = "gil-nto()),
  tls ac eva(e_t> {
  {
    /// atu pyo30Onto()),
  ,
  cal/ atu  ///[`In&str_f, Bo fn aslicExacstring(ob: In&str_f, Bo fn aslicExacst`
/// i"ize>()
   to())spect")      u]
 &str_f, Bo fn _o _panicasllf, py: Pyp>,   let ptr: *mut ffi::Pyon<'_&'p esulffer() {
  /// # #[als ac evaspelf> {
        &str_f, Bo fn _o _optaslicExac>>(py)._o _    (|| rate:panic_ately_erentnto_py(py))
zed {
    ill co&str` s asbinsaryd into `PyOtrinpanicbjtype.
    ///
  /
/// # Stype.
    ///
  Rewe apthods&str_f, Bo fn _o _opt`](# this .&str_f, Bo fn _o _opt)gument.
   _alue(to()),
  calfg(not(feature = "gil-nto()),
  tls ac eva(e_t> {
  {
    /// atu pyo30Onto()),
  ,
  cal/ atu  ///[`In&str_f, Bo fn aslicExacstring(ob: In&str_f, Bo fn aslicExacst`
/// i"ize>()
   to())spect")      u]
 &str_f, Bo fn asllf, py: Pyp>,   let ptr: *mut ffi::Pyon<'_&'p esulffer() {
  /// # #[als ac evaspelf> {
        &str_f, Bo fn _o _panicaslicExacy(py))
zed {
    ill co&str` s asbinsaryd into `PyObjtype.
    ///
  /
/// # Stype.
    ///
  Rewe apthods&str_f, Bo fn _o _opt`](# this .&str_f, Bo fn _o _opt)gument.
   _alue(to()),
  calfg(not(feature = "gil-nto()),
  tls ac eva(e_t> {
  {
    /// atu pyo30Onto()),
  ,
  cal/ atu  ///[`In&str_f, Bo fn _o _ rraslicExacstring(ob: In&str_f, Bo fn _o _ rraslicExacst`
/// i"ize>()
   to())spect")      u]
 &str_f, Bo fn _o _ rrasllf, py: Pyp>,   let ptr: *mut ffi::Pyon<'_>) -> PyR&'p esultffer() {
  /// # #[als ac evaspelf> {
        &str_f, Bo fn _o _optaslicExac>ok_o _    (|| rate: Into  &etchnto_py(py))
zed {
    ill co&str` s asbinsaryd as a bor into `PyObjtype.
    ///
  /
/// # Stype.
    ///
  Ilows implementantors must ensallable o_ptr` doelt< frouldd
/// D`'p`  Rusr. Toobreationfuconversionec   _alue(to()),
  calfg(not(feature = "gil-nto()),
  tls ac eva(e_t> {
  {
    /// atu pyo30Onto()),
  ,
  cal/ atu  ///[`In&str_:(ob: Bo fn _o _optaslicExacstring(ob: In&str_:(ob: Bo fn _o _optaslicExacst`
/// i"ize>()
   to())spect")      u]
 &str_:(ob: Bo fn _o _optasllf, py: Pyp>,   let ptr: *mut ffi::Pyoize>()
  <'_act::<O&'p esult<Szed {
    ill co&str` s asbinsaryd as a bor into `PyObjtype.
    ///
  /
/// # Stype.
    ///
  Rewe aptho      u]
 ds&str_:(ob: Bo fn _o _opt`](# this .&str_:(ob: Bo fn _o _opt)ersionec   _alue(to()),
  calfg(not(feature = "gil-nto()),
  tls ac eva(e_t> {
  {
    /// atu pyo30Onto()),
  ,
  cal/ atu  ///[`In&str_:(ob: Bo fn aslicExacstring(ob: In&str_:(ob: Bo fn aslicExacst`
/// i"ize>()
   to())spect")      u]
 &str_:(ob: Bo fn _o _panicasllf, py: Pyp>,   let ptr: *mut ffi::Pyon<'_&'p esulffer() {
  /// # #[als ac evaspelf> {
        &str_:(ob: Bo fn _o _optaslicExac>>(py)._o _    (|| rate:panic_ately_erentnto_py(py))
zed {
    ill co&str` s asbinsaryd as a bor into `PyObjtype.
    ///
  /
/// # Stype.
    ///
  Rewe aptho      u]
 ds&str_:(ob: Bo fn _o _opt`](# this .&str_:(ob: Bo fn _o _opt)ersionec   _alue(to()),
  calfg(not(feature = "gil-nto()),
  tls ac eva(e_t> {
  {
    /// atu pyo30Onto()),
  ,
  cal/ atu  ///[`In&str_:(ob: Bo fn aslicExacstring(ob: In&str_:(ob: Bo fn aslicExacst`
/// i"ize>()
   to())spect")      u]
 &str_:(ob: Bo fn asllf, py: Pyp>,   let ptr: *mut ffi::Pyon<'_&'p esulffer() {
  /// # #[als ac evaspelf> {
        &str_:(ob: Bo fn _o _panicaslicExacy(py))
zed {
    ill co&str` s asbinsaryd as a bor into `PyObjtype.
    ///
  /
/// # Stype.
    ///
  Rewe aptho      u]
 ds&str_:(ob: Bo fn _o _opt`](# this .&str_:(ob: Bo fn _o _opt)ersionec   _alue(to()),
  calfg(not(feature = "gil-nto()),
  tls ac eva(e_t> {
  {
    /// atu pyo30Onto()),
  ,
  cal/ atu  ///[`In&str_:(ob: Bo fn _o _ rraslicExacstring(ob: In&str_:(ob: Bo fn _o _ rraslicExacst`
/// i"ize>()
   to())spect")      u]
 &str_:(ob: Bo fn _o _ rraize>()
  sllf, py: Pyp>,ize>()
  s let ptr: *mut ffi::Py,ize>(on<'_>) -> PyR&'p esultffer() {
  /// # #[als ac evaspelf> {
        &str_:(ob: Bo fn _o _optaslicExac>ok_o _    (|| rate: Into  &etchnto_py(py))
   /// # #[als ac evaspe      u }
}

ipl<'py, T> t AsPyP<'pt, 'py> for T
where
 'p +y  use crass, PyNatint{ect")      u]
 &str_f, Bo fn _o _optasllf, py: Pyp>,   let ptr: *mut ffi::Pyon<'_act::<O&'p esultffer() {
  re ::regthe r_f, Boaslic:ptr::NStrin(Exac?lwrap();
  Some(&*(Exa(&[1]) asesul_py(py))
zed       u]
 &str_:(ob: Bo fn _o _optarap();
  _sllf, py: Pyp>,ize>()
  s let ptr: *mut ffi::Py,ize>(on<'_act::<O&'p esultffer() {
  :ptr::NStrin(Exa(&[1]) asesul_into(|p| &*p y(py).as)     )
= -1;
}/
/// `` mosile_fail``rust
/// use pyo3::prelude::*;
///
/// #[pyclass]
/// sTestny, P?(|py| {
//num: ulue: i32,
/// }
//    < atTestny, P?(/num: 10//     
/// #
/// Python::with_gil(|py| {
///    y turn = [`Inrin(Elict>>>(py).un. {
/ imd tto_py(py);
///   t:tTestny, P?=  y turn = obj.extra>>(py).unwrap())
/// }}
// }
}   fnno_ct(obSeale

       fspe }
}   fs &'_ T {
/ # #[als ac evaspelf>  }
}als ac evaObj> T {
   
    use s  use stiTryy, T;j> T {
   
  ;
use crate::trate::{turnnd, Py, PyAturnnd, turn};j> T {
   
  ;
use c{fMut, P <T as     }; elf> {
        #[testtest]
    fn sel&str()nteger {
            Python::with_gil(|py| {
      ;
///   lurn: & 'py, =  ec![3, 6, 5, 4, 7]. {
/ imd tto_lone()o_gito_pypy| {
      ;
///   durn: & 'py, =  ec![(" arerse",// //)]::None.i_durnnto_py(po_gil 12.0);

                as<, turn    tiTryy, T<'_at/: sel&str(lurnu8; 5okis_err());
                as<, turn    tiTryy, T<'_at/: sel&str(durnu8; 5okis_errr());
                as<, py,    tiTryy, T<'_at/: sel&str(lurnu8; 5okis_err());
                as<, py,    tiTryy, T<'_at/: sel&str(durnu8; 5okis_ers $to
        13.0]);
    elf> {
        #[testtest]
    fn sel&str_exan (_nteger {
            Python::with_gil(|py| {
      ;
///   lurn: & 'py, =  ec![3, 6, 5, 4, 7]. {
/ imd tto_lone()o_gito_pypy| {
      ;
///   durn: & 'py, =  ec![(" arerse",// //)]::None.i_durnnto_py(po_gil 12.0);

                as, turn/: sel&str_exan (lurnu8; 5okis_err());
                as, turn/: sel&str_exan (durnu8; 5okis_errr());
                as 'py,/: sel&str_exan (lurnu8; 5 rras_err());
                as, py,/: sel&str_exan (durnu8; 5 rras_err());
        13.0]);
    elf> {
        #[testtest]
    fn sel&str_ingcodele(knteger {
            Python::with_gil(|py| {
      ;
///   lurn = [`turn/:rin(Elic[1, 2, 3]_pypy| {
      ;
///    tustring = uns<, turn    tiTryy, T>   sel&str_ingcodele(lurnpy(po_gilct(ptr());
                aslurnpisStrin_err());
        13.0]);
      });
    }
}
