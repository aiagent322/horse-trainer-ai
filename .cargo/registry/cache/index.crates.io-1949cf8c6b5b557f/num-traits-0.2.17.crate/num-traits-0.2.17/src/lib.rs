// Copyright 2013-2014 The Rust Project Developers. See the COPYRIGHT
// file at the top-level directory of this distribution and at
// http://rust-lang.org/COPYRIGHT.
//
// Licensed under the Apache License, Version 2.0 <LICENSE-APACHE or
// http://www.apache.org/licenses/LICENSE-2.0> or the MIT license
// <LICENSE-MIT or http://opensource.org/licenses/MIT>, at your
// option. This file may not be copied, modified, or distributed
// except according to those terms.

//! Numeric traits for generic mathematics
//!
//! ## Compatibility
//!
//! The `num-traits` crate is tested for rustc 1.31 and greater.

#![doc(html_root_url = "https://docs.rs/num-traits/0.2")]
#![deny(unconditional_recursion)]
#![no_std]

// Need to explicitly bring the crate in for inherent float methods
#[cfg(feature = "std")]
extern crate std;

use core::fmt;
use core::num::Wrapping;
use core::ops::{Add, Div, Mul, Rem, Sub};
use core::ops::{AddAssign, DivAssign, MulAssign, RemAssign, SubAssign};

pub use crate::bounds::Bounded;
#[cfg(any(feature = "std", feature = "libm"))]
pub use crate::float::Float;
pub use crate::float::FloatConst;
// pub use real::{FloatCore, Real}; // NOTE: Don't do this, it breaks `use num_traits::*;`.
pub use crate::cast::{cast, AsPrimitive, FromPrimitive, NumCast, ToPrimitive};
pub use crate::identities::{one, zero, One, Zero};
pub use crate::int::PrimInt;
pub use crate::ops::bytes::{FromBytes, ToBytes};
pub use crate::ops::checked::{
    CheckedAdd, CheckedDiv, CheckedMul, CheckedNeg, CheckedRem, CheckedShl, CheckedShr, CheckedSub,
};
pub use crate::ops::euclid::{CheckedEuclid, Euclid};
pub use crate::ops::inv::Inv;
pub use crate::ops::mul_add::{MulAdd, MulAddAssign};
pub use crate::ops::saturating::{Saturating, SaturatingAdd, SaturatingMul, SaturatingSub};
pub use crate::ops::wrapping::{
    WrappingAdd, WrappingMul, WrappingNeg, WrappingShl, WrappingShr, WrappingSub,
};
pub use crate::pow::{checked_pow, pow, Pow};
pub use crate::sign::{abs, abs_sub, signum, Signed, Unsigned};

#[macro_use]
mod macros;

pub mod bounds;
pub mod cast;
pub mod float;
pub mod identities;
pub mod int;
pub mod ops;
pub mod pow;
pub mod real;
pub mod sign;

/// The base trait for numeric types, covering `0` and `1` values,
/// comparisons, basic numeric operations, and string conversion.
pub trait Num: PartialEq + Zero + One + NumOps {
    type FromStrRadixErr;

    /// Convert from a string and radix (typically `2..=36`).
    ///
    /// # Examples
    ///
    /// ```rust
    /// use num_traits::Num;
    ///
    /// let result = <i32 as Num>::from_str_radix("27", 10);
    /// assert_eq!(result, Ok(27));
    ///
    /// let result = <i32 as Num>::from_str_radix("foo", 10);
    /// assert!(result.is_err());
    /// ```
    ///
    /// # Supported radices
    ///
    /// The exact range of supported radices is at the discretion of each type implementation. For
    /// primitive integers, this is implemented by the inherent `from_str_radix` methods in the
    /// standard library, which **panic** if the radix is not in the range from 2 to 36. The
    /// implementation in this crate for primitive floats is similar.
    ///
    /// For third-party types, it is suggested that implementations should follow suit and at least
    /// accept `2..=36` without panicking, but an `Err` may be returned for any unsupported radix.
    /// It's possible that a type might not even support the common radix 10, nor any, if string
    /// parsing doesn't make sense for that type.
    fn from_str_radix(str: &str, radix: u32) -> Result<Self, Self::FromStrRadixErr>;
}

/// Generic trait for types implementing basic numeric operations
///
/// This is automatically implemented for types which implement the operators.
pub trait NumOps<Rhs = Self, Output = Self>:
    Add<Rhs, Output = Output>
    + Sub<Rhs, Output = Output>
    + Mul<Rhs, Output = Output>
    + Div<Rhs, Output = Output>
    + Rem<Rhs, Output = Output>
{
}

impl<T, Rhs, Output> NumOps<Rhs, Output> for T where
    T: Add<Rhs, Output = Output>
        + Sub<Rhs, Output = Output>
        + Mul<Rhs, Output = Output>
        + Div<Rhs, Output = Output>
        + Rem<Rhs, Output = Output>
{
}

/// The trait for `Num` types which also implement numeric operations taking
/// the second operand by reference.
///
/// This is automatically implemented for types which implement the operators.
pub trait NumRef: Num + for<'r> NumOps<&'r Self> {}
impl<T> NumRef for T where T: Num + for<'r> NumOps<&'r T> {}

/// The trait for `Num` references which implement numeric operations, taking the
/// second operand either by value or by reference.
///
/// This is automatically implemented for all types which implement the operators. It covers
/// every type implementing the operations though, regardless of it being a reference or
/// related to `Num`.
pub trait RefNum<Base>: NumOps<Base, Base> + for<'r> NumOps<&'r Base, Base> {}
impl<T, Base> RefNum<Base> for T where T: NumOps<Base, Base> + for<'r> NumOps<&'r Base, Base> {}

/// Generic trait for types implementing numeric assignment operators (like `+=`).
///
/// This is automatically implemented for types which implement the operators.
pub trait NumAssignOps<Rhs = Self>:
    AddAssign<Rhs> + SubAssign<Rhs> + MulAssign<Rhs> + DivAssign<Rhs> + RemAssign<Rhs>
{
}

impl<T, Rhs> NumAssignOps<Rhs> for T where
    T: AddAssign<Rhs> + SubAssign<Rhs> + MulAssign<Rhs> + DivAssign<Rhs> + RemAssign<Rhs>
{
}

/// The trait for `Num` types which also implement assignment operators.
///
/// This is automatically implemented for types which implement the operators.
pub trait NumAssign: Num + NumAssignOps {}
impl<T> NumAssign for T where T: Num + NumAssignOps {}

/// The trait for `NumAssign` types which also implement assignment operations
/// taking the second operand by reference.
///
/// This is automatically implemented for types which implement the operators.
pub trait NumAssignRef: NumAssign + for<'r> NumAssignOps<&'r Self> {}
impl<T> NumAssignRef for T where T: NumAssign + for<'r> NumAssignOps<&'r T> {}

macro_rules! int_trait_impl {
    ($name:ident for $($t:ty)*) => ($(
        impl $name for $t {
            type FromStrRadixErr = ::core::num::ParseIntError;
            #[inline]
            fn from_str_radix(s: &str, radix: u32)
                              -> Result<Self, ::core::num::ParseIntError>
            {
                <$t>::from_str_radix(s, radix)
            }
        }
    )*)
}
int_trait_impl!(Num for usize u8 u16 u32 u64 u128);
int_trait_impl!(Num for isize i8 i16 i32 i64 i128);

impl<T: Num> Num for Wrapping<T>
where
    Wrapping<T>: NumOps,
{
    type FromStrRadixErr = T::FromStrRadixErr;
    fn from_str_radix(str: &str, radix: u32) -> Result<Self, Self::FromStrRadixErr> {
        T::from_str_radix(str, radix).map(Wrapping)
    }
}

#[derive(Debug)]
pub enum FloatErrorKind {
    Empty,
    Invalid,
}
// FIXME: core::num::ParseFloatError is stable in 1.0, but opaque to us,
// so there's not really any way for us to reuse it.
#[derive(Debug)]
pub struct ParseFloatError {
    pub kind: FloatErrorKind,
}

impl fmt::Display for ParseFloatError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let description = match self.kind {
            FloatErrorKind::Empty => "cannot parse float from empty string",
            FloatErrorKind::Invalid => "invalid float literal",
        };

        description.fmt(f)
    }
}

fn str_to_ascii_lower_eq_str(a: &str, b: &str) -> bool {
    a.len() == b.len()
        && a.bytes().zip(b.bytes()).all(|(a, b)| {
            let a_to_ascii_lower = a | (((b'A' <= a && a <= b'Z') as u8) << 5);
            a_to_ascii_lower == b
        })
}

// FIXME: The standard library from_str_radix on floats was deprecated, so we're stuck
// with this implementation ourselves until we want to make a breaking change.
// (would have to drop it from `Num` though)
macro_rules! float_trait_impl {
    ($name:ident for $($t:ident)*) => ($(
        impl $name for $t {
            type FromStrRadixErr = ParseFloatError;

            fn from_str_radix(src: &str, radix: u32)
                              -> Result<Self, Self::FromStrRadixErr>
            {
                use self::FloatErrorKind::*;
                use self::ParseFloatError as PFE;

                // Special case radix 10 to use more accurate standard library implementation
                if radix == 10 {
                    return src.parse().map_err(|_| PFE {
                        kind: if src.is_empty() { Empty } else { Invalid },
                    });
                }

                // Special values
                if str_to_ascii_lower_eq_str(src, "inf")
                    || str_to_ascii_lower_eq_str(src, "infinity")
                {
                    return Ok(core::$t::INFINITY);
                } else if str_to_ascii_lower_eq_str(src, "-inf")
                    || str_to_ascii_lower_eq_str(src, "-infinity")
                {
                    return Ok(core::$t::NEG_INFINITY);
                } else if str_to_ascii_lower_eq_str(src, "nan") {
                    return Ok(core::$t::NAN);
                } else if str_to_ascii_lower_eq_str(src, "-nan") {
                    return Ok(-core::$t::NAN);
                }

                fn slice_shift_char(src: &str) -> Option<(char, &str)> {
                    let mut chars = src.chars();
                    Some((chars.next()?, chars.as_str()))
                }

                let (is_positive, src) =  match slice_shift_char(src) {
                    None             => return Err(PFE { kind: Empty }),
                    Some(('-', ""))  => return Err(PFE { kind: Empty }),
                    Some(('-', src)) => (false, src),
                    Some((_, _))     => (true,  src),
                };

                // The significand to accumulate
                let mut sig = if is_positive { 0.0 } else { -0.0 };
                // Necessary to detect overflow
                let mut prev_sig = sig;
                let mut cs = src.chars().enumera   let repim => (false, src),
                    Some((_mera  kind: Empty }),
       alent to signed `Shr`.
ples
    ///
    /// ```
    /// use num_traits::PrimInt;
e, e chffsetind: Empty }),
       alePri__too toN      s_str()se cor>0.0 };
               ationt bit
    //    tlet n = Necessary t.chars();
           (i   )et = s   _m_t( => return Err(PFE { kin      c`expdigit(::num:      }

                //     digiteq!(one::<$t>(), on };
               P = onNecessary to: Emdigittwisee::<$t>(), on };
            ((_m*=mpty() 16 u30.0 };
                           add/subbasicltin primdigittld ap_be numnNece0 };
                        v_sig = sig;
   atErrorKind::*;
                 ((_m+=  digit 16 dixEr) 16 u30.orKind::*;
                  /// Raises sorKind::*;
                 ((_m-=  digit 16 dixEr) 16 u30.orKind::*;
                  .0 };
                           Dim => (false, sign  type crate lgnifsrc, ,e `num-0 };
                           v_s it
      seenfmt:: thas::cmdigitles
                           v_s Some((_m_fal.0aises sorKind::*;
                 v_sig = sig;
  tr_((_mdix Some((_ses sorKind::*;
                 src,     || str_to_ascii_lower_eq_st }
    };
}

on*;
                 v_s!ig = sig;
  tr_((_m>ix Some((_ses sorKind::*;
                 src,     || str_to_ascii_lre::$t::NAN);
  .0 };
                               Dim => (false, sign      ators.
pu = oes (-addree ra  ses sorKind::*;
                 v_sig = sig;
  tr_( Some((_m_fa(((_m- digit 16 $teq/mpty() 16 u3)ses sorKind::*;
                 src,     || str_to_ascii_lower_eq_st }
    };
}

on*;
                 v_s!ig = sig;
  tr_( Some((_m_fa(((_m+ digit 16 $teq/mpty() 16 u3)ses sorKind::*;
                 src,     || str_to_ascii_lre::$t::NAN);
  .orKind::*;
                  .orKind::*;
                  Some((_mera  kind: Empty }),
           ,ind: Empty }),
          d: Em!(o      caises sorKind::*;
             'e' | 'E' | 'p' | 'P'q!(one::<$t>(), on };
                Pri__too toift_cha, im+ 1));e::<$t>(), on };
                r $($;     Pt  tlet PrimInt;.orKind::*;
                  ,ses sorKind::*;
             '.'q!(one::<$t>(), on };
                r $($;     Pt  tlet fasic nutr(   t.orKind::*;
                  ,ses sorKind::*;
             _q!(one::<$t>(), on };
                _, _))     => (true,  s_ascii_lo);e::<$t>(), on };
             ,ses sorKind::*;
         ower_eq_str(src, "inf")
                  || str_to_ascii_lowerI_s i n =     yetnt `fromPrimInt;
ptiont bitfasic nutr| str_to_ascii_lower   tlet n = Necessary t.chars();
       if Pri__tooues
n/int.rs     rc),
                     standa1.0;e::<$t>(), on };
        (i   )et = s   _m_t( => return Err(PFE { kin kin      c`expdigit(::num:      }

                //  //     digiteq!(one::<$t>(), on };
                   Dic
   m_traits:nd least-sigmacestudee::<$t>(), on };
                traits/=mpty() 16 u30.::<$t>(), on };
                   add/subbasicltin primdigittld ap_be numnNece0 };
                            ((_m= v_sig = sig;
   atErrorKind::*;
                     ((_m+  digit 16 $teq* traitatErrorKind::*;
                  /// Raises sorKind::*;
                     ((_m-  digit 16 $teq* traitatErrorKind::*;
                  ;0 };
                               Dim => (false, sign  type crate lgnifsrc, ses sorKind::*;
                 v_sig = sig;
  tr_((_mdx Some((_ses sorKind::*;
                 src,     || str_to_ascii_lower_eq_st }
    };
}

on*;
                 v_s!ig = sig;
  tr_((_m>x Some((_ses sorKind::*;
                 src,     || str_to_ascii_lre::$t::NAN);
  .::<$t>(), on };
                tSome((_mera  kind: Empty }),
               ,ses sorKind::*;
             d: Em!(o      caises sorKind::*;
                 'e' | 'E' | 'p' | 'P'q!(one::<$t>(), on };
                    Pri__too toift_cha, im+ 1));e::<$t>(), on };
                    r $($;    Pt  tlet PrimInt;.orKind::*;
                      ,ses sorKind::*;
                 _q!(one::<$t>(), on };
                    _, _))     => (true,  s_ascii_lo);e::<$t>(), on };
                 ,ses sorKind::*;
              ,ses sorKind::*;
         oer_eq_str(src, "inf")
                  || str_to_ascii_lowerationty tocalcoverf`fromPrimInt;ind: Empty }),
      PriatErrorKiPri__too {rc) =  match slice_shift_cha,chffset)eq!(one::<$t>(), on };
            conve=o      caises sorKind::*;
             'E' | 'e' _empty() { Empt!(o1l.0,ses sorKind::*;
             'P' | 'p' _empty() { Em6t!(o2.0,ses sorKind::*;
             _me((_, _))     => (true,  s_ascii_lo),ses sorKind::*;
         o0.0 };
                       ationt bitPrimInt;
wouldcimtr(g., bitw::<$t>(), on };
            srce=o&src[hffset..];w::<$t>(), on };
            : Empty }),
  m_inatErrorKin   Some(('-', ""))  => return Err(PFE { kin;

                // The significand t      ::Self>
>()), return Err(PFE { kin;

            +   // The sigf is_posit      ::Self>
>()), return Err(PFE { kin;

           let mut sig = if is_posit      ::Self>
>()), return Err(PFE { kin;

     d: Empty }),
                    Some(('-',_ascii_lo),ses sorKind::*;
         o0.0 };
                     Rem, Sub};
use core::op };
                    nt_implconv: $tpe, signixEr) ->                                  F use cimpilconvpe, s 16 dFloatErrorKind::*;
         }0 };
                       orror;
   u second 

#![doc`imp`ped.
    / bri
 return Err(PFE { kin kin      : Empty }),
  m_ina                              if is_potr_m_inhe siimplconv  m_in, return Err(PFE { kin;

     gnificantr_m_inhe si1.0q/mimplconv  m_in, return Err(PFE { kin;

     glet     mut sig                 Some(('-',_ascii_lo),ses sorKind::*;
         o
nd::*;
              ,ses sorKind::*;
     d: Em!(otErroit wasPrimInt;ind: Empty }),
  o0.0 };
            tr_((_m*im_int_impl!(u16, i16, u16);
prim_pl<T: RadixErr = Parse FromStrRaf32 fte::io().co
/// valnst;
/equivaminimomS   //n  ximomsign + forI_sineranis <&'r thanamin    ntationr  ///
 min. + forI_sineranis 
// Nee thanamax    ntationr  ///
 max. + forOrror;
   ationr  ///
 inerassign + fo**Pn suss sinuldbugrati     `!(min <tErrx)`Erronum::Par  asserclampfn f + BitXor<>(inera: T, min: T, max: T) ->      }

ldbug_orted ramin <tErrx, "min m//rube <&'r thanarRaequCopy:idex");e::<$i_sineran<amin           min
     }

      ineran>amax           max
     /// Raises sorKiinerap(b.bytes(().co
/// valnst;
/equivaminimomSsrc, sign + forI_sineranis <&'r thanamin    ntationr  ///
 min. + forOrror;
   ationr  ///
 inerassign  `clamp_min(ore::f4), NAN,otEr)`    //rt_im`NAN`mdiffops::{Ar $t f4), min(ore::f4), NAN,otEr)`ssign + fo**Pn suss sinuldbugrati     `!(min { Eminn fo(r<'r>oap_es    `min`nis `NAN`.)rronum::Par#[ad ra(clippy::eq_op)ar  asserclamp_minfn f + BitXor<>(inera: T, min: T) ->      }

ldbug_orted ramin { Emin, "min m//rumatics
NAN");e::<$i_sineran<amin           min
     }

   ises sorKiinerap(b.bytes(().co
/// valnst;
/equivam ximomSsrc, sign + forI_sineranis 
// Nee thanamax    ntationr  ///
 max. + forOrror;
   ationr  ///
 inerassign  `clamp_max(ore::f4), NAN,otEr)`    //rt_im`NAN`mdiffops::{Ar $t f4), max(ore::f4), NAN,otEr)`ssign + fo**Pn suss sinuldbugrati     `!(ma) { Errx)`Eo(r<'r>oap_es    `max`nis `NAN`.)rronum::Par#[ad ra(clippy::eq_op)ar  asserclamp_maxfn f + BitXor<>(inera: T, max: T) ->      }

ldbug_orted rama) { Errx, "ma) m//rumatics
NAN");e::<$i_sineran>amax           max
     /// Raises sorKiinerap(b.bytes(, 0);
  serclamp_0);
(// }
    / )
  0);

               1,rclamp 1,r-1,r2));e::<$           -1,rclamp -2,r-1,r2));e::<$           2,rclamp 3,r-1,r2));e::<$           1,rclamp_min(1,r-1));e::<$           -1,rclamp_min(-2,r-1));e::<$           -1,rclamp_max(1,r-1));e::<$           -2,rclamp_max(-2,r-1));e}
    / F use 0);

               1Erroclamp 1Erro-1Erro2.0));e::<$           -1Erroclamp  notro-1Erro2.0));e::<$           2Erroclamp 3otro-1Erro2.0));e::<$           1Erroclamp_min(1otro-1Er));e::<$           -1Erroclamp_min(-2otro-1Er));e::<$           -1Erroclamp_max(1otro-1Er));e::<$           -2Erroclamp_max(-2otro-1Er));e::<$      !(clamp     )*)
f4), NAN,o-1Erro1Er)ues
nan());e::<$      !(clamp_min(    )*)
f4), NAN,o1Er)ues
nan());e::<$      !(clamp_max(    )*)
f4), NAN,o1Er)ues
nan());ees(, 0);
  #[nsuppo_en su] pub usldbug_orted ent )  serclamp_nan_min(// }
   clamp 0.}
    )*)
f4), NAN,o1E);ees(, 0);
  #[nsuppo_en su] pub usldbug_orted ent )  serclamp_nan_max(// }
   clamp 0.}
-1E}
    )*)
f4), NAN);ees(, 0);
  #[nsuppo_en su] pub usldbug_orted ent )  serclamp_nan_min_max(// }
   clamp 0.}
    )*)
f4), NAN,o    )*)
f4), NAN);ees(, 0);
  #[nsuppo_en su] pub usldbug_orted ent )  serclamp_min_nan_min(// }
   clamp_min(0E}
    )*)
f4), NAN);ees(, 0);
  #[nsuppo_en su] pub usldbug_orted ent )  serclamp_max_nan_max(// }
   clamp_max(0E}
    )*)
f4), NAN);ees(, 0);
           {
      _unow::(// }
    / http: emptye     m//ru radi fn fo detd radunow::(/
_33) << 2i:FromS=ally  ///
    /// The 0ct ran.unow::(/;e::<$           i8::MIN_33) << 2f:af32 =ally  ///
    /// The 0.0ct ran.unow::(/;e::<$           f,al.0);ees(, 0);
           {
      _met ns(sel_fail(// }
    / Ens;
usStrRadixErr>;
}
en su,om_strlemenscii_l   im', "act.
pu::<$      !(f4), ///
    /// The ™metht ran.s at the di}
    / E_strw  ntStrRadix bitPrimInt;
Nece0 };
      !(f4), ///
    /// The metE™1ht ran.s at the dies(, 0);
           {
      _ece )*_    (// }
     );

        assertf4), ///
    /// The InF"urn 0.unow::(/,ses sorKi    )*)
f4), $t::NAN)
       
     );

        assertf4), ///
    /// The Ino_ascY"urn 0.unow::(/,ses sorKi    )*)
f4), $t::NAN)
       
     );

        assertf4), ///
    /// The -InF"ur80.unow::(/,ses sorKi    )*)
f4), re::$t::NAN)
       
     );

        assertf4), ///
    /// The -Ino_ascY"ur80.unow::(/,ses sorKi    )*)
f4), re::$t::NAN)
       
     );

!(f4), ///
    /// The nAn"ur40.unow::(/ues
nan());e::<$      !(f4), ///
    /// The -nAn"ur40.unow::(/ues
nan());ees(, 0);
     ow::{che_es
num(// }
   sert_qui)*_numfn from_(_: &T) { = (rep_qui)*_num(&eFloatEr(42_:Flo   #[inliqui)*_num(&eFloatEr(-42));ees(, 0);
     ow::{che_///
    /// The// }
    type FromStr0);
_ow::{che_///
    /// Thaises sorKi(        +eq!(one::<$t>(), on$(.chars();
           &Num f)et =&[("4tht ran, ("4tht 2n, ("-13.0ct ran, ("exact ran]rs     rc),
               w =aWw::{check8);
int_trait_impl!(Num f::Pars|w| w.0);e::<$t>(), on };
      );

     w,28);dices
    ///
    /// Theum f:  let mut chars = srcut chars = s)+
         ;0 };
 || str0);
_ow::{che_///
    /// Th
prim_ie
    Wrapping<TdixErr = T::FromStrR);ees(, 0);
     
pub _num_ops(// }
   ser  tyute<ng the setrib>lf) T, y: T) ->      }





x * y / y % y + y - yep_03 = (re  );

       tyute(1t 2n, 1)ees(, 0);
     
pub _numref_ops(// }
   ser  tyute<ng theRef>lf) T, y: &T) ->      }





x * y / y % y + y - yep_03 = (re  );

       tyute(1t &2n, 1)ees(, 0);
     
pub _refnum_ops(// }
   ser  tyute<ng trib>lf) &T, y: T) ->   reversdix: u32       <'a> &'a($(
mplemenT>,ses s   }





&(&(&(&(x * yeq/myeq%myeq+myeq- yep_03 = (re  );

       tyute(&1t 2n, 1)ees(, 0);
     
pub _refref_ops(// }
   ser  tyute<n>lf) &T, y: &T) ->   reversdix: u32       <'a> &'a($(
mplemenT>,ses s   }





&(&(&(&(x * yeq/myeq%myeq+myeq- yep_03 = (re  );

       tyute(&1t &2n, 1)ees(, 0);
     
pub _numypes w_ops(// }
   ser  tyute<ng the     impltrib>l    f) T, y: T) ->      }





x *= y;  }





x /= y;  }





x %= y;  }





x += y;  }





x -= y;  }





xep_03 = (re  );

       tyute(1t 2n, 1)ees(, 0);
     
pub _numypes wref_ops(// }
   ser  tyute<ng thent for $($pltrib>l    f) T, y: &T) ->      }





x *= y;  }
