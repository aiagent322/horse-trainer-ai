/*!
Provides [`Automaton`] trait for abstracting over Aho-Corasick automata.

The `Automaton` trait provides a way to write generic code over any
Aho-Corasick automaton. It also provides access to lower level APIs that
permit walking the state transitions of an Aho-Corasick automaton manually.
*/

use alloc::{string::String, vec::Vec};

use crate::util::{
    error::MatchError,
    primitives::PatternID,
    search::{Anchored, Input, Match, MatchKind, Span},
};

pub use crate::util::{
    prefilter::{Candidate, Prefilter},
    primitives::{StateID, StateIDError},
};

/// We seal the `Automaton` trait for now. It's a big trait, and it's
/// conceivable that I might want to add new required methods, and sealing the
/// trait permits doing that in a backwards compatible fashion. On other the
/// hand, if you have a solid use case for implementing the trait yourself,
/// please file an issue and we can discuss it. This was *mostly* done as a
/// conservative step.
pub(crate) mod private {
    pub trait Sealed {}
}
impl private::Sealed for crate::nfa::noncontiguous::NFA {}
impl private::Sealed for crate::nfa::contiguous::NFA {}
impl private::Sealed for crate::dfa::DFA {}

impl<'a, T: private::Sealed + ?Sized> private::Sealed for &'a T {}

/// A trait that abstracts over Aho-Corasick automata.
///
/// This trait primarily exists for niche use cases such as:
///
/// * Using an NFA or DFA directly, bypassing the top-level
/// [`AhoCorasick`](crate::AhoCorasick) searcher. Currently, these include
/// [`noncontiguous::NFA`](crate::nfa::noncontiguous::NFA),
/// [`contiguous::NFA`](crate::nfa::contiguous::NFA) and
/// [`dfa::DFA`](crate::dfa::DFA).
/// * Implementing your own custom search routine by walking the automaton
/// yourself. This might be useful for implementing search on non-contiguous
/// strings or streams.
///
/// For most use cases, it is not expected that users will need
/// to use or even know about this trait. Indeed, the top level
/// [`AhoCorasick`](crate::AhoCorasick) searcher does not expose any details
/// about this trait, nor does it implement it itself.
///
/// Note that this trait defines a number of default methods, such as
/// [`Automaton::try_find`] and [`Automaton::try_find_iter`], which implement
/// higher level search routines in terms of the lower level automata API.
///
/// # Sealed
///
/// Currently, this trait is sealed. That means users of this crate can write
/// generic routines over this trait but cannot implement it themselves. This
/// restriction may be lifted in the future, but sealing the trait permits
/// adding new required methods in a backwards compatible fashion.
///
/// # Special states
///
/// This trait encodes a notion of "special" states in an automaton. Namely,
/// a state is treated as special if it is a dead, match or start state:
///
/// * A dead state is a state that cannot be left once entered. All transitions
/// on a dead state lead back to itself. The dead state is meant to be treated
/// as a sentinel indicating that the search should stop and return a match if
/// one has been found, and nothing otherwise.
/// * A match state is a state that indicates one or more patterns have
/// matched. Depending on the [`MatchKind`] of the automaton, a search may
/// stop once a match is seen, or it may continue looking for matches until
/// it enters a dead state or sees the end of the haystack.
/// * A start state is a state that a search begins in. It is useful to know
/// when a search enters a start state because it may mean that a prefilter can
/// be used to skip ahead and quickly look for candidate matches. Unlike dead
/// and match states, it is never necessary to explicitly handle start states
/// for correctness. Indeed, in this crate, implementations of `Automaton`
/// will only treat start states as "special" when a prefilter is enabled and
/// active. Otherwise, treating it as special has no purpose and winds up
/// slowing down the overall search because it results in ping-ponging between
/// the main state transition and the "special" state logic.
///
/// Since checking whether a state is special by doing three different
/// checks would be too expensive inside a fast search loop, the
/// [`Automaton::is_special`] method is provided for quickly checking whether
/// the state is special. The `Automaton::is_dead`, `Automaton::is_match` and
/// `Automaton::is_start` predicates can then be used to determine which kind
/// of special state it is.
///
/// # Panics
///
/// Most of the APIs on this trait should panic or give incorrect results
/// if invalid inputs are given to it. For example, `Automaton::next_state`
/// has unspecified behavior if the state ID given to it is not a valid
/// state ID for the underlying automaton. Valid state IDs can only be
/// retrieved in one of two ways: calling `Automaton::start_state` or calling
/// `Automaton::next_state` with a valid state ID.
///
/// # Safety
///
/// This trait is not safe to implement so that code may rely on the
/// correctness of implementations of this trait to avoid undefined behavior.
/// The primary correctness guarantees are:
///
/// * `Automaton::start_state` always returns a valid state ID or an error or
/// panics.
/// * `Automaton::next_state`, when given a valid state ID, always returns
/// a valid state ID for all values of `anchored` and `byte`, or otherwise
/// panics.
///
/// In general, the rest of the methods on `Automaton` need to uphold their
/// contracts as well. For example, `Automaton::is_dead` should only returns
/// true if the given state ID is actually a dead state.
///
/// Note that currently this crate does not rely on the safety property defined
/// here to avoid undefined behavior. Instead, this was done to make it
/// _possible_ to do in the future.
///
/// # Example
///
/// This example shows how one might implement a basic but correct search
/// routine. We keep things simple by not using prefilters or worrying about
/// anchored searches, but do make sure our search is correct for all possible
/// [`MatchKind`] semantics. (The comments in the code below note the parts
/// that are needed to support certain `MatchKind` semantics.)
///
/// ```
/// use aho_corasick::{
///     automaton::Automaton,
///     nfa::noncontiguous::NFA,
///     Anchored, Match, MatchError, MatchKind,
/// };
///
/// // Run an unanchored search for 'aut' in 'haystack'. Return the first match
/// // seen according to the automaton's match semantics. This returns an error
/// // if the given automaton does not support unanchored searches.
/// fn find<A: Automaton>(
///     aut: A,
///     haystack: &[u8],
/// ) -> Result<Option<Match>, MatchError> {
///     let mut sid = aut.start_state(Anchored::No)?;
///     let mut at = 0;
///     let mut mat = None;
///     let get_match = |sid, at| {
///         let pid = aut.match_pattern(sid, 0);
///         let len = aut.pattern_len(pid);
///         Match::new(pid, (at - len)..at)
///     };
///     // Start states can be match states!
///     if aut.is_match(sid) {
///         mat = Some(get_match(sid, at));
///         // Standard semantics require matches to be reported as soon as
///         // they're seen. Otherwise, we continue until we see a dead state
///         // or the end of the haystack.
///         if matches!(aut.match_kind(), MatchKind::Standard) {
///             return Ok(mat);
///         }
///     }
///     while at < haystack.len() {
///         sid = aut.next_state(Anchored::No, sid, haystack[at]);
///         if aut.is_special(sid) {
///             if aut.is_dead(sid) {
///                 return Ok(mat);
///             } else if aut.is_match(sid) {
///                 mat = Some(get_match(sid, at + 1));
///                 // As above, standard semantics require that we return
///                 // immediately once a match is found.
///                 if matches!(aut.match_kind(), MatchKind::Standard) {
///                     return Ok(mat);
///                 }
///             }
///         }
///         at += 1;
///     }
///     Ok(mat)
/// }
///
/// // Show that it works for standard searches.
/// let nfa = NFA::new(&["samwise", "sam"]).unwrap();
/// assert_eq!(Some(Match::must(1, 0..3)), find(&nfa, b"samwise")?);
///
/// // But also works when using leftmost-first. Notice how the match result
/// // has changed!
/// let nfa = NFA::builder()
///     .match_kind(MatchKind::LeftmostFirst)
///     .build(&["samwise", "sam"])
///     .unwrap();
/// assert_eq!(Some(Match::must(0, 0..7)), find(&nfa, b"samwise")?);
///
/// # Ok::<(), Box<dyn std::error::Error>>(())
/// ```
pub unsafe trait Automaton: private::Sealed {
    /// Returns the starting state for the given anchor mode.
    ///
    /// Upon success, the state ID returned is guaranteed to be valid for
    /// this automaton.
    ///
    /// # Errors
    ///
    /// This returns an error when the given search configuration is not
    /// supported by the underlying automaton. For example, if the underlying
    /// automaton only supports unanchored searches but the given configuration
    /// was set to an anchored search, then this must return an error.
    fn start_state(&self, anchored: Anchored) -> Result<StateID, MatchError>;

    /// Performs a state transition from `sid` for `byte` and returns the next
    /// state.
    ///
    /// `anchored` should be [`Anchored::Yes`] when executing an anchored
    /// search and [`Anchored::No`] otherwise. For some implementations of
    /// `Automaton`, it is required to know whether the search is anchored
    /// or not in order to avoid following failure transitions. Other
    /// implementations may ignore `anchored` altogether and depend on
    /// `Automaton::start_state` returning a state that walks a different path
    /// through the automaton depending on whether the search is anchored or
    /// not.
    ///
    /// # Panics
    ///
    /// This routine may panic or return incorrect results when the given state
    /// ID is invalid. A state ID is valid if and only if:
    ///
    /// 1. It came from a call to `Automaton::start_state`, or
    /// 2. It came from a previous call to `Automaton::next_state` with a
    /// valid state ID.
    ///
    /// Implementations must treat all possible values of `byte` as valid.
    ///
    /// Implementations may panic on unsupported values of `anchored`, but are
    /// not required to do so.
    fn next_state(
        &self,
        anchored: Anchored,
        sid: StateID,
        byte: u8,
    ) -> StateID;

    /// Returns true if the given ID represents a "special" state. A special
    /// state is a dead, match or start state.
    ///
    /// Note that implementations may choose to return false when the given ID
    /// corresponds to a start state. Namely, it always correct to treat start
    /// states as non-special. Implementations must return true for states that
    /// are dead or contain matches.
    ///
    /// This has unspecified behavior when given an invalid state ID.
    fn is_special(&self, sid: StateID) -> bool;

    /// Returns true if the given ID represents a dead state.
    ///
    /// A dead state is a type of "sink" in a finite state machine. It
    /// corresponds to a state whose transitions all loop back to itself. That
    /// is, once entered, it can never be left. In practice, it serves as a
    /// sentinel indicating that the search should terminate.
    ///
    /// This has unspecified behavior when given an invalid state ID.
    fn is_dead(&self, sid: StateID) -> bool;

    /// Returns true if the given ID represents a match state.
    ///
    /// A match state is always associated with one or more pattern IDs that
    /// matched at the position in the haystack when the match state was
    /// entered. When a match state is entered, the match semantics dictate
    /// whether it should be returned immediately (for `MatchKind::Standard`)
    /// or if the search should continue (for `MatchKind::LeftmostFirst` and
    /// `MatchKind::LeftmostLongest`) until a dead state is seen or the end of
    /// the haystack has been reached.
    ///
    /// This has unspecified behavior when given an invalid state ID.
    fn is_match(&self, sid: StateID) -> bool;

    /// Returns true if the given ID represents a start state.
    ///
    /// While it is never incorrect to ignore start states during a search
    /// (except for the start of the search of course), knowing whether one has
    /// entered a start state can be useful for certain classes of performance
    /// optimizations. For example, if one is in a start state, it may be legal
    /// to try to skip ahead and look for match candidates more quickly than
    /// would otherwise be accomplished by walking the automaton.
    ///
    /// Implementations of `Automaton` in this crate "unspecialize" start
    /// states when a prefilter is not active or enabled. In this case, it
    /// is possible for `Automaton::is_special(sid)` to return false while
    /// `Automaton::is_start(sid)` returns true.
    ///
    /// This has unspecified behavior when given an invalid state ID.
    fn is_start(&self, sid: StateID) -> bool;

    /// Returns the match semantics that this automaton was built with.
    fn match_kind(&self) -> MatchKind;

    /// Returns the total number of matches for the given state ID.
    ///
    /// This has unspecified behavior if the given ID does not refer to a match
    /// state.
    fn match_len(&self, sid: StateID) -> usize;

    /// Returns the pattern ID for the match state given by `sid` at the
    /// `index` given.
    ///
    /// Typically, `index` is only ever greater than `0` when implementing an
    /// overlapping search. Otherwise, it's likely that your search only cares
    /// about reporting the first pattern ID in a match state.
    ///
    /// This has unspecified behavior if the given ID does not refer to a match
    /// state, or if the index is greater than or equal to the total number of
    /// matches in this match state.
    fn match_pattern(&self, sid: StateID, index: usize) -> PatternID;

    /// Returns the total number of patterns compiled into this automaton.
    fn patterns_len(&self) -> usize;

    /// Returns the length of the pattern for the given ID.
    ///
    /// This has unspecified behavior when given an invalid pattern
    /// ID. A pattern ID is valid if and only if it is less than
    /// `Automaton::patterns_len`.
    fn pattern_len(&self, pid: PatternID) -> usize;

    /// Returns the length, in bytes, of the shortest pattern in this
    /// automaton.
    fn min_pattern_len(&self) -> usize;

    /// Returns the length, in bytes, of the longest pattern in this automaton.
    fn max_pattern_len(&self) -> usize;

    /// Returns the heap memory usage, in bytes, used by this automaton.
    fn memory_usage(&self) -> usize;

    /// Returns a prefilter, if available, that can be used to accelerate
    /// searches for this automaton.
    ///
    /// The typical way this is used is when the start state is entered during
    /// a search. When that happens, one can use a prefilter to skip ahead and
    /// look for candidate matches without having to walk the automaton on the
    /// bytes between candidates.
    ///
    /// Typically a prefilter is only available when there are a small (<100)
    /// number of patterns built into the automaton.
    fn prefilter(&self) -> Option<&Prefilter>;

    /// Executes a non-overlapping search with this automaton using the given
    /// configuration.
    ///
    /// See
    /// [`AhoCorasick::try_find`](crate::AhoCorasick::try_find)
    /// for more documentation and examples.
    fn try_find(
        &self,
        input: &Input<'_>,
    ) -> Result<Option<Match>, MatchError> {
        try_find_fwd(&self, input)
    }

    /// Executes a overlapping search with this automaton using the given
    /// configuration.
    ///
    /// See
    /// [`AhoCorasick::try_find_overlapping`](crate::AhoCorasick::try_find_overlapping)
    /// for more documentation and examples.
    fn try_find_overlapping(
        &self,
        input: &Input<'_>,
        state: &mut OverlappingState,
    ) -> Result<(), MatchError> {
        try_find_overlapping_fwd(&self, input, state)
    }

    /// Returns an iterator of non-overlapping matches with this automaton
    /// using the given configuration.
    ///
    /// See
    /// [`AhoCorasick::try_find_iter`](crate::AhoCorasick::try_find_iter)
    /// for more documentation and examples.
    fn try_find_iter<'a, 'h>(
        &'a self,
        input: Input<'h>,
    ) -> Result<FindIter<'a, 'h, Self>, MatchError>
    where
        Self: Sized,
    {
        FindIter::new(self, input)
    }

    /// Returns an iterator of overlapping matches with this automaton
    /// using the given configuration.
    ///
    /// See
    /// [`AhoCorasick::try_find_overlapping_iter`](crate::AhoCorasick::try_find_overlapping_iter)
    /// for more documentation and examples.
    fn try_find_overlapping_iter<'a, 'h>(
        &'a self,
        input: Input<'h>,
    ) -> Result<FindOverlappingIter<'a, 'h, Self>, MatchError>
    where
        Self: Sized,
    {
        if !self.match_kind().is_standard() {
            return Err(MatchError::unsupported_overlapping(
                self.match_kind(),
            ));
        }
        //  We might consider lifting this restriction. The reason why I added
        // it was to ban the combination of "anchored search" and "overlapping
        // iteration." The match semantics aren't totally clear in that case.
        // Should we allow *any* matches that are adjacent to *any* previous
        // match? Or only following the most recent one? Or only matches
        // that start at the beginning of the search? We might also elect to
        // just keep this restriction in place, as callers should be able to
        // implement it themselves if they want to.
        if input.get_anchored().is_anchored() {
            return Err(MatchError::invalid_input_anchored());
        }
        let _ = self.start_state(input.get_anchored())?;
        let state = OverlappingState::start();
        Ok(FindOverlappingIter { aut: self, input, state })
    }

    /// Replaces all non-overlapping matches in `haystack` with
    /// strings from `replace_with` depending on the pattern that
    /// matched. The `replace_with` slice must have length equal to
    /// `Automaton::patterns_len`.
    ///
    /// See
    /// [`AhoCorasick::try_replace_all`](crate::AhoCorasick::try_replace_all)
    /// for more documentation and examples.
    fn try_replace_all<B>(
        &self,
        haystack: &str,
        replace_with: &[B],
    ) -> Result<String, MatchError>
    where
        Self: Sized,
        B: AsRef<str>,
    {
        assert_eq!(
            replace_with.len(),
            self.patterns_len(),
            "replace_all requires a replacement for every pattern \
             in the automaton"
        );
        let mut dst = String::with_capacity(haystack.len());
        self.try_replace_all_with(haystack, &mut dst, |mat, _, dst| {
            dst.push_str(replace_with[mat.pattern()].as_ref());
            true
        })?;
        Ok(dst)
    }

    /// Replaces all non-overlapping matches in `haystack` with
    /// strings from `replace_with` depending on the pattern that
    /// matched. The `replace_with` slice must have length equal to
    /// `Automaton::patterns_len`.
    ///
    /// See
    /// [`AhoCorasick::try_replace_all_bytes`](crate::AhoCorasick::try_replace_all_bytes)
    /// for more documentation and examples.
    fn try_replace_all_bytes<B>(
        &self,
        haystack: &[u8],
        replace_with: &[B],
    ) -> Result<Vec<u8>, MatchError>
    where
        Self: Sized,
        B: AsRef<[u8]>,
    {
        assert_eq!(
            replace_with.len(),
            self.patterns_len(),
            "replace_all requires a replacement for every pattern \
             in the automaton"
        );
        let mut dst = Vec::with_capacity(haystack.len());
        self.try_replace_all_with_bytes(haystack, &mut dst, |mat, _, dst| {
            dst.extend(replace_with[mat.pattern()].as_ref());
            true
        })?;
        Ok(dst)
    }

    /// Replaces all non-overlapping matches in `haystack` by calling the
    /// `replace_with` closure given.
    ///
    /// See
    /// [`AhoCorasick::try_replace_all_with`](crate::AhoCorasick::try_replace_all_with)
    /// for more documentation and examples.
    fn try_replace_all_with<F>(
        &self,
        haystack: &str,
        dst: &mut String,
        mut replace_with: F,
    ) -> Result<(), MatchError>
    where
        Self: Sized,
        F: FnMut(&Match, &str, &mut String) -> bool,
    {
        let mut last_match = 0;
        for m in self.try_find_iter(Input::new(haystack))? {
            // Since there are no restrictions on what kinds of patterns are
            // in an Aho-Corasick automaton, we might get matches that split
            // a codepoint, or even matches of a partial codepoint. When that
            // happens, we just skip the match.
            if !haystack.is_char_boundary(m.start())
                || !haystack.is_char_boundary(m.end())
            {
                continue;
            }
            dst.push_str(&haystack[last_match..m.start()]);
            last_match = m.end();
            if !replace_with(&m, &haystack[m.start()..m.end()], dst) {
                break;
            };
        }
        dst.push_str(&haystack[last_match..]);
        Ok(())
    }

    /// Replaces all non-overlapping matches in `haystack` by calling the
    /// `replace_with` closure given.
    ///
    /// See
    /// [`AhoCorasick::try_replace_all_with_bytes`](crate::AhoCorasick::try_replace_all_with_bytes)
    /// for more documentation and examples.
    fn try_replace_all_with_bytes<F>(
        &self,
        haystack: &[u8],
        dst: &mut Vec<u8>,
        mut replace_with: F,
    ) -> Result<(), MatchError>
    where
        Self: Sized,
        F: FnMut(&Match, &[u8], &mut Vec<u8>) -> bool,
    {
        let mut last_match = 0;
        for m in self.try_find_iter(Input::new(haystack))? {
            dst.extend(&haystack[last_match..m.start()]);
            last_match = m.end();
            if !replace_with(&m, &haystack[m.start()..m.end()], dst) {
                break;
            };
        }
        dst.extend(&haystack[last_match..]);
        Ok(())
    }

    /// Returns an iterator of non-overlapping matches with this automaton
    /// from the stream given.
    ///
    /// See
    /// [`AhoCorasick::try_stream_find_iter`](crate::AhoCorasick::try_stream_find_iter)
    /// for more documentation and examples.
    #[cfg(feature = "std")]
    fn try_stream_find_iter<'a, R: std::io::Read>(
        &'a self,
        rdr: R,
    ) -> Result<StreamFindIter<'a, Self, R>, MatchError>
    where
        Self: Sized,
    {
        Ok(StreamFindIter { it: StreamChunkIter::new(self, rdr)? })
    }

    /// Replaces all non-overlapping matches in `rdr` with strings from
    /// `replace_with` depending on the pattern that matched, and writes the
    /// result to `wtr`. The `replace_with` slice must have length equal to
    /// `Automaton::patterns_len`.
    ///
    /// See
    /// [`AhoCorasick::try_stream_replace_all`](crate::AhoCorasick::try_stream_replace_all)
    /// for more documentation and examples.
    #[cfg(feature = "std")]
    fn try_stream_replace_all<R, W, B>(
        &self,
        rdr: R,
        wtr: W,
        replace_with: &[B],
    ) -> std::io::Result<()>
    where
        Self: Sized,
        R: std::io::Read,
        W: std::io::Write,
        B: AsRef<[u8]>,
    {
        assert_eq!(
            replace_with.len(),
            self.patterns_len(),
            "streaming replace_all requires a replacement for every pattern \
             in the automaton",
        );
        self.try_stream_replace_all_with(rdr, wtr, |mat, _, wtr| {
            wtr.write_all(replace_with[mat.pattern()].as_ref())
        })
    }

    /// Replaces all non-overlapping matches in `rdr` by calling the
    /// `replace_with` closure given and writing the result to `wtr`.
    ///
    /// See
    /// [`AhoCorasick::try_stream_replace_all_with`](crate::AhoCorasick::try_stream_replace_all_with)
    /// for more documentation and examples.
    #[cfg(feature = "std")]
    fn try_stream_replace_all_with<R, W, F>(
        &self,
        rdr: R,
        mut wtr: W,
        mut replace_with: F,
    ) -> std::io::Result<()>
    where
        Self: Sized,
        R: std::io::Read,
        W: std::io::Write,
        F: FnMut(&Match, &[u8], &mut W) -> std::io::Result<()>,
    {
        let mut it = StreamChunkIter::new(self, rdr).map_err(|e| {
            let kind = std::io::ErrorKind::Other;
            std::io::Error::new(kind, e)
        })?;
        while let Some(result) = it.next() {
            let chunk = result?;
            match chunk {
                StreamChunk::NonMatch { bytes, .. } => {
                    wtr.write_all(bytes)?;
                }
                StreamChunk::Match { bytes, mat } => {
                    replace_with(&mat, bytes, &mut wtr)?;
                }
            }
        }
        Ok(())
    }
}

// SAFETY: This just defers to the underlying 'AcAutomaton' and thus inherits
// its safety properties.
unsafe impl<'a, A: Automaton + ?Sized> Automaton for &'a A {
    #[inline(always)]
    fn start_state(&self, anchored: Anchored) -> Result<StateID, MatchError> {
        (**self).start_state(anchored)
    }

    #[inline(always)]
    fn next_state(
        &self,
        anchored: Anchored,
        sid: StateID,
        byte: u8,
    ) -> StateID {
        (**self).next_state(anchored, sid, byte)
    }

    #[inline(always)]
    fn is_special(&self, sid: StateID) -> bool {
        (**self).is_special(sid)
    }

    #[inline(always)]
    fn is_dead(&self, sid: StateID) -> bool {
        (**self).is_dead(sid)
    }

    #[inline(always)]
    fn is_match(&self, sid: StateID) -> bool {
        (**self).is_match(sid)
    }

    #[inline(always)]
    fn is_start(&self, sid: StateID) -> bool {
        (**self).is_start(sid)
    }

    #[inline(always)]
    fn match_kind(&self) -> MatchKind {
        (**self).match_kind()
    }

    #[inline(always)]
    fn match_len(&self, sid: StateID) -> usize {
        (**self).match_len(sid)
    }

    #[inline(always)]
    fn match_pattern(&self, sid: StateID, index: usize) -> PatternID {
        (**self).match_pattern(sid, index)
    }

    #[inline(always)]
    fn patterns_len(&self) -> usize {
        (**self).patterns_len()
    }

    #[inline(always)]
    fn pattern_len(&self, pid: PatternID) -> usize {
        (**self).pattern_len(pid)
    }

    #[inline(always)]
    fn min_pattern_len(&self) -> usize {
        (**self).min_pattern_len()
    }

    #[inline(always)]
    fn max_pattern_len(&self) -> usize {
        (**self).max_pattern_len()
    }

    #[inline(always)]
    fn memory_usage(&self) -> usize {
        (**self).memory_usage()
    }

    #[inline(always)]
    fn prefilter(&self) -> Option<&Prefilter> {
        (**self).prefilter()
    }
}

/// Represents the current state of an overlapping search.
///
/// This is used for overlapping searches since they need to know something
/// about the previous search. For example, when multiple patterns match at the
/// same position, this state tracks the last reported pattern so that the next
/// search knows whether to report another matching pattern or continue with
/// the search at the next position. Additionally, it also tracks which state
/// the last search call terminated in and the current offset of the search
/// in the haystack.
///
/// This type provides limited introspection capabilities. The only thing a
/// caller can do is construct it and pass it around to permit search routines
/// to use it to track state, and to ask whether a match has been found.
///
/// Callers should always provide a fresh state constructed via
/// [`OverlappingState::start`] when starting a new search. That same state
/// should be reused for subsequent searches on the same `Input`. The state
/// given will advance through the haystack itself. Callers can detect the end
/// of a search when neither an error nor a match is returned.
///
/// # Example
///
/// This example shows how to manually iterate over all overlapping matches. If
/// you need this, you might consider using
/// [`AhoCorasick::find_overlapping_iter`](crate::AhoCorasick::find_overlapping_iter)
/// instead, but this shows how to correctly use an `OverlappingState`.
///
/// ```
/// use aho_corasick::{
///     automaton::OverlappingState,
///     AhoCorasick, Input, Match,
/// };
///
/// let patterns = &["append", "appendage", "app"];
/// let haystack = "append the app to the appendage";
///
/// let ac = AhoCorasick::new(patterns).unwrap();
/// let mut state = OverlappingState::start();
/// let mut matches = vec![];
///
/// loop {
///     ac.find_overlapping(haystack, &mut state);
///     let mat = match state.get_match() {
///         None => break,
///         Some(mat) => mat,
///     };
///     matches.push(mat);
/// }
/// let expected = vec![
///     Match::must(2, 0..3),
///     Match::must(0, 0..6),
///     Match::must(2, 11..14),
///     Match::must(2, 22..25),
///     Match::must(0, 22..28),
///     Match::must(1, 22..31),
/// ];
/// assert_eq!(expected, matches);
/// ```
#[derive(Clone, Debug)]
pub struct OverlappingState {
    /// The match reported by the most recent overlapping search to use this
    /// state.
    ///
    /// If a search does not find any matches, then it is expected to clear
    /// this value.
    mat: Option<Match>,
    /// The state ID of the state at which the search was in when the call
    /// terminated. When this is a match state, `last_match` must be set to a
    /// non-None value.
    ///
    /// A `None` value indicates the start state of the corresponding
    /// automaton. We cannot use the actual ID, since any one automaton may
    /// have many start states, and which one is in use depends on search-time
    /// factors (such as whether the search is anchored or not).
    id: Option<StateID>,
    /// The position of the search.
    ///
    /// When `id` is None (i.e., we are starting a search), this is set to
    /// the beginning of the search as given by the caller regardless of its
    /// current value. Subsequent calls to an overlapping search pick up at
    /// this offset.
    at: usize,
    /// The index into the matching patterns of the next match to report if the
    /// current state is a match state. Note that this may be 1 greater than
    /// the total number of matches to report for the current match state. (In
    /// which case, no more matches should be reported at the current position
    /// and the search should advance to the next position.)
    next_match_index: Option<usize>,
}

impl OverlappingState {
    /// Create a new overlapping state that begins at the start state.
    pub fn start() -> OverlappingState {
        OverlappingState { mat: None, id: None, at: 0, next_match_index: None }
    }

    /// Return the match result of the most recent search to execute with this
    /// state.
    ///
    /// Every search will clear this result automatically, such that if no
    /// match is found, this will always correctly report `None`.
    pub fn get_match(&self) -> Option<Match> {
        self.mat
    }
}

/// An iterator of non-overlapping matches in a particular haystack.
///
/// This iterator yields matches according to the [`MatchKind`] used by this
/// automaton.
///
/// This iterator is constructed via the [`Automaton::try_find_iter`] method.
///
/// The type variable `A` refers to the implementation of the [`Automaton`]
/// trait used to execute the search.
///
/// The lifetime `'a` refers to the lifetime of the [`Automaton`]
/// implementation.
///
/// The lifetime `'h` refers to the lifetime of the haystack being searched.
#[derive(Debug)]
pub struct FindIter<'a, 'h, A> {
    /// The automaton used to drive the search.
    aut: &'a A,
    /// The input parameters to give to each search call.
    ///
    /// The start position of the search is mutated during iteration.
    input: Input<'h>,
    /// Records the end offset of the most recent match. This is necessary to
    /// handle a corner case for preventing empty matches from overlapping with
    /// the ending bounds of a prior match.
    last_match_end: Option<usize>,
}

impl<'a, 'h, A: Automaton> FindIter<'a, 'h, A> {
    /// Creates a new non-overlapping iterator. If the given automaton would
    /// return an error on a search with the given input configuration, then
    /// that error is returned here.
    fn new(
        aut: &'a A,
        input: Input<'h>,
    ) -> Result<FindIter<'a, 'h, A>, MatchError> {
        // The only way this search can fail is if we cannot retrieve the start
        // state. e.g., Asking for an anchored search when only unanchored
        // searches are supported.
        let _ = aut.start_state(input.get_anchored())?;
        Ok(FindIter { aut, input, last_match_end: None })
    }

    /// Executes a search and returns a match if one is found.
    ///
    /// This does not advance the input forward. It just executes a search
    /// based on the current configuration/offsets.
    fn search(&self) -> Option<Match> {
        // The unwrap is OK here because we check at iterator construction time
        // that no subsequent search call (using the same configuration) will
        // ever return an error.
        self.aut
            .try_find(&self.input)
            .expect("already checked that no match error can occur")
    }

    /// Handles the special case of an empty match by ensuring that 1) the
    /// iterator always advances and 2) empty matches never overlap with other
    /// matches.
    ///
    /// (1) is necessary because we principally make progress by setting the
    /// starting location of the next search to the ending location of the last
    /// match. But if a match is empty, then this results in a search that does
    /// not advance and thus does not terminate.
    ///
    /// (2) is not strictly necessary, but makes intuitive sense and matches
    /// the presiding behavior of most general purpose regex engines.
    /// (Obviously this crate isn't a regex engine, but we choose to match
    /// their semantics.) The "intuitive sense" here is that we want to report
    /// NON-overlapping matches. So for example, given the patterns 'a' and
    /// '' (an empty string) against the haystack 'a', without the special
    /// handling, you'd get the matches [0, 1) and [1, 1), where the latter
    /// overlaps with the end bounds of the former.
    ///
    /// Note that we mark this cold and forcefully prevent inlining because
    /// handling empty matches like this is extremely rare and does require
    /// quite a bit of code, comparatively. Keeping this code out of the main
    /// iterator function keeps it smaller and more amenable to inlining
    /// itself.
    #[cold]
    #[inline(never)]
    fn handle_overlapping_empty_match(
        &mut self,
        mut m: Match,
    ) -> Option<Match> {
        assert!(m.is_empty());
        if Some(m.end()) == self.last_match_end {
            self.input.set_start(self.input.start().checked_add(1).unwrap());
            m = self.search()?;
        }
        Some(m)
    }
}

rid
//lf.last_maiV(        m      Ok(dst)
    }

    /// Replaces allOk(dst)
o the endi  //Dysst_maiV(  s 'a' and
    ///ate = Oveecked_add(1).unwrap());
    mat -> Option< Some(m.end()) eecked_ad #[cold]
    #[inline(never)]
 mwrap());
            m== self.last_match_ensert!(m.         in the));
        if =    assert!(m.;        m = self.search()?n<Match> {
        .mat
    }
}

/// An iterator of non-overlapping matches in a partict if the next
    /// Imp

/// An iterator of non-overlap..28),splitched at the pohoulmat
  atchKind`] used by this
/// automaton.
///
///ensive inside a fa/
    /// See
    /// [`Aho via the [`Automaton::try_find_iter`] method.
///
/// The type variable `A` refers to the implementation of the [`Automaton`]
/// trait used to execute the search.
///
/// The lifetime `'a` refers to the lifetime of the [`Automaton`]
/// implementation.
///
/// The lifetime `'h` refers to the lifetime of the haystack being searcnput: Input<'h>,
    ) -       m s returned here. fn new(
        aut: ,
     e aho_corasick::{
()?;
        }
        Some(m)
    }
}

rid
//lnput: Input<'h>,
    ) -       m      Ok(dst)
    }

    /// Replaces allOk(dst)
o the endi  //Dysst_maiV(  s 'a' and
    ///    // ever return an error.
 ec![];
///
//      self.,ndle_overl.y_find_over          .try_find(&self.input)
            .expect("already eir s".         in the&mut state);
/// .search()?n<Match> {
          the nesp

/// An iter  #[cfping matches in a particular haelifetir
        `FnMut(&Matcs 'a' `u'd get aton's match tch. ch casepatterrn in ing woitemonsie sen matches 

// SAFETY  #[cfping e the  {
        /// no  ///
 ched at t

// SAFETY  #[cf end ofs `EOF`atchKind`] used by this
/// automaton.
///
/// This iterator is   /// See
    /// ind`]via the [`Automaton::try_find_iter`] method.
///
/// The type variable `A` refers to the implementation of the [`Automaton`]
/// trait use:try_find_iter`R method.
///
///`        `Y  #[cf lear tsefers tnsie
ping mat
/// trait used to execute the search.
///
/// The lifetime `'a` refers to the lifetime of tmore documentation and etime of the haystack being self,
        rdr: RA  ) and
   d,
    {
        Okdr: RA  ) {
()?more documentation and eits
// its safety prostd")]
    fn try_s)
    }
}

       elf,
        rdr: RA  ) 
    m      Ok(dst)  F: FnMut(&Matcs 'a' }

    )
o the endi  //Dysst_maiV(    F: FnMut(&Matcs 'a'  and
    ///a/ let ) {
            le     s?;
        while let So = match sta config   Ov.write_all(bytes)?= se).isn's)) sta config?= se).isn's))v.write_all(bytes)?= see
        match chunk {
       )) sta{}.write_all(bytes)?= see
        match nk {
    {
      )) sta{
h_kind(), MatchKind::Standa?= see
 m//    eplace_with(&mat, bytes, &mut wtr)?;
         ch()?n<Match> {
          the nesp

/// An iter  #[cfping match(tch if onnes.
   //
///allers sh
///`
    }
}`plementes.
    is as nonding ting searcvious c/
/// The atcd of
haviorbute`  is owpoin:find_a ///OKe of lly ma if hn ing`
   `]via th// itsed by this-causeen The sthe sftype)ing matches in a particular haelifetir
        `FnMut(&Matc       matc `u'd geting tonnput configuch casepatterrn in ing woitemonsie sen matches 

// SAFET lly ma#[cfpe the  {
        /// no  ///
 ched at t

// SAFETY  #[cf end ofs];
///EOF`atchKind`] uhe deaeir semantics. /// t chun    /// Retdetect te. A speciption<mgState,
/// itsfappin au.
   statee shone` val chuarchmentat without    odu.
    
course) // o reetir
    es with t    (*-   -  (*atchKind`] usedt chuns a typryo repoare ly thacstatee itstngines.erminate.s of `an
ck::try_er  #[cfto the l       jus  the nesp

/// Ang locweam_r all ing searches scause
     'h,e aut, where "   "streami" API, the cu allsf
    /// `iin and l chuarself. Tcopyn may
    /sel allsf
     "str tmore documentation and etime of the haystbeing self,
        Okdr: RA  ) ebug)]
pub strution is not
    /// chored`
    /// The automaton used to drive thesource lifto walove, adg mat
/ll_with<R, W, F>
    /ro shbute`     ///naghis co wals in `hd andBe aparch wton.
    /// is in a sta match. begin    }

nto the ear tseautoms accwostate` retns of the s
    //`hd ., ad()`e end offnes.erminate. allasepate shwe. allasemost recentdo in ithe nex   /// If:finerrn i//
   your searcl chuar   selfssary, but makesnecessary, ee itse search isdte tra,love, a/
//jus  ly way  stateourverlapping m[cftorrect .mat
    }
}blocuar   co waf the for oves constroch one is i advances::newove, sa  /// Re::start_state`, o`r   `Y     i()
    }
/ll_wbut: AhoCoraua i/// te` ::B te` ,ug)]
pub struti       // ivate::Sealed     eto accelerate
     ivat      anchored:s value.
    m    es accelerate
             anchored:pub strucbsol [`Aarch call.veongest`)) //   #[cfpi autobsol [`_arcick up at
    /// thiarch callwe'rexecutes /
  emantiRepl/ t`
/ll_wbute` _arcick up at
    /// thibute`  arch call.
    /nput: ing a ylementatwovesame poration is in a starbeginningndBe aparch wchedlwayswe
    //essary,love prefhat etate regex enginrpecial" ate` recelk the aud get the of matchertatee it pattern IDs one is i  next seara ylewove, sation,starbeginningndIatterrn'ial" ate` rece, regex enginnhwe. allible for `Aa 'chunk {
'cl chu
/ll_wbute` _guch cas_arcick up at()?more documentation and eits
// its safety prostd")]
    fn try_s)elf,
        Okdr: RA  ) ebug)]
/// that error is returned here.
   io::Read>(
        &'a self,
        Okdr: RA  ) {
    ) -> Result<FindIter<'aalso elect to
  sy if:rry .matner caslarchmatsutomatonse regex eics aren't toI" adnes. sincng a e iwidt/ startinkut`. The ng_iter match, say,cs aren't toltmostFi-ly car  /ltmostFi-Returns t: usizeIf:fi.   ch semanticscs aren't to  /// Im?pub str    woitemomantics.oop bppin etaatch state was
ncs aren't toltmostFi-ly carbut we chlappinly '  jus  stope a neasearinto for exaen't tothe nexte endingYpin sincnoe mighgoe::S   ///ppindetect hller`Matcil is if we cannor  /EOFeportng_idteppin  /// `Anwithoif hller`Matc canno stall,cs aren't toppindo ' f t, whof patterns ,oI"bel searppinly  
   a latte jusiail is if we e itsay, "oop bt to track state,tmos,withoif  allibles
    /// Th aail is if we es
  Na ylem"ud get N=rchen(&self) -> usizeics aren't til is if we W    /sssftypIf:finity, th)
 anecent oneely nce tsearch-twe'rexma ifcs aren't tolprethe start`MatchKind::ether t allsf
  patsuss.
 rory bute` r exaen't tothf ifaf t   /// it of cof onnes., a/
// matchis do, th)  ///rvscs aren't to*roch* oneely  rory bute` othf ifa,rd. tween che special casor if the gi if we cpan state.
   i()
    }
/ll_w       lrchen(elf: Sized,
    {
        if !self.match_kind().is_standard() {
            #[cf(rchen(elf: Sized      self.match_kind(),
end offs, rdr }

ncop-of.,n:finnt inlining be
   SUPER y was noics aren't toIhe on  /// usedly '   codep (w    /ssswtatwoveen /// nerrn)ch with thetriction. / (2) c/
o, comlogic mll cs/allerf t, whcent oaID {I'casdep  in place, as        te a bit orent sly thi allibledeftypaton' aping
      stariail is if we ly cais doin / iteration." The  isneswtatwch semantidte a new se we check at icom/// `re,tateI" ecilasemo jus  brs sho/rve
   ics aren't til is if we Iat the tmombecausea this
weiTh in   bles      n. W.
 f t s
    ///ail is if we cam[cftsfappi'rexjus  goe::S &'aeasor if te a place_aern IDs?cs aren't til is if we ¯\_(ツ)_/¯/ll_w       rchen(&self) -> usizeis_e0  if !self.match_kind().is_standard() {
          Option<Match> {
  }f.start_state(inrtsearches are supporte(
    h ch aut.start_statelf,
        Ok  if !self.matc_ancif !self.matchdrcif !self.matcbut: AhoCoraua i/// te` ::B te` endagerchen(&self) -> usizert_eq!(
         aret_eq!(
              aret_eq!(
       obsol [`_arcic0cif !self.matcbute` _arcic0cif !self.matcbute` _guch cas_arcic0cif !self.r { aut, input)
o the endi  //Dysst_maiV(    F: FnMut(&Matc       matc esult<FindIter<'aalsof coih)  /tinlgnar ///IatIScs/aller/// st   /nquivales a sdwe check at ithe curstate`, oaf pppingStach_ Ths
    /atorhes.
    //// Replil is if we e    /// chramatsal  get atdt the   /atorhes.
    /// sincabue.
  dn place, as         start    /// antics.o reakinds nt inlelf) ->ics aren't til is if we I   
/// // it of coc   /// wmadly rare s/aller/ acdesigntrospel is if we k t Ok bute` oobsmit of the seaen't til is if we  locan   /// t,// it of cotsef. tween cs, ..-///
eportithoif  alle check at it&'aout`. The re step-by-stepit&'aroiven. On m    es ksedbiir
  e check at ily thexityo remit sWhen `fewstate` ret / based  'bute` _arc' ig the most rewerrn i//
   the curbute`     /ngState:'bute` _guch cas_arc'omantiscs aren't to  /n IDs t  /// wheth* previous
   seara ylewthe curbute`  matches of a  rewe'vve, sation,starbeginningndAtdt'obsol [`_arc'omantisl.veoaifcs aren't toecutes acbsol [`Aarch call.
    ///
    /nngest`)) //   #[cf,o for exaen't toton.
   wlace_with cpans/
   your sate
//   /r
  .d
    ///a/ let ) {
               // e: StateID)  the&id    while let So = mpping(hays  thetate);
///   eplace_with(&mat   (kind, e)
)ays  thetatenon       l chu      {
h_kind(), MatchKind:  thebute` _guch cas_arc += r asser;
h_kind(), MatchKind:(kin yleme=e(alwaebutebute` ()[r];
h_kind(), MatchKind::Standa?= see
        match chunk {
          ))                wtr.write_all(bytes)  the&id_anchored());; while let So = mppinrays  thetate);
// l chu     ;
nd(), MatchKind:  thebute` _guch cas_arc += r asser;
h_kind(), MatchK(kin yleme=e(alwaebutebute` ()[r];
h_kind(), MatchK:Standa?= see
        match       }
            ))              } ) {
               /bute` _arc >= alwaebutebute` () asser {
h_kind(), MatchK   (kind, e)
)ays  thetatesta_ro senon       l chu   {
h_kind(), MatchKind:  thebute` _guch cas_arc += r asser;
h_kind(), MatchKind:(kin yleme=e(alwaebutebute` ()[r];
h_kind(), MatchKind::Standa?= see
        match chunk {
          ))                wtr.write_all(bytes)       /butebute` () asser >= alwaebuten(&sbute` _asser {
h_kind(), MatchKind:  thebute` _arc = alwaebuten(&sbute` _asser;
h_kind(), MatchKind:  thebute` _guch cas_arc -=
h_kind(), MatchKind:ind:  thebutebute` () asser - alwaebuten(&sbute` _asser;
h_kind(), MatchKind:  thebut.ro s()                wtr.write_all(bytes)    le     but.f if endi  //D. mut {
h_kind(), MatchKind:).isn's) sta config?= se).isn's))v.write_all(bytes)rt_statat.p) sta{}.write_all(bytes)rt_statf the) sta{
h_kind(), MatchKind: if we We'vvehlleEOFIf:finifew(haystackma if roch one nd(), MatchKind: if we unOverlappingtes litr  `re,tr_match_inm  //. one nd(), MatchKind: if    (kind, e)
)ays  thetateeofenon       l chu   {
h_kind(), MatchKind:tchKind:  thebute` _guch cas_arc += r asser;
h_kind(), MatchKind:tchKind:(kin yleme=e(alwaebutebute` ()[r];
h_kind(), MatchKind:tchKind::Standa?= see
        match chunk {
          ))                wt      wtr.write_all(bytes)ind: if we We'vveOverlappiplacesearc!
nd(), MatchKind:tchKind::Standa   O                wt    } eplace_with(&mat, bytes, &mut wtr)?;
   rt_state(inrtsea    //bsol [`_arc              'a, A ylewthealwaebutebute` ()[  thebute` _arc..]. = 0;  {
h_kind(), MatchK  the&id_anchore/ e:
    ) -> Ste(
    h ch,K  the&id    (**;
nd(), MatchKind:  the/bsol [`_arc += 1;.write_all(bytes)       // e: StateID)  the&id    while let So = mtart()..m.end()], dst) &mat, bytes, &mut wtr)?;
   rt_s  thebute` _arc +ea    //bsol [`_arc - a());; while le None, at: 0, next_matcha     let chunhe totaloverla endingIr tseassumt)
     the of mat: 0, next sta, no more match`bute` _arc` on the ctate);
// l chu #[inlinngStank {
ysst_ppioraopsMutangeior matand
    ///ate (inrtsea    /bute` _arc -nngS asser;
h_kind()///  ndsea    /bute` _arc;

         are.ert!None, at: 0, next_matcha selfssaryet chu> usi
    ///
  jus  brfo   your searca
    /// the/er<'aalso   }

 // non-ifew(hayss not he::S &'your s. Ow(hawise,he most recentassumts
     the overla endixt sta, no more match`bute` _arc` on the ctatenon       l chu  #[inline(always)]
    fngStank {
      &mut self,
 ppioraopsMutangeior mattand
    ///ate bute` _ngS_(inrtsea    /bute` _arc -nngS asser;
h_kind()ifebute` _ngS_(inrts>:  thebute` _guch cas_arc {tr)?;
   rt_state(inrtsea    /bute` _guch cas_arc;tr)?;
   rt_state ndseabute` _ngS_(inrt;
ind:tchKind::Standa?= se  are.ert!Match> {
  }f.start_s/ noNone, at: 0, nexLprefstart
ya ylementatw
    /// which case,sha selfssaryejus  brfo  terator. Ioon-overlaabute` aps with the end bounds of tverlapnch is fousa ylemeupit&'`bute`  asser -ch to the (&sbute` _ass`/ jusi ///er t  /// Imp
    /// `arch-time
 ylemorasick::trprevious
  eman
   tor oip was
n te. A specier  on the ctatesta_ro senon       l chu configuration/offppioraopsMutangeior mattand
    ///ate  ndse
tchKind:ind:  thebutebute` () asser.sumenasear_sub(alwaebuten(&sbute` _asserr;
h_kind()ife  thebute` _guch cas_arc <  if Some(m.end()) :Standa?= se  thebute` _guch cas_arc.ert!Match> {
  }f.start_s/ noNone, at: 0, next_matchany unOverlappingtes ,sha selfssaryeup starting lt: ing a ute` aps with the end bT_overla  //pnch beginnind ched at tse) // o reetir
    es bute`   sinut forwardate,tmthe li atdtEOFack state,hlleched arye::S &'f ifing a ute` aps wie ctateeofenon       l chu configuration/offppioraopsMutangeior mattand
    ///ife  thebute` _guch cas_arc < alwaebutebute` () asser {
h_kind(), Ma:Standa?= se  thebute` _guch cas_arc.ealwaebutebute` () asserMatch> {
  }f.start_s/ noNone, at: 0, next_matchthe of mat, no more matches shoulthe total number  search to execute withT_ovepan    ife`    // e: StateID)  the&id `offnes.at.p on the ctate);
//  #[inline(alway {
h_kind()tate);
//     // e,K  the&id  0,a    //bsol [`_arc .search()?n<Mattomaglval chucular ppingStatecam[cftl chuc   /// CrtchKind`] uhe`'r`/
/// The he search.
///
/// The lifetimcam[cftl chuc   /// Crtmore documentation and etime of the haystenum)elf,
      <'r ebug)]
pub Atl chucempty, th/er to reakindsyches never ovechunk {
        eturr io:: },ug)]
pub Atl chucemptystaciseon." reakisca
    /// thenk {
        eturr io::inngStank {
 },u()?mong
    /// itsepub(AhoCo)ples.
  ee
  fwd<s safety properties.
u(e automatond here. fn new&(
     _>,
       &'a so clear
    //
    ) -> Result<Fi themselv Sta noer {
h_kind():Standae
 / noMatch> }f.staate  arliestsearchen(elf: Sized,
    {
       ||hemselves i arliester;
h_ki themselves if they want to.
        if input.ge.
  ee
  fwd_imp(_anchored())   Ovete(
    h Y     arliest .searc el   i  (kind, e)sta)searcheption<&Prefand
    ///ife arliests{eplace_with[mat  ee
  fwd_imp(_anchored())d, e)sta)vete(
    h ch,Kat.p)tch> {
  } el   {eplace_with[mat  ee
  fwd_imp(_anchored())d, e)sta)vete(
    h ch,Kf the) while le None,  el   {eplace_wiife arliests{eplace_with[mat  ee
  fwd_imp(_anchored())   Ovete(
    h ch,Kat.p)tch> {
  } el   {eplace_with[mat  ee
  fwd_imp(_anchored())   Ovete(
    h ch,Kf the) while le None, u()?mong
    ces allOkles.
  ee
  fwd_imp<s safety properties.
u(e automatond here. fn new&(
     _>,
will re:e(always)]
    fn p,
willn next_state(
        &s arliest:FnMut(&       &'a so clear
    //
    ) -> Result<Fiorasick::id_anrches are supported.
        let _ = aut.staorasick:(hays           seut.staorasick:g(hays   O         rche StateID) ->  {eplace_wig(haysd, e)tate);
// / e,K id  0,a//    eplace_wife arliests{eplace_with[m:Standae
     ;
nd(), Ma}tch> }f.stai  (kind, e)sta)seasta {eplace_wig(hbseqres = veinrted.
 e `'h` rmut ted.
     cpan(m.i{eplace_with[mC{
 idoCoraatch sta confige
 / noM,eplace_with[mC{
 idoCoraMr)]
 mw sta confige
  = selfM,eplace_with[mC{
 idoCoraP /// ImS    OfMr)]
 i) sta{
h_kind(), MatchK(hays ; bytes, &mut wtr)?;
         chError::new(ha< ted.
 rt!(msult<FindIter<I'vveis sd unOoon-overlovea/ lewith)li from overla.inpu If:finnin place, as mlf) - wlaceI" ad,oI"c   //er tob//rvs

nconsusswe mamfouners shonil is if we e h be  lformeI"c   //deviseto rf rochtch he "sf
    -provg{
    is,r exaen't totoeA>, Maisdtearch daviodi at '
    ) -> _un.input)']via th/ch.
//r exaen't to'his just delementious c/defa /// nextemptyusth/'
    ) -> 'pe thnil is if we     '/ e:
    ) -> _un.input)'] get atdt/allers shis on DFA/// youind: if we un.input)
 resuls offsacceve)   &self,
  _anrche
    ) -> StateID {
      ted.
 e `'h` rmu[at]   eplace_wiferche StateID) -> boet ) {
           rche StateID) ->a{
h_kind(), MatchK:Standae
     ;
nd(), Masearc el   i  rche StateID) ->  {eplace_wiind: if we We     '/tper1'<Match> {
    the of matche to res se an anchoredl is if we ets
   seara ylewlifetimelf) ->iput::newe     half-sdep anchoredl is if we i se val If a ng lt: ing arange comparatif the ltch pand
    anchoredl is if we seara yle. while let So = mpping_antate);
// / e,K id  0,a//per1*;
nd(), MatchKind:we Fe totalt    //a /nnge regex e      ausea ays)]lem codff
nd(), MatchKind:we werrn i//earchthat no suaafe impl<'a, bous c      // for exaen'tind: if we un       // statewaf the a tsearcherla
    /// (1, beca/allyr exaen'tind: if we te.
 rprevious    entalemn shoulsor::newly tu `replacehe la exaen'tind: if we cannot Iorasick:The on      &'f  it patthe
  tx e     :Stand anchoredl is if we e`MatchKind:, the cuiutomatos    ///
    blestop.h(tch  anchoredl is if we isor:y/'
    ) -> 'u allsf
    /// `arch-time
    /// f anchoredl is if we etors (such as .) Ioiodile patt/// sinctate` ret an fail is if ind: if we cannosfstart
     // fo un       // statewaf The matcheack  anchoredl is if we e`    -a/ led get as  /// overly, th/er . anchoredl is if we anchoredl is if we Innge reway,  only  rchthat no suis sn of the [`Abous anchoredl is if we etors (su fo un       // statewaf Therpecial"co the e The.eplace_wiind: if we Whed buil fromds of patterns are
      fstaring for an anchoredanchored search whe,  onlopyne a corner caof matche tsf
  /// seche ts anchoredanchored se(w    /wa  //pw(hawise te.
be of matche ts)-ifew(hyestrictions on when't toth a _iter///
as    entalemn shoul. Inngeegin    }

n anchoredl is if we etors (suarch w,  on*ateIDftween *am_r otThe "intuitive senseoredl is if we gees the pohou> {
    theyn    /// Rater than
ent one seaearch tooredl is if we geea search), this is set t. anchoredl is if we anchoredl is if we N/// coc   //tweak  es accelerat rochng_itertate` ret/ wh anchoredl is if we etors (suer caun       //of matche tsk::find_ovewa  // aus anchoredl is if we 'rche StateIDdeferspotret/ en c'rche StateID) '
 rowngndAtd anchoredl is if we ethe  ause es accelerat nd morteratoly thex. anchoredl is if we anchoredl is if we Inrasick://// ,
   e`  occur"hytes<iftime
    /// f anchoredl is if we etors (sk:///a/ally ignh state. (Inempty, nes. sear aail is if l is if we geeaone sethis is set t. end offseotTremely dealt sly thil is if l is if we m_r  occurys)]lnd oode out otheands oA>, Matptyung for an anchoredanchored search whey, nes.paythe totcial// the se brg fof t  l most recenoredanchored seg match
    a///
    bleo report   fstarerato// stiail is if l is if we pw(hawise o clmeen csa  /ch atan
  be match st// st    anchoredl is if we seturns s whetheent for every paf The th sulthe totd offil is if l is if we geatwoveenallinweam_nes. rprevs    entalemn shoulsort pos anchoredl is if we et etors (suarch w. Combiion,ious   // tactate` ret g for an anchoredanchored seaivate::Sealed ious or c   -a/ lk:///guaemnteds of the'ifcs aren'tl is if we etswo carmovput`. The ay be 1 grealemn shoulsoreplace_t    anchoredl is if we seturns s wheth. anchoredl is if we anchoredl is if we N///he tDFA If a nwhoiousrintothis imch daviehaysn wh anchoredl is if we     entalemn shoulsose) ///
eportw(hayss notA>, Maiss, M"if
nd(), MatchKind:we i ///t
        // state.m_nes. rprevs    entalemn shouls." anchoredl is if we Inrasick:///
   //
// sincnoebuil ccwosse) ///
/ suire
h anchoredl is if we e    /// anet.
    alemn shoul t_ite. On mious     entil is if l is if we gemn shoulsobuiltnet.
 ing a
/t
/// se ear tseete`c
    /il is if l is if we jus  ds nncodh), this isbn   bs snet.
 aalemn shoul t_ite.il is if l is if we DFA kma if  all over  // Th e The,h> {
    the of matche ts anchoredanchored seaistate:rrythe pohoulnch is a _iter///
as    entalemn shoul.eplace_wiind: if we Why? B {
    remov`replacm tmombetate of e,Kal e The Ieplace_wiind: if we  sinnes.return t c/
o, com e The . anchoredl is if    lStateID {t to.
        i&& m      se >s           se    while let So = mtartg(haysd, e)m)                wt    ife arliests{eplace_with[mnd(), MatchK:Standae
     ;
nd(), Masear  wt    } eplace_with(&mat, bytes, &mut w el   i  (kind, e)sta)seasta {eplace_wis aren't toIhe o'rex(hay,e on  ///i ///t`  occur"e {
    ///ffseotTail is if l is if we match/ of a seare {
  ANDal casorption<&Precialc
   f Thus,
nd(), MatchKind:we i n this isa overlapping stateeeeeeeeeeeeede ha_ch,
    rche StateID) -> *;
nd(), MatchKind:we Weam_nes.cmpty nce t'C{
 idoCoraMr)]
'<Match> {
    ife ucs anchoredl is if we e a searwatch  /// Imch ataa  // sinctate,, sation, ncve
nd(), MatchKind:we wernhwe.ruhe curstaon<&Prebrfo   walk`replaceaccelerate
    r)?;
   rt_state(pan ysdpan::er c(at..ted.
 rt!(m*;
nd(), MatchKind:g(hbseqres = veinrted.
 e `'h` rmut (pan).et.
_o clea   {
h_kind(), MatchKind:atch sta confige
 / noM,eplace_with[ml(bytes)?= sei) sta{
h_kind(), MatchKind: if  the >sat {
h_kind(), MatchKind:tchKind:(hays ; bytes, &mut                 o report                wt      wtr.write_all(bytes)ind:} eplace_with(&mat, bytes, &mut w el   {eplace_wiind: if we Whed qres Stn noer   /// aivate::Sealedverla  //te.
beil is if l is if we geeacase,sh  occure::starerlaty strinorption<&Pr,)
    }

   anchoredanchored seala  //pnch r_match_rrt ahed at ttch to repomatch/ of a seaa exaen'tind: if we cannot anchoredl is if we anchoredl is if we I//ffs  /// Imp
   the [`Aton would
   trinorption<&Pr,spli
nd(), MatchKind:we wernhat t

// SAFETY  the l  ck s no: et etors (suarch w.
nd(), MatchKind:we  locan  bit orent  es accelerat / (2) i// ne /// Imp
  mcve
nd(), MatchKind:we b` re.
    a    /// A `Nby OK here beca, search tk:///ahng iteraten'tind: if we t same ca /// it brg fofstateeeeeeeeeeeeede ha_ch,
    f the, "unOv a _ite"); bytes, &mut wtr)?;
             //pe= 1;.writ      e
     u()?mong
    /// itseles.
  ee
   See
    ///fwd<s safety properties.
u(e automatond here. fn new&(
     _>,
ut: ,
     endi e aho_corasick::{
       &'a ser      ) -> Result<Ficannotg(hays   O         emselv Sta noer {
h_kind():Standae
 (m*;
nd()}ug)]
pu Srch warcvious c/s whetheID state.
   tateID {
  o:///ahng i/pnch // i
 if we     orption<&Pr,s can o/s whetheID staretur.        rcheption<&Prefe Sta= se i&& !emselves if they want to.
        if input.gerasicntatircheption<&Prefe let ac = e_with[mat  ee
   See
    ///fwd_imp(_anchored())d, e)sta)vey_find_overw el   {eplace_wiat  ee
   See
    ///fwd_imp(_anchored())   Ovey_find_overwu()?mong
    ces allOkles.
  ee
   See
    ///fwd_imp<s safety properties.
u(e automatond here. fn new&(
     _>,
will re:e(always)]
    fn p,
will,
     endi e aho_corasick::{
       &'a ser      ) -> Result<Fiorasick::id_anof matches tif Some(m.endatch sta{tr)?;
   rt_state(id_anrches are supported.
        let _ = aut.staind: if we Hmatch. begin   d get the     /// A `N report if the
   :starerl
 if l is if we geea the patternhave maourrt state of thethe nexplace_a searwa
 if l is if we ly  Match> fo   mov`repo/// thupdasear 'the
  atdefers'ches tif'
 if l is if we g&'f  itch state. (In mao// se tors lifetime `'h` r. ) {
           rche StateID) ->  {eplace_wiind: if tateist)  es tgState { mat: Noe let a_or(0r;
h_kind(), MatchK(kinlensearchen(elf:asse -> ;.write_all(bytes)   i <nlens{
h_kind(), MatchKind:  es tgState { mat: Noaysd, e)iper1*;
nd(), MatchKind:t<Ficannotg(haysd, e)tate);
// / e,K id  i,s           se );
h_kind(), MatchKind::Standae
 (m*;
nd()], dst) &mat, bytes, &mut wtr)?;
   rt_s he
  atays           seut.sta
   rt_s he
  if =    as -> ;.write_all(by  es tgState { mat: Noays   O              cannotg(hays   O        &self,
  p());
            m = se ->  sta{tr)?;
   rt_s toIhe onma if hnvstate. (Inltmoe matching pnterns match ahli
nd(), MatchK tothe nexlacm    ///we'vveexh
  ot fiacm. On/
  ft se ear do ia
 if l is if we sition
    /// and t: Inputthe current offsetchKind: if    (kind, e)i)st)  es tgState { mat: No {eplace_wiind: if tatelensearchen(elf:asse -> ;.write_all(bytes)   i <nlens{
h_kind(), MatchKind:  es tgState { mat: Noaysd, e)iper1*;
nd(), MatchKind:t<Ficannotg(haysd, e)tate);
// / e,K id  i,s he
  ataer1*);
h_kind(), MatchKind::Standae
 (m*;
nd()], dst) &mat, bytes, &mut  if we O::newe'vveOverlappi    ining be
inorreturnes shoul, thi allil is if l is if we go found.
    /   /// startinand the search
, MatchKind:t<Ficannot//pe= 1;.writwrite_all(by  es tgState { mat: Noays   O                  cannotg(hays   O        &self,}       &self,
  p());
         };hError::newcannot//p< ted.
 rt!(msult<FindIt
  _anrche
    ) -> SetchKind: if  ed.
        let _ =t_eq!(
          ,etchKind: if  ed.
 e `'h` rmu[cannot//],etchKind:   eplace_wiferche StateID) -> boet ) {
         he
  if =    as -> ;.write_all(by   rche StateID) ->a{
h_kind(), MatchK:Standae
 (m*;
nd()], dst) c el   i  rche StateID) ->  {eplace_wiind: if   es tgState { mat: Noaysd, e)1*;
nd(), MatchKind:cannotg(haysd, e)tate);
// / e,K id  0,s he
  ataer1*);
h_kind(), MatchK:Standae
 (m*;
nd()], dst) c el   i  (kind, e)sta)seasta {eplace_wis aren't toIhe o'rex(hay,e on  ///i ///t`  occur"e {
    ///ffseotTail is if l is if we match/ of a seare {
  ANDal casorption<&Precialc
   f Thus,
nd(), MatchKind:we i n this isa overlapping stateeeeeeeeeeeeede ha_ch,
    rche StateID) -> *;
nd(), MatchKind:tate(pan ysdpan::er c( he
  at..ted.
 rt!(m*;
nd(), MatchKind:g(hbseqres = veinrted.
 e `'h` rmut (pan).et.
_o clea   {
h_kind(), MatchKind:atch sta confige
 ()M,eplace_with[ml(bytes)?= sei) sta{
h_kind(), MatchKind: if  the >s he
  ata{
h_kind(), MatchKind:tchKind: he
  atays ; bytes, &mut                 o report                wt      wtr.write_all(bytes)ind:} eplace_with(&mat, bytes, &mut w el   {eplace_wiind: if we Whed qres Stn noer   /// aivate::Sealedverla  //te.
beil is if l is if we geeacase,sh  occure::starerlaty strinorption<&Pr,)
    }

   anchoredanchored seala  //pnch r_match_rrt ahed at ttch to repomatch/ of a seaa exaen'tind: if we cannot anchoredl is if we anchoredl is if we .   excep  startch n occur")
  :othea #[cfto the `re,tthil is if l is if we ecutes /
      urrent value. Subseious c/'chue'rption<&Pr,ictions on when't toth the search  `arch-ttch exisrs lh as ,h> {
    a #[cf anchoredanchored search wearcly '  ecutes /
 ,e aut, whption<&Pr  /// match in anchoredl is if we elr")
  s. bytes, &mut wtr)?;
             cannot//pe= 1;.writ}
     he
  if =    as -> ;.write
 ()Mu()?mong
    ces allOklestate);
//<s safety properties.
u(e automatond here.         anchored:t: Nonek up at
    pick up atline(alway {
h_kirasic  _anrchee { mas wheth(     te Noeut.staoraslensearcheelf) -> usizp-> ;.writalwayendagep    (//p-slen)..   u()? posirmely rptionxion   a" te e.
 
}

ridfmt::he hat/alls. Iat t.
   s, ..s];
//exaatch cwos
   t_itea ylemeno the overla ovelf) -rtchKind`]SteIDftween ,// it bs ss bles ccinatch disrearuiswhere tate` ret     r
  ecent sears:`MatchKind:s, overlappingssnecessaryappings. Iatsplit///
u "sff match  patter// Impurrent valuarch tate` ret an tse:trys.h(tc, 'h, Ater// Im
is i advancpernhavetics.of of mat,nd overlappings.)epub(AhoCo)plesfmt ) -> _te e.
 
}<s safety prou(e autf  endi ppiorafmt::Fovelf) -  _>,
willomatod here.        anchoysst_ppiorafmt::  &'a sult<Fi thrche StateID->  {eplace_wis, ..!(f, "D " aut.stac el   i  rche StateID)->  {eplace_wiiferche StateID)->  {eplace_wiind:s, ..!(f, "*>"wrap());
     el   {eplace_wiind:s, ..!(f, "* "wrap());
         c el   i  rche StateID)->  {eplace_wis, ..!(f, " >" aut.stac el   {eplace_wis, ..!(f, "  " aut.stac.write
 ()Mu()? next_matchanh> {
        gemn shoulso iter parcessarg(hanew nonnh> {
    
is i  nelr"exthaci /
 ,efiion,lemn shouls.e the  {
     ular haranger
  ecentlemn shouls will clear e h adjaRecorgemn shoulsomcoden,starbegno secent searstackcombiion,et.
 aaomaglvarange.epub(AhoCo)ples parce_gemn shouls<'au(e autmfinit:/ next
    }
}<Ok(dst)(u8,     anc)>per'ahoysst_ next
    }
}<Ok(dst)(u8, u8,     anc)>per'asult<Fiorasick:ecu:e(always(u8, u8,     anc)>pys   O      ppiora  {
::er c_fn(movpu|| {eplace_wis::new(kind, e)(clch,,nand )) s s?;
        while let So(kin)stavtateID,rstat  if,rstat and )_anof matdy e{.write_all(bytes)?= sex) stax, while let So = match sta{
h_kind(), MatchKind:dy e=nd, e)(clch,,nclch,,nand ))                wt    o report                wt, bytes, &mut w;.write_all(by   stat and is_eand i{
h_kind(), MatchKdy e=nd, e)(stavtateID,rclch,,nstat and )*;
nd()], dst) c el   {
h_kind(), MatchKdy e=nd, e)(clch,,nclch,,nand ))                wt:Standa?= se)stavtateID,rstat  if,rstat and )); bytes, &mut wtr)?;
             i  (kind, e)(ateID,r if,rand )) s dy .takeer {
h_kind(), Ma:Standa?= se(ateID,r if,rand ))atch> {
  }f.start_s/ noNone, Mu()                                     