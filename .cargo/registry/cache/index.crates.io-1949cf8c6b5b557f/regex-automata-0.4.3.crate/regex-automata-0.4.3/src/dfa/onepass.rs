/*!
A DFA that can return spans for matching capturing groups.

This module is the home of a [one-pass DFA](DFA).

This module also contains a [`Builder`] and a [`Config`] for building and
configuring a one-pass DFA.
*/

// A note on naming and credit:
//
// As far as I know, Russ Cox came up with the practical vision and
// implementation of a "one-pass regex engine." He mentions and describes it
// briefly in the third article of his regexp article series:
// https://swtch.com/~rsc/regexp/regexp3.html
//
// Cox's implementation is in RE2, and the implementation below is most
// heavily inspired by RE2's. The key thing they have in common is that
// their transitions are defined over an alphabet of bytes. In contrast,
// Go's regex engine also has a one-pass engine, but its transitions are
// more firmly rooted on Unicode codepoints. The ideas are the same, but the
// implementations are different.
//
// RE2 tends to call this a "one-pass NFA." Here, we call it a "one-pass DFA."
// They're both true in their own ways:
//
// * The "one-pass" criterion is generally a property of the NFA itself. In
// particular, it is said that an NFA is one-pass if, after each byte of input
// during a search, there is at most one "VM thread" remaining to take for the
// next byte of input. That is, there is never any ambiguity as to the path to
// take through the NFA during a search.
//
// * On the other hand, once a one-pass NFA has its representation converted
// to something where a constant number of instructions is used for each byte
// of input, the implementation looks a lot more like a DFA. It's technically
// more powerful than a DFA since it has side effects (storing offsets inside
// of slots activated by a transition), but it is far closer to a DFA than an
// NFA simulation.
//
// Thus, in this crate, we call it a one-pass DFA.

use alloc::{vec, vec::Vec};

use crate::{
    dfa::{remapper::Remapper, DEAD},
    nfa::thompson::{self, NFA},
    util::{
        alphabet::ByteClasses,
        captures::Captures,
        escape::DebugByte,
        int::{Usize, U32, U64, U8},
        look::{Look, LookSet, UnicodeWordBoundaryError},
        primitives::{NonMaxUsize, PatternID, StateID},
        search::{Anchored, Input, Match, MatchError, MatchKind, Span},
        sparse_set::SparseSet,
    },
};

/// The configuration used for building a [one-pass DFA](DFA).
///
/// A one-pass DFA configuration is a simple data object that is typically used
/// with [`Builder::configure`]. It can be cheaply cloned.
///
/// A default configuration can be created either with `Config::new`, or
/// perhaps more conveniently, with [`DFA::config`].
#[derive(Clone, Debug, Default)]
pub struct Config {
    match_kind: Option<MatchKind>,
    starts_for_each_pattern: Option<bool>,
    byte_classes: Option<bool>,
    size_limit: Option<Option<usize>>,
}

impl Config {
    /// Return a new default one-pass DFA configuration.
    pub fn new() -> Config {
        Config::default()
    }

    /// Set the desired match semantics.
    ///
    /// The default is [`MatchKind::LeftmostFirst`], which corresponds to the
    /// match semantics of Perl-like regex engines. That is, when multiple
    /// patterns would match at the same leftmost position, the pattern that
    /// appears first in the concrete syntax is chosen.
    ///
    /// Currently, the only other kind of match semantics supported is
    /// [`MatchKind::All`]. This corresponds to "classical DFA" construction
    /// where all possible matches are visited.
    ///
    /// When it comes to the one-pass DFA, it is rarer for preference order and
    /// "longest match" to actually disagree. Since if they did disagree, then
    /// the regex typically isn't one-pass. For example, searching `Samwise`
    /// for `Sam|Samwise` will report `Sam` for leftmost-first matching and
    /// `Samwise` for "longest match" or "all" matching. However, this regex is
    /// not one-pass if taken literally. The equivalent regex, `Sam(?:|wise)`
    /// is one-pass and `Sam|Samwise` may be optimized to it.
    ///
    /// The other main difference is that "all" match semantics don't support
    /// non-greedy matches. "All" match semantics always try to match as much
    /// as possible.
    pub fn match_kind(mut self, kind: MatchKind) -> Config {
        self.match_kind = Some(kind);
        self
    }

    /// Whether to compile a separate start state for each pattern in the
    /// one-pass DFA.
    ///
    /// When enabled, a separate **anchored** start state is added for each
    /// pattern in the DFA. When this start state is used, then the DFA will
    /// only search for matches for the pattern specified, even if there are
    /// other patterns in the DFA.
    ///
    /// The main downside of this option is that it can potentially increase
    /// the size of the DFA and/or increase the time it takes to build the DFA.
    ///
    /// You might want to enable this option when you want to both search for
    /// anchored matches of any pattern or to search for anchored matches of
    /// one particular pattern while using the same DFA. (Otherwise, you would
    /// need to compile a new DFA for each pattern.)
    ///
    /// By default this is disabled.
    ///
    /// # Example
    ///
    /// This example shows how to build a multi-regex and then search for
    /// matches for a any of the patterns or matches for a specific pattern.
    ///
    /// ```
    /// use regex_automata::{
    ///     dfa::onepass::DFA, Anchored, Input, Match, PatternID,
    /// };
    ///
    /// let re = DFA::builder()
    ///     .configure(DFA::config().starts_for_each_pattern(true))
    ///     .build_many(&["[a-z]+", "[0-9]+"])?;
    /// let (mut cache, mut caps) = (re.create_cache(), re.create_captures());
    /// let haystack = "123abc";
    /// let input = Input::new(haystack).anchored(Anchored::Yes);
    ///
    /// // A normal multi-pattern search will show pattern 1 matches.
    /// re.try_search(&mut cache, &input, &mut caps)?;
    /// assert_eq!(Some(Match::must(1, 0..3)), caps.get_match());
    ///
    /// // If we only want to report pattern 0 matches, then we'll get no
    /// // match here.
    /// let input = input.anchored(Anchored::Pattern(PatternID::must(0)));
    /// re.try_search(&mut cache, &input, &mut caps)?;
    /// assert_eq!(None, caps.get_match());
    ///
    /// # Ok::<(), Box<dyn std::error::Error>>(())
    /// ```
    pub fn starts_for_each_pattern(mut self, yes: bool) -> Config {
        self.starts_for_each_pattern = Some(yes);
        self
    }

    /// Whether to attempt to shrink the size of the DFA's alphabet or not.
    ///
    /// This option is enabled by default and should never be disabled unless
    /// one is debugging a one-pass DFA.
    ///
    /// When enabled, the DFA will use a map from all possible bytes to their
    /// corresponding equivalence class. Each equivalence class represents a
    /// set of bytes that does not discriminate between a match and a non-match
    /// in the DFA. For example, the pattern `[ab]+` has at least two
    /// equivalence classes: a set containing `a` and `b` and a set containing
    /// every byte except for `a` and `b`. `a` and `b` are in the same
    /// equivalence class because they never discriminate between a match and a
    /// non-match.
    ///
    /// The advantage of this map is that the size of the transition table
    /// can be reduced drastically from (approximately) `#states * 256 *
    /// sizeof(StateID)` to `#states * k * sizeof(StateID)` where `k` is the
    /// number of equivalence classes (rounded up to the nearest power of 2).
    /// As a result, total space usage can decrease substantially. Moreover,
    /// since a smaller alphabet is used, DFA compilation becomes faster as
    /// well.
    ///
    /// **WARNING:** This is only useful for debugging DFAs. Disabling this
    /// does not yield any speed advantages. Namely, even when this is
    /// disabled, a byte class map is still used while searching. The only
    /// difference is that every byte will be forced into its own distinct
    /// equivalence class. This is useful for debugging the actual generated
    /// transitions because it lets one see the transitions defined on actual
    /// bytes instead of the equivalence classes.
    pub fn byte_classes(mut self, yes: bool) -> Config {
        self.byte_classes = Some(yes);
        self
    }

    /// Set a size limit on the total heap used by a one-pass DFA.
    ///
    /// This size limit is expressed in bytes and is applied during
    /// construction of a one-pass DFA. If the DFA's heap usage exceeds
    /// this configured limit, then construction is stopped and an error is
    /// returned.
    ///
    /// The default is no limit.
    ///
    /// # Example
    ///
    /// This example shows a one-pass DFA that fails to build because of
    /// a configured size limit. This particular example also serves as a
    /// cautionary tale demonstrating just how big DFAs with large Unicode
    /// character classes can get.
    ///
    /// ```
    /// # if cfg!(miri) { return Ok(()); } // miri takes too long
    /// use regex_automata::{dfa::onepass::DFA, Match};
    ///
    /// // 6MB isn't enough!
    /// DFA::builder()
    ///     .configure(DFA::config().size_limit(Some(6_000_000)))
    ///     .build(r"\w{20}")
    ///     .unwrap_err();
    ///
    /// // ... but 7MB probably is!
    /// // (Note that DFA sizes aren't necessarily stable between releases.)
    /// let re = DFA::builder()
    ///     .configure(DFA::config().size_limit(Some(7_000_000)))
    ///     .build(r"\w{20}")?;
    /// let (mut cache, mut caps) = (re.create_cache(), re.create_captures());
    /// let haystack = "A".repeat(20);
    /// re.captures(&mut cache, &haystack, &mut caps);
    /// assert_eq!(Some(Match::must(0, 0..20)), caps.get_match());
    ///
    /// # Ok::<(), Box<dyn std::error::Error>>(())
    /// ```
    ///
    /// While one needs a little more than 3MB to represent `\w{20}`, it
    /// turns out that you only need a little more than 4KB to represent
    /// `(?-u:\w{20})`. So only use Unicode if you need it!
    pub fn size_limit(mut self, limit: Option<usize>) -> Config {
        self.size_limit = Some(limit);
        self
    }

    /// Returns the match semantics set in this configuration.
    pub fn get_match_kind(&self) -> MatchKind {
        self.match_kind.unwrap_or(MatchKind::LeftmostFirst)
    }

    /// Returns whether this configuration has enabled anchored starting states
    /// for every pattern in the DFA.
    pub fn get_starts_for_each_pattern(&self) -> bool {
        self.starts_for_each_pattern.unwrap_or(false)
    }

    /// Returns whether this configuration has enabled byte classes or not.
    /// This is typically a debugging oriented option, as disabling it confers
    /// no speed benefit.
    pub fn get_byte_classes(&self) -> bool {
        self.byte_classes.unwrap_or(true)
    }

    /// Returns the DFA size limit of this configuration if one was set.
    /// The size limit is total number of bytes on the heap that a DFA is
    /// permitted to use. If the DFA exceeds this limit during construction,
    /// then construction is stopped and an error is returned.
    pub fn get_size_limit(&self) -> Option<usize> {
        self.size_limit.unwrap_or(None)
    }

    /// Overwrite the default configuration such that the options in `o` are
    /// always used. If an option in `o` is not set, then the corresponding
    /// option in `self` is used. If it's not set in `self` either, then it
    /// remains not set.
    pub(crate) fn overwrite(&self, o: Config) -> Config {
        Config {
            match_kind: o.match_kind.or(self.match_kind),
            starts_for_each_pattern: o
                .starts_for_each_pattern
                .or(self.starts_for_each_pattern),
            byte_classes: o.byte_classes.or(self.byte_classes),
            size_limit: o.size_limit.or(self.size_limit),
        }
    }
}

/// A builder for a [one-pass DFA](DFA).
///
/// This builder permits configuring options for the syntax of a pattern, the
/// NFA construction and the DFA construction. This builder is different from a
/// general purpose regex builder in that it permits fine grain configuration
/// of the construction process. The trade off for this is complexity, and
/// the possibility of setting a configuration that might not make sense. For
/// example, there are two different UTF-8 modes:
///
/// * [`syntax::Config::utf8`](crate::util::syntax::Config::utf8) controls
/// whether the pattern itself can contain sub-expressions that match invalid
/// UTF-8.
/// * [`thompson::Config::utf8`] controls whether empty matches that split a
/// Unicode codepoint are reported or not.
///
/// Generally speaking, callers will want to either enable all of these or
/// disable all of these.
///
/// # Example
///
/// This example shows how to disable UTF-8 mode in the syntax and the NFA.
/// This is generally what you want for matching on arbitrary bytes.
///
/// ```
/// # if cfg!(miri) { return Ok(()); } // miri takes too long
/// use regex_automata::{
///     dfa::onepass::DFA,
///     nfa::thompson,
///     util::syntax,
///     Match,
/// };
///
/// let re = DFA::builder()
///     .syntax(syntax::Config::new().utf8(false))
///     .thompson(thompson::Config::new().utf8(false))
///     .build(r"foo(?-u:[^b])ar.*")?;
/// let (mut cache, mut caps) = (re.create_cache(), re.create_captures());
///
/// let haystack = b"foo\xFFarzz\xE2\x98\xFF\n";
/// re.captures(&mut cache, haystack, &mut caps);
/// // Notice that `(?-u:[^b])` matches invalid UTF-8,
/// // but the subsequent `.*` does not! Disabling UTF-8
/// // on the syntax permits this.
/// //
/// // N.B. This example does not show the impact of
/// // disabling UTF-8 mode on a one-pass DFA Config,
/// //  since that only impacts regexes that can
/// // produce matches of length 0.
/// assert_eq!(Some(Match::must(0, 0..8)), caps.get_match());
///
/// # Ok::<(), Box<dyn std::error::Error>>(())
/// ```
#[derive(Clone, Debug)]
pub struct Builder {
    config: Config,
    #[cfg(feature = "syntax")]
    thompson: thompson::Compiler,
}

impl Builder {
    /// Create a new one-pass DFA builder with the default configuration.
    pub fn new() -> Builder {
        Builder {
            config: Config::default(),
            #[cfg(feature = "syntax")]
            thompson: thompson::Compiler::new(),
        }
    }

    /// Build a one-pass DFA from the given pattern.
    ///
    /// If there was a problem parsing or compiling the pattern, then an error
    /// is returned.
    #[cfg(feature = "syntax")]
    pub fn build(&self, pattern: &str) -> Result<DFA, BuildError> {
        self.build_many(&[pattern])
    }

    /// Build a one-pass DFA from the given patterns.
    ///
    /// When matches are returned, the pattern ID corresponds to the index of
    /// the pattern in the slice given.
    #[cfg(feature = "syntax")]
    pub fn build_many<P: AsRef<str>>(
        &self,
        patterns: &[P],
    ) -> Result<DFA, BuildError> {
        let nfa =
            self.thompson.build_many(patterns).map_err(BuildError::nfa)?;
        self.build_from_nfa(nfa)
    }

    /// Build a DFA from the given NFA.
    ///
    /// # Example
    ///
    /// This example shows how to build a DFA if you already have an NFA in
    /// hand.
    ///
    /// ```
    /// use regex_automata::{dfa::onepass::DFA, nfa::thompson::NFA, Match};
    ///
    /// // This shows how to set non-default options for building an NFA.
    /// let nfa = NFA::compiler()
    ///     .configure(NFA::config().shrink(true))
    ///     .build(r"[a-z0-9]+")?;
    /// let re = DFA::builder().build_from_nfa(nfa)?;
    /// let (mut cache, mut caps) = (re.create_cache(), re.create_captures());
    /// re.captures(&mut cache, "foo123bar", &mut caps);
    /// assert_eq!(Some(Match::must(0, 0..9)), caps.get_match());
    ///
    /// # Ok::<(), Box<dyn std::error::Error>>(())
    /// ```
    pub fn build_from_nfa(&self, nfa: NFA) -> Result<DFA, BuildError> {
        // Why take ownership if we're just going to pass a reference to the
        // NFA to our internal builder? Well, the first thing to note is that
        // an NFA uses reference counting internally, so either choice is going
        // to be cheap. So there isn't much cost either way.
        //
        // The real reason is that a one-pass DFA, semantically, shares
        // ownership of an NFA. This is unlike other DFAs that don't share
        // ownership of an NFA at all, primarily because they want to be
        // self-contained in order to support cheap (de)serialization.
        //
        // But then why pass a '&nfa' below if we want to share ownership?
        // Well, it turns out that using a '&NFA' in our internal builder
        // separates its lifetime from the DFA we're building, and this turns
        // out to make code a bit more composable. e.g., We can iterate over
        // things inside the NFA while borrowing the builder as mutable because
        // we know the NFA cannot be mutated. So TL;DR --- this weirdness is
        // "because borrow checker."
        InternalBuilder::new(self.config.clone(), &nfa).build()
    }

    /// Apply the given one-pass DFA configuration options to this builder.
    pub fn configure(&mut self, config: Config) -> &mut Builder {
        self.config = self.config.overwrite(config);
        self
    }

    /// Set the syntax configuration for this builder using
    /// [`syntax::Config`](crate::util::syntax::Config).
    ///
    /// This permits setting things like case insensitivity, Unicode and multi
    /// line mode.
    ///
    /// These settings only apply when constructing a one-pass DFA directly
    /// from a pattern.
    #[cfg(feature = "syntax")]
    pub fn syntax(
        &mut self,
        config: crate::util::syntax::Config,
    ) -> &mut Builder {
        self.thompson.syntax(config);
        self
    }

    /// Set the Thompson NFA configuration for this builder using
    /// [`nfa::thompson::Config`](crate::nfa::thompson::Config).
    ///
    /// This permits setting things like whether additional time should be
    /// spent shrinking the size of the NFA.
    ///
    /// These settings only apply when constructing a DFA directly from a
    /// pattern.
    #[cfg(feature = "syntax")]
    pub fn thompson(&mut self, config: thompson::Config) -> &mut Builder {
        self.thompson.configure(config);
        self
    }
}

/// An internal builder for encapsulating the state necessary to build a
/// one-pass DFA. Typical use is just `InternalBuilder::new(..).build()`.
///
/// There is no separate pass for determining whether the NFA is one-pass or
/// not. We just try to build the DFA. If during construction we discover that
/// it is not one-pass, we bail out. This is likely to lead to some undesirable
/// expense in some cases, so it might make sense to try an identify common
/// patterns in the NFA that make it definitively not one-pass. That way, we
/// can avoid ever trying to build a one-pass DFA in the first place. For
/// example, '\w*\s' is not one-pass, and since '\w' is Unicode-aware by
/// default, it's probably not a trivial cost to try and build a one-pass DFA
/// for it and then fail.
///
/// Note that some (immutable) fields are duplicated here. For example, the
/// 'nfa' and 'classes' fields are both in the 'DFA'. They are the same thing,
/// but we duplicate them because it makes composition easier below. Otherwise,
/// since the borrow checker can't see through method calls, the mutable borrow
/// we use to mutate the DFA winds up preventing borrowing from any other part
/// of the DFA, even though we aren't mutating those parts. We only do this
/// because the duplication is cheap.
#[derive(Debug)]
struct InternalBuilder<'a> {
    /// The DFA we're building.
    dfa: DFA,
    /// An unordered collection of NFA state IDs that we haven't yet tried to
    /// build into a DFA state yet.
    ///
    /// This collection does not ultimately wind up including every NFA state
    /// ID. Instead, each ID represents a "start" state for a sub-graph of the
    /// NFA. The set of NFA states we then use to build a DFA state consists
    /// of that "start" state and all states reachable from it via epsilon
    /// transitions.
    uncompiled_nfa_ids: Vec<StateID>,
    /// A map from NFA state ID to DFA state ID. This is useful for easily
    /// determining whether an NFA state has been used as a "starting" point
    /// to build a DFA state yet. If it hasn't, then it is mapped to DEAD,
    /// and since DEAD is specially added and never corresponds to any NFA
    /// state, it follows that a mapping to DEAD implies the NFA state has
    /// no corresponding DFA state yet.
    nfa_to_dfa_id: Vec<StateID>,
    /// A stack used to traverse the NFA states that make up a single DFA
    /// state. Traversal occurs until the stack is empty, and we only push to
    /// the stack when the state ID isn't in 'seen'. Actually, even more than
    /// that, if we try to push something on to this stack that is already in
    /// 'seen', then we bail out on construction completely, since it implies
    /// that the NFA is not one-pass.
    stack: Vec<(StateID, Epsilons)>,
    /// The set of NFA states that we've visited via 'stack'.
    seen: SparseSet,
    /// Whether a match NFA state has been observed while constructing a
    /// one-pass DFA state. Once a match state is seen, assuming we are using
    /// leftmost-first match semantics, then we don't add any more transitions
    /// to the DFA state we're building.
    matched: bool,
    /// The config passed to the builder.
    ///
    /// This is duplicated in dfa.config.
    config: Config,
    /// The NFA we're building a one-pass DFA from.
    ///
    /// This is duplicated in dfa.nfa.
    nfa: &'a NFA,
    /// The equivalence classes that make up the alphabet for this DFA>
    ///
    /// This is duplicated in dfa.classes.
    classes: ByteClasses,
}

impl<'a> InternalBuilder<'a> {
    /// Create a new builder with an initial empty DFA.
    fn new(config: Config, nfa: &'a NFA) -> InternalBuilder {
        let classes = if !config.get_byte_classes() {
            // A one-pass DFA will always use the equivalence class map, but
            // enabling this option is useful for debugging. Namely, this will
            // cause all transitions to be defined over their actual bytes
            // instead of an opaque equivalence class identifier. The former is
            // much easier to grok as a human.
            ByteClasses::singletons()
        } else {
            nfa.byte_classes().clone()
        };
        // Normally a DFA alphabet includes the EOI symbol, but we don't need
        // that in the one-pass DFA since we handle look-around explicitly
        // without encoding it into the DFA. Thus, we don't need to delay
        // matches by 1 byte. However, we reuse the space that *would* be used
        // by the EOI transition by putting match information there (like which
        // pattern matches and which look-around assertions need to hold). So
        // this means our real alphabet length is 1 fewer than what the byte
        // classes report, since we don't use EOI.
        let alphabet_len = classes.alphabet_len().checked_sub(1).unwrap();
        let stride2 = classes.stride2();
        let dfa = DFA {
            config: config.clone(),
            nfa: nfa.clone(),
            table: vec![],
            starts: vec![],
            // Since one-pass DFAs have a smaller state ID max than
            // StateID::MAX, it follows that StateID::MAX is a valid initial
            // value for min_match_id since no state ID can ever be greater
            // than it. In the case of a one-pass DFA with no match states, the
            // min_match_id will keep this sentinel value.
            min_match_id: StateID::MAX,
            classes: classes.clone(),
            alphabet_len,
            stride2,
            pateps_offset: alphabet_len,
            // OK because PatternID::MAX*2 is guaranteed not to overflow.
            explicit_slot_start: nfa.pattern_len().checked_mul(2).unwrap(),
        };
        InternalBuilder {
            dfa,
            uncompiled_nfa_ids: vec![],
            nfa_to_dfa_id: vec![DEAD; nfa.states().len()],
            stack: vec![],
            seen: SparseSet::new(nfa.states().len()),
            matched: false,
            config,
            nfa,
            classes,
        }
    }

    /// Build the DFA from the NFA given to this builder. If the NFA is not
    /// one-pass, then return an error. An error may also be returned if a
    /// particular limit is exceeded. (Some limits, like the total heap memory
    /// used, are configurable. Others, like the total patterns or slots, are
    /// hard-coded based on representational limitations.)
    fn build(mut self) -> Result<DFA, BuildError> {
        self.nfa.look_set_any().available().map_err(BuildError::word)?;
        for look in self.nfa.look_set_any().iter() {
            // This is a future incompatibility check where if we add any
            // more look-around assertions, then the one-pass DFA either
            // needs to reject them (what we do here) or it needs to have its
            // Transition representation modified to be capable of storing the
            // new assertions.
            if look.as_repr() > Look::WordUnicodeNegate.as_repr() {
                return Err(BuildError::unsupported_look(look));
            }
        }
        if self.nfa.pattern_len().as_u64() > PatternEpsilons::PATTERN_ID_LIMIT
        {
            return Err(BuildError::too_many_patterns(
                PatternEpsilons::PATTERN_ID_LIMIT,
            ));
        }
        if self.nfa.group_info().explicit_slot_len() > Slots::LIMIT {
            return Err(BuildError::not_one_pass(
                "too many explicit capturing groups (max is 16)",
            ));
        }
        assert_eq!(DEAD, self.add_empty_state()?);

        // This is where the explicit slots start. We care about this because
        // we only need to track explicit slots. The implicit slots---two for
        // each pattern---are tracked as part of the search routine itself.
        let explicit_slot_start = self.nfa.pattern_len() * 2;
        self.add_start_state(None, self.nfa.start_anchored())?;
        if self.config.get_starts_for_each_pattern() {
            for pid in self.nfa.patterns() {
                self.add_start_state(
                    Some(pid),
                    self.nfa.start_pattern(pid).unwrap(),
                )?;
            }
        }
        // NOTE: One wonders what the effects of treating 'uncompiled_nfa_ids'
        // as a stack are. It is really an unordered *set* of NFA state IDs.
        // If it, for example, in practice led to discovering whether a regex
        // was or wasn't one-pass later than if we processed NFA state IDs in
        // ascending order, then that would make this routine more costly in
        // the somewhat common case of a regex that isn't one-pass.
        while let Some(nfa_id) = self.uncompiled_nfa_ids.pop() {
            let dfa_id = self.nfa_to_dfa_id[nfa_id];
            // Once we see a match, we keep going, but don't add any new
            // transitions. Normally we'd just stop, but we have to keep
            // going in order to verify that our regex is actually one-pass.
            self.matched = false;
            // The NFA states we've already explored for this DFA state.
            self.seen.clear();
            // The NFA states to explore via epsilon transitions. If we ever
            // try to push an NFA state that we've already seen, then the NFA
            // is not one-pass because it implies there are multiple epsilon
            // transition paths that lead to the same NFA state. In other
            // words, there is ambiguity.
            self.stack_push(nfa_id, Epsilons::empty())?;
            while let Some((id, epsilons)) = self.stack.pop() {
                match *self.nfa.state(id) {
                    thompson::State::ByteRange { ref trans } => {
                        self.compile_transition(dfa_id, trans, epsilons)?;
                    }
                    thompson::State::Sparse(ref sparse) => {
                        for trans in sparse.transitions.iter() {
                            self.compile_transition(dfa_id, trans, epsilons)?;
                        }
                    }
                    thompson::State::Dense(ref dense) => {
                        for trans in dense.iter() {
                            self.compile_transition(dfa_id, &trans, epsilons)?;
                        }
                    }
                    thompson::State::Look { look, next } => {
                        let looks = epsilons.looks().insert(look);
                        self.stack_push(next, epsilons.set_looks(looks))?;
                    }
                    thompson::State::Union { ref alternates } => {
                        for &sid in alternates.iter().rev() {
                            self.stack_push(sid, epsilons)?;
                        }
                    }
                    thompson::State::BinaryUnion { alt1, alt2 } => {
                        self.stack_push(alt2, epsilons)?;
                        self.stack_push(alt1, epsilons)?;
                    }
                    thompson::State::Capture { next, slot, .. } => {
                        let slot = slot.as_usize();
                        let epsilons = if slot < explicit_slot_start {
                            // If this is an implicit slot, we don't care
                            // about it, since we handle implicit slots in
                            // the search routine. We can get away with that
                            // because there are 2 implicit slots for every
                            // pattern.
                            epsilons
                        } else {
                            // Offset our explicit slots so that they start
                            // at index 0.
                            let offset = slot - explicit_slot_start;
                            epsilons.set_slots(epsilons.slots().insert(offset))
                        };
                        self.stack_push(next, epsilons)?;
                    }
                    thompson::State::Fail => {
                        continue;
                    }
                    thompson::State::Match { pattern_id } => {
                        // If we found two different paths to a match state
                        // for the same DFA state, then we have ambiguity.
                        // Thus, it's not one-pass.
                        if self.matched {
                            return Err(BuildError::not_one_pass(
                                "multiple epsilon transitions to match state",
                            ));
                        }
                        self.matched = true;
                        // Shove the matching pattern ID and the 'epsilons'
                        // into the current DFA state's pattern epsilons. The
                        // 'epsilons' includes the slots we need to capture
                        // before reporting the match and also the conditional
                        // epsilon transitions we need to check before we can
                        // report a match.
                        self.dfa.set_pattern_epsilons(
                            dfa_id,
                            PatternEpsilons::empty()
                                .set_pattern_id(pattern_id)
                                .set_epsilons(epsilons),
                        );
                        // N.B. It is tempting to just bail out here when
                        // compiling a leftmost-first DFA, since we will never
                        // compile any more transitions in that case. But we
                        // actually need to keep going in order to verify that
                        // we actually have a one-pass regex. e.g., We might
                        // see more Match states (e.g., for other patterns)
                        // that imply that we don't have a one-pass regex.
                        // So instead, we mark that we've found a match and
                        // continue on. When we go to compile a new DFA state,
                        // we just skip that part. But otherwise check that the
                        // one-pass property is upheld.
                    }
                }
            }
        }
        self.shuffle_states();
        Ok(self.dfa)
    }

    /// Shuffle all match states to the end of the transition table and set
    /// 'min_match_id' to the ID of the first such match state.
    ///
    /// The point of this is to make it extremely cheap to determine whether
    /// a state is a match state or not. We need to check on this on every
    /// transition during a search, so it being cheap is important. This
    /// permits us to check it by simply comparing two state identifiers, as
    /// opposed to looking for the pattern ID in the state's `PatternEpsilons`.
    /// (Which requires a memory load and some light arithmetic.)
    fn shuffle_states(&mut self) {
        let mut remapper = Remapper::new(&self.dfa);
        let mut next_dest = self.dfa.last_state_id();
        for i in (0..self.dfa.state_len()).rev() {
            let id = StateID::must(i);
            let is_match =
                self.dfa.pattern_epsilons(id).pattern_id().is_some();
            if !is_match {
                continue;
            }
            remapper.swap(&mut self.dfa, next_dest, id);
            self.dfa.min_match_id = next_dest;
            next_dest = self.dfa.prev_state_id(next_dest).expect(
                "match states should be a proper subset of all states",
            );
        }
        remapper.remap(&mut self.dfa);
    }

    /// Compile the given NFA transition into the DFA state given.
    ///
    /// 'Epsilons' corresponds to any conditional epsilon transitions that need
    /// to be satisfied to follow this transition, and any slots that need to
    /// be saved if the transition is followed.
    ///
    /// If this transition indicates that the NFA is not one-pass, then
    /// this returns an error. (This occurs, for example, if the DFA state
    /// already has a transition defined for the same input symbols as the
    /// given transition, *and* the result of the old and new transitions is
    /// different.)
    fn compile_transition(
        &mut self,
        dfa_id: StateID,
        trans: &thompson::Transition,
        epsilons: Epsilons,
    ) -> Result<(), BuildError> {
        let next_dfa_id = self.add_dfa_state_for_nfa_state(trans.next)?;
        for byte in self
            .classes
            .representatives(trans.start..=trans.end)
            .filter_map(|r| r.as_u8())
        {
            let oldtrans = self.dfa.transition(dfa_id, byte);
            let newtrans =
                Transition::new(self.matched, next_dfa_id, epsilons);
            // If the old transition points to the DEAD state, then we know
            // 'byte' has not been mapped to any transition for this DFA state
            // yet. So set it unconditionally. Otherwise, we require that the
            // old and new transitions are equivalent. Otherwise, there is
            // ambiguity and thus the regex is not one-pass.
            if oldtrans.state_id() == DEAD {
                self.dfa.set_transition(dfa_id, byte, newtrans);
            } else if oldtrans != newtrans {
                return Err(BuildError::not_one_pass(
                    "conflicting transition",
                ));
            }
        }
        Ok(())
    }

    /// Add a start state to the DFA corresponding to the given NFA starting
    /// state ID.
    ///
    /// If adding a state would blow any limits (configured or hard-coded),
    /// then an error is returned.
    ///
    /// If the starting state is an anchored state for a particular pattern,
    /// then callers must provide the pattern ID for that starting state.
    /// Callers must also ensure that the first starting state added is the
    /// start state for all patterns, and then each anchored starting state for
    /// each pattern (if necessary) added in order. Otherwise, this panics.
    fn add_start_state(
        &mut self,
        pid: Option<PatternID>,
        nfa_id: StateID,
    ) -> Result<StateID, BuildError> {
        match pid {
            // With no pid, this should be the start state for all patterns
            // and thus be the first one.
            None => assert!(self.dfa.starts.is_empty()),
            // With a pid, we want it to be at self.dfa.starts[pid+1].
            Some(pid) => assert!(self.dfa.starts.len() == pid.one_more()),
        }
        let dfa_id = self.add_dfa_state_for_nfa_state(nfa_id)?;
        self.dfa.starts.push(dfa_id);
        Ok(dfa_id)
    }

    /// Add a new DFA state corresponding to the given NFA state. If adding a
    /// state would blow any limits (configured or hard-coded), then an error
    /// is returned. If a DFA state already exists for the given NFA state,
    /// then that DFA state's ID is returned and no new states are added.
    ///
    /// It is not expected that this routine is called for every NFA state.
    /// Instead, an NFA state ID will usually correspond to the "start" state
    /// for a sub-graph of the NFA, where all states in the sub-graph are
    /// reachable via epsilon transitions (conditional or unconditional). That
    /// sub-graph of NFA states is ultimately what produces a single DFA state.
    fn add_dfa_state_for_nfa_state(
        &mut self,
        nfa_id: StateID,
    ) -> Result<StateID, BuildError> {
        // If we've already built a DFA state for the given NFA state, then
        // just return that. We definitely do not want to have more than one
        // DFA state in existence for the same NFA state, since all but one of
        // them will likely become unreachable. And at least some of them are
        // likely to wind up being incomplete.
        let existing_dfa_id = self.nfa_to_dfa_id[nfa_id];
        if existing_dfa_id != DEAD {
            return Ok(existing_dfa_id);
        }
        // If we don't have any DFA state yet, add it and then add the given
        // NFA state to the list of states to explore.
        let dfa_id = self.add_empty_state()?;
        self.nfa_to_dfa_id[nfa_id] = dfa_id;
        self.uncompiled_nfa_ids.push(nfa_id);
        Ok(dfa_id)
    }

    /// Unconditionally add a new empty DFA state. If adding it would exceed
    /// any limits (configured or hard-coded), then an error is returned. The
    /// ID of the new state is returned on success.
    ///
    /// The added state is *not* a match state.
    fn add_empty_state(&mut self) -> Result<StateID, BuildError> {
        let state_limit = Transition::STATE_ID_LIMIT;
        // Note that unlike dense and lazy DFAs, we specifically do NOT
        // premultiply our state IDs here. The reason is that we want to pack
        // our state IDs into 64-bit transitions with other info, so the fewer
        // the bits we use for state IDs the better. If we premultiply, then
        // our state ID space shrinks. We justify this by the assumption that
        // a one-pass DFA is just already doing a fair bit more work than a
        // normal DFA anyway, so an extra multiplication to compute a state
        // transition doesn't seem like a huge deal.
        let next_id = self.dfa.table.len() >> self.dfa.stride2();
        let id = StateID::new(next_id)
            .map_err(|_| BuildError::too_many_states(state_limit))?;
        if id.as_u64() > Transition::STATE_ID_LIMIT {
            return Err(BuildError::too_many_states(state_limit));
        }
        self.dfa
            .table
            .extend(core::iter::repeat(Transition(0)).take(self.dfa.stride()));
        // The default empty value for 'PatternEpsilons' is sadly not all
        // zeroes. Instead, a special sentinel is used to indicate that there
        // is no pattern. So we need to explicitly set the pattern epsilons to
        // the correct "empty" PatternEpsilons.
        self.dfa.set_pattern_epsilons(id, PatternEpsilons::empty());
        if let Some(size_limit) = self.config.get_size_limit() {
            if self.dfa.memory_usage() > size_limit {
                return Err(BuildError::exceeded_size_limit(size_limit));
            }
        }
        Ok(id)
    }

    /// Push the given NFA state ID and its corresponding epsilons (slots and
    /// conditional epsilon transitions) on to a stack for use in a depth first
    /// traversal of a sub-graph of the NFA.
    ///
    /// If the given NFA state ID has already been pushed on to the stack, then
    /// it indicates the regex is not one-pass and this correspondingly returns
    /// an error.
    fn stack_push(
        &mut self,
        nfa_id: StateID,
        epsilons: Epsilons,
    ) -> Result<(), BuildError> {
        // If we already have seen a match and we are compiling a leftmost
        // first DFA, then we shouldn't add any more states to look at. This is
        // effectively how preference order and non-greediness is implemented.
        // if !self.config.get_match_kind().continue_past_first_match()
        // && self.matched
        // {
        // return Ok(());
        // }
        if !self.seen.insert(nfa_id) {
            return Err(BuildError::not_one_pass(
                "multiple epsilon transitions to same state",
            ));
        }
        self.stack.push((nfa_id, epsilons));
        Ok(())
    }
}

/// A one-pass DFA for executing a subset of anchored regex searches while
/// resolving capturing groups.
///
/// A one-pass DFA can be built from an NFA that is one-pass. An NFA is
/// one-pass when there is never any ambiguity about how to continue a search.
/// For example, `a*a` is not one-pass becuase during a search, it's not
/// possible to know whether to continue matching the `a*` or to move on to
/// the single `a`. However, `a*b` is one-pass, because for every byte in the
/// input, it's always clear when to move on from `a*` to `b`.
///
/// # Only anchored searches are supported
///
/// In this crate, especially for DFAs, unanchored searches are implemented by
/// treating the pattern as if it had a `(?s-u:.)*?` prefix. While the prefix
/// is one-pass on its own, adding anything after it, e.g., `(?s-u:.)*?a` will
/// make the overall pattern not one-pass. Why? Because the `(?s-u:.)` matches
/// any byte, and there is therefore ambiguity as to when the prefix should
/// stop matching and something else should start matching.
///
/// Therefore, one-pass DFAs do not support unanchored searches. In addition
/// to many regexes simply not being one-pass, it implies that one-pass DFAs
/// have limited utility. With that said, when a one-pass DFA can be used, it
/// can potentially provide a dramatic speed up over alternatives like the
/// [`BoundedBacktracker`](crate::nfa::thompson::backtrack::BoundedBacktracker)
/// and the [`PikeVM`](crate::nfa::thompson::pikevm::PikeVM). In particular,
/// a one-pass DFA is the only DFA capable of reporting the spans of matching
/// capturing groups.
///
/// To clarify, when we say that unanchored searches are not supported, what
/// that actually means is:
///
/// * The high level routines, [`DFA::is_match`] and [`DFA::captures`], always
/// do anchored searches.
/// * Since iterators are most useful in the context of unanchored searches,
/// there is no `DFA::captures_iter` method.
/// * For lower level routines like [`DFA::try_search`], an error will be
/// returned if the given [`Input`] is configured to do an unanchored search or
/// search for an invalid pattern ID. (Note that an [`Input`] is configured to
/// do an unanchored search by default, so just giving a `Input::new` is
/// guaranteed to return an error.)
///
/// # Other limitations
///
/// In addition to the [configurable heap limit](Config::size_limit) and
/// the requirement that a regex pattern be one-pass, there are some other
/// limitations:
///
/// * There is an internal limit on the total number of explicit capturing
/// groups that appear across all patterns. It is somewhat small and there is
/// no way to configure it. If your pattern(s) exceed this limit, then building
/// a one-pass DFA will fail.
/// * If the number of patterns exceeds an internal unconfigurable limit, then
/// building a one-pass DFA will fail. This limit is quite large and you're
/// unlikely to hit it.
/// * If the total number of states exceeds an internal unconfigurable limit,
/// then building a one-pass DFA will fail. This limit is quite large and
/// you're unlikely to hit it.
///
/// # Other examples of regexes that aren't one-pass
///
/// One particularly unfortunate example is that enabling Unicode can cause
/// regexes that were one-pass to no longer be one-pass. Consider the regex
/// `(?-u)\w*\s` for example. It is one-pass because there is exactly no
/// overlap between the ASCII definitions of `\w` and `\s`. But `\w*\s`
/// (i.e., with Unicode enabled) is *not* one-pass because `\w` and `\s` get
/// translated to UTF-8 automatons. And while the *codepoints* in `\w` and `\s`
/// do not overlap, the underlying UTF-8 encodings do. Indeed, because of the
/// overlap between UTF-8 automata, the use of Unicode character classes will
/// tend to vastly increase the likelihood of a regex not being one-pass.
///
/// # How does one know if a regex is one-pass or not?
///
/// At the time of writing, the only way to know is to try and build a one-pass
/// DFA. The one-pass property is checked while constructing the DFA.
///
/// This does mean that you might potentially waste some CPU cycles and memory
/// by optimistically trying to build a one-pass DFA. But this is currently the
/// only way. In the future, building a one-pass DFA might be able to use some
/// heuristics to detect common violations of the one-pass property and bail
/// more quickly.
///
/// # Resource usage
///
/// Unlike a general DFA, a one-pass DFA has stricter bounds on its resource
/// usage. Namely, construction of a one-pass DFA has a time and space
/// complexity of `O(n)`, where `n ~ nfa.states().len()`. (A general DFA's time
/// and space complexity is `O(2^n)`.) This smaller time bound is achieved
/// because there is at most one DFA state created for each NFA state. If
/// additional DFA states would be required, then the pattern is not one-pass
/// and construction will fail.
///
/// Note though that currently, this DFA uses a fully dense representation.
/// This means that while its space complexity is no worse than an NFA, it may
/// in practice use more memory because of higher constant factors. The reason
/// for this trade off is two-fold. Firstly, a dense representation makes the
/// search faster. Secondly, the bigger an NFA, the more unlikely it is to be
/// one-pass. Therefore, most one-pass DFAs are usually pretty small.
///
/// # Example
///
/// This example shows that the one-pass DFA implements Unicode word boundaries
/// correctly while simultaneously reporting spans for capturing groups that
/// participate in a match. (This is the only DFA that implements full support
/// for Unicode word boundaries.)
///
/// ```
/// # if cfg!(miri) { return Ok(()); } // miri takes too long
/// use regex_automata::{dfa::onepass::DFA, Match, Span};
///
/// let re = DFA::new(r"\b(?P<first>\w+)[[:space:]]+(?P<last>\w+)\b")?;
/// let (mut cache, mut caps) = (re.create_cache(), re.create_captures());
///
/// re.captures(&mut cache, "Шерлок Холмс", &mut caps);
/// assert_eq!(Some(Match::must(0, 0..23)), caps.get_match());
/// assert_eq!(Some(Span::from(0..12)), caps.get_group_by_name("first"));
/// assert_eq!(Some(Span::from(13..23)), caps.get_group_by_name("last"));
/// # Ok::<(), Box<dyn std::error::Error>>(())
/// ```
///
/// # Example: iteration
///
/// Unlike other regex engines in this crate, this one does not provide
/// iterator search functions. This is because a one-pass DFA only supports
/// anchored searches, and so iterator functions are generally not applicable.
///
/// However, if you know that all of your matches are
/// directly adjacent, then an iterator can be used. The
/// [`util::iter::Searcher`](crate::util::iter::Searcher) type can be used for
/// this purpose:
///
/// ```
/// # if cfg!(miri) { return Ok(()); } // miri takes too long
/// use regex_automata::{
///     dfa::onepass::DFA,
///     util::iter::Searcher,
///     Anchored, Input, Span,
/// };
///
/// let re = DFA::new(r"\w(\d)\w")?;
/// let (mut cache, caps) = (re.create_cache(), re.create_captures());
/// let input = Input::new("a1zb2yc3x").anchored(Anchored::Yes);
///
/// let mut it = Searcher::new(input).into_captures_iter(caps, |input, caps| {
///     Ok(re.try_search(&mut cache, input, caps)?)
/// }).infallible();
/// let caps0 = it.next().unwrap();
/// assert_eq!(Some(Span::from(1..2)), caps0.get_group(1));
///
/// # Ok::<(), Box<dyn std::error::Error>>(())
/// ```
#[derive(Clone)]
pub struct DFA {
    /// The configuration provided by the caller.
    config: Config,
    /// The NFA used to build this DFA.
    ///
    /// NOTE: We probably don't need to store the NFA here, but we use enough
    /// bits from it that it's convenient to do so. And there really isn't much
    /// cost to doing so either, since an NFA is reference counted internally.
    nfa: NFA,
    /// The transition table. Given a state ID 's' and a byte of haystack 'b',
    /// the next state is `table[sid + classes[byte]]`.
    ///
    /// The stride of this table (i.e., the number of columns) is always
    /// a power of 2, even if the alphabet length is smaller. This makes
    /// converting between state IDs and state indices very cheap.
    ///
    /// Note that the stride always includes room for one extra "transition"
    /// that isn't actually a transition. It is a 'PatternEpsilons' that is
    /// used for match states only. Because of this, the maximum number of
    /// active columns in the transition table is 257, which means the maximum
    /// stride is 512 (the next power of 2 greater than or equal to 257).
    table: Vec<Transition>,
    /// The DFA state IDs of the starting states.
    ///
    /// `starts[0]` is always present and corresponds to the starting state
    /// when searching for matches of any pattern in the DFA.
    ///
    /// `starts[i]` where i>0 corresponds to the starting state for the pattern
    /// ID 'i-1'. These starting states are optional.
    starts: Vec<StateID>,
    /// Every state ID >= this value corresponds to a match state.
    ///
    /// This is what a search uses to detect whether a state is a match state
    /// or not. It requires only a simple comparison instead of bit-unpacking
    /// the PatternEpsilons from every state.
    min_match_id: StateID,
    /// The alphabet of this DFA, split into equivalence classes. Bytes in the
    /// same equivalence class can never discriminate between a match and a
    /// non-match.
    classes: ByteClasses,
    /// The number of elements in each state in the transition table. This may
    /// be less than the stride, since the stride is always a power of 2 and
    /// the alphabet length can be anything up to and including 256.
    alphabet_len: usize,
    /// The number of columns in the transition table, expressed as a power of
    /// 2.
    stride2: usize,
    /// The offset at which the PatternEpsilons for a match state is stored in
    /// the transition table.
    ///
    /// PERF: One wonders whether it would be better to put this in a separate
    /// allocation, since only match states have a non-empty PatternEpsilons
    /// and the number of match states tends be dwarfed by the number of
    /// non-match states. So this would save '8*len(non_match_states)' for each
    /// DFA. The question is whether moving this to a different allocation will
    /// lead to a perf hit during searches. You might think dealing with match
    /// states is rare, but some regexes spend a lot of time in match states
    /// gobbling up input. But... match state handling is already somewhat
    /// expensive, so maybe this wouldn't do much? Either way, it's worth
    /// experimenting.
    pateps_offset: usize,
    /// The first explicit slot index. This refers to the first slot appearing
    /// immediately after the last implicit slot. It is always 'patterns.len()
    /// * 2'.
    ///
    /// We record this because we only store the explicit slots in our DFA
    /// transition table that need to be saved. Implicit slots are handled
    /// automatically as part of the search.
    explicit_slot_start: usize,
}

impl DFA {
    /// Parse the given regular expression using the default configuration and
    /// return the corresponding one-pass DFA.
    ///
    /// If you want a non-default configuration, then use the [`Builder`] to
    /// set your own configuration.
    ///
    /// # Example
    ///
    /// ```
    /// use regex_automata::{dfa::onepass::DFA, Match};
    ///
    /// let re = DFA::new("foo[0-9]+bar")?;
    /// let (mut cache, mut caps) = (re.create_cache(), re.create_captures());
    ///
    /// re.captures(&mut cache, "foo12345barzzz", &mut caps);
    /// assert_eq!(Some(Match::must(0, 0..11)), caps.get_match());
    /// # Ok::<(), Box<dyn std::error::Error>>(())
    /// ```
    #[cfg(feature = "syntax")]
    #[inline]
    pub fn new(pattern: &str) -> Result<DFA, BuildError> {
        DFA::builder().build(pattern)
    }

    /// Like `new`, but parses multiple patterns into a single "multi regex."
    /// This similarly uses the default regex configuration.
    ///
    /// # Example
    ///
    /// ```
    /// use regex_automata::{dfa::onepass::DFA, Match};
    ///
    /// let re = DFA::new_many(&["[a-z]+", "[0-9]+"])?;
    /// let (mut cache, mut caps) = (re.create_cache(), re.create_captures());
    ///
    /// re.captures(&mut cache, "abc123", &mut caps);
    /// assert_eq!(Some(Match::must(0, 0..3)), caps.get_match());
    ///
    /// re.captures(&mut cache, "123abc", &mut caps);
    /// assert_eq!(Some(Match::must(1, 0..3)), caps.get_match());
    ///
    /// # Ok::<(), Box<dyn std::error::Error>>(())
    /// ```
    #[cfg(feature = "syntax")]
    #[inline]
    pub fn new_many<P: AsRef<str>>(patterns: &[P]) -> Result<DFA, BuildError> {
        DFA::builder().build_many(patterns)
    }

    /// Like `new`, but builds a one-pass DFA directly from an NFA. This is
    /// useful if you already have an NFA, or even if you hand-assembled the
    /// NFA.
    ///
    /// # Example
    ///
    /// This shows how to hand assemble a regular expression via its HIR,
    /// compile an NFA from it and build a one-pass DFA from the NFA.
    ///
    /// ```
    /// use regex_automata::{
    ///     dfa::onepass::DFA,
    ///     nfa::thompson::NFA,
    ///     Match,
    /// };
    /// use regex_syntax::hir::{Hir, Class, ClassBytes, ClassBytesRange};
    ///
    /// let hir = Hir::class(Class::Bytes(ClassBytes::new(vec![
    ///     ClassBytesRange::new(b'0', b'9'),
    ///     ClassBytesRange::new(b'A', b'Z'),
    ///     ClassBytesRange::new(b'_', b'_'),
    ///     ClassBytesRange::new(b'a', b'z'),
    /// ])    /// # Ok::<(), Byntax")]
-pass DFA wi ///s_iteFA winy(     ize_limit):must1_000 # Ok::<(),  = se     /s_iteFA fror_past_If you or hary(patterA.
 _cla(&cla let (mut ct re = DFA::new_many(&["[a-A.
 _e  silo let (mut cache, mut caps) = (re.create_cache(), re.create_captures());
    ///
    /// reit_slot_this r= :must(0, 0..11)), caps.g
    /// rei(&mut cache, "123abc", &mAs);
    /// assert_eq!(Some(Match:ot_this match());
    ///
    /// # Ok::<(), Box<dyn std::error::Error>>(())
    /// ```
    #[cfg(featumany<P: AsRA.
 _e  silo/// T<DFA, BuildError> {
        DFA::builder().build_many(patterA.
 _e  silo  /// Compile the res()y DFA sA from the NFo be any patt.
    .. mat  /// # Example
    ///
    /// ```
    /// use regex_automata::{dfa::onepass::DFA, Match};
    ///
    /// let re = DFA::nd     r().bterns.    ///
let (mut cache,"123abc",      he(), re.createet (mut cache,"123abps      he(), re.c    ///
   /// let re = DFA::not_this r= (0, 0..11)), caps.0eet (mut ca   het cache, "123abc", &ms);
    /// assert_eq!(Some(Match::mustot_this _match());
    /// # Ok::<(),    het cache, "123abc", &mzzzs);
    /// assert_eq!(Some(Match::mustot_this _match());
    /// # Ok::<(), Box<dyn std::error::Error>>(())
    /// ```
    #[cfg(featumany<P:terns.    ///
DFA, BuildError> {
        DFA::builde = se     FA,
    ///  .bterns.    ///
k(())
    o
    / b'z')y(patterA.
 _e  silo  /// Compile the res()y DFA sA from the NFo be iminat
/// diren  .. mat  /// # Example
    ///
    /// ```
    /// use regex_automata::{dfa::onepas::DFA, Match};
    /// let re = DFA::nd     r().bimina    ///
let (mut cache,"123abc",      he(), re.createet (mut cache,"123abps      he(), re.c    ///
   /// let re = DF   het cache, "123abc", &ms);
    /// assert_eq!(Some(Match:nfa.sttch());
    /// # Ok::<(),    het cache, "123abc", &mzzzs);
    /// assert_eq!(Some(Match:nfa.sttch());
    /// # Ok::<(), Box<dyn std::error::Error>>(())
    /// ```
    #[cfg(featumany<P: Aina    ///
DFA, BuildError> {
        DFA::builde = se     FA,
    ///  .b Aina    ///
k(())
    o
    / b'z')y(patterA.
 _e  silo  /// Compile theRror.)
/nfiguration and
    /// state/
    /// If you wantt a seara to do so.ce called f "muvoid saved a oneThis
 :.)` m /// Tse regex_a useding fc1))omizault conn of a one-pass DFD
    /// # Example
    ///
    /// This shows how tws that the oninue a shtransnd also thgulanect c, split intFA.
  indicates snfigurati"      // appea"e a "/ # " to coefault"/ #,"ness is implemeOk::<(),   like a
///yansitioit's wovideorder and non-gre//
/// Th special s NFA.
    //ne-past{
      know whepatterns.lhe
    ///(Al curretrannn of a one-p, indicates '. Thisnow whe stateA from the NFoo-empty Pllocation wns///  each patter"order and non-gr" vsi" e-past{
    .")  /// ```
    /// use regex_automata::{dfa::onepass::DFA, Match};
    ///
   ///
Kind    /// let re = DFA::new_many(&[uild_many  ClassBytesRast_If you Ds_iteFA winy().continue_ ///
Kind::All)y  ClassBytesRarn)
  r"(abc)+?"
let (mut cache,"123abc",   ache(), re.createet (mut cache,"123abps   aptures());
    ///
   /// re.captures(&mut cache, "abc123", &mut caps);
    /// assert_eq!(t the just r of coss is im spanet that '8*lenar ek itaps.ge            eq!(Some(Match::must(0, 0..3)), caps.g6t_match());
    /// # Ok::<(), Box<dyn std::error::Error>>(())
    /// ```
    #[cfg(feature pub fn new_many<P:eFA winyDFA, /// TDFA::buildee_limit)'z')y /// Compile theRror.)
/nuild_maing grt_If yoault conn of a one-pass DFD
    /// # Example
 t a seara to do so.ce called f "muvoid saved a oneThis
 :.)`Example
  to
    /// susedine of a regexs   /// # Example
    ///
    /// This shows how tws that the oninue a uilder`]uild_maiing wheed tata, tmode   /// ```
    /// use regex_airi) { return Ok(()); } // miri takes too long
/// use reg regex_automata::{
    ///     dfa::onepass::DFA,
    ///     nfa::thompson::NFA,
       nfa::thomps:Searc::{Hir   Match,
    /// };
    /// use regex_t re = DFA::new_many(&[uild_many  ClassBytesRa::{Hir(::{Hir, e_limit)'z')y.utf8(     )y  ClassBytesRaFA,
    (FA,
    //e_limit)'z')y.utf8(     )y  ClassBytesRarn)
  r"zzz for:[^b])ar.*/ let (mut cache, mut caps) = (re.create_cache(), re.create_captures());
    ///
    /// re.capturesir::c,
    //= b"zzz\xFFt ca\xE2\x98\xFF\n"   /// reit_slot_this r= :must(0, 0..11)), caps.8
    /// rei(&mut cache, "123abc", &c,
    /);
    /// assert_eq!(Some(Match:ot_this match());
    ///
    /// # Ok::<(), Box<dyn std::error::Error>>(())
    /// ```
    #[cfg(feature pub fn new_many<P:uild_manyDFA,o
    /DFA::buildeo
    / b'z')y /// Compile the res()y DFA srnEpsiored reroups that
/// particsearto return an eb`Example
 rn ID.e NFA stato detAPIs every
  D
    /// # Example
 A m always
/esponds each NFA staly do NOT used, ine-pasatch s    /en  not. It rt's wD
    /// # Example
 t a seara to do so.ce re generFA st[m always
.btel`] thee:.)`Example
  t always
/]wovcumkes the
/lid patot_sanane-pass s sns like the
nverting betf a ont usBut oto cherrespondind thehe st
    arch, it's not
// the alphabet  it dealiremely condly, feature pub fn new_many<P:eres());
    ///&sult<Stat always
DFA::buildeealways
.btel(_dfa_id[.me("lae fe_passtru    /// Add a start res()y DFA sabc", A state
       /// The stride of tabc",  the givet matchthe e
/// this pre not supA state
A. The questio a non-defaun erruilder`]abc", A stanrt's wD
 the [`BnonA. The qunsurert o  t ac",ansiore/]w         pondi(or,. Otherwiset rExample
  tny(&[sioree.crea`]) feature pub fn new_many<P:eres());
reat&sult<Stat ac", FA::buildeeac",antched, ny /// Compile theRrtern epsar expabc", stateonvenied for
/// this pfor matches       eis returns an ondi(nsitthe es an ond)   /// # Example
 A abc",  tternto checkrruichesuse of e an NFAwill
  . Othe this bc",en searchiwe wanllocation D
    /// # Example
    ///
    /// This shows how to hand assembrfro
/// `ra tbc", A st storwe wanllocation D
    /// # Example
  use regex_airi) { return Ok(()); } // miri takes too long
/// use reg regex_automata::{
    ///   s::DFA, Match};
    ///
    /// let re = DFA::new1(r"\w(\d)\w")?;
/ let (mut cache,re2(r"\w(\d)\w")?;W"
let (mut cache,"123abps1   ap1tures());
    ///
   /// reache,"123abps2   ap2he(), re.c    ///
   /// let re = DFA::n"123abc",   ac1he(), re.createet (mut caSome(Match:  ClassBytesR:must(0, 0..23)), caps.g)    ClassBytesR{ ac1het cache, "abc123", &mΔs);
    /// 1i t/// 1));
    ///
 }   ClassBy
   /// let re = DFtheriches'123",'orwe wre2(pass
//a ///
  ys 'maythe old  usefn ad each patterice upty" Pathe oldion
//rify thatrfro
/// `rer`]abc",hat wethat.  'min_match_ates t       eFA will fail. Te'd// [`Boa uilds t    .in_match_atin_match_ateSes the d,last implo thesand efault conabc",      'ac1'epattesap, tin_match_atea ///
    /// If ap2hsioree.crea, "abc123",eet (mut caSome(Match:  ClassBytesR:must(0, 0..23)), caps.3)    ClassBytesR{ ac2het cache, "abc123", &m☃s);
    /// 2i t/// 2));
    ///
 }   ClassBy
   /// let re = DFBox<dyn std::error::Error>>(())
    /// ```
    #[cfg(feature pub fn new_many<P:sioree.crea,    nfc123",:;
    eac",     return 123",hsioreed, ny; /// Compile theRror.)
tation pro A state
 A.
    ///
    ///re pub fn new_many<P:);
 eFA win&sult<Stat& /// TDFA::builde&.get_match_ /// Compile theRror.)sexpreer and nt slot UTF-8 encodN
    ///re pub fn new_many<P:);
 e  s&sult<Stat&N/ Parse tilde&.get_n    .taCompile theRror.)seumber of states exceto a singa_ids.puFA statee
       /// The stride re, buiegexass DFD
 ntly, toes inn. So we nees,ns an error. (`0`   ///re pub fn new_many<P:ilons(id// *&sult<Statmpl DParse tilde.get_);
 e  sd().is_som// * 2'.
 Compile theRror.)seumber of states excehe sub-graphe
 A.
    ///
    /// Note that the stride e and lazy DF pfoiple chored DFA directly frovide
///ot_/ `power of 2,its nes liy frAPI, most one-pae is called fand littlicode ctinue han less than ete.
 fe ju starts: Vecre pub fn new_many<P:).rev() {
&sult<Statmpl DParse tilde.get_ >> self.dfa.stride2        l2'.
 Compile theRror.)seumber of states exce each state t length can A state
       /// The stride oficsea,ns an error. (umber of states exce that need
    /// DFA. The que transitioan ondiethatemption isber of
 ngth can pl DPch me6ns the nverting beo a match stan (if snow whestackspond   /// The added state gth can pl DPmaytn the stride,me6  curretrnsite aemeOk::<(), [`e_limit)stac_teClassgured  wheed d,e
/// onypart of ethathe stride
    strid56onstructiobyional.
 me("lpuFA sta classes. Bytes in  stateonvennet your owdentbysub-graph arenceever discrdid);
 uishate is st. This
    classes: Bymple, `a*a` is nograph agurati`^0-9]+"$`,definitionsbysub-`-9]`ternldlocation, sitn tgraph arence classes. Bytes it is quin Nh state.
sybe complexe equivaleo a s   /// Note that the striurrently, t length can be anytovide_s(
  added iniof 7).
    eis returns of slways aexity ong
nncompyFA state.
    fn adnsition table, expis returnsmay
  structioA stringe ju.ce cor thmum numlways a power of  same equivals maks2 greater tdentrticseart or equal to 257).
    tt length cant re = DFA: any.e, `as an err th_match`] lways gur st[mch`] lways 2A::creachable vost nely it u alr.state gth can maller. Thnypart of ou alrethe e each patter
 fe ju start//
/// `s   /// Note that the sttesapride e and lazy DF pfoiple chored DFA directly frovidn-match staDFA statntinel isend-of-ut::ne(EOI). It is a 'Paause a one-passpower of 2,A has a time an// ashis i-arievedSome(Meed
 set the pat(/ [`Boundk::<(), [`ate::nfa::thompson::pikevm::PikeVM). In partiche rerovide
///uild_e transitionmFA state g that need
 of   ///
    ///re pub fn new_many<P:n: usize,
  
&sult<Statmpl DParse tilde.get_n: usize,
  2'.
 Compile theRror.)seumber of slways ayte in thee transitioan ond as a power of
oundk::<(), ot_/neis to 2 and
    //. of this tab DFA thamrnalexcehxity in the trais returnsmg
//ut...tion table, expressed as a power of
  tates exce that need
Which requiUnld thithat need
 mapwhethead this wo)  /// The stride of this table a only DFwer of  Otherwiserting stas maks2 greater 
    stridtrticseart or equal to 257).
    tt le/// an gth can mallerPaauseOk::<(),  of `\w` aefaultsitionhxitys multisnow wynto checkondly, to UTF-8expis returnte IDs and sta tantififirsber of iring one-pass DFAe,
  snsitioan ond'sansition table that need    /// Note that tF if the DFA state
    'sthis tab DF16hithat need
the [`Bheck`lways 2A returned. I`4` match `2^4 =F16    /// The stride of tm `\of
 `lways 2Aesponds. I`1`d or to the given Nathis table `2`)en searchindepointsber of
 `lways 2Aesponds. I`9`d or to the given Nathis taachable vos `512`)ion isber of
 ..tion of he start s`8ds a onehis, the muristediately all suppane-pa a sksFo be anyd, thelax. Othe tuilding a iss becauely iat isn't actns`8d. (Dap, t`Input`]sber of slways aaratecredw wynome red a nt re = DF'8*leneing o        //y DFwe  // natrfd///
ntograph agurati we need)  /// Note that the stride e and lazy DF pfoiple chored DFA directly frovide
///ot_/ `power of 2,its nes liy frAPI, most one-pae is called fand littlicode ctinue han less than ete.
 fe ju starts: Vecre pub fn new_many<P:).      &sult<Statmpl DParse tilde.get_).     2'.
 Compile theRror.)seumber of slways ayte in thee transitioan ondPaause beo a matchis returns (umber of states exce that need
 ld thpyFin the transitioan ond'sansition table that need    /// Note that tPlkelihseet[mch`] lways 2A:: of ay it
 fe ju staular,
/// a one-tate
A. The querror. (umbeys inclus of match stateithat need
thtates ick`lways 2A returnederror. (d a sit slots/neis to 2 and
    //.  /// Note that the stride e and lazy DF pfoiple chored DFA directly frovide
///ot_/ `power of 2,its nes liy frAPI, most one-pae is called fand littlicode ctinue han less than ete.
 fe ju starts: Vecre pub fn new_many<P:).     &sult<Statmpl DParse tilde1 <<tride2        l2'.
 Compile theRror.)seumbeuse of ly, cnograbBytesR, split int   /// The stride of tmse of ly, cred tote
  morese stackf match statebysub-ld this returneder correspplit int   /// The stride ofn that y*ass b*oom for  then
     pl DPld thcompyFioan ondPaaompile an NFA u stride,code `:Erromset) and
of::<A, Match};
 >eral: Vecre pub fn new_many<P:e() > size_li&sult<Statmpl DParse tildeode :repeamset) and
of;
rse tilde.get_ >> self.dfa*  and
of::<,
    /// T(   .map_err(|_+.push((nf= pid.one_*  and
of::<   /// E(/// A one-p    /// Parse the gEsubseeed state for a      // aorward's not
// thuerror. (uruns != the alphabethe eifaphe
 A.
    ///
 t
/// dir epsar expc,
    /   /// The stride ofn tcalled fanydhe rt circuiss `(?s-ll osFo be s, inches ding ch patter
 ::ne///
/iminaterf hit dullocation he oldular,
/// a one-tstate
g regex_auTF-8 encod/
 t/ trrtate
    /// orpattern in tcalled f///
/error.`
    #[cfurun`y after the l    contintinetg afters ding ... matc(e regex
/howis returns an  dealiremeldullocatiocpsar expph agurati`a+`stackf mc,
    /`
    #[cfaaaaaaaaaaaaaaa`. ofn tcalled fiscrng an.g., `(?hseesslot appear`a`   ClassBya onke [`DFA::try_`f `d` saved. Itching thor matches` and `\s+` useful if yis im s so just go)  /// The stride of tar exp configred aorce repretern a uild[`es);
///
/// guretate
g regex_aar expan and
    ///wnd [`es);
///
/Nogur(atternilt regex conf)   /// # Example
   Pfn ad  /// The stride ofn tcalled fefn ad ih.
    expliternlde
///       leaause b to ccuach patter
 slot ao ///ng grircumrs. ces:  /// The stride * to coshouldhe call configran and
    ///pass
//what
/// .e, `dk::<(), othe DFA b dramatig afteauTwhat
/// tate fotmode ee_lcrethe ,is returns an  ccuae is neefault[`es);
///
/lons
  /]w    conticode caOk::<(), [`e_limit)(nf= pate(
in tsilons(i`]   /// We record thass DF explitefn ad,  confisd, ine-pr to continuete
    /the giv `dk::<(), uire  /// We record tUsy_search`], an error d-assembe more tha// aoshos fefn ad nd // is returnedsponds bit-unp   /// # Example
    ///
    /// This shows how to handresic ly, c:  /// ```
    /// use regex_automata::{dfa::onepas::DFA, Match};
    /// let re = DFA::new("foo[0-9]+bar")?;
    /// let (mut cache,"123abc",   ache(), re.createet (mut ct (mut caSome(M!cachand [`DF, "foo12345barzzz", &mut ")eet (mut caSome(M!(!achand [`DF, "foo12345barzzzut ")eet (mut caBox<dyn std::error::Error>>(())
    /// ```
    #[cfg(featu # Example
    ///
  : betf the s l    tato detAPIs  /// ```
    /// and [`DFAsearto return an e)); } /furun`yis nminat` always
/  /// an error.
  is is thause am for one not sup one-pasa subsen aantirhe l    innon-match.
 in `\w` :  /// ```
    /// use regex_automata::{dfa::onepass::DFA, Match};
   confi    /// let re = DFA::new("foo[0-9]+baa*/ let (mut cache,"123abc",   ache(), re.createet (mut ct (mut caSome(M!c!achand [`DF, "foo12345ba"a1zb2yc3x")☃s).aptups0.geteet (mut caBox<dyn std::error::Error>>(())
    /// ```
    #[cfg(featu # Example
 he ice its spatomata, tmodered  wheed d,ettern is ab `a*pans fsnon-match.

    /re is at mo he nds o /// g inntstead-wid  /// stsup one-equivaon-match.
 in `\w` fand  on tlig.,d:  /// ```
    /// use regex_automata::{dfa::onepass::DFA, Match};
   on::NFA,
    ///    confi    /// let re = DFA::new("foo[0-uild_many  ClassBytesRaFA,
    (/s_iteFA winy(utf8(     )y  ClassBytesRarn)
  aa*/ let (mut cache,"123abc",   ache(), re.createet (mut ct (mut caSome(M!cachand [`DF, "foo12345ba"a1zb2yc3x")☃s).aptups0.geteet (mut caBox<dyn std::error::Error>>(())
    /// ```
    #[cfg(feature pub fn new_many<P:and [`DF<'
//I:a"ato<"a1zb<'
>///rse tilde&.get,  return 123",:;
    eac",,  return .. ma:a"Result<(), boolDFA::builde = sarchet::new(.. matA stny( none-pt(urunif let Some(si// stsu!o_capt_);
 chored::Ystdes);
///
/No     if self.dfa.capt_s;
 chored::Yes);
///
/// let       self.stack.push(], an erro: usis(12345ba&)?)
///
    []
/// asserhanduris l2'.
 Compile theEsubseeed state for a      // aorward's not
// thuerror. (a `M[`DFAsefd the number the eifaphe
 A.
    ///
 t
/// dir epsar expc,
    /   /// The stride ofn tcalled fthe eim for on pattern not
    //ptuPaao:);
 accesrst slotch patter
 diati.
  tching
//in throups that
/// , uild[`es`], always
//.  /// The stride of tar exp configred aorce repretern a uild[`es);
///
/// guretate
g regex_aar expan and
    ///wnd [`es);
///
/Nogur(atternilt regex conf)   /// # Example
   Pfn ad  /// The stride ofn tcalled fefn ad ih.
    expliternlde
///       leaause b to ccuach patter
 slot ao ///ng grircumrs. ces:  /// The stride * to coshouldhe call configran and
    ///pass
//what
/// .e, `dk::<(), othe DFA b dramatig afteauTwhat
/// tate fotmode ee_lcrethe ,is returns an  ccuae is neefault[`es);
///
/lons
  /]w    conticode caOk::<(), [`e_limit)(nf= pate(
in tsilons(i`]   /// We record thass DF explitefn ad,  confisd, ine-pr to continuete
    /the giv `dk::<(), uire  /// We record tUsy_search`], an error d-assembe more tha// aoshos fefn ad nd // is returnedsponds bit-unp   /// # Example
    ///
    /// This shows L     // appeaalso thgulanect c to the starting stlso th       eis returnas maks2 ates are Ae,
  e enougates t sloer tich thed  ethrminreatins returnorder  that none-r brate ub-graph aorigiart/ression via its HI.e, `dk::<(), othe DFA `Sam|Samwisemake ttlso th`Sam`d `\sSamwiseme enousSamwise|Sam`en searchiw ttlso th`Samwisema `\sSamwisem   /// # Example
 Gt applicaspeakly way to"      // appea"elso thind ass  // BoundedBa caOk::<(), ression via its HIsstly incr
   Paause a oine onded so eiPOSIX-sty    /// Th ression via its HIsstht poielde"      //  e-past"t
/// di  structi  ClassByaoth `Sam|Samwisema/ do Samwise|Sam`tlso th`Samwisemais neefault (mut cach    //  e-pasthgulanect the only:thomrovide
///he
/// onl for Uni (mut cach    //  e-pasthgulanect t)  /// ```
    /// use regex_automata::{dfa::onepass::DFA, Match};
    ///
    /// let re = DFA::new("foo[0-9]+bar")?;
   "
let (mut cache,"123abc",   ache(), re.createet (mut cache,ot_this r= (0, 0..11)), caps.8assert_eq!(Some(Match::mustot_this _maachf `d, "foo12345barzzz", &m")
   /// let re = DFtheE expphurrenaelso thindfievedSg., `an Nault conappeaastack(`a`    ClassBysition l     // appeaalso thgulanect cdulandone-pass f `d t slonone-pt  ClassBysitlso thBut othe firs none-r 
///
 of   //the DFA.ativelr equ
///
.t re = DFA::new("foo[0-9]+baabc|a"
let (mut cache,"123abc",   ache(), re.createet (mut cache,ot_this r= (0, 0..11)), caps.3assert_eq!(Some(Match::mustot_this _maachf `d, "foo12345barcaps
    /// # Ok::<(), Box<dyn std::error::Error>>(())
    /// ```
    #[cfg(feature pub fn new_many<P:f `d<'
//I:a"ato<"a1zb<'
>///rse tilde&.get,  return 123",:;
    eac",,  return .. ma:a"Result<(), O  sta<(0, 0>DFA::builde = sarchet::new(.. matA stnyf let Some(si// stsu!o_capt_);
 chored::Ystdes);
///
/No     if self.dfa.capt_s;
 chored::Yes);
///
/// let       self.stack.(si.get_);
 e  sd().is_som// *  == 1    if self.dfa = sarchandled= [nfa.stnfa.];  if self.dfa = spi r=  if self.dfaack.push(], an erro: usis(12345ba&)?)
///
     usis
/// asser?;  if self.dfa = sing.
/=  usis[0]/// asserh);
nyf let Some.dfa = sly i=  usis[1]/// asserh);
nyf let Some.dfa)); } /:must(0, 0..: &stone-1..2 {sing.
,sly i})let       self.stack. = sg
 fei=  get_);
 e  sd(me("lae fe_p;lf.stack. = s usism// i= g
 fe.ot. It i: usiz// * ;
self.dfa = sarchandled= //   nfa.;s usism// ];
self.dfa = spi r=.push(], an erro: usis(12345ba&)?)
///
     usis
/// asser?;  if self = sing.
/=  usis[pi .as_mpl Dne_* 2]/// asserh);
nyf let Some = sly i=  usis[pi .as_mpl Dne_* 2 + 1]/// asserh);
nyf let Some:must(0, 0..: &stone-1..2 {sing.
,sly i})l2'.
 Compile theEsubseeed state for a      // aorward's not
a/ doe on on pattchinachable vos roups that
/// partics in a matchd. (This is FA state gldhe calExample
  t always
/]wspond o a notlso th andfieve,ettern[m always
.band [`DFA: returned. Ito return an e)); } /f     `.  /// The stride of tar exp configred aorce repretern a uild[`es);
///
/// guretate
g regex_aar expan and
    ///wnd [`es);
///
/Nogur(atternilt regex conf)   /// # Example
   Pfn ad  /// The stride ofn tcalled fefn ad ih.
    expliternlde
///       leaause b to ccuach patter
 slot ao ///ng grircumrs. ces:  /// The stride * to coshouldhe call configran and
    ///pass
//what
/// .e, `dk::<(), othe DFA b dramatig afteauTwhat
/// tate fotmode ee_lcrethe ,is returns an  ccuae is neefault[`es);
///
/lons
  /]w    conticode caOk::<(), [`e_limit)(nf= pate(
in tsilons(i`]   /// We record thass DF explitefn ad,  confisd, ine-pr to continuete
    /the giv `dk::<(), uire  /// We record tUsy_search`], an error d-assembe more tha// aoshos fefn ad nd // is returnedsponds bit-unp   /// # Example
    ///
    /// This shows how to handmparison ws that ss DFA has a tgurati   ///itioctonverting boups that
/// ttchin.  /// ```
    /// use regex_automata::{dfa::onepass::DFA, Match};
    ///
  /// let /// let re = DFA::new("foo[0-9]+b  ClassBytesRe
 he ice its spicode itionsates.uration to the gived bounda(?-u)\ ClassBytesRe
 w toadicable.//
/// # H ClassBytesR"w+)[[:spac[[: gth t>\w]+(?P<last>\w+)\b")?;
[[: gth t>\w]"   ClassBy
let (mut cache, mut caps) = (re.create_cache(), re.create_captures());
    ///
    /// re.captures(&mut cache, "abc123", &mBruce Sp that-uens);
    /// assert_eq!(Some(Match::must(0, 0..11)), caps.g7t_match());
    /// # Ok::<(), Some(Span::from(0..12)), caps.5t_group_by_name("l(1 # Ok::<(), Some(Span::from(0..12)), ca6s.g7t_match());
 me("last"));
/// # Ok::< /// # Ok::<(), Box<dyn std::error::Error>>(())
    /// ```
    #[cfg(feature pub fn new_many<P:ut cache<'
//I:a"ato<"a1zb<'
>///rse tilde&.get,  return 123",:;
    eac",,  return .. ma:a"Resulturn 12ps:;
    ea cacheResult<(FA::builde = sarchet::new(.. matA stnyf let Some(si// stsu!o_capt_);
 chored::Ystdes);
///
/No     if self.dfa.capt_s;
 chored::Yes);
///
/// let       self.stack.push(], an erro(12345ba&)?)
////// a/// assert_'.
 Compile theEsubseeed state for a      // aorward's not
a/ doe on on pattchinachable vos roups that
/// partics in a matchd. (This is FA state gldhe calExample
  t always
/]wspond o a notlso th andfieve,ettern[m always
.band [`DFA: returned. Ito return an e)); } /f     `.  /// The stride of tllocatiocpsh     [`es`], always
//-pas:  /// The stride 1rs to theror. (an // is bit-unpackiefn akete.
h.
    explit// N# H ClassBy2. Accept (an `&configreit-unpackial coto<"a1zb>`. ofn tto checkrruichee transition renceet::ne of aterns innd so iteratternd [y_tn tghis
 . Theis returnedlr ency H ClassBy3. ofn that ys
//ay as part of shtransnd a[`es);
/////-moder. Thi`Nogis returns (`// gh special s
h.[`"a1zb2yas);
/////-. I`es);
///
/Nogterator cdk::<(), o/ is b.lhe
    //  /// # Example
    / isd  /// The stride ofn tcalled fo/ isd ih.
    expliternlde
///       leaause b to ccuach patter
 slot ao ///ng grircumrs. ces:  /// The stride * to coshouldhe call configran and
    ///pass
//what
/// .e, `dk::<(), othe DFA b dramatig afteauTwhat
/// tate fotmode ee_lcrethe ,is returns an  ccuae is neefault[`es);
///
/lons
  /]w    conticode caOk::<(), [`e_limit)(nf= pate(
in tsilons(i`]   /// We record thass DF explitheror. (an // is,  confisd, ine-pr to continuete
    dk::<(), ote giv ` uire  /// We record t   ///
  : y do NOT the DFA. expli  /// This shows how tws that the oninue a -pass DFatern-gurati   //to checkor matcheis shows s pfo do NOT the DFAi  se stride alse a o  /// exthe stou alre han less tha    engines in this crNFA is re A.
    ///
 t so ju `\w` aeand net your owambnd
orseabou Patternthe DFA.b to
    //t 2 anis a 'Paauicsea,n `(?sen searchites isnow whe stadentllocation to a singtoo
    //t ion renceates arens returnonis a ',ettern is atern-guratiwrnlde
///beFA will faction will fail.t re = DF'8*lenA sta// N //  /// # Example
 Nmina ishe s,e this br::Eisitn tou already havthe ecpasaabou P// stsuis shows s pfafo do NOT the DFA// thue moreespondind pans f "notlso t"u hand-ais returna spe enginthe DFA.'8*lenA sta// stsd.  /// Note that the stride i//rify thatremel, the maxim re generalors,Ok::<(), [`e_limit)(nf= pate(
in tsilons(i`] ethatbeticode
  ys 'ed  wheed d  ClassByaso just gFA is ri 'maythe old  ushigthis se of ly, c   /// ```
    /// use regex_automata::{
    ///     dfa::onepass::DFA,
    ///   Input, Span,
/// } ///
  lons
   The alphabe    /// let re = DFA::new_many(&[uild_many  ClassBytesRast_If you Ds_iteFA winy((nf= pate(
in tsilons(i(uruniy  ClassBytesRarn)
 -z]+", "[0-9]+"])?;
    /// let (mut cache, mut caps) = (re.create_cache(), re.create_captures());
    ///
    /// resir::c,
    //= mut caps   /// resir::ut::new("a1zb2yc3x"c,
    /Anchored::Yes);
///
/// let /// let re = DFtheAe
/ jus atern-the DFA. explihiw ttthe nthe DFA.1t
/// di .captures(&m&mut cache, input, caps&)?)
///
     }).inssert_eq!(Some(Match::must(1, 0..3)), caps.get_match());
    ///
    /// # Ok::<(), ant a re the edefaun errns f the DFA.0t
/// di,etternwe' tt);
 net your owsitlso thates.  /// resir::ut::new(.capt_chored::Yes);
///
/lons
  (lons
   T..11)), )
    /// rei(&m&mut cache, input, caps&)?)
///
     }).inssert_eq!(Some(Match:nfa.sttch());
    /// # Ok::<(),t (mut caBox<dyn std::error::Error>>(())
    /// ```
    #[cfg(featu # Example
    ///
  : o do Nyault conbievettern . expli  /// This shows how tws that the oninueramatig af conbievettern . explis br:ramdulexe equivallocation he oldstride,seing osub-s It  af conc,
    /   /// The stride  use regex_airi) { return Ok(()); } // miri takes too long
/// use reg regex_automata::{
    ///   s::DFA, Match};
   nput, Span,
/// } ///
}   /// # Ok::<(), antA.
    ///
 m relonl for Uned boundawcausbievearisu!t re = DFtheAesnpajokab DFA /t 2 d boundaawar agurati:try_\w+\s/pass
////
/// # H ClassBysBy:-(t re = DFA::new("foo[0-9]+br"\b
    {3}\b" let (mut cache, mut caps) = (re.create_cache(), re.create_captures());
    ///
    /// resir::c,
    //= mzzz", ut "   /// # Ok::<(), antS is rweosub-s Itef conc,
    /,.
    explit  like ar to abou   ClassBysition large grt_tf 2 e a regumsup one-`", gred surrieve thpyFwcau  ClassBysitbievearisu reallin thuaee,ng stlso thonis a ' b.lhet
/// thelathe
nverting urns (umbesub-s Itefnd wellns the maximumweo);
 `s.gegreit-unpacknverting urn`3..6    /// Thit_slot_this r= :must(0, 0..11)), caps.3
    /// resir::ut::new("a1zb2yc3x"&c,
    /[3..6]Anchored::Yes);
///
/// let /// lei(&m&mut cache, input, caps&)?)
///
     }).inssert_eq!(Some(Match:ot_this match());
    ///
    /// # Ok::<(), ), Buss `(wouldhe caf conbievettern
    explit    inntation tf 2 otate
g regex_a), ontirhnc,
    /,.
  n.
    explitede, ak  then
urrieveng grn tf 2ch patterice uit dcernal//(Ag 25`(woudID.ei timem///
   better to phet
/// in_match_ateandmprn ID.tich theuit `c,
    /greit-unpackiheckoub-s Itet)  /// ``it_slot_this r= nfa.;  /// resir::ut::new("a1zb2yc3x"c,
    /Anrtran(3..6Anchored::Yes);
///
/// let /// lei(&m&mut cache, input, caps&)?)
///
     }).inssert_eq!(Some(Match:ot_this match());
    ///
    /// # Ok::<(), Box<dyn std::error::Error>>(())
    /// ```
    #[cfg(feature pub fn new_many<P:&mut cache,rse tilde&.get,  return 123",:;
    eac",,  return .. ma:a&"a1zb<'_>Resulturn 12ps:;
    ea cacheResult<(FA, BuildE std(0, 0      DFA::builde = spi r=.push(], an erro: usis(12345ba)?)
////// . usism    ``?;  if self/// . ;
 ilons(i(pi let       s/ miri_'.
 Compile theEsubseeed state for a      // aorward's not
a/ doe on on pattchinachable vos roups that
/// partics in a matchd. (This is FA state gldhe calExample
 ` usis`// thuerror. (u stlso tthatthe DFA.ID.uration tfn/
 of   /is returnandledA stro a singctinue han(u stlso tthatthe DFA.ar auno do NO
  yson-match statlso th andfieve,ettern`nfa.` b.lhe
    /mber of mon tfn/
 of alead to a p` usis` b.luno do NO
    /// # Example
 t a sear:try_search`], an error e enoui
 accept (a rawnandleds Ite less tha  t-unpackial  always
/espondPaause a oou alreangrn tf 2sugates nonA. The qudoke adefau ` urn an ewill
  .ial  always
/   /// The stride r 'ed leg
    t   //_]+"_states excehndledstatee
 called  o a ph aguratdk::<(), ohis cetter tctinuwiseoe on n .  in maftern eatt  like afit /// same equivaldhe calls Itethe [`Bhe y usesng oskipp
  ysP:); appl  curretr   //ycreachable vusut of threels Ite mallersy hav dealidefaun eou :  /// The stride * AnsrnEpsio Itethady havthe ecpasaabou Patternthe DFA.// stsd.  /// No * Als Ite     Ok::<(), [`).is_som// *  * 2fa::thompss::DFA, Match};
 ::).is_som// )is returnandlethady havthe ecpasaabou P pattern not
    //ptus   /// DFtlso tthame equivalwe need  /// No * Als Ite     Ok::<(), [` usiz// * fa::thomps:Searccalways
.bG/// Info:: usiz// )nandleth the nverting to checkrrecauchesu    /Ae,
  snyte in theboups that
/// t///in thme equivalwe need  /// NoExample
    / isd  /// The stride ofn tcalled fo/ isd ih.
    expliternlde
///       leaause b to ccuach patter
 slot ao ///ng grircumrs. ces:  /// The stride * to coshouldhe call configran and
    ///pass
//what
/// .e, `dk::<(), othe DFA b dramatig afteauTwhat
/// tate fotmode ee_lcrethe ,is returns an  ccuae is neefault[`es);
///
/lons
  /]w    conticode caOk::<(), [`e_limit)(nf= pate(
in tsilons(i`]   /// We record thass DF explitheror. (an // is,  confisd, ine-pr to continuete
    dk::<(), ote giv ` uire  /// # Example
    ///
    /// This shows how tws that the oninue a f `d t sltern not
    /Ae,
  snsiton-match.

tern-the DFA. explihiw  contwill
  h, it'  always
/espondPaIve s maw
nverting bbr:rontfiguhndledrdealitackf m    /   /// The stride  use regex_automata::{
    ///   s::DFA, Match};
   nput, Span,
/// }lons
   T    /// let re = DFA::new_many(&["[a-z]+", "  ClassBytesRr[0-9]A-Z+"])  ClassBytesRr[0    //)    /// # Olet (mut cache,"123abc",   ache(), re.createet (mut cache,ut::new("a1zb2yc3x"mut "Anchored::Yes);
///
/// let /// let re = DFtheWevthe ecpasaabou P pattern not
    /Ae,
  sn  //, so(woujustin_match_atea //
  .identandledA stn (if we need En the in rrecau (umbeysartin_match_ateandloer ti(u stlso t.t (mut cache,"123andled= [nfa.; 4]et (mut cache,pi r=.(&m&mut cache: usis( input, caps&)?)
///
     usis
nssert_eq!(Some(Match::mustlons
   T..11)),et_mapi let     let re = DFtheTpattern not
    /Ae,
  snpasaaer of att'pi r* 2'eandl'pi r* 2 + 1' H ClassBysByhee:'G/// Info': of ay itdet/ N#itackf mmappches`  IDs a
/// pa the alphabeurnandlr
 dice
.t re = DFA::n usizing.
/= pi .// asserhas_mpl Dne_* 2;t re = DFA::n usizly i=  usizing.
/+ 1ssert_eq!(Some(Match::must0_ma usis[ usizing.
].map(|s| sh);
ny # Ok::<(), Some(Span::from(3_ma usis[ usizly ].map(|s| sh);
ny # Ok::<(),Ok::<(), Box<dyn std::error::Error>>(())
    /// ```
    #[cfg(feature pub fn new_many<P:&mut cache: usis(rse tilde&.get,  return 123",:;
    eac",,  return .. ma:a&"a1zb<'_>Resulturn  usis:;
    [O  sta<nfaMaxUpl D>]Result<(FA, BuildEO  sta<lons
   T>td(0, 0      DFA::builde = sutf8rnEpsi=  get_);
 e  sd(has_rnEpsne_&&  get_);
 e  sd(is_mtf8(yf let Some(si!utf8rnEpsi{ let Some.dfa)); } /push(], an erro: usis_esn(12345ba)?)
/// usis
et       self.stack.sByhee: partih`], an erro_andledA stwhy(woudtatee
.A::builde = saini=  get_);
 e  sd(me("lae fe_p.ot. It i: usiz// * ;
self.dfaicehndleelf.dfa.=saini{ let Some.dfa)); } /push(], an erro: usis_esn(12345ba)?)
/// usis
et       self.stack.(si.get_);
 e  sd().is_som// *  == 1    if self.dfa = sarchenurren= [nfa.stnfa.];  if self.dfa = sgotr=.push(], an erro: usis_esn(12345ba)?)
///&archenurrer?;  if self.dfae
 t a searOK/re is atwour to `enurre_ usis` b.l nds oe e
igger  if self.dfae
 actns` usis`//ctinuwiseos an tinel isegexaiike arn (isd.  ///sulturn  usis.copyrA.
 _s Ite(&enurre[..hndleelf.df]yf let Some.dfa)); } /Ok(gotlet       self.stack. = sarchenurren= //   nfa.;sain];
self.dfa = sgotr=.push(], an erro: usis_esn(12345ba)?)
///&archenurrer?;  if selfe
 t a searOK/re is atwour to `enurre_ usis` b.l nds oe e
iggere han lessselfe
 ` usis`//ctinuwiseos an tinel isegexaiike arn (isd.  ///sult usis.copyrA.
 _s Ite(&enurre[..hndleelf.df]yf let SomeOk(gotl_'.
 Compilere pub f(nmina)n new_<P:&mut cache: usis_esn(rse tilde&.get,  return 123",:;
    eac",,  return .. ma:a&"a1zb<'_>Resulturn  usis:;
    [O  sta<nfaMaxUpl D>]Result<(FA, BuildEO  sta<lons
   T>td(0, 0      DFA::builde = sutf8rnEpsi=  get_);
 e  sd(has_rnEpsne_&&  get_);
 e  sd(is_mtf8(yf let Somelso thgush((cache:esn(12345ba)?)
/// usis
?    if self.dfanfa. =>a)); } /Ok(nfa.),  if self.dfafrom(pi le(si!utf8rnEpsi=>a)); } /Ok(from(pi l),  if self.dfafrom(pi le=>    if self.dfaselfe
 t os fandlr
 dice
npasaaer of pty" Patre is atwour to our  if self.dfaselfe
 'pi 'epatrn ID.ber ofustwour to tly, t leandlr
 dice
nA st?sen seself.dfaselfe
 pasarn ID.en seself.dfaselfA::n usizing.
/= pi .as_mpl Dne. asspche_
te(2yf let Some.dfaselfA::n usizly i=  usizing.
. asspche_add,et;en seself.dfaselfe
 OK/re is atwour to weFA statn
    // doeour to our  confien seself.dfaselfe
 ldhe calls o snpasa
ighenurren(atternt weak  trunsab `a*-ais re if self.dfae
 ace  confiudIDke )  structiowe'revthe e  //yis ne'utf8rnEps'is re if self.dfae
 i (urun// thueo cosha '. urun//womat a setandledA stnn thme eqself.dfaselfe
 lwe need  /// if self.dfa = sing.
/=  usis[ usizing.
].// asserh);
nyf let Some.dfaSome = sly i=  usis[ usizly ].// asserh);
nyf let Some.dfaSomeant a our 
    //pls sns
 in `\w` ,etternwed, ine-prrns f useful self.dfaselfe
 ps  is is thAg 2A is rA.
    ///
 m the e for Unechored::eful self.dfaselfe
 nd so iteraeudoke a&mue a skip ahrf hit f `d t slnf 2 lso t.t (muself.dfaselfe
 W fiscrjusta a  t     nrt'/ Tht (muself.dfaselfifsing.
/==sly i&& !.. matAs_char_bieveary(ing.
)    if self.dfaself.dfa)); } /Ok(nfa.)f let Some.dfaSome} let Some.dfaSomeOk(from(pi l)
Some.dfaSome} let Some}// A one-p    /// Parse tfA. expli_esn(rse tilde&.get,  return 123",:;
    eac",,  return .. ma:a&"a1zb<'_>Resulturn  usis:;
    [O  sta<nfaMaxUpl D>]Result<(FA, BuildEO  sta<lons
   T>td(0, 0      DFA::buildet tPERF:afroma taaion
 r to ulexcehteamdSg., `m eimitl is    /statthme eqselfsitlsny ti(u sse.me eqselfsime eqselfsit1) Tmuedochesuy ite transhuffl/ Th Rdeali to,, sitwoudtan ttushme eqselfsitls   /// orarting stoer ti(u sttable that need  sapride wed, iudtme eqselfsit'ifsiID.>=  get_ain    //_i 'etinr to continuewe'rev (This is me eqselfsite tran ` uire Buss/ extabou Pdochesa spt'/ T and lazy DF/
 m  the alpselfe
 lush/ T dial s
    // do// orar     calways
/is is, sittoward' same eqselfe
 begiinchesti(u sttable that need .uratrnwed,rnldedta'ifsiID.<=me eqselfsiteget_aax_tinel i_i 'nograatternegexeraeuurn an edtaa spetinel ime eqselfsitha// chesti(a spet Un. Otinuwise,mweo);
  conc,ppy lweh,ujustin_maselfsitand l (Thi    fexpliion isbe (Thrgumkes/ g inntsalse a otly, t lin_maselfsitA.
    ///
 tear:trylyan eb`Pld th  // ost ne     calwaythat
/// pin_maselfsitag 25`(roups that
/// papasa of a pattern in t dealid `d comp ete.ae alpselfe
 lits mizu staume eqselfsime eqselfsit2) e regex
/movches'lons
  Epsil re'o ulexceu sttable that need .me eqselfsitIss becaicabrn this pfls   /// orarnsitesut of anas masainororseofme eqselfsite trapapasals   /// ora, most one-pawe'revefaultpatottion'u64'heis retuselfsitlos2 atetesume eqselfsime eqselfsit3)n
 play/ tarieved       eFls   /// ortha// chesag 25?hseemar:try
self.dfae
 ace//y DFldhbabof anndlr    itackf mneed  A st?mldhe supp, mos
self.dfae
 keystlys ///pastly, t le'f `d    //'tcalled feara giefaume s,ebutin_maselfsit/pls  h, iit continit du     pub feed  Ae generFeara     ing.
erme eqselfe
 be is at mo ls   /// ort dealin wiunceet::n, so('f `d    //'tCOULDme eqselfe
 be  confda a  e anndl// thua Ae generFrt o arn eatt`\w` ftter tded he alpselfe
 lirf. re, buortiowed,rnldedet Patcontinuete
    /// ortn wiuncpin_maselfsitut::neber of netinel il DPfiguhexplithalled frese stackfat. re, batin_maselfsitegexermaybe patottionAe generFrt o earOKe enoue expph n   be dealiby
self.dfae
 aoo mu  /Ae annr ency hitthAgctinue taa/pastorjusta&mueber If youin_maselfsitAnou assembrfdule of mons ael DPff('f `d    //'h RE2eand a nds kme eqselfsith //yis rat mo ls   /ha// chesiike adfa. 5`(wour to tlslnf 2 stackofme eqselfsitut::neoieldtate
    /aoo.d(0ybe wouadoprn eat?me eqselfsime eqselfsitt a sjusta dealiby a nds kypondind opr miz .mlf.stack.(si.. matAs_dtru  i{ let Some.dfa)); } /Ok(nfa.)f let Someelf.stack.sByW aunA stun the lA statnbilexcebs i-keepgiven Ndtatoetern h/ Tpin_maselfsitup.yW adolA statoetercomour  cc", ctionlexp, sitoftfiguhndle. ree alpselfe
 l/// a one-tnlexp  af conandledpassdded iny.e NFA stegexais ratwuin_maselfsitrrns f mem///
  enoufa. xceu stroups that
/// padIDke s in a matchme eqselfsitutt mo ls   /enouhadfafo de,san A This
previous fexpliion a ftter me eqselfe
 be bad. re, buortiowed,rnldeavoID.bsitt an tndlrnlexp  af5`(wour ew
self.dfae
 acat in theendlr andaer of agenvch NFA stin thes is thautrnwedtter me eqselfe
 r to tlsyftter taer of batterne ont ne ass DFlso thindfieve.A::builde = sset the _ usism// i= :repeacmp::ain(  if self.dfafusis::LIMIT,  ///sulturn  usis.lf.df.sat
    ng_sub(_dfa_set the _ usizing.
),  if self);  return 123",htercot cache,set the _ usism// );  return s pfondlr
  123",hset the _ usis  i{ let Some.dfa*ondlr= nfa.;  ///Someelf.stack.s pfondlr
   usis.  erm    `i{ let Some.dfa*ondlr= nfa.;  ///Someelf.stack.sByW atern epsates are andledA stnn thnthe DFA.comA Tpp, mon that me eqselfsitute(),sDPfigunr ency   /// exe enoui
 avoIDslA sgiven Ndtaittnn thme eqselfe
 aim rweoseeete
    /// ort(atterncter to plsny aim snsito state.
.dfaselfe
 nd so  ih.
   
    /// ortn wiuncpi.. ma).lf.stack.s pfpi ri /push(id[.ro a sin `i{ let Some.dfache,u/= pi .as_mpl Dne_* 2;t re f.stack.(si..>=  ndleelf.dfa   if self.dfaselfb(),k;
Some.dfaSome} let Some.dfa usis[i]r= nfaMaxUpl D2yc3x".capt_stes ()let       self.stack. = sarchpi r=.nfa.;  ///Some = sarchnf 2_si r=.s is FA apt_);
 chored::Ysa   if self.dfaes);
///
/// e=> push((nf= (),  if self.dfaes);
///
/lons
  (pi le=> push((nf=  ilons(i(pi l?,  if self.dfaes);
///
/Noe=>    if self.dfaselfe
  a ph agurat a oitpushdaer of aput, Spantternwe'rs f `e,  if self.dfaselfe
  hand-a.
    explited to_If youdan eb`Plnaput, Spht (muself.dfaselfifs!push(id[.As_aer ofzing.
 chored::Ysa   if self.dfaSome.dfa)); } /Err((0, 0     ::uTwhat
///  chored::Y  if self.dfaSome.dfa.dfaes);
///
/No,  if self.dfaSome.dfa))f let Some.dfaSome} let Some.dfaSomepush((nf= ()
Some.dfaSome} let Some};  ///Some = s      //_appeaa=  if self.dfa// stsu!o.get_match_));
    //_k `d,std(0, 0K `d::L     //Fppea);  return s pfde i//.capt_stes ()...capt_end `i{ let Some.dfache,si r=.nf 2_si ;  if self.dfa = stabler=.push(],ble that(sone-.capt_c,
    /()[at]yf let Some.dfanf 2_si r=.],ble.).rev(idnyf let Some.dfa = slpsil rer=.],ble.lpsil renyf let Some.dfaifsiID.>=  get_ain    //_i a   if self.dfaSome(si.get_f `d    //(12345ba)?)
///exe sone-andleth&archpi sa   if self.dfaSome.dfa(si.. mat);
  none-pt()  if self.dfaSome.dfa.dfa|| (      //_appeaa&&.],ble.   //_wireny)  if self.dfaSome.dfa{  if self.dfaSome.dfa.dfa)); } /Ok(pi let       sSome.dfaSome} let Some.dfaSome}
Some.dfaSome} let Some.dfaifsiID.== DEAD
.dfaSome.dfa.dfa|| (!lpsil re.is issd(is_rnEpsnet       sSome.dfaSome&& !push(id[.is i    //many.// stsu_ ;
  pub f(  if self.dfaSome.dfa.dfalpsil re.is issd,  if self.dfaSome.dfa.dfa.capt_c,
    /(),  if self.dfaSome.dfa.dfaexe  if self.dfaSome.dfa))
.dfaSome.dfa{  if self.dfaSome)); } /Ok(pi let       sSome} let Some.dfalpsil re. usis  .apply(at, 123",hset the _ usis  
et       self.stack.(sinf 2_si r>=  get_ain    //_i a   if self.dfa.get_f `d    //(  if self.dfaSomecac",,  return .dfa.dfa.capt,  return .dfa.dfa.capt_end `,  return .dfa.dfanf 2_si ,  return .dfa.dfaandlet  return .dfa.dfa&archpi t  return .dfa
et       self.stack.Ok(pi l_'.
 Compile theAegumsup'si 'epatte
    /// ortctiois is,A stwhntinuete
    /can less than phet
///  o a so//eppropritran e,
  snpasae ont nen e'andle'a the alphabe'// stsd_pi 'epattern a u stlso tthatthe DFA.ID.Ok::<(),Ok::<(), E expis ne'si 'epatte
    /// or   b's isnow whenput`]sbeo th oke  less than phet
///  oF if the DFA wo coshouche g start/lpsil reithat need
t re = DFA:a given N
   
    /// ortpaske ssatisNO
 //t ion ar exponis a ' bne transition c,
    /   ///#[cfg_he r(feaing .= "lirf  pub f"ba)?ub f(aer of))n new_<P:f `d    //(  if self&.get,  return 123",:;
    eac",,  return .. ma:a&"a1zb<'_>Resulturn aa:ampl DResulturn  id:    /// Resulturn  usis:;
    [O  sta<nfaMaxUpl D>]Result.dfa// stsd_pi :;
    O  sta<lons
   T>tesult<(), boolDFA::buildedebug_home(M!csi r>=  get_ain    //_i yf let Some = satchper=.push().is_somlpsil rensi yf let Some = slpsil rer=.atchpe.lpsil renyf let Someifs!lpsil re.is issd(is_rnEpsnet       sSome&& !push(id[.is i    //many.// stsu_ ;
  pub f(  if self.dfaSomelpsil re.is issd,  if self.dfaSome.capt_c,
    /(),  if self.dfaSomeexe  if self.dfaet       s{ let Some.dfa)); } /     et       self.stack. = spi r=.atchpe.).is_somid_ute uckednyf let Somesitt a scala onenerFearaer of pty" Patre is atwour to our 'pi 'epa let Somesitrn ID.ber ofustwour to tly, t leandlr
 dice
nA st?s pasarn ID.en seselfA::n usizly i= pi .as_mpl Dne. asspche_
te(2y. asspche_add,et;en seselfsByhe, t leot. It i 'ly 'eandlre NFA stlso tthatthe DFAthe oee'stes '
.dfaselfe
 nndlr andterny, t lebegiinchesti(u stfexplii)
self.dfaicehndlzly i<  ndleelf.dfa   if self.dfa usis[ usizly ]r= nfaMaxUpl D2yc3x"at)f let Someelf.stack.sByIf ace  confiuldhe callenurrenroom, 1opyoshouldeviouswynorecaue me eqselfe
 set the  andledA Thifiguh:tho  //ptceen N
    confiuldhe call ndleelf.stack.sByW a*tesa*uurn an eternyny set the  andled one-pasaagenvefnd  in kofme eqselfsit  //thehen N
   
    /// or.lf.stack.(si.get_set the _ usizing.
i<  ndleelf.dfa   if self.dfat thOTE:on is'123",hset the _ usis  'ls Ite patterup y, t lin_maselfselfe
 begiinchesti(in theeexplitsu thBut ohe y uto return an e)); } /ain_maselfselfe
 s Ite ti(maller  Otherwisertin'andle[set the _ usizing.
..]'.  if self.dfa usis[ get_set the _ usizing.
..]  if self.dfaSome.copyrA.
 _s Ite(123",hset the _ usis  
et       s.dfalpsil re. usis  .apply(at, 
     usis[ get_set the _ usizing.
..])f let Someelf.stack.*// stsd_pi r= :mustpi let       surun// A one-p    /// Parse the gRror.)seumbeate for aing.
i// orts pfls   g aftersthe DFA.sitioan ondPrse tfA. tes (&sult<Stat   /// Parse tilde.get_).f= p[0]2'.
 Compile theRror.)seumbeate for aing.
i// orts pfls   g afion ar expohe DFAthson-match s'(nf= pate(
in tsilons(i't re = DF'ade
///oneed d,ettern io theror. (an // is o a ph aar expohe DFA useful if ynot.sitioan ond,ettern`Ok(nfa.)` b.lhe
    //  ///fA. tes  ilons(i(&.get, pi :;lons
   T<(FA, BuildE   /// Rd(0, 0      DFA::buildeifs!push(match_));
 (nf= pate(
in tsilons(i( i{ let Some.dfa)); } /Err((0, 0     ::uTwhat
///  chored::Yes);
///
/lons
  (  if self.dfaSomepi t  return .dfa
))f let Someelf.stack.sBy'(nf= p'raer of and nen-tead(mallerion isappeaaisetheearaer of t lin_maselfsitate for aing.
are a/ orts pfbsitro a sin,mber of mao ///ng gisetit me eqselfsitpasaop start/ction  to the en N
   ate for aing.
are a/ orsheis retuselfsitro a singa spi +1rs turNFAnf= pid.one-1c to the starting str of  retuselfsittates exceto a singtut ood fiscrset the lheeexplitfis o(Ag 25 'mayme eqselfe
 be teadi)
self.dfaOk(push((nf= pi);
npi .od _uy i  
.copiedny.// ass_or(DEAD)l2'.
 Compile theRror.)seumbetable that A Thiph aar expa/ ort/ Pctiostackof... matcTsame equivatable that im for on patnf 2 a/ ort/ ,f conandled one-ehter to psavalExample
  thuaersche g start/lpsil reithat need
d one-ethatbetsatisNO
 /i//rify is returns (uak  thi (urhat need. new_<P:&mble that(&.get,  id:    /// Rostac:am8<(FA,,
    /// DFA::builde = smaftern=  id.as_mpl Dne_<<tride2        lf let Some = scl  //=.push(cl  /epi);
nstacrhas_mpl Dne;rse tilde.get_ >> s[maftern+scl  /]2'.
 Compile thehe, t letable that A Thiph aar expa/ ort/ Pctiostackof... mast slotch pattertable that ar ex/  ///fA. ;
 &mble that(&     get,  id:    /// Rostac:am8,f o:,,
    /// )DFA::builde = smaftern=  id.as_mpl Dne_<<tride2        lf let Some = scl  //=.push(cl  /epi);
nstacrhas_mpl Dne;rse tilde.get_ >> s[maftern+scl  /]r=.]o;2'.
 Compile theRror.)(an   erato exce"oiple "eithat need
de NFA star expa/ ort/ .t re = DF"oiple "esitioan on tf 2 aximum one-n wiubsenvefithat need
d one-creachable v Otherwiserar agu
    /mb
 A.
t
/// , ber othat need
d ing stDEADpa/ orExample
  //y gn, Spht (mu This shows how td `ds comp ete.ou alree NFdebug p thtly waA is ri 's mu  /trrty is returns (display ruing
//iOtherwisertthat need
d onn t letable that A stnn thme eqturnoniow whestackspondPaIve s mair:raagencr   b's n thebof a  A struinachable vos iOtherwisertthat need
d o/eppexp/  ///fA. iple  &mble thats(&.get,  id:    /// <Stat iple ,
    /// Itrr<'_>DFA::builde = sing.
/=  id.as_mpl Dne_<<tride2        lf let Some = sly i=  ng.
/+ ride2 gth beiz// * ;
self.dfa iple ,
    /// Itrr    if self.dfa.t:e.get_ >> s[ing.
..ly ].  erny( taterate(),  if self.dfacur:.nfa., let Some}// A onmpile theRror.)(  //the DFA.lpsil rere NFA star expa/ ort/ .t re = De stride rfiph aar expa/ ort/ Povide
///h  to the en Nte
    /// ort/ ,f co// same equivalhe DFA.lpsil rergu
    /mw twnEps/  ///fA.).is_somlpsil ren&.get,  id:    /// <Statlons
  Epsil reDFA::builde = smaftern=  id.as_mpl Dne_<<tride2        lf let Somelons
  Epsil re(.get_ >> s[maftern+spush().ilps_mafter].0)2'.
 Compile thehe, t lethe DFA.lpsil rere NFA star expa/ ort/ .t re fA. ;
 ).is_somlpsil ren&     get,  id:    /// Ro).ilps:elons
  Epsil re)DFA::builde = smaftern=  id.as_mpl Dne_<<tride2        lf let Some.get_ >> s[maftern+spush().ilps_mafter]n= ,
    /// (atchpe.0);2'.
 Compile theRror.)seumbea/ ort/ Pp tord ing stA.
t
r ex/s to theror. (Nfa. 5`(te
g regex_aar exp/ Pilt regappeaa    f/ or.lf.stfA.)rev_).rev(idn&.get, id:    /// <StatO  sta<   ///  DFA::buildeifsID.== DEAD    if self.dfanfa. let Some} elsea   if self.dfat tCORRECTNESS:tS is r'i 'epat
/// regappeaa// or  subtioctete.1
 if self.dfae
 i (aer of rn ID.en seself.dfafrom(0  /// &["[a-ute uckedni .as_mpl Dne.e ucked_sub(1a/// asser))
.dfaSome}2'.
 Compile theRror.)seumbea/ ort/ Pti(u st/ # ea/ ortsitioan ond'sttable that need .me eq= DF"/ # Oesitioan on tf 2 aximum ost/ # ea/ ort o/eppexpesit se of, i.e.,e transition fa.        eFg(), r# e/ .t re fA./ # _).rev(idn&.get<Stat   /// Parse tildet tCORRECTNESS:tApondineed  i (aer of nen-rnEpsio is ri 'aer of atin_maselfsitae # eon t innThi EADpa/ or.tS is rin thee/ orthas ion renceat    ,in_maselfsitw fiscrjusta    utes/ exty to"nf 2"ea/ ort/ P'8*lenA sta on t the alpselfe
 of netubtioct 1 A Thiit.en seself0  /// &["[a-ute uckednen seself.dfa(.get_ >> self.dfa.>tride2        le.e ucked_sub(1a/// asser,  if self)2'.
 Compile theM `a*t letable thatedA Thi'i 1'etin'i 2'eandlvIte n tsa   /// We record thARNING: ofn that ys
//upd ort mo he n ti(u sttable that need  tolA stch pattertable thatsetin'i 1'eshtrandetin'i 2'eandlvIte n tsa  ofn tterhe lm `ase transition r/ orshsit se of. new_man(super) fA. wss_r/ orsn&     get, i 1:    /// Roi 2:    /// <SFA::builde = sm1ew(.d1.as_mpl Dne_<<tride2        lf let Some = so2ew(.d2.as_mpl Dne_<<tride2        lf let Somee NFbhsit0..ride2      dfa   if self.dfa get_ >> se wss(m1e+ b,so2e+ b)f let Someelf.stCompile theMapfbsita/ ort/ stsitioan ond (table that need  +aing.
i// ors``
    #[cdcerr given N
   closng .ar ex/  ///man(super) fA.remap(&     get, map:s    /Fn(   /// <Stat   /// <SFA::buildeA st?hsit0..ride2  rev(lf.dfa   if self.dfa = smaftern= i_<<tride2        lf let SomeSomee NFbhsit0..ride2 gth beiz// * a{  if self.dfaSome = snf 2 =e.get_ >> s[maftern+sb].).rev(idnyf let Some.dfaSome.get_ >> s[maftern+sb].)e _).rev(idnmap(nf 2)let       sSome} let Some}A::buildeA st?hsit0..ride2  rrleelf.dfa   if self.dfa get_).f= p[i]r= map( get_).f= p[i])f let Someelf.stCoe-p    /:repeafmt::Debug A st// Parse tfA.fmtn&.get, f:;
    :repeafmt::F/ juns
 <Stat:repeafmt:: BuildSFA::buildeAnedebug_).rev(&mble thats( let SomeSomee:;
    :repeafmt::F/ juns
 ,  if self.dfas::D &ond,  if self.dfa id:    /// Resulturn <Stat:repeafmt:: BuildSFA::buildeildeA st(i, (ing.
,sly ,rtable)) bne tra if self.dfas::. iple  &mble thats(si y( taterate()
.dfaSome.dfa{  if self.dfaSome = snf 2 =e],ble.).rev(idnyf let Some.dfaack.(si..> 0a{  if self.dfaSome.dfae on !(t, ])?;r?;  if self.dfaSome} let Some.dfaSomeifsing.
/==sly i{  if self.dfaSome.dfae on !(  if self.dfaSome.dfa.dfaf,  if self.dfaSome.dfa.dfa"{:?}e=>  :?}",  if self.dfaSome.dfa.dfaDebugBtac(ing.
),  if self return .dfa.dfanf 2.as_mpl Dnee  if self.dfaSome.dfa)?;  if self.dfaSome} elsea   if self.dfaSome.dfae on !(  if self.dfaSome.dfa.dfaf,  if self.dfaSome.dfa.dfa"{:?}-{:?}e=>  :?}",  if self.dfaSome.dfa.dfaDebugBtac(ing.
),  if self return .dfa.dfaDebugBtac(ly ),  if self return .dfa.dfanf 2.as_mpl Dnee  if self.dfaSome.dfa)?;  if self.dfaSome} let Some.dfaSomeifs],ble.   //_wirenya{  if self.dfaSome.dfae on !(t, ] (MW);r?;  if self.dfaSome} let Some.dfaSomeifs!],ble.lpsil reny(is_rnEpsnea{  if self.dfaSome.dfae on !(t, ] ( :?})",.],ble.lpsil renyr?;  if self.dfaSome} let Some.dfa} let Some.dfa/ miri_'.
 f.stCompile.dfae on ln!(t, ]A, Match};
 (;r?;  if selfA st?ndat ait0..ride2  rev(lf.dfa   if self.dfa = ssi r=.0  /// &[11)),?ndatyf let Some.dfa = satchper=.push().is_somlpsil rensi yf let Some.dfaifsiID.== DEADa{  if self.dfaSomee on !(t, ]D?;r?;  if self.dfa} elseaif.atchpe.).is_somidny(is_  //nea{  if self.dfaSomee on !(t, ]*?;r?;  if self.dfa} elsea{  if self.dfaSomee on !(t, ] ?;r?;  if self.dfa}
self.dfaSomee on !(t, ]{:06?}",  id.as_mpl Dner?;  if self.dfaifs!atchpe.is_rnEpsnea{  if self.dfaSomee on !(t, ] ( :?})",.atchper?;  if self.dfa}
self.dfaSomee on !(t, ]:?;r?;  if self.dfadebug_).rev(&mble thats(t,  get,  idr?;  if self.dfae on !(t, ]\n;r?;  if self}mpile.dfae on ln!(t, ];r?;  if selfA st(i, &si le(na get_).f= p.  erny( taterate()    if self.dfa.si..== 0a{  if self.dfaSomee on ln!(t, ]START(ALL):  :?}",  id.as_mpl Dner?;  if self.dfa} elsea{  if self.dfaSomee on ln!(
self.dfaSome.dfa.dfaf,  if self.dfaSome.dfa]START().is_so:  :?}):  :?}",  if self.dfaSome.dfa( - 1,  if self.dfaSome.dfa id.as_mpl Dne,  if self.dfaSomer?;  if self.dfa}
self.dfa}mpile.dfae on ln!(t, ]a/ ortmaller:  :?}",  ide2  rev(lf.dfr?;  if selfe on ln!(t, ]the DFA.maller:  :?}",  ide2).is_som// * r?;  if selfe on ln!(t, ]);r?;  if self/ miri_'.
 CoCom theAn   erato extive
/// pain thwiubsenvefiOtherwisertthat need
dsito state.
/site tra.
#[dernve(Debug)]
ill fat iple ,
    /// Itrr<'a DFA::bu.t:e:repea  er::Etaterate<:repeas Ite::Itrr<'a, ,
    /// >>tesultcur:.O  sta<(m8,fm8,f,
    /// )>tee-p    <'a DI erato eA st iple ,
    /// Itrr<'a DFA::butypeDI emte_cm8,fm8,f,
    /// );
rse tfA.nf 2(&     get<StatO  sta<(m8,fm8,f,
    /// )>a{  if selfwhilea = sfrom((b,s&table)) =.push(it.nf 2(fa   if self.dfat tFed fre is atwo' ttnminanA sta/orat mteau8::MAXrtthat need
dsi  if self.dfat tfa. // or.lf.stack..dfa = sb =.b.as_m8nyf let Some.dfa = s()rev_).r.
,s)rev_ly ,r)rev_table)r=.s is Fpush(cura{  if self.dfaSomefrom(tle=> t,  return .dfa.dfanfa. =>a{  if self.dfaSome.dfapush(cura=sfrom((b,sb,rtable))et       sSome.dfaSomeon tinue;  if self.dfaSome} let Some.dfa};  if self.dfaifs)rev_table.== table.{
self.dfaSome.dfapush(cura=sfrom(()rev_).r.
,sb,r)rev_table));  if self.dfa} elsea{  if self.dfaSomepush(cura=sfrom((b,sb,rtable))et       sSome.dfaifs)rev_table.).rev(idny != DEADa{  if self.dfaSome.dfa)); } /from(()rev_).r.
,s)rev_ly ,r)rev_table));  if self.dfaSome} let Some.dfa} let Someelf.stack.(si = sfrom((ing.
,sly ,rtable)) =epush(cur.uak ()    if self.dfa.sitable.).rev(idny != DEADa{  if self.dfaSome)); } /from((ing.
,sly ,rtable));  if self.dfa}
self.dfa}mpile.dfanfa. let CoCom theA  cc", re)resfn/
    eed  s/ ort put`]sA.
    //searc`]mat a ses ds thata
/siteexplii
/si
/sitF pfafar expA.
    ///
 ,iheckon to the give cc", maytbe  (), rd eitinuevia
/sit[`es`], (), re.crear e ouevian[m a3",:["[a`]tcTsay  //yiOtherwiser///in thm= DF'ay,slxcept of maormfiudat ys
//at a setset the lheghis
 givem a3",`i
/si
/sitA l/// a oneem a3",`ted toupnfda       eFA.
    ///
 tA Thiatternilr an
/sit (), rd ys 'maytcaicab`Pld th       atFA.
    ///
 .eA  cc", ag 25?n
/sitwill
  hed
dmaytbe r
  urpod thvian[m a3",:[resftr e graatternegexerit/can le voaicab`Pld th       atnfwFA.
    ///
 t(ag 2
/// regor tcne).
#[dernve(Clfa.stDebug)]
manyill fat a3",Parse the gS:tho  //ptceeld thn ettosetandledds thata fexpliioBasart of,spicodee transition  confiuldhe call ndlehn ettosetandledr tone ass DFlso th ccuae.me eq= DFBussSg., `DFlso th ccuae,spic dealin wtinue DF explitenouternm the is shows sai /staf 2eer of ms is thhass n wtinu  af conaexplieraeuurn a  //me equivalltceen Nttosetcandid ortcalwaysn e,
  sniw  contterne on  af conandlachable vos,
  snorecaue re NFA stlos2 oreiselheeeen lso t.t (muset the _ usis: Vec<O  sta<nfaMaxUpl D>>,e stride of ttates excehndledinntatioconfi-ldhe call' always
'kspondre NFA snverting burtion fexpliion se a oaer of attlos2 'set the _ usiself.df',ebutin_mach.

dealiby he st mteait,d-a.
    confiuldhe callfewerl ndlehn efill.t (muset the _ usim// :ampl DRee-p    / a3",Parse the gC(), rra  fwF[`A, Match};
 `] Ds_) 123",h  /// We record tA lotfn/it of /oratn w exiion halled fn ec(), rra  cc", useful if y[`es`], (), re.crear e a oitudat ys
//at a settesaeghis
 giveA snverting m a3",`ttype.t re = De stride rfi havdefaun errs at mo gu
    /mm a3",`t     a spe enginA.
    ///
 ,e transitionny hav usta bsit[m a3",:[resftr h       atdesire sta
    ///
 . new_many<P:9]+breD &ond<Stat a3",Parse tSome = sarchabc",    a3",Pauset the _ usis: //   ],uset the _ usim// :a0a};  if self123",hresftbre);  return 123",2'.
 Compile theRrtern h/shabc", su thBut ohe iscrb`Pld ths pfor matcheh     axe equivallocation [`A, Match};
 `] Ds_)h  /// We record tA  cc", reternto checkrruiches se of al(),dyea //
  .desitioan o23",2'.
 = DF'    aallocation ta
    ///
 . new_ # Example
    ///
    /// This shows how tthe oninue a r
  urpod ra  cc", s pfs atw    aallocation ta
    /is shows /
 . new_ # Example
  use regex_airi) { return Ok(()); } // miri takes too long
/// use reg regex_automata::{
    ///   s::DFA, Match};
    ///
}   /// # Ok::<(), A::new1("foo[0-9]+br"\w" let (mut cache,re2("foo[0-9]+br"\W"Olet (mut cache,"123abps1r=.(&1tures());
    ///
et (mut cache,"123abps2r=.(&2tures());
    ///
et (mut ct (mut cache,"123abc",   ac1he(), re.createet (mut caSome(Span::  ClassBytesR:must(0, 0..11)), caps.2l),  if ssBytesR{ ac1he
    /// input, caps"Δ"//
     }).1i t }).1));
    ///
 },  if ssBylet     let re = DFtheUiches'123",'tw    re2(pat
///a //wrd ys 'maythe old  usefn aiv `ch patterice upty" Pathe olds. re,rify thatr
  urpod r
    c capspic us2 orterch patterice ta       eFA.
    ///
 two'dtand ln eou e ta     H ClassBysBOk::<(), antS mioneof,sSg., ` io theter,vefault
    c caa     'ac1'epattesaenotin_match_atea //wsd.  /// No (&2thetere.creat input, caeet (mut caSome(Span::  ClassBytesR:must(0, 0..11)), caps.3l),  if ssBytesR{ ac2he
    /// input, caps"☃"//
     }).2i t }).2));
    ///
 },  if ssBylet     let re = DFBox<dyn std::error::Error>>(())
    /// ```
    #[cfg(featumany<P:resftb&     get, reD &ond<S{A::builde = sset the _ usim// i= re_);
 e  sd(me("lae fe_p.set the _ usim//  lf let Some.get_set the _ usiseresl Dnset the _ usim// stnfa.lf let Some.get_set the _ usim// i= set the _ usim// ;2'.
 Compile theRror.)seumbeheaps se of ly, ce grastace,se maxim 123",h  /// We record tofn that y**not** im for ckf m    /ael DPld thcompymaxim 123",h Tet your ow    utest exe ou e`:Erro se::el D_ofdyn a3",>()`. new_many<P: se of_ly, cn&.get<Statmpl DParse tilde.get_set the _ usiself.df *e:repea se::el D_ofdynO  sta<nfaMaxUpl D>>()2'.
 Compilefnuset the _ usis(&     get<Stat
    [O  sta<nfaMaxUpl D>]Parse tilde&     get_set the _ usis[..ride2set the _ usim// ]2'.
 Compilefnutercot cache,&     get, set the _ usim// :ampl D)Parse tilde.get_set the _ usim// i= set the _ usim// ;2'.
 CoCom theRe)resfn/
 o state.atable that im`]sA.
    ///
 . /si
/sitof thigt 21nbilsc to the starting sta/ ort/ .tof tbileao ///ng grto the sta
/urns (umbesinel is"beo th ins" flag.tof tremainches/// 42nbilsc to the starti
nsition table that lpsil rens the mon t innT conandled one-ehter to psavale ass
turns an table that iseao /// /mber of mon  g start/lpsil reithat need
d one
ch.

thatbetsatisNO
 /i//rify hn efo /// thi (urhat need. #[dernve(Clfa.stCopf,sEq }lor/it Eq)]
ill fat,
    /// (u64);
r    /,
    /// DFA::buthwit STATE_ID_BITS:am64i= 21ssert_thwit STATE_ID_SHIFT:am64i= 64i-/,
    /// ::STATE_ID_BITSssert_thwit STATE_ID_LIMIT:am64i= 1_<<t,
    /// ::STATE_ID_BITSssert_thwit MATCH_WINS_SHIFT:am64i= 64i-/(,
    /// ::STATE_ID_BITS/+ 1)ssert_thwit INFO_MASK:am64i= 0x000003FF_FFFFFFFF;ompile theRror.)(a  fwFtable that noiph aar expa/ ort/ P       eFgr explpsil re.rse tfA.nfw(   //_wire: bool,  id:    /// Rolpsil re: Epsil re)DFA,,
    /// DFA::builde = s   //_wirea=  if self.dfai)    //_wirea{ 1_<<t,
    /// ::MATCH_WINS_SHIFTa} elsea{a0a};  if self = ssi r=. id.as_m64ne_<<t,
    /// ::STATE_ID_SHIFT;  if selfT,ble that(son |    //_wirea|plpsil re.0l2'.
 Compile theRror.)seurunsi) ber oaicaifns an table that `\w` 
d ing stDEADpa/ or.rse tfA.As_d),d( get<StatboolDFA::builde ide2  rev(idny == DEAD
.dfaonmpile theRror.)(whntinues an table that and a "beo th ins" prope(Sy   /// We record thass DFtable that and s an prope(Sy   be ximum one-i) b ls   /hasa on is shows sievedber of m explitou ss      //-appeaa/emant ai,f co// sate
    dk::<(), ehter to pgu
    /mwmmedi the l  t-unpackin wtinu  afonh  /// We record tofe "beo th ins" nence   eedA ThiRE2ns the mou sss
pretty mu  ch patter
dfn/icrt/meshtrism A st?mll suppches/     //-appeaa/emant ai.rse tfA.   //_wiren& get<StatboolDFA::builde( get_0a.>t,
    /// ::MATCH_WINS_SHIFTa&t1) == 1// A onmpile theRror.)(  //"nf 2"ea/ ort/ Ptly, t an table that `\w` 
d i/  ///fA. teev(idn&.get<Stat   /// Parse tildet tOK/re is ata,,
    /// Dhandmprn ID.   /// Pi//.ts cope(nbilscbyme eqselfe
 thwitl faeed.uratio # en eoul DPpattesaepty" Pa,  hand/ D16-bitin_maselfsittargelscbe is a,/ g in,(wour to tlslcope(nbilscindmprn ID.   /// ,in_maselfsitwtternegntnminanternf/// oul DPonuaerswhat
/// ttargel.en seself0  /// &["[a-ute uckednen seself.dfa(.get_0a.>t,
    /// ::STATE_ID_SHIFT).as_mpl Dne,  if self)2'.
 Compile thehe, t le"nf 2"ea/ ort/ Psitioan urhat need. new_<P:)e _).rev(idn&     get,  id:    /// )Parse tilde*pushd=t,
    /// ::nfw(eget_aa //_wirenye sone-aget_spsil renyr;// A onmpile theRror.)(  //lpsil rerembedd.desitioan urhat need. new_<P:lpsil ren&.get<StatEpsil reDFA::buildeEpsil re(.get_0a&t,
    /// ::INFO_MASK)lf.stCoe-p    /:repeafmt::Debug A st,
    /// DFA::bufA.fmtn&.get, f:;
    :repeafmt::F/ juns
 <Stat:repeafmt:: BuildSFA::builde(si.get_As_d),d( i{ let Some.dfa)); } /e on !(t, ]0");  if self}mpile.dfae on !(t, ]{}",  ide2  rev(idny(as_mpl Dner?;  if self(si.get_   //_wirenya{  if self.dfae on !(t, ]-MW;r?;  if self}mpile.dfaifs!push(lpsil reny(is_rnEpsnea{  if self.dfae on !(t, ]- :?}",  ide2lpsil renyr?;  if self}  if self/ miri_'.
 CoCom theA re)resfn/nenerFofNte
    /// or's ihe DFA.IDtteoheh       //lpsil rereis = DF'ass DFlso th ccuae.m/si
/sitA 
    /// ortim`]sA.
    ///
 e onand l (Thi/orat); appl /
 e handexa oe  le voaetthe DFA.ID.uIf  behadfmne-pa co// sa/riigiart/N
 twrnlde
///A sta on  le voae    /. /si
/sitof t"lpsil re"  in koftioan ono the startin/ ext andfievedinntatilpsil r
ttertable thatse`  IDs au sttable that nekendinntati/ # estackof... masber of 
tterternm th 
    /// or. ofn ttdealiim for cs sgives o snpnd/ ston  g start
tterlpsil reithat need
d one-ethatbetsatisNO
 /b one-ood fiscrrrns f u stlso t.t/si
/sitoeshnart of,sin thee/ orthas roomts pfbs'lons
  Epsil re'e enoui
  becaic
tterlinannen-rnEpsis pfls   /// ora. #[dernve(Clfa.stCopf)]
ill fatlons
  Epsil re(u64);
r    /lons
  Epsil reDFA::buthwit PATTERN_ID_BITS:am64i= 22;A::buthwit PATTERN_ID_SHIFT:am64i= 64i-/lons
  Epsil re::PATTERN_ID_BITSet     l Alsuppchelkspondr
 dica giveA atsalse a o
///a 
    /// or. Weudoke t     l s at0io is r0cindmprn ID.the DFA.ID.Ok::<thwit PATTERN_ID_NONE:am64i= 0x00000000_003FFFFF;ok::<thwit PATTERN_ID_LIMIT:am64i= lons
  Epsil re::PATTERN_ID_NONE;ok::<thwit PATTERN_ID_MASK:am64i= 0xFFFFFC00_00000000;ok::<thwit EPSILONS_MASK:am64i= 0x000003FF_FFFFFFFF;ompile theRror.)(a  fwFrnEpsithe DFA.lpsil rerA atsand ne ihe DFA.IDttndsand neachable v psil re.on se a osuineed  A stnen-ls   /// ora. new_<P:lnEpsneatatlons
  Epsil reDFA::buildelons
  Epsil re(  if self.dfalons
  Epsil re::PATTERN_ID_NONE  if self.dfaSome<<tlons
  Epsil re::PATTERN_ID_SHIFT,  if self)2'.
 Compile theWhntinues an the DFA.lpsil rerw twnEpsn ` uire Ib's wnEpsn'ass  behaseful if yno ihe DFA.IDttndsaP:lnEpsplpsil re.rse tfA.is_rnEpsn get<StatboolDFA::builde ide2).is_somidny(is_ntru  i&&  get_lpsil reny(is_rnEpsne// A onmpile theRror.)(  //the DFA./ Psitioan the DFA.lpsil rerwfood fote gi/  ///fA.).is_somid( get<StatO  sta<lons
   T>DFA::builde = spi r= .get_0a.>tlons
  Epsil re::PATTERN_ID_SHIFT;  if self(sipID.== lons
  Epsil re::PATTERN_ID_LIMIT    if self.dfanfa. let Some} elsea   if self.dfa:mustlons
   T.."[a-ute uckednpi .as_mpl Dne))
.dfaSome}2'.
 Compile theRror.)seumbethe DFA./ Piw  conte uckcheh hntinue b's nn ID. rfiphse a nverting bbonfdaber of //y DFno ihe DFA.IDtsitioan `lons
  Epsil re`,ettern io 2'.
 = DF' llr:trylyaprodule ane upty" Pathe oldn ` oniow wy  handasefn av `ch patter to ernf///e Busssafepsn' llr
///betviol, rd   /// We record tofn tn tou alrewonny havr to a l/// a onee// ortis/a 
    /// or. son-match s b's te
    /// or  tass  beethatA statnthe DFA.ID.Ok::<fA.).is_somid-ute uckedn get<Statlons
   TDFA::builde = spi r= .get_0a.>tlons
  Epsil re::PATTERN_ID_SHIFT;  if selflons
   T.."[a-ute uckednpi .as_mpl Dne)2'.
 Compile theRror.)(a  fwFthe DFA.lpsil rer       eFgr expthe DFA.IDe enouion rencachable v psil re.t re fA. ;
 ).is_somid( get, pi :;lons
   T<(FA,lons
  Epsil reDFA::buildelons
  Epsil re(  if self.dfanpi .as_m64ne_<<tlons
  Epsil re::PATTERN_ID_SHIFTet       sSome.dfa| (.get_0a&tlons
  Epsil re::EPSILONS_MASKe,  if self)2'.
 Compile theRror.)(  //lpsil rer in koftioan the DFA.lpsil re. new_<P:lpsil ren.get<StatEpsil reDFA::buildeEpsil re(.get_0a&tlons
  Epsil re::EPSILONS_MASKe2'.
 Compile theRror.)(a  fwFthe DFA.lpsil rer       eFgr explpsil rensenouion rencachable vthe DFA.ID.Ok::<fA. ;
 lpsil ren.getRolpsil re: Epsil re)DFA,lons
  Epsil reDFA::buildelons
  Epsil re(  if self.dfan.get_0a&tlons
  Epsil re::PATTERN_ID_MASKet       sSome.dfa| (m64eafrom(lpsil re.0la&tlons
  Epsil re::EPSILONS_MASKe,  if self)2'.
 Coe-p    /:repeafmt::Debug A stlons
  Epsil reDFA::bufA.fmtn&.get, f:;
    :repeafmt::F/ juns
 <Stat:repeafmt:: BuildSFA::builde(si.get_As_rnEpsnea{  if self.dfa)); } /e on !(t, ]N/A"
et       self.stack.(si = sfrom(pi le=e ide2).is_somidnya{  if self.dfae on !(t, ]{}", pid.as_mpl Dner?;  if self}mpile.dfaifs!push(lpsil reny(is_rnEpsnea{  if self.dfa(si.get_).is_somidny(is_  //nea{  if self.dfaSomee on !(t, ]/;r?;  if self.dfa}
self.dfaSomee on !(t, ]{:?}",  ide2lpsil renyr?;  if self}  if self/ miri_'.
 CoCom theEpsil rergu)resfn/
 ositoftion N
 tlpsil rerAthat need
d one-wiser// o/e
/sitetate.atable that im`]setate.a    f/ or. re, bim 12exerit/oaicagu)resfn/

nsition lpsil reithat need
d one-A staa spek `dtoftnen-n wiungivesir ceff Pa:
tterlitinues .atable that at a ses ttosault
    urtion onis a ' ti(u stfexpli
tterinit dusndl//oues .atable that an on  g start/ber at a ses 
    urtion
turnoni that im`t leo. mast ssatisNuebeaSome(Shat b one-os .atable that maytbe
nsitieken. /si
/sitofiseao ds 
    um onenv ceff PaFofNteme("lFofNN   f/ ors (ositon n Paed
/sitby lpsil reithat need
)udownrinit dustate.aselexcebids. Whileau sseebids
/sit scrrrnresfn/fbsitrniow wheon  g start/lpsil reithat need
erit/oaicato chec
/site osault"lFit dus /// exnas mastates excehndle. /si
/sitEpsil rerw trrnresfn/ /mb
 a 42-bitrinieger oF if the DFA i
  bepackedrinit
nsition /// r 42nbilscofNte`,
    /// `. (Ws rat mo higt 22nbilsc t t innTh
nsit`   /// `/ thua sinel is"beo th ins" prope(Sy ) #[dernve(Clfa.stCopf)]
ill fatEpsil re(u64);
r    /Epsil reDFA::buthwit SLOT_MASK:am64i= 0x000003FF_FFFFFC00;ok::<thwit SLOT_SHIFT:am64i= 10;ok::<thwit LOOK_MASK:am64i= 0x00000000_000003FF;ompile theC(), rra  fwFlnEpsplpsil re.ys 'and ne s o snpnd ne Some(Shats, batin_maif yneudan eb`PsatisNO
 . new_<P:lnEpsneatatEpsil reDFA::buildeEpsil re(0l2'.
 Compile theRror.)seurunsi)  bim lpsil rer t t innTne s o snpnd ne Some(Shats.rse tfA.is_rnEpsn get<StatboolDFA::builde ide20.== 02'.
 Compile theRror.)seumbeandlrlpsil reithat need
.Ok::<fA. usis(.get<Stat  o snFA::builde  o s((.get_0a.>tEpsil re::SLOT_SHIFT).///_u32ne)2'.
 Compile thehe, t leandlrlpsil reithat need
.Ok::<fA. e _ usis( get,  usis:   o seatatEpsil reDFA::buildeEpsil re(  if self.dfanm64eafrom(hndle.0e_<<tEpsil re::SLOT_SHIFT)t       sSome.dfa| (.get_0a&tEpsil re::LOOK_MASKe,  if self)2'.
 Compile theRror.)(  //selexceis i-arievedSome(Shats,im`t lserlpsil reithat need
.Ok::<fA.is iss.get<StatLs ihe, FA::buildeLs ihe, Fnbils: (.get_0a&tEpsil re::LOOK_MASKe.///_u32nee}2'.
 Compile thehe, t leis i-arievedSome(Shats,om`t lserlpsil reithat need
.Ok::<fA. e _is iss.get,eis i_ ;
:eLs ihe,eatatEpsil reDFA::buildeEpsil re(  if self.dfan.get_0a&tEpsil re::SLOT_MASKet       sSome.dfa| (m64eafrom(is i_ ;
.bils)a&tEpsil re::LOOK_MASKe,  if self)2'.
 Coe-p    /:repeafmt::Debug A stEpsil reDFA::bufA.fmtn&.get, f:;
    :repeafmt::F/ juns
 <Stat:repeafmt:: BuildSFA::buildeche,"123wrot,        et       sifs!push( usis  .is_rnEpsnea{  if self.dfae on !(t, ] :?}",  ide2 usis  
?;  if self.dfae ot,   urun;  if self}mpile.dfaifs!push(is issd(is_rnEpsnea{  if self.dfa(sie ot, {  if self.dfaSomee on !(t, ]/;r?;  if self.dfa}
self.dfaSomee on !(t, ]{:?}",  ide2is issd
?;  if self.dfae ot,   urun;  if self}mpile.dfaifs!e ot, {  if self.dfae on !(t, ]N/A"
?;  if self}  if self/ miri_'.
 CoCom theT //selexcelpsil reithat need
d
 dica giveA atsal   urtion onis a ' im`]
/siteexpli-ehter to psavaleit dusndl. /si
/sitofise*oaic*rgu)resfn/
 set the  andle.sfr A stnthe DFA umbethe DFA
nsit`[a-z]+([0-9]+)([a-z]+)`'and: /si
/sit* 3troups that
/// p, ofust6ehndle. /sit* 1eot. It i roups that
/// , ofust2eot. It i hndle. /sit* 2 set the  roups that
/// p, ofust4 set the  andle. /si
/sitWhileaot. It i hndlerar agunresfn/ /mby lpsil reithat need
 im`]nNN  ,(wo
/sitdoe
///oet the lherrnresfn/fumbmth //. ret-unp,aot. It i hndlerar aaegumsd
/urns (bouldesfn/fbndsanndnfdab    //art of im`t leeexpli-ons , most one-p
nsitioabe ximumweecaicabrn thatr
ldesfn/fset the  andledi//rurilpsil r
ttertable thats. /si
/sitIts re)resfn/nenerFis/a b5?hset.tof tbile'i'epatterni) ber oaicaifns st 
tterlte gi scrset the eandlrde i/dat 'c',ais rat'cte_c#to a sing*t2) + i'ion a 
tterii,f cotbile'i'e to the starting stappeaaiet the eandlrder of mappea
tterltt the eandlrdppexpsmwmmedi the lao ///ng gtati/ # eot. It i hndl. (If
turns an ed to_Iefaul,oseee`G/// Info`is pflne-odet ils,om`inueandledworks ) /si
/sitA state.a`  o s`rgu)resfn/
 osit
   agenvefandledi//aetub-grap /Ae anNN  , = DF'assetteltion r/ orshpasa o n Paedmby lpsil reithat need
. re,eff Pa,e ass
turnsran tsng gtatiA.
    ///
 tds thata fexpli,fbsitandledternin a l/// a one
ttertable that-ethatbete
    /dmby orecauault
    urtion eexpli-onis a '. /si
/sitof tAPI/Ae `  o s`rgu a ses 
    confiutolA ndnftion ltt the eandlros,
  .
/sitofde in,mb `  o s`rhat ke sr to is rat mo set the  andleding.
/s pfb
turno/// a oneeN
 .e turNF-a.
    confiedter's tf tbile'i'epatterpa co// sac
tterbrn thatd N
   a onhme/ a abostatoef `d 'c',aisilited  mo gurt/bctuaitandl
tterindat aitof mon to the giveN
 . #[dernve(Clfa.stCopf)]
ill fat  o s(u32);
r    /  o snFA::buthwit LIMIT:amul DP= 32;ompile thereter, t leandlr/t ion ar expbitrindat.rse tfA.ieter,( get,  usi:ampl D)Ptat  o snFA::buildedebug_home(M!csndlr<afusis::LIMIT ;
self.dfa usis( get_0a| (1_<<thndl.as_m32ne))2'.
 Compile theRrm `a*t leandlr/t ion ar expbitrindat.rse tfA.rrm `a( get,  usi:ampl D)Ptat  o snFA::buildedebug_home(M!csndlr<afusis::LIMIT ;
self.dfa usis( get_0a& !(1_<<thndl.as_m32ne))2'.
 Compile theRror.)seurunsi) ber oaicaifns an tern t t innTne s o s.rse tfA.is_rnEpsn get<StatboolDFA::builde ide20.== 02'.
 Compile theRror.)sean   erato extiveositoftion ternbilscinns an ter.rse tfA.i ern.get<Stat  o sItrr    if self  o sItrr    usis: pushd}2'.
 Compile theFoues .aonis a ' `at` aitof mourtion c,
    /, 1opyoiast `
    #[cf confi_set the _ usis`ts pfbsitandled one-pasainns an ter.rse t We record tCconfiedmayt   //a s Ite ti(aersmallerioSndledinntaan ternbiggnues ane transition maller ofiph aar expset the  andledpasas    y skippedh  /// We record tofe s Ite *etha*/h  to the eoaicating stset the  andledper of mappea
chable v l supptoftion t Ite ethataer of pty"  the en N
   appeaaiet the eandln-match s itof mon to the giveN
 . se tfA.apply(A::builde ideResulturn aa:ampl DResulturn  confi_set the _ usis:;
    [O  sta<nfaMaxUpl D>]Result)SFA::builde(si.get_As_rnEpsnea{  if self.dfa)); } et       self.stack. = satr= nfaMaxUpl D2yc3x"at)f let Somes pfondlr
   ush(iternya{  if self.dfa(si.ndlr>=  confi_set the _ usiself.dfa   if self.dfaselfb(),k;
Some.dfaSome} let Some.dfa confi_set the _ usis[ usi]r= atf let Someelf.stCoe-p    /:repeafmt::Debug A st  o snFA::bufA.fmtn&.get, f:;
    :repeafmt::F/ juns
 <Stat:repeafmt:: BuildSFA::buildee on !(t, ]S;r?;  if selfA stondlr
   ush(iternya{  if self.dfae on !(t, ]- :?}",  ndlr?;  if self}  if self/ miri_'.
 CoCom theAn   erato extiveositoftion bilscternin a ondlr
  .
/si
/sitofiserror.)seumbebitrindatm one-iatterpasaepconfiedmaytbrn thatmafternit
/urns (ge, t lebctuaitN   fndlr
 dat.r#[dernve(Debug)]
ill fat  o sItrr    if  usis:   o sRee-p    /I erato eA st  o sItrr    if typeDI emte_mpl D;
rse tfA.nf 2(&     get<StatO  sta<mpl D>Parse tildet tNates exceteades f //y DFaer of <=au8::MAX, ber soef ledi//aempl D.en seselfA::n usie=e ide2hndle.0(],bilche_teads(rhas_mpl Dne;rse tilde(si.ndlr>= fusis::LIMITa{  if self.dfa)); } /nfa.;  ///Some}A::builde ide2  o sn=e ide2hndle.rrm `a( ndlr;
self.dfa  //n ndlr_'.
 CoCom theAn r>>((   atFAcourtidtds thatof mon itl faeedcofNteA.
    ///
 . /si
/sitofim l>>(( dat ys
//ldhe cadmanf imtadspefaeedce
 abilcties, most -creaex_aa; appllytcaicatw N
 thasy hav scrd N     it: /si
/sit* Obt inNtehumscrrradeed  mesy, chvian led`:Errofmt::Display`eot. . /sit* Acce stteau darlythat[`thomps/ ::Build
    `] typeDA Thiited`:rurce`
ch.

ethothvianof m`:Error>>(())
    `rtabit.tofim l>>(( caica ccuaeewonnyefaul
/sit  w exiiote halled ere NFbuildthata A.
    ///
 tdi" Pae la Thiaethe DFA
nsit    ng. /si
/sitWhs au st`:Er`tseaing .im lneed d,ettan emll suppsnof m`:Error>>(())
    `
ttertabit.e#[dernve(Clfa.stDebug)]
manyill fatBuild
    a{  if k `d:tBuild
    K `d,oCom theT //k `dtoftr>>((   atFAcourtidtds thatof mon itl faeedcofNteA.
    ///
 . #[dernve(Clfa.stDebug)]
 tattBuild
    K `da{  if N  (:thoD2yc::DFthomps/ ::Build
    e,  if Wcau(Unions WcauBieveary
    e,  if TooManfS/ orsh{ lim.t:em64i},  if TooManfPo a sing{ lim.t:em64i},  if UTwhat
/// Ls ig{ ls i:eLs ii},  if Excrn edSl DLim.tg{ lim.t:emul DP},  if NotOneP  //{ msg:;
'(nf/ a itlP}, e-p    /Build
    a{  if fA.nfa(r>>: :thoD2yc::DFthomps/ ::Build
    eStatBuild
    a{  if     Build
    a{ k `d:tBuild
    K `d::N  (r>>ee}2'.
 CompilefA.wcau(r>>: Unions WcauBieveary
    eStatBuild
    a{  if     Build
    a{ k `d:tBuild
    K `d::Wcau(r>>ee}2'.
 CompilefA.too_manf_r/ orsnlim.t:em64eStatBuild
    a{  if     Build
    a{ k `d:tBuild
    K `d::TooManfS/ orsh{ lim.t }e}2'.
 CompilefA.too_manf_to a sinnlim.t:em64eStatBuild
    a{  if     Build
    a{ k `d:tBuild
    K `d::TooManfPo a sing{ lim.t }e}2'.
 CompilefA.uTwhat
///  ls i(ls i:eLs ieStatBuild
    a{  if     Build
    a{ k `d:tBuild
    K `d::UTwhat
/// Ls ig{ ls i }e}2'.
 CompilefA.excrn ed_el D_lim.t(lim.t:emul DeStatBuild
    a{  if     Build
    a{ k `d:tBuild
    K `d::Excrn edSl DLim.tg{ lim.t }e}2'.
 CompilefA.s
/_od _   /(msg:;
'(nf/ a itleStatBuild
    a{  if     Build
    a{ k `d:tBuild
    K `d::NotOneP  //{ msg }e}2'.
 CoCom#[cfg(feaing .= ":Er")]
    /:Error>>(())
    re NFBuild
    a{  if fA.:rurcen&.get<StatO  sta<&(ror::Error>>(())
     + '(nf/ a)>a{  if selfs at.get::Build
    K `d::*;
esult.dfa// ste ide2kiy i{  if self.dfaN  (reftr>>le=>   //nr>>l,  return .dfaWcau(reftr>>le=>   //nr>>l,  return .dfa_e=> nfa., let Some}// A one-p    /:repeafmt::Display e NFBuild
    a{  if fA.fmtn&.get, f:;
    :repeafmt::F/ juns
 <'_><Stat:repeafmt:: BuildSFA::buildes at.get::Build
    K `d::*;
esult.dfa// ste ide2kiy i{  if self.dfaN  (_le=> e on !(t, ]r>>(( buildthatN  "l,  return .dfaWcau(_le=> e on !(t, ]N    t t innTUnions .wcau bieveary"l,  return .dfaTooManfS/ orsh{ lim.t }e=> e on !(
.dfaSome.dfa.dfaf,  if self.dfaSome"A.
    ///
 texcrn edNtelim.t ofN{:?}eA stnates exceh/ ors",  if self.dfaSomelim.tt  return .dfa
,  return .dfaTooManfPo a sing{ lim.t }e=> e on !(
.dfaSome.dfa.dfaf,  if self.dfaSome"A.
    ///
 texcrn edNtelim.t ofN{:?}eA stnates exceto a sin",  if self.dfaSomelim.tt  return .dfa
,  return .dfaUTwhat
/// Ls ig{ ls i }e=> e on !(
.dfaSome.dfa.dfaf,  if self.dfaSome"A.
    ///
 tdat ys
//what
//tof m{:?}eSome(Shat",  if self.dfaSomels it  return .dfa
,  return .dfaExcrn edSl DLim.tg{ lim.t }e=> e on !(
.dfaSome.dfa.dfaf,  if self.dfaSome"A.
    ///
 texcrn edNul DPlim.t ofN{:?}eds thatbuildtha",  if self.dfaSomelim.tt  return .dfa
,  return .dfaNotOneP  //{ msg }e=> e on !(
.dfaSome.dfa.dfaf,  if self.dfaSome"A.
    ///
 tcrnlde
///betbuilt/re is at\  if self.dfaSome.ohe DFA use
///A.
    /: {}",  if self.dfaSomemsgt  return .dfa
,  return }2'.
 CoCom#[cfg(pll( r# , feaing .= ":y t x"))]
moth r# snFA::bus ata //
::    ng::ToS   ng;
esults at.uper::*;
esult#[ r# ]  if fA.fbil_to_Ilictete &mble that(<S{A::builde = sptidica  .= |r>>: &   |tr>>. t t inn("to_Ilictetertable that");
esult.dfa = ssrr("foo[0-9]+br"a*[ab]"y.// ass_srr(rhto_    ngne;rse tildehome(M!cptidica  (&r>>l, ]{}", r>>l;// A onmpile#[ r# ]  if fA.fbil_mternll  lpsil r(<S{A::builde = sptidica  .= |r>>: &   |t{  if self.dfar>>. t t inn("mternll  lpsil reithat need
d o renceata  ")
.dfaSome};
esult.dfa = ssrr("foo[0-9]+br"(^|$)a"y.// ass_srr(rhto_    ngne;rse tildehome(M!cptidica  (&r>>l, ]{}", r>>l;// A onmpile#[ r# ]  if fA.fbil_mternll     ///
 {A::builde = sptidica  .= |r>>: &   |t{  if self.dfar>>. t t inn("mternll  lpsil reithat need
d o 
    /// or")
.dfaSome};
esult.dfa = ssrr("foo[0-9]+_manf(&[r"^", r"$"]y.// ass_srr(rhto_    ngne;rse tildehome(M!cptidica  (&r>>l, ]{}", r>>l;// A onmpilesitofim  r# en tteefaun ebuildNteA.
    //ata::r       eFmaximattnates excmpilesitrniow whes o s.rse tWe record NOTE:eRrmetes eA atsal  .ndlrlim.t oaicaappli
///  set the  roups tha record 
/// p. Anytnates exceot. It i roups that
/// e a osuat
/// t("lFit A snvertinFmaximattnates excosuat
/// tto a sin)waA is rit. It i 
/// e pasaanndnfdnvertinFpymaxleeexpli-ls piiteide2mpile#[ r# ]  if fA.max_ usis()Parse tildet tOd fn odmanf...en seselfA::npatr= r"(a)(b)(c)(d)(e)(f)(g)(h)(i)(j)(k)(l)(m)(n)(o)(p)(q)";rse tildehome(M!coo[0-9]+bpatd(is_rrr(re;rse tildet tJus2 odeal.en seselfA::npatr= r"(a)(b)(c)(d)(e)(f)(g)(h)(i)(j)(k)(l)(m)(n)(o)(p)";rse tildehome(M!coo[0-9]+bpatd(is_ i()l;// A onmpilesitofim  r# eensng seA atsal  A.
    ///
 tworkstw    allr:s i-arievempilesitSome(Shats, batmweeset PaFiast tworka     H Classmpilesitofe utilctykoftioan  r# en t batmea th .
    //table that and a as mampilesitSmievt ofN/ptceen Nttosetis i-arievedSome(Shats. Curtionof,sof //y Dmpilesitlog a  itof m .
    //on itl faord inensng sof //ypaske s/orat mteatn is showtrniow wheSome(Shats. Avedine s maof //ypastcaicatexptniow wheSome(Shatsis showt(atsaime ti(e on  a)pasaes an ed okaye Busson ceivabof,s/oratSome(Shatsis showtcter to padd.d.sfr w fi uckeA atsalshasyatsae # eworka    n/ ext snvertinFset PaFumbmtt tworka     H Cla#[ r# ]  if fA.Some(Shats()Parse tildet tc,
    / anchorsrse tildehome(M!coo[0-9]+br"^"d(is_ i()l;// A ildehome(M!coo[0-9]+br"$"d(is_ i()l;/in_maselfsitaed fanchorsrse tildehome(M!coo[0-9]+br"(?m)^"d(is_ i()l;// A ildehome(M!coo[0-9]+br"(?m)$"d(is_ i()l;// A ildehome(M!coo[0-9]+br"(?Rm)^"d(is_ i()l;// A ildehome(M!coo[0-9]+br"(?Rm)$"d(is_ i()l;/in_maselfsitwcau bieveariesrse tilde(si{ retfeaing .= "unions -wcau-bieveary"lt{  if self.dfahome(M!coo[0-9]+br"\b"d(is_ i()l;// A ilde.dfahome(M!coo[0-9]+br"\B"d(is_ i()l;// A ilde}// A ildehome(M!coo[0-9]+br"(?-u)\b"d(is_ i()l;// A ildehome(M!coo[0-9]+br"(?-u)\B"d(is_ i()l;// A onmpile#[cfg(
//turn O)] sitieke/// use re,om`urn H Cla#[ r# ]  if fA.is_ d _   /()SFA::buildes at:thoD2yutil:: y t x;/in_maselfhome(M!coo[0-9]+br"a*b"d(is_ i()l;// A ilde(si{ retfeaing .= "unions -perl"lt{  if self.dfahome(M!coo[0-9]+br"\w"d(is_ i()l;// A ilde}// A ildehome(M!coo[0-9]+br"(?-u)\w*\s"d(is_ i()l;// A ildehome(M!coo[0-9]+br"(?s:.)*?"d(is_ i()l;// A ildehome(M!coo[0-builderny  if self.dfa. y t x( y t x::Co_Iig0-9]+by./tf8(     )y  if self.dfa.buildbr"(?s-u:.)*?"d  if self.dfa.is_ i()l;// A onmpile#[ r# ]  if fA.is_s
/_od _   /(lt{  if selfhome(M!coo[0-9]+br"a*a"d(is_rrr(re;rse tildehome(M!coo[0-9]+br"(?s-u:.)*?"d(is_rrr(re;rse tildehome(M!coo[0-9]+br"(?s:.)*?a"d(is_rrr(re;rse tonmpile#[cfg(
//turn O)]mpile#[ r# ]  if fA.is_s
/_od _   /_biggnu(lt{  if selfhome(M!coo[0-9]+br"\w*\s"d(is_rrr(r