/*!
Provides a contiguous NFA implementation of Aho-Corasick.

This is a low-level API that generally only needs to be used in niche
circumstances. When possible, prefer using [`AhoCorasick`](crate::AhoCorasick)
instead of a contiguous NFA directly. Using an `NFA` directly is typically only
necessary when one needs access to the [`Automaton`] trait implementation.
*/

use alloc::{vec, vec::Vec};

use crate::{
    automaton::Automaton,
    nfa::noncontiguous,
    util::{
        alphabet::ByteClasses,
        error::{BuildError, MatchError},
        int::{Usize, U16, U32},
        prefilter::Prefilter,
        primitives::{IteratorIndexExt, PatternID, SmallIndex, StateID},
        search::{Anchored, MatchKind},
        special::Special,
    },
};

/// A contiguous NFA implementation of Aho-Corasick.
///
/// When possible, prefer using [`AhoCorasick`](crate::AhoCorasick) instead of
/// this type directly. Using an `NFA` directly is typically only necessary
/// when one needs access to the [`Automaton`] trait implementation.
///
/// This NFA can only be built by first constructing a [`noncontiguous::NFA`].
/// Both [`NFA::new`] and [`Builder::build`] do this for you automatically, but
/// [`Builder::build_from_noncontiguous`] permits doing it explicitly.
///
/// The main difference between a noncontiguous NFA and a contiguous NFA is
/// that the latter represents all of its states and transitions in a single
/// allocation, where as the former uses a separate allocation for each state.
/// Doing this at construction time while keeping a low memory footprint isn't
/// feasible, which is primarily why there are two different NFA types: one
/// that does the least amount of work possible to build itself, and another
/// that does a little extra work to compact itself and make state transitions
/// faster by making some states use a dense representation.
///
/// Because a contiguous NFA uses a single allocation, there is a lot more
/// opportunity for compression tricks to reduce the heap memory used. Indeed,
/// it is not uncommon for a contiguous NFA to use an order of magnitude less
/// heap memory than a noncontiguous NFA. Since building a contiguous NFA
/// usually only takes a fraction of the time it takes to build a noncontiguous
/// NFA, the overall build time is not much slower. Thus, in most cases, a
/// contiguous NFA is the best choice.
///
/// Since a contiguous NFA uses various tricks for compression and to achieve
/// faster state transitions, currently, its limit on the number of states
/// is somewhat smaller than what a noncontiguous NFA can achieve. Generally
/// speaking, you shouldn't expect to run into this limit if the number of
/// patterns is under 1 million. It is plausible that this limit will be
/// increased in the future. If the limit is reached, building a contiguous NFA
/// will return an error. Often, since building a contiguous NFA is relatively
/// cheap, it can make sense to always try it even if you aren't sure if it
/// will fail or not. If it does, you can always fall back to a noncontiguous
/// NFA. (Indeed, the main [`AhoCorasick`](crate::AhoCorasick) type employs a
/// strategy similar to this at construction time.)
///
/// # Example
///
/// This example shows how to build an `NFA` directly and use it to execute
/// [`Automaton::try_find`]:
///
/// ```
/// use aho_corasick::{
///     automaton::Automaton,
///     nfa::contiguous::NFA,
///     Input, Match,
/// };
///
/// let patterns = &["b", "abc", "abcd"];
/// let haystack = "abcd";
///
/// let nfa = NFA::new(patterns).unwrap();
/// assert_eq!(
///     Some(Match::must(0, 1..2)),
///     nfa.try_find(&Input::new(haystack))?,
/// );
/// # Ok::<(), Box<dyn std::error::Error>>(())
/// ```
///
/// It is also possible to implement your own version of `try_find`. See the
/// [`Automaton`] documentation for an example.
#[derive(Clone)]
pub struct NFA {
    /// The raw NFA representation. Each state is packed with a header
    /// (containing the format of the state, the failure transition and, for
    /// a sparse state, the number of transitions), its transitions and any
    /// matching pattern IDs for match states.
    repr: Vec<u32>,
    /// The length of each pattern. This is used to compute the start offset
    /// of a match.
    pattern_lens: Vec<SmallIndex>,
    /// The total number of states in this NFA.
    state_len: usize,
    /// A prefilter for accelerating searches, if one exists.
    prefilter: Option<Prefilter>,
    /// The match semantics built into this NFA.
    match_kind: MatchKind,
    /// The alphabet size, or total number of equivalence classes, for this
    /// NFA. Dense states always have this many transitions.
    alphabet_len: usize,
    /// The equivalence classes for this NFA. All transitions, dense and
    /// sparse, are defined on equivalence classes and not on the 256 distinct
    /// byte values.
    byte_classes: ByteClasses,
    /// The length of the shortest pattern in this automaton.
    min_pattern_len: usize,
    /// The length of the longest pattern in this automaton.
    max_pattern_len: usize,
    /// The information required to deduce which states are "special" in this
    /// NFA.
    special: Special,
}

impl NFA {
    /// Create a new Aho-Corasick contiguous NFA using the default
    /// configuration.
    ///
    /// Use a [`Builder`] if you want to change the configuration.
    pub fn new<I, P>(patterns: I) -> Result<NFA, BuildError>
    where
        I: IntoIterator<Item = P>,
        P: AsRef<[u8]>,
    {
        NFA::builder().build(patterns)
    }

    /// A convenience method for returning a new Aho-Corasick contiguous NFA
    /// builder.
    ///
    /// This usually permits one to just import the `NFA` type.
    pub fn builder() -> Builder {
        Builder::new()
    }
}

impl NFA {
    /// A sentinel state ID indicating that a search should stop once it has
    /// entered this state. When a search stops, it returns a match if one
    /// has been found, otherwise no match. A contiguous NFA always has an
    /// actual dead state at this ID.
    const DEAD: StateID = StateID::new_unchecked(0);
    /// Another sentinel state ID indicating that a search should move through
    /// current state's failure transition.
    ///
    /// Note that unlike DEAD, this does not actually point to a valid state
    /// in a contiguous NFA. (noncontiguous::NFA::FAIL does point to a valid
    /// state.) Instead, this points to the position that is guaranteed to
    /// never be a valid state ID (by making sure it points to a place in the
    /// middle of the encoding of the DEAD state). Since we never need to
    /// actually look at the FAIL state itself, this works out.
    ///
    /// By why do it this way? So that FAIL is a constant. I don't have any
    /// concrete evidence that this materially helps matters, but it's easy to
    /// do. The alternative would be making the FAIL ID point to the second
    /// state, which could be made a constant but is a little trickier to do.
    /// The easiest path is to just make the FAIL state a runtime value, but
    /// since comparisons with FAIL occur in perf critical parts of the search,
    /// we want it to be as tight as possible and not waste any registers.
    ///
    /// Very hand wavy... But the code complexity that results from this is
    /// very mild.
    const FAIL: StateID = StateID::new_unchecked(1);
}

// SAFETY: 'start_state' always returns a valid state ID, 'next_state' always
// returns a valid state ID given a valid state ID. We otherwise claim that
// all other methods are correct as well.
unsafe impl Automaton for NFA {
    #[inline(always)]
    fn start_state(&self, anchored: Anchored) -> Result<StateID, MatchError> {
        match anchored {
            Anchored::No => Ok(self.special.start_unanchored_id),
            Anchored::Yes => Ok(self.special.start_anchored_id),
        }
    }

    #[inline(always)]
    fn next_state(
        &self,
        anchored: Anchored,
        mut sid: StateID,
        byte: u8,
    ) -> StateID {
        let repr = &self.repr;
        let class = self.byte_classes.get(byte);
        let u32tosid = StateID::from_u32_unchecked;
        loop {
            let o = sid.as_usize();
            let kind = repr[o] & 0xFF;
            // I tried to encapsulate the "next transition" logic into its own
            // function, but it seemed to always result in sub-optimal codegen
            // that led to real and significant slowdowns. So we just inline
            // the logic here.
            //
            // I've also tried a lot of different ways to speed up this
            // routine, and most of them have failed.
            if kind == State::KIND_DENSE {
                let next = u32tosid(repr[o + 2 + usize::from(class)]);
                if next != NFA::FAIL {
                    return next;
                }
            } else if kind == State::KIND_ONE {
                if class == repr[o].low_u16().high_u8() {
                    return u32tosid(repr[o + 2]);
                }
            } else {
                // NOTE: I tried a SWAR technique in the loop below, but found
                // it slower. See the 'swar' test in the tests for this module.
                let trans_len = kind.as_usize();
                let classes_len = u32_len(trans_len);
                let trans_offset = o + 2 + classes_len;
                for (i, &chunk) in
                    repr[o + 2..][..classes_len].iter().enumerate()
                {
                    let classes = chunk.to_ne_bytes();
                    if classes[0] == class {
                        return u32tosid(repr[trans_offset + i * 4]);
                    }
                    if classes[1] == class {
                        return u32tosid(repr[trans_offset + i * 4 + 1]);
                    }
                    if classes[2] == class {
                        return u32tosid(repr[trans_offset + i * 4 + 2]);
                    }
                    if classes[3] == class {
                        return u32tosid(repr[trans_offset + i * 4 + 3]);
                    }
                }
            }
            // For an anchored search, we never follow failure transitions
            // because failure transitions lead us down a path to matching
            // a *proper* suffix of the path we were on. Thus, it can only
            // produce matches that appear after the beginning of the search.
            if anchored.is_anchored() {
                return NFA::DEAD;
            }
            sid = u32tosid(repr[o + 1]);
        }
    }

    #[inline(always)]
    fn is_special(&self, sid: StateID) -> bool {
        sid <= self.special.max_special_id
    }

    #[inline(always)]
    fn is_dead(&self, sid: StateID) -> bool {
        sid == NFA::DEAD
    }

    #[inline(always)]
    fn is_match(&self, sid: StateID) -> bool {
        !self.is_dead(sid) && sid <= self.special.max_match_id
    }

    #[inline(always)]
    fn is_start(&self, sid: StateID) -> bool {
        sid == self.special.start_unanchored_id
            || sid == self.special.start_anchored_id
    }

    #[inline(always)]
    fn match_kind(&self) -> ens: Vec<e is enabled by default. If yond(&ser
            an<ually point to a valid state
    /u32tosid(repnd(&sertechniq       // produce matches th    s i(alw   primit   an<ually point to a valid state
   [i(a]            == self.special.start_anchored_id
   t pattern in t         an<ually point to a val t pattern in t == self.special.start_anchored_id
    xpattern in t         an<ually point to a val  xpattern in t == self.special.start_anchored_id
    }

 es th    s e(always)]
    fn<ually point to   }
     }

 es ta vals have this , ) -> State[       loop {
 in) == self.special.start_anchored_id
    }

 haystackh    s e(always)]
 uilddexhis aut   fn   primity point to   }
     }

 haystack   return NFA: vals have this ,   return NFA) -> State[       loop {
 in,   return NFAlddex,   return) == self.special.start_anchored_id
   order_ature         an<ually point to 
*/

 ||   em::uall   cked() {
  ( -> State /u32turnuall   ::Ds fo:<()  return NFA+ ( -> Sid state
    /u32turnuall   ::Dof a match.:<()  return NFA+  -> Sine exist    ne {
     orsert|p| p. order_ature )tosid(repnd(&sertechniq       // producntation an       anes, if &one existsy point to a valine exist    ne {
> Builder {
   
 ||  fmtteI
    ct as well.
unodufmtkh    s f:stream
 ||  fmtteFatter(cra  an
 ||  fmtteate(&s    #[test]
    fn oib`
/// use afmt
    #_    ///orcked() {
  wof `ln!( s "
    /// in a c("as_be()
              a : StateID) ;own a
/// chtain]);
``tables a a
/// ctruct Nsid = StateID::from_u32_uncheckene)]=A) -> State[       loop {
 ines.get(rep);
    ne): Stntery           if anchorebreak{
                return NFAecke  }

   pr = &se  }

    ) ->            let o `table    }
   rteID) vals have this ,   }

   , ne)>            lefmt
    #_    ///or( s     s e(aas_be()
    {
  wof `!(rans_offset = o +            }
     "{:06}({:06}): "           }
            loop {
           }
      IL dorans            == s  return)s_be()
    {
   IL dormtkfas_be()
    {
  wof `!( s "\n"as_be()
    {
     = &se  }

    ) ->         if anchorewof `!( s "  -> Result<St   /"as_be()
    {
   o + 2 +i // 0    L do  }

 es iter().enumerate()
        psses.get(b    }

 haystack) vals have this , ne),    let classes = chunk.to_ni > 0            if classes[3] =wof `!( s ",/"as_be()
    {
   o +et + i * 4 + 2]);
        wof `!( s "{}"s i(a           as_be()
    {
   o +}       if anchorewof `!( s "\n"as_be()
    {
    }
             TThe easiest paAho-Coras. Since      maton d. Ind`tablese a coedext transition" l2 +iions real
    /    eon is 
non-red_id
 is n.ewof `tried icant slowdowns. So /// middle after the beginn, sid: StateID)          if anchorewof `ln!( s "F {:06}:"s ss)]);
             as_be()
    {
      return NFAeckeze();
get(b  es ta vals have this ,   }

   , ne)>            leasses.get(byte)r()        loop {
 et u32t_add(  le/
/// let][..classes_len].i/
/// let n    {
      returnwof `ln!( s "

   pcs bui{:?}"s ind(&self) -> eas_be()
    wof `ln!( s "ting search{:?}"s ind(&ine exist   }
nwra)as_be()
    wof `ln!( s "`tablen_pattch{:?}"s ind(&number ofas_be()
    wof `ln!( s "t   /// n_pattch{:?}"s ind(&ond(&ser
    )as_be()
    wof `ln!( s "`asses,
    /// Tn_pattch{:?}"s ind(& t pattern in tas_be()
    wof `ln!( s " usize,
    /// n_pattch{:?}"s ind(&  xpattern in tas_be()
    wof `ln!( s "atch_kindn_pattch{:?}"s ind(&s have this as_be()
    wof `ln!( s "omaton.
    ch{:?}"s ind(&sses`](crate:s_be()
    wof `ln!( s "ression turech{:?}"s ind(& order_ature )ts_be()
    wof `ln!( s ")"as_bbe()
    ow gref.byte_classesTThe"i   order"b struct NFA {

/// Becaues for2 +ot explicitlyyn std::eA `get(b`'
    ression struct NFA {

s
/// N   //s. Since   /// colitetd::edick autontinel resentaint to a valid ste alls re the sec Onc, bull back to, the givding ato ja `get(b`which. Since a
/// strhat 
    `I
   std::ismilar s point toa `get(b`wpe.

# Craec<SmallIndex>ic otherwis  }

 and recer pack`](cratngut the colone)]bin dirlace in the
    icitlyyn`] documentation an exaget(b<'a>e.
#[derive(Cloressionoe format of noey is '](cra_     xt' yie0%93Co format of
#[derivewould b easiest p afterransnchored: Anchorrive(Cloghput when searchs andble equivalenc    }
k
alg
    /// ma, code complexity a
/// czeroe-step usin the hea
/// cbigger of stzeroetch semantin this automaton.
    maot expl  }aster by making some
/// usuas
          See the est p afteras
  nchoredTs
  <'a>,_classesTThe if tlyin tby making some
///ot expl  }aster as
          Seealicitlyyn std::eilure trantion.`get(b`     ay? Soectly. Usia
/// strt on theport `Samitstd::edick autontinel sthe encoay? Soa
/// cf thete I on the complu only ttd::eby making //
      o be rol,ok ayyn`] documentationpr[ochoredTs
  <'a>  Builder::newt explby making some
/// s
          Seealicitlsitions ng an alg eas
#[derivew the number reivalence
/// class, eve afterSt expl        ifus::NFA,
 'a [s fn,   returnattern_les
          See the est psitions : Vec format of aw NFA re   returnatteulateaD;
 tters,r an8 mod und the
staewould bomaton.
  es `std::erreturnatte format of,n complefor t 24 mod und the
staewould bfrom(osure is cerreturnatt   returnatternaw NFA ld_frst
/// fe   xt_state' a     his stataint to a v   returnatteften, s2^24-1 cerreturnfromA,
 'a [s fn,   re} in this NFA" ///
I tried to ressionead, th    //ay
    /// maick contiguous NFA
 ou a rei//
/arg(test) Thisy useest psis realdense  it is generaking the FAthat  that doby making some
s `std:mick coOnpl        ift is a li///
///port `Safte'smatch_kindave any
   format of aw       ift isns, denss `.       ifus::N    mut si#[derive(Cloressionthe etate I format of noen't expearch shoymbol aw       ift isequousintous::N' cerreturnfrom:D;
 ,   re} in this NFAaster by making some
/// s
          Seealicitlsitions    
#[derivew the number reivalence
/// class, eve,atterns/ do. the numberwould 
#[derive easiest p afterce cla        ift isFAaster     /// s
         wouteID::ntorized r_les
         may       ift isA. (noncont easiest puild oint toaing
Aho-ntinel state Iter of::erreturnattesamhe format of we nupever'rans' cerreturnatt   returnatteilure trancode coAlddexiagnosomatond
    /// sparse, are defi   returnatted not on thed rEach det '](cra_     xt[d no]'frst
rosearchi  returnatte'](cra_     xt[pr;
        let c]'frstaim tha.e(Cloghput whe:erreturnatte format ofse hea
/// cnd
    //tsintous::N   s have this ()'.       ifus::N_     xt,
 'a [s fn,   re} ier {
  <'a> get(b<'a>e.
#[derive(Clo          oions      -> e"o comp The raw stof tht sure le keearch stops, s that apw_unche on theried a  with a'sailure transitin complef-> ens: V a con the
sta   /// st, for
    /// a spars // it sest p afterom thi    his autes.0;
Builder::new()
    } on t
    /// Another it sest p.
///
//aster by making some sfterom thi          :D;
 es.0         er::new()
    } on t
    /// Another it sest p.
///
//red_id
 "arch stops, 
I tried to lace in ven wpous Ncng

alg
    /// maalue, b ///
I tried tnsitions), on.up to buildoiolmodifiej libyo comllndex>,
    s tilways     er::nuilder`] can be used tos real of  it is gen      LeftmosAthat  that d     er::by making some sfterom thi     ON :D;
 es.0  E;
Builder::ilter:xim[oc, for
    /// a spars o] & 0   /asailure transiti insSinceng the FAIL IDs resenta
      w the number reivnsiderthat r retchKi  /// chinh stops, 
pattern. nsiti ifinding a contoaing
Ahowill rprobrasices for l
 aneng the FAs t/// ifindingngle
//oaing
 /// do. Tmces fornew`es aailure tAhow'rch stops, r reick contiguous NFA
    low-level AP throuenple pvels for
b: Vecs that apw_unche on thetate, the fa'    ' `Auto. Namh fasilure transitinefords// st, for
    /// a spars
turnatteulate         '. B`] c:build"ure tr"which nsitin      Onthat this mld 
#[derive";
  " br    current state's fai.B.e(Cl NFA ? Soanyts transr Nc matce   gisons`Aut t127st inl Itate's fa and tly repitaailure tI er`] nerakylure transitines the / NFA. 
turnatte format ofse hegort and . Forceate or lt r retc comisure iids
    /// nsitions), . Dense statesng with a e the secd
 tr, replconstch cochin s of thh stops, 
pat format ofsedick autontinel s t/// sfterom thiMAX_SPARSE_TRANSITIONShis autes.127;
Builder::Remapt_state' 
   -ID (bcurrent state's fa`set(b`wr you need
pat olone)]bin dirlace in the
alicitly impletern.h stops, s that aencteru This the
staewould btern. Th
    /// (cowill repoenctnsitions), yhat un;
puhing thun;
 to a place in the
    AIL doel.
unoduremap(   nfa::noncontigin this automatonnnnnold_     w,
 [hored: n,   returnAIL d:stream[s fn,   reasick::AhoCorasiI, P>(patte        byte: u= sid.aget(b     #[iddle _be()
     of them have failed.
            if kind =iddle  }
 nold_     w[iddle  }    loop {
}    l32   let classes = Seefrom(iseest p[) in
  oncontigin t      _rea           if anchore*:KIND_Dold_     w[:KIN    loop {
}    l32   let classes =    returnxt;
                }
            } else if kindiddle  }
 nold_     w[iddle  }    loop {
}    l32   let classes =est p[)}
 nold_     w[iddle 2}    loop {
}    l32   let class]);
                } for this module  }
   ure tr_ this mod[iddle _be()
    en = kind.as_usize();
                let classes_len iddle  }
 nold_     w[iddle  }    loop {
}    l32   let classes = Seefrom(iseest p[)          let  in
          l      _rea           if anchore*:KIND_Dold_     w[:KIN    loop {
}    l32   let classes =    returnxbe()
    ow gref.byte_Builder::Retate It min_pattuild , for
    l32overfe the est p afterntiguous NFA
     The lrol,  }

 and reIL IDs om tan `build, e.g., // it sI
   
turnatteu
   nd whethlow-rt and stof location, whmapt the  The raddexand sts not actualldpw_ufiasick contiguous NFA`set(b`wr you need
pat olone)]bin dirlace in the
alicitly impletern.h stops, s that aencteru This the
staewould btern. Th
    /// (cowill repoenctnsitions), yhat un;
puhing thun;
 to a place in the
    AIL doel.
unodu    oncontigin this auto   }

   :n is_,nAIL d:st[s fn   an<ually point to e: u= siize();
1_be()
        ransize();
1_be()
        = sid.aget(b     #[iddle _be()
        (       let ,r this mod)d.a of them have failed.
            if kind =serts have this a   returnxt;
                }
            } else if kindsert_)let class]);
                } for this module  }
   ure tr_ this mod[iddle _be()
    en = kind.as_usize();
                let classes_len (       let ,r this mod)let class]_be()
          }

 es i.a of!  }

   p             }0   returnxt;
        }
     }

 es ts have this , iddle     1p             }NFA
     Thn-red_id
 is naailure trches,
  NFA u /// searchs aetate, thad us down a 
    /// ma, ncreasedlass, evegnos/// Becau;
 ees thod uor te never follow fa own
  (ory footp Thi// we w Seeal retur searchs a) after the beg1let class]);
                }lemee[mat 1pnoenternsat olo;
 enead,    ///es// st, for
   path we were on. searchs andnead, For a after the beg1per: }
     }

 es ts have this , iddle let class]_be()
    = siize()+ ransize()         let )   this modu+   }

 es f.byte_Builder::Retate It mi     rfe the est p afterntiguous NFA
    ng annternsa It minepllet .pnd(&sertechniq       // produ   #[iddle:st[s fn   an<
 e{   returnAIL d[  }
       e();
   f.byte_Builder::Getansitions, currere tra/// a spars // itquivalenc rasickanh    / a new Ahoetions,of st  }
   MAX_SPARSE_TRANSITIONS,/asaillndex>,
 es thsingl#[derivew the number reiv 0   d/asade classes, ick contiguous NFA`set(b`wr you need
pat olone)]bin dirlace in the
alire transiti iimplng the FAIL n. Th
    /encteru This the
staewould btern. Th
    /// (cowill reng the FAIencter yhat un;
puhing thun;
 to a place in the
    AIL doell be
/ nsitions)A ? Soalure transition annen. Foris_an on t
 it ired_iandaick contiguous NFADodefire trancode coAng anlegousintcte IDn
alire transiti iSoetate, the faSamwise` " ///
I tried to ressioe fst a lure transitionsoh a e the efi   rew Ahoetlegousintcte Ie / NFns)
  useeher l est p aftersafe impl Automaton for NFre tr_ this mod[iddle:st[s fn   an<ually point to (AIL d[  }
       e();
   )            == self.speer::Retate It mind,
    /// The , its transitions and// itquivalenc Ca expoh stops, 
pcoAngch nsitinnead, t? Soal
    /y... But//  ired_iandat semantiant but is ausng wiForis_adat  /// T th    //0w Seealllaim thatcte sick contiguous NFA`set(b`wr you need
pat olone)]bin dirlace in the
alicitly impletern.h stops, s that aencteru This the
staewould btern. Th
    /// (cowill repoenctnsitions), yhat un;
puhing thun;
 to a place in the
    AIL doel.
uncial.start_anchored_id
    }

 es toncontigin this auto iddle:st[s fn   an<ually point to lemee[ay? Sof the Dny ree w         
  NFailure tfix of ion that ipoint to lem
    /// maick co        pFA rep=      }
      #[iddle m have failed.
            if kind =t o `tarND_D)   oncontigin tt classes_len iddle `tarN]            == s  re]);
                } for this module  }
   ure tr_ this mod[iddle _be()
    en = kind.as_usize();
                let classes_len t o `tarND_D)          let )   this modt classes_len iddle `tarN]            == s  re]_be()
     ofpFA rep& (1 << 31 m ha0            if NFA re   return]);
                }1      sid = u32tosid(rer::Retate It mi searchs aeis the
start and t milways
addexay.

* **std not actuallways.e(Clo`addex`ight use eru Thbus NFA,of sttCloghput when searchs anot actually  the est p afterntiguous NFA`set(b`wr you need
pat olone)]bin dirlace in the
alicitly impletern.   path ps, 
pattencteru This the
staewould btern. Th
    /// (cowill repoenct may     e faSa un;
puhing thun;
 to a place in the
    AIL doel.
unntiguous NFAl be
//lways
ressioe fst a l
    /// maut
// be
//addexait the   path ps, btechson annen.ie no m ired_iandat semantiant bucial.start_anchored_id
    }

 haystack   nfa::noncontigin this automatonnnnniddle:st[s fn   error::{Bdexhis aut,   reasick   primity point to lemee[ay? Sof the Dny ree w         
  NFailure tfix of ion that ipoint to lem
    /// maick co        `tarND_D     }
      #[iddle m have failed.
            if kind =)   oncontigin t == s  re]);
                } for this module  }
   ure tr_ this mod[iddle _be()
    en = kind.as_usize();
                let classes_len )          let )   this modlet class]_be()
        pFA rep= iddle `tarN]_be()
        piep=    pFA rep& (1 << 31 m ha0            if iddle `tarN
    retBdex] == s  re]);
                } NFA::new(p0uilddexet classes_len pFA rep& !(1 << 31 let class]_be()
       primite);
        let u32t(pie  == self.speer::Read
alicitl's]bin dirlace in tate thein-ression struct NFA {
 afterntiguous NFA`oncontigin t`wr you need
pat d,
    /// The  format ofseds, denss `ly helps me classes, ick contiguous NFA`  }

   `wr you need
rue// be
he est p  Thn-
    /// mauould a
  h stops, step usincurrent state's fa`set(b`wr you need
pat olone)]bin dirlace in the
alicitly impletern.h stops, s that aencteru This the
staewould btern. Th
    /// (cowill repoenctnsitions), yhat un;
puhing thun;
 to a place in the
    AIL doel.
unodureadk   nfa::noncontigin this automatonnnnn  }

   :n is_,matonnnnniddle:st'a [s fn,   red: StateID<'a>e.
#[de        = sid.aget(b     #[iddle _be()
          }

 es i.after the beginn!  }

   p a0 ]);
       }
     }

 es ts have this , iddle  ]_be()
              , rans)d.a of them have failed.
            if kind =    ranses.get(byte);
        let u32t(iddle  } _be()
    en = kind.as__     xt]=A) st p[) in
  oncontigin t t classes_len (horedTs
  teI
 cla nd.as__     xt]}, rans)   returnxt;
                }
            } else if kind    ranses.get(byte);
        let u32t(iddle  } _be()
    en = kind.as_p= iddle   }
       e               if cl_be()
    en = kin  xt]=Aiddle 2}t classes_len (horedTs
  teOnpl nd.as_,   xt]}, rans)   returnxt;
   } else if kind    ranses.get(byte);
        let u32t(iddle  } _be()
    en = kin this module  }
   ure tr_ this mod[iddle _be()
    en = kind.as_usize();
                let classes_len t o         {
) st p[) in
              _be()
    en = kin  xt  {
) st p[)          let  in
          l t classes_len (horedTs
  teSt expl ze, or tot  xt  }, rans)   returnx;point to   }
 l zrans,   }

 es ,r thisd = u32tosid(rer::E 0   /     oldo ressio the /// is somewhat smalate thebin di     er::by making someand t milways
`dst`poenct. `e, or t`wr you need
patlet ns: V a co        of eacday.

* **/ is somewhat smalaher it slways
ressiocam ns: V a c the afterntiguous NFA
     state IDa conti    `dst`pailuransocbiglaher `get(byt`ickanh lly helps  usizthat c: Sped= Seefrw:ntorizedstep usined this stateit sest p.ity  path ps, 
patfrw:ntori c: Sped afterntiguous NFAt has` Sece_me cl`whic
rueon annen. Fv 0   d/nsitinesllea
/// cdensely helps me clapatteredstep usined expea
///citly.
//es for thlure tra. It is g the FAsBuilder::buipea
kin b thated on eoldiest p afterrn wof `k   nfa::nn     &ate
    /// in a comatonnnnnold  anchored: Anchored,
old  &ate
    /// in hored,       ifus::NFA,
 us,
    util::{
     dst:streamn IDs for matces = Sece_me cl:n is_,matonrt_state(&self, anchoI, P>(patte        byte: uasses.get(byte)r() dst /u32t
     con(|e| } else if kindI, P>(patt  u   #_ d_uildf    get(byte)MAX     64rasie.  prmpt
   )   returnxas_be()
        old_ze();
n        _ this(old  a).ces: cl_be()
          }IL IDs resenta
      w the numbe     mrch,
    alldo.
    //
 slowdowns. Somces fo.A
 ou a    heporhot}IL IDs  un;
nd . Fthat r retcs rea'r/
 slowdowns.ok yhes thodc rasic     lway cdetions,apw_unchs // it sest p'w       ift  '    ' point t    cdetc: Spe       // Insitin     also     on       ift  maton.
#[de        = sid.a    Sece_me clal.sold_ze()>t  }
   MAX_SPARSE_TRANSITIONS } else if kindve failed.
         returnxt;
      old_ze();  1p&& !olde  }

    ) } else if kindve failed.
    let class]);
                }lem   }
kure transition and= sidsico.
  / st, for
    /// a spars after the begs f use itt = old_ze(e/
/// let == s  re]_be()
     of them have failed.
            if kind =dst push(-> ea;    if kind =dst push(olderans()    l32  a;    if kind =ve failwof `_me cl_ this(n   ,nold  a,ze, or totdstas_be()
    xt;
                }
            } else if kind    t);
n        _ this(old  a).  xt()/
/// let n    {
  en = kind.as_p= s f uxt = u32to       t&sses  aa;    if kind =dst push(     | (      << 8)a;    if kind =dst push(olderans()    l32  a;    if kind =dst push(t.  xt()/   l32  a;    if ki]);
                }dst push(-> ea;    if kind =dst push(olderans()    l32  a;    if kind =ve failwof `_ure tr_ this(n   ,nold  a,ze, or totdstas_be()
    x       ift  N an ior lt wof `t/ st, for
    t can on compleft can onlyemselves after the   olde  }

    ) } else if kind      }

usize();
n        _  }

us(old  a).ces: cl_be()
     the     }

usize();  1p             }        piep= n        _  }

us(old  a).  xt()/
/// let    l32   let classes =   } NFA::new(p0uipiep& (1 << 31   let classes =   }dst push((1 << 31 m|ipie  let classes = );
                }
    NFA::new(p0ui  }

usize()& (1 << 31   let classes =   }dst push(  }

usize(    l32  a;    if kind =   }dst at un;(n        _  }

us(old  a).map(|pie| i(a     32  a  let classes =    returnxbe()
    ow sie  == self.speer::E 0   /     oldo ressio s
          the /// is somewhat smalate thpath ps, bin dirwt explby making some
nd t milways
`dst`poenct. `e, or t`wr you    rew Ahoetld bomaton.
      of eacday.

* **/ is somewhat smalaher it slwaysng the FAIL IDocam c the afterntiguous NFA
     state IDa conti    `dst`pailuransocbiglaher `get(byt`ickanh lly helps  usizthat c: Sped= Seefrw:ntorizeafterrn wof `_ure tr_ this(   nfa::nn     &ate
    /// in a comatonnnnnold  anchored: Anchored,
us::NFA,
 us,
    util::{
     dst:streamn IDs for matcasick::AhoCorasiI, P>(patte        byte: u(ream
    ,     mod)d.a([0; 4], 0  let classy.

*ild ,        _ this(old  a)              }
    [  l  = u32to       t&sses  a n    {
  en = kn +;
1_be()
     the   ze();  4              }
   dst push(s f uxt =          ses_lea;    if kind =   }ses_l = [0; 4]t classes_len = u32_nes.0;
et classes =    returnxbe()
       ze()> 0            if r s pd expeae trchre// st, for
    /// a spars /t? Sodivi/ we e never follow fay 4,nding asbyte_}ses_l . It      mtranleftbuild rohe s picant slowdowns. Ssickained   "o.
 "b steNFA and asbynd
    /// sparse. B path we were on.de allocated   kneplchanleftuild faux /// a spars . It     / a neer follow fai, For adat slure tff
Ahowi a *,h a e the      eturns or adapath we were on. TihKind ncrenA and asbynd
    /// sparse. 
         cdetmtra a neer follow far    ld_frn
Aho-ntinel ato jressio s
       ed to.from_u32_uncheckensteNFA=}
    [  l - 1]t classes_len / Doin  l < 4              }
   
    [  l  = nsteNFt classes_len = u32_ne+;
1_be()
     the}
       }
   dst push(s f uxt =          ses_lea;    if ki}let classy.

*ild ,        _ this(old  a)              }dst push(t.  xt()/   l32  a;    if ki]be()
    ow gref.byte_Builder::E 0   /     oldo ressio s
          the /// is somewhat smalate thpath ps, bin diraster by making some
nd t milways
`dst`poenct. `e, or t`wr you    rew Ahoetld bomaton.
      of eacday.

* **/ is somewhat smalaher it slwaysng the FAIL IDocam c the afterntiguous NFA
     state IDa conti    `dst`pailuransocbiglaher `get(byt`ickanh lly helps  usizthat c: Sped= Seefrw:ntorizeafterrn wof `_me cl_ this(   nfa::nn     &ate
    /// in a comatonnnnnold  anchored: Anchored,
us::NFA,
 us,
    util::{
     dst:streamn IDs for matcasick::AhoCorasiI, P>(patte        bytps Ourbomaton.
     f.byte etri_l Aho-nally   It ime classes, rwould 
#[de bytps   /// The alphabet size, or t`AhoCorasicco.
  fixld_fromwou256 cerreturnat Anan algvalence
///ds, dens format of aw o.
  aI format of noeld 
#[de bytps  easiest puis realfie Ie ad,  in]);
` complenbuildoof `t/ smhes t
#[de bytps valence
///ds, dens format ofe. (Most}IL IDs probrasicng anh    on/
 slowdowns.or, whivalence
///ds, dens format ofe.)
           // the l fai.B.eReme/// Te ad,/ Doinill retur[`Buildomewhat sma,realdensstd not ac if r s Dut the coloitude less
/// heapId, t? Sois tlrea've[matthete        ift  mses, rw ad,/ slot. If ttle epoitude less
/// andno de less
/// anick co        `tarND_Ddst /u32t;
nd =   }dst at un;(            }
 ||        rtteNFtate
    /// in a contigu/   l32  a[..classes_len].i/y ta(us::N   s have this ()
          t;
nd =   } NFA::!(`tarND<Ddst /u32t, "nd
    /// sparse, arr      //ntery"  let classy.

*ild ,        _ this(old  a)              }dst `tarN
   let next = u32to       t&sses  aa]i.after the begftera.  xt()/   l32  ;   returnxbe()
    ow gref.byte_Builder::RetateIDa idError>build ethat valence
///ds, dens format of aeduce which staest p afterrn  format ofe<'b>(&'b        anu
   ldError>
    whe(u8,ways)]
  >
  'b {be()
            ies.0;
et class
 ||        xt = fn(D ind||er: Optiolf       } else if kindve faTs
  teSt expl ze, or tot  xt  }red_} else if kind == Stai >=t  xt  /u32tuss == repr[o].low_u16().high_Non/_be()
    {
   o +}       if anchore kindes_l =         i / 4]t classes_len = u32_ind.as_p=                     i % 4]t classes_len = u32_in  xt]=Aget(byte);
        let u32t(  xt [iid(repr[o + 2 + usizee+;
1_be()
     thekindvnwra(d.as_,   xt a[..classes_le} else if kindve faTs
  teOnpl nd.as_,   xt]}red_} else if kind == Stai  ha0            if 2 + usizee+;
1_be()
     thekindkindvnwra(d.as_, get(byte);
        let u32t(  xt) a[..classes_len].i );
                }
       Noificant slowdow                    }
          horedTs
  teI
 cla nd.as__     xt]}red_} else if kind == Stai >=td.as__     xt /u32tuss == repr[o].low_u16().high_Non/_be()
    {
   o +}       if anchore kind.as_p= i/   l8     let trans_len = kin  xt]=Aget(byte);
        let u32t(](cra_     xt[iid(repr[o + 2 + usizee+;
1_be()
     thekindvnwra(d.as_,   xt a[..classes_le} else if }
> Builder {
  <'a>e
 ||  fmtteI
    ct aateID<'a>e.
#[deodufmtkh    s f:stream
 ||  fmtteFatter(cr<'_>a  an
 ||  fmtteate(&s    #[test]
    fn oib{`
/// use aure tr_ this numbe  u tl::d
   teI
   us,
}_bbe()
    ecke t]=Aire tr_ this numbe(iolf       numbe( a[..classes_leNFAtparin thutealll easi format ofse hed
 tr,nois/ ifioint towa a neer follow fo.
  n: usizureaderh FAIL ochutpunonconssumeoanyts traabct Nsid = Sta to lem
 psewould b easih
    /// currens_len].i/ation a|&(_, _s e(aa.startclass)]);
  a[..classes_leepr[o + 2..] let classy.

 cla(`tarN,hun;s e(aaen;
e t]{
es = chunk.to_ni > 0            if claswof `!( s ",/"as_be()
    {
  }after the beginn,tarND_=hun;
           if claswof `!( s "{:?}red_}:?}"s I
   us,
(`tarN),        loop {
as_be()
    {
  });
                }
   wof `!(rans_offset = o + o +            }
         "{:?}-{:?}red_}:?}"s          }
         I
   us,
(`tarN),          }
         I
   us,
(un;),          }
                loop {
          }
     as_be()
    {
  }after the}be()
    ow gref.byte_classesA import sy.

ilder`]  traanenience method for returningyyn std::e
    import shasailuub    ///  ochpnumber vaila)
/// `aown vershoce methoguration.( fn oibshoce methoguratio). O ByteClaa nerhpnumbeo, the giirt semantiootp dpw_ucalyyn`] documentats I
   ion for an exaFA` type.
    ate
    /// in ate
    /// in:FA` typ,     me cl_depttchs automatondistinct
    / is_,mer {
   Dorasicsy.

FA` type.
    fn-Corasicthe `NFA` type.
    pub fn buil              }ate
    /// in ate
    /// in:FA` typder() -,          }
 me cl_depttch2,          }
 distinct
    /
rueo      sid = u32toer {
   fn buil       ecial: Special,
}import sy.

ilder`]  traanenience method for returningyylen pto changethe `NFA` type.
    pub fn buildeCorasicthf.byte_Builder::fn buaanenience method for returningt the cololways
adError>bu path ps, ond(&ser afterntiguous NFAA import s, yhbzureusthe Dnc: Spe ions,ings one to just impor the coh    s ifiguration.
    pub fn new<I, P>(patterns: I) -> Result<NFA, BuildError>
    where
        I: IntoIterator<Item = P>,
     kin    pr = &seate
    /// iu8]>,
    {
    s_be()
    ind(&s]>,
_xt =  te
    /// i(&    hf.byte_Builder::fn buaanenience method for returningt the cololways
itude less
/// heaurrent state's failure tranwannen.ie Fns)
   The lmatcing aClo`me cl_deptt`raking the FA`distinct
   `wn
 ttngutonen.ie import saizurered_ped e(Clo tep which stae
 ttngutonng appng aobe
//ad //emed /// strome
/// usunience metho g the FAsBuilderope the ea new Ahie Fns)
  n: usizsIe ad,   //emed /// stromeh stops, it r l
 ane/// Vereve,aillnd
 ttngutihat din thg annt //emed /// stromeh stops, rr   o  usizthrelev thione to just impor_xt =  te
    /// i(inline(always)]
    fn nn     &ate
    /// in a comaton.
    pub fn new<I, P>(patte = P>,
    d
   !("ill returde less
/// he" _be()
        distinct
   d.a   ind(&sses`](crate              }a    sses`](crate{
 entat   == s  re]);
                }us,
    uti::uaBecatmbe( let class]_be()
         utilddex_   u   #_ dd.avec![StateID) ;oa    mses, {
 /u32t]_be()
         uti   pr s well.
unlow_u16().pr:avec![n,   return NFAid state
   :oa    id state
   _raeth    vec -,          }
 number of:oa    mses, {
 /u32t,   return NFAiing searcha    intation a).map(|p| p.entat  t,   return NFAself) -> echa      }

    #[t,   return NFAoncontigin thilf.repr;
    s have this (),          }
 distinct
   ,   return NFAst pattern in tcha     t pattern in t t,   return NFAsexpattern in tcha      xpattern in t t,   return NFA
    maotd_id
 _state' 
 arr     
   rcurrens_len].iotd_id
: Std_id
::zero t,   return} let classy.

 old  a,ziddle  ld ,    mses, {
      rees t u   #_ ds2tuss == repr[o].lemee[ay? Soh. Since & 0   /a ranse_statesthe ere le keenecessaryline
           
    wnsstie Il pare trakever be . D// By wise clm    apath we were on.aim thaly after the beginnold  aD_=hate
    /// in a contigu_} else if kind == Sddex_   u   #_ d[old  a] lass)]);
  ;    if kind =   }s    nue_be()
    {
      return NFAecke Sece_me cla=Aiddle.deptt()            < ind(&me cl_deptt_be()
    en = kin  wssses.get(b  wof `k   nfa::n       }a   ,          }
     old  a,          }
      IL d,          }
     &    sses`](crate,          }
     & uti   State,be()
    {
   o + 2 ce_me cl, == s  return)s_be()
    {
  Sddex_   u   #_ d[old  a] la  wsss;    if ki}let classy.

&  wsssein Sddex_   u   #_ d      r]{
es = chunk.to_n  wssseslass)]);
                if nes    nue_be()
    {
      return NFAecke`table  & uti   State[  wsss    loop {
 ines.get(rep);
   }
   rtmap(   Ss have this , )Sddex_   u   #_ d,ziddle s_be()
    x       ift  N anw ad,/ 've[rtmappthete I usu and// It imses, ,ete I uais mleft       ift      smappetur[`Buotd_id
 _state' 
.      byte: u8, epo= )Sddex_   u   #_ d_be()
        oldp= n    

    #[ _be()
        l,
}  & uti   S

    #;cerreturnfrwbool {
         = ns ep[oldbool {
        ];cerreturnfrwbool d(sid) & = ns ep[oldbool d(sid) &];cerreturnfrwbool {
        sid = = ns ep[oldbool {
        sid =];cerreturnfrwbool {
      sid = = ns ep[oldbool {
      sid =];cerreturnd
   !(s.get(rep);
 " for returningtill t, <mses, ch{:?},-nallch{:?},-\            ifatch_kindn_pch{:?}>"s          }
     mses,his ,   return NFA     order_ature ),   return NFA    lf.repr;
    s have this (),         l_be()
         mavecor>ickanhgr an~tw///ca cbigedick aud /// strome
 slure tipoint to lemVec ardetallshgr ath.
    ha *,h   'e etri_l Ahtngut. If causetopoint to lemw ad,/ sh. Since f thesthe enc'r      //gort and mat ions,ote t cerreturnf  State.etri_l_   fi cl_be()
        id state
   .etri_l_   fi cl_be()
    Ok(   hf.byte_Builder::Setansitdesi nerr: Optiomaw_ucs afterntiguous NFA
    ng anappniDs rannea new [`fn buildeill r`]are defi   rewn verfn buildeill r_xt =  te
    /// i`] afterntiguous NFASee   rewn vershoce methoguratio    }

    #n.( fn oibshoce methoguratio    }

    #)ns: V a c .

ions,documt NFA {

/e dSamwises one to just   }

    #[i        s -> echays)]
   .
   i    FA` type.
    pub = &seate
    /// iu  }

    #[-> ea;    if ki= &sf.byte_Builder::E a)
//ASCII-awe cleae ti cl   //ve , its tr afterntiguous NFA
    ng anappniDs rannea new [`fn buildeill r`]are defi   rewn verfn buildeill r_xt =  te
    /// i`] afterntiguous NFASee   rewn vershoce methoguratio  ascii_eae _i cl   //ven.( fn oibshoce methoguratio  ascii_eae _i cl   //ve)ns: V a c .

ions,documt NFA {

/e dSamwises one to just ascii_eae _i cl   //ve[i        s y   / is_.
   i    FA` type.
    pub = &seate
    /// iuascii_eae _i cl   //ve[y  a;    if ki= &sf.byte_Builder::E a)
//heicks>ic intation rhpnumizaspars afterntiguous NFA
    ng anappniDs rannea new [`fn buildeill r`]are defi   rewn verfn buildeill r_xt =  te
    /// i`] afterntiguous NFASee   rewn vershoce methoguratio  intation n.( fn oibshoce methoguratio  intation )ns: V a c .

ions,documt NFA {

/e dSamwises one to just cntation an        s y   / is_.
   i    FA` type.
    pub = &seate
    /// iucntation ay  a;    if ki= &sf.byte_Builder::Setansitlior
b{

h an, . Dmses, rdense aster by making some
y.

* *irl#[derivew the numbeedstep }IL IDs ree Igenerince dense  i explby making some afterntiguous NFASee   rewn vershoce methoguratio  me cl_deptt`.( fn oibshoce methoguratio  me cl_deptt)ns: V a c .

ions,documt NFA {

/e dSamwises one to just me cl_depttan        s depttchs aut.
   i    FA` type.
    pub = &seme cl_depttD_Ddeptt_be()
    = &sf.byte_Builder::And
   nd
 ttngc .

rantep }nd m prmptalso tri_l Aho-nally    reng the FAsBuildero'smatch_kindSeefot afterntiguous NFA
    r you nion that e a)
/d un NFA,you'r  d
   g traanesBuilderoptate's faiamh fasdisa)
 traomaton.
     rakesi format ofseemetp }nd rememeh stops, rAut ,esthe eAhowire tAhosh. Sinaomatt`AhoCorasiccnd
    /// sparse, ptate's faDisa)
 tra Ssickonferh nels fpatten//citntatteverntinel ato  afterntiguous NFASee   rewn vershoce methoguratio  distinct
   `.( fn oibshoce methoguratio  sses`](crate:ns: V a c .

ions,documt NFA {

/e dSamwises one to just sses`](crate{n        s y   / is_.
   i    FA` type.
    pub = &sedistinct
   d.ay  _be()
    = &sf.byte_classesCof eacs// st, for
    te_} on thef ththe Dnby making  ///omatope`std::/ps   /// The  format ofselways.
st         nas
  ncs aut.
   <ually pointo_n       % 4  ha0                  >> 2
  re]);
             (       >> 2)
   f.byte_cla#[cfg(es,
)]
mohe s,
s       ecA
    es,
 dord///  IDs a SWAR eschniqu tI trndatrn
Aho-nre tra/// a spar
ere on.aid ti cidly   '  xt u   #'. Namh fasere tra/// a spars ok a/om
ere on.adErroin thn thte_}ses_lted s th: Vecdes_l 
   ainin tup to 4 nct
   
ere on.aim te
start and 4ew the numbeed
    SWAR eschniqu t    cdetf    ely help , its tra format of nd wheth
  n ttetur[`Bu;
 entch [u8; 4] afterntly help Itals_adatounoncoat itlittlr, rep thtn .
t   th fasory foot? Soeolly helpver pcksetu,esthe eAhde coAtion anaeAhrple punoornd eveghpnumizaspar afternt LeID:unro expoaAho-Coraremnce  elpcdetailure tAho} o
    j libyo c
  ift  mses, rh    that few /// a spars afterntly help A t///,a Ssickodlywasaillittlr,trnckg aobwof `uis rIh
  n ttrepita/ `aowdowns. s,
 rn
eae tmtra ///er`] nt the heplconre tfixions,effecobuild,of sly help Ih
 ou  afterntly help (rasic     ng anok autonelittlr,etaran iSoebigeetaran e the e the Dnis g the sh.ces: ed= Seeo_n/ son thdecihthe Dnre tAhsicI Ahtnkoel.
uncicfg(earg thetaran = "littlr"ored_id#[ s,
ton for NFwe  r]{
es = chudenssupio  *_bbe()
    r Nhas_zero     (x:D;
    an<
 e{   returnfterom thiLO_U32:D;
 es.0 01010101;   returnfterom thiHI_U32:D;
 es.0 80808080_bbe()
        x.// lpetu_sub(LO_U32)p& !xp& HI_U32be()
    x be()
    r Nbroadeaet(b       an<
 e{   returnfter(s f uxt =(b)) *r(s f uMAX / 255)be()
    x be()
    r NSddex_of(x:D;
    an<ually point to         oi.after the begfter(((x - 1)();
 01010101).// lpetu_mul(
 01010101) >> 24) - 1;   returnftero            == s  re]
be()
        dist nc[u8; 4] = [b'1', b'A', b'a', b'z']_be()
        des_l = s f uxt =               )_bbe()
    eckee thlle  broadeaet(b'1't;
nd =   } NFA::new(p0uilddex_of(has_zero     (e thlle^ ses_lea _be()
        l,thlle  broadeaet(b'A't;
nd =   } NFA::new(p1uilddex_of(has_zero     (e thlle^ ses_lea _be()
        l,thlle  broadeaet(b'a't;
nd =   } NFA::new(p2uilddex_of(has_zero     (e thlle^ ses_lea _be()
        l,thlle  broadeaet(b'z't;
nd =   } NFA::new(p3uilddex_of(has_zero     (e thlle^ ses_lea _be()
e_cl                                  