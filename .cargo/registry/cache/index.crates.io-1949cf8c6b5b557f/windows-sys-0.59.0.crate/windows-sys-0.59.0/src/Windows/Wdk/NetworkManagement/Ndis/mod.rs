windows_targets::link!("ndis.sys" "system" fn NdisAcquireReadWriteLock(lock : *mut NDIS_RW_LOCK, fwrite : super::super::super::Win32::Foundation:: BOOLEAN, lockstate : *mut LOCK_STATE));
windows_targets::link!("ndis.sys" "system" fn NdisAllocateMemoryWithTag(virtualaddress : *mut *mut core::ffi::c_void, length : u32, tag : u32) -> i32);
#[cfg(all(feature = "Wdk_Foundation", feature = "Wdk_System_SystemServices", feature = "Win32_System_Kernel"))]
windows_targets::link!("ndis.sys" "system" fn NdisCancelTimer(timer : *const NDIS_TIMER, timercancelled : *mut super::super::super::Win32::Foundation:: BOOLEAN));
windows_targets::link!("ndis.sys" "system" fn NdisClAddParty(ndisvchandle : *const core::ffi::c_void, protocolpartycontext : *const core::ffi::c_void, callparameters : *mut CO_CALL_PARAMETERS, ndispartyhandle : *mut *mut core::ffi::c_void) -> i32);
windows_targets::link!("ndis.sys" "system" fn NdisClCloseAddressFamily(ndisafhandle : *const core::ffi::c_void) -> i32);
windows_targets::link!("ndis.sys" "system" fn NdisClCloseCall(ndisvchandle : *const core::ffi::c_void, ndispartyhandle : *const core::ffi::c_void, buffer : *const core::ffi::c_void, size : u32) -> i32);
windows_targets::link!("ndis.sys" "system" fn NdisClDeregisterSap(ndissaphandle : *const core::ffi::c_void) -> i32);
windows_targets::link!("ndis.sys" "system" fn NdisClDropParty(ndispartyhandle : *const core::ffi::c_void, buffer : *const core::ffi::c_void, size : u32) -> i32);
windows_targets::link!("ndis.sys" "system" fn NdisClGetProtocolVcContextFromTapiCallId(tapicallid : super::super::super::Win32::Foundation:: UNICODE_STRING, protocolvccontext : *mut *mut core::ffi::c_void) -> i32);
windows_targets::link!("ndis.sys" "system" fn NdisClIncomingCallComplete(status : i32, ndisvchandle : *const core::ffi::c_void, callparameters : *const CO_CALL_PARAMETERS));
windows_targets::link!("ndis.sys" "system" fn NdisClMakeCall(ndisvchandle : *const core::ffi::c_void, callparameters : *mut CO_CALL_PARAMETERS, protocolpartycontext : *const core::ffi::c_void, ndispartyhandle : *mut *mut core::ffi::c_void) -> i32);
windows_targets::link!("ndis.sys" "system" fn NdisClModifyCallQoS(ndisvchandle : *const core::ffi::c_void, callparameters : *const CO_CALL_PARAMETERS) -> i32);
windows_targets::link!("ndis.sys" "system" fn NdisClRegisterSap(ndisafhandle : *const core::ffi::c_void, protocolsapcontext : *const core::ffi::c_void, sap : *const CO_SAP, ndissaphandle : *mut *mut core::ffi::c_void) -> i32);
windows_targets::link!("ndis.sys" "system" fn NdisCloseConfiguration(configurationhandle : *const core::ffi::c_void));
windows_targets::link!("ndis.sys" "system" fn NdisCloseFile(filehandle : *const core::ffi::c_void));
windows_targets::link!("ndis.sys" "system" fn NdisCmActivateVc(ndisvchandle : *const core::ffi::c_void, callparameters : *mut CO_CALL_PARAMETERS) -> i32);
windows_targets::link!("ndis.sys" "system" fn NdisCmAddPartyComplete(status : i32, ndispartyhandle : *const core::ffi::c_void, callmgrpartycontext : *const core::ffi::c_void, callparameters : *const CO_CALL_PARAMETERS));
windows_targets::link!("ndis.sys" "system" fn NdisCmCloseAddressFamilyComplete(status : i32, ndisafhandle : *const core::ffi::c_void));
windows_targets::link!("ndis.sys" "system" fn NdisCmCloseCallComplete(status : i32, ndisvchandle : *const core::ffi::c_void, ndispartyhandle : *const core::ffi::c_void));
windows_targets::link!("ndis.sys" "system" fn NdisCmDeactivateVc(ndisvchandle : *const core::ffi::c_void) -> i32);
windows_targets::link!("ndis.sys" "system" fn NdisCmDeregisterSapComplete(status : i32, ndissaphandle : *const core::ffi::c_void));
windows_targets::link!("ndis.sys" "system" fn NdisCmDispatchCallConnected(ndisvchandle : *const core::ffi::c_void));
windows_targets::link!("ndis.sys" "system" fn NdisCmDispatchIncomingCall(ndissaphandle : *const core::ffi::c_void, ndisvchandle : *const core::ffi::c_void, callparameters : *const CO_CALL_PARAMETERS) -> i32);
windows_targets::link!("ndis.sys" "system" fn NdisCmDispatchIncomingCallQoSChange(ndisvchandle : *const core::ffi::c_void, callparameters : *const CO_CALL_PARAMETERS));
windows_targets::link!("ndis.sys" "system" fn NdisCmDispatchIncomingCloseCall(closestatus : i32, ndisvchandle : *const core::ffi::c_void, buffer : *const core::ffi::c_void, size : u32));
windows_targets::link!("ndis.sys" "system" fn NdisCmDispatchIncomingDropParty(dropstatus : i32, ndispartyhandle : *const core::ffi::c_void, buffer : *const core::ffi::c_void, size : u32));
windows_targets::link!("ndis.sys" "system" fn NdisCmDropPartyComplete(status : i32, ndispartyhandle : *const core::ffi::c_void));
windows_targets::link!("ndis.sys" "system" fn NdisCmMakeCallComplete(status : i32, ndisvchandle : *const core::ffi::c_void, ndispartyhandle : *const core::ffi::c_void, callmgrpartycontext : *const core::ffi::c_void, callparameters : *const CO_CALL_PARAMETERS));
windows_targets::link!("ndis.sys" "system" fn NdisCmModifyCallQoSComplete(status : i32, ndisvchandle : *const core::ffi::c_void, callparameters : *const CO_CALL_PARAMETERS));
windows_targets::link!("ndis.sys" "system" fn NdisCmOpenAddressFamilyComplete(status : i32, ndisafhandle : *const core::ffi::c_void, callmgrafcontext : *const core::ffi::c_void));
windows_targets::link!("ndis.sys" "system" fn NdisCmRegisterSapComplete(status : i32, ndissaphandle : *const core::ffi::c_void, callmgrsapcontext : *const core::ffi::c_void));
windows_targets::link!("ndis.sys" "system" fn NdisCoAssignInstanceName(ndisvchandle : *const core::ffi::c_void, baseinstancename : *const super::super::super::Win32::Foundation:: UNICODE_STRING, vcinstancename : *mut super::super::super::Win32::Foundation:: UNICODE_STRING) -> i32);
windows_targets::link!("ndis.sys" "system" fn NdisCoCreateVc(ndisbindinghandle : *const core::ffi::c_void, ndisafhandle : *const core::ffi::c_void, protocolvccontext : *const core::ffi::c_void, ndisvchandle : *mut *mut core::ffi::c_void) -> i32);
windows_targets::link!("ndis.sys" "system" fn NdisCoDeleteVc(ndisvchandle : *const core::ffi::c_void) -> i32);
windows_targets::link!("ndis.sys" "system" fn NdisCoGetTapiCallId(ndisvchandle : *const core::ffi::c_void, tapicallid : *mut VAR_STRING) -> i32);
#[cfg(feature = "Wdk_Foundation")]
windows_targets::link!("ndis.sys" "system" fn NdisCompleteDmaTransfer(status : *mut i32, ndisdmahandle : *mut core::ffi::c_void, buffer : *mut super::super::Foundation:: MDL, offset : u32, length : u32, writetodevice : super::super::super::Win32::Foundation:: BOOLEAN));
#[cfg(feature = "Wdk_Foundation")]
windows_targets::link!("ndis.sys" "system" fn NdisCopyBuffer(status : *mut i32, buffer : *mut *mut super::super::Foundation:: MDL, poolhandle : *const core::ffi::c_void, memorydescriptor : *const core::ffi::c_void, offset : u32, length : u32));
windows_targets::link!("ndis.sys" "system" fn NdisDeregisterTdiCallBack());
windows_targets::link!("ndis.sys" "system" fn NdisFreeMemory(virtualaddress : *const core::ffi::c_void, length : u32, memoryflags : u32));
windows_targets::link!("ndis.sys" "system" fn NdisGeneratePartialCancelId() -> u8);
windows_targets::link!("ndis.sys" "system" fn NdisGetCurrentProcessorCounts(pidlecount : *mut u32, pkernelanduser : *mut u32, pindex : *mut u32));
windows_targets::link!("ndis.sys" "system" fn NdisGetCurrentProcessorCpuUsage(pcpuusage : *mut u32));
windows_targets::link!("ndis.sys" "system" fn NdisGetRoutineAddress(ndisroutinename : *const super::super::super::Win32::Foundation:: UNICODE_STRING) -> *mut core::ffi::c_void);
windows_targets::link!("ndis.sys" "system" fn NdisGetSharedDataAlignment() -> u32);
windows_targets::link!("ndis.sys" "system" fn NdisGetVersion() -> u32);
windows_targets::link!("ndis.sys" "system" fn NdisIMAssociateMiniport(driverhandle : *const core::ffi::c_void, protocolhandle : *const core::ffi::c_void));
windows_targets::link!("ndis.sys" "system" fn NdisIMCancelInitializeDeviceInstance(driverhandle : *const core::ffi::c_void, deviceinstance : *const super::super::super::Win32::Foundation:: UNICODE_STRING) -> i32);
windows_targets::link!("ndis.sys" "system" fn NdisIMDeInitializeDeviceInstance(ndisminiporthandle : *const core::ffi::c_void) -> i32);
windows_targets::link!("ndis.sys" "system" fn NdisIMGetBindingContext(ndisbindinghandle : *const core::ffi::c_void) -> *mut core::ffi::c_void);
windows_targets::link!("ndis.sys" "system" fn NdisIMInitializeDeviceInstanceEx(driverhandle : *const core::ffi::c_void, driverinstance : *const super::super::super::Win32::Foundation:: UNICODE_STRING, devicecontext : *const core::ffi::c_void) -> i32);
#[cfg(all(feature = "Wdk_Foundation", feature = "Win32_System_Kernel"))]
windows_targets::link!("ndis.sys" "system" fn NdisInitializeEvent(event : *mut NDIS_EVENT));
windows_targets::link!("ndis.sys" "system" fn NdisInitializeReadWriteLock(lock : *mut NDIS_RW_LOCK));
windows_targets::link!("ndis.sys" "system" fn NdisInitializeString(destination : *mut super::super::super::Win32::Foundation:: UNICODE_STRING, source : *const u8));
#[cfg(all(feature = "Wdk_Foundation", feature = "Wdk_System_SystemServices", feature = "Win32_System_Kernel"))]
windows_targets::link!("ndis.sys" "system" fn NdisInitializeTimer(timer : *mut NDIS_TIMER, timerfunction : PNDIS_TIMER_FUNCTION, functioncontext : *const core::ffi::c_void));
windows_targets::link!("ndis.sys" "system" fn NdisMAllocateSharedMemory(miniportadapterhandle : *const core::ffi::c_void, length : u32, cached : super::super::super::Win32::Foundation:: BOOLEAN, virtualaddress : *mut *mut core::ffi::c_void, physicaladdress : *mut i64));
windows_targets::link!("ndis.sys" "system" fn NdisMAllocateSharedMemoryAsync(miniportadapterhandle : *const core::ffi::c_void, length : u32, cached : super::super::super::Win32::Foundation:: BOOLEAN, context : *const core::ffi::c_void) -> i32);
#[cfg(all(feature = "Wdk_Foundation", feature = "Wdk_System_SystemServices", feature = "Win32_System_Kernel"))]
windows_targets::link!("ndis.sys" "system" fn NdisMCancelTimer(timer : *const NDIS_MINIPORT_TIMER, timercancelled : *mut super::super::super::Win32::Foundation:: BOOLEAN));
windows_targets::link!("ndis.sys" "system" fn NdisMCloseLog(loghandle : *const core::ffi::c_void));
windows_targets::link!("ndis.sys" "system" fn NdisMCmActivateVc(ndisvchandle : *const core::ffi::c_void, callparameters : *const CO_CALL_PARAMETERS) -> i32);
windows_targets::link!("ndis.sys" "system" fn NdisMCmCreateVc(miniportadapterhandle : *const core::ffi::c_void, ndisafhandle : *const core::ffi::c_void, miniportvccontext : *const core::ffi::c_void, ndisvchandle : *mut *mut core::ffi::c_void) -> i32);
windows_targets::link!("ndis.sys" "system" fn NdisMCmDeactivateVc(ndisvchandle : *const core::ffi::c_void) -> i32);
windows_targets::link!("ndis.sys" "system" fn NdisMCmDeleteVc(ndisvchandle : *const core::ffi::c_void) -> i32);
windows_targets::link!("ndis.sys" "system" fn NdisMCmRegisterAddressFamily(miniportadapterhandle : *mut core::ffi::c_void, addressfamily : *mut CO_ADDRESS_FAMILY, cmcharacteristics : *mut NDIS_CALL_MANAGER_CHARACTERISTICS, sizeofcmcharacteristics : u32) -> i32);
windows_targets::link!("ndis.sys" "system" fn NdisMCoActivateVcComplete(status : i32, ndisvchandle : *const core::ffi::c_void, callparameters : *const CO_CALL_PARAMETERS));
windows_targets::link!("ndis.sys" "system" fn NdisMCoDeactivateVcComplete(status : i32, ndisvchandle : *const core::ffi::c_void));
windows_targets::link!("ndis.sys" "system" fn NdisMCreateLog(miniportadapterhandle : *const core::ffi::c_void, size : u32, loghandle : *mut *mut core::ffi::c_void) -> i32);
windows_targets::link!("ndis.sys" "system" fn NdisMDeregisterDmaChannel(miniportdmahandle : *const core::ffi::c_void));
windows_targets::link!("ndis.sys" "system" fn NdisMDeregisterIoPortRange(miniportadapterhandle : *const core::ffi::c_void, initialport : u32, numberofports : u32, portoffset : *const core::ffi::c_void));
windows_targets::link!("ndis.sys" "system" fn NdisMFlushLog(loghandle : *const core::ffi::c_void));
windows_targets::link!("ndis.sys" "system" fn NdisMFreeSharedMemory(miniportadapterhandle : *const core::ffi::c_void, length : u32, cached : super::super::super::Win32::Foundation:: BOOLEAN, virtualaddress : *const core::ffi::c_void, physicaladdress : i64));
#[cfg(all(feature = "Wdk_Foundation", feature = "Wdk_Storage_FileSystem", feature = "Wdk_System_SystemServices", feature = "Win32_Security", feature = "Win32_System_IO", feature = "Win32_System_Kernel", feature = "Win32_System_Power"))]
windows_targets::link!("ndis.sys" "system" fn NdisMGetDeviceProperty(miniportadapterhandle : *const core::ffi::c_void, physicaldeviceobject : *mut *mut super::super::Foundation:: DEVICE_OBJECT, functionaldeviceobject : *mut *mut super::super::Foundation:: DEVICE_OBJECT, nextdeviceobject : *mut *mut super::super::Foundation:: DEVICE_OBJECT, allocatedresources : *mut *mut super::super::System::SystemServices:: CM_RESOURCE_LIST, allocatedresourcestranslated : *mut *mut super::super::System::SystemServices:: CM_RESOURCE_LIST));
windows_targets::link!("ndis.sys" "system" fn NdisMGetDmaAlignment(miniportadapterhandle : *const core::ffi::c_void) -> u32);
#[cfg(all(feature = "Wdk_Foundation", feature = "Wdk_System_SystemServices", feature = "Win32_System_Kernel"))]
windows_targets::link!("ndis.sys" "system" fn NdisMInitializeTimer(timer : *const NDIS_MINIPORT_TIMER, miniportadapterhandle : *const core::ffi::c_void, timerfunction : PNDIS_TIMER_FUNCTION, functioncontext : *const core::ffi::c_void));
windows_targets::link!("ndis.sys" "system" fn NdisMMapIoSpace(virtualaddress : *mut *mut core::ffi::c_void, miniportadapterhandle : *const core::ffi::c_void, physicaladdress : i64, length : u32) -> i32);
windows_targets::link!("ndis.sys" "system" fn NdisMQueryAdapterInstanceName(padapterinstancename : *mut super::super::super::Win32::Foundation:: UNICODE_STRING, miniporthandle : *const core::ffi::c_void) -> i32);
windows_targets::link!("ndis.sys" "system" fn NdisMReadDmaCounter(miniportdmahandle : *const core::ffi::c_void) -> u32);
#[cfg(feature = "Wdk_System_SystemServices")]
windows_targets::link!("ndis.sys" "system" fn NdisMRegisterDmaChannel(miniportdmahandle : *mut *mut core::ffi::c_void, miniportadapterhandle : *const core::ffi::c_void, dmachannel : u32, dma32bitaddresses : super::super::super::Win32::Foundation:: BOOLEAN, dmadescription : *const NDIS_DMA_DESCRIPTION, maximumlength : u32) -> i32);
windows_targets::link!("ndis.sys" "system" fn NdisMRegisterIoPortRange(portoffset : *mut *mut core::ffi::c_void, miniportadapterhandle : *const core::ffi::c_void, initialport : u32, numberofports : u32) -> i32);
windows_targets::link!("ndis.sys" "system" fn NdisMRemoveMiniport(miniporthandle : *const core::ffi::c_void) -> i32);
#[cfg(all(feature = "Wdk_Foundation", feature = "Wdk_System_SystemServices", feature = "Win32_System_Kernel"))]
windows_targets::link!("ndis.sys" "system" fn NdisMSetPeriodicTimer(timer : *const NDIS_MINIPORT_TIMER, millisecondperiod : u32));
windows_targets::link!("ndis.sys" "system" fn NdisMSleep(microsecondstosleep : u32));
windows_targets::link!("ndis.sys" "system" fn NdisMUnmapIoSpace(miniportadapterhandle : *const core::ffi::c_void, virtualaddress : *const core::ffi::c_void, length : u32));
windows_targets::link!("ndis.sys" "system" fn NdisMWriteLogData(loghandle : *const core::ffi::c_void, logbuffer : *const core::ffi::c_void, logbuffersize : u32) -> i32);
windows_targets::link!("ndis.sys" "system" fn NdisMapFile(status : *mut i32, mappedbuffer : *mut *mut core::ffi::c_void, filehandle : *const core::ffi::c_void));
windows_targets::link!("ndis.sys" "system" fn NdisOpenConfigurationKeyByIndex(status : *mut i32, configurationhandle : *const core::ffi::c_void, index : u32, keyname : *mut super::super::super::Win32::Foundation:: UNICODE_STRING, keyhandle : *mut *mut core::ffi::c_void));
windows_targets::link!("ndis.sys" "system" fn NdisOpenConfigurationKeyByName(status : *mut i32, configurationhandle : *const core::ffi::c_void, subkeyname : *const super::super::super::Win32::Foundation:: UNICODE_STRING, subkeyhandle : *mut *mut core::ffi::c_void));
windows_targets::link!("ndis.sys" "system" fn NdisOpenFile(status : *mut i32, filehandle : *mut *mut core::ffi::c_void, filelength : *mut u32, filename : *const super::super::super::Win32::Foundation:: UNICODE_STRING, highestacceptableaddress : i64));
windows_targets::link!("ndis.sys" "system" fn NdisQueryAdapterInstanceName(padapterinstancename : *mut super::super::super::Win32::Foundation:: UNICODE_STRING, ndisbindinghandle : *const core::ffi::c_void) -> i32);
windows_targets::link!("ndis.sys" "system" fn NdisQueryBindInstanceName(padapterinstancename : *mut super::super::super::Win32::Foundation:: UNICODE_STRING, bindingcontext : *const core::ffi::c_void) -> i32);
windows_targets::link!("ndis.sys" "system" fn NdisReEnumerateProtocolBindings(ndisprotocolhandle : *const core::ffi::c_void));
windows_targets::link!("ndis.sys" "system" fn NdisReadConfiguration(status : *mut i32, parametervalue : *mut *mut NDIS_CONFIGURATION_PARAMETER, configurationhandle : *const core::ffi::c_void, keyword : *const super::super::super::Win32::Foundation:: UNICODE_STRING, parametertype : NDIS_PARAMETER_TYPE));
windows_targets::link!("ndis.sys" "system" fn NdisReadNetworkAddress(status : *mut i32, networkaddress : *mut *mut core::ffi::c_void, networkaddresslength : *mut u32, configurationhandle : *const core::ffi::c_void));
windows_targets::link!("ndis.sys" "system" fn NdisRegisterTdiCallBack(registercallback : TDI_REGISTER_CALLBACK, pnphandler : TDI_PNP_HANDLER));
windows_targets::link!("ndis.sys" "system" fn NdisReleaseReadWriteLock(lock : *mut NDIS_RW_LOCK, lockstate : *const LOCK_STATE));
#[cfg(all(feature = "Wdk_Foundation", feature = "Win32_System_Kernel"))]
windows_targets::link!("ndis.sys" "system" fn NdisResetEvent(event : *const NDIS_EVENT));
#[cfg(all(feature = "Wdk_Foundation", feature = "Win32_System_Kernel"))]
windows_targets::link!("ndis.sys" "system" fn NdisSetEvent(event : *const NDIS_EVENT));
#[cfg(all(feature = "Wdk_Foundation", feature = "Wdk_System_SystemServices", feature = "Win32_System_Kernel"))]
windows_targets::link!("ndis.sys" "system" fn NdisSetPeriodicTimer(ndistimer : *const NDIS_TIMER, millisecondsperiod : u32));
#[cfg(all(feature = "Wdk_Foundation", feature = "Wdk_System_SystemServices", feature = "Win32_System_Kernel"))]
windows_targets::link!("ndis.sys" "system" fn NdisSetTimer(timer : *const NDIS_TIMER, millisecondstodelay : u32));
#[cfg(all(feature = "Wdk_Foundation", feature = "Wdk_System_SystemServices", feature = "Win32_System_Kernel"))]
windows_targets::link!("ndis.sys" "system" fn NdisSetTimerEx(ndistimer : *const NDIS_TIMER, millisecondstodelay : u32, functioncontext : *const core::ffi::c_void));
#[cfg(feature = "Wdk_Foundation")]
windows_targets::link!("ndis.sys" "system" fn NdisSetupDmaTransfer(status : *mut i32, ndisdmahandle : *mut core::ffi::c_void, buffer : *mut super::super::Foundation:: MDL, offset : u32, length : u32, writetodevice : super::super::super::Win32::Foundation:: BOOLEAN));
windows_targets::link!("ndis.sys" "system" fn NdisSystemProcessorCount() -> i8);
windows_targets::link!("ndis.sys" "system" fn NdisUnmapFile(filehandle : *const core::ffi::c_void));
windows_targets::link!("ndis.sys" "system" fn NdisUpdateSharedMemory(ndisadapterhandle : *mut core::ffi::c_void, length : u32, virtualaddress : *mut core::ffi::c_void, physicaladdress : i64));
#[cfg(all(feature = "Wdk_Foundation", feature = "Win32_System_Kernel"))]
windows_targets::link!("ndis.sys" "system" fn NdisWaitEvent(event : *const NDIS_EVENT, mstowait : u32) -> super::super::super::Win32::Foundation:: BOOLEAN);
windows_targets::link!("ndis.sys" "system" fn NdisWriteConfiguration(status : *mut i32, configurationhandle : *const core::ffi::c_void, keyword : *const super::super::super::Win32::Foundation:: UNICODE_STRING, parametervalue : *const NDIS_CONFIGURATION_PARAMETER));
windows_targets::link!("ndis.sys" "cdecl" fn NdisWriteErrorLogEntry(ndisadapterhandle : *const core::ffi::c_void, errorcode : u32, numberoferrorvalues : u32, ...));
windows_targets::link!("ndis.sys" "system" fn NdisWriteEventLogEntry(loghandle : *const core::ffi::c_void, eventcode : i32, uniqueeventvalue : u32, numstrings : u16, stringslist : *const core::ffi::c_void, datasize : u32, data : *const core::ffi::c_void) -> i32);
pub const AUTHENTICATE: OFFLOAD_OPERATION_E = 1i32;
pub const BINARY_COMPATIBLE: u32 = 0u32;
pub const BROADCAST_VC: u32 = 8u32;
pub const CALL_PARAMETERS_CHANGED: u32 = 2u32;
pub const CLOCK_NETWORK_DERIVED: u32 = 2u32;
pub const CLOCK_PRECISION: u32 = 4u32;
pub const CO_ADDRESS_FAMILY_PROXY: u32 = 2147483648u32;
pub const CO_SEND_FLAG_SET_DISCARD_ELIBILITY: u32 = 1u32;
pub const CRYPTO_GENERIC_ERROR: u32 = 1u32;
pub const CRYPTO_INVALID_PACKET_SYNTAX: u32 = 6u32;
pub const CRYPTO_INVALID_PROTOCOL: u32 = 7u32;
pub const CRYPTO_SUCCESS: u32 = 0u32;
pub const CRYPTO_TRANSPORT_AH_AUTH_FAILED: u32 = 2u32;
pub const CRYPTO_TRANSPORT_ESP_AUTH_FAILED: u32 = 3u32;
pub const CRYPTO_TUNNEL_AH_AUTH_FAILED: u32 = 4u32;
pub const CRYPTO_TUNNEL_ESP_AUTH_FAILED: u32 = 5u32;
pub const CachedNetBufferList: NDIS_PER_PACKET_INFO = 10i32;
pub const ClassificationHandlePacketInfo: NDIS_PER_PACKET_INFO = 3i32;
pub const DD_NDIS_DEVICE_NAME: windows_sys::core::PCWSTR = windows_sys::core::w!("\\Device\\NDIS");
pub const DOT11_RSN_KCK_LENGTH: u32 = 16u32;
pub const DOT11_RSN_KEK_LENGTH: u32 = 16u32;
pub const DOT11_RSN_MAX_CIPHER_KEY_LENGTH: u32 = 32u32;
pub const EAPOL_REQUEST_ID_WOL_FLAG_MUST_ENCRYPT: u32 = 1u32;
pub const ENCRYPT: OFFLOAD_OPERATION_E = 2i32;
pub const ERRED_PACKET_INDICATION: u32 = 1u32;
pub const ETHERNET_LENGTH_OF_ADDRESS: u32 = 6u32;
pub const GUID_NDIS_NDK_CAPABILITIES: windows_sys::core::GUID = windows_sys::core::GUID::from_u128(0x7969ba4d_dd80_4bc7_b3e6_68043997e519);
pub const GUID_NDIS_NDK_STATE: windows_sys::core::GUID = windows_sys::core::GUID::from_u128(0x530c69c9_2f51_49de_a1af_088d54ffa474);
pub const INDICATE_END_OF_TX: u32 = 32u32;
pub const INDICATE_ERRED_PACKETS: u32 = 16u32;
pub const IOCTL_NDIS_RESERVED5: u32 = 1507380u32;
pub const IOCTL_NDIS_RESERVED6: u32 = 1540152u32;
pub const IPSEC_OFFLOAD_V2_AND_TCP_CHECKSUM_COEXISTENCE: u32 = 2u32;
pub const IPSEC_OFFLOAD_V2_AND_UDP_CHECKSUM_COEXISTENCE: u32 = 4u32;
pub const IPSEC_OFFLOAD_V2_AUTHENTICATION_AES_GCM_128: u32 = 8u32;
pub const IPSEC_OFFLOAD_V2_AUTHENTICATION_AES_GCM_192: u32 = 16u32;
pub const IPSEC_OFFLOAD_V2_AUTHENTICATION_AES_GCM_256: u32 = 32u32;
pub const IPSEC_OFFLOAD_V2_AUTHENTICATION_MD5: u32 = 1u32;
pub const IPSEC_OFFLOAD_V2_AUTHENTICATION_SHA_1: u32 = 2u32;
pub const IPSEC_OFFLOAD_V2_AUTHENTICATION_SHA_256: u32 = 4u32;
pub const IPSEC_OFFLOAD_V2_ENCRYPTION_3_DES_CBC: u32 = 4u32;
pub const IPSEC_OFFLOAD_V2_ENCRYPTION_AES_CBC_128: u32 = 64u32;
pub const IPSEC_OFFLOAD_V2_ENCRYPTION_AES_CBC_192: u32 = 128u32;
pub const IPSEC_OFFLOAD_V2_ENCRYPTION_AES_CBC_256: u32 = 256u32;
pub const IPSEC_OFFLOAD_V2_ENCRYPTION_AES_GCM_128: u32 = 8u32;
pub const IPSEC_OFFLOAD_V2_ENCRYPTION_AES_GCM_192: u32 = 16u32;
pub const IPSEC_OFFLOAD_V2_ENCRYPTION_AES_GCM_256: u32 = 32u32;
pub const IPSEC_OFFLOAD_V2_ENCRYPTION_DES_CBC: u32 = 2u32;
pub const IPSEC_OFFLOAD_V2_ENCRYPTION_NONE: u32 = 1u32;
pub const IPSEC_OFFLOAD_V2_ESN_SA: u32 = 1u32;
pub const IPSEC_OFFLOAD_V2_INBOUND: u32 = 1u32;
pub const IPSEC_OFFLOAD_V2_IPv6: u32 = 16u32;
pub const IPSEC_OFFLOAD_V2_MAX_EXTENSION_HEADERS: u32 = 2u32;
pub const IPSEC_OFFLOAD_V2_TRANSPORT_OVER_UDP_ESP_ENCAPSULATION_TUNNEL: u32 = 4u32;
pub const IPSEC_OFFLOAD_V2_UDP_ESP_ENCAPSULATION_NONE: u32 = 0u32;
pub const IPSEC_OFFLOAD_V2_UDP_ESP_ENCAPSULATION_TRANSPORT: u32 = 1u32;
pub const IPSEC_OFFLOAD_V2_UDP_ESP_ENCAPSULATION_TRANSPORT_OVER_TUNNEL: u32 = 8u32;
pub const IPSEC_OFFLOAD_V2_UDP_ESP_ENCAPSULATION_TUNNEL: u32 = 2u32;
pub const IPSEC_TPTOVERTUN_UDPESP_ENCAPTYPE_IKE: u32 = 4u32;
pub const IPSEC_TPTOVERTUN_UDPESP_ENCAPTYPE_OTHER: u32 = 64u32;
pub const IPSEC_TPT_UDPESP_ENCAPTYPE_IKE: u32 = 1u32;
pub const IPSEC_TPT_UDPESP_ENCAPTYPE_OTHER: u32 = 16u32;
pub const IPSEC_TPT_UDPESP_OVER_PURE_TUN_ENCAPTYPE_IKE: u32 = 8u32;
pub const IPSEC_TPT_UDPESP_OVER_PURE_TUN_ENCAPTYPE_OTHER: u32 = 128u32;
pub const IPSEC_TUN_UDPESP_ENCAPTYPE_IKE: u32 = 2u32;
pub const IPSEC_TUN_UDPESP_ENCAPTYPE_OTHER: u32 = 32u32;
pub const Ieee8021QInfo: NDIS_PER_PACKET_INFO = 6i32;
pub const IpSecPacketInfo: NDIS_PER_PACKET_INFO = 1i32;
pub const MAXIMUM_IP_OPER_STATUS_ADDRESS_FAMILIES_SUPPORTED: u32 = 32u32;
pub const MAX_HASHES: u32 = 4u32;
pub const MULTIPOINT_VC: u32 = 16u32;
pub const MaxPerPacketInfo: NDIS_PER_PACKET_INFO = 12i32;
pub const NBL_FLAGS_MINIPORT_RESERVED: u32 = 61440u32;
pub const NBL_FLAGS_NDIS_RESERVED: u32 = 4092u32;
pub const NBL_FLAGS_PROTOCOL_RESERVED: u32 = 4293918723u32;
pub const NBL_FLAGS_SCRATCH: u32 = 983040u32;
pub const NBL_PROT_RSVD_FLAGS: u32 = 4293918723u32;
pub const NDIS630_MINIPORT: u32 = 1u32;
pub const NDIS685_MINIPORT: u32 = 1u32;
pub const NDIS_802_11_AI_REQFI_CAPABILITIES: u32 = 1u32;
pub const NDIS_802_11_AI_REQFI_CURRENTAPADDRESS: u32 = 4u32;
pub const NDIS_802_11_AI_REQFI_LISTENINTERVAL: u32 = 2u32;
pub const NDIS_802_11_AI_RESFI_ASSOCIATIONID: u32 = 4u32;
pub const NDIS_802_11_AI_RESFI_CAPABILITIES: u32 = 1u32;
pub const NDIS_802_11_AI_RESFI_STATUSCODE: u32 = 2u32;
pub const NDIS_802_11_AUTH_REQUEST_AUTH_FIELDS: u32 = 15u32;
pub const NDIS_802_11_AUTH_REQUEST_GROUP_ERROR: u32 = 14u32;
pub const NDIS_802_11_AUTH_REQUEST_KEYUPDATE: u32 = 2u32;
pub const NDIS_802_11_AUTH_REQUEST_PAIRWISE_ERROR: u32 = 6u32;
pub const NDIS_802_11_AUTH_REQUEST_REAUTH: u32 = 1u32;
pub const NDIS_802_11_LENGTH_RATES: u32 = 8u32;
pub const NDIS_802_11_LENGTH_RATES_EX: u32 = 16u32;
pub const NDIS_802_11_LENGTH_SSID: u32 = 32u32;
pub const NDIS_802_11_PMKID_CANDIDATE_PREAUTH_ENABLED: u32 = 1u32;
pub const NDIS_802_3_MAC_OPTION_PRIORITY: u32 = 1u32;
pub const NDIS_ANY_NUMBER_OF_NBLS: u32 = 4294967295u32;
pub const NDIS_ATTRIBUTE_BUS_MASTER: u32 = 8u32;
pub const NDIS_ATTRIBUTE_DESERIALIZE: u32 = 32u32;
pub const NDIS_ATTRIBUTE_DO_NOT_BIND_TO_ALL_CO: u32 = 1024u32;
pub const NDIS_ATTRIBUTE_IGNORE_PACKET_TIMEOUT: u32 = 1u32;
pub const NDIS_ATTRIBUTE_IGNORE_REQUEST_TIMEOUT: u32 = 2u32;
pub const NDIS_ATTRIBUTE_IGNORE_TOKEN_RING_ERRORS: u32 = 4u32;
pub const NDIS_ATTRIBUTE_INTERMEDIATE_DRIVER: u32 = 16u32;
pub const NDIS_ATTRIBUTE_MINIPORT_PADS_SHORT_PACKETS: u32 = 2048u32;
pub const NDIS_ATTRIBUTE_NOT_CO_NDIS: u32 = 256u32;
pub const NDIS_ATTRIBUTE_NO_HALT_ON_SUSPEND: u32 = 64u32;
pub const NDIS_ATTRIBUTE_SURPRISE_REMOVE_OK: u32 = 128u32;
pub const NDIS_ATTRIBUTE_USES_SAFE_BUFFER_APIS: u32 = 512u32;
pub const NDIS_BIND_FAILED_NOTIFICATION_REVISION_1: u32 = 1u32;
pub const NDIS_BIND_PARAMETERS_REVISION_1: u32 = 1u32;
pub const NDIS_BIND_PARAMETERS_REVISION_2: u32 = 2u32;
pub const NDIS_BIND_PARAMETERS_REVISION_3: u32 = 3u32;
pub const NDIS_BIND_PARAMETERS_REVISION_4: u32 = 4u32;
pub const NDIS_CLONE_FLAGS_RESERVED: u32 = 1u32;
pub const NDIS_CLONE_FLAGS_USE_ORIGINAL_MDLS: u32 = 2u32;
pub const NDIS_CONFIGURATION_OBJECT_REVISION_1: u32 = 1u32;
pub const NDIS_CONFIG_FLAG_FILTER_INSTANCE_CONFIGURATION: u32 = 1u32;
pub const NDIS_CO_CALL_MANAGER_OPTIONAL_HANDLERS_REVISION_1: u32 = 1u32;
pub const NDIS_CO_CLIENT_OPTIONAL_HANDLERS_REVISION_1: u32 = 1u32;
pub const NDIS_CO_MAC_OPTION_DYNAMIC_LINK_SPEED: u32 = 1u32;
pub const NDIS_DEFAULT_RECEIVE_FILTER_ID: u32 = 0u32;
pub const NDIS_DEFAULT_RECEIVE_QUEUE_GROUP_ID: u32 = 0u32;
pub const NDIS_DEFAULT_RECEIVE_QUEUE_ID: u32 = 0u32;
pub const NDIS_DEFAULT_SWITCH_ID: u32 = 0u32;
pub const NDIS_DEFAULT_VPORT_ID: u32 = 0u32;
pub const NDIS_DEVICE_OBJECT_ATTRIBUTES_REVISION_1: u32 = 1u32;
pub const NDIS_DEVICE_TYPE_ENDPOINT: u32 = 1u32;
pub const NDIS_DEVICE_WAKE_ON_MAGIC_PACKET_ENABLE: u32 = 4u32;
pub const NDIS_DEVICE_WAKE_ON_PATTERN_MATCH_ENABLE: u32 = 2u32;
pub const NDIS_DEVICE_WAKE_UP_ENABLE: u32 = 1u32;
pub const NDIS_DRIVER_FLAGS_RESERVED: u32 = 8u32;
pub const NDIS_ENCAPSULATED_PACKET_TASK_OFFLOAD_INNER_IPV4: u32 = 1u32;
pub const NDIS_ENCAPSULATED_PACKET_TASK_OFFLOAD_INNER_IPV6: u32 = 4u32;
pub const NDIS_ENCAPSULATED_PACKET_TASK_OFFLOAD_NOT_SUPPORTED: u32 = 0u32;
pub const NDIS_ENCAPSULATED_PACKET_TASK_OFFLOAD_OUTER_IPV4: u32 = 2u32;
pub const NDIS_ENCAPSULATED_PACKET_TASK_OFFLOAD_OUTER_IPV6: u32 = 8u32;
pub const NDIS_ENCAPSULATION_IEEE_802_3: u32 = 2u32;
pub const NDIS_ENCAPSULATION_IEEE_802_3_P_AND_Q: u32 = 4u32;
pub const NDIS_ENCAPSULATION_IEEE_802_3_P_AND_Q_IN_OOB: u32 = 8u32;
pub const NDIS_ENCAPSULATION_IEEE_LLC_SNAP_ROUTED: u32 = 16u32;
pub const NDIS_ENCAPSULATION_NOT_SUPPORTED: u32 = 0u32;
pub const NDIS_ENCAPSULATION_NULL: u32 = 1u32;
pub const NDIS_ENCAPSULATION_TYPE_GRE_MAC: u32 = 1u32;
pub const NDIS_ENCAPSULATION_TYPE_VXLAN: u32 = 2u32;
pub const NDIS_ENUM_FILTERS_REVISION_1: u32 = 1u32;
pub const NDIS_ETH_TYPE_802_1Q: u32 = 33024u32;
pub const NDIS_ETH_TYPE_802_1X: u32 = 34958u32;
pub const NDIS_ETH_TYPE_ARP: u32 = 2054u32;
pub const NDIS_ETH_TYPE_IPV4: u32 = 2048u32;
pub const NDIS_ETH_TYPE_IPV6: u32 = 34525u32;
pub const NDIS_ETH_TYPE_SLOW_PROTOCOL: u32 = 34825u32;
pub const NDIS_FILTER_ATTACH_FLAGS_IGNORE_MANDATORY: u32 = 1u32;
pub const NDIS_FILTER_ATTACH_PARAMETERS_REVISION_1: u32 = 1u32;
pub const NDIS_FILTER_ATTACH_PARAMETERS_REVISION_2: u32 = 2u32;
pub const NDIS_FILTER_ATTACH_PARAMETERS_REVISION_3: u32 = 3u32;
pub const NDIS_FILTER_ATTACH_PARAMETERS_REVISION_4: u32 = 4u32;
pub const NDIS_FILTER_ATTRIBUTES_REVISION_1: u32 = 1u32;
pub const NDIS_FILTER_CHARACTERISTICS_REVISION_1: u32 = 1u32;
pub const NDIS_FILTER_CHARACTERISTICS_REVISION_2: u32 = 2u32;
pub const NDIS_FILTER_CHARACTERISTICS_REVISION_3: u32 = 3u32;
pub const NDIS_FILTER_DRIVER_MANDATORY: u32 = 1u32;
pub const NDIS_FILTER_DRIVER_SUPPORTS_CURRENT_MAC_ADDRESS_CHANGE: u32 = 2u32;
pub const NDIS_FILTER_DRIVER_SUPPORTS_L2_MTU_SIZE_CHANGE: u32 = 4u32;
pub const NDIS_FILTER_INTERFACE_IM_FILTER: u32 = 1u32;
pub const NDIS_FILTER_INTERFACE_LW_FILTER: u32 = 2u32;
pub const NDIS_FILTER_INTERFACE_RECEIVE_BYPASS: u32 = 8u32;
pub const NDIS_FILTER_INTERFACE_REVISION_1: u32 = 1u32;
pub const NDIS_FILTER_INTERFACE_REVISION_2: u32 = 2u32;
pub const NDIS_FILTER_INTERFACE_SEND_BYPASS: u32 = 4u32;
pub const NDIS_FILTER_MAJOR_VERSION: u32 = 6u32;
pub const NDIS_FILTER_MINIMUM_MAJOR_VERSION: u32 = 6u32;
pub const NDIS_FILTER_MINIMUM_MINOR_VERSION: u32 = 0u32;
pub const NDIS_FILTER_MINOR_VERSION: u32 = 87u32;
pub const NDIS_FILTER_PARTIAL_CHARACTERISTICS_REVISION_1: u32 = 1u32;
pub const NDIS_FILTER_PAUSE_PARAMETERS_REVISION_1: u32 = 1u32;
pub const NDIS_FILTER_RESTART_PARAMETERS_REVISION_1: u32 = 1u32;
pub const NDIS_FLAGS_DONT_LOOPBACK: u32 = 128u32;
pub const NDIS_FLAGS_DOUBLE_BUFFERED: u32 = 2048u32;
pub const NDIS_FLAGS_IS_LOOPBACK_PACKET: u32 = 256u32;
pub const NDIS_FLAGS_LOOPBACK_ONLY: u32 = 512u32;
pub const NDIS_FLAGS_MULTICAST_PACKET: u32 = 16u32;
pub const NDIS_FLAGS_PADDED: u32 = 65536u32;
pub const NDIS_FLAGS_PROTOCOL_ID_MASK: u32 = 15u32;
pub const NDIS_FLAGS_RESERVED2: u32 = 32u32;
pub const NDIS_FLAGS_RESERVED3: u32 = 64u32;
pub const NDIS_FLAGS_RESERVED4: u32 = 1024u32;
pub const NDIS_FLAGS_SENT_AT_DPC: u32 = 4096u32;
pub const NDIS_FLAGS_USES_ORIGINAL_PACKET: u32 = 16384u32;
pub const NDIS_FLAGS_USES_SG_BUFFER_LIST: u32 = 8192u32;
pub const NDIS_FLAGS_XLATE_AT_TOP: u32 = 131072u32;
pub const NDIS_GFP_ENCAPSULATION_TYPE_IP_IN_GRE: u32 = 4u32;
pub const NDIS_GFP_ENCAPSULATION_TYPE_IP_IN_IP: u32 = 2u32;
pub const NDIS_GFP_ENCAPSULATION_TYPE_NOT_ENCAPSULATED: u32 = 1u32;
pub const NDIS_GFP_ENCAPSULATION_TYPE_NVGRE: u32 = 8u32;
pub const NDIS_GFP_ENCAPSULATION_TYPE_VXLAN: u32 = 16u32;
pub const NDIS_GFP_EXACT_MATCH_PROFILE_RDMA_FLOW: u32 = 1u32;
pub const NDIS_GFP_EXACT_MATCH_PROFILE_REVISION_1: u32 = 1u32;
pub const NDIS_GFP_HEADER_GROUP_EXACT_MATCH_IS_TTL_ONE: u32 = 1u32;
pub const NDIS_GFP_HEADER_GROUP_EXACT_MATCH_PROFILE_IS_TTL_ONE: u32 = 1u32;
pub const NDIS_GFP_HEADER_GROUP_EXACT_MATCH_PROFILE_REVISION_1: u32 = 1u32;
pub const NDIS_GFP_HEADER_GROUP_EXACT_MATCH_REVISION_1: u32 = 1u32;
pub const NDIS_GFP_HEADER_GROUP_WILDCARD_MATCH_IS_TTL_ONE: u32 = 1u32;
pub const NDIS_GFP_HEADER_GROUP_WILDCARD_MATCH_PROFILE_IS_TTL_ONE: u32 = 1u32;
pub const NDIS_GFP_HEADER_GROUP_WILDCARD_MATCH_PROFILE_REVISION_1: u32 = 1u32;
pub const NDIS_GFP_HEADER_GROUP_WILDCARD_MATCH_REVISION_1: u32 = 1u32;
pub const NDIS_GFP_HEADER_PRESENT_ESP: u32 = 2048u32;
pub const NDIS_GFP_HEADER_PRESENT_ETHERNET: u32 = 1u32;
pub const NDIS_GFP_HEADER_PRESENT_ICMP: u32 = 32u32;
pub const NDIS_GFP_HEADER_PRESENT_IPV4: u32 = 2u32;
pub const NDIS_GFP_HEADER_PRESENT_IPV6: u32 = 4u32;
pub const NDIS_GFP_HEADER_PRESENT_IP_IN_GRE_ENCAP: u32 = 256u32;
pub const NDIS_GFP_HEADER_PRESENT_IP_IN_IP_ENCAP: u32 = 128u32;
pub const NDIS_GFP_HEADER_PRESENT_NO_ENCAP: u32 = 64u32;
pub const NDIS_GFP_HEADER_PRESENT_NVGRE_ENCAP: u32 = 512u32;
pub const NDIS_GFP_HEADER_PRESENT_TCP: u32 = 8u32;
pub const NDIS_GFP_HEADER_PRESENT_UDP: u32 = 16u32;
pub const NDIS_GFP_HEADER_PRESENT_VXLAN_ENCAP: u32 = 1024u32;
pub const NDIS_GFP_UNDEFINED_PROFILE_ID: u32 = 0u32;
pub const NDIS_GFP_WILDCARD_MATCH_PROFILE_REVISION_1: u32 = 1u32;
pub const NDIS_GFT_COUNTER_INFO_ARRAY_REVISION_1: u32 = 1u32;
pub const NDIS_GFT_COUNTER_INFO_REVISION_1: u32 = 1u32;
pub const NDIS_GFT_COUNTER_PARAMETERS_CLIENT_SPECIFIED_ADDRESS: u32 = 1u32;
pub const NDIS_GFT_COUNTER_PARAMETERS_REVISION_1: u32 = 1u32;
pub const NDIS_GFT_COUNTER_VALUE_ARRAY_GET_VALUES: u32 = 2u32;
pub const NDIS_GFT_COUNTER_VALUE_ARRAY_REVISION_1: u32 = 1u32;
pub const NDIS_GFT_COUNTER_VALUE_ARRAY_UPDATE_MEMORY_MAPPED_COUNTERS: u32 = 1u32;
pub const NDIS_GFT_CUSTOM_ACTION_LAST_ACTION: u32 = 1u32;
pub const NDIS_GFT_CUSTOM_ACTION_PROFILE_REVISION_1: u32 = 1u32;
pub const NDIS_GFT_CUSTOM_ACTION_REVISION_1: u32 = 1u32;
pub const NDIS_GFT_DELETE_PROFILE_ALL_PROFILES: u32 = 1u32;
pub const NDIS_GFT_DELETE_PROFILE_PARAMETERS_REVISION_1: u32 = 1u32;
pub const NDIS_GFT_DELETE_TABLE_PARAMETERS_REVISION_1: u32 = 1u32;
pub const NDIS_GFT_EMFE_ADD_IN_ACTIVATED_STATE: u32 = 1u32;
pub const NDIS_GFT_EMFE_ALL_VPORT_FLOW_ENTRIES: u32 = 33554432u32;
pub const NDIS_GFT_EMFE_COPY_AFTER_TCP_FIN_FLAG_SET: u32 = 2097152u32;
pub const NDIS_GFT_EMFE_COPY_AFTER_TCP_RST_FLAG_SET: u32 = 4194304u32;
pub const NDIS_GFT_EMFE_COPY_ALL_PACKETS: u32 = 65536u32;
pub const NDIS_GFT_EMFE_COPY_CONDITION_CHANGED: u32 = 16777216u32;
pub const NDIS_GFT_EMFE_COPY_FIRST_PACKET: u32 = 131072u32;
pub const NDIS_GFT_EMFE_COPY_WHEN_TCP_FLAG_SET: u32 = 262144u32;
pub const NDIS_GFT_EMFE_COUNTER_ALLOCATE: u32 = 1u32;
pub const NDIS_GFT_EMFE_COUNTER_CLIENT_SPECIFIED_ADDRESS: u32 = 4u32;
pub const NDIS_GFT_EMFE_COUNTER_MEMORY_MAPPED: u32 = 2u32;
pub const NDIS_GFT_EMFE_COUNTER_TRACK_TCP_FLOW: u32 = 8u32;
pub const NDIS_GFT_EMFE_CUSTOM_ACTION_PRESENT: u32 = 524288u32;
pub const NDIS_GFT_EMFE_MATCH_AND_ACTION_MUST_BE_SUPPORTED: u32 = 2u32;
pub const NDIS_GFT_EMFE_META_ACTION_BEFORE_HEADER_TRANSPOSITION: u32 = 1048576u32;
pub const NDIS_GFT_EMFE_RDMA_FLOW: u32 = 4u32;
pub const NDIS_GFT_EMFE_REDIRECT_TO_EGRESS_QUEUE_OF_VPORT: u32 = 8192u32;
pub const NDIS_GFT_EMFE_REDIRECT_TO_EGRESS_QUEUE_OF_VPORT_IF_TTL_IS_ONE: u32 = 32768u32;
pub const NDIS_GFT_EMFE_REDIRECT_TO_INGRESS_QUEUE_OF_VPORT: u32 = 4096u32;
pub const NDIS_GFT_EMFE_REDIRECT_TO_INGRESS_QUEUE_OF_VPORT_IF_TTL_IS_ONE: u32 = 16384u32;
pub const NDIS_GFT_EXACT_MATCH_FLOW_ENTRY_REVISION_1: u32 = 1u32;
pub const NDIS_GFT_FLOW_ENTRY_ARRAY_REVISION_1: u32 = 1u32;
pub const NDIS_GFT_FLOW_ENTRY_ID_ALL_NIC_SWITCH_FLOW_ENTRIES: u32 = 1u32;
pub const NDIS_GFT_FLOW_ENTRY_ID_ALL_TABLE_FLOW_ENTRIES: u32 = 2u32;
pub const NDIS_GFT_FLOW_ENTRY_ID_ALL_VPORT_FLOW_ENTRIES: u32 = 4u32;
pub const NDIS_GFT_FLOW_ENTRY_ID_ARRAY_COUNTER_VALUES: u32 = 65536u32;
pub const NDIS_GFT_FLOW_ENTRY_ID_ARRAY_DEFINED: u32 = 16u32;
pub const NDIS_GFT_FLOW_ENTRY_ID_ARRAY_REVISION_1: u32 = 1u32;
pub const NDIS_GFT_FLOW_ENTRY_ID_RANGE_DEFINED: u32 = 8u32;
pub const NDIS_GFT_FLOW_ENTRY_INFO_ALL_FLOW_ENTRIES: u32 = 1u32;
pub const NDIS_GFT_FLOW_ENTRY_INFO_ARRAY_REVISION_1: u32 = 1u32;
pub const NDIS_GFT_FREE_COUNTER_PARAMETERS_REVISION_1: u32 = 1u32;
pub const NDIS_GFT_HEADER_GROUP_TRANSPOSITION_DECREMENT_TTL_IF_NOT_ONE: u32 = 1u32;
pub const NDIS_GFT_HEADER_GROUP_TRANSPOSITION_PROFILE_DECREMENT_TTL_IF_NOT_ONE: u32 = 1u32;
pub const NDIS_GFT_HEADER_GROUP_TRANSPOSITION_PROFILE_REVISION_1: u32 = 1u32;
pub const NDIS_GFT_HEADER_GROUP_TRANSPOSITION_REVISION_1: u32 = 1u32;
pub const NDIS_GFT_HEADER_TRANSPOSITION_PROFILE_REVISION_1: u32 = 1u32;
pub const NDIS_GFT_HTP_COPY_ALL_PACKETS: u32 = 16u32;
pub const NDIS_GFT_HTP_COPY_FIRST_PACKET: u32 = 32u32;
pub const NDIS_GFT_HTP_COPY_WHEN_TCP_FLAG_SET: u32 = 64u32;
pub const NDIS_GFT_HTP_CUSTOM_ACTION_PRESENT: u32 = 128u32;
pub const NDIS_GFT_HTP_META_ACTION_BEFORE_HEADER_TRANSPOSITION: u32 = 256u32;
pub const NDIS_GFT_HTP_REDIRECT_TO_EGRESS_QUEUE_OF_VPORT: u32 = 2u32;
pub const NDIS_GFT_HTP_REDIRECT_TO_EGRESS_QUEUE_OF_VPORT_IF_TTL_IS_ONE: u32 = 8u32;
pub const NDIS_GFT_HTP_REDIRECT_TO_INGRESS_QUEUE_OF_VPORT: u32 = 1u32;
pub const NDIS_GFT_HTP_REDIRECT_TO_INGRESS_QUEUE_OF_VPORT_IF_TTL_IS_ONE: u32 = 4u32;
pub const NDIS_GFT_MAX_COUNTER_OBJECTS_PER_FLOW_ENTRY: u32 = 8u32;
pub const NDIS_GFT_OFFLOAD_CAPABILITIES_REVISION_1: u32 = 1u32;
pub const NDIS_GFT_OFFLOAD_CAPS_8021P_PRIORITY_MASK: u32 = 131072u32;
pub const NDIS_GFT_OFFLOAD_CAPS_ADD_FLOW_ENTRY_DEACTIVATED_PREFERRED: u32 = 1u32;
pub const NDIS_GFT_OFFLOAD_CAPS_ALLOW: u32 = 262144u32;
pub const NDIS_GFT_OFFLOAD_CAPS_CLIENT_SPECIFIED_MEMORY_MAPPED_COUNTERS: u32 = 16u32;
pub const NDIS_GFT_OFFLOAD_CAPS_COMBINED_COUNTER_AND_STATE: u32 = 256u32;
pub const NDIS_GFT_OFFLOAD_CAPS_COPY_ALL: u32 = 256u32;
pub const NDIS_GFT_OFFLOAD_CAPS_COPY_FIRST: u32 = 512u32;
pub const NDIS_GFT_OFFLOAD_CAPS_COPY_WHEN_TCP_FLAG_SET: u32 = 1024u32;
pub const NDIS_GFT_OFFLOAD_CAPS_DESIGNATED_EXCEPTION_VPORT: u32 = 32768u32;
pub const NDIS_GFT_OFFLOAD_CAPS_DROP: u32 = 524288u32;
pub const NDIS_GFT_OFFLOAD_CAPS_DSCP_MASK: u32 = 65536u32;
pub const NDIS_GFT_OFFLOAD_CAPS_EGRESS_AGGREGATE_COUNTERS: u32 = 64u32;
pub const NDIS_GFT_OFFLOAD_CAPS_EGRESS_EXACT_MATCH: u32 = 8u32;
pub const NDIS_GFT_OFFLOAD_CAPS_EGRESS_WILDCARD_MATCH: u32 = 2u32;
pub const NDIS_GFT_OFFLOAD_CAPS_EXT_VPORT_EGRESS_EXACT_MATCH: u32 = 128u32;
pub const NDIS_GFT_OFFLOAD_CAPS_EXT_VPORT_EGRESS_WILDCARD_MATCH: u32 = 32u32;
pub const NDIS_GFT_OFFLOAD_CAPS_EXT_VPORT_INGRESS_EXACT_MATCH: u32 = 64u32;
pub const NDIS_GFT_OFFLOAD_CAPS_EXT_VPORT_INGRESS_WILDCARD_MATCH: u32 = 16u32;
pub const NDIS_GFT_OFFLOAD_CAPS_IGNORE_ACTION_SUPPORTED: u32 = 8u32;
pub const NDIS_GFT_OFFLOAD_CAPS_INGRESS_AGGREGATE_COUNTERS: u32 = 32u32;
pub const NDIS_GFT_OFFLOAD_CAPS_INGRESS_EXACT_MATCH: u32 = 4u32;
pub const NDIS_GFT_OFFLOAD_CAPS_INGRESS_WILDCARD_MATCH: u32 = 1u32;
pub const NDIS_GFT_OFFLOAD_CAPS_MEMORY_MAPPED_COUNTERS: u32 = 1u32;
pub const NDIS_GFT_OFFLOAD_CAPS_MEMORY_MAPPED_PAKCET_AND_BYTE_COUNTERS: u32 = 2u32;
pub const NDIS_GFT_OFFLOAD_CAPS_META_ACTION_AFTER_HEADER_TRANSPOSITION: u32 = 8192u32;
pub const NDIS_GFT_OFFLOAD_CAPS_META_ACTION_BEFORE_HEADER_TRANSPOSITION: u32 = 4096u32;
pub const NDIS_GFT_OFFLOAD_CAPS_MODIFY: u32 = 4u32;
pub const NDIS_GFT_OFFLOAD_CAPS_PER_FLOW_ENTRY_COUNTERS: u32 = 4u32;
pub const NDIS_GFT_OFFLOAD_CAPS_PER_PACKET_COUNTER_UPDATE: u32 = 8u32;
pub const NDIS_GFT_OFFLOAD_CAPS_PER_VPORT_EXCEPTION_VPORT: u32 = 16384u32;
pub const NDIS_GFT_OFFLOAD_CAPS_POP: u32 = 1u32;
pub const NDIS_GFT_OFFLOAD_CAPS_PUSH: u32 = 2u32;
pub const NDIS_GFT_OFFLOAD_CAPS_RATE_LIMITING_QUEUE_SUPPORTED: u32 = 2u32;
pub const NDIS_GFT_OFFLOAD_CAPS_REDIRECT_TO_EGRESS_QUEUE_OF_VPORT: u32 = 32u32;
pub const NDIS_GFT_OFFLOAD_CAPS_REDIRECT_TO_EGRESS_QUEUE_OF_VPORT_IF_TTL_IS_ONE: u32 = 128u32;
pub const NDIS_GFT_OFFLOAD_CAPS_REDIRECT_TO_INGRESS_QUEUE_OF_VPORT: u32 = 16u32;
pub const NDIS_GFT_OFFLOAD_CAPS_REDIRECT_TO_INGRESS_QUEUE_OF_VPORT_IF_TTL_IS_ONE: u32 = 64u32;
pub const NDIS_GFT_OFFLOAD_CAPS_SAMPLE: u32 = 2048u32;
pub const NDIS_GFT_OFFLOAD_CAPS_TRACK_TCP_FLOW_STATE: u32 = 128u32;
pub const NDIS_GFT_OFFLOAD_INFO_COPY_PACKET: u32 = 4u32;
pub const NDIS_GFT_OFFLOAD_INFO_DIRECTION_INGRESS: u32 = 1u32;
pub const NDIS_GFT_OFFLOAD_INFO_EXCEPTION_PACKET: u32 = 2u32;
pub const NDIS_GFT_OFFLOAD_INFO_SAMPLE_PACKET: u32 = 8u32;
pub const NDIS_GFT_OFFLOAD_PARAMETERS_CUSTOM_PROVIDER_RESERVED: u32 = 4278190080u32;
pub const NDIS_GFT_OFFLOAD_PARAMETERS_ENABLE_OFFLOAD: u32 = 1u32;
pub const NDIS_GFT_OFFLOAD_PARAMETERS_REVISION_1: u32 = 1u32;
pub const NDIS_GFT_PROFILE_INFO_ARRAY_REVISION_1: u32 = 1u32;
pub const NDIS_GFT_PROFILE_INFO_REVISION_1: u32 = 1u32;
pub const NDIS_GFT_RESERVED_CUSTOM_ACTIONS: u32 = 256u32;
pub const NDIS_GFT_STATISTICS_REVISION_1: u32 = 1u32;
pub const NDIS_GFT_TABLE_INCLUDE_EXTERNAL_VPPORT: u32 = 1u32;
pub const NDIS_GFT_TABLE_INFO_ARRAY_REVISION_1: u32 = 1u32;
pub const NDIS_GFT_TABLE_INFO_REVISION_1: u32 = 1u32;
pub const NDIS_GFT_TABLE_PARAMETERS_REVISION_1: u32 = 1u32;
pub const NDIS_GFT_UNDEFINED_COUNTER_ID: u32 = 0u32;
pub const NDIS_GFT_UNDEFINED_CUSTOM_ACTION: u32 = 0u32;
pub const NDIS_GFT_UNDEFINED_FLOW_ENTRY_ID: u32 = 0u32;
pub const NDIS_GFT_UNDEFINED_TABLE_ID: u32 = 0u32;
pub const NDIS_GFT_VPORT_DSCP_FLAGS_CHANGED: u32 = 67108864u32;
pub const NDIS_GFT_VPORT_DSCP_GUARD_ENABLE_RX: u32 = 1u32;
pub const NDIS_GFT_VPORT_DSCP_GUARD_ENABLE_TX: u32 = 2u32;
pub const NDIS_GFT_VPORT_DSCP_MASK_CHANGED: u32 = 8388608u32;
pub const NDIS_GFT_VPORT_DSCP_MASK_ENABLE_RX: u32 = 4u32;
pub const NDIS_GFT_VPORT_DSCP_MASK_ENABLE_TX: u32 = 8u32;
pub const NDIS_GFT_VPORT_ENABLE: u32 = 1u32;
pub const NDIS_GFT_VPORT_ENABLE_STATE_CHANGED: u32 = 1048576u32;
pub const NDIS_GFT_VPORT_EXCEPTION_VPORT_CHANGED: u32 = 2097152u32;
pub const NDIS_GFT_VPORT_MAX_DSCP_MASK_COUNTER_OBJECTS: u32 = 64u32;
pub const NDIS_GFT_VPORT_MAX_PRIORITY_MASK_COUNTER_OBJECTS: u32 = 8u32;
pub const NDIS_GFT_VPORT_PARAMETERS_REVISION_1: u32 = 1u32;
pub const NDIS_GFT_VPORT_PARAMS_CHANGE_MASK: u32 = 4293918720u32;
pub const NDIS_GFT_VPORT_PARAMS_CUSTOM_PROVIDER_RESERVED: u32 = 1044480u32;
pub const NDIS_GFT_VPORT_PARSE_VXLAN: u32 = 2u32;
pub const NDIS_GFT_VPORT_PARSE_VXLAN_NOT_IN_SRC_PORT_RANGE: u32 = 4u32;
pub const NDIS_GFT_VPORT_PRIORITY_MASK_CHANGED: u32 = 16777216u32;
pub const NDIS_GFT_VPORT_SAMPLING_RATE_CHANGED: u32 = 4194304u32;
pub const NDIS_GFT_VPORT_VXLAN_SETTINGS_CHANGED: u32 = 33554432u32;
pub const NDIS_GFT_WCFE_ADD_IN_ACTIVATED_STATE: u32 = 1u32;
pub const NDIS_GFT_WCFE_COPY_ALL_PACKETS: u32 = 32u32;
pub const NDIS_GFT_WCFE_COUNTER_ALLOCATE: u32 = 1u32;
pub const NDIS_GFT_WCFE_COUNTER_CLIENT_SPECIFIED_ADDRESS: u32 = 4u32;
pub const NDIS_GFT_WCFE_COUNTER_MEMORY_MAPPED: u32 = 2u32;
pub const NDIS_GFT_WCFE_CUSTOM_ACTION_PRESENT: u32 = 64u32;
pub const NDIS_GFT_WCFE_REDIRECT_TO_EGRESS_QUEUE_OF_VPORT: u32 = 4u32;
pub const NDIS_GFT_WCFE_REDIRECT_TO_EGRESS_QUEUE_OF_VPORT_IF_TTL_IS_ONE: u32 = 16u32;
pub const NDIS_GFT_WCFE_REDIRECT_TO_INGRESS_QUEUE_OF_VPORT: u32 = 2u32;
pub const NDIS_GFT_WCFE_REDIRECT_TO_INGRESS_QUEUE_OF_VPORT_IF_TTL_IS_ONE: u32 = 8u32;
pub const NDIS_GFT_WILDCARD_MATCH_FLOW_ENTRY_REVISION_1: u32 = 1u32;
pub const NDIS_HARDWARE_CROSSTIMESTAMP_REVISION_1: u32 = 1u32;
pub const NDIS_HASH_FUNCTION_MASK: u32 = 255u32;
pub const NDIS_HASH_IPV4: u32 = 256u32;
pub const NDIS_HASH_IPV6: u32 = 1024u32;
pub const NDIS_HASH_IPV6_EX: u32 = 2048u32;
pub const NDIS_HASH_TCP_IPV4: u32 = 512u32;
pub const NDIS_HASH_TCP_IPV6: u32 = 4096u32;
pub const NDIS_HASH_TCP_IPV6_EX: u32 = 8192u32;
pub const NDIS_HASH_TYPE_MASK: u32 = 16776960u32;
pub const NDIS_HASH_UDP_IPV4: u32 = 16384u32;
pub const NDIS_HASH_UDP_IPV6: u32 = 32768u32;
pub const NDIS_HASH_UDP_IPV6_EX: u32 = 65536u32;
pub const NDIS_HD_SPLIT_ATTRIBUTES_REVISION_1: u32 = 1u32;
pub const NDIS_HD_SPLIT_CAPS_SUPPORTS_HEADER_DATA_SPLIT: u32 = 1u32;
pub const NDIS_HD_SPLIT_CAPS_SUPPORTS_IPV4_OPTIONS: u32 = 2u32;
pub const NDIS_HD_SPLIT_CAPS_SUPPORTS_IPV6_EXTENSION_HEADERS: u32 = 4u32;
pub const NDIS_HD_SPLIT_CAPS_SUPPORTS_TCP_OPTIONS: u32 = 8u32;
pub const NDIS_HD_SPLIT_COMBINE_ALL_HEADERS: u32 = 1u32;
pub const NDIS_HD_SPLIT_CURRENT_CONFIG_REVISION_1: u32 = 1u32;
pub const NDIS_HD_SPLIT_ENABLE_HEADER_DATA_SPLIT: u32 = 1u32;
pub const NDIS_HD_SPLIT_PARAMETERS_REVISION_1: u32 = 1u32;
pub const NDIS_HYPERVISOR_INFO_FLAG_HYPERVISOR_PRESENT: u32 = 1u32;
pub const NDIS_HYPERVISOR_INFO_REVISION_1: u32 = 1u32;
pub const NDIS_INTERMEDIATE_DRIVER: u32 = 1u32;
pub const NDIS_INTERRUPT_MODERATION_CHANGE_NEEDS_REINITIALIZE: u32 = 2u32;
pub const NDIS_INTERRUPT_MODERATION_CHANGE_NEEDS_RESET: u32 = 1u32;
pub const NDIS_INTERRUPT_MODERATION_PARAMETERS_REVISION_1: u32 = 1u32;
pub const NDIS_IPSEC_OFFLOAD_V2_ADD_SA_EX_REVISION_1: u32 = 1u32;
pub const NDIS_IPSEC_OFFLOAD_V2_ADD_SA_REVISION_1: u32 = 1u32;
pub const NDIS_IPSEC_OFFLOAD_V2_DELETE_SA_REVISION_1: u32 = 1u32;
pub const NDIS_IPSEC_OFFLOAD_V2_UPDATE_SA_REVISION_1: u32 = 1u32;
pub const NDIS_IP_OPER_STATE_REVISION_1: u32 = 1u32;
pub const NDIS_IP_OPER_STATUS_INFO_REVISION_1: u32 = 1u32;
pub const NDIS_ISOLATION_NAME_MAX_STRING_SIZE: u32 = 127u32;
pub const NDIS_ISOLATION_PARAMETERS_REVISION_1: u32 = 1u32;
pub const NDIS_KDNET_ADD_PF_REVISION_1: u32 = 1u32;
pub const NDIS_KDNET_ENUMERATE_PFS_REVISION_1: u32 = 1u32;
pub const NDIS_KDNET_PF_ENUM_ELEMENT_REVISION_1: u32 = 1u32;
pub const NDIS_KDNET_QUERY_PF_INFORMATION_REVISION_1: u32 = 1u32;
pub const NDIS_KDNET_REMOVE_PF_REVISION_1: u32 = 1u32;
pub const NDIS_LARGE_SEND_OFFLOAD_MAX_HEADER_LENGTH: u32 = 128u32;
pub const NDIS_LEGACY_DRIVER: u32 = 1u32;
pub const NDIS_LEGACY_MINIPORT: u32 = 1u32;
pub const NDIS_LEGACY_PROTOCOL: u32 = 1u32;
pub const NDIS_LINK_PARAMETERS_REVISION_1: u32 = 1u32;
pub const NDIS_LINK_STATE_DUPLEX_AUTO_NEGOTIATED: u32 = 4u32;
pub const NDIS_LINK_STATE_PAUSE_FUNCTIONS_AUTO_NEGOTIATED: u32 = 8u32;
pub const NDIS_LINK_STATE_RCV_LINK_SPEED_AUTO_NEGOTIATED: u32 = 2u32;
pub const NDIS_LINK_STATE_REVISION_1: u32 = 1u32;
pub const NDIS_LINK_STATE_XMIT_LINK_SPEED_AUTO_NEGOTIATED: u32 = 1u32;
pub const NDIS_MAC_OPTION_8021P_PRIORITY: u32 = 64u32;
pub const NDIS_MAC_OPTION_8021Q_VLAN: u32 = 512u32;
pub const NDIS_MAC_OPTION_COPY_LOOKAHEAD_DATA: u32 = 1u32;
pub const NDIS_MAC_OPTION_EOTX_INDICATION: u32 = 32u32;
pub const NDIS_MAC_OPTION_FULL_DUPLEX: u32 = 16u32;
pub const NDIS_MAC_OPTION_NO_LOOPBACK: u32 = 8u32;
pub const NDIS_MAC_OPTION_RECEIVE_AT_DPC: u32 = 256u32;
pub const NDIS_MAC_OPTION_RECEIVE_SERIALIZED: u32 = 2u32;
pub const NDIS_MAC_OPTION_RESERVED: u32 = 2147483648u32;
pub const NDIS_MAC_OPTION_SUPPORTS_MAC_ADDRESS_OVERWRITE: u32 = 128u32;
pub const NDIS_MAC_OPTION_TRANSFERS_NOT_PEND: u32 = 4u32;
pub const NDIS_MAXIMUM_PORTS: u32 = 16777216u32;
pub const NDIS_MAX_LOOKAHEAD_SIZE_ACCESSED_UNDEFINED: i32 = -1i32;
pub const NDIS_MAX_PROCESSOR_COUNT: u32 = 64u32;
pub const NDIS_MEDIA_CAP_RECEIVE: u32 = 2u32;
pub const NDIS_MEDIA_CAP_TRANSMIT: u32 = 1u32;
pub const NDIS_MEDIA_SPECIFIC_INFO_EAPOL: u32 = 2147549185u32;
pub const NDIS_MEDIA_SPECIFIC_INFO_FCOE: u32 = 2147549184u32;
pub const NDIS_MEDIA_SPECIFIC_INFO_LLDP: u32 = 2147549186u32;
pub const NDIS_MEDIA_SPECIFIC_INFO_TIMESYNC: u32 = 2147549187u32;
pub const NDIS_MEDIA_SPECIFIC_INFO_TUNDL: u32 = 65537u32;
pub const NDIS_MEMORY_CONTIGUOUS: u32 = 1u32;
pub const NDIS_MEMORY_NONCACHED: u32 = 2u32;
pub const NDIS_MINIPORT_ADAPTER_802_11_ATTRIBUTES_REVISION_1: u32 = 1u32;
pub const NDIS_MINIPORT_ADAPTER_802_11_ATTRIBUTES_REVISION_2: u32 = 2u32;
pub const NDIS_MINIPORT_ADAPTER_802_11_ATTRIBUTES_REVISION_3: u32 = 3u32;
pub const NDIS_MINIPORT_ADAPTER_GENERAL_ATTRIBUTES_REVISION_1: u32 = 1u32;
pub const NDIS_MINIPORT_ADAPTER_GENERAL_ATTRIBUTES_REVISION_2: u32 = 2u32;
pub const NDIS_MINIPORT_ADAPTER_HARDWARE_ASSIST_ATTRIBUTES_REVISION_1: u32 = 1u32;
pub const NDIS_MINIPORT_ADAPTER_HARDWARE_ASSIST_ATTRIBUTES_REVISION_2: u32 = 2u32;
pub const NDIS_MINIPORT_ADAPTER_HARDWARE_ASSIST_ATTRIBUTES_REVISION_3: u32 = 3u32;
pub const NDIS_MINIPORT_ADAPTER_HARDWARE_ASSIST_ATTRIBUTES_REVISION_4: u32 = 4u32;
pub const NDIS_MINIPORT_ADAPTER_NDK_ATTRIBUTES_REVISION_1: u32 = 1u32;
pub const NDIS_MINIPORT_ADAPTER_OFFLOAD_ATTRIBUTES_REVISION_1: u32 = 1u32;
pub const NDIS_MINIPORT_ADAPTER_PACKET_DIRECT_ATTRIBUTES_REVISION_1: u32 = 1u32;
pub const NDIS_MINIPORT_ADAPTER_REGISTRATION_ATTRIBUTES_REVISION_1: u32 = 1u32;
pub const NDIS_MINIPORT_ADAPTER_REGISTRATION_ATTRIBUTES_REVISION_2: u32 = 2u32;
pub const NDIS_MINIPORT_ADD_DEVICE_REGISTRATION_ATTRIBUTES_REVISION_1: u32 = 1u32;
pub const NDIS_MINIPORT_ATTRIBUTES_BUS_MASTER: u32 = 64u32;
pub const NDIS_MINIPORT_ATTRIBUTES_CONTROLS_DEFAULT_PORT: u32 = 128u32;
pub const NDIS_MINIPORT_ATTRIBUTES_DO_NOT_BIND_TO_ALL_CO: u32 = 16u32;
pub const NDIS_MINIPORT_ATTRIBUTES_HARDWARE_DEVICE: u32 = 1u32;
pub const NDIS_MINIPORT_ATTRIBUTES_NDIS_WDM: u32 = 2u32;
pub const NDIS_MINIPORT_ATTRIBUTES_NOT_CO_NDIS: u32 = 8u32;
pub const NDIS_MINIPORT_ATTRIBUTES_NO_HALT_ON_SUSPEND: u32 = 32u32;
pub const NDIS_MINIPORT_ATTRIBUTES_NO_OID_INTERCEPT_ON_NONDEFAULT_PORTS: u32 = 512u32;
pub const NDIS_MINIPORT_ATTRIBUTES_NO_PAUSE_ON_SUSPEND: u32 = 256u32;
pub const NDIS_MINIPORT_ATTRIBUTES_REGISTER_BUGCHECK_CALLBACK: u32 = 1024u32;
pub const NDIS_MINIPORT_ATTRIBUTES_SURPRISE_REMOVE_OK: u32 = 4u32;
pub const NDIS_MINIPORT_CO_CHARACTERISTICS_REVISION_1: u32 = 1u32;
pub const NDIS_MINIPORT_DRIVER: u32 = 1u32;
pub const NDIS_MINIPORT_DRIVER_CHARACTERISTICS_REVISION_1: u32 = 1u32;
pub const NDIS_MINIPORT_DRIVER_CHARACTERISTICS_REVISION_2: u32 = 2u32;
pub const NDIS_MINIPORT_DRIVER_CHARACTERISTICS_REVISION_3: u32 = 3u32;
pub const NDIS_MINIPORT_INIT_PARAMETERS_REVISION_1: u32 = 1u32;
pub const NDIS_MINIPORT_INTERRUPT_REVISION_1: u32 = 1u32;
pub const NDIS_MINIPORT_MAJOR_VERSION: u32 = 6u32;
pub const NDIS_MINIPORT_MINIMUM_MAJOR_VERSION: u32 = 5u32;
pub const NDIS_MINIPORT_MINIMUM_MINOR_VERSION: u32 = 0u32;
pub const NDIS_MINIPORT_MINOR_VERSION: u32 = 87u32;
pub const NDIS_MINIPORT_PAUSE_PARAMETERS_REVISION_1: u32 = 1u32;
pub const NDIS_MINIPORT_PNP_CHARACTERISTICS_REVISION_1: u32 = 1u32;
pub const NDIS_MINIPORT_RESTART_PARAMETERS_REVISION_1: u32 = 1u32;
pub const NDIS_MINIPORT_SS_CHARACTERISTICS_REVISION_1: u32 = 1u32;
pub const NDIS_MIN_API: u32 = 1024u32;
pub const NDIS_MONITOR_CONFIG_REVISION_1: u32 = 1u32;
pub const NDIS_MSIX_CONFIG_PARAMETERS_REVISION_1: u32 = 1u32;
pub const NDIS_M_MAX_LOOKAHEAD: u32 = 526u32;
pub const NDIS_NBL_FLAGS_CAPTURE_TIMESTAMP_ON_TRANSMIT: u32 = 65536u32;
pub const NDIS_NBL_FLAGS_HD_SPLIT: u32 = 256u32;
pub const NDIS_NBL_FLAGS_IS_IPV4: u32 = 512u32;
pub const NDIS_NBL_FLAGS_IS_IPV6: u32 = 1024u32;
pub const NDIS_NBL_FLAGS_IS_LOOPBACK_PACKET: u32 = 32768u32;
pub const NDIS_NBL_FLAGS_IS_TCP: u32 = 2048u32;
pub const NDIS_NBL_FLAGS_IS_UDP: u32 = 4096u32;
pub const NDIS_NBL_FLAGS_RECV_READ_ONLY: u32 = 2u32;
pub const NDIS_NBL_FLAGS_SEND_READ_ONLY: u32 = 1u32;
pub const NDIS_NBL_FLAGS_SPLIT_AT_UPPER_LAYER_PROTOCOL_HEADER: u32 = 8192u32;
pub const NDIS_NBL_FLAGS_SPLIT_AT_UPPER_LAYER_PROTOCOL_PAYLOAD: u32 = 16384u32;
pub const NDIS_NBL_MEDIA_SPECIFIC_INFO_REVISION_1: u32 = 1u32;
pub const NDIS_NDK_CAPABILITIES_REVISION_1: u32 = 1u32;
pub const NDIS_NDK_CONNECTIONS_REVISION_1: u32 = 1u32;
pub const NDIS_NDK_LOCAL_ENDPOINTS_REVISION_1: u32 = 1u32;
pub const NDIS_NDK_STATISTICS_INFO_REVISION_1: u32 = 1u32;
pub const NDIS_NIC_SWITCH_CAPABILITIES_REVISION_1: u32 = 1u32;
pub const NDIS_NIC_SWITCH_CAPABILITIES_REVISION_2: u32 = 2u32;
pub const NDIS_NIC_SWITCH_CAPABILITIES_REVISION_3: u32 = 3u32;
pub const NDIS_NIC_SWITCH_CAPS_ASYMMETRIC_QUEUE_PAIRS_FOR_NONDEFAULT_VPORT_SUPPORTED: u32 = 4u32;
pub const NDIS_NIC_SWITCH_CAPS_NIC_SWITCH_WITHOUT_IOV_SUPPORTED: u32 = 64u32;
pub const NDIS_NIC_SWITCH_CAPS_PER_VPORT_INTERRUPT_MODERATION_SUPPORTED: u32 = 2u32;
pub const NDIS_NIC_SWITCH_CAPS_RSS_ON_PF_VPORTS_SUPPORTED: u32 = 128u32;
pub const NDIS_NIC_SWITCH_CAPS_RSS_PARAMETERS_PER_PF_VPORT_SUPPORTED: u32 = 32u32;
pub const NDIS_NIC_SWITCH_CAPS_RSS_PER_PF_VPORT_HASH_FUNCTION_SUPPORTED: u32 = 512u32;
pub const NDIS_NIC_SWITCH_CAPS_RSS_PER_PF_VPORT_HASH_KEY_SUPPORTED: u32 = 2048u32;
pub const NDIS_NIC_SWITCH_CAPS_RSS_PER_PF_VPORT_HASH_TYPE_SUPPORTED: u32 = 1024u32;
pub const NDIS_NIC_SWITCH_CAPS_RSS_PER_PF_VPORT_INDIRECTION_TABLE_SIZE_RESTRICTED: u32 = 4096u32;
pub const NDIS_NIC_SWITCH_CAPS_RSS_PER_PF_VPORT_INDIRECTION_TABLE_SUPPORTED: u32 = 256u32;
pub const NDIS_NIC_SWITCH_CAPS_SINGLE_VPORT_POOL: u32 = 16u32;
pub const NDIS_NIC_SWITCH_CAPS_VF_RSS_SUPPORTED: u32 = 8u32;
pub const NDIS_NIC_SWITCH_CAPS_VLAN_SUPPORTED: u32 = 1u32;
pub const NDIS_NIC_SWITCH_DELETE_SWITCH_PARAMETERS_REVISION_1: u32 = 1u32;
pub const NDIS_NIC_SWITCH_DELETE_VPORT_PARAMETERS_REVISION_1: u32 = 1u32;
pub const NDIS_NIC_SWITCH_FREE_VF_PARAMETERS_REVISION_1: u32 = 1u32;
pub const NDIS_NIC_SWITCH_INFO_ARRAY_REVISION_1: u32 = 1u32;
pub const NDIS_NIC_SWITCH_INFO_REVISION_1: u32 = 1u32;
pub const NDIS_NIC_SWITCH_PARAMETERS_CHANGE_MASK: u32 = 4294901760u32;
pub const NDIS_NIC_SWITCH_PARAMETERS_DEFAULT_NUMBER_OF_QUEUE_PAIRS_FOR_DEFAULT_VPORT: u32 = 1u32;
pub const NDIS_NIC_SWITCH_PARAMETERS_REVISION_1: u32 = 1u32;
pub const NDIS_NIC_SWITCH_PARAMETERS_REVISION_2: u32 = 2u32;
pub const NDIS_NIC_SWITCH_PARAMETERS_SWITCH_NAME_CHANGED: u32 = 65536u32;
pub const NDIS_NIC_SWITCH_VF_INFO_ARRAY_ENUM_ON_SPECIFIC_SWITCH: u32 = 1u32;
pub const NDIS_NIC_SWITCH_VF_INFO_ARRAY_REVISION_1: u32 = 1u32;
pub const NDIS_NIC_SWITCH_VF_INFO_REVISION_1: u32 = 1u32;
pub const NDIS_NIC_SWITCH_VF_PARAMETERS_REVISION_1: u32 = 1u32;
pub const NDIS_NIC_SWITCH_VPORT_INFO_ARRAY_ENUM_ON_SPECIFIC_FUNCTION: u32 = 1u32;
pub const NDIS_NIC_SWITCH_VPORT_INFO_ARRAY_ENUM_ON_SPECIFIC_SWITCH: u32 = 2u32;
pub const NDIS_NIC_SWITCH_VPORT_INFO_ARRAY_REVISION_1: u32 = 1u32;
pub const NDIS_NIC_SWITCH_VPORT_INFO_GFT_ENABLED: u32 = 4u32;
pub const NDIS_NIC_SWITCH_VPORT_INFO_LOOKAHEAD_SPLIT_ENABLED: u32 = 1u32;
pub const NDIS_NIC_SWITCH_VPORT_INFO_PACKET_DIRECT_RX_ONLY: u32 = 2u32;
pub const NDIS_NIC_SWITCH_VPORT_INFO_REVISION_1: u32 = 1u32;
pub const NDIS_NIC_SWITCH_VPORT_PARAMETERS_REVISION_1: u32 = 1u32;
pub const NDIS_NIC_SWITCH_VPORT_PARAMETERS_REVISION_2: u32 = 2u32;
pub const NDIS_NIC_SWITCH_VPORT_PARAMS_CHANGE_MASK: u32 = 4294901760u32;
pub const NDIS_NIC_SWITCH_VPORT_PARAMS_ENFORCE_MAX_SG_LIST: u32 = 32768u32;
pub const NDIS_NIC_SWITCH_VPORT_PARAMS_FLAGS_CHANGED: u32 = 65536u32;
pub const NDIS_NIC_SWITCH_VPORT_PARAMS_INT_MOD_CHANGED: u32 = 262144u32;
pub const NDIS_NIC_SWITCH_VPORT_PARAMS_LOOKAHEAD_SPLIT_ENABLED: u32 = 1u32;
pub const NDIS_NIC_SWITCH_VPORT_PARAMS_NAME_CHANGED: u32 = 131072u32;
pub const NDIS_NIC_SWITCH_VPORT_PARAMS_NDK_PARAMS_CHANGED: u32 = 2097152u32;
pub const NDIS_NIC_SWITCH_VPORT_PARAMS_NUM_QUEUE_PAIRS_CHANGED: u32 = 8388608u32;
pub const NDIS_NIC_SWITCH_VPORT_PARAMS_PACKET_DIRECT_RX_ONLY: u32 = 2u32;
pub const NDIS_NIC_SWITCH_VPORT_PARAMS_PROCESSOR_AFFINITY_CHANGED: u32 = 1048576u32;
pub const NDIS_NIC_SWITCH_VPORT_PARAMS_QOS_SQ_ID_CHANGED: u32 = 4194304u32;
pub const NDIS_NIC_SWITCH_VPORT_PARAMS_STATE_CHANGED: u32 = 524288u32;
pub const NDIS_NT: u32 = 1u32;
pub const NDIS_OBJECT_REVISION_1: u32 = 1u32;
pub const NDIS_OBJECT_TYPE_BIND_PARAMETERS: u32 = 134u32;
pub const NDIS_OBJECT_TYPE_CLIENT_CHIMNEY_OFFLOAD_CHARACTERISTICS: u32 = 147u32;
pub const NDIS_OBJECT_TYPE_CLIENT_CHIMNEY_OFFLOAD_GENERIC_CHARACTERISTICS: u32 = 142u32;
pub const NDIS_OBJECT_TYPE_CONFIGURATION_OBJECT: u32 = 169u32;
pub const NDIS_OBJECT_TYPE_CO_CALL_MANAGER_OPTIONAL_HANDLERS: u32 = 165u32;
pub const NDIS_OBJECT_TYPE_CO_CLIENT_OPTIONAL_HANDLERS: u32 = 166u32;
pub const NDIS_OBJECT_TYPE_CO_MINIPORT_CHARACTERISTICS: u32 = 145u32;
pub const NDIS_OBJECT_TYPE_CO_PROTOCOL_CHARACTERISTICS: u32 = 144u32;
pub const NDIS_OBJECT_TYPE_DEFAULT: u32 = 128u32;
pub const NDIS_OBJECT_TYPE_DEVICE_OBJECT_ATTRIBUTES: u32 = 133u32;
pub const NDIS_OBJECT_TYPE_DRIVER_WRAPPER_OBJECT: u32 = 170u32;
pub const NDIS_OBJECT_TYPE_DRIVER_WRAPPER_REVISION_1: u32 = 1u32;
pub const NDIS_OBJECT_TYPE_FILTER_ATTACH_PARAMETERS: u32 = 153u32;
pub const NDIS_OBJECT_TYPE_FILTER_ATTRIBUTES: u32 = 141u32;
pub const NDIS_OBJECT_TYPE_FILTER_DRIVER_CHARACTERISTICS: u32 = 139u32;
pub const NDIS_OBJECT_TYPE_FILTER_PARTIAL_CHARACTERISTICS: u32 = 140u32;
pub const NDIS_OBJECT_TYPE_FILTER_PAUSE_PARAMETERS: u32 = 154u32;
pub const NDIS_OBJECT_TYPE_FILTER_RESTART_PARAMETERS: u32 = 155u32;
pub const NDIS_OBJECT_TYPE_HD_SPLIT_ATTRIBUTES: u32 = 171u32;
pub const NDIS_OBJECT_TYPE_MINIPORT_ADAPTER_GENERAL_ATTRIBUTES: u32 = 159u32;
pub const NDIS_OBJECT_TYPE_MINIPORT_ADAPTER_HARDWARE_ASSIST_ATTRIBUTES: u32 = 175u32;
pub const NDIS_OBJECT_TYPE_MINIPORT_ADAPTER_NATIVE_802_11_ATTRIBUTES: u32 = 161u32;
pub const NDIS_OBJECT_TYPE_MINIPORT_ADAPTER_NDK_ATTRIBUTES: u32 = 179u32;
pub const NDIS_OBJECT_TYPE_MINIPORT_ADAPTER_OFFLOAD_ATTRIBUTES: u32 = 160u32;
pub const NDIS_OBJECT_TYPE_MINIPORT_ADAPTER_PACKET_DIRECT_ATTRIBUTES: u32 = 197u32;
pub const NDIS_OBJECT_TYPE_MINIPORT_ADAPTER_REGISTRATION_ATTRIBUTES: u32 = 158u32;
pub const NDIS_OBJECT_TYPE_MINIPORT_ADD_DEVICE_REGISTRATION_ATTRIBUTES: u32 = 164u32;
pub const NDIS_OBJECT_TYPE_MINIPORT_DEVICE_POWER_NOTIFICATION: u32 = 198u32;
pub const NDIS_OBJECT_TYPE_MINIPORT_DRIVER_CHARACTERISTICS: u32 = 138u32;
pub const NDIS_OBJECT_TYPE_MINIPORT_INIT_PARAMETERS: u32 = 129u32;
pub const NDIS_OBJECT_TYPE_MINIPORT_INTERRUPT: u32 = 132u32;
pub const NDIS_OBJECT_TYPE_MINIPORT_PNP_CHARACTERISTICS: u32 = 146u32;
pub const NDIS_OBJECT_TYPE_MINIPORT_SS_CHARACTERISTICS: u32 = 180u32;
pub const NDIS_OBJECT_TYPE_NDK_PROVIDER_CHARACTERISTICS: u32 = 178u32;
pub const NDIS_OBJECT_TYPE_NSI_COMPARTMENT_RW_STRUCT: u32 = 173u32;
pub const NDIS_OBJECT_TYPE_NSI_INTERFACE_PERSIST_RW_STRUCT: u32 = 174u32;
pub const NDIS_OBJECT_TYPE_NSI_NETWORK_RW_STRUCT: u32 = 172u32;
pub const NDIS_OBJECT_TYPE_OFFLOAD: u32 = 167u32;
pub const NDIS_OBJECT_TYPE_OFFLOAD_ENCAPSULATION: u32 = 168u32;
pub const NDIS_OBJECT_TYPE_OID_REQUEST: u32 = 150u32;
pub const NDIS_OBJECT_TYPE_OPEN_PARAMETERS: u32 = 135u32;
pub const NDIS_OBJECT_TYPE_PCI_DEVICE_CUSTOM_PROPERTIES_REVISION_1: u32 = 1u32;
pub const NDIS_OBJECT_TYPE_PCI_DEVICE_CUSTOM_PROPERTIES_REVISION_2: u32 = 2u32;
pub const NDIS_OBJECT_TYPE_PD_RECEIVE_QUEUE: u32 = 191u32;
pub const NDIS_OBJECT_TYPE_PD_TRANSMIT_QUEUE: u32 = 190u32;
pub const NDIS_OBJECT_TYPE_PORT_CHARACTERISTICS: u32 = 156u32;
pub const NDIS_OBJECT_TYPE_PORT_STATE: u32 = 157u32;
pub const NDIS_OBJECT_TYPE_PROTOCOL_DRIVER_CHARACTERISTICS: u32 = 149u32;
pub const NDIS_OBJECT_TYPE_PROTOCOL_RESTART_PARAMETERS: u32 = 163u32;
pub const NDIS_OBJECT_TYPE_PROVIDER_CHIMNEY_OFFLOAD_CHARACTERISTICS: u32 = 148u32;
pub const NDIS_OBJECT_TYPE_PROVIDER_CHIMNEY_OFFLOAD_GENERIC_CHARACTERISTICS: u32 = 143u32;
pub const NDIS_OBJECT_TYPE_QOS_CAPABILITIES: u32 = 181u32;
pub const NDIS_OBJECT_TYPE_QOS_CLASSIFICATION_ELEMENT: u32 = 183u32;
pub const NDIS_OBJECT_TYPE_QOS_PARAMETERS: u32 = 182u32;
pub const NDIS_OBJECT_TYPE_REQUEST_EX: u32 = 150u32;
pub const NDIS_OBJECT_TYPE_RESTART_GENERAL_ATTRIBUTES: u32 = 162u32;
pub const NDIS_OBJECT_TYPE_RSS_CAPABILITIES: u32 = 136u32;
pub const NDIS_OBJECT_TYPE_RSS_PARAMETERS: u32 = 137u32;
pub const NDIS_OBJECT_TYPE_RSS_PARAMETERS_V2: u32 = 200u32;
pub const NDIS_OBJECT_TYPE_RSS_PROCESSOR_INFO: u32 = 177u32;
pub const NDIS_OBJECT_TYPE_RSS_SET_INDIRECTION_ENTRIES: u32 = 201u32;
pub const NDIS_OBJECT_TYPE_SG_DMA_DESCRIPTION: u32 = 131u32;
pub const NDIS_OBJECT_TYPE_SHARED_MEMORY_PROVIDER_CHARACTERISTICS: u32 = 176u32;
pub const NDIS_OBJECT_TYPE_STATUS_INDICATION: u32 = 152u32;
pub const NDIS_OBJECT_TYPE_SWITCH_OPTIONAL_HANDLERS: u32 = 184u32;
pub const NDIS_OBJECT_TYPE_TIMER_CHARACTERISTICS: u32 = 151u32;
pub const NDIS_OFFLOAD_ENCAPSULATION_REVISION_1: u32 = 1u32;
pub const NDIS_OFFLOAD_FLAGS_GROUP_CHECKSUM_CAPABILITIES: u32 = 1u32;
pub const NDIS_OFFLOAD_NOT_SUPPORTED: u32 = 0u32;
pub const NDIS_OFFLOAD_PARAMETERS_CONNECTION_OFFLOAD_DISABLED: u32 = 1u32;
pub const NDIS_OFFLOAD_PARAMETERS_CONNECTION_OFFLOAD_ENABLED: u32 = 2u32;
pub const NDIS_OFFLOAD_PARAMETERS_IPSECV1_AH_AND_ESP_ENABLED: u32 = 4u32;
pub const NDIS_OFFLOAD_PARAMETERS_IPSECV1_AH_ENABLED: u32 = 2u32;
pub const NDIS_OFFLOAD_PARAMETERS_IPSECV1_DISABLED: u32 = 1u32;
pub const NDIS_OFFLOAD_PARAMETERS_IPSECV1_ESP_ENABLED: u32 = 3u32;
pub const NDIS_OFFLOAD_PARAMETERS_IPSECV2_AH_AND_ESP_ENABLED: u32 = 4u32;
pub const NDIS_OFFLOAD_PARAMETERS_IPSECV2_AH_ENABLED: u32 = 2u32;
pub const NDIS_OFFLOAD_PARAMETERS_IPSECV2_DISABLED: u32 = 1u32;
pub const NDIS_OFFLOAD_PARAMETERS_IPSECV2_ESP_ENABLED: u32 = 3u32;
pub const NDIS_OFFLOAD_PARAMETERS_LSOV1_DISABLED: u32 = 1u32;
pub const NDIS_OFFLOAD_PARAMETERS_LSOV1_ENABLED: u32 = 2u32;
pub const NDIS_OFFLOAD_PARAMETERS_LSOV2_DISABLED: u32 = 1u32;
pub const NDIS_OFFLOAD_PARAMETERS_LSOV2_ENABLED: u32 = 2u32;
pub const NDIS_OFFLOAD_PARAMETERS_NO_CHANGE: u32 = 0u32;
pub const NDIS_OFFLOAD_PARAMETERS_REVISION_1: u32 = 1u32;
pub const NDIS_OFFLOAD_PARAMETERS_REVISION_2: u32 = 2u32;
pub const NDIS_OFFLOAD_PARAMETERS_REVISION_3: u32 = 3u32;
pub const NDIS_OFFLOAD_PARAMETERS_REVISION_4: u32 = 4u32;
pub const NDIS_OFFLOAD_PARAMETERS_REVISION_5: u32 = 5u32;
pub const NDIS_OFFLOAD_PARAMETERS_RSC_DISABLED: u32 = 1u32;
pub const NDIS_OFFLOAD_PARAMETERS_RSC_ENABLED: u32 = 2u32;
pub const NDIS_OFFLOAD_PARAMETERS_RX_ENABLED_TX_DISABLED: u32 = 3u32;
pub const NDIS_OFFLOAD_PARAMETERS_SKIP_REGISTRY_UPDATE: u32 = 1u32;
pub const NDIS_OFFLOAD_PARAMETERS_TX_ENABLED_RX_DISABLED: u32 = 2u32;
pub const NDIS_OFFLOAD_PARAMETERS_TX_RX_DISABLED: u32 = 1u32;
pub const NDIS_OFFLOAD_PARAMETERS_TX_RX_ENABLED: u32 = 4u32;
pub const NDIS_OFFLOAD_PARAMETERS_USO_DISABLED: u32 = 1u32;
pub const NDIS_OFFLOAD_PARAMETERS_USO_ENABLED: u32 = 2u32;
pub const NDIS_OFFLOAD_REVISION_1: u32 = 1u32;
pub const NDIS_OFFLOAD_REVISION_2: u32 = 2u32;
pub const NDIS_OFFLOAD_REVISION_3: u32 = 3u32;
pub const NDIS_OFFLOAD_REVISION_4: u32 = 4u32;
pub const NDIS_OFFLOAD_REVISION_5: u32 = 5u32;
pub const NDIS_OFFLOAD_REVISION_6: u32 = 6u32;
pub const NDIS_OFFLOAD_REVISION_7: u32 = 7u32;
pub const NDIS_OFFLOAD_SET_NO_CHANGE: u32 = 0u32;
pub const NDIS_OFFLOAD_SET_OFF: u32 = 2u32;
pub const NDIS_OFFLOAD_SET_ON: u32 = 1u32;
pub const NDIS_OFFLOAD_SUPPORTED: u32 = 1u32;
pub const NDIS_OID_REQUEST_FLAGS_VPORT_ID_VALID: u32 = 1u32;
pub const NDIS_OID_REQUEST_NDIS_RESERVED_SIZE: u32 = 16u32;
pub const NDIS_OID_REQUEST_REVISION_1: u32 = 1u32;
pub const NDIS_OID_REQUEST_REVISION_2: u32 = 2u32;
pub const NDIS_OID_REQUEST_TIMEOUT_INFINITE: u32 = 0u32;
pub const NDIS_OPEN_PARAMETERS_REVISION_1: u32 = 1u32;
pub const NDIS_OPEN_RECEIVE_NOT_REENTRANT: u32 = 1u32;
pub const NDIS_OPER_STATE_REVISION_1: u32 = 1u32;
pub const NDIS_PACKET_TYPE_ALL_FUNCTIONAL: u32 = 8192u32;
pub const NDIS_PACKET_TYPE_ALL_LOCAL: u32 = 128u32;
pub const NDIS_PACKET_TYPE_ALL_MULTICAST: u32 = 4u32;
pub const NDIS_PACKET_TYPE_BROADCAST: u32 = 8u32;
pub const NDIS_PACKET_TYPE_DIRECTED: u32 = 1u32;
pub const NDIS_PACKET_TYPE_FUNCTIONAL: u32 = 16384u32;
pub const NDIS_PACKET_TYPE_GROUP: u32 = 4096u32;
pub const NDIS_PACKET_TYPE_MAC_FRAME: u32 = 32768u32;
pub const NDIS_PACKET_TYPE_MULTICAST: u32 = 2u32;
pub const NDIS_PACKET_TYPE_NO_LOCAL: u32 = 65536u32;
pub const NDIS_PACKET_TYPE_PROMISCUOUS: u32 = 32u32;
pub const NDIS_PACKET_TYPE_SMT: u32 = 64u32;
pub const NDIS_PACKET_TYPE_SOURCE_ROUTING: u32 = 16u32;
pub const NDIS_PAUSE_ATTACH_FILTER: u32 = 16u32;
pub const NDIS_PAUSE_BIND_PROTOCOL: u32 = 4u32;
pub const NDIS_PAUSE_DETACH_FILTER: u32 = 32u32;
pub const NDIS_PAUSE_FILTER_RESTART_STACK: u32 = 64u32;
pub const NDIS_PAUSE_LOW_POWER: u32 = 2u32;
pub const NDIS_PAUSE_MINIPORT_DEVICE_REMOVE: u32 = 128u32;
pub const NDIS_PAUSE_NDIS_INTERNAL: u32 = 1u32;
pub const NDIS_PAUSE_UNBIND_PROTOCOL: u32 = 8u32;
pub const NDIS_PD_ACQUIRE_QUEUES_FLAG_DRAIN_NOTIFICATION: u32 = 1u32;
pub const NDIS_PD_ACQUIRE_QUEUES_PARAMETERS_REVISION_1: u32 = 1u32;
pub const NDIS_PD_CAPABILITIES_REVISION_1: u32 = 1u32;
pub const NDIS_PD_CAPS_DRAIN_NOTIFICATIONS_SUPPORTED: u32 = 2u32;
pub const NDIS_PD_CAPS_NOTIFICATION_MODERATION_COUNT_SUPPORTED: u32 = 8u32;
pub const NDIS_PD_CAPS_NOTIFICATION_MODERATION_INTERVAL_SUPPORTED: u32 = 4u32;
pub const NDIS_PD_CAPS_RECEIVE_FILTER_COUNTERS_SUPPORTED: u32 = 1u32;
pub const NDIS_PD_CLOSE_PROVIDER_PARAMETERS_REVISION_1: u32 = 1u32;
pub const NDIS_PD_CONFIG_REVISION_1: u32 = 1u32;
pub const NDIS_PD_COUNTER_PARAMETERS_REVISION_1: u32 = 1u32;
pub const NDIS_PD_FILTER_PARAMETERS_REVISION_1: u32 = 1u32;
pub const NDIS_PD_OPEN_PROVIDER_PARAMETERS_REVISION_1: u32 = 1u32;
pub const NDIS_PD_PROVIDER_DISPATCH_REVISION_1: u32 = 1u32;
pub const NDIS_PD_QUEUE_DISPATCH_REVISION_1: u32 = 1u32;
pub const NDIS_PD_QUEUE_FLAG_DRAIN_NOTIFICATION: u32 = 1u32;
pub const NDIS_PD_QUEUE_PARAMETERS_REVISION_1: u32 = 1u32;
pub const NDIS_PD_QUEUE_REVISION_1: u32 = 1u32;
pub const NDIS_PM_CAPABILITIES_REVISION_1: u32 = 1u32;
pub const NDIS_PM_CAPABILITIES_REVISION_2: u32 = 2u32;
pub const NDIS_PM_MAX_PATTERN_ID: u32 = 65535u32;
pub const NDIS_PM_MAX_STRING_SIZE: u32 = 64u32;
pub const NDIS_PM_PARAMETERS_REVISION_1: u32 = 1u32;
pub const NDIS_PM_PARAMETERS_REVISION_2: u32 = 2u32;
pub const NDIS_PM_PRIVATE_PATTERN_ID: u32 = 1u32;
pub const NDIS_PM_PROTOCOL_OFFLOAD_80211_RSN_REKEY_ENABLED: u32 = 128u32;
pub const NDIS_PM_PROTOCOL_OFFLOAD_80211_RSN_REKEY_SUPPORTED: u32 = 128u32;
pub const NDIS_PM_PROTOCOL_OFFLOAD_ARP_ENABLED: u32 = 1u32;
pub const NDIS_PM_PROTOCOL_OFFLOAD_ARP_SUPPORTED: u32 = 1u32;
pub const NDIS_PM_PROTOCOL_OFFLOAD_NS_ENABLED: u32 = 2u32;
pub const NDIS_PM_PROTOCOL_OFFLOAD_NS_SUPPORTED: u32 = 2u32;
pub const NDIS_PM_PROTOCOL_OFFLOAD_PRIORITY_HIGHEST: u32 = 1u32;
pub const NDIS_PM_PROTOCOL_OFFLOAD_PRIORITY_LOWEST: u32 = 4294967295u32;
pub const NDIS_PM_PROTOCOL_OFFLOAD_PRIORITY_NORMAL: u32 = 268435456u32;
pub const NDIS_PM_PROTOCOL_OFFLOAD_REVISION_1: u32 = 1u32;
pub const NDIS_PM_PROTOCOL_OFFLOAD_REVISION_2: u32 = 2u32;
pub const NDIS_PM_SELECTIVE_SUSPEND_ENABLED: u32 = 16u32;
pub const NDIS_PM_SELECTIVE_SUSPEND_SUPPORTED: u32 = 2u32;
pub const NDIS_PM_WAKE_ON_LINK_CHANGE_ENABLED: u32 = 1u32;
pub const NDIS_PM_WAKE_ON_MEDIA_CONNECT_SUPPORTED: u32 = 1u32;
pub const NDIS_PM_WAKE_ON_MEDIA_DISCONNECT_ENABLED: u32 = 2u32;
pub const NDIS_PM_WAKE_ON_MEDIA_DISCONNECT_SUPPORTED: u32 = 2u32;
pub const NDIS_PM_WAKE_PACKET_INDICATION_SUPPORTED: u32 = 1u32;
pub const NDIS_PM_WAKE_PACKET_REVISION_1: u32 = 1u32;
pub const NDIS_PM_WAKE_REASON_REVISION_1: u32 = 1u32;
pub const NDIS_PM_WOL_BITMAP_PATTERN_ENABLED: u32 = 1u32;
pub const NDIS_PM_WOL_BITMAP_PATTERN_SUPPORTED: u32 = 1u32;
pub const NDIS_PM_WOL_EAPOL_REQUEST_ID_MESSAGE_ENABLED: u32 = 65536u32;
pub const NDIS_PM_WOL_EAPOL_REQUEST_ID_MESSAGE_SUPPORTED: u32 = 65536u32;
pub const NDIS_PM_WOL_IPV4_DEST_ADDR_WILDCARD_ENABLED: u32 = 512u32;
pub const NDIS_PM_WOL_IPV4_DEST_ADDR_WILDCARD_SUPPORTED: u32 = 512u32;
pub const NDIS_PM_WOL_IPV4_TCP_SYN_ENABLED: u32 = 4u32;
pub const NDIS_PM_WOL_IPV4_TCP_SYN_SUPPORTED: u32 = 4u32;
pub const NDIS_PM_WOL_IPV6_DEST_ADDR_WILDCARD_ENABLED: u32 = 2048u32;
pub const NDIS_PM_WOL_IPV6_DEST_ADDR_WILDCARD_SUPPORTED: u32 = 2048u32;
pub const NDIS_PM_WOL_IPV6_TCP_SYN_ENABLED: u32 = 8u32;
pub const NDIS_PM_WOL_IPV6_TCP_SYN_SUPPORTED: u32 = 8u32;
pub const NDIS_PM_WOL_MAGIC_PACKET_ENABLED: u32 = 2u32;
pub const NDIS_PM_WOL_MAGIC_PACKET_SUPPORTED: u32 = 2u32;
pub const NDIS_PM_WOL_PATTERN_REVISION_1: u32 = 1u32;
pub const NDIS_PM_WOL_PATTERN_REVISION_2: u32 = 2u32;
pub const NDIS_PM_WOL_PRIORITY_HIGHEST: u32 = 1u32;
pub const NDIS_PM_WOL_PRIORITY_LOWEST: u32 = 4294967295u32;
pub const NDIS_PM_WOL_PRIORITY_NORMAL: u32 = 268435456u32;
pub const NDIS_PNP_WAKE_UP_LINK_CHANGE: u32 = 4u32;
pub const NDIS_PNP_WAKE_UP_MAGIC_PACKET: u32 = 1u32;
pub const NDIS_PNP_WAKE_UP_PATTERN_MATCH: u32 = 2u32;
pub const NDIS_POLL_CHARACTERISTICS_REVISION_1: u32 = 1u32;
pub const NDIS_POLL_DATA_REVISION_1: u32 = 1u32;
pub const NDIS_POLL_NOTIFICATION_REVISION_1: u32 = 1u32;
pub const NDIS_PORT_ARRAY_REVISION_1: u32 = 1u32;
pub const NDIS_PORT_AUTHENTICATION_PARAMETERS_REVISION_1: u32 = 1u32;
pub const NDIS_PORT_CHARACTERISTICS_REVISION_1: u32 = 1u32;
pub const NDIS_PORT_CHAR_USE_DEFAULT_AUTH_SETTINGS: u32 = 1u32;
pub const NDIS_PORT_STATE_REVISION_1: u32 = 1u32;
pub const NDIS_PROTOCOL_CO_CHARACTERISTICS_REVISION_1: u32 = 1u32;
pub const NDIS_PROTOCOL_DRIVER_CHARACTERISTICS_REVISION_1: u32 = 1u32;
pub const NDIS_PROTOCOL_DRIVER_CHARACTERISTICS_REVISION_2: u32 = 2u32;
pub const NDIS_PROTOCOL_DRIVER_SUPPORTS_CURRENT_MAC_ADDRESS_CHANGE: u32 = 2u32;
pub const NDIS_PROTOCOL_DRIVER_SUPPORTS_L2_MTU_SIZE_CHANGE: u32 = 4u32;
pub const NDIS_PROTOCOL_ID_DEFAULT: u32 = 0u32;
pub const NDIS_PROTOCOL_ID_IP6: u32 = 3u32;
pub const NDIS_PROTOCOL_ID_IPX: u32 = 6u32;
pub const NDIS_PROTOCOL_ID_MASK: u32 = 15u32;
pub const NDIS_PROTOCOL_ID_MAX: u32 = 15u32;
pub const NDIS_PROTOCOL_ID_NBF: u32 = 7u32;
pub const NDIS_PROTOCOL_ID_TCP_IP: u32 = 2u32;
pub const NDIS_PROTOCOL_MAJOR_VERSION: u32 = 6u32;
pub const NDIS_PROTOCOL_MINIMUM_MAJOR_VERSION: u32 = 4u32;
pub const NDIS_PROTOCOL_MINIMUM_MINOR_VERSION: u32 = 0u32;
pub const NDIS_PROTOCOL_MINOR_VERSION: u32 = 87u32;
pub const NDIS_PROTOCOL_PAUSE_PARAMETERS_REVISION_1: u32 = 1u32;
pub const NDIS_PROTOCOL_RESTART_PARAMETERS_REVISION_1: u32 = 1u32;
pub const NDIS_PROT_OPTION_ESTIMATED_LENGTH: u32 = 1u32;
pub const NDIS_PROT_OPTION_NO_LOOPBACK: u32 = 2u32;
pub const NDIS_PROT_OPTION_NO_RSVD_ON_RCVPKT: u32 = 4u32;
pub const NDIS_PROT_OPTION_SEND_RESTRICTED: u32 = 8u32;
pub const NDIS_QOS_ACTION_MAXIMUM: u32 = 1u32;
pub const NDIS_QOS_ACTION_PRIORITY: u32 = 0u32;
pub const NDIS_QOS_CAPABILITIES_CEE_DCBX_SUPPORTED: u32 = 4u32;
pub const NDIS_QOS_CAPABILITIES_IEEE_DCBX_SUPPORTED: u32 = 8u32;
pub const NDIS_QOS_CAPABILITIES_MACSEC_BYPASS_SUPPORTED: u32 = 2u32;
pub const NDIS_QOS_CAPABILITIES_REVISION_1: u32 = 1u32;
pub const NDIS_QOS_CAPABILITIES_STRICT_TSA_SUPPORTED: u32 = 1u32;
pub const NDIS_QOS_CLASSIFICATION_ELEMENT_REVISION_1: u32 = 1u32;
pub const NDIS_QOS_CLASSIFICATION_ENFORCED_BY_MINIPORT: u32 = 16777216u32;
pub const NDIS_QOS_CLASSIFICATION_SET_BY_MINIPORT_MASK: u32 = 4278190080u32;
pub const NDIS_QOS_CONDITION_DEFAULT: u32 = 1u32;
pub const NDIS_QOS_CONDITION_ETHERTYPE: u32 = 5u32;
pub const NDIS_QOS_CONDITION_MAXIMUM: u32 = 7u32;
pub const NDIS_QOS_CONDITION_NETDIRECT_PORT: u32 = 6u32;
pub const NDIS_QOS_CONDITION_RESERVED: u32 = 0u32;
pub const NDIS_QOS_CONDITION_TCP_OR_UDP_PORT: u32 = 4u32;
pub const NDIS_QOS_CONDITION_TCP_PORT: u32 = 2u32;
pub const NDIS_QOS_CONDITION_UDP_PORT: u32 = 3u32;
pub const NDIS_QOS_DEFAULT_SQ_ID: u32 = 0u32;
pub const NDIS_QOS_MAXIMUM_PRIORITIES: u32 = 8u32;
pub const NDIS_QOS_MAXIMUM_TRAFFIC_CLASSES: u32 = 8u32;
pub const NDIS_QOS_OFFLOAD_CAPABILITIES_REVISION_1: u32 = 1u32;
pub const NDIS_QOS_OFFLOAD_CAPABILITIES_REVISION_2: u32 = 2u32;
pub const NDIS_QOS_OFFLOAD_CAPS_GFT_SQ: u32 = 2u32;
pub const NDIS_QOS_OFFLOAD_CAPS_STANDARD_SQ: u32 = 1u32;
pub const NDIS_QOS_PARAMETERS_CLASSIFICATION_CHANGED: u32 = 65536u32;
pub const NDIS_QOS_PARAMETERS_CLASSIFICATION_CONFIGURED: u32 = 131072u32;
pub const NDIS_QOS_PARAMETERS_ETS_CHANGED: u32 = 1u32;
pub const NDIS_QOS_PARAMETERS_ETS_CONFIGURED: u32 = 2u32;
pub const NDIS_QOS_PARAMETERS_PFC_CHANGED: u32 = 256u32;
pub const NDIS_QOS_PARAMETERS_PFC_CONFIGURED: u32 = 512u32;
pub const NDIS_QOS_PARAMETERS_REVISION_1: u32 = 1u32;
pub const NDIS_QOS_PARAMETERS_WILLING: u32 = 2147483648u32;
pub const NDIS_QOS_SQ_ARRAY_REVISION_1: u32 = 1u32;
pub const NDIS_QOS_SQ_PARAMETERS_ARRAY_REVISION_1: u32 = 1u32;
pub const NDIS_QOS_SQ_PARAMETERS_REVISION_1: u32 = 1u32;
pub const NDIS_QOS_SQ_PARAMETERS_REVISION_2: u32 = 2u32;
pub const NDIS_QOS_SQ_RECEIVE_CAP_ENABLED: u32 = 4u32;
pub const NDIS_QOS_SQ_STATS_REVISION_1: u32 = 1u32;
pub const NDIS_QOS_SQ_TRANSMIT_CAP_ENABLED: u32 = 1u32;
pub const NDIS_QOS_SQ_TRANSMIT_RESERVATION_ENABLED: u32 = 2u32;
pub const NDIS_QOS_TSA_CBS: u32 = 1u32;
pub const NDIS_QOS_TSA_ETS: u32 = 2u32;
pub const NDIS_QOS_TSA_MAXIMUM: u32 = 3u32;
pub const NDIS_QOS_TSA_STRICT: u32 = 0u32;
pub const NDIS_RECEIVE_FILTER_ANY_VLAN_SUPPORTED: u32 = 32u32;
pub const NDIS_RECEIVE_FILTER_ARP_HEADER_OPERATION_SUPPORTED: u32 = 1u32;
pub const NDIS_RECEIVE_FILTER_ARP_HEADER_SPA_SUPPORTED: u32 = 2u32;
pub const NDIS_RECEIVE_FILTER_ARP_HEADER_SUPPORTED: u32 = 8u32;
pub const NDIS_RECEIVE_FILTER_ARP_HEADER_TPA_SUPPORTED: u32 = 4u32;
pub const NDIS_RECEIVE_FILTER_CAPABILITIES_REVISION_1: u32 = 1u32;
pub const NDIS_RECEIVE_FILTER_CAPABILITIES_REVISION_2: u32 = 2u32;
pub const NDIS_RECEIVE_FILTER_CLEAR_PARAMETERS_REVISION_1: u32 = 1u32;
pub const NDIS_RECEIVE_FILTER_DYNAMIC_PROCESSOR_AFFINITY_CHANGE_FOR_DEFAULT_QUEUE_SUPPORTED: u32 = 64u32;
pub const NDIS_RECEIVE_FILTER_DYNAMIC_PROCESSOR_AFFINITY_CHANGE_SUPPORTED: u32 = 8u32;
pub const NDIS_RECEIVE_FILTER_FIELD_MAC_HEADER_VLAN_UNTAGGED_OR_ZERO: u32 = 1u32;
pub const NDIS_RECEIVE_FILTER_FIELD_PARAMETERS_REVISION_1: u32 = 1u32;
pub const NDIS_RECEIVE_FILTER_FIELD_PARAMETERS_REVISION_2: u32 = 2u32;
pub const NDIS_RECEIVE_FILTER_FLAGS_RESERVED: u32 = 1u32;
pub const NDIS_RECEIVE_FILTER_GLOBAL_PARAMETERS_REVISION_1: u32 = 1u32;
pub const NDIS_RECEIVE_FILTER_IMPLAT_MIN_OF_QUEUES_MODE: u32 = 64u32;
pub const NDIS_RECEIVE_FILTER_IMPLAT_SUM_OF_QUEUES_MODE: u32 = 128u32;
pub const NDIS_RECEIVE_FILTER_INFO_ARRAY_REVISION_1: u32 = 1u32;
pub const NDIS_RECEIVE_FILTER_INFO_ARRAY_REVISION_2: u32 = 2u32;
pub const NDIS_RECEIVE_FILTER_INFO_ARRAY_VPORT_ID_SPECIFIED: u32 = 1u32;
pub const NDIS_RECEIVE_FILTER_INFO_REVISION_1: u32 = 1u32;
pub const NDIS_RECEIVE_FILTER_INTERRUPT_VECTOR_COALESCING_SUPPORTED: u32 = 16u32;
pub const NDIS_RECEIVE_FILTER_IPV4_HEADER_PROTOCOL_SUPPORTED: u32 = 1u32;
pub const NDIS_RECEIVE_FILTER_IPV4_HEADER_SUPPORTED: u32 = 2u32;
pub const NDIS_RECEIVE_FILTER_IPV6_HEADER_PROTOCOL_SUPPORTED: u32 = 1u32;
pub const NDIS_RECEIVE_FILTER_IPV6_HEADER_SUPPORTED: u32 = 4u32;
pub const NDIS_RECEIVE_FILTER_LOOKAHEAD_SPLIT_SUPPORTED: u32 = 4u32;
pub const NDIS_RECEIVE_FILTER_MAC_HEADER_DEST_ADDR_SUPPORTED: u32 = 1u32;
pub const NDIS_RECEIVE_FILTER_MAC_HEADER_PACKET_TYPE_SUPPORTED: u32 = 32u32;
pub const NDIS_RECEIVE_FILTER_MAC_HEADER_PRIORITY_SUPPORTED: u32 = 16u32;
pub const NDIS_RECEIVE_FILTER_MAC_HEADER_PROTOCOL_SUPPORTED: u32 = 4u32;
pub const NDIS_RECEIVE_FILTER_MAC_HEADER_SOURCE_ADDR_SUPPORTED: u32 = 2u32;
pub const NDIS_RECEIVE_FILTER_MAC_HEADER_SUPPORTED: u32 = 1u32;
pub const NDIS_RECEIVE_FILTER_MAC_HEADER_VLAN_ID_SUPPORTED: u32 = 8u32;
pub const NDIS_RECEIVE_FILTER_MOVE_FILTER_PARAMETERS_REVISION_1: u32 = 1u32;
pub const NDIS_RECEIVE_FILTER_MSI_X_SUPPORTED: u32 = 1u32;
pub const NDIS_RECEIVE_FILTER_PACKET_COALESCING_FILTERS_ENABLED: u32 = 2u32;
pub const NDIS_RECEIVE_FILTER_PACKET_COALESCING_SUPPORTED_ON_DEFAULT_QUEUE: u32 = 256u32;
pub const NDIS_RECEIVE_FILTER_PACKET_ENCAPSULATION: u32 = 2u32;
pub const NDIS_RECEIVE_FILTER_PACKET_ENCAPSULATION_GRE: u32 = 2u32;
pub const NDIS_RECEIVE_FILTER_PARAMETERS_REVISION_1: u32 = 1u32;
pub const NDIS_RECEIVE_FILTER_PARAMETERS_REVISION_2: u32 = 2u32;
pub const NDIS_RECEIVE_FILTER_QUEUE_STATE_CHANGE_REVISION_1: u32 = 1u32;
pub const NDIS_RECEIVE_FILTER_RESERVED: u32 = 254u32;
pub const NDIS_RECEIVE_FILTER_TEST_HEADER_FIELD_EQUAL_SUPPORTED: u32 = 1u32;
pub const NDIS_RECEIVE_FILTER_TEST_HEADER_FIELD_MASK_EQUAL_SUPPORTED: u32 = 2u32;
pub const NDIS_RECEIVE_FILTER_TEST_HEADER_FIELD_NOT_EQUAL_SUPPORTED: u32 = 4u32;
pub const NDIS_RECEIVE_FILTER_UDP_HEADER_DEST_PORT_SUPPORTED: u32 = 1u32;
pub const NDIS_RECEIVE_FILTER_UDP_HEADER_SUPPORTED: u32 = 16u32;
pub const NDIS_RECEIVE_FILTER_VMQ_FILTERS_ENABLED: u32 = 1u32;
pub const NDIS_RECEIVE_FILTER_VM_QUEUES_ENABLED: u32 = 1u32;
pub const NDIS_RECEIVE_FILTER_VM_QUEUE_SUPPORTED: u32 = 2u32;
pub const NDIS_RECEIVE_FLAGS_DISPATCH_LEVEL: u32 = 1u32;
pub const NDIS_RECEIVE_FLAGS_MORE_NBLS: u32 = 8192u32;
pub const NDIS_RECEIVE_FLAGS_PERFECT_FILTERED: u32 = 1024u32;
pub const NDIS_RECEIVE_FLAGS_RESOURCES: u32 = 2u32;
pub const NDIS_RECEIVE_FLAGS_SHARED_MEMORY_INFO_VALID: u32 = 4096u32;
pub const NDIS_RECEIVE_FLAGS_SINGLE_ETHER_TYPE: u32 = 256u32;
pub const NDIS_RECEIVE_FLAGS_SINGLE_QUEUE: u32 = 2048u32;
pub const NDIS_RECEIVE_FLAGS_SINGLE_VLAN: u32 = 512u32;
pub const NDIS_RECEIVE_FLAGS_SWITCH_DESTINATION_GROUP: u32 = 16384u32;
pub const NDIS_RECEIVE_FLAGS_SWITCH_SINGLE_SOURCE: u32 = 32768u32;
pub const NDIS_RECEIVE_HASH_FLAG_ENABLE_HASH: u32 = 1u32;
pub const NDIS_RECEIVE_HASH_FLAG_HASH_INFO_UNCHANGED: u32 = 2u32;
pub const NDIS_RECEIVE_HASH_FLAG_HASH_KEY_UNCHANGED: u32 = 4u32;
pub const NDIS_RECEIVE_HASH_PARAMETERS_REVISION_1: u32 = 1u32;
pub const NDIS_RECEIVE_QUEUE_ALLOCATION_COMPLETE_ARRAY_REVISION_1: u32 = 1u32;
pub const NDIS_RECEIVE_QUEUE_ALLOCATION_COMPLETE_PARAMETERS_REVISION_1: u32 = 1u32;
pub const NDIS_RECEIVE_QUEUE_FREE_PARAMETERS_REVISION_1: u32 = 1u32;
pub const NDIS_RECEIVE_QUEUE_INFO_ARRAY_REVISION_1: u32 = 1u32;
pub const NDIS_RECEIVE_QUEUE_INFO_REVISION_1: u32 = 1u32;
pub const NDIS_RECEIVE_QUEUE_INFO_REVISION_2: u32 = 2u32;
pub const NDIS_RECEIVE_QUEUE_PARAMETERS_CHANGE_MASK: u32 = 4294901760u32;
pub const NDIS_RECEIVE_QUEUE_PARAMETERS_FLAGS_CHANGED: u32 = 65536u32;
pub const NDIS_RECEIVE_QUEUE_PARAMETERS_INTERRUPT_COALESCING_DOMAIN_ID_CHANGED: u32 = 1048576u32;
pub const NDIS_RECEIVE_QUEUE_PARAMETERS_LOOKAHEAD_SPLIT_REQUIRED: u32 = 2u32;
pub const NDIS_RECEIVE_QUEUE_PARAMETERS_NAME_CHANGED: u32 = 524288u32;
pub const NDIS_RECEIVE_QUEUE_PARAMETERS_PER_QUEUE_RECEIVE_INDICATION: u32 = 1u32;
pub const NDIS_RECEIVE_QUEUE_PARAMETERS_PROCESSOR_AFFINITY_CHANGED: u32 = 131072u32;
pub const NDIS_RECEIVE_QUEUE_PARAMETERS_QOS_SQ_ID_CHANGED: u32 = 2097152u32;
pub const NDIS_RECEIVE_QUEUE_PARAMETERS_REVISION_1: u32 = 1u32;
pub const NDIS_RECEIVE_QUEUE_PARAMETERS_REVISION_2: u32 = 2u32;
pub const NDIS_RECEIVE_QUEUE_PARAMETERS_REVISION_3: u32 = 3u32;
pub const NDIS_RECEIVE_QUEUE_PARAMETERS_SUGGESTED_RECV_BUFFER_NUMBERS_CHANGED: u32 = 262144u32;
pub const NDIS_RECEIVE_QUEUE_STATE_REVISION_1: u32 = 1u32;
pub const NDIS_RECEIVE_SCALE_CAPABILITIES_REVISION_1: u32 = 1u32;
pub const NDIS_RECEIVE_SCALE_CAPABILITIES_REVISION_2: u32 = 2u32;
pub const NDIS_RECEIVE_SCALE_CAPABILITIES_REVISION_3: u32 = 3u32;
pub const NDIS_RECEIVE_SCALE_PARAMETERS_REVISION_1: u32 = 1u32;
pub const NDIS_RECEIVE_SCALE_PARAMETERS_REVISION_2: u32 = 2u32;
pub const NDIS_RECEIVE_SCALE_PARAMETERS_REVISION_3: u32 = 3u32;
pub const NDIS_RECEIVE_SCALE_PARAMETERS_V2_REVISION_1: u32 = 1u32;
pub const NDIS_RECEIVE_SCALE_PARAM_ENABLE_RSS: u32 = 1u32;
pub const NDIS_RECEIVE_SCALE_PARAM_HASH_INFO_CHANGED: u32 = 2u32;
pub const NDIS_RECEIVE_SCALE_PARAM_HASH_KEY_CHANGED: u32 = 4u32;
pub const NDIS_RECEIVE_SCALE_PARAM_NUMBER_OF_ENTRIES_CHANGED: u32 = 16u32;
pub const NDIS_RECEIVE_SCALE_PARAM_NUMBER_OF_QUEUES_CHANGED: u32 = 8u32;
pub const NDIS_RESTART_GENERAL_ATTRIBUTES_MAX_LOOKAHEAD_ACCESSED_DEFINED: u32 = 1u32;
pub const NDIS_RESTART_GENERAL_ATTRIBUTES_REVISION_1: u32 = 1u32;
pub const NDIS_RESTART_GENERAL_ATTRIBUTES_REVISION_2: u32 = 2u32;
pub const NDIS_RETURN_FLAGS_DISPATCH_LEVEL: u32 = 1u32;
pub const NDIS_RETURN_FLAGS_SINGLE_QUEUE: u32 = 2u32;
pub const NDIS_RETURN_FLAGS_SWITCH_SINGLE_SOURCE: u32 = 4u32;
pub const NDIS_RING_AUTO_REMOVAL_ERROR: u32 = 1024u32;
pub const NDIS_RING_COUNTER_OVERFLOW: u32 = 256u32;
pub const NDIS_RING_HARD_ERROR: u32 = 16384u32;
pub const NDIS_RING_LOBE_WIRE_FAULT: u32 = 2048u32;
pub const NDIS_RING_REMOVE_RECEIVED: u32 = 512u32;
pub const NDIS_RING_RING_RECOVERY: u32 = 64u32;
pub const NDIS_RING_SIGNAL_LOSS: u32 = 32768u32;
pub const NDIS_RING_SINGLE_STATION: u32 = 128u32;
pub const NDIS_RING_SOFT_ERROR: u32 = 8192u32;
pub const NDIS_RING_TRANSMIT_BEACON: u32 = 4096u32;
pub const NDIS_ROUTING_DOMAIN_ENTRY_REVISION_1: u32 = 1u32;
pub const NDIS_ROUTING_DOMAIN_ISOLATION_ENTRY_REVISION_1: u32 = 1u32;
pub const NDIS_RSC_STATISTICS_REVISION_1: u32 = 1u32;
pub const NDIS_RSS_CAPS_CLASSIFICATION_AT_DPC: u32 = 67108864u32;
pub const NDIS_RSS_CAPS_CLASSIFICATION_AT_ISR: u32 = 33554432u32;
pub const NDIS_RSS_CAPS_HASH_TYPE_TCP_IPV4: u32 = 256u32;
pub const NDIS_RSS_CAPS_HASH_TYPE_TCP_IPV6: u32 = 512u32;
pub const NDIS_RSS_CAPS_HASH_TYPE_TCP_IPV6_EX: u32 = 1024u32;
pub const NDIS_RSS_CAPS_HASH_TYPE_UDP_IPV4: u32 = 2048u32;
pub const NDIS_RSS_CAPS_HASH_TYPE_UDP_IPV6: u32 = 4096u32;
pub const NDIS_RSS_CAPS_HASH_TYPE_UDP_IPV6_EX: u32 = 8192u32;
pub const NDIS_RSS_CAPS_MESSAGE_SIGNALED_INTERRUPTS: u32 = 16777216u32;
pub const NDIS_RSS_CAPS_RSS_AVAILABLE_ON_PORTS: u32 = 268435456u32;
pub const NDIS_RSS_CAPS_SUPPORTS_INDEPENDENT_ENTRY_MOVE: u32 = 1073741824u32;
pub const NDIS_RSS_CAPS_SUPPORTS_MSI_X: u32 = 536870912u32;
pub const NDIS_RSS_CAPS_USING_MSI_X: u32 = 134217728u32;
pub const NDIS_RSS_HASH_SECRET_KEY_MAX_SIZE_REVISION_1: u32 = 40u32;
pub const NDIS_RSS_HASH_SECRET_KEY_MAX_SIZE_REVISION_2: u32 = 40u32;
pub const NDIS_RSS_HASH_SECRET_KEY_MAX_SIZE_REVISION_3: u32 = 40u32;
pub const NDIS_RSS_HASH_SECRET_KEY_SIZE_REVISION_1: u32 = 40u32;
pub const NDIS_RSS_INDIRECTION_TABLE_MAX_SIZE_REVISION_1: u32 = 128u32;
pub const NDIS_RSS_INDIRECTION_TABLE_SIZE_REVISION_1: u32 = 128u32;
pub const NDIS_RSS_PARAM_FLAG_BASE_CPU_UNCHANGED: u32 = 1u32;
pub const NDIS_RSS_PARAM_FLAG_DEFAULT_PROCESSOR_UNCHANGED: u32 = 32u32;
pub const NDIS_RSS_PARAM_FLAG_DISABLE_RSS: u32 = 16u32;
pub const NDIS_RSS_PARAM_FLAG_HASH_INFO_UNCHANGED: u32 = 2u32;
pub const NDIS_RSS_PARAM_FLAG_HASH_KEY_UNCHANGED: u32 = 8u32;
pub const NDIS_RSS_PARAM_FLAG_ITABLE_UNCHANGED: u32 = 4u32;
pub const NDIS_RSS_PROCESSOR_INFO_REVISION_1: u32 = 1u32;
pub const NDIS_RSS_PROCESSOR_INFO_REVISION_2: u32 = 2u32;
pub const NDIS_RSS_SET_INDIRECTION_ENTRIES_REVISION_1: u32 = 1u32;
pub const NDIS_RSS_SET_INDIRECTION_ENTRY_FLAG_DEFAULT_PROCESSOR: u32 = 2u32;
pub const NDIS_RSS_SET_INDIRECTION_ENTRY_FLAG_PRIMARY_PROCESSOR: u32 = 1u32;
pub const NDIS_RUNTIME_VERSION_60: u32 = 393216u32;
pub const NDIS_RWL_AT_DISPATCH_LEVEL: u32 = 1u32;
pub const NDIS_SCATTER_GATHER_LIST_PARAMETERS_REVISION_1: u32 = 1u32;
pub const NDIS_SEND_COMPLETE_FLAGS_DISPATCH_LEVEL: u32 = 1u32;
pub const NDIS_SEND_COMPLETE_FLAGS_SINGLE_QUEUE: u32 = 2u32;
pub const NDIS_SEND_COMPLETE_FLAGS_SWITCH_SINGLE_SOURCE: u32 = 4u32;
pub const NDIS_SEND_FLAGS_CHECK_FOR_LOOPBACK: u32 = 2u32;
pub const NDIS_SEND_FLAGS_DISPATCH_LEVEL: u32 = 1u32;
pub const NDIS_SEND_FLAGS_SINGLE_QUEUE: u32 = 4u32;
pub const NDIS_SEND_FLAGS_SWITCH_DESTINATION_GROUP: u32 = 16u32;
pub const NDIS_SEND_FLAGS_SWITCH_SINGLE_SOURCE: u32 = 32u32;
pub const NDIS_SG_DMA_64_BIT_ADDRESS: u32 = 1u32;
pub const NDIS_SG_DMA_DESCRIPTION_REVISION_1: u32 = 1u32;
pub const NDIS_SG_DMA_DESCRIPTION_REVISION_2: u32 = 2u32;
pub const NDIS_SG_DMA_HYBRID_DMA: u32 = 4u32;
pub const NDIS_SG_DMA_V3_HAL_API: u32 = 2u32;
pub const NDIS_SG_LIST_WRITE_TO_DEVICE: u64 = 1u64;
pub const NDIS_SHARED_MEMORY_PARAMETERS_REVISION_1: u32 = 1u32;
pub const NDIS_SHARED_MEMORY_PARAMETERS_REVISION_2: u32 = 2u32;
pub const NDIS_SHARED_MEMORY_PROVIDER_CHARACTERISTICS_REVISION_1: u32 = 1u32;
pub const NDIS_SHARED_MEMORY_PROVIDER_CHAR_SUPPORTS_PF_VPORTS: u32 = 1u32;
pub const NDIS_SHARED_MEM_PARAMETERS_CONTIGOUS: u32 = 1u32;
pub const NDIS_SHARED_MEM_PARAMETERS_CONTIGUOUS: u32 = 1u32;
pub const NDIS_SIZEOF_NDIS_PM_PROTOCOL_OFFLOAD_REVISION_1: u32 = 240u32;
pub const NDIS_SRIOV_BAR_RESOURCES_INFO_REVISION_1: u32 = 1u32;
pub const NDIS_SRIOV_CAPABILITIES_REVISION_1: u32 = 1u32;
pub const NDIS_SRIOV_CAPS_PF_MINIPORT: u32 = 2u32;
pub const NDIS_SRIOV_CAPS_SRIOV_SUPPORTED: u32 = 1u32;
pub const NDIS_SRIOV_CAPS_VF_MINIPORT: u32 = 4u32;
pub const NDIS_SRIOV_CONFIG_STATE_PARAMETERS_REVISION_1: u32 = 1u32;
pub const NDIS_SRIOV_OVERLYING_ADAPTER_INFO_VERSION_1: u32 = 1u32;
pub const NDIS_SRIOV_PF_LUID_INFO_REVISION_1: u32 = 1u32;
pub const NDIS_SRIOV_PROBED_BARS_INFO_REVISION_1: u32 = 1u32;
pub const NDIS_SRIOV_READ_VF_CONFIG_BLOCK_PARAMETERS_REVISION_1: u32 = 1u32;
pub const NDIS_SRIOV_READ_VF_CONFIG_SPACE_PARAMETERS_REVISION_1: u32 = 1u32;
pub const NDIS_SRIOV_RESET_VF_PARAMETERS_REVISION_1: u32 = 1u32;
pub const NDIS_SRIOV_SET_VF_POWER_STATE_PARAMETERS_REVISION_1: u32 = 1u32;
pub const NDIS_SRIOV_VF_INVALIDATE_CONFIG_BLOCK_INFO_REVISION_1: u32 = 1u32;
pub const NDIS_SRIOV_VF_SERIAL_NUMBER_INFO_REVISION_1: u32 = 1u32;
pub const NDIS_SRIOV_VF_VENDOR_DEVICE_ID_INFO_REVISION_1: u32 = 1u32;
pub const NDIS_SRIOV_WRITE_VF_CONFIG_BLOCK_PARAMETERS_REVISION_1: u32 = 1u32;
pub const NDIS_SRIOV_WRITE_VF_CONFIG_SPACE_PARAMETERS_REVISION_1: u32 = 1u32;
pub const NDIS_STATISTICS_BROADCAST_BYTES_RCV_SUPPORTED: u32 = 32768u32;
pub const NDIS_STATISTICS_BROADCAST_BYTES_XMIT_SUPPORTED: u32 = 512u32;
pub const NDIS_STATISTICS_BROADCAST_FRAMES_RCV_SUPPORTED: u32 = 65536u32;
pub const NDIS_STATISTICS_BROADCAST_FRAMES_XMIT_SUPPORTED: u32 = 1024u32;
pub const NDIS_STATISTICS_BYTES_RCV_SUPPORTED: u32 = 524288u32;
pub const NDIS_STATISTICS_BYTES_XMIT_SUPPORTED: u32 = 1048576u32;
pub const NDIS_STATISTICS_DIRECTED_BYTES_RCV_SUPPORTED: u32 = 2048u32;
pub const NDIS_STATISTICS_DIRECTED_BYTES_XMIT_SUPPORTED: u32 = 32u32;
pub const NDIS_STATISTICS_DIRECTED_FRAMES_RCV_SUPPORTED: u32 = 4096u32;
pub const NDIS_STATISTICS_DIRECTED_FRAMES_XMIT_SUPPORTED: u32 = 64u32;
pub const NDIS_STATISTICS_FLAGS_VALID_BROADCAST_BYTES_RCV: u32 = 262144u32;
pub const NDIS_STATISTICS_FLAGS_VALID_BROADCAST_BYTES_XMIT: u32 = 2097152u32;
pub const NDIS_STATISTICS_FLAGS_VALID_BROADCAST_FRAMES_RCV: u32 = 4u32;
pub const NDIS_STATISTICS_FLAGS_VALID_BROADCAST_FRAMES_XMIT: u32 = 256u32;
pub const NDIS_STATISTICS_FLAGS_VALID_BYTES_RCV: u32 = 8u32;
pub const NDIS_STATISTICS_FLAGS_VALID_BYTES_XMIT: u32 = 512u32;
pub const NDIS_STATISTICS_FLAGS_VALID_DIRECTED_BYTES_RCV: u32 = 65536u32;
pub const NDIS_STATISTICS_FLAGS_VALID_DIRECTED_BYTES_XMIT: u32 = 524288u32;
pub const NDIS_STATISTICS_FLAGS_VALID_DIRECTED_FRAMES_RCV: u32 = 1u32;
pub const NDIS_STATISTICS_FLAGS_VALID_DIRECTED_FRAMES_XMIT: u32 = 64u32;
pub const NDIS_STATISTICS_FLAGS_VALID_MULTICAST_BYTES_RCV: u32 = 131072u32;
pub const NDIS_STATISTICS_FLAGS_VALID_MULTICAST_BYTES_XMIT: u32 = 1048576u32;
pub const NDIS_STATISTICS_FLAGS_VALID_MULTICAST_FRAMES_RCV: u32 = 2u32;
pub const NDIS_STATISTICS_FLAGS_VALID_MULTICAST_FRAMES_XMIT: u32 = 128u32;
pub const NDIS_STATISTICS_FLAGS_VALID_RCV_DISCARDS: u32 = 16u32;
pub const NDIS_STATISTICS_FLAGS_VALID_RCV_ERROR: u32 = 32u32;
pub const NDIS_STATISTICS_FLAGS_VALID_XMIT_DISCARDS: u32 = 32768u32;
pub const NDIS_STATISTICS_FLAGS_VALID_XMIT_ERROR: u32 = 1024u32;
pub const NDIS_STATISTICS_GEN_STATISTICS_SUPPORTED: u32 = 4194304u32;
pub const NDIS_STATISTICS_INFO_REVISION_1: u32 = 1u32;
pub const NDIS_STATISTICS_MULTICAST_BYTES_RCV_SUPPORTED: u32 = 8192u32;
pub const NDIS_STATISTICS_MULTICAST_BYTES_XMIT_SUPPORTED: u32 = 128u32;
pub const NDIS_STATISTICS_MULTICAST_FRAMES_RCV_SUPPORTED: u32 = 16384u32;
pub const NDIS_STATISTICS_MULTICAST_FRAMES_XMIT_SUPPORTED: u32 = 256u32;
pub const NDIS_STATISTICS_RCV_CRC_ERROR_SUPPORTED: u32 = 131072u32;
pub const NDIS_STATISTICS_RCV_DISCARDS_SUPPORTED: u32 = 2097152u32;
pub const NDIS_STATISTICS_RCV_ERROR_SUPPORTED: u32 = 8u32;
pub const NDIS_STATISTICS_RCV_NO_BUFFER_SUPPORTED: u32 = 16u32;
pub const NDIS_STATISTICS_RCV_OK_SUPPORTED: u32 = 2u32;
pub const NDIS_STATISTICS_TRANSMIT_QUEUE_LENGTH_SUPPORTED: u32 = 262144u32;
pub const NDIS_STATISTICS_XMIT_DISCARDS_SUPPORTED: u32 = 134217728u32;
pub const NDIS_STATISTICS_XMIT_ERROR_SUPPORTED: u32 = 4u32;
pub const NDIS_STATISTICS_XMIT_OK_SUPPORTED: u32 = 1u32;
pub const NDIS_STATUS_INDICATION_FLAGS_MEDIA_CONNECT_TO_CONNECT: u32 = 4096u32;
pub const NDIS_STATUS_INDICATION_FLAGS_NDIS_RESERVED: u32 = 4095u32;
pub const NDIS_STATUS_INDICATION_REVISION_1: u32 = 1u32;
pub const NDIS_SUPPORT_60_COMPATIBLE_API: u32 = 1u32;
pub const NDIS_SUPPORT_NDIS6: u32 = 1u32;
pub const NDIS_SUPPORT_NDIS61: u32 = 1u32;
pub const NDIS_SUPPORT_NDIS620: u32 = 1u32;
pub const NDIS_SUPPORT_NDIS630: u32 = 1u32;
pub const NDIS_SUPPORT_NDIS640: u32 = 1u32;
pub const NDIS_SUPPORT_NDIS650: u32 = 1u32;
pub const NDIS_SUPPORT_NDIS651: u32 = 1u32;
pub const NDIS_SUPPORT_NDIS660: u32 = 1u32;
pub const NDIS_SUPPORT_NDIS670: u32 = 1u32;
pub const NDIS_SUPPORT_NDIS680: u32 = 1u32;
pub const NDIS_SUPPORT_NDIS681: u32 = 1u32;
pub const NDIS_SUPPORT_NDIS682: u32 = 1u32;
pub const NDIS_SUPPORT_NDIS683: u32 = 1u32;
pub const NDIS_SUPPORT_NDIS684: u32 = 1u32;
pub const NDIS_SUPPORT_NDIS685: u32 = 1u32;
pub const NDIS_SUPPORT_NDIS686: u32 = 1u32;
pub const NDIS_SUPPORT_NDIS687: u32 = 1u32;
pub const NDIS_SWITCH_COPY_NBL_INFO_FLAGS_PRESERVE_DESTINATIONS: u32 = 1u32;
pub const NDIS_SWITCH_COPY_NBL_INFO_FLAGS_PRESERVE_SWITCH_INFO_ONLY: u32 = 2u32;
pub const NDIS_SWITCH_DEFAULT_NIC_INDEX: u32 = 0u32;
pub const NDIS_SWITCH_DEFAULT_PORT_ID: u32 = 0u32;
pub const NDIS_SWITCH_FEATURE_STATUS_CUSTOM_REVISION_1: u32 = 1u32;
pub const NDIS_SWITCH_FEATURE_STATUS_PARAMETERS_REVISION_1: u32 = 1u32;
pub const NDIS_SWITCH_FORWARDING_DESTINATION_ARRAY_REVISION_1: u32 = 1u32;
pub const NDIS_SWITCH_NET_BUFFER_LIST_CONTEXT_TYPE_INFO_REVISION_1: u32 = 1u32;
pub const NDIS_SWITCH_NIC_ARRAY_REVISION_1: u32 = 1u32;
pub const NDIS_SWITCH_NIC_FLAGS_MAPPED_NIC_UPDATED: u32 = 4u32;
pub const NDIS_SWITCH_NIC_FLAGS_NIC_INITIALIZING: u32 = 1u32;
pub const NDIS_SWITCH_NIC_FLAGS_NIC_SUSPENDED: u32 = 2u32;
pub const NDIS_SWITCH_NIC_FLAGS_NIC_SUSPENDED_LM: u32 = 16u32;
pub const NDIS_SWITCH_NIC_OID_REQUEST_REVISION_1: u32 = 1u32;
pub const NDIS_SWITCH_NIC_PARAMETERS_REVISION_1: u32 = 1u32;
pub const NDIS_SWITCH_NIC_PARAMETERS_REVISION_2: u32 = 2u32;
pub const NDIS_SWITCH_NIC_SAVE_STATE_REVISION_1: u32 = 1u32;
pub const NDIS_SWITCH_NIC_SAVE_STATE_REVISION_2: u32 = 2u32;
pub const NDIS_SWITCH_NIC_STATUS_INDICATION_REVISION_1: u32 = 1u32;
pub const NDIS_SWITCH_OBJECT_SERIALIZATION_VERSION_1: u32 = 1u32;
pub const NDIS_SWITCH_OPTIONAL_HANDLERS_PD_RESERVED_SIZE: u32 = 14u32;
pub const NDIS_SWITCH_OPTIONAL_HANDLERS_REVISION_1: u32 = 1u32;
pub const NDIS_SWITCH_OPTIONAL_HANDLERS_REVISION_2: u32 = 2u32;
pub const NDIS_SWITCH_PARAMETERS_REVISION_1: u32 = 1u32;
pub const NDIS_SWITCH_PORT_ARRAY_REVISION_1: u32 = 1u32;
pub const NDIS_SWITCH_PORT_FEATURE_STATUS_CUSTOM_REVISION_1: u32 = 1u32;
pub const NDIS_SWITCH_PORT_FEATURE_STATUS_PARAMETERS_REVISION_1: u32 = 1u32;
pub const NDIS_SWITCH_PORT_PARAMETERS_FLAG_RESTORING_PORT: u32 = 2u32;
pub const NDIS_SWITCH_PORT_PARAMETERS_FLAG_UNTRUSTED_INTERNAL_PORT: u32 = 1u32;
pub const NDIS_SWITCH_PORT_PARAMETERS_REVISION_1: u32 = 1u32;
pub const NDIS_SWITCH_PORT_PROPERTY_CUSTOM_REVISION_1: u32 = 1u32;
pub const NDIS_SWITCH_PORT_PROPERTY_DELETE_PARAMETERS_REVISION_1: u32 = 1u32;
pub const NDIS_SWITCH_PORT_PROPERTY_ENUM_INFO_REVISION_1: u32 = 1u32;
pub const NDIS_SWITCH_PORT_PROPERTY_ENUM_PARAMETERS_REVISION_1: u32 = 1u32;
pub const NDIS_SWITCH_PORT_PROPERTY_ISOLATION_REVISION_1: u32 = 1u32;
pub const NDIS_SWITCH_PORT_PROPERTY_PARAMETERS_REVISION_1: u32 = 1u32;
pub const NDIS_SWITCH_PORT_PROPERTY_PROFILE_REVISION_1: u32 = 1u32;
pub const NDIS_SWITCH_PORT_PROPERTY_ROUTING_DOMAIN_REVISION_1: u32 = 1u32;
pub const NDIS_SWITCH_PORT_PROPERTY_SECURITY_REVISION_1: u32 = 1u32;
pub const NDIS_SWITCH_PORT_PROPERTY_SECURITY_REVISION_2: u32 = 2u32;
pub const NDIS_SWITCH_PORT_PROPERTY_VLAN_REVISION_1: u32 = 1u32;
pub const NDIS_SWITCH_PROPERTY_CUSTOM_REVISION_1: u32 = 1u32;
pub const NDIS_SWITCH_PROPERTY_DELETE_PARAMETERS_REVISION_1: u32 = 1u32;
pub const NDIS_SWITCH_PROPERTY_ENUM_INFO_REVISION_1: u32 = 1u32;
pub const NDIS_SWITCH_PROPERTY_ENUM_PARAMETERS_REVISION_1: u32 = 1u32;
pub const NDIS_SWITCH_PROPERTY_PARAMETERS_REVISION_1: u32 = 1u32;
pub const NDIS_SWITCH_REPORT_FILTERED_NBL_FLAGS_IS_INCOMING: u32 = 1u32;
pub const NDIS_SYSTEM_PROCESSOR_INFO_EX_REVISION_1: u32 = 1u32;
pub const NDIS_SYSTEM_PROCESSOR_INFO_REVISION_1: u32 = 1u32;
pub const NDIS_TASK_OFFLOAD_VERSION: u32 = 1u32;
pub const NDIS_TASK_TCP_LARGE_SEND_V0: u32 = 0u32;
pub const NDIS_TCP_CONNECTION_OFFLOAD_REVISION_1: u32 = 1u32;
pub const NDIS_TCP_CONNECTION_OFFLOAD_REVISION_2: u32 = 2u32;
pub const NDIS_TCP_LARGE_SEND_OFFLOAD_IPv4: u32 = 0u32;
pub const NDIS_TCP_LARGE_SEND_OFFLOAD_IPv6: u32 = 1u32;
pub const NDIS_TCP_LARGE_SEND_OFFLOAD_V1_TYPE: u32 = 0u32;
pub const NDIS_TCP_LARGE_SEND_OFFLOAD_V2_TYPE: u32 = 1u32;
pub const NDIS_TCP_RECV_SEG_COALESC_OFFLOAD_REVISION_1: u32 = 1u32;
pub const NDIS_TIMEOUT_DPC_REQUEST_CAPABILITIES_REVISION_1: u32 = 1u32;
pub const NDIS_TIMER_CHARACTERISTICS_REVISION_1: u32 = 1u32;
pub const NDIS_TIMESTAMP_CAPABILITIES_REVISION_1: u32 = 1u32;
pub const NDIS_UDP_SEGMENTATION_OFFLOAD_IPV4: u32 = 0u32;
pub const NDIS_UDP_SEGMENTATION_OFFLOAD_IPV6: u32 = 1u32;
pub const NDIS_WDF: u32 = 1u32;
pub const NDIS_WDM: u32 = 0u32;
pub const NDIS_WDM_DRIVER: u32 = 2u32;
pub const NDIS_WLAN_WAKE_ON_4WAY_HANDSHAKE_REQUEST_ENABLED: u32 = 8u32;
pub const NDIS_WLAN_WAKE_ON_4WAY_HANDSHAKE_REQUEST_SUPPORTED: u32 = 8u32;
pub const NDIS_WLAN_WAKE_ON_AP_ASSOCIATION_LOST_ENABLED: u32 = 2u32;
pub const NDIS_WLAN_WAKE_ON_AP_ASSOCIATION_LOST_SUPPORTED: u32 = 2u32;
pub const NDIS_WLAN_WAKE_ON_GTK_HANDSHAKE_ERROR_ENABLED: u32 = 4u32;
pub const NDIS_WLAN_WAKE_ON_GTK_HANDSHAKE_ERROR_SUPPORTED: u32 = 4u32;
pub const NDIS_WLAN_WAKE_ON_NLO_DISCOVERY_ENABLED: u32 = 1u32;
pub const NDIS_WLAN_WAKE_ON_NLO_DISCOVERY_SUPPORTED: u32 = 1u32;
pub const NDIS_WMI_DEFAULT_METHOD_ID: u32 = 1u32;
pub const NDIS_WMI_ENUM_ADAPTER_REVISION_1: u32 = 1u32;
pub const NDIS_WMI_EVENT_HEADER_REVISION_1: u32 = 1u32;
pub const NDIS_WMI_METHOD_HEADER_REVISION_1: u32 = 1u32;
pub const NDIS_WMI_OBJECT_TYPE_ENUM_ADAPTER: u32 = 4u32;
pub const NDIS_WMI_OBJECT_TYPE_EVENT: u32 = 3u32;
pub const NDIS_WMI_OBJECT_TYPE_METHOD: u32 = 2u32;
pub const NDIS_WMI_OBJECT_TYPE_OUTPUT_INFO: u32 = 5u32;
pub const NDIS_WMI_OBJECT_TYPE_SET: u32 = 1u32;
pub const NDIS_WMI_PM_ACTIVE_CAPABILITIES_REVISION_1: u32 = 1u32;
pub const NDIS_WMI_PM_ADMIN_CONFIG_REVISION_1: u32 = 1u32;
pub const NDIS_WMI_RECEIVE_QUEUE_INFO_REVISION_1: u32 = 1u32;
pub const NDIS_WMI_RECEIVE_QUEUE_PARAMETERS_REVISION_1: u32 = 1u32;
pub const NDIS_WMI_SET_HEADER_REVISION_1: u32 = 1u32;
pub const NDIS_WWAN_WAKE_ON_PACKET_STATE_ENABLED: u32 = 8u32;
pub const NDIS_WWAN_WAKE_ON_PACKET_STATE_SUPPORTED: u32 = 8u32;
pub const NDIS_WWAN_WAKE_ON_REGISTER_STATE_ENABLED: u32 = 1u32;
pub const NDIS_WWAN_WAKE_ON_REGISTER_STATE_SUPPORTED: u32 = 1u32;
pub const NDIS_WWAN_WAKE_ON_SMS_RECEIVE_ENABLED: u32 = 2u32;
pub const NDIS_WWAN_WAKE_ON_SMS_RECEIVE_SUPPORTED: u32 = 2u32;
pub const NDIS_WWAN_WAKE_ON_UICC_CHANGE_ENABLED: u32 = 16u32;
pub const NDIS_WWAN_WAKE_ON_UICC_CHANGE_SUPPORTED: u32 = 16u32;
pub const NDIS_WWAN_WAKE_ON_USSD_RECEIVE_ENABLED: u32 = 4u32;
pub const NDIS_WWAN_WAKE_ON_USSD_RECEIVE_SUPPORTED: u32 = 4u32;
pub const NET_BUFFER_LIST_POOL_FLAG_VERIFY: u32 = 1u32;
pub const NET_BUFFER_LIST_POOL_PARAMETERS_REVISION_1: u32 = 1u32;
pub const NET_BUFFER_LIST_POOL_PARAMETERS_REVISION_2: u32 = 2u32;
pub const NET_BUFFER_POOL_FLAG_VERIFY: u32 = 1u32;
pub const NET_BUFFER_POOL_PARAMETERS_REVISION_1: u32 = 1u32;
pub const NET_BUFFER_POOL_PARAMETERS_REVISION_2: u32 = 2u32;
pub const NET_DEVICE_PNP_EVENT_REVISION_1: u32 = 1u32;
pub const NET_EVENT_FLAGS_VPORT_ID_VALID: u32 = 2u32;
pub const NET_EVENT_HALT_MINIPORT_ON_LOW_POWER: u32 = 1u32;
pub const NET_PNP_EVENT_NOTIFICATION_REVISION_1: u32 = 1u32;
pub const NET_PNP_EVENT_NOTIFICATION_REVISION_2: u32 = 2u32;
pub const Ndis802_11AuthModeAutoSwitch: NDIS_802_11_AUTHENTICATION_MODE = 2i32;
pub const Ndis802_11AuthModeMax: NDIS_802_11_AUTHENTICATION_MODE = 11i32;
pub const Ndis802_11AuthModeOpen: NDIS_802_11_AUTHENTICATION_MODE = 0i32;
pub const Ndis802_11AuthModeShared: NDIS_802_11_AUTHENTICATION_MODE = 1i32;
pub const Ndis802_11AuthModeWPA: NDIS_802_11_AUTHENTICATION_MODE = 3i32;
pub const Ndis802_11AuthModeWPA2: NDIS_802_11_AUTHENTICATION_MODE = 6i32;
pub const Ndis802_11AuthModeWPA2PSK: NDIS_802_11_AUTHENTICATION_MODE = 7i32;
pub const Ndis802_11AuthModeWPA3: NDIS_802_11_AUTHENTICATION_MODE = 8i32;
pub const Ndis802_11AuthModeWPA3Ent: NDIS_802_11_AUTHENTICATION_MODE = 10i32;
pub const Ndis802_11AuthModeWPA3Ent192: NDIS_802_11_AUTHENTICATION_MODE = 8i32;
pub const Ndis802_11AuthModeWPA3SAE: NDIS_802_11_AUTHENTICATION_MODE = 9i32;
pub const Ndis802_11AuthModeWPANone: NDIS_802_11_AUTHENTICATION_MODE = 5i32;
pub const Ndis802_11AuthModeWPAPSK: NDIS_802_11_AUTHENTICATION_MODE = 4i32;
pub const Ndis802_11AutoUnknown: NDIS_802_11_NETWORK_INFRASTRUCTURE = 2i32;
pub const Ndis802_11Automode: NDIS_802_11_NETWORK_TYPE = 4i32;
pub const Ndis802_11DS: NDIS_802_11_NETWORK_TYPE = 1i32;
pub const Ndis802_11Encryption1Enabled: NDIS_802_11_WEP_STATUS = 0i32;
pub const Ndis802_11Encryption1KeyAbsent: NDIS_802_11_WEP_STATUS = 2i32;
pub const Ndis802_11Encryption2Enabled: NDIS_802_11_WEP_STATUS = 4i32;
pub const Ndis802_11Encryption2KeyAbsent: NDIS_802_11_WEP_STATUS = 5i32;
pub const Ndis802_11Encryption3Enabled: NDIS_802_11_WEP_STATUS = 6i32;
pub const Ndis802_11Encryption3KeyAbsent: NDIS_802_11_WEP_STATUS = 7i32;
pub const Ndis802_11EncryptionDisabled: NDIS_802_11_WEP_STATUS = 1i32;
pub const Ndis802_11EncryptionNotSupported: NDIS_802_11_WEP_STATUS = 3i32;
pub const Ndis802_11FH: NDIS_802_11_NETWORK_TYPE = 0i32;
pub const Ndis802_11IBSS: NDIS_802_11_NETWORK_INFRASTRUCTURE = 0i32;
pub const Ndis802_11Infrastructure: NDIS_802_11_NETWORK_INFRASTRUCTURE = 1i32;
pub const Ndis802_11InfrastructureMax: NDIS_802_11_NETWORK_INFRASTRUCTURE = 3i32;
pub const Ndis802_11MediaStreamOff: NDIS_802_11_MEDIA_STREAM_MODE = 0i32;
pub const Ndis802_11MediaStreamOn: NDIS_802_11_MEDIA_STREAM_MODE = 1i32;
pub const Ndis802_11NetworkTypeMax: NDIS_802_11_NETWORK_TYPE = 5i32;
pub const Ndis802_11OFDM24: NDIS_802_11_NETWORK_TYPE = 3i32;
pub const Ndis802_11OFDM5: NDIS_802_11_NETWORK_TYPE = 2i32;
pub const Ndis802_11PowerModeCAM: NDIS_802_11_POWER_MODE = 0i32;
pub const Ndis802_11PowerModeFast_PSP: NDIS_802_11_POWER_MODE = 2i32;
pub const Ndis802_11PowerModeMAX_PSP: NDIS_802_11_POWER_MODE = 1i32;
pub const Ndis802_11PowerModeMax: NDIS_802_11_POWER_MODE = 3i32;
pub const Ndis802_11PrivFilter8021xWEP: NDIS_802_11_PRIVACY_FILTER = 1i32;
pub const Ndis802_11PrivFilterAcceptAll: NDIS_802_11_PRIVACY_FILTER = 0i32;
pub const Ndis802_11RadioStatusHardwareOff: NDIS_802_11_RADIO_STATUS = 1i32;
pub const Ndis802_11RadioStatusHardwareSoftwareOff: NDIS_802_11_RADIO_STATUS = 3i32;
pub const Ndis802_11RadioStatusMax: NDIS_802_11_RADIO_STATUS = 4i32;
pub const Ndis802_11RadioStatusOn: NDIS_802_11_RADIO_STATUS = 0i32;
pub const Ndis802_11RadioStatusSoftwareOff: NDIS_802_11_RADIO_STATUS = 2i32;
pub const Ndis802_11ReloadWEPKeys: NDIS_802_11_RELOAD_DEFAULTS = 0i32;
pub const Ndis802_11StatusTypeMax: NDIS_802_11_STATUS_TYPE = 3i32;
pub const Ndis802_11StatusType_Authentication: NDIS_802_11_STATUS_TYPE = 0i32;
pub const Ndis802_11StatusType_MediaStreamMode: NDIS_802_11_STATUS_TYPE = 1i32;
pub const Ndis802_11StatusType_PMKID_CandidateList: NDIS_802_11_STATUS_TYPE = 2i32;
pub const Ndis802_11WEPDisabled: NDIS_802_11_WEP_STATUS = 1i32;
pub const Ndis802_11WEPEnabled: NDIS_802_11_WEP_STATUS = 0i32;
pub const Ndis802_11WEPKeyAbsent: NDIS_802_11_WEP_STATUS = 2i32;
pub const Ndis802_11WEPNotSupported: NDIS_802_11_WEP_STATUS = 3i32;
pub const NdisClass802_3Priority: NDIS_CLASS_ID = 0i32;
pub const NdisClassAtmAALInfo: NDIS_CLASS_ID = 3i32;
pub const NdisClassIrdaPacketInfo: NDIS_CLASS_ID = 2i32;
pub const NdisClassWirelessWanMbxMailbox: NDIS_CLASS_ID = 1i32;
pub const NdisDefinitelyNetworkChange: NDIS_NETWORK_CHANGE_TYPE = 2i32;
pub const NdisDevicePnPEventMaximum: NDIS_DEVICE_PNP_EVENT = 6i32;
pub const NdisDevicePnPEventPowerProfileChanged: NDIS_DEVICE_PNP_EVENT = 5i32;
pub const NdisDevicePnPEventQueryRemoved: NDIS_DEVICE_PNP_EVENT = 0i32;
pub const NdisDevicePnPEventQueryStopped: NDIS_DEVICE_PNP_EVENT = 3i32;
pub const NdisDevicePnPEventRemoved: NDIS_DEVICE_PNP_EVENT = 1i32;
pub const NdisDevicePnPEventStopped: NDIS_DEVICE_PNP_EVENT = 4i32;
pub const NdisDevicePnPEventSurpriseRemoved: NDIS_DEVICE_PNP_EVENT = 2i32;
pub const NdisDeviceStateD0: NDIS_DEVICE_POWER_STATE = 1i32;
pub const NdisDeviceStateD1: NDIS_DEVICE_POWER_STATE = 2i32;
pub const NdisDeviceStateD2: NDIS_DEVICE_POWER_STATE = 3i32;
pub const NdisDeviceStateD3: NDIS_DEVICE_POWER_STATE = 4i32;
pub const NdisDeviceStateMaximum: NDIS_DEVICE_POWER_STATE = 5i32;
pub const NdisDeviceStateUnspecified: NDIS_DEVICE_POWER_STATE = 0i32;
pub const NdisEnvironmentWindows: NDIS_ENVIRONMENT_TYPE = 0i32;
pub const NdisEnvironmentWindowsNt: NDIS_ENVIRONMENT_TYPE = 1i32;
pub const NdisFddiRingDetect: NDIS_FDDI_RING_MGT_STATE = 4i32;
pub const NdisFddiRingDirected: NDIS_FDDI_RING_MGT_STATE = 7i32;
pub const NdisFddiRingIsolated: NDIS_FDDI_RING_MGT_STATE = 1i32;
pub const NdisFddiRingNonOperational: NDIS_FDDI_RING_MGT_STATE = 2i32;
pub const NdisFddiRingNonOperationalDup: NDIS_FDDI_RING_MGT_STATE = 5i32;
pub const NdisFddiRingOperational: NDIS_FDDI_RING_MGT_STATE = 3i32;
pub const NdisFddiRingOperationalDup: NDIS_FDDI_RING_MGT_STATE = 6i32;
pub const NdisFddiRingTrace: NDIS_FDDI_RING_MGT_STATE = 8i32;
pub const NdisFddiStateActive: NDIS_FDDI_LCONNECTION_STATE = 9i32;
pub const NdisFddiStateBreak: NDIS_FDDI_LCONNECTION_STATE = 2i32;
pub const NdisFddiStateConnect: NDIS_FDDI_LCONNECTION_STATE = 4i32;
pub const NdisFddiStateJoin: NDIS_FDDI_LCONNECTION_STATE = 7i32;
pub const NdisFddiStateMaintenance: NDIS_FDDI_LCONNECTION_STATE = 10i32;
pub const NdisFddiStateNext: NDIS_FDDI_LCONNECTION_STATE = 5i32;
pub const NdisFddiStateOff: NDIS_FDDI_LCONNECTION_STATE = 1i32;
pub const NdisFddiStateSignal: NDIS_FDDI_LCONNECTION_STATE = 6i32;
pub const NdisFddiStateTrace: NDIS_FDDI_LCONNECTION_STATE = 3i32;
pub const NdisFddiStateVerify: NDIS_FDDI_LCONNECTION_STATE = 8i32;
pub const NdisFddiTypeCWrapA: NDIS_FDDI_ATTACHMENT_TYPE = 10i32;
pub const NdisFddiTypeCWrapB: NDIS_FDDI_ATTACHMENT_TYPE = 11i32;
pub const NdisFddiTypeCWrapS: NDIS_FDDI_ATTACHMENT_TYPE = 12i32;
pub const NdisFddiTypeIsolated: NDIS_FDDI_ATTACHMENT_TYPE = 1i32;
pub const NdisFddiTypeLocalA: NDIS_FDDI_ATTACHMENT_TYPE = 2i32;
pub const NdisFddiTypeLocalAB: NDIS_FDDI_ATTACHMENT_TYPE = 4i32;
pub const NdisFddiTypeLocalB: NDIS_FDDI_ATTACHMENT_TYPE = 3i32;
pub const NdisFddiTypeLocalS: NDIS_FDDI_ATTACHMENT_TYPE = 5i32;
pub const NdisFddiTypeThrough: NDIS_FDDI_ATTACHMENT_TYPE = 13i32;
pub const NdisFddiTypeWrapA: NDIS_FDDI_ATTACHMENT_TYPE = 6i32;
pub const NdisFddiTypeWrapAB: NDIS_FDDI_ATTACHMENT_TYPE = 8i32;
pub const NdisFddiTypeWrapB: NDIS_FDDI_ATTACHMENT_TYPE = 7i32;
pub const NdisFddiTypeWrapS: NDIS_FDDI_ATTACHMENT_TYPE = 9i32;
pub const NdisHardwareStatusClosing: NDIS_HARDWARE_STATUS = 3i32;
pub const NdisHardwareStatusInitializing: NDIS_HARDWARE_STATUS = 1i32;
pub const NdisHardwareStatusNotReady: NDIS_HARDWARE_STATUS = 4i32;
pub const NdisHardwareStatusReady: NDIS_HARDWARE_STATUS = 0i32;
pub const NdisHardwareStatusReset: NDIS_HARDWARE_STATUS = 2i32;
pub const NdisHashFunctionReserved1: u32 = 2u32;
pub const NdisHashFunctionReserved2: u32 = 4u32;
pub const NdisHashFunctionReserved3: u32 = 8u32;
pub const NdisHashFunctionToeplitz: u32 = 1u32;
pub const NdisInterface1394: NDIS_INTERFACE_TYPE = 18i32;
pub const NdisInterfaceCBus: NDIS_INTERFACE_TYPE = 9i32;
pub const NdisInterfaceEisa: NDIS_INTERFACE_TYPE = 2i32;
pub const NdisInterfaceInternal: NDIS_INTERFACE_TYPE = 0i32;
pub const NdisInterfaceInternalPowerBus: NDIS_INTERFACE_TYPE = 13i32;
pub const NdisInterfaceIrda: NDIS_INTERFACE_TYPE = 17i32;
pub const NdisInterfaceIsa: NDIS_INTERFACE_TYPE = 1i32;
pub const NdisInterfaceMPIBus: NDIS_INTERFACE_TYPE = 10i32;
pub const NdisInterfaceMPSABus: NDIS_INTERFACE_TYPE = 11i32;
pub const NdisInterfaceMca: NDIS_INTERFACE_TYPE = 3i32;
pub const NdisInterfacePNPBus: NDIS_INTERFACE_TYPE = 15i32;
pub const NdisInterfacePNPISABus: NDIS_INTERFACE_TYPE = 14i32;
pub const NdisInterfacePcMcia: NDIS_INTERFACE_TYPE = 8i32;
pub const NdisInterfacePci: NDIS_INTERFACE_TYPE = 5i32;
pub const NdisInterfaceProcessorInternal: NDIS_INTERFACE_TYPE = 12i32;
pub const NdisInterfaceTurboChannel: NDIS_INTERFACE_TYPE = 4i32;
pub const NdisInterfaceUSB: NDIS_INTERFACE_TYPE = 16i32;
pub const NdisInterruptModerationDisabled: NDIS_INTERRUPT_MODERATION = 3i32;
pub const NdisInterruptModerationEnabled: NDIS_INTERRUPT_MODERATION = 2i32;
pub const NdisInterruptModerationNotSupported: NDIS_INTERRUPT_MODERATION = 1i32;
pub const NdisInterruptModerationUnknown: NDIS_INTERRUPT_MODERATION = 0i32;
pub const NdisMaximumInterfaceType: NDIS_INTERFACE_TYPE = 19i32;
pub const NdisMediaStateConnected: NDIS_MEDIA_STATE = 0i32;
pub const NdisMediaStateDisconnected: NDIS_MEDIA_STATE = 1i32;
pub const NdisMedium1394: NDIS_MEDIUM = 13i32;
pub const NdisMedium802_3: NDIS_MEDIUM = 0i32;
pub const NdisMedium802_5: NDIS_MEDIUM = 1i32;
pub const NdisMediumArcnet878_2: NDIS_MEDIUM = 7i32;
pub const NdisMediumArcnetRaw: NDIS_MEDIUM = 6i32;
pub const NdisMediumAtm: NDIS_MEDIUM = 8i32;
pub const NdisMediumBpc: NDIS_MEDIUM = 11i32;
pub const NdisMediumCoWan: NDIS_MEDIUM = 12i32;
pub const NdisMediumDix: NDIS_MEDIUM = 5i32;
pub const NdisMediumFddi: NDIS_MEDIUM = 2i32;
pub const NdisMediumIP: NDIS_MEDIUM = 19i32;
pub const NdisMediumInfiniBand: NDIS_MEDIUM = 14i32;
pub const NdisMediumIrda: NDIS_MEDIUM = 10i32;
pub const NdisMediumLocalTalk: NDIS_MEDIUM = 4i32;
pub const NdisMediumLoopback: NDIS_MEDIUM = 17i32;
pub const NdisMediumMax: NDIS_MEDIUM = 20i32;
pub const NdisMediumNative802_11: NDIS_MEDIUM = 16i32;
pub const NdisMediumTunnel: NDIS_MEDIUM = 15i32;
pub const NdisMediumWan: NDIS_MEDIUM = 3i32;
pub const NdisMediumWiMAX: NDIS_MEDIUM = 18i32;
pub const NdisMediumWirelessWan: NDIS_MEDIUM = 9i32;
pub const NdisNetworkChangeFromMediaConnect: NDIS_NETWORK_CHANGE_TYPE = 3i32;
pub const NdisNetworkChangeMax: NDIS_NETWORK_CHANGE_TYPE = 4i32;
pub const NdisParameterBinary: NDIS_PARAMETER_TYPE = 4i32;
pub const NdisParameterHexInteger: NDIS_PARAMETER_TYPE = 1i32;
pub const NdisParameterInteger: NDIS_PARAMETER_TYPE = 0i32;
pub const NdisParameterMultiString: NDIS_PARAMETER_TYPE = 3i32;
pub const NdisParameterString: NDIS_PARAMETER_TYPE = 2i32;
pub const NdisPauseFunctionsReceiveOnly: NDIS_SUPPORTED_PAUSE_FUNCTIONS = 2i32;
pub const NdisPauseFunctionsSendAndReceive: NDIS_SUPPORTED_PAUSE_FUNCTIONS = 3i32;
pub const NdisPauseFunctionsSendOnly: NDIS_SUPPORTED_PAUSE_FUNCTIONS = 1i32;
pub const NdisPauseFunctionsUnknown: NDIS_SUPPORTED_PAUSE_FUNCTIONS = 4i32;
pub const NdisPauseFunctionsUnsupported: NDIS_SUPPORTED_PAUSE_FUNCTIONS = 0i32;
pub const NdisPhysicalMedium1394: NDIS_PHYSICAL_MEDIUM = 7i32;
pub const NdisPhysicalMedium802_3: NDIS_PHYSICAL_MEDIUM = 14i32;
pub const NdisPhysicalMedium802_5: NDIS_PHYSICAL_MEDIUM = 15i32;
pub const NdisPhysicalMediumBluetooth: NDIS_PHYSICAL_MEDIUM = 10i32;
pub const NdisPhysicalMediumCableModem: NDIS_PHYSICAL_MEDIUM = 2i32;
pub const NdisPhysicalMediumDSL: NDIS_PHYSICAL_MEDIUM = 5i32;
pub const NdisPhysicalMediumFibreChannel: NDIS_PHYSICAL_MEDIUM = 6i32;
pub const NdisPhysicalMediumInfiniband: NDIS_PHYSICAL_MEDIUM = 11i32;
pub const NdisPhysicalMediumIrda: NDIS_PHYSICAL_MEDIUM = 16i32;
pub const NdisPhysicalMediumMax: NDIS_PHYSICAL_MEDIUM = 21i32;
pub const NdisPhysicalMediumNative802_11: NDIS_PHYSICAL_MEDIUM = 9i32;
pub const NdisPhysicalMediumNative802_15_4: NDIS_PHYSICAL_MEDIUM = 20i32;
pub const NdisPhysicalMediumOther: NDIS_PHYSICAL_MEDIUM = 19i32;
pub const NdisPhysicalMediumPhoneLine: NDIS_PHYSICAL_MEDIUM = 3i32;
pub const NdisPhysicalMediumPowerLine: NDIS_PHYSICAL_MEDIUM = 4i32;
pub const NdisPhysicalMediumUWB: NDIS_PHYSICAL_MEDIUM = 13i32;
pub const NdisPhysicalMediumUnspecified: NDIS_PHYSICAL_MEDIUM = 0i32;
pub const NdisPhysicalMediumWiMax: NDIS_PHYSICAL_MEDIUM = 12i32;
pub const NdisPhysicalMediumWiredCoWan: NDIS_PHYSICAL_MEDIUM = 18i32;
pub const NdisPhysicalMediumWiredWAN: NDIS_PHYSICAL_MEDIUM = 17i32;
pub const NdisPhysicalMediumWirelessLan: NDIS_PHYSICAL_MEDIUM = 1i32;
pub const NdisPhysicalMediumWirelessWan: NDIS_PHYSICAL_MEDIUM = 8i32;
pub const NdisPortAuthorizationUnknown: NDIS_PORT_AUTHORIZATION_STATE = 0i32;
pub const NdisPortAuthorized: NDIS_PORT_AUTHORIZATION_STATE = 1i32;
pub const NdisPortControlStateControlled: NDIS_PORT_CONTROL_STATE = 1i32;
pub const NdisPortControlStateUncontrolled: NDIS_PORT_CONTROL_STATE = 2i32;
pub const NdisPortControlStateUnknown: NDIS_PORT_CONTROL_STATE = 0i32;
pub const NdisPortReauthorizing: NDIS_PORT_AUTHORIZATION_STATE = 3i32;
pub const NdisPortType8021xSupplicant: NDIS_PORT_TYPE = 3i32;
pub const NdisPortTypeBridge: NDIS_PORT_TYPE = 1i32;
pub const NdisPortTypeMax: NDIS_PORT_TYPE = 4i32;
pub const NdisPortTypeRasConnection: NDIS_PORT_TYPE = 2i32;
pub const NdisPortTypeUndefined: NDIS_PORT_TYPE = 0i32;
pub const NdisPortUnauthorized: NDIS_PORT_AUTHORIZATION_STATE = 2i32;
pub const NdisPossibleNetworkChange: NDIS_NETWORK_CHANGE_TYPE = 1i32;
pub const NdisPowerProfileAcOnLine: NDIS_POWER_PROFILE = 1i32;
pub const NdisPowerProfileBattery: NDIS_POWER_PROFILE = 0i32;
pub const NdisProcessorAlpha: NDIS_PROCESSOR_TYPE = 2i32;
pub const NdisProcessorAmd64: NDIS_PROCESSOR_TYPE = 4i32;
pub const NdisProcessorArm: NDIS_PROCESSOR_TYPE = 6i32;
pub const NdisProcessorArm64: NDIS_PROCESSOR_TYPE = 7i32;
pub const NdisProcessorIA64: NDIS_PROCESSOR_TYPE = 5i32;
pub const NdisProcessorMips: NDIS_PROCESSOR_TYPE = 1i32;
pub const NdisProcessorPpc: NDIS_PROCESSOR_TYPE = 3i32;
pub const NdisProcessorVendorAuthenticAMD: NDIS_PROCESSOR_VENDOR = 2i32;
pub const NdisProcessorVendorGenuinIntel: NDIS_PROCESSOR_VENDOR = 1i32;
pub const NdisProcessorVendorGenuineIntel: NDIS_PROCESSOR_VENDOR = 1i32;
pub const NdisProcessorVendorUnknown: NDIS_PROCESSOR_VENDOR = 0i32;
pub const NdisProcessorX86: NDIS_PROCESSOR_TYPE = 0i32;
pub const NdisRequestClose: NDIS_REQUEST_TYPE = 4i32;
pub const NdisRequestGeneric1: NDIS_REQUEST_TYPE = 8i32;
pub const NdisRequestGeneric2: NDIS_REQUEST_TYPE = 9i32;
pub const NdisRequestGeneric3: NDIS_REQUEST_TYPE = 10i32;
pub const NdisRequestGeneric4: NDIS_REQUEST_TYPE = 11i32;
pub const NdisRequestOpen: NDIS_REQUEST_TYPE = 3i32;
pub const NdisRequestQueryInformation: NDIS_REQUEST_TYPE = 0i32;
pub const NdisRequestQueryStatistics: NDIS_REQUEST_TYPE = 2i32;
pub const NdisRequestReset: NDIS_REQUEST_TYPE = 7i32;
pub const NdisRequestSend: NDIS_REQUEST_TYPE = 5i32;
pub const NdisRequestSetInformation: NDIS_REQUEST_TYPE = 1i32;
pub const NdisRequestTransferData: NDIS_REQUEST_TYPE = 6i32;
pub const NdisReserved: NDIS_PER_PACKET_INFO = 4i32;
pub const NdisRingStateClosed: NDIS_802_5_RING_STATE = 2i32;
pub const NdisRingStateClosing: NDIS_802_5_RING_STATE = 4i32;
pub const NdisRingStateOpenFailure: NDIS_802_5_RING_STATE = 5i32;
pub const NdisRingStateOpened: NDIS_802_5_RING_STATE = 1i32;
pub const NdisRingStateOpening: NDIS_802_5_RING_STATE = 3i32;
pub const NdisRingStateRingFailure: NDIS_802_5_RING_STATE = 6i32;
pub const NdisWanErrorControl: NDIS_WAN_QUALITY = 1i32;
pub const NdisWanHeaderEthernet: NDIS_WAN_HEADER_FORMAT = 1i32;
pub const NdisWanHeaderNative: NDIS_WAN_HEADER_FORMAT = 0i32;
pub const NdisWanMediumAgileVPN: NDIS_WAN_MEDIUM_SUBTYPE = 14i32;
pub const NdisWanMediumAtm: NDIS_WAN_MEDIUM_SUBTYPE = 5i32;
pub const NdisWanMediumFrameRelay: NDIS_WAN_MEDIUM_SUBTYPE = 4i32;
pub const NdisWanMediumGre: NDIS_WAN_MEDIUM_SUBTYPE = 15i32;
pub const NdisWanMediumHub: NDIS_WAN_MEDIUM_SUBTYPE = 0i32;
pub const NdisWanMediumIrda: NDIS_WAN_MEDIUM_SUBTYPE = 10i32;
pub const NdisWanMediumIsdn: NDIS_WAN_MEDIUM_SUBTYPE = 2i32;
pub const NdisWanMediumL2TP: NDIS_WAN_MEDIUM_SUBTYPE = 9i32;
pub const NdisWanMediumPPTP: NDIS_WAN_MEDIUM_SUBTYPE = 8i32;
pub const NdisWanMediumParallel: NDIS_WAN_MEDIUM_SUBTYPE = 11i32;
pub const NdisWanMediumPppoe: NDIS_WAN_MEDIUM_SUBTYPE = 12i32;
pub const NdisWanMediumSSTP: NDIS_WAN_MEDIUM_SUBTYPE = 13i32;
pub const NdisWanMediumSW56K: NDIS_WAN_MEDIUM_SUBTYPE = 7i32;
pub const NdisWanMediumSerial: NDIS_WAN_MEDIUM_SUBTYPE = 3i32;
pub const NdisWanMediumSonet: NDIS_WAN_MEDIUM_SUBTYPE = 6i32;
pub const NdisWanMediumSubTypeMax: NDIS_WAN_MEDIUM_SUBTYPE = 16i32;
pub const NdisWanMediumX_25: NDIS_WAN_MEDIUM_SUBTYPE = 1i32;
pub const NdisWanRaw: NDIS_WAN_QUALITY = 0i32;
pub const NdisWanReliable: NDIS_WAN_QUALITY = 2i32;
pub const OFFLOAD_INBOUND_SA: u32 = 1u32;
pub const OFFLOAD_IPSEC_CONF_3_DES: OFFLOAD_CONF_ALGO = 3i32;
pub const OFFLOAD_IPSEC_CONF_DES: OFFLOAD_CONF_ALGO = 1i32;
pub const OFFLOAD_IPSEC_CONF_MAX: OFFLOAD_CONF_ALGO = 4i32;
pub const OFFLOAD_IPSEC_CONF_NONE: OFFLOAD_CONF_ALGO = 0i32;
pub const OFFLOAD_IPSEC_CONF_RESERVED: OFFLOAD_CONF_ALGO = 2i32;
pub const OFFLOAD_IPSEC_INTEGRITY_MAX: OFFLOAD_INTEGRITY_ALGO = 3i32;
pub const OFFLOAD_IPSEC_INTEGRITY_MD5: OFFLOAD_INTEGRITY_ALGO = 1i32;
pub const OFFLOAD_IPSEC_INTEGRITY_NONE: OFFLOAD_INTEGRITY_ALGO = 0i32;
pub const OFFLOAD_IPSEC_INTEGRITY_SHA: OFFLOAD_INTEGRITY_ALGO = 2i32;
pub const OFFLOAD_IPSEC_UDPESP_ENCAPTYPE_IKE: UDP_ENCAP_TYPE = 0i32;
pub const OFFLOAD_IPSEC_UDPESP_ENCAPTYPE_OTHER: UDP_ENCAP_TYPE = 1i32;
pub const OFFLOAD_MAX_SAS: u32 = 3u32;
pub const OFFLOAD_OUTBOUND_SA: u32 = 2u32;
pub const OID_1394_LOCAL_NODE_INFO: u32 = 201392385u32;
pub const OID_1394_VC_INFO: u32 = 201392386u32;
pub const OID_802_11_ADD_KEY: u32 = 218169629u32;
pub const OID_802_11_ADD_WEP: u32 = 218169619u32;
pub const OID_802_11_ASSOCIATION_INFORMATION: u32 = 218169631u32;
pub const OID_802_11_AUTHENTICATION_MODE: u32 = 218169624u32;
pub const OID_802_11_BSSID: u32 = 218169601u32;
pub const OID_802_11_BSSID_LIST: u32 = 218169879u32;
pub const OID_802_11_BSSID_LIST_SCAN: u32 = 218169626u32;
pub const OID_802_11_CAPABILITY: u32 = 218169634u32;
pub const OID_802_11_CONFIGURATION: u32 = 218169873u32;
pub const OID_802_11_DESIRED_RATES: u32 = 218169872u32;
pub const OID_802_11_DISASSOCIATE: u32 = 218169621u32;
pub const OID_802_11_ENCRYPTION_STATUS: u32 = 218169627u32;
pub const OID_802_11_FRAGMENTATION_THRESHOLD: u32 = 218169865u32;
pub const OID_802_11_INFRASTRUCTURE_MODE: u32 = 218169608u32;
pub const OID_802_11_MEDIA_STREAM_MODE: u32 = 218169633u32;
pub const OID_802_11_NETWORK_TYPES_SUPPORTED: u32 = 218169859u32;
pub const OID_802_11_NETWORK_TYPE_IN_USE: u32 = 218169860u32;
pub const OID_802_11_NON_BCAST_SSID_LIST: u32 = 218169636u32;
pub const OID_802_11_NUMBER_OF_ANTENNAS: u32 = 218169867u32;
pub const OID_802_11_PMKID: u32 = 218169635u32;
pub const OID_802_11_POWER_MODE: u32 = 218169878u32;
pub const OID_802_11_PRIVACY_FILTER: u32 = 218169625u32;
pub const OID_802_11_RADIO_STATUS: u32 = 218169637u32;
pub const OID_802_11_RELOAD_DEFAULTS: u32 = 218169628u32;
pub const OID_802_11_REMOVE_KEY: u32 = 218169630u32;
pub const OID_802_11_REMOVE_WEP: u32 = 218169620u32;
pub const OID_802_11_RSSI: u32 = 218169862u32;
pub const OID_802_11_RSSI_TRIGGER: u32 = 218169863u32;
pub const OID_802_11_RTS_THRESHOLD: u32 = 218169866u32;
pub const OID_802_11_RX_ANTENNA_SELECTED: u32 = 218169868u32;
pub const OID_802_11_SSID: u32 = 218169602u32;
pub const OID_802_11_STATISTICS: u32 = 218235410u32;
pub const OID_802_11_SUPPORTED_RATES: u32 = 218169870u32;
pub const OID_802_11_TEST: u32 = 218169632u32;
pub const OID_802_11_TX_ANTENNA_SELECTED: u32 = 218169869u32;
pub const OID_802_11_TX_POWER_LEVEL: u32 = 218169861u32;
pub const OID_802_11_WEP_STATUS: u32 = 218169627u32;
pub const OID_802_3_ADD_MULTICAST_ADDRESS: u32 = 16843272u32;
pub const OID_802_3_CURRENT_ADDRESS: u32 = 16843010u32;
pub const OID_802_3_DELETE_MULTICAST_ADDRESS: u32 = 16843273u32;
pub const OID_802_3_MAC_OPTIONS: u32 = 16843013u32;
pub const OID_802_3_MAXIMUM_LIST_SIZE: u32 = 16843012u32;
pub const OID_802_3_MULTICAST_LIST: u32 = 16843011u32;
pub const OID_802_3_PERMANENT_ADDRESS: u32 = 16843009u32;
pub const OID_802_3_RCV_ERROR_ALIGNMENT: u32 = 16908545u32;
pub const OID_802_3_RCV_OVERRUN: u32 = 16908803u32;
pub const OID_802_3_XMIT_DEFERRED: u32 = 16908801u32;
pub const OID_802_3_XMIT_HEARTBEAT_FAILURE: u32 = 16908805u32;
pub const OID_802_3_XMIT_LATE_COLLISIONS: u32 = 16908807u32;
pub const OID_802_3_XMIT_MAX_COLLISIONS: u32 = 16908802u32;
pub const OID_802_3_XMIT_MORE_COLLISIONS: u32 = 16908547u32;
pub const OID_802_3_XMIT_ONE_COLLISION: u32 = 16908546u32;
pub const OID_802_3_XMIT_TIMES_CRS_LOST: u32 = 16908806u32;
pub const OID_802_3_XMIT_UNDERRUN: u32 = 16908804u32;
pub const OID_802_5_ABORT_DELIMETERS: u32 = 33686019u32;
pub const OID_802_5_AC_ERRORS: u32 = 33686018u32;
pub const OID_802_5_BURST_ERRORS: u32 = 33686017u32;
pub const OID_802_5_CURRENT_ADDRESS: u32 = 33620226u32;
pub const OID_802_5_CURRENT_FUNCTIONAL: u32 = 33620227u32;
pub const OID_802_5_CURRENT_GROUP: u32 = 33620228u32;
pub const OID_802_5_CURRENT_RING_STATE: u32 = 33620231u32;
pub const OID_802_5_CURRENT_RING_STATUS: u32 = 33620230u32;
pub const OID_802_5_FRAME_COPIED_ERRORS: u32 = 33686020u32;
pub const OID_802_5_FREQUENCY_ERRORS: u32 = 33686021u32;
pub const OID_802_5_INTERNAL_ERRORS: u32 = 33686023u32;
pub const OID_802_5_LAST_OPEN_STATUS: u32 = 33620229u32;
pub const OID_802_5_LINE_ERRORS: u32 = 33685761u32;
pub const OID_802_5_LOST_FRAMES: u32 = 33685762u32;
pub const OID_802_5_PERMANENT_ADDRESS: u32 = 33620225u32;
pub const OID_802_5_TOKEN_ERRORS: u32 = 33686022u32;
pub const OID_ARCNET_CURRENT_ADDRESS: u32 = 100729090u32;
pub const OID_ARCNET_PERMANENT_ADDRESS: u32 = 100729089u32;
pub const OID_ARCNET_RECONFIGURATIONS: u32 = 100794881u32;
pub const OID_ATM_ACQUIRE_ACCESS_NET_RESOURCES: u32 = 134283779u32;
pub const OID_ATM_ALIGNMENT_REQUIRED: u32 = 134283784u32;
pub const OID_ATM_ASSIGNED_VPI: u32 = 134283778u32;
pub const OID_ATM_CALL_ALERTING: u32 = 134283788u32;
pub const OID_ATM_CALL_NOTIFY: u32 = 134283790u32;
pub const OID_ATM_CALL_PROCEEDING: u32 = 134283787u32;
pub const OID_ATM_CELLS_HEC_ERROR: u32 = 134349314u32;
pub const OID_ATM_DIGITAL_BROADCAST_VPIVCI: u32 = 134283782u32;
pub const OID_ATM_GET_NEAREST_FLOW: u32 = 134283783u32;
pub const OID_ATM_HW_CURRENT_ADDRESS: u32 = 134283524u32;
pub const OID_ATM_ILMI_VPIVCI: u32 = 134283781u32;
pub const OID_ATM_LECS_ADDRESS: u32 = 134283785u32;
pub const OID_ATM_MAX_AAL0_PACKET_SIZE: u32 = 134283528u32;
pub const OID_ATM_MAX_AAL1_PACKET_SIZE: u32 = 134283529u32;
pub const OID_ATM_MAX_AAL34_PACKET_SIZE: u32 = 134283530u32;
pub const OID_ATM_MAX_AAL5_PACKET_SIZE: u32 = 134283531u32;
pub const OID_ATM_MAX_ACTIVE_VCI_BITS: u32 = 134283526u32;
pub const OID_ATM_MAX_ACTIVE_VCS: u32 = 134283525u32;
pub const OID_ATM_MAX_ACTIVE_VPI_BITS: u32 = 134283527u32;
pub const OID_ATM_MY_IP_NM_ADDRESS: u32 = 134283791u32;
pub const OID_ATM_PARTY_ALERTING: u32 = 134283789u32;
pub const OID_ATM_RCV_CELLS_DROPPED: u32 = 134349059u32;
pub const OID_ATM_RCV_CELLS_OK: u32 = 134349057u32;
pub const OID_ATM_RCV_INVALID_VPI_VCI: u32 = 134349313u32;
pub const OID_ATM_RCV_REASSEMBLY_ERROR: u32 = 134349315u32;
pub const OID_ATM_RELEASE_ACCESS_NET_RESOURCES: u32 = 134283780u32;
pub const OID_ATM_SERVICE_ADDRESS: u32 = 134283786u32;
pub const OID_ATM_SIGNALING_VPIVCI: u32 = 134283777u32;
pub const OID_ATM_SUPPORTED_AAL_TYPES: u32 = 134283523u32;
pub const OID_ATM_SUPPORTED_SERVICE_CATEGORY: u32 = 134283522u32;
pub const OID_ATM_SUPPORTED_VC_RATES: u32 = 134283521u32;
pub const OID_ATM_XMIT_CELLS_OK: u32 = 134349058u32;
pub const OID_CO_ADDRESS_CHANGE: u32 = 4261412871u32;
pub const OID_CO_ADD_ADDRESS: u32 = 4261412868u32;
pub const OID_CO_ADD_PVC: u32 = 4261412865u32;
pub const OID_CO_AF_CLOSE: u32 = 4261412874u32;
pub const OID_CO_DELETE_ADDRESS: u32 = 4261412869u32;
pub const OID_CO_DELETE_PVC: u32 = 4261412866u32;
pub const OID_CO_GET_ADDRESSES: u32 = 4261412870u32;
pub const OID_CO_GET_CALL_INFORMATION: u32 = 4261412867u32;
pub const OID_CO_SIGNALING_DISABLED: u32 = 4261412873u32;
pub const OID_CO_SIGNALING_ENABLED: u32 = 4261412872u32;
pub const OID_CO_TAPI_ADDRESS_CAPS: u32 = 4261416963u32;
pub const OID_CO_TAPI_CM_CAPS: u32 = 4261416961u32;
pub const OID_CO_TAPI_DONT_REPORT_DIGITS: u32 = 4261416969u32;
pub const OID_CO_TAPI_GET_CALL_DIAGNOSTICS: u32 = 4261416967u32;
pub const OID_CO_TAPI_LINE_CAPS: u32 = 4261416962u32;
pub const OID_CO_TAPI_REPORT_DIGITS: u32 = 4261416968u32;
pub const OID_CO_TAPI_TRANSLATE_NDIS_CALLPARAMS: u32 = 4261416965u32;
pub const OID_CO_TAPI_TRANSLATE_TAPI_CALLPARAMS: u32 = 4261416964u32;
pub const OID_CO_TAPI_TRANSLATE_TAPI_SAP: u32 = 4261416966u32;
pub const OID_FDDI_ATTACHMENT_TYPE: u32 = 50462977u32;
pub const OID_FDDI_DOWNSTREAM_NODE_LONG: u32 = 50462979u32;
pub const OID_FDDI_FRAMES_LOST: u32 = 50462981u32;
pub const OID_FDDI_FRAME_ERRORS: u32 = 50462980u32;
pub const OID_FDDI_IF_ADMIN_STATUS: u32 = 50528894u32;
pub const OID_FDDI_IF_DESCR: u32 = 50528889u32;
pub const OID_FDDI_IF_IN_DISCARDS: u32 = 50528900u32;
pub const OID_FDDI_IF_IN_ERRORS: u32 = 50528901u32;
pub const OID_FDDI_IF_IN_NUCAST_PKTS: u32 = 50528899u32;
pub const OID_FDDI_IF_IN_OCTETS: u32 = 50528897u32;
pub const OID_FDDI_IF_IN_UCAST_PKTS: u32 = 50528898u32;
pub const OID_FDDI_IF_IN_UNKNOWN_PROTOS: u32 = 50528902u32;
pub const OID_FDDI_IF_LAST_CHANGE: u32 = 50528896u32;
pub const OID_FDDI_IF_MTU: u32 = 50528891u32;
pub const OID_FDDI_IF_OPER_STATUS: u32 = 50528895u32;
pub const OID_FDDI_IF_OUT_DISCARDS: u32 = 50528906u32;
pub const OID_FDDI_IF_OUT_ERRORS: u32 = 50528907u32;
pub const OID_FDDI_IF_OUT_NUCAST_PKTS: u32 = 50528905u32;
pub const OID_FDDI_IF_OUT_OCTETS: u32 = 50528903u32;
pub const OID_FDDI_IF_OUT_QLEN: u32 = 50528908u32;
pub const OID_FDDI_IF_OUT_UCAST_PKTS: u32 = 50528904u32;
pub const OID_FDDI_IF_PHYS_ADDRESS: u32 = 50528893u32;
pub const OID_FDDI_IF_SPECIFIC: u32 = 50528909u32;
pub const OID_FDDI_IF_SPEED: u32 = 50528892u32;
pub const OID_FDDI_IF_TYPE: u32 = 50528890u32;
pub const OID_FDDI_LCONNECTION_STATE: u32 = 50462985u32;
pub const OID_FDDI_LCT_FAILURES: u32 = 50462983u32;
pub const OID_FDDI_LEM_REJECTS: u32 = 50462984u32;
pub const OID_FDDI_LONG_CURRENT_ADDR: u32 = 50397442u32;
pub const OID_FDDI_LONG_MAX_LIST_SIZE: u32 = 50397444u32;
pub const OID_FDDI_LONG_MULTICAST_LIST: u32 = 50397443u32;
pub const OID_FDDI_LONG_PERMANENT_ADDR: u32 = 50397441u32;
pub const OID_FDDI_MAC_AVAILABLE_PATHS: u32 = 50528803u32;
pub const OID_FDDI_MAC_BRIDGE_FUNCTIONS: u32 = 50528800u32;
pub const OID_FDDI_MAC_COPIED_CT: u32 = 50528828u32;
pub const OID_FDDI_MAC_CURRENT_PATH: u32 = 50528804u32;
pub const OID_FDDI_MAC_DA_FLAG: u32 = 50528842u32;
pub const OID_FDDI_MAC_DOWNSTREAM_NBR: u32 = 50528806u32;
pub const OID_FDDI_MAC_DOWNSTREAM_PORT_TYPE: u32 = 50528811u32;
pub const OID_FDDI_MAC_DUP_ADDRESS_TEST: u32 = 50528809u32;
pub const OID_FDDI_MAC_ERROR_CT: u32 = 50528831u32;
pub const OID_FDDI_MAC_FRAME_CT: u32 = 50528827u32;
pub const OID_FDDI_MAC_FRAME_ERROR_FLAG: u32 = 50528844u32;
pub const OID_FDDI_MAC_FRAME_ERROR_RATIO: u32 = 50528838u32;
pub const OID_FDDI_MAC_FRAME_ERROR_THRESHOLD: u32 = 50528837u32;
pub const OID_FDDI_MAC_FRAME_STATUS_FUNCTIONS: u32 = 50528799u32;
pub const OID_FDDI_MAC_HARDWARE_PRESENT: u32 = 50528847u32;
pub const OID_FDDI_MAC_INDEX: u32 = 50528812u32;
pub const OID_FDDI_MAC_LATE_CT: u32 = 50528835u32;
pub const OID_FDDI_MAC_LONG_GRP_ADDRESS: u32 = 50528814u32;
pub const OID_FDDI_MAC_LOST_CT: u32 = 50528832u32;
pub const OID_FDDI_MAC_MA_UNITDATA_AVAILABLE: u32 = 50528846u32;
pub const OID_FDDI_MAC_MA_UNITDATA_ENABLE: u32 = 50528848u32;
pub const OID_FDDI_MAC_NOT_COPIED_CT: u32 = 50528834u32;
pub const OID_FDDI_MAC_NOT_COPIED_FLAG: u32 = 50528845u32;
pub const OID_FDDI_MAC_NOT_COPIED_RATIO: u32 = 50528840u32;
pub const OID_FDDI_MAC_NOT_COPIED_THRESHOLD: u32 = 50528839u32;
pub const OID_FDDI_MAC_OLD_DOWNSTREAM_NBR: u32 = 50528808u32;
pub const OID_FDDI_MAC_OLD_UPSTREAM_NBR: u32 = 50528807u32;
pub const OID_FDDI_MAC_REQUESTED_PATHS: u32 = 50528810u32;
pub const OID_FDDI_MAC_RING_OP_CT: u32 = 50528836u32;
pub const OID_FDDI_MAC_RMT_STATE: u32 = 50528841u32;
pub const OID_FDDI_MAC_SHORT_GRP_ADDRESS: u32 = 50528815u32;
pub const OID_FDDI_MAC_SMT_ADDRESS: u32 = 50528813u32;
pub const OID_FDDI_MAC_TOKEN_CT: u32 = 50528830u32;
pub const OID_FDDI_MAC_TRANSMIT_CT: u32 = 50528829u32;
pub const OID_FDDI_MAC_TVX_CAPABILITY: u32 = 50528802u32;
pub const OID_FDDI_MAC_TVX_EXPIRED_CT: u32 = 50528833u32;
pub const OID_FDDI_MAC_TVX_VALUE: u32 = 50528819u32;
pub const OID_FDDI_MAC_T_MAX: u32 = 50528818u32;
pub const OID_FDDI_MAC_T_MAX_CAPABILITY: u32 = 50528801u32;
pub const OID_FDDI_MAC_T_NEG: u32 = 50528817u32;
pub const OID_FDDI_MAC_T_PRI0: u32 = 50528820u32;
pub const OID_FDDI_MAC_T_PRI1: u32 = 50528821u32;
pub const OID_FDDI_MAC_T_PRI2: u32 = 50528822u32;
pub const OID_FDDI_MAC_T_PRI3: u32 = 50528823u32;
pub const OID_FDDI_MAC_T_PRI4: u32 = 50528824u32;
pub const OID_FDDI_MAC_T_PRI5: u32 = 50528825u32;
pub const OID_FDDI_MAC_T_PRI6: u32 = 50528826u32;
pub const OID_FDDI_MAC_T_REQ: u32 = 50528816u32;
pub const OID_FDDI_MAC_UNDA_FLAG: u32 = 50528843u32;
pub const OID_FDDI_MAC_UPSTREAM_NBR: u32 = 50528805u32;
pub const OID_FDDI_PATH_CONFIGURATION: u32 = 50528854u32;
pub const OID_FDDI_PATH_INDEX: u32 = 50528849u32;
pub const OID_FDDI_PATH_MAX_T_REQ: u32 = 50528859u32;
pub const OID_FDDI_PATH_RING_LATENCY: u32 = 50528850u32;
pub const OID_FDDI_PATH_SBA_AVAILABLE: u32 = 50528856u32;
pub const OID_FDDI_PATH_SBA_OVERHEAD: u32 = 50528853u32;
pub const OID_FDDI_PATH_SBA_PAYLOAD: u32 = 50528852u32;
pub const OID_FDDI_PATH_TRACE_STATUS: u32 = 50528851u32;
pub const OID_FDDI_PATH_TVX_LOWER_BOUND: u32 = 50528857u32;
pub const OID_FDDI_PATH_T_MAX_LOWER_BOUND: u32 = 50528858u32;
pub const OID_FDDI_PATH_T_R_MODE: u32 = 50528855u32;
pub const OID_FDDI_PORT_ACTION: u32 = 50528888u32;
pub const OID_FDDI_PORT_AVAILABLE_PATHS: u32 = 50528867u32;
pub const OID_FDDI_PORT_BS_FLAG: u32 = 50528873u32;
pub const OID_FDDI_PORT_CONNECTION_CAPABILITIES: u32 = 50528870u32;
pub const OID_FDDI_PORT_CONNECTION_POLICIES: u32 = 50528862u32;
pub const OID_FDDI_PORT_CONNNECT_STATE: u32 = 50528882u32;
pub const OID_FDDI_PORT_CURRENT_PATH: u32 = 50528864u32;
pub const OID_FDDI_PORT_EB_ERROR_CT: u32 = 50528875u32;
pub const OID_FDDI_PORT_HARDWARE_PRESENT: u32 = 50528886u32;
pub const OID_FDDI_PORT_INDEX: u32 = 50528871u32;
pub const OID_FDDI_PORT_LCT_FAIL_CT: u32 = 50528876u32;
pub const OID_FDDI_PORT_LEM_CT: u32 = 50528879u32;
pub const OID_FDDI_PORT_LEM_REJECT_CT: u32 = 50528878u32;
pub const OID_FDDI_PORT_LER_ALARM: u32 = 50528881u32;
pub const OID_FDDI_PORT_LER_CUTOFF: u32 = 50528880u32;
pub const OID_FDDI_PORT_LER_ESTIMATE: u32 = 50528877u32;
pub const OID_FDDI_PORT_LER_FLAG: u32 = 50528885u32;
pub const OID_FDDI_PORT_MAC_INDICATED: u32 = 50528863u32;
pub const OID_FDDI_PORT_MAC_LOOP_TIME: u32 = 50528868u32;
pub const OID_FDDI_PORT_MAC_PLACEMENT: u32 = 50528866u32;
pub const OID_FDDI_PORT_MAINT_LS: u32 = 50528872u32;
pub const OID_FDDI_PORT_MY_TYPE: u32 = 50528860u32;
pub const OID_FDDI_PORT_NEIGHBOR_TYPE: u32 = 50528861u32;
pub const OID_FDDI_PORT_PCM_STATE: u32 = 50528883u32;
pub const OID_FDDI_PORT_PC_LS: u32 = 50528874u32;
pub const OID_FDDI_PORT_PC_WITHHOLD: u32 = 50528884u32;
pub const OID_FDDI_PORT_PMD_CLASS: u32 = 50528869u32;
pub const OID_FDDI_PORT_REQUESTED_PATHS: u32 = 50528865u32;
pub const OID_FDDI_RING_MGT_STATE: u32 = 50462982u32;
pub const OID_FDDI_SHORT_CURRENT_ADDR: u32 = 50397446u32;
pub const OID_FDDI_SHORT_MAX_LIST_SIZE: u32 = 50397448u32;
pub const OID_FDDI_SHORT_MULTICAST_LIST: u32 = 50397447u32;
pub const OID_FDDI_SHORT_PERMANENT_ADDR: u32 = 50397445u32;
pub const OID_FDDI_SMT_AVAILABLE_PATHS: u32 = 50528779u32;
pub const OID_FDDI_SMT_BYPASS_PRESENT: u32 = 50528788u32;
pub const OID_FDDI_SMT_CF_STATE: u32 = 50528790u32;
pub const OID_FDDI_SMT_CONFIG_CAPABILITIES: u32 = 50528780u32;
pub const OID_FDDI_SMT_CONFIG_POLICY: u32 = 50528781u32;
pub const OID_FDDI_SMT_CONNECTION_POLICY: u32 = 50528782u32;
pub const OID_FDDI_SMT_ECM_STATE: u32 = 50528789u32;
pub const OID_FDDI_SMT_HI_VERSION_ID: u32 = 50528771u32;
pub const OID_FDDI_SMT_HOLD_STATE: u32 = 50528791u32;
pub const OID_FDDI_SMT_LAST_SET_STATION_ID: u32 = 50528798u32;
pub const OID_FDDI_SMT_LO_VERSION_ID: u32 = 50528772u32;
pub const OID_FDDI_SMT_MAC_CT: u32 = 50528776u32;
pub const OID_FDDI_SMT_MAC_INDEXES: u32 = 50528787u32;
pub const OID_FDDI_SMT_MANUFACTURER_DATA: u32 = 50528773u32;
pub const OID_FDDI_SMT_MASTER_CT: u32 = 50528778u32;
pub const OID_FDDI_SMT_MIB_VERSION_ID: u32 = 50528775u32;
pub const OID_FDDI_SMT_MSG_TIME_STAMP: u32 = 50528795u32;
pub const OID_FDDI_SMT_NON_MASTER_CT: u32 = 50528777u32;
pub const OID_FDDI_SMT_OP_VERSION_ID: u32 = 50528770u32;
pub const OID_FDDI_SMT_PEER_WRAP_FLAG: u32 = 50528794u32;
pub const OID_FDDI_SMT_PORT_INDEXES: u32 = 50528786u32;
pub const OID_FDDI_SMT_REMOTE_DISCONNECT_FLAG: u32 = 50528792u32;
pub const OID_FDDI_SMT_SET_C_FDoDTGLAG: u32 = 50528792u32;
pub coT_LAST_D_FDDI_PORT_ACTION: uLAG: u32 = 50528792u32;
pub coT_LAST__OP_VERSION_ID: 69AG: u32 = 50528792u32;
pub coT_LAST__PATH_TRACE_STATUS:793AG: u32 = 50528792u32;
pub coT_L_RPTT_CONNECTION_POLICY: u32 = 50528794u32;
pub const OD_FDDI_FDDDDI_MATH_CONFIGURATION:7852 = 50528794u32;
pub const OD_FNSI11_FRADI_SMT_MSG_TIME_STAMP: u32 = 50528786u32;
pub const OTOID_ATM_CALL_NOTION:783AG: u32 = 50528792u32;
pub cUST_MANUFACTURER_DATA: u32 = 50528794u32;
pub conID_FDDI_MADOWNSTREAM_NODE_LONG: u32 = 50528778u32;
pubFMAC_APTD_FDDI_PI_CALLPARA279900u32 = 50528833u32;
pubFMA: NDIS_I_CALLPARA279244932 = 50528778u32;
pubFMAANUFACTURER_RA279245u32 = 50528800u32;
pubFMAARIVD_FDDI_PI_CALLPARA279900u22 = 50528800u32;
pubFMAFLUSHI_CALLPARA279244972 = 50528800u32;
pubFMATE_TAPI_CALLPARA279244992 = 50528800u32;
pubFMAnst OIDI_CALLPARA279244932 = 50528786u32;
puGEN OID_FDDI_IF_ADMIN_ST661u32 = 50528794u32;
puGEN OLIA_ADMIN_ST661u52 = 50528794u32;
puGEN ATM_DIGITABYTESonstMIT_CELLS_15952 = 50528794u32;
puGEN ATM_DIGITABYTESonst MIT_CELLS_15u32 = 50528789u32;
puGEN ATM_DIGITAst OID_nstMIT_CELLS_15962 = 50528789u32;
puGEN ATM_DIGITAst OID_nst MIT_CELLS_15u32 = 50528790u32;
puGEN AYTESonstMIT_CELLS_16092 = 50528790u32;
puGEN AYTESonst MIT_CELLS_16132 = 50528790u32;
puGEN COABYTESonstMIT_CELLS_15912 = 50528790u32;
puGEN COABYTESonst MIT_CELLS_15u52 = 50528790u32;
puGEN COABYTESonst  OIDDI_N_CALL_PROCEEDI16172 = 50528790u32;
puGEN COAified: NNDIS_PMIT_CELLS_16022 = 50528790u32;
puGEN COAiRIVD_FFDDI_SMADMIN_ST65 u32 = 50528808u32;
puGEN COAnst OITI_IFORT_MAC_LOOP_S_16002 = 50528808u32;
puGEN COAnst ADI_SO_TAPI_LINE_S_15992 = 50528808u32;
puGEN COAReset: NDIS_HARADMIN_ST65 u32 = 50528794u32;
puGEN COALINK OID_FDDI_IF_S65 u92 = 50528808u32;
puGEN COAt OID_802_3_MAC_OPT65 112 = 50528790u32;
puGEN COA OID_8T_REMOTEIS_HARADMIN_ST65 u32 = 50528812u32;
puGEN COA OID_8ETWORK_TYPE_IN65 u62 = 50528812u32;
puGEN COA OID_8TWORK_TYPES_SUPPO65 u52 = 50528790u32;
puGEN COAD_FID_802_NK OID_FDDI_IF_SS_13602 = 50528808u32;
puGEN COAOITI_IFOPATH_SBA_PAYS_16012 = 50528790u32;
puGEN COA_IN_UCOLID_802_3_MAC_OPT65 102 = 50528808u32;
puGEN COAnst ORATM_CELLS_HEC_ERR15972 = 50528808u32;
puGEN COAnst PDUSTM_CELLS_HEC_ERR13322 = 50528808u32;
puGEN COAnst PDUSTNOABUFFELLS_HEC_ERR13332 = 50528808u32;
puGEN COAnst PDUST_XMIT_CELLS_13302 = 50528808u32;
puGEN COAnst OID_ATGUID3_MAC_OPT65 152 = 50528808u32;
puGEN COAnst OID_ATT_MULTICAST_65 u32 = 50528808u32;
puGEN COAID_FDDI_MQUEUWNSENGT_CURRENT_RR15932 = 50528808u32;
puGEN COAS_PROC OID_FIPT_SMADMIN_ST65 u52 = 50528808u32;
puGEN COAS_PROC ORIVD_FFDDI_SMADMIN_ST65 142 = 50528808u32;
puGEN COAS_PROC IDADMIN_ST65 u42 = 50528808u32;
puGEN COAnst  PDUSTM_CELLS_HEC_ERR13312 = 50528808u32;
puGEN COAnst  PDUST_XMIT_CELLS_13292 = 50528808u32;
puGEN CFDDI_SHLOOKAATH_SBA_OVER65 u72 = 50528808u32;
puGEN CFDDI_SHTM_MAX__11_PRIVACY_FI65 u62 = 50528812u32;
puGEN ified: NNDIS_PMIT_CELLS_16022 = 50528790u32;
puGEN DIR_ANTEABYTESonstMIT_CELLS_15912 = 50528790u32;
puGEN DIR_ANTEABYTESonst MIT_CELLS_15u52 = 50528790u32;
puGEN DIR_ANTEAst OID_nstMIT_CELLS_15922 = 50528790u32;
puGEN DIR_ANTEAst OID_nst MIT_CELLS_15u62 = 50528812u32;
puGEN iSMT_RTINUFLOART_MAC_LOOP_661732 = 50528808u32;
puGEN iRIVD_FFDDI_SMADMIN_ST65 u32 = 50528808u32;
puGEN ENUMNTEREOID_F_ADMIN_ST660612 = 50528790u32;
puGEN FRI_PRLY_NA_MAC_LOOP_S_16062 = 50528812u32;
puGEN nst OITI_IFORT_MAC_LOOP_S_16002 = 50528808u32;
puGEN nst ADI_SO_TAPI_LINE_S_15992 = 50528808u32;
puGEN Reset: NDIS_HARADMIN_ST65 u32 = 50528794u32;
puGEN HD OILIID_FDDI_SHID_FDDADMIN_ST660802 = 50528794u32;
puGEN HD OILIIDtring: ND_ADMIN_ST660732 = 50528808u32;
puGEN _FIt ADI_SMSAC_LOOP_S_16032 = 50528808u32;
puGEN _Fype: NDIOID_1394_VC_661u32 = 50528808u32;
puGEN _Fype: NDIS_INTERRUPADMIN_ST660572 = 50528808u32;
puGEN IP OID_FDDI_IF_OPER_ST661u92 = 50528808u32;
puGEN ISOL_LAST_tring: ND_ADMIN_ST663u42 = 50528808u32;
puGEN OID_FDDI_IF_LAST_CH661772 = 50528808u32;
puGEN 2_NK tring: ND_ADMIN_ST660562 = 50528808u32;
puGEN 2_NK OID_FDDI_IF_S65 u92 = 50528808u32;
puGEN 2_NK OID_F_DDI_PORT_I661u72 = 50528808u32;
puGEN 2_NK DI_SMT_HOLD_S660552 = 50528790u32;
puGEN t OHID_CNA_MAC_LOOP_660742 = 50528790u32;
puGEN t OFDDI_MAC_SMT_ADD660532 = 50528790u32;
puGEN t OFD_802_3_MAC_OPT65 112 = 50528790u32;
puGEN t OID_80ID_FDDIT_MAX_LIST_65 u82 = 50528790u32;
puGEN t OID_80LOOKAATH_SBA_OVER657972 = 50528808u32;
puGEN t OID_80S_PRHTM_MAX3_MAC_OPT65 132 = 50528808u32;
puGEN t OID_80TOOID_IT_MAX_LIST_658092 = 50528790u32;
puGEN _FDDI_NK OID_FDDI_IF_S660542 = 50528790u32;
puGEN tOID_8TSMT_CONFIG_CAPABILI660492 = 50528790u32;
puGEN tOID_8T_REMOTEIS_HARADMIN_ST65 u32 = 50528812u32;
puGEN tOID_8T_REMOTEIS_HAR_DDI_PORT_I661u62 = 50528812u32;
puGEN tOID_8DUPLEX DI_SMT_HOLD_S661882 = 50528812u32;
puGEN tOID_8ETWORK_TYPE_IN65 u62 = 50528812u32;
puGEN  OID_8TENSEFDDI_SSAC_LOOP_S_16052 = 50528812u32;
puGEN  OID_8TWORK_TYPES_SUPPO65 u52 = 50528790u32;
puGEN D_FIst OID_DI_ OIDTTRIBUTG_CAPABILI660772 = 50528808u32;
puGEN _FDDI_SHORBYTESonstMIT_CELLS_15932 = 50528808u32;
puGEN _FDDI_SHORBYTESonst MIT_CELLS_15u72 = 50528808u32;
puGEN _FDDI_SHORst OID_nstMIT_CELLS_15942 = 50528808u32;
puGEN _FDDI_SHORst OID_nst MIT_CELLS_15u82 = 50528812u32;
puGEN ansferDPSEC_C_1AC_LOOP_S_16072 = 50528812u32;
puGEN ansferDPSEC_C_2AC_LOOP_S_16082 = 50528812u32;
puGEN ansferDPSEC_C_3DDI_IF_S660582 = 50528812u32;
puGEN ansferDPSEC_C_4DDI_IF_S660592 = 50528812u32;
puGEN ansferDPSEC_C_5ADMIN_ST660602 = 50528812u32;
puGEN ansferDPSEC_C_6ADMIN_ST660662 = 50528812u32;
puGEN ansferDPSEC_C_7L_PROCEEDI16142 = 50528808u32;
puGEN OITI_IFOPATH_SBA_PAYS_16012 = 50528790u32;
puGEN  OID_802LAY_FDDOID_CO_GET_ADDRE65 u62 = 50528812u32;
puGEN OID_ACURRENFDDI_IF_OPER_ST661792 = 50528812u32;
puGEN TM_MAX_MOFItELLS_HEC_E662572 = 50528808u32;
puGEN PCI ified: CUSTOM NNDPATM_G_CAPABILI660652 = 50528790u32;
puGEN ssWan: NDIS_PHYDDI_IF_S660502 = 50528790u32;
puGEN ssWan: NDIS_PHY_DDI_PORT_I660672 = 50528808u32;
puGEN Pized: ND_802_11_AUTtring: ND_ADMIN_ST660632 = 50528808u32;
puGEN PizedDI_SMT_HOLD_S660632 = 50528812u32;
puGEN NNDMSMTUOAR_DI_PATH_T_R_661762 = 50528812u32;
puGEN NND_UCOLID_802_3_MAC_OPT65 102 = 50528808u32;
puGEN nst ORATM_CELLS_HEC_ERR15972 = 50528808u32;
puGEN nst FDDI_IF_OUT_DISCDI16112 = 50528808u32;
puGEN nst M_CELLS_HEC_ERR13322 = 50528808u32;
puGEN nst I_NK OID_FDDI_IF_S661812 = 50528808u32;
puGEN nst NOABUFFELLS_HEC_ERR13332 = 50528808u32;
puGEN t OIDXMIT_CELLS_13302 = 50528808u32;
puGEN R_AE_ATMBLOCK_IT_MAX_LIST_658032 = 50528808u32;
puGEN R_AE_ATMBUFFEL OI NDAX_LIST_658012 = 50528808u32;
puGEN R_AE_ATMHASHI_CALLPA660792 = 50528808u32;
puGEN R_AE_ATMDI_LE8TSMT_CONFIG_CAPABILI660512 = 50528808u32;
puGEN R_AE_ATMDI_LE8tring: ND_ADMIN_ST660522 = 50528808u32;
puGEN R_AE_ATMDI_LE8tring: ND__V2T_HOLD_S660682 = 50528808u32;
puGEN R_ID_FDDI_SSAC_LOOP_S_16042 = 50528808u32;
puGEN RI_TRAND_FDDI_ring: NDI_CALLPA660752 = 50528790u32;
puGEN RSSOID_FDI_PRDDI_SMTTDI_SM_80RIG_CAPABILI662402 = 50528808u32;
puGEN  OID_802_11_STATISS_13342 = 50528808u32;
puGEN nst OID_ATGUID3_MAC_OPT65 152 = 50528808u32;
puGEN nst OID_ATT_MULTICAST_65 u32 = 50528808u32;
puGEN ADI_OID_FP OID_FDDI8TSMT_CONFIG_CAPABILI660642 = 50528808u32;
puGEN ID_FDDI_MBLOCK_IT_MAX_LIST_658022 = 50528808u32;
puGEN ID_FDDI_MBUFFEL OI NDAX_LIST_658002 = 50528808u32;
puGEN ID_FDDI_MQUEUWNSENGT_CURRENT_RR15932 = 50528808u32;
puGEN ID_FDst OID: NDISOFFID__MAC_OPT65 172 = 50528808u32;
puGEN _FDDI_IF_IN_UNKNOWN_PR661822 = 50528808u32;
puGEN S_PROC OID_FIPT_SMADMIN_ST65 u52 = 50528808u32;
puGEN S_PROC ORIVD_FFDDI_SMADMIN_ST65 142 = 50528808u32;
puGEN S_PROC IDADMIN_ST65 u42 = 50528808u32;
puGEN VLAT__OP_VERSIO660762 = 50528812u32;
puGEN t OID_DDI_IF_OUT_DISCDI16122 = 50528812u32;
puGEN t OIDM_CELLS_HEC_ERR13312 = 50528808u32;
puGEN t OID__NK OID_FDDI_IF_S661802 = 50528808u32;
puGEN t OID_XMIT_CELLS_13292 = 50528808u32;
puGFOID_FDVEREOGET_M_80RIG_CAPABILI665752 = 50528790u32;
puGFORT_POGET_M_80RIG_CAPABILI665722 = 50528790u32;
puGFORTLst OTEFDDI_SND_ADMIN_ST665672 = 50528808u32;
puGFTFDDI_SNDFDDI_M_CAPABILI665702 = 50528808u32;
puGFTFDREOTEFLOGn: NDV OIDI_CALLPA665u32 = 50528794u32;
puGFTFDREOTEFTTH_SBA_AVAIL665632 = 50528794u32;
puGFTFDFDDI_SHISMT_CONFIG_CAPABILI665622 = 50528790u32;
puGFORDED_FDVEREOGET_M_80RIG_CAPABILI665762 = 50528790u32;
puGFORDEst OIGET_M_80RIG_CAPABILI665732 = 50528790u32;
puGFORDEst OILOGn: NDV OIDI_CALLPA665u52 = 50528790u32;
puGFORDEst OINNDIS_PMIT_CELL665u22 = 50528790u32;
puGFORDEst OITTH_SBA_AVAIL665652 = 50528790u32;
puGFORENUMFDDI_SND_ADMIN_ST665692 = 50528790u32;
puGFORENUMFGET_M_80RIG_CAPABILI665742 = 50528790u32;
puGFORENUMFLOGn: NDV OID_CAPABILI665862 = 50528790u32;
puGFORENUMFNNDIS_P_CAPABILI665812 = 50528790u32;
puGFORENUMFTTH_S_ADMIN_ST665662 = 50528790u32;
puGFOREXD_F_MATCHINNDIS_PMIT_CELL665732 = 50528808u32;
puGFTFGET_M_80RY8tring: ND_ADMIN_ST665772 = 50528808u32;
puGFTFFREEFDDI_SND_ADMIN_ST665632 = 50528808u32;
puGFTFGLOB NDtring: ND_ADMIN_ST665632 = 50528790u32;
puGFORReset: NDISMT_CONFIG_CAPABILI665612 = 50528790u32;
puGFORD: NDISID_FDstSI11_FRNNDIS_PMIT_CELL665792 = 50528790u32;
puGFOR OID_802_11_STATIS665712 = 50528790u32;
puGFORVst OIDring: ND_ADMIN_ST665832 = 50528790u32;
puGFORWILDI_IFOMATCHINNDIS_PMIT_CELL665802 = 50528808u32;
puIP4_;
pub coDDI_PI_CALLPARA279244u92 = 50528808u32;
puIP6_;
pub coDDI_PI_CALLPARA279244u32 = 50528790u32;
puIRDAREXID_ t OIBOFRE_COLLISIO78382082 = 50528812u32;
puIRDAR2_NK OID_FDDI_IF_SSO78379552 = 50528790u32;
puIRDAR_FDDR_AE_ATMWDI_T_MAXIMUM_LIST_SI78382122 = 50528812u32;
puIRDAR_FDDS_PRHWDI_T_MAXIMUM_LIST_SI78382132 = 50528812u32;
puIRDAR_FDDUNI_SHORT_MUMAXIMUM_LIST_SI78382112 = 50528812u32;
puIRDAR_OID_8BUSYDDI_IF_SSO78379562 = 50528812u32;
puIRDARTEREOSNIORT_LER_CUIO78382092 = 50528812u32;
puIRDART_AE_ACALL_PROCEEDO78379522 = 50528812u32;
puIRDART_PSEC_C1UM_LIST_SI78382182 = 50528812u32;
puIRDART_PSEC_C2UM_LIST_SI78382232 = 50528812u32;
puIRDARnst OID_ATMID_FSL_PROCEEDO78379542 = 50528812u32;
puIRDARTURNAROFFLORT_MAC_LOOP_SO78379532 = 50528812u32;
puIRDARUNI_SHORT_MUUM_LIST_SI78382132 = 50528790u32;
puKDNnst OI_PFOUT_DISCDI16192 = 50528790u32;
puKDNnstENUMNTEREOIF_OUT_DISCDI16182 = 50528790u32;
puKDNnstQUERY8tF_CO_GET_CALL_INFORMADI16u32 = 50528821u32;
puKDNnst OID_80PFOUT_DISCDI16u32 = 50528820u32;
puLTALK_3_XMIT_MORE_COLLIS840176662 = 50528790u32;
puLTALK_3FDDI_SH_1394_FDDI_IF_S83951 u32 = 50528874u32;
puLTALK__802_RE_COLLIS840176672 = 50528874u32;
puLTALK_FCS_FDDI_IF_OUT_ER840176732 = 50528820u32;
puLTALK_IN ATM_DIGITIF_OUT_ER840174092 = 50528812u32;
puLTALK_IN SENGT__FDDI_IF_OUT_ER84017u32 = 218235410u32;
puLTALK_NO__MAC_MDDI_IF_OUT_ER840176632 = 50528808u32;
puLTALK_OID_FOAReNDL2_RE_COLLIS840176652 = 50528808u32;
puLTALK_D_FDOFDDIS_FDDI_IF_OUT_ER840176692 = 50528790u32;
puNDKOID_FDDI_SMPI_CALLPARA281213912 = 50528790u32;
puNDKOst OID_PRPOINTPI_CALLPARA281213922 = 50528790u32;
puNDKODI_SMT_LEI_CALLPARA281213892 = 50528790u32;
puNDKO OID_802_11_STATISRA28121392 = 218235410u32;
puNI__SWITCHITLst OTEFVFDDI_IF_S661172 = 50528808u32;
puNI__SWITCHIDREOTEFSWITCHDDI_IF_S661032 = 50528808u32;
puNI__SWITCHIDREOTEFV OIDI_CALLPA661132 = 50528808u32;
puNI__SWITCHIDFDDI_SHISMT_CONFIG_CAPABILI660u52 = 50528790u32;
puNI__SWITCHIDEst OISWITCHDDI_IF_S661052 = 50528790u32;
puNI__SWITCHIDEst OIV OIDI_CALLPA661162 = 50528790u32;
puNI__SWITCHIENUMFSWITCHG_CAPABILI661122 = 50528812u32;
puNI__SWITCHIENUMFVF_CAPABILI661202 = 50528812u32;
puNI__SWITCHIENUMFV OID_CAPABILI661152 = 50528790u32;
puNI__SWITCHIFREEFVFDDI_IF_S661182 = 50528790u32;
puNI__SWITCHIReset: NDISMT_CONFIG_CAPABILI660942 = 50528808u32;
puNI__SWITCHIDring: ND_ADMIN_ST661042 = 50528808u32;
puNI__SWITCHIVFIDring: ND_ADMIN_ST661192 = 50528790u32;
puNI__SWITCHIVst OIDring: ND_ADMIN_ST661142 = 50528808u32;
pu;
pub co_OTHESUL_CALL_INFORMADIST: u82 = 50528790u32;
puTM_MAX_COA_S_Ct OI_11_PROMATCHIDDI_SMT_SET_C661012 = 50528790u32;
puPDst OIDINNDVIDNDI_CALLPA66 u32 = 50528818u32;
puPDs_802_NNDVIDNDI_CALLPA66 u72 = 50528818u32;
puPDsQUERY8_FDDI_SHID_FDDADMIN_ST66 u32 = 50528819u32;
puPMt OI_PND_UCOLID
pub c1_STATISRA447014532 = 50528812u32;
puPMt OI_WONDtrTOID_1_STATISRA447014502 = 50528812u32;
puPMtDFDDI_SHISMT_CONFIG_CAPABILIRA447014u32 = 50397447u32;
puPconst PND_UCOLID
pub c1_STATISRA447014542 = 50397447u32;
puPcoReset: NDISMT_CONFIG_CAPABILIRA447014u82 = 50397447u32;
puPcoDring: ND_ADMIN_STRA447014u32 = 50528819u32;
puPMtPND_UCOLID
pub cRT_MUUM_LIST_RA447014562 = 50528819u32;
puPMt OID_80PND_UCOLID
pub c1_STATISRA447014552 = 50528819u32;
puPMt OID_80WONDtrTOID_1_STATISRA447014512 = 50528819u32;
puPMt OPSEC_C_1AC_LOOP_RA447014532 = 50397447u32;
puPcoWONDtrTOID_RT_MUUM_LIST_RA447014522 = 50528812u32;
puPNPt OI_WAKE_UPDtrTOID_1_STATISRA447014u32 = 50528843u32;
puPNPtISMT_CONFIG_CAPABILIRA447014u02 = 50528843u32;
puPNPtMA_UNI_WAKE_UPCAPABILIRA447014u62 = 50528843u32;
puPNPtQUERY8tPATHCAPABILIRA447014u22 = 50528812u32;
puPNPt OID_80WAKE_UPDtrTOID_1_STATISRA447014u42 = 50528812u32;
puPNPtDI_StPATHCAPABILIRA447014u12 = 50528812u32;
puPNPtWAKE_UPDM_CELLS_HEC_ERA447672332 = 50528812u32;
puPNPtWAKE_UPD_XMIT_CELLRA447672322 = 50528812u32;
puPNPtWAKE_UPDtrTOID_RT_MUUM_LIST_RA447014u32 = 50397445u32;
puQOStDFDDI_SHISMT_CONFIG_CAPABILIRA281861142 = 50528808u32;
puQOStReset: NDISMT_CONFIG_CAPABILIRA281861132 = 50528808u32;
puQOStF_RESERVEREOTEFSATH_MAX_T673752 = 50528808u32;
puQOStF_RESERVEFDDI_SHISMT_CONFIG_CAPABILI670742 = 50528790u32;
puQOStF_RESERVDEst OISATH_MAX_T673762 = 50528790u32;
puQOStF_RESERVENUMFSQ_CAPABILI670782 = 50528790u32;
puQOStF_RESERVReset: NDISMT_CONFIG_CAPABILI670732 = 50528808u32;
puQOStF_RESERVSQoDDI_PI_CALLPA670792 = 50528808u32;
puQOStF_RESERVUPDOTEFSATH_MAX_T673772 = 50528808u32;
puQOStFID_ACURRENFDring: ND_ADMIN_STRA281861162 = 50528790u32;
puQOStDring: ND_ADMIN_STRA281861152 = 50528808u32;
puQOStID_FDDIDring: ND_ADMIN_STRA281861172 = 50528808u32;
puQOStIDPSEC_C1UM_LIST_42111470082 = 50528808u32;
puQOStIDPSEC_C10UM_LIST_42111470172 = 50528808u32;
puQOStIDPSEC_C11UM_LIST_42111470182 = 50528808u32;
puQOStIDPSEC_C12UM_LIST_42111470192 = 50528808u32;
puQOStIDPSEC_C13UM_LIST_42111470202 = 50528812u32;
puQOStIDPSEC_C14UM_LIST_42111470212 = 50528812u32;
puQOStIDPSEC_C15UM_LIST_42111470222 = 50528812u32;
puQOStIDPSEC_C16UM_LIST_42111470232 = 50528812u32;
puQOStIDPSEC_C17UM_LIST_42111470242 = 50528812u32;
puQOStIDPSEC_C18UM_LIST_42111470252 = 50528812u32;
puQOStIDPSEC_C19UM_LIST_42111470262 = 50528812u32;
puQOStIDPSEC_C2UM_LIST_42111470092 = 50528808u32;
puQOStIDPSEC_C20UM_LIST_42111470272 = 50528808u32;
puQOStIDPSEC_C3UM_LIST_42111470102 = 50528812u32;
puQOStIDPSEC_C4UM_LIST_42111470112 = 50528812u32;
puQOStIDPSEC_C5UM_LIST_42111470122 = 50528812u32;
puQOStIDPSEC_C6UM_LIST_42111470132 = 50528812u32;
puQOStIDPSEC_C7UM_LIST_42111470142 = 50528812u32;
puQOStIDPSEC_C8UM_LIST_42111470152 = 50528812u32;
puQOStIDPSEC_C9UM_LIST_42111470162 = 50528790u32;
puR_AE_ATM_11_PROTLst OTEFQUEUWADMIN_ST660832 = 50528790u32;
puR_AE_ATM_11_PROCLEAR__11_PRIVACY_FI660882 = 50528790u32;
puR_AE_ATM_11_PROCFDDI_SHISMT_CONFIG_CAPABILI660u32 = 50528790u32;
puR_AE_ATM_11_PROENUMFG11_PR_CAPABILI660892 = 50528790u32;
puR_AE_ATM_11_PROENUMFQUEUW_CAPABILI660852 = 50528790u32;
puR_AE_ATM_11_PROFREEFQUEUWADMIN_ST660842 = 50528790u32;
puR_AE_ATM_11_PROGLOB NDtring: ND_ADMIN_ST660u22 = 50528790u32;
puR_AE_ATM_11_PROReset: NDISMT_CONFIG_CAPABILI660812 = 50528790u32;
puR_AE_ATM_11_PROID_80_11_PRIVACY_FI660962 = 50528790u32;
puR_AE_ATM_11_PROtring: ND_ADMIN_ST66092 = 218235410u32;
puR_AE_ATM_11_PROQUEUWNTLst OTPORT_OMPst OADMIN_ST66091 = 218235410u32;
puR_AE_ATM_11_PROQUEUWNtring: ND_ADMIN_ST660u62 = 50528790u32;
puR_AE_ATM_11_PROSAX__11_PRIVACY_FI660u72 = 50528808u32;
puSRIOV_BAR__ACCESS_NET_RESOU661372 = 50528808u32;
puSRIOV_ND_FDDIDI_SMT_HOLD_S661u32 = 50397445u32;
puSRIOV_NFDDI_SHISMT_CONFIG_CAPABILI661u32 = 50528828u32;
puSRIOV_Reset: NDISMT_CONFIG_CAPABILI661212 = 50528812u32;
puSRIOV_DI_PLYt OIC_APTD_FOID_1394_VC_661522 = 50528812u32;
puSRIOV_PF_LU_OP_VERSIO661u42 = 50528812u32;
puSRIOV_PROBTEABAD_ADMIN_ST661u32 = 50528836u32;
puSRIOV_REODIVFIND_FDDIBLOCKADMIN_ST661u12 = 50528836u32;
puSRIOV_REODIVFIND_FDDIOI NDAX_LIST_661292 = 50528836u32;
puSRIOV_RESAX_VFDDI_IF_S661332 = 50528812u32;
puSRIOV_SAX_VFID_802_DI_SMT_HOLD_S661342 = 50528812u32;
puSRIOV_VF OID_ATMOTEFDD_FDDIBLOCKADMIN_ST661532 = 50528812u32;
puSRIOV_VF PSEIOID_OID_8P_VERSIO661u62 = 50528812u32;
puSRIOV_VF S_PROC OIied: _OP_VERSIO661332 = 50397445u32;
puSRIOV_WRITEFVFIND_FDDIBLOCKADMIN_ST661u22 = 50397445u32;
puSRIOV_WRITEFVFIND_FDDIOI NDAX_LIST_661302 = 50528808u32;
puSWITCHIFEOTU NDIS_HARtQUERYADMIN_ST661512 = 50528808u32;
puSWITCHINI__ARRAYADMIN_ST661672 = 50528874u32;
puSWITCHINI__ID_FDDIATH_T_R_661712 = 50528808u32;
puSWITCHINI__EREOTEATH_T_R_661702 = 50528808u32;
puSWITCHINI__DEst OATH_T_R_661732 = 50528808u32;
puSWITCHINI__DPRDDIOID_FDDIATH_T_R_661932 = 50528808u32;
puSWITCHINI__DPSID_FDDIATH_T_R_661722 = 50528808u32;
puSWITCHINI__ID_FDDIATH_T_R_661602 = 50528808u32;
puSWITCHINI__IDSTOROATH_T_R_661942 = 50528808u32;
puSWITCHINI__IDSTOROT_OMPst OADMIN_ST661u52 = 50528790u32;
puSWITCHINI__IDSU_MAC_LOOP_662002 = 50528808u32;
puSWITCHINI__SAVOADMIN_ST661u22 = 50528808u32;
puSWITCHINI__SAVOT_OMPst OADMIN_ST661u32 = 50528808u32;
puSWITCHINI__SUSPENOP_VERSIO661u92 = 50528808u32;
puSWITCHINI__SUSPENO_ATTMFSCESS___1NISH_FDDI_IF_S662022 = 50528808u32;
puSWITCHINI__SUSPENO_ATTMFSCESS__DI_ O_FDDI_IF_S662012 = 50528808u32;
puSWITCHINI__UPDOTEOP_VERSIO661u62 = 50528808u32;
puSWITCHIDring: ND_ADMIN_ST661652 = 50528790u32;
puSWITCHIPized:RRAYADMIN_ST661662 = 50528790u32;
puSWITCHIPizedEREOTEATH_T_R_661682 = 50528790u32;
puSWITCHIPizedDEst OATH_T_R_661692 = 50528790u32;
puSWITCHIPizedFEOTU NDIS_HARtQUERYADMIN_ST661742 = 50528790u32;
puSWITCHIPizedNNDPATMYt OIATH_T_R_661612 = 50528790u32;
puSWITCHIPizedNNDPATMYtDEst OATH_T_R_661632 = 50528790u32;
puSWITCHIPizedNNDPATMYtENUMATH_T_R_661642 = 50528790u32;
puSWITCHIPizedNNDPATMYtUPDOTEATH_T_R_661622 = 50528790u32;
puSWITCHIPizedTEARDDI_ADMIN_ST661752 = 50528790u32;
puSWITCHIPizedUPDOTEOP_VERSIO661u72 = 50528874u32;
puSWITCHINNDPATMYt OIATH_T_R_661472 = 50528874u32;
puSWITCHINNDPATMYtDEst OATH_T_R_661492 = 50528874u32;
puSWITCHINNDPATMYtENUMATH_T_R_661502 = 50528874u32;
puSWITCHINNDPATMYtUPDOTEATH_T_R_661u82 = 50397447u32;
puonst OCCEPUUM_LIST_S176373772 = 50528808u32;
puonst ONSATHCAPABILIS176373782 = 50397447u32;
puonst t OID_CO_AF_CS176373792 = 50397447u32;
puonst t OIDANSLA_CO_AF_CS176373802 = 50528808u32;
puonst tONDICURRENFtOID_8Dt O_FDDI_PORT_ACS176373812 = 50528808u32;
puonst tONFDDIID_LOG_PORT_ACS176373822 = 50528808u32;
puonst OIi OID_FDDI_IF_SPECS176373832 = 50528808u32;
puonst OIAA_CO_AF_CS176373842 = 50528808u32;
puonst ONDP_CO_AF_CS176373852 = 50528808u32;
puonst GATHT_MAAPI_REPORT_DIS176374112 = 50528808u32;
puonst onst OID_COSO_TAPI_LINE_S176373862 = 50528808u32;
puonst onst OID_COS_OP_VERSIOS176373872 = 50528808u32;
puonst onst OID_COSDDI_IF_OPER_STS176373882 = 50528808u32;
puonst onstnst OIOID_COS_OP_VERSIOS176373892 = 50528808u32;
puonst onstnst OOID_1394_VC_S176373902 = 50528808u32;
puonst onstnst ODDI_IF_OPER_STS176373912 = 50528808u32;
puonst onstOIi O_TAPI_LINE_S176373922 = 50528808u32;
puonst onstOIi OD_FDDADMIN_STS176373932 = 50528808u32;
puonst onstEXTENI_SMT_OP_VERSIOS176373942 = 50528808u32;
puonst onst_OP_VERSIOS176373952 = 50528808u32;
puonst onstOID_COIi ODI_IF_OPER_STS176373962 = 50528808u32;
puonst MAKE_NSLA_CO_AF_CS176373972 = 50528808u32;
puonst MOFItELMAAPI_REPORT_DIS176374122 = 50528808u32;
puonst NEGOTIOTEFEXTFFDDI_SMADMIN_STS176373982 = 50528808u32;
puonst _802ADMIN_STS176373992 = 50528808u32;
puonst NNDVIDND _FItIAAXIMUM_LIST_S176374002 = 50528808u32;
puonst NNDVIDND SHUTDDI_ADMIN_STS176374012 = 50528808u32;
puonst SECURE_NSLA_CO_AF_CS176374022 = 50528808u32;
puonst SELDDIOEXTFFDDI_SMADMIN_STS176374032 = 50528808u32;
puonst SENDcUST_MUST_MOID_1394_VC_S176374042 = 50528808u32;
puonst SEst PP OID_FDDI_IF_SPECS176374052 = 50528808u32;
puonst SEstnst OIE_TAPI_CALLPAS176374062 = 50528808u32;
puonst SEstDEFAULTFtOID_8Dt O_FDDI_PORT_ACS176374072 = 50528808u32;
puonst SEstDEi OD_FDDADMIN_STS176374082 = 50528808u32;
puonst SEsttOID_8DI_PATH_T_R_S176374092 = 50528808u32;
puonst SEstIS_HARtM_COAGEREPORT_DIS176374102 = 50528808u32;
puoCP4_;
pub coDDI_PI_CALLPARA279244u72 = 50528808u32;
puoCP6_;
pub coDDI_PI_CALLPARA279244882 = 50528808u32;
puoCPOID_FDDI_SMTF_RESERVEFDDI_SHID_FDDADMIN_STRA279244u42 = 50528808u32;
puoCPOID_FDDI_SMTF_RESERVReset: NDISMT_CONFIG_CAPABILIRA279244u52 = 50528808u32;
puoCPOID_FDDI_SMTF_RESERVDring: ND_ADMIN_STRA280555532 = 50528808u32;
puoCPOF_RESERVEFDDI_SHID_FDDADMIN_STRA279244u12 = 50528808u32;
puoCPOF_RESERVReset: NDISMT_CONFIG_CAPABILIRA279244u32 = 50528808u32;
puoCPOF_RESERVDring: ND_ADMIN_STRA279244u22 = 50528808u32;
puoCPORSC  OID_802_11_STATISS_16132 = 50528808u32;
puoCPOSANAnst OIDI_CALLPARA279244842 = 50528808u32;
puoCPOTASK_IPSECt OI_SAI_CALLPARA279244822 = 50528808u32;
puoCPOTASK_IPSECt OI_UDPESP_SAI_CALLPARA279244852 = 50528808u32;
puoCPOTASK_IPSECtDEst OISAI_CALLPARA279244832 = 50528808u32;
puoCPOTASK_IPSECtDEst OIUDPESP_SAI_CALLPARA279244862 = 50528808u32;
puoCPOTASK_IPSECtF_RESERVV2t OI_SAI_CALLPARA280555542 = 50528808u32;
puoCPOTASK_IPSECtF_RESERVV2t OI_SA_DDI_PORT_IRA280555572 = 50528808u32;
puoCPOTASK_IPSECtF_RESERVV2tDEst OISAI_CALLPARA280555552 = 50528808u32;
puoCPOTASK_IPSECtF_RESERVV2tUPDOTEFSAI_CALLPARA280555562 = 50528808u32;
puoCPOTASK_D
pub c1_STATISRA279244812 = 50528808u32;
puoIMEMT_MSDI_MAC_T_MAX_CAPABI104857612 = 50528808u32;
puoIMEMT_MSDIFDDI_SHID_FDDADMIN_ST104857622 = 50528808u32;
puoIMEMT_MSDonstnROSSoIMEMT_MSADMIN_ST104857632 = 50528808u32;
puoU_FDL _Fype: NDInst OID_O_OP_VERSIO2517240392 = 50528808u32;
puoU_FDL _Fype: NDISEstO_OP_VERSIO2517240382 = 50528808u32;
puVLAT_IDPSEC_C1UM_LIST_660972 = 50528808u32;
puVLAT_IDPSEC_C2T_HOLD_S660982 = 50528808u32;
puVLAT_IDPSEC_C3DDI_IF_S660992 = 50528808u32;
puVLAT_IDPSEC_C4MT_SET_C661002 = 50528808u32;
puWAN COAnst _OMPFOID_1394_VC_671750402 = 50528808u32;
puWAN COAnst OID_1394_VC_67174 u32 = 50528794u32;
puWAN COAnst 2_NK OID_1394_VC_67174 u62 = 50528794u32;
puWAN COAnst DDI_PFOID_1394_VC_671750422 = 50528794u32;
puWAN COASst _OMPFOID_1394_VC_671750412 = 50528794u32;
puWAN COASst 2_NK OID_1394_VC_67174 u52 = 50528794u32;
puWAN CFDDI_SHORT_MAC_SMT_ADD671746582 = 50528812u32;
puWAN nst ID_FDDIOID_1394_VC_671749222 = 50528812u32;
puWAN nst _OMPFOID_1394_VC_671749242 = 50528812u32;
puWAN nst OID_1394_VC_671746632 = 50528808u32;
puWAN nst 2_NK OID_1394_VC_671746652 = 50528808u32;
puWAN nst DDI_PFOID_1394_VC_671749262 = 50528794u32;
puWAN D: NDIS_GET_C1394_VC_671746622 = 50528812u32;
puWAN OID_CODI_SMT_SET_C671746662 = 50528794u32;
puWAN IS_PHY_SUBRT_NEIGHBOR_671746612 = 50528794u32;
puWAN _FDDI_SHORT_PEMAC_SMT_ADD671746572 = 50528794u32;
puWAN _ND_UCOLIO_TAPI_LINE_671746672 = 50528794u32;
puWAN _ND_UCOLIRT_NEIGHBOR_671746602 = 50528808u32;
puWAN QUAT_MA_D
TM_SUPPO_SMT_ADD671746592 = 50528808u32;
puWAN Sst ID_FDDIOID_1394_VC_671749232 = 50528808u32;
puWAN Sst _OMPFOID_1394_VC_671749252 = 50528808u32;
puWAN Sst 2_NK OID_1394_VC_671746642 = 50528812u32;
puWWAN : NDFDDILSENGO_SMT_ADD234u46 u32 = 50528837u32;
puWWAN BOID_oT_LASTPFOID_1394_VC_234u46 882 = 50528808u32;
puWWAN CO_FDDIATH_T_R_234u46 282 = 50528808u32;
puWWAN CREOTEFMACATH_T_R_234u46 542 = 50528812u32;
puWWAN DEst OIMACATH_T_R_234u46 552 = 50528812u32;
puWWAN DEied: BIN_CALSATH_T_R_234u46 652 = 50528812u32;
puWWAN DEied: O_TAPI_LINE_234u46 172 = 50528812u32;
puWWAN DEied: O_TA_DDI_PORT_I234u46 622 = 50528812u32;
puWWAN DEied: RESAX1394_VC_234u46 872 = 50528812u32;
puWWAN DEied: M_SUPPO _OMDI_D1394_VC_234u46 402 = 50528808u32;
puWWAN DEied: M_SUPPO SMACDDI_PORT_AC234u46 512 = 50528808u32;
puWWAN DEied: M_SUPPO SMACDDI_WRITE_PORT_AC234u46 522 = 50528812u32;
puWWAN DRIVD_FO_TAPI_LINE_234u46 162 = 50528812u32;
puWWAN ENUMNTEREODEied: M_SUPPOAPI_LINE_234u46 382 = 50528812u32;
puWWAN ENUMNTEREODEied: M_SUPPO _OMDI_DAPI_LINE_234u46 502 = 50528808u32;
puWWAN HOMDINNDVIDNDI_CALLPA234u46 222 = 50528812u32;
puWWAN IMS_VOIDDI_PATE_PORT_AC234u46 672 = 50528812u32;
puWWAN st OTPORT_PATE_PORT_AC234u46 692 = 50528812u32;
puWWAN sREOst OIDHID_FDDADMIN_ST234u46 822 = 50528812u32;
puWWAN sREOst OIDHODI_IF_OPER_ST234u46 832 = 50528812u32;
puWWAN MBIMFFDDI_SMADMIN_ST234u46 602 = 50528808u32;
puWWAN DI_PM tONFDDIOID_1394_VC_234u46 842 = 50528808u32;
puWWAN DI_PM LOGGt OIID_FDDADMIN_ST234u46 912 = 50528808u32;
puWWAN MPDP1394_VC_234u46 892 = 50528812u32;
puWWAN  OID_802BLACKT_MUUM_LIST_234u46 812 = 50528812u32;
puWWAN  OID_802IDLE_HINUUM_LIST_234u46 712 = 50528812u32;
puWWAN  OID_802IE_TAPI_CALLPA234u46 932 = 50528812u32;
puWWAN NITZUM_LIST_234u46 702 = 50528808u32;
puWWAN TM_MAX_M_SUPPO_SMT_ADD234u46 262 = 50528812u32;
puWWAN PC_1394_VC_234u46 852 = 50528812u32;
puWWAN PIMADMIN_ST234u46 202 = 50528812u32;
puWWAN PIM_DDI_PORT_I234u46 492 = 50528812u32;
puWWAN PIM_DD2PI_LINE_234u46 592 = 50528812u32;
puWWAN PIM_T_MUUM_LIST_234u46 212 = 50528812u32;
puWWAN PR802_MAC__FDDI_SRRIPROtNDVIDNDAPI_LINE_234u46 532 = 50528812u32;
puWWAN PR802_MAC_tNDVIDNDAPI_LINE_234u46 232 = 50528812u32;
puWWAN PR8SHUTDDI_ADMIN_ST234u46 722 = 50528812u32;
puWWAN PRDVII_SMAC_TOFypXTAPI_LINE_234u46 292 = 50528812u32;
puWWAN PS tOID_8T_RFDDADMIN_ST234u46 782 = 50528812u32;
puWWAN RADIOT_PATE_PORT_AC234u46 192 = 50528812u32;
puWWAN REODYIOID_1394_VC_234u46 182 = 50528812u32;
puWWAN REGIS_PROtringPI_CALLPA234u46 922 = 50528812u32;
puWWAN REGIS_PRO_PATE_PORT_AC234u46 252 = 50528812u32;
puWWAN REGIS_PRO_PATE_DDI_PORT_I234u46 662 = 50528812u32;
puWWAN SAR8T_RFDDADMIN_ST234u46 792 = 50528812u32;
puWWAN SAR8ID_FDDIACDDI_ODI_IF_OPER_ST234u46 802 = 50528812u32;
puWWAN M_SUPPO D_FDVER_SMADMIN_ST234u46 302 = 50528812u32;
puWWAN MIGRENFDDI_E_PORT_AC234u46 272 = 50528812u32;
puWWAN MIGRENFDDI_E_DDI_PORT_I234u46 682 = 50528812u32;
puWWAN SLOt OID__ODI_IF_OPER_ST234u46 642 = 50528812u32;
puWWAN SMSID_FDDI_PATH_CONFIGURA234u46 312 = 50528812u32;
puWWAN SMSIDEst OATH_T_R_234u46 342 = 50528812u32;
puWWAN SMSIRTH_SBA_OVER234u46 322 = 50528812u32;
puWWAN SMSISE_D1394_VC_234u46 332 = 50528812u32;
puWWAN SMSISDI_IF_OPER_ST234u46 352 = 50528812u32;
puWWAN SUBD_FIBEODEied: M_SUPPO EVENTAPI_LINE_234u46 392 = 50528812u32;
puWWAN SYSFO_TAPI_LINE_234u46 612 = 50528812u32;
puWWAN SYSFSLOtMAPPCALSATH_T_R_234u46 632 = 50528812u32;
puWWAN UWNtCONNECTION_PO234u46 942 = 50528812u32;
puWWAN UICC OCCESS BINARECTION_PO234u46 572 = 50528812u32;
puWWAN UICC OCCESS RECORD1394_VC_234u46 582 = 50528812u32;
puWWAN UICC OPDUADMIN_ST234u46 762 = 50528812u32;
puWWAN UICC OPP_T_MUUM_LIST_234u46 902 = 50528812u32;
puWWAN UICC OTDI_CALLPA234u46 732 = 50528812u32;
puWWAN UICC t OIDANHA_FDLI_CALLPA234u46 752 = 50528812u32;
puWWAN UICC IS_PISDI_IF_OPER_ST234u46 562 = 50528812u32;
puWWAN UICC _802_NHA_FDLI_CALLPA234u46 742 = 50528812u32;
puWWAN UICC RESAX1394_VC_234u46 862 = 50528812u32;
puWWAN UICC _PRMIRENFI_MAC_T_MAX_CAPABI234u46 772 = 50528812u32;
puWWAN USSD1394_VC_234u46 412 = 50528812u32;
puWWAN S_PROC OID_FDDI_IF_SPEC234u46 362 = 50528812u32;
puWWAN VII_I_SMTNDVIDNDAPI_LINE_234u46 242 = 50528812u32;
puXBOX OCC_IDPSEC_C0UM_LIST_41943040002 = 50528808u32;riginalNetBufferList: I_TRAPPROtr_MAX_OID_ST_9i = 50528808u32;riginalPacketInfo: I_TRAPPROtr_MAX_OID_ST_7i = 50528808u32PDMBUFFEL DTTRMBUILX_OI__MAC_BUFFELLS_HEC_ERu = 50528808u32PDMBUFFEL _DISOtritIAAOtr_MAX_ATH_SBA_OVERRu = 50528808u32PDMBUFFEL D_FDRX__MAC_DI_ OIDLIGRRT_MAC_PLACE2u = 50528808u32PDMBUFFEL D_FDRX__MAC_DI_ OIDDI_MAC_TVX_V32u = 50528808u32PDMBUFFEL D_FDTX__MAC_DI_ OIDLIGRRT_MAC_PLACE2u = 50528808u32PFDDI_SHORVCSBA_OVERRu = 50528808u32PacketCancelId: I_TRAPPROtr_MAX_OID_ST_8i = 50528808u32QUERY8_st OIE_TA: ND_ADMIN_STRu = 50528808u32RTH__UNI_st OIDCLOCKADMIN_ST1u = 50528808u32RTAE_ATMADI_SDI_PORTDDI_PORT_ACSu = 50528808u32RTAE_ATMADI_SDI_PORTDDIFI_MAC_PMIT_CELL8u = 50528808u32RTAE_ATMVCSBA_OVER8u = 50528808u32RTPSEC___ACCESS_NMVCSBA_OVER642 = 50528812u32ROFFLODDI_FGET__PORT_ACS282 = 50528808u32ROFFLOUPFGET__PORT_AC2562 = 50528812u32STst O_GET_C_ASCII_PORT_ACSu = 50528808u32STst O_GET_C_BINARECTION_PO4u = 50528808u32STst O_GET_C_DB_11_STATIS2u = 50528808u32STst O_GET_C_UNI_I_PATH_T_R_32 = 50528812u32ScatterGatherListPacketInfo: I_TRAPPROtr_MAX_OID_ST_5i = 50528808u32ShortPacketPaddingInfo: I_TRAPPROtr_MAX_OID_ST_11i = 50528808u32ADI_D SENDcI_MAC_PMIT_CELL162 = 50528812u32ADI_SMT_MScI_MAC_PMIT_CELL32u = 50528808u32ID_FDDI_MVCSBA_OVER4u = 50528808u32IDUNORT_MMHASH SEN_PORT_ACS2u = 50528808u32IcpIpChecksumPacketInfo: I_TRAPPROtr_MAX_OID_ST_0i = 50528808u32IcpLargeSendPacketInfo: I_TRAPPROtr_MAX_OID_ST_2i = 50528808u32USERADI_SMT_MS11_STATIS2u = 50528808u32WAN _ND_UCOLIKEEPSoDDI_PI_CALLPASu = 50528808u32fI_TRAGUIDNTLstWIRTH_SBA_OVER32u = 50528808u32fI_TRAGUIDNTLstWIWRITE_PORT_AC642 = 50528812u32fI_TRAGUIDNTNSI_STst OSBA_OVER4u = 50528808u32fI_TRAGUIDNTRRAYADMIN_ST162 = 50528812u32fI_TRAGUIDNA: HOD_PORT_ACS282 = 50528808u32fI_TRAGUIDNansferDPSEC_C_PORT_AC2562 = 50528812u32fI_TRAGUIDNnst OID _OMDON D: NDIAM_NODE_L12u = 50528808u32fI_TRAGUIDNTOtO_OP_VERSIO1u = 50528808u32fI_TRAGUIDNTOtSDI_IF_OPER_ST2u = 50528808u32fI_TRAGUIDNUNI_I_P_STst OSBA_OVER82 = 50528808u32ftr_MAX_TLst OTEEABYNansf_PORT_ACS282 = 50528808u32fTM_MAX_CONTAINS tOID_8OID_FDDI OID_1394_VC_642 = 50528808u32fTM_MAX_DI_SPPROrDPSEC_C_PORT_AC632 = 50528type I_TRA802_11d: ND_802_11_AUTDI_P_ACi = 50528type I_TRA802_11dtOID_8OFDDI_MDI_P_ACi = 50528type I_TRA802_11d OID_802INFRAOFDUI_SMT_ACi = 50528type I_TRA802_11d OID_802RT_N_ACi = 50528type I_TRA802_11dD_802_DI_P_ACi = 50528type I_TRA802_11dPRDVECY__11_PR_ACi = 50528type I_TRA802_11dRADIOT_PATUS_ACi = 50528type I_TRA802_11dREESERVDEFAULTS_ACi = 50528type I_TRA802_11dIS_HARtRT_N_ACi = 50528type I_TRA802_11dWEPT_PATUS_ACi = 50528type I_TRA802_5nst OIDDI_E_ACi = 50528type I_TRADI_PO_ID_ACi = 50528type I_TRAified: NNPtMVENT_ACi = 50528type I_TRAified: N_802_DI_SM_ACi = 50528type I_TRAENVIRORRT_MtRT_N_ACi = 50528type I_TRAb const OIDRT_MtRT_N_ACi = 50528type I_TRAb conLID_FDDI_SMTDI_SM_ACi = 50528type I_TRAb const OID_FDDI_RI_ACi = 50528type I_TRAReset: NDIS_HAR_ACi = 50528type I_TRA_Fype: NDIRT_N_ACi = 50528type I_TRA_Fype: NDIS_INTERRUP_ACi = 50528type I_TRAtOID_8OF_RI_ACi = 50528type I_TRAIS_PHY_ACi = 50528type I_TRA OID_802DDI_IFIRT_N_ACi = 50528type I_TRAIE_TA: NDIRT_N_ACi = 50528type I_TRAIPROtr_MAX_OID_ST_i = 50528type I_TRAIsWan: NDIS_PHYST_i = 50528type I_TRAIized: NDORIZAI_SMTDI_SM_ACi = 50528type I_TRA OID _ONDIS_TDI_SM_ACi = 50528type I_TRA OID RT_N_ACi = 50528type I_TRAI_802_NNDIS_P_ACi = 50528type I_TRAIROCESSODIRT_N_ACi = 50528type I_TRAIROCESSODIS_PROC_ACi = 50528type I_TRAID_FDDI8RT_N_ACi = 50528type I_TRAnst OID_ATPAUSERFUNOLASTP_ACi = 50528type I_TRAWAN D: NDIS_GET_C_ACi = 50528type I_TRAWAN IS_PHY_SUBRT_N_ACi = 50528type I_TRAWAN QUAT_MA_ACi = 50528type F_RESERVEONF_TLGO_ACi = 50528type F_RESERV_FypGR_MA_TLGO_ACi = 50528type F_RESERVFID_ACURR_N_ACi = 50528type UDPo_OTHE8RT_N_ACi = 5#[repr(C)]5#[derive(Clone, Copy)]50528struct BINARE__MAC {
    0528Length_PO16,
    0528Buffer: *mut880re::ffi::c_void,
}5#[repr(C)]5#[derive(Clone, Copy)]50528struct BSS
puIID_S{
    0528BSS
p: [u8; 6],
    0528PMK
p: [u8; 16],
}5#[repr(C)]5#[derive(Clone, Copy)]50528struct CORT_PEMACS{
    0528AddressSize_PORT,
    0528Address: [u8; 1],
}5#[repr(C)]5#[derive(Clone, Copy)]50528struct CORT_PEMAC_FAMILYS{
    0528AddressFamily_PORT,
    0528MajorVersion_PORT,
    0528MinorVersion_PORT,
}5#[repr(C)]5#[derive(Clone, Copy)]50528struct CORT_PEMAC_T_MUS{
    0528NumberOfAddressesAvailable_PORT,
    0528NumberOfAddresses_PORT,
    0528AddressList: CORT_PEMAC,
}5#[repr(C)]5#[cfg(feature_AC"Win32_Networking_WinSock")]5#[derive(Clone, Copy)]50528struct COR_st OMANAGPROtring: ND_S{
    0528Transmit: super::super::super::Win32::Networking::WinSock::GET_OID_,
    0528Receive: super::super::super::Win32::Networking::WinSock::GET_OID_,
    0528CallMgrSpecific: COROID_FDDI tring: ND_,
}50528type COR_st Otring: ND_SACisize;50528type CORtOID_8tring: ND_SACisize;5#[repr(C)]5#[derive(Clone, Copy)]50528struct CORPVCS{
    0528NdisAfHandle_P*mut880re::ffi::c_void,
    0528PvcParameters: COROID_FDDI tring: ND_,
}5#[repr(C)]5#[derive(Clone, Copy)]50528struct CORSAPS{
    0528SapType_PORT,
    0528SapLength_PORT,
    0528Sap: [u8; 1],
}5#[repr(C)]5#[derive(Clone, Copy)]50528struct COROID_FDDI tring: ND_S{
    0528ParamType_PORT,
    0528Length_PORT,
    0528Parameters: [u8; 1],
}50528type : H__11_PR_ACisize;5#[repr(C)]5#[derive(Clone, Copy)]50528struct _11_PRDBCS{
    0528Anonymous: _11_PRDBC_0,
    0528TrDB_P*mut8isize,
    0528YYYDB_P*mut880re::ffi::c_void,
    0528XXXDB_P*mut880re::ffi::c_void,
}5#[repr(C)]5#[derive(Clone, Copy)]50528union _11_PRDBC_0S{
    0528EthDB_P*mut8: H__11_PR,
    0528NullDB_P*mut8isize,
}5#[repr(C)]5#[derive(Clone, Copy)]50528struct GEN nst OITI_IFORT_MS{
    0528ReadTime_PO64,
}5#[repr(C)]5#[derive(Clone, Copy)]50528struct GEN nst ADI_SO_TAS{
    0528Flags_PORT,
    0528ClockPrecision_PORT,
}5#[repr(C)]5#[derive(Clone, Copy)]50528struct LOCK_II_SM_{
    0528LockState_PO16,
    0528OldIrql_PO8,
}5#[repr(C)]5#[derive(Clone, Copy)]50528struct tOID_8OID_FDDI OID_ET_CALLS{
    0528NextEntryOffset_PORT,
    0528ClassId: I_TRADI_PO_ID,
    0528Size_PORT,
    0528ClassInformation_P[u8; 1],
}5#[repr(C)]5#[derive(Clone, Copy)]50528struct I_TRA802_11d:IAID_FIS{
    0528Capabilities_PO16,
    0528ListenInterval_PO16,
    0528CurrentAPAddress: [u8; 6],
}5#[repr(C)]5#[derive(Clone, Copy)]50528struct I_TRA802_11d:IAIDSFIS{
    0528Capabilities_PO16,
    0528StatusCode_PO16,
    0528AssociationId: O16,
}5#[repr(C)]5#[derive(Clone, Copy)]50528struct I_TRA802_11d:SSOCIACURR_OID_ET_CALLS{
    0528Length_PORT,
    0528AvailableRequestFixedIEs_PO16,
    0528RequestFixedIEs_PI_TRA802_11d:IAID_FI,
    0528RequestIELength_PORT,
    0528OffsetRequestIEs_PORT,
    0528AvailableResponseFixedIEs_PO16,
    0528ResponseFixedIEs_PI_TRA802_11d:IAIDSFI,
    0528ResponseIELength_PORT,
    0528OffsetResponseIEs_PORT,
}5#[repr(C)]5#[derive(Clone, Copy)]50528struct I_TRA802_11d: ND_802_11_AUT_OTRYPCALLS{
    0528AuthModeSupported: I_TRA802_11d: ND_802_11_AUTDI_P,
    0528EncryptStatusSupported: I_TRA802_11dWEPT_PATUS,
}5#[repr(C)]5#[derive(Clone, Copy)]50528struct I_TRA802_11d: ND_802_11_AUT_VENT_{
    0528Status: I_TRA802_11dIS_HARtDI_PORTDDI,
    0528Request: [I_TRA802_11d: ND_802_11_AUTID_FDDI; 1],
}5#[repr(C)]5#[derive(Clone, Copy)]50528struct I_TRA802_11d: ND_802_11_AUTID_FDDIS{
    0528Length_PORT,
    0528Bssid: [u8; 6],
    0528Flags_PORT,
}5#[repr(C)]5#[derive(Clone, Copy)]50528struct I_TRA802_11dBSS
puT_MUS{
    0528NumberOfItems_PORT,
    0528Bssid: [I_TRAWLAT_BSS
p; 1],
}5#[repr(C)]5#[derive(Clone, Copy)]50528struct I_TRA802_11dBSS
puT_MU_EXS{
    0528NumberOfItems_PORT,
    0528Bssid: [I_TRAWLAT_BSS
p_EX; 1],
}5#[repr(C)]5#[derive(Clone, Copy)]50528struct I_TRA802_11dI_MAC_T_MAS{
    0528Length_PORT,
    0528Version_PORT,
    0528NoOfPMK
ps_PORT,
    0528NoOfAuthEncryptPairsSupported: ORT,
    0528AuthenticationEncryptionSupported: [I_TRA802_11d: ND_802_11_AUT_OTRYPCALL; 1],
}5#[repr(C)]5#[derive(Clone, Copy)]50528struct I_TRA802_11dI_FDDI_PATH_CS{
    0528Length_PORT,
    0528BeaconPeriod: ORT,
    0528AADIWindow: ORT,
    0528DSConfig: ORT,
    0528FHConfig: I_TRA802_11dI_FDDI_PATH_C_FH,
}5#[repr(C)]5#[derive(Clone, Copy)]50528struct I_TRA802_11dI_FDDI_PATH_C_FHS{
    0528Length_PORT,
    0528HopPattern_PORT,
    0528HopSet_PORT,
    0528DwellTime_PORT,
}5#[repr(C)]5#[derive(Clone, Copy)]50528struct I_TRA802_11dFIXED_IEsS{
    0528Timestamp: [u8; 8],
    0528BeaconInterval_PO16,
    0528Capabilities_PO16,
}5#[repr(C)]5#[derive(Clone, Copy)]50528struct I_TRA802_11dKEAS{
    0528Length_PORT,
    0528KeyIndex_PORT,
    0528KeyLength_PORT,
    0528BSS
p: [u8; 6],
    0528KeyRSC_PO64,
    0528KeyMaterial_P[u8; 1],
}5#[repr(C)]5#[derive(Clone, Copy)]50528struct I_TRA802_11d OID_802RT_NuT_MUS{
    0528NumberOfItems_PORT,
    0528NetworkType_P[I_TRA802_11d OID_802RT_N; 1],
}5#[repr(C)]5#[derive(Clone, Copy)]50528struct I_TRA802_11d _C_B_SHORSS
puT_MUS{
    0528NumberOfItems_PORT,
    0528Non_Bcast_Ssid: [I_TRA802_11dIS
p; 1],
}5#[repr(C)]5#[derive(Clone, Copy)]50528struct I_TRA802_11dPMK
pS{
    0528Length_PORT,
    0528BIS
pInfoCount_PORT,
    0528BIS
pInfo: [BSS
puIID_; 1],
}5#[repr(C)]5#[derive(Clone, Copy)]50528struct I_TRA802_11dPMK
pdI_I_TDOTEFT_MUS{
    0528Version_PORT,
    0528NumCandidates_PORT,
    0528CandidateList: [PMK
pdI_I_TDOTE; 1],
}5#[repr(C)]5#[derive(Clone, Copy)]50528struct I_TRA802_11d OID_80KEAS{
    0528Length_PORT,
    0528KeyIndex_PORT,
    0528BSS
p: [u8; 6],
}5#[repr(C)]5#[derive(Clone, Copy)]50528struct I_TRA802_11dSS
p_{
    0528SsidLength_PORT,
    0528Ssid: [u8; 32],
}5#[repr(C)]5#[derive(Clone, Copy)]50528struct I_TRA802_11dSOID_802_1S{
    0528Length_PORT,
    0528TransmittedFragmentCount_Pi64,
    0528MulticastTransmittedFrameCount_Pi64,
    0528FailedCount_Pi64,
    0528RetryCount_Pi64,
    0528MultipleRetryCount_Pi64,
    0528RTSSuccessCount_Pi64,
    0528RTSFailureCount_Pi64,
    0528ACKFailureCount_Pi64,
    0528FrameDuplicateCount_Pi64,
    0528ReceivedFragmentCount_Pi64,
    0528MulticastReceivedFrameCount_Pi64,
    0528FCSErrorCount_Pi64,
    0528TKIPLocalMICFailures_Pi64,
    0528TKIPICVErrorCount_Pi64,
    0528TKIPCounterMeasuresInvoked: i64,
    0528TKIPReplays_Pi64,
    0528CCMPFormatErrors_Pi64,
    0528CCMPReplays_Pi64,
    0528CCMPDecryptErrors_Pi64,
    0528FourWayHandshakeFailures_Pi64,
    0528WEPUndecryptableCount_Pi64,
    0528WEPICVErrorCount_Pi64,
    0528DecryptSuccessCount_Pi64,
    0528DecryptFailureCount_Pi64,
}5#[repr(C)]5#[derive(Clone, Copy)]50528struct I_TRA802_11dSOIDARtDI_PORTDDI_{
    0528StatusType_PI_TRA802_11dIS_HARtRT_N,
}5#[repr(C)]5#[derive(Clone, Copy)]50528struct I_TRA802_11dTDDIS{
    0528Length_PORT,
    0528Type_PORT,
    0528Anonymous: I_TRA802_11dTDDI_0,
}5#[repr(C)]5#[derive(Clone, Copy)]50528union I_TRA802_11dTDDI_0S{
    0528AuthenticationEvent: I_TRA802_11d: ND_802_11_AUT_VENT,
    0528RssiTrigger: iRT,
}5#[repr(C)]5#[derive(Clone, Copy)]50528struct I_TRA802_11dVARI_UNI_IEsS{
    0528Element_OP_V8,
    0528Length_PO8,
    0528data_P[u8; 1],
}5#[repr(C)]5#[derive(Clone, Copy)]50528struct I_TRA802_11dWEPS{
    0528Length_PORT,
    0528KeyIndex_PORT,
    0528KeyLength_PORT,
    0528KeyMaterial_P[u8; 1],
}50528type I_TRAAFFT_MUSACisize;50528type I_TRADst OMANAGPROCHARACTER_802_1SACisize;5#[repr(C)]5#[derive(Clone, Copy)]50528struct I_TRAND_FDD_PATH_C_tring: NDS{
    0528ParameterType_PI_TRAIE_TA: NDIRT_N,
    0528ParameterData_PI_TRAND_FDD_PATH_C_tring: ND_0,
}5#[repr(C)]5#[derive(Clone, Copy)]50528union I_TRAND_FDD_PATH_C_tring: ND_0S{
    0528IntegerData_PORT,
    0528StringData_Psuper::super::super::Win32::Foundation_:UNI_I_P_STst O,
    0528BinaryData_PBINARE__MAC,
}5#[repr(C)]5#[derive(Clone, Copy)]50528struct I_TRACOAified: NNDIS_P_{
    0528DeviceDescription_PI_TRAVAR__MAC_OID_,
    0528DevSpecificInfo: I_TRAVAR__MAC_OID_,
    0528ulonstSupplementaryPassThru_PORT,
    0528ulAddressModes_PORT,
    0528ulNumAddresses_PORT,
    0528ulBearerModes_PORT,
    0528ulMaxTxRate_PORT,
    0528ulMinTxRate_PORT,
    0528ulMaxRxRate_PORT,
    0528ulMinRxRate_PORT,
    0528ulMediaModes_PORT,
    0528ulGenerateToneModes_PORT,
    0528ulGenerateToneMaxNumFreq_PORT,
    0528ulGenerateDigitModes_PORT,
    0528ulMonitorToneMaxNumFreq_PORT,
    0528ulMonitorToneMaxNumEntries_PORT,
    0528ulMonitorDigitModes_PORT,
    0528ulGatherDigitsMinTimeout_PORT,
    0528ulGatherDigitsMaxTimeout_PORT,
    0528ulDevCapFlags_PORT,
    0528ulMaxNumActiveCalls_PORT,
    0528ulAnswerMode_PORT,
    0528ulUUIAcceptSize_PORT,
    0528ulUUIAnswerSize_PORT,
    0528ulUUIMakeCallSize_PORT,
    0528ulUUIDropSize_PORT,
    0528ulUUISendUserUserInfoSize_PORT,
    0528ulUUICallInfoSize_PORT,
}5#[repr(C)]5#[derive(Clone, Copy)]50528struct I_TRACOA2_NK OID_F_{
    0528Outbound_PORT,
    0528Inbound_PORT,
}5#[repr(C)]5#[cfg(all(feature_AC"Wdk_Foundation", feature_AC"Win32_System_Kernel"))]5#[derive(Clone, Copy)]50528struct I_TRADMAIBLOCK_{
    0528MapRegisterBase_P*mut880re::ffi::c_void,
    0528AllocationEvent: super::super::Foundation_:K_VENT,
    0528SystemAdapterObject_P*mut880re::ffi::c_void,
    0528Miniport_P*mut880re::ffi::c_void,
    0528InProgress: super::super::super::Win32::Foundation_:BOOLEAN,
}5#[repr(C)]5#[cfg(feature_AC"Wdk_System_SystemServices")]5#[derive(Clone, Copy)]50528struct I_TRADMAIOID_RIPCALLS{
    0528DemandMode_Psuper::super::super::Win32::Foundation_:BOOLEAN,
    0528AutoInitialize_Psuper::super::super::Win32::Foundation_:BOOLEAN,
    0528DmaChannelSpecified: super::super::super::Win32::Foundation_:BOOLEAN,
    0528DmaWidth_Psuper::super::System::SystemServices::DMAIWIDTH,
    0528DmaSpeed: super::super::System::SystemServices::DMAIOID_F,
    0528DmaPort_PORT,
    0528DmaChannel_PORT,
}5#[repr(C)]5#[cfg(all(feature_AC"Wdk_Foundation", feature_AC"Win32_System_Kernel"))]5#[derive(Clone, Copy)]50528struct I_TRA_VENT_{
    0528Event: super::super::Foundation_:K_VENT,
}5#[repr(C)]5#[derive(Clone, Copy)]50528struct I_TRAGUID_{
    0528Guid: windows_sys_:80re::GUIDr(C)]5#[derive(Clone, Copy
    0528Gu00528Size_PORT,
    0528ClassIPORT,
}5#[repr(C)]5#[derive(Clone, Copy)]50528structI_TRAND_FDD528Gu0 0528Outbounid
    0528StringDaI_TRA85#[repr(C)]5#[derive(Clone, Copy)]50528struct I_TRA802_11 NDISMT_COMEMT_MSADMIN_ 0528OutbouHeadT,
}02_11OBJTFFDS_GET_,528Flags_PORT,
    0528ClockP_Kerneamp: [u8;1
    0528KeyMatHardwdesrecisamp: [u8; 8   0528KeyMat_Kerneamp: [u8;2
}5#[repr(C)]5#[derive(Clone, Copy)]50528struct GEN nsFype: NDIS_INTERRUP_ACi =: ND_S{
    0528ParamTHeadT,
}02_11OBJTFFDS_GET_,528Flags_PORT,
    0528ClockPal_POrup_PORTraI_TRAVAR__M NDIS_INTERRUP_ACi =repr(C)]5#[derive(Clone, Copy)]50528struct GEN nsFype: _RESERVV2tUPDO1 0528StatusTed: I_TRA802_11 _RESERVV2tUPDO1_ 0528ClockPaPv4AHA802_11 _RESERVV2tUPDO1_00528ClockPaPv4ESPA802_11 _RESERVV2tUPDO1_1repr(C)]5#[derive(Clone, Copy)]50528struct GEN nsFype: _RESERVV2tUPDO1u0 0528Outbou_bitsupld
}5#[repr(C)]5#[derive(Clone, Copy)]50528struct I_TRACOA2_N _RESERVV2tUPDO1_1 0528Outbou_bitsupld
}5#[repr(C)]5#[derive(Clone, Copy)]50528struct I_TRACOA2_N _RESERVV2tUPDO1_2 0528Event: ncapsulaI_TRAV   0528AnonymohEspCombinT,
    0528Authenitted: I_TuORT,CombinT,
    0528AuthenaPv4OPI_TRs
    0528ClassIPORT,
}5#[repr(C)]5#[deriveature_AC"Win32_Networking_WiManagryPas_Hand"erive(Clone, Copy)]50528struct I_TRACOA2_N _CURR__{
    0528LockStHeadT,
}02_11OBJTFFDS_GET_,528Flags_PORT,
    0528ClockPapOpTraI_TRal: I_TRA802_11 _CURR__{
  USrepr(C)]5#[deriveature_AC"Win32_Networking_WiManagryPas_Hand"erive(Clone, Copy)]50528struct I_TRACOA2_N _CURR__{
  US 0528AddressFamily_PORT,
    0528MajorVOpTraI_TRal: I_TRA8:super::super::Win32::Networking::WManagryPasorkandork_ST_FCURR__{
  USre28MajorVOpTraI_TRal: I_TRPORT,
}5#[repr(C)]5#[deriveature_AC"Win32_Networking_WiManagryPas_Hand"erive(Clone, Copy)]50528struct I_TRACOA2_N _CURR__{
  US{
    0528BSS
p:HeadT,
}02_11OBJTFFDS_GET_,528Flags_PORT,
    0528ClockPOfItemofsFamily_PORTRT,ReC"WnT,
    0528AuthenapOpTraI_TRal: I_TRA8[OA2_N _CURR__{
  US
}5#[repr(C)]5#[derive(Clone, Copy)]50528struct I_TRA802_11IRDAX_OID_ST_i = 0528Event: xtraBOFs
    0528MinorVersT"WnArion_ORT,
}5#[repr(C)]5#[deriveature_AC"Win32_Networking_WiManagryPas_Hand"erive(Clone, Copy)]50528struct I_TRACOA2_NID_F_ ND_S{
    0528ParamTHeadT,
}02_11OBJTFFDS_GET_,528Flags_odes_ateCexPO16,
 :super::super::Win32::Networking::WManagryPasorkandork_ST_FCDt O_FDUPLEX_{
   0528XXXDB_PmitLink super:   0528KeyMatRcvLink super:   0528KeyMatPauseFuncI_TRs
 st OID_ATPAUSERFUNOLASTP_ACi =0528AutoInitiaNegotId: O1PORT,
}5#[repr(C)]5#[derive(Clone, Copy)]50528struct I_TRA802_11ID_F_{
    0528OutbouPmitLink super:   0528KeyMatRcvLink super:   05pr(C)]5#[deriveature_AC"Win32_Networking_WiManagryPas_Hand"erive(Clone, Copy)]50528struct I_TRACOA2_NID_F_{
    0528LockStHeadT,
}02_11OBJTFFDS_GET_,528Flags_odes_CoORTctPO16,
 :super::super::Win32::Networking::WManagryPasorkandork_ST_FCDt O_FI_SMTDI_{
   0528XXXDB_odes_ateCexPO16,
 :super::super::Win32::Networking::WManagryPasorkandork_ST_FCDt O_FDUPLEX_{
   0528XXXDB_PmitLink super:   0528KeyMatRcvLink super:   0528KeyMatPauseFuncI_TRs
 st OID_ATPAUSERFUNOLASTP_ACi =0528AutoInitiaNegotId: O1PORT,
}5#[reprpe I_TRAIS_PHY_INIT_N_A{
    e;5#[repr(C)]5#[derivel(feature_AC"Wdk_Foundation", feature_AC"Win32_Stem_SystemServices")]5#[dure_AC"Win32_System_Kernel"))]5#[derive(Clone, Copy)]50528struct I_TRA_VENT__INIT_N_A_MSAR 0528Timestamp:rr::super::System::SystemServices::DMAIOIK_MSAR0528DmaChanpcr::super::Foundation_:K_VENT,DPC0528Miniport_P*mutamp:rFuncI_TR: PVENT__MSARASTP_ACi 0528Miniport_P*mutamp:rCoOtext880re::ffi::c_void,
    0528Miniport_P*mut880re::S_PHY_INIT_N_A{
   ,528NextEntryOamp:rr:0re::S_PHY_INIT_N_A_MSAR05prpe I_TRAIS_PHY__FO_TAPI{
    e;5#[repr(C)]5#[derive(Clone, Copy)]50528struct I_TRA_VENT_OBJTFFDS_GET_ 0528TimestaRT,
  80528ReceivedvPORT,
}580528Size_PORT,
  #[repr(C)]5#[derive(Clone, Copy)]50528struct I_TRA802_11RVV2tUP 0528LockStHeadT,
}02_11OBJTFFDS_GET_,528Flags_umPacket
}02_11SK_D _CCHECKSUM1RVV2tUP0528Length_soV1
}02_11SK_DLARGEI_MAC_RVV2tUPDO10528AuthenaPsecV1
}02_11 _RESERVV2tUPDO10528Length_soV2
}02_11SK_DLARGEI_MAC_RVV2tUPDO20528Flags_PORT,
}5#[repr(C)]5#[derive(Clone, Copy)]50528struct I_TRA802_11RVDring: ND_ADMIN_ 0528LockStHeadT,
}02_11OBJTFFDS_GET_,528Flags_aPv4umPacket
}580528Size_PSK_aPv4umPacket
}580528Size_PUDPaPv4umPacket
}580528Size_PSK_aPv6umPacket
}580528Size_PUDPaPv6umPacket
}580528Size_P_soV1
}580528Size_PaPsecV1
}580528Size_P_soV2aPv4
}580528Size_P_soV2aPv6
}580528Size_PScpCoORTct O16Pv4
}580528Size_PScpCoORTct O16Pv6
}580528Size_PPORT,
}5#[reprpe I_TRAIS_PHYHA_FD{
    e;5#[repr(C)]5#[derivel(fee_AC"Win32_Networking_WiManagryPas_Hand"erive(Clone, Copy)]50528struct I_TRACOA2_NURR__{
    0528LockStHeadT,
}02_11OBJTFFDS_GET_,528Flags_OpTraI_TRal: I_TRA8:super::super::Win32::Networking::WManagryPasorkandork_ST_FCURR__{
  USre28MajorVOpTraI_TRal: I_TRPORT,
}5#[repr(C)]5#[derive(Clone, Copy)]50528struct I_TRACOA2_N_OID_ST8021QT_i = 0528Event:lone, Copy
    0_OID_ST8021QT_i =#[repr(C)]5#[derive(Clone, Copy)]50528union I_TRAND_FDD_OID_ST8021QT_i =#[ 0528TimestaagHeadT,
}02_11_OID_ST8021QT_i =#[_00528ClockPValue880re::ffi::c_void,
}5#[repr(C)]5#[derive(Clone, Copy)]50528struct BSS
pu02_11_OID_ST8021QT_i =#[_0 0528Outbou_bitsupld
}5#[repr(C)]5#[derive(Clone, Copy)]50528struct I_TRACOA2_NPCI: O_TA_DDUSTOMTMYtUPDOIE_ 0528LockStHeadT,
}02_11OBJTFFDS_GET_,528Flags_DescriORT,
    0528AnonymtAPAddr supeA_Psuper:   0528AnonymtAPAddrPayloadORT,
    0528ClassIMaxPayloadORT,
    0528ClassIMaxme_Pt: [I_TORT,
    0528ClassInAPAddrLink super:   0528ClassInAPAddrLinkPsuper:   0528ClassIMaxLink super:   0528ClassIMaxLinkPsuper:   0528ClassIPciExpmilyn_PORT,
    0528NumCanal_POrup_ORT,
    0528AnonymMaxal_POrup_Pilyagr,
}5#[reprpe I_TRAIS_PHYPDMT_SETet: NND = 500re::ffi::c_void,
}5#[;rpe I_TRAIS_PHYPDMOReset: NND = 500re::ffi::c_void,
}5#[;rpe I_TRAIS_PHYPDMND SHUTDD NND = 500re::ffi::c_void,
}5#[;r(C)]5#[derive(Clone, Copy)]50528struct I_TRACOA2_NPNDIS_PHYC_T_MUS{UNI  0528Event:Physicals: [u8; 6   0528Decryp_PORT,
    05pr(C)]5#[derive(Clone, Copy)]50528struct I_TRACOA2_NPM1_OID_STPATset  0528DemandPriorit,
    0528MajorVRess::per:   0528ClassIMaskORT,
    0528ClassIn_PORT,_PORT,
    0528ClassIn_PORT,ORT,
    0528ClassIn_PORT,PORT,
}5#[repr(C)]5#[derive(Clone, Copy)]50528struct I_TRACOA2_N_M_WLA_CUPCONFIG_CAPABI 0528MapRegiinMagicInfo: WakeUp:ified: N_802_DI_SM_ACi =0528Miniport_n_PORT,WakeUp:ified: N_802_DI_SM_ACi =0528Miniport_Linkl_POgeWakeUp:ified: N_802_DI_SM_ACi =05pr(C)]5#[derive(Clone, Copy)]50528struct I_TRACOA2_N_NPCONFIG_CAPABI 0528MapRegPORT,
    0528ClockPWakeUplities_PO16,
}OA2_N_M_WLA_CUPCONFIG_CAPABIreprpe I_TRAIS_PHYPOLLD NND = 500re::ffi::c_void,
}5#[;r(C)]5#[derivel(fee_AC"Win32_Networking_WiManagryPas_Hand"erive(Clone, Copy)]50528struct I_TRACOA2_NT_N_ 0528NextEntryOr:0re::S_PHYT_N_,528NdisAfHandRess::per:0re::ffi::c_void,
    0528Miniport_P*mutRess::per:0re::ffi::c_void,
    0528MinipoProtocolRess::per:0re::ffi::c_void,
    0528MinipoPmutl_Prac_P[ustic,
}OA2_N_NDIS_ER_802_1SACisi05pr(C)]5#[deriveature_AC"Win32_Networking_WiManagryPas_Hand"erive(Clone, Copy)]50528struct I_TRACOA2_NRRAYADMIN_ 0528LockStHeadT,
}02_11OBJTFFDS_GET_,528Flags_OfItems_Pmuts
    0528OffsetResponFirstORT,
    0528DmaChat_OP_V8ORT,
    0528ClassInmuts
 [OA2_N_NDIS_ER_802_1SACisi}5#[repr(C)]5#[derive(Clone, Copy)]50528struct I_TRA802_11 NDORIZAI1_AUT_VENT, ND_ADMIN_ 0528LockStHeadT,
}02_11OBJTFFDS_GET_,528Flags_erUsCoOtrolPO16,
 OID _ONDIS_TDI_SM_ACi =0528KeyMatRcvCoOtrolPO16,
 OID _ONDIS_TDI_SM_ACi =0528KeyMaterUsticaorizaI_TRPO16,
 OID _ONDISIZAI_SMTDI_SM_ACi =0528KeyMatRcvticaorizaI_TRPO16,
 OID _ONDISIZAI_SMTDI_SM_ACi =05pr(C)]5#[deriveature_AC"Win32_Networking_WiManagryPas_Hand"erive(Clone, Copy)]50528struct I_TRACOA2_NRRAYATER_802_1SACisiz0528LockStHeadT,
}02_11OBJTFFDS_GET_,528Flags_nmutOfItem
    0528ClassIPORT,
}5#[re28TimestaRT,
 OID RT_N_ACi =,528Flags_odes_CoORTctPO16,
 :super::super::Win32::Networking::WManagryPasorkandork_ST_FCDt O_FI_SMTDI_{
   0528XXXDB_PmitLink super:   0528KeyMatRcvLink super:   0528KeyMatDirecI_TR: :super::super::Win32::Networking::WManagryPasorkandork_ST_FCOID_FD_SM_Ci =,528Flags_erUsCoOtrolPO16,
 OID _ONDIS_TDI_SM_ACi =0528KeyMatRcvCoOtrolPO16,
 OID _ONDIS_TDI_SM_ACi =0528KeyMaterUsticaorizaI_TRPO16,
 OID _ONDISIZAI_SMTDI_SM_ACi =0528KeyMatRcvticaorizaI_TRPO16,
 OID _ONDISIZAI_SMTDI_SM_ACi =05pr(C)]5#[deriveature_AC"Win32_Networking_WiManagryPas_Hand"erive(Clone, Copy)]50528struct I_TRACOA2_NRRAYA{
    0528LockStHeadT,
}02_11OBJTFFDS_GET_,528Flags_odes_CoORTctPO16,
 :super::super::Win32::Networking::WManagryPasorkandork_ST_FCDt O_FI_SMTDI_{
   0528XXXDB_PmitLink super:   0528KeyMatRcvLink super:   0528KeyMatDirecI_TR: :super::super::Win32::Networking::WManagryPasorkandork_ST_FCOID_FD_SM_Ci =,528Flags_erUsCoOtrolPO16,
 OID _ONDIS_TDI_SM_ACi =0528KeyMatRcvCoOtrolPO16,
 OID _ONDIS_TDI_SM_ACi =0528KeyMaterUsticaorizaI_TRPO16,
 OID _ONDISIZAI_SMTDI_SM_ACi =0528KeyMatRcvticaorizaI_TRPO16,
 OID _ONDISIZAI_SMTDI_SM_ACi =0528Size_PPORT,
}5#[reprpe I_TRAIS_PHYOLIKEEPSo{
    e;5#[repr(C)]5#[derive(Clone, Copy)]50528struct I_TRA_VENT_TMVCSBA_EN_PO ND_S{
    0528ParamTHeadT,
}02_11OBJTFFDS_GET_,528Flags_PORT,
    0528ClockPHashation_P[u8; 1   0528ClockPHashSecretKeyORT,
  #[re28ClockPHashSecretKey_PORT,
    05}r(C)]5#[derive(Clone, Copy)]50528struct I_TRA_VENT_TMVCSBA_S_PHECONFIG_CAPABI 0528MapRegHeadT,
}02_11OBJTFFDS_GET_,528Flags_uities_PO16,PORT,
    0528ClockPOfItemOfal_POrup_Pilyagr,
}5#[re28ClockPOfItemOfedFrameQueues
    05}r(C)]5#[derive(Clone, Copy)]50528struct I_TRA_VENT_TMVCSBA_S_PHEC ND_S{
    0528ParamTHeadT,
}02_11OBJTFFDS_GET_,528Flags_PORT,
    0528Buffer:aseCpuOfItem
  #[re28ClockPHashation_P[u8; 1   0528ClockPIndirecI_TRTunt_ORT,
  #[re28ClockPIndirecI_TRTunt__PORT,
    0528ClassIHashSecretKeyORT,
  #[re28ClockPHashSecretKey_PORT,
    05}r(C)]5#[derive(Clone, Copy)]50528struct I_TRA_VENT_TW_
    0528MapReglone, Cop1
}02_11TW_
   _00528ClockPlone, Cop2
}02_11TW_
   _1repr(C)]5#[derive(Clone, Copy)]50528union I_TRAND_FDDTW_
   _0 0528Event:lone, Copy
    0TW_
   _0_00528ClockPRess::per:6],
}5#[repr(C)]5#[derive(Clone, Copy)]50528struct CORT_P    0TW_
   _0_0 0528StatusTpt_LET_O u    0528YYYDB_CoOtext880re::ffi::c_void,
    05pr(C)]5#[derive(Clone, Copy)]50528union I_TRAND_FDDTW_
   _1 0528ReadTimefPi64,
}[D_FDDTW_
   _REFT_SET
}5#[re28ReadTimefPi64,Exr:6]32;= 50],528Event:lone, Copy
    0TW_
   _1#[repr(C)]5#[derive(Clone, Copy)]50528union  CORT_P    0TW_
   _1u0 0528OutboumefPi64,LET_O u    0528YYYDB_S_PredmefPi64,
}   0528ClockPWri_POWaPO1ngr::super::super::Win32::Foundation_:BOOLEAN,
}5#[repr(C)]5#[cfg(fe(Clone, Copy)]50528union I_TRAND_FDDTW_
   _REFT_SET 0528ReadTimefPi64,
}   0528ClockPcacheLiner:6],
}5#[repr(C)]5#[derive(Clone, Copy)]50528struct CORT_P    0SMUUM_    0528MapRegTpt_LET_O u    0528YYYDB_l_PO8,
}5#[repr(C)]5#[derive(Clone, Copy)]50528struct tOID_8    0S2_1S{
   {
    0528BSS
p:HeadT,
}02_11OBJTFFDS_GET_,528Flags_Ted: I_TRPO16ustic,
}   0528ClockPifalDiscardsr:   0528KeyMatifal_Pi64,
    0528KeyMatifHCInOc_Pt,
    0528KeyMatifHCInUceivPkt,
    0528KeyMatifHCInastReceivPkt,
    0528KeyMatifHCInBroadceivPkt,
    0528KeyMatifHCOutOc_Pt,
    0528KeyMatifHCOutUceivPkt,
    0528KeyMatifHCOutastReceivPkt,
    0528KeyMatifHCOutBroadceivPkt,
    0528KeyMatifOut_Pi64,
    0528KeyMatifOutDiscardsr:   0528KeyMatifHCInUceivOc_Pt,
    0528KeyMatifHCInastReceivOc_Pt,
    0528KeyMatifHCInBroadceivOc_Pt,
    0528KeyMatifHCOutUceivOc_Pt,
    0528KeyMatifHCOutastReceivOc_Pt,
    0528KeyMatifHCOutBroadceivOc_Pt,
    05pr(C)]5#[derive(Clone, Copy)]50528struct tOID_8    0S2_1S{
   {C_TVX 0528Outbounid
    0528StringBINA_PORT,
    0528KeyMatDu8; 1],
}5#[repr(C)]5#[derive(Clone, Copy)]50528struct I_TRA802_11S2_1S{
   {C_TVX    0528Numbernid
    0528StringBINA_PORT,
    0528KeyMat_PORT,
    0528KeyMatDu8; 1],
}5#[repr(C)]5#[derive(Clone, Copy)]50528struct I_TRA802_11SK_DI_SMTDI_SM_RVV2tUP 0528LockStHeadT,
}02_11OBJTFFDS_GET_,528Flags_ ncapsulaI_TRAV   0528Anonym_bitsupld
}5#[re28Size_PScpCoORTct O1_POloaduiticit,
    0528MajorVPORT,
}5#[repr(C)]5#[derive(Clone, Copy)]50528struct I_TRACOA2_NSK_D _CCHECKSUM1RVV2tUP 0528IntegerPv4it: super:OA2_NSK_D _CCHECKSUM1RVV2tUP_1,528Flags_aPv4e: super:OA2_NSK_D _CCHECKSUM1RVV2tUP_00528ClockPaPv6it: super:OA2_NSK_D _CCHECKSUM1RVV2tUP_30528ClockPaPv6e: super:OA2_NSK_D _CCHECKSUM1RVV2tUP_[repr(C)]5#[derive(Clone, Copy)]50528struct I_TRACOA2_NSK_D _CCHECKSUM1RVV2tUP   0528EthDB_PncapsulaI_TRAV   0528Anonym_bitsupld
}5#[repr(C)]5#[derive(Clone, Copy)]50528struct I_TRACOA2_NSK_D _CCHECKSUM1RVV2tUP 1 0528EthDB_PncapsulaI_TRAV   0528Anonym_bitsupld
}5#[repr(C)]5#[derive(Clone, Copy)]50528struct I_TRACOA2_NSK_D _CCHECKSUM1RVV2tUP 2 0528EthDB_PncapsulaI_TRAV   0528Anonym_bitsupld
}5#[repr(C)]5#[derive(Clone, Copy)]50528struct I_TRACOA2_NSK_D _CCHECKSUM1RVV2tUP 3 0528EthDB_PncapsulaI_TRAV   0528Anonym_bitsupld
}5#[repr(C)]5#[derive(Clone, Copy)]50528struct I_TRACOA2_NSK_D _CCHECKSUM1_OID_ST_i = 0528Event:lone, Copy
    0SK_D _CCHECKSUM1_OID_ST_i =#[repr(C)]5#[derive(Clone, Copy)]50528union I_TRAND_FDDSK_D _CCHECKSUM1_OID_ST_i =#[ 0528Transmit: super:D_FDDSK_D _CCHECKSUM1_OID_ST_i =#[_1,528Flags_e: super:OA2_NSK_D _CCHECKSUM1_OID_ST_i =#[_00528ClockPValue885#[repr(C)]5#[derive(Clone, Copy)]50528struct I_TRACOA2_NSK_D _CCHECKSUM1_OID_ST_i =#[_0 0528Outbou_bitsupld
}5#[repr(C)]5#[derive(Clone, Copy)]50528struct I_TRACOA2_NSK_D _CCHECKSUM1_OID_ST_i =#[_1 0528Outbou_bitsupld
}5#[repr(C)]5#[derive(Clone, Copy)]50528struct I_TRACOA2_NSK_DLARGEI_MAC_RVV2tUPDO1 0528IntegerPv4
}02_11SK_DLARGEI_MAC_RVV2tUPDO1#[repr(C)]5#[derive(Clone, Copy)]50528union  CORT_P    0SK_DLARGEI_MAC_RVV2tUPDO1#[ 0528EthDB_PncapsulaI_TRAV   0528AnonymMax_POLoadORT,
    0528ClassIMinSeount_Pi64,
    0528Anonym_bitsupld
}5#[repr(C)]5#[derive(Clone, Copy)]50528struct I_TRACOA2_NSK_DLARGEI_MAC_RVV2tUPDO2 0528IntegerPv4
}02_11SK_DLARGEI_MAC_RVV2tUPDO2_00528ClockPaPv6
}02_11SK_DLARGEI_MAC_RVV2tUPDO2_1repr(C)]5#[derive(Clone, Copy)]50528struct I_TRACOA2_NSK_DLARGEI_MAC_RVV2tUPDO2#[ 0528EthDB_PncapsulaI_TRAV   0528AnonymMax_POLoadORT,
    0528ClassIMinSeount_Pi64,
    05pr(C)]5#[derive(Clone, Copy)]50528struct I_TRACOA2_NSK_DLARGEI_MAC_RVV2tUPDO2#1 0528EthDB_PncapsulaI_TRAV   0528AnonymMax_POLoadORT,
    0528ClassIMinSeount_Pi64,
    0528Anonym_bitsupld
}5#[repr(C)]5#[derive(Clone, Copy)]50528struct I_TRACOA2_NSIMEOUT_DPCDI8RT_N_AONFIG_CAPABI 0528MapRegHeadT,
}02_11OBJTFFDS_GET_,528Flags_PORT,
}5#[re28Timesta_PORT,Arrah_PORT,
    0528KeyMata_PORT,Arrahr:6]32;= ]repr(C)]5#[cfg(all(feature_AC"Wdk_Foundation", feature_AC"Win32_Stem_SystemServices")]5#[dure_AC"Win32_System_Kernel"))]5#[derive(Clone, Copy)]50528struct I_TRA_VENT__MSAR 0528Timestamp:rr::super::System::SystemServices::DMAIOIK_MSAR0528DmaChanpcr::super::Foundation_:K_VENT,DPC05pr(C)]5#[derive(Clone, Copy)]50528struct I_TRACOA2_NSIMEI_MAC_PMIT__CAPABI 0528MapRegHeadT,
}02_11OBJTFFDS_GET_,528Flags_HardwdesrecisORT,uencyHz
    0528KeyMatCrossamp: [u8; 8:super::super::Win32::Foundation_:BOOLEAN,
    0528DmaWidRess::pe1
    0528KeyMatRess::pe2
    0528KeyMatamp: [u8;PORT,
}OA2_NSIMEI_MAC_PMIT__CAPYtritIS05pr(C)]5#[derive(Clone, Copy)]50528struct I_TRACOA2_NSIMEI_MAC_PMIT__CAPYtritIS 0528DemandPtpV2OverUdpaPv4EsupeMsge: supeHw 8:super::super::Win32::Foundation_:BOOLEAN,
    0528DmaWidPtpV2OverUdpaPv4AllMsge: supeHw 8:super::super::Win32::Foundation_:BOOLEAN,
    0528DmaWidPtpV2OverUdpaPv4EsupeMsgit: supeHw 8:super::super::Win32::Foundation_:BOOLEAN,
    0528DmaWidPtpV2OverUdpaPv4AllMsgit: supeHw 8:super::super::Win32::Foundation_:BOOLEAN,
    0528DmaWidPtpV2OverUdpaPv6EsupeMsge: supeHw 8:super::super::Win32::Foundation_:BOOLEAN,
    0528DmaWidPtpV2OverUdpaPv6AllMsge: supeHw 8:super::super::Win32::Foundation_:BOOLEAN,
    0528DmaWidPtpV2OverUdpaPv6EsupeMsgit: supeHw 8:super::super::Win32::Foundation_:BOOLEAN,
    0528DmaWidPtpV2OverUdpaPv6AllMsgit: supeHw 8:super::super::Win32::Foundation_:BOOLEAN,
    0528DmaWidAlle: supeHw 8:super::super::Win32::Foundation_:BOOLEAN,
    0528DmaWidAllit: supeHw 8:super::super::Win32::Foundation_:BOOLEAN,
    0528DmaWidTaggedit: supeHw 8:super::super::Win32::Foundation_:BOOLEAN,
    0528DmaWidAlle: supeSw 8:super::super::Win32::Foundation_:BOOLEAN,
    0528DmaWidAllit: supeSw 8:super::super::Win32::Foundation_:BOOLEAN,
    0528DmaWidTaggedit: supeSw 8:super::super::Win32::Foundation_:BOOLEAN,
    05pr(C)]5#[derive(Clone, Copy)]50528struct I_TRACOA2_NAC_OID_,
     0528Length_PO16,
    0528BufferMaximum_PO16,
    0528Buffer_PORT,
  }5#[repr(C)]5#[derive(Clone, Copy)]50528struct GEN nsAN QUAT_MFRAGMEET 0528ReadTimemotes: [u8; 6],
}5#[re28LockStateals: [u8; 6],
}5#[repr(C)]5#[derive(Clone, Copy)]50528struct I_TRA802_11AT_MI_SO_CALL 0528LockStateals: [u8; 6],
}5#[re28Buffer:ytesSeT,
    0528BIS
pInytesRcvd
}5#[re28Size_Pount_sSeT,
    0528BIS
pIount_sRcvd
}5#[re28Size_PCRC_Pi64,
    0528KeyMata_PORT,_Pi64,
    0528KeyMatAlignunt__Pi64,
    0528KeyMatSP[u8;Overrun_Pi64,
    0528KeyMatounting_Pi64,
    0528KeyMat: *mutOverrun_Pi64,
    0528KeyMatnytesittedFrameCUncompmilyper:   0528ClassInytesRdFrameCUncompmilyper:   0528ClassInytesittedFrameCCompmilyper:   0528ClassInytesRdFrameCCompmilyper:   05pr(C)]5#[derive(Clone, Copy)]50528struct I_TRA802_11AT_MLINEGET__ 0528ReadTimemotes: [u8; 6],
}5#[re28LockStateals: [u8; 6],
}5#[repr(C)]5#[derive(Clone, Copy)]50528struct I_TRA802_11AT_MLINEGU  0528Length_ink super:   0528ClassIMaximumTotaPORT,
    0528ulUUIDQualit,
 AN QUAT_MA_ACi =0528KeyMaterUs: ORT,
    0528Responsemotes: [u8; 6],
}5#[re28LockStateals: [u8; 6],
}5#[re28MinipoProtocolList: IPORT,
    0528ParametrotocolList: 880re::580528Size_PtrotocolORT,
    0528ResponDescriNamer::super::super::Win32::Foundation_:UNI_I_P_STst O,
    05pr(C)]5#[derive(Clone, Copy)]50528struct I_TRA802_11AT_MOLIKEEPSo
    0528Flags_PORT,
    0528ClockPRess::per:   05pr(C)]5#[derive(Clone, Copy)]50528struct I_TRA802_11AS
p_EX; 1 0528Length_PORT,
    0528KeyIndMacs: [u8; 6],
}5#[re28MinipoRess::per:6],
}#[re28ReadTi[u8; 302_11dSS
p_{
   0528Size_Ptrivac,
    0528MajorVRssiA85#[re28NetworkType_P[I_TInUsRA802_11dIS_HAR02RT_N; 1],
0528YYYDB_CoOfiguraI_TRAVAR__MdI_FDDI_PATH_C_FHS{
re28ClockPInfra I_TRA"Wisuper:02_11d OID_802INFRAOFDUI_SMT_ACi =,528Flags_Ted: I_TRRORT,
 ],
    05pr(C)]5#[derive(Clone, Copy)]50528struct I_TRA802_11AS
p_EX; 1    0528Number_PORT,
    0528KeyIndMacs: [u8; 6],
}5#[re28MinipoRess::per:6],
}#[re28ReadTi[u8; 302_11dSS
p_{
   0528Size_Ptrivac,
    0528MajorVRssiA85#[re28NetworkType_P[I_TInUsRA802_11dIS_HAR02RT_N; 1],
0528YYYDB_CoOfiguraI_TRAVAR__MdI_FDDI_PATH_C_FHS{
re28ClockPInfra I_TRA"Wisuper:02_11d OID_802INFRAOFDUI_SMT_ACi =,528Flags_Ted: I_TRRORT,
 ],
  1#[re28Minipoth_PORT,
    0528OffsetRT,
}],
}5#[repr(C)]5#[deriveature_AC"Win32_Networking_WiManagryPas_Hand"erive(Clone, Copy)]50528struct I_TRACOA2_NWMI_ENUM_ADAP    0528ParameHeadT,
}02_11OBJTFFDS_GET_,528Flags_afPORT,
    0528KeyLenkinLindow:super::super::Win32::Networking::WManagryPasorkandork_STL28GuLH0528ResponDescriName_PO16,
    0528BufferDescriNamer:[i
}5#[repr(C)]5#[deriveature_AC"Win32_Networking_WiManagryPas_Hand"erive(Clone, Copy)]50528struct I_TRACOA2_NWMI_E}5#[DS_GET_ 0528TimestHeadT,
}02_11OBJTFFDS_GET_,528Flags_afPORT,
    0528KeyLenkinLindow:super::super::Win32::Networking::WManagryPasorkandork_STL28GuLH0528RespontIEs_PORer:   0528KeyMatPmutOfItem
    0528ClassIDescriName_PO16,
    0528ClassIDescriName_PORT,
    0528ClassIn_nfo: 
}],
}54 05pr(C)]5#[derive(Clone, Copy)]50528struct I_TRA802_11AMI_ _RESERVV2tUPDO1 0528StatusTed: I_TRA802_11AMI_ _RESERVV2tUPDO1_ 0528ClockPaPv4AHA802_11AMI_ _RESERVV2tUPDO1_00528ClockPaPv4ESPA802_11AMI_ _RESERVV2tUPDO1_105pr(C)]5#[derive(Clone, Copy)]50528struct I_TRA802_11AMI_ _RESERVV2tUPDO1#[ 0528EthDB_Md5
    0528KeyMatSha_1
    0528Authenitted: I_
    0528AutheniuORT,
}5#[re28KeyMaterUs
    0528ClockPRe super:   05pr(C)]5#[derive(Clone, Copy)]50528struct I_TRA802_11AMI_ _RESERVV2tUPDO1_1 0528DemandMos
    0528MajorVRess::per:   0528ClassITrtryCDr,
}5#[re28ClockPOfllEsp
    0528Authenitted: I_
    0528AutheniuORT,
}5#[re28KeyMaterUs
    0528ClockPRe super:   05pr(C)]5#[derive(Clone, Copy)]50528struct I_TRA802_11AMI_ _RESERVV2tUPDO1_2 0528Event: ncapsulaI_TRAV   0528AnonymohEspCombinT,
    0528Authenitted: I_TuORT,CombinT,
    0528AuthenaPv4OPI_TRs
    0528ClassIPORT,
}5#[repr(C)]5#[deriveature_AC"Win32_Networking_WiManagryPas_Hand"erive(Clone, Copy)]50528struct I_TRACOA2_NAMI_METHODDS_GET_ 0528TimestHeadT,
}02_11OBJTFFDS_GET_,528Flags_PmutOfItem
    0528ClassIkinLindow:super::super::Win32::Networking::WManagryPasorkandork_STL28GuLH0528RespontIEs_PORer:   0528KeyMatt_PORT,
    0528ulDevCn_nfo: 
}],
}54 05pr(C)]5#[derive(Clone, Copy)]50528struct I_TRA802_11AMI_RVV2tUP 0528LockStHeadT,
}02_11OBJTFFDS_GET_,528Flags_umPacket
}02_11AMI_SK_D _CCHECKSUM1RVV2tUP0528Length_soV1
}02_11AMI_SK_DLARGEI_MAC_RVV2tUPDO10528AuthenaPsecV1
}02_11AMI_ _RESERVV2tUPDO10528Length_soV2
}02_11AMI_SK_DLARGEI_MAC_RVV2tUPDO 0528MajorVPORT,
}5#[repr(C)]5#[derive(Clone, Copy)]50528struct I_TRACOA2_NAMI_RUTPUT{
    0528BSS
p:HeadT,
}02_11OBJTFFDS_GET_,528Flags_PORT,
    0528ClockPTed: I_TRRdvPORT,
}580528Size_PDu8;_PORT,
    05}r(C)]5#[deriveature_AC"Win32_Networking_WiManagryPas_Hand"erive(Clone, Copy)]50528struct I_TRACOA2_NAMI_SETDS_GET_ 0528TimestHeadT,
}02_11OBJTFFDS_GET_,528Flags_PmutOfItem
    0528ClassIkinLindow:super::super::Win32::Networking::WManagryPasorkandork_STL28GuLH0528RespontIEs_PORer:   0528KeyMatt_PORT,
    0528ulDevCn_nfo: 
}],
}54 05pr(C)]5#[derive(Clone, Copy)]50528struct I_TRACOA2_NAMI_SK_DI_SMTDI_SM_RVV2tUP 0528LockStHeadT,
}02_11OBJTFFDS_GET_,528Flags_ ncapsulaI_TRAV   0528AnonymTed: I_6Pv4
}5  0528AnonymTed: I_6Pv6
}5  0528AnonymTed: I_6Pv6ExtenORT,HeadT,,
    0528ClockPTed: I_SaT_O u#[re28Size_PScpCoORTct O1_POloaduiticit,
    0528MajorVPORT,
}5#[repr(C)]5#[derive(Clone, Copy)]50528struct I_TRACOA2_NAMI_SK_D _CCHECKSUM1RVV2tUP 0528IntegerPv4it: super:OA2_NAMI_SK_D _CCHECKSUM1RVV2tUP_1,528Flags_aPv4e: super:OA2_NAMI_SK_D _CCHECKSUM1RVV2tUP_00528ClockPaPv6it: super:OA2_NAMI_SK_D _CCHECKSUM1RVV2tUP_30528ClockPaPv6e: super:OA2_NAMI_SK_D _CCHECKSUM1RVV2tUP_[repr(C)]5#[derive(Clone, Copy)]50528struct I_TRACOA2_NAMI_SK_D _CCHECKSUM1RVV2tUP#[ 0528EthDB_PncapsulaI_TRAV   0528AnonymapOpI_TRsted: ORT,
    0528AuthenScpOpI_TRsted: ORT,
    0528AuthenScpumPacket
}5  0528AuthenUdpumPacket
}5  0528AuthenIpumPacket
}5  05pr(C)]5#[derive(Clone, Copy)]50528struct I_TRACOA2_NAMI_SK_D _CCHECKSUM1RVV2tUP#1 0528EthDB_PncapsulaI_TRAV   0528AnonymapOpI_TRsted: ORT,
    0528AuthenScpOpI_TRsted: ORT,
    0528AuthenScpumPacket
}5  0528AuthenUdpumPacket
}5  0528AuthenIpumPacket
}5  05pr(C)]5#[derive(Clone, Copy)]50528struct I_TRACOA2_NAMI_SK_D _CCHECKSUM1RVV2tUP#2 0528EthDB_PncapsulaI_TRAV   0528AnonymapExtenORT,HeadT,,ted: ORT,
    0528AuthenScpOpI_TRsted: ORT,
    0528AuthenScpumPacket
}5  0528AuthenUdpumPacket
}5  05pr(C)]5#[derive(Clone, Copy)]50528struct I_TRACOA2_NAMI_SK_D _CCHECKSUM1RVV2tUP#3 0528EthDB_PncapsulaI_TRAV   0528AnonymapExtenORT,HeadT,,ted: ORT,
    0528AuthenScpOpI_TRsted: ORT,
    0528AuthenScpumPacket
}5  0528AuthenUdpumPacket
}5  05pr(C)]5#[derive(Clone, Copy)]50528struct I_TRACOA2_NAMI_SK_DLARGEI_MAC_RVV2tUPDO1 0528IntegerPv4
}02_11AMI_SK_DLARGEI_MAC_RVV2tUPDO1#[repr(C)]5#[derive(Clone, Copy)]50528union  CORT_P    0AMI_SK_DLARGEI_MAC_RVV2tUPDO1#[ 0528EthDB_PncapsulaI_TRAV   0528AnonymMax_POLoadORT,
    0528ClassIMinSeount_Pi64,
    0528AnonymScpOpI_TRsAV   0528AnonymapOpI_TRs
}5  05pr(C)]5#[derive(Clone, Copy)]50528struct I_TRACOA2_NAMI_SK_DLARGEI_MAC_RVV2tUPDO2 0528IntegerPv4
}02_11AMI_SK_DLARGEI_MAC_RVV2tUPDO2_00528ClockPaPv6
}02_11AMI_SK_DLARGEI_MAC_RVV2tUPDO2_105pr(C)]5#[derive(Clone, Copy)]50528struct I_TRACOA2_NAMI_SK_DLARGEI_MAC_RVV2tUPDO2#[ 0528EthDB_PncapsulaI_TRAV   0528AnonymMax_POLoadORT,
    0528ClassIMinSeount_Pi64,
    05pr(C)]5#[derive(Clone, Copy)]50528struct I_TRACOA2_NAMI_SK_DLARGEI_MAC_RVV2tUPDO2_1 0528EthDB_PncapsulaI_TRAV   0528AnonymMax_POLoadORT,
    0528ClassIMinSeount_Pi64,
    0528AnonymapExtenORT,HeadT,,ted: ORT,
    0528AuthenScpOpI_TRsted: ORT,
    05pr(C)]5#[derive(Clone, Copy)]50528struct I_TRACOA2_NAFRAOFTEM 0528CapabiloOtext880re::ffi::c_void,
    0528MinipoRRT,iner:S_PHYOLIC0528ClockPWrapin3Ress::per:6],
}5#[reprpe I_TRAIS_PHYWRAPPTDD NND = 505#[repr(C)]5#[derive(Clone, Copy)]50528struct I_TRA_V2INFRAOC_T_MUS 0528AddressFamily_PO16,
    0528BuffersFamilyORT,
    0528Respons: [u8; 6],
}5#[repr(C)]5#[derive(Clone, Copy)]50528struct I_TRA802INFRAOC_T_MUSD _ 0528Addressin_: I_
  #[re28ClockPINOC_T_
    0528Authensin_zero
 ],
    05pr(C)]5#[derive(Clone, Copy)]50528struct I_TRA802INFRAOC_T_MUSD _6 0528Addressin6_: I_
  #[re28ClockPsin6_Olowi_TRAV   0528Authensin6__nfr
 ],16    0528Beaconsin6_scope_i,
    05pr(C)]5#[derive(Clone, Copy)]50528struct I_TRACO2INFRAOC_T_MUSD _  0528NumberOing::Ws: [u8; 6   0528Non_Bcasdes: [u8; 6],
}5#[re28LockStSofo: 
  #[repr(C)]5#[derive(Clone, Copy)]50528struct I_TRA802INFRAOC_T_MUSD
    0528Versios: [u8;Pi64,
}5  0528AnonymoFamilyORT,
    0528Respons: [u8; 6]02INFRAOC_T_MUS}50528type I_TRAAFULLMOReset 505#[repr(C)]5#[derive(Clone, Copy)]50528struct I_TRA_RVV2tUPDALGO{
    0528BSS
p:algoIdtionfiem
    0528ClassIalgoKeylen
    0528ClassIalgoRion_s
}5  05pr(C)]5#[derive(Clone, Copy)]50528struct I_TRACRVV2tUPD _RESEC_T_SA 0528StatusTrcs: [
    0528ClockPTrcMask
    0528ClassIDests: [
    0528ClockPDestMask
    0528ClassItrotocol
    0528ClockPTrcP I_
  #[re28ClockPDestP I_
  #[re28ClockPTrcTuORT,s: [
    0528ClockPDestTuORT,s: [
    0528ClockPPORT,
    0528BufferNumSA; 6 #[re28ClockPTecAssoc 6]RVV2tUPDRESURAPYtASSOCIA1],
}53]0528Buffer_POloadakeFler::super::super::Win32::Foundation_:UNI_I_ NND =0528KeyLength_PO
    0528KeyMaterial_ 6],
}5#[repr(C)]5#[derive(Clone, Copy)]50528struct I_TRA8RVV2tUPD _RESEC_T_UDPESP_SA 0528StatusTrcs: [
    0528ClockPTrcMask
    0528ClassIDsts: [
    0528ClockPDstMask
    0528ClassItrotocol
    0528ClockPTrcP I_
  #[re28ClockPDstP I_
  #[re28ClockPTrcTuORT,s: [
    0528ClockPDstTuORT,s: [
    0528ClockPPORT,
    0528BufferNumSA; 6 #[re28ClockPTecAssoc 6]RVV2tUPDRESURAPYtASSOCIA1],
}53]0528Buffer_POloadakeFler::super::super::Win32::Foundation_:UNI_I_ NND =0528KeyLenPncapORT,s_POy:8RVV2tUPD _RESEUDPESP_ENCAP_MUS{ENTRY0528KeyLenPncapORT,s_POy_POldakeFler::super::super::Win32::Foundation_:UNI_I_ NND =0528KeyLength_PO
    0528KeyMaterial_ 6],
}5#[repr(C)]5#[derive(Clone, Copy)]50528struct I_TRA8RVV2tUPD _RESEDELETE_SA 0528Status_POloadakeFler::super::super::Win32::Foundation_:UNI_I_ NND =05pr(C)]5#[derive(Clone, Copy)]50528struct I_TRA8RVV2tUPD _RESEDELETE_UDPESP_SA 0528Status_POloadakeFler::super::super::Win32::Foundation_:UNI_I_ NND =0528KeyLenPncapORT,s_POy_POldakeFler::super::super::Win32::Foundation_:UNI_I_ NND =05pr(C)]5#[derive(Clone, Copy)]50528struct I_TRA8RVV2tUPD _RESEUDPESP_ENCAP_MUS{ENTRY 0528StatusUdpPncapORT,:PUDP_ENCAP 1],
0528YYYDB_DstPncapP I_
  #[repr(C)]5#[derive(Clone, Copy)]50528struct I_TRA8RVV2tUPDRESURAPYtASSOCIA1],
 0528Status_pTraI_TRAVRVV2tUPDtUPD_VENT,
re28ClockPTPI
    0528NumCanal_Pgrit,Algo:_RVV2tUPDALGO{
   0528YYYDB_CoOfAlgo:_RVV2tUPDALGO{
   0528YYYDB_Ress::per:RVV2tUPDALGO{
   05pr(C)]5#[derive(Clone, Copy)]50528struct I_TRA8I_I_TDOTE; 1],
 0528Status [u8; 6],
}5#[re28MajorVPORT,
}5#[repr(C)]5#[derive(Clone, Copy)]50528struct I_TRACREFERENCE 0528MapRegTpt_LET_O u    0528YYYDB_Referenc_Pi64,
}   0528Buffer Cos1ngr::super::super::Win32::Foundation_:BOOLEAN,
}5#[repr(C)]5#[cfg(fe(Clone, Copy)]50528union  I_TRACTRANSONDISS_GET__RVVSE  0528Event:ProtocolORT,
    0528ResponHeadT,_PORT,
  #[reprpe I_TRAATRMOReset 505#[repr(C)]5#[derive(Clone, Copy)]50528struct I_TRA_AC_O,
     0528Event:ulTotaPORT,
    0528ulUUIDulNeededORT,
    0528ulUUICallsedORT,
    0528ulUUICalData_PErrors
    0528ulUUICalData_PORT,
    0528ulUUICalData_P_PORT,
    05}rpe I_TRAACHYC_TC NDPYtCOMPLETE_ NND =t 50OpI_TR<unsafe extern "servic" fn()>;rpe I_TRAACHYANAGPI_SMTDIED_ NND =t 50OpI_TR<unsafe extern "servic" fn()>;rpe I_TRAACHYALOSEMUSACOMPLETE_ NND =t 50OpI_TR<unsafe extern "servic" fn()>;rpe I_TRAACHYALOSEMANAGPI_MPLETE_ NND =t 50OpI_TR<unsafe extern "servic" fn()>;rpe I_TRAACHYET_EG_SAPPI_MPLETE_ NND =t 50OpI_TR<unsafe extern "servic" fn()>;rpe I_TRAACHYEROPC NDPYtCOMPLETE_ NND =t 50OpI_TR<unsafe extern "servic" fn()>;rpe I_TRAACHYINCOM   MANAGP NND =t 50OpI_TR<unsafe extern "servic" fn() ->}5  >;rpe I_TRAACHYINCOM   MANAGPQOSATERNGE_ NND =t 50OpI_TR<unsafe extern "servic" fn()>;rpe I_TRAACHYINCOM   MALOSEMANAGP NND =t 50OpI_TR<unsafe extern "servic" fn()>;rpe I_TRAACHYINCOM   MEROPC NDPYt NND =t 50OpI_TR<unsafe extern "servic" fn()>;rpe I_TRAACHYMLA_CANAGPI_MPLETE_ NND =t 50OpI_TR<unsafe extern "servic" fn()>;rpe I_TRAACHYMODIFYMANAGPQOSAT_MPLETE_ NND =t 50OpI_TR<unsafe extern "servic" fn()>;rpe I_TRAACHYHA_FDUSACOMPLETE_ NND =t 50OpI_TR<unsafe extern "servic" fn()>;rpe I_TRAACHY_EG_SAPPI_MPLETE_ NND =t 50OpI_TR<unsafe extern "servic" fn()>;rpe I_TRAACM_ACTIV],
_VCPI_MPLETE_ NND =t 50OpI_TR<unsafe extern "servic" fn()>;rpe I_TRAACM_A_TC NDPYt NND =t 50OpI_TR<unsafe extern "servic" fn() ->}5  >;rpe I_TRAACMYALOSEMUSA NND =t 50OpI_TR<unsafe extern "servic" fn() ->}5  >;rpe I_TRAACMYALOSEMANAGP NND =t 50OpI_TR<unsafe extern "servic" fn() ->}5  >;rpe I_TRAACMYETACTIV],
_VCPI_MPLETE_ NND =t 50OpI_TR<unsafe extern "servic" fn()>;rpe I_TRAACM_ET_EG_SAPP NND =t 50OpI_TR<unsafe extern "servic" fn() ->}5  >;rpe I_TRAACMYEROPC NDPYt NND =t 50OpI_TR<unsafe extern "servic" fn() ->}5  >;rpe I_TRAACMYINCOM   MANAGPI_MPLETE_ NND =t 50OpI_TR<unsafe extern "servic" fn()>;rpe I_TRAACM_MLA_CANAGP NND =t 50OpI_TR<unsafe extern "servic" fn() ->}5  >;rpe I_TRAACMYMODIFYMANAGPQOSA NND =t 50OpI_TR<unsafe extern "servic" fn() ->}5  >;rpe I_TRAACMYHA_FDUSA NND =t 50OpI_TR<unsafe extern "servic" fn() ->}5  >;rpe I_TRAACMY_EG_SAPP NND =t 50OpI_TR<unsafe extern "servic" fn() ->}5  >;rpe I_TRAACODUSA_EGISset:NOTIFYM NND =t 50OpI_TR<unsafe extern "servic" fn()>;rpe I_TRAACO_CRE],
_VCP NND =t 50OpI_TR<unsafe extern "servic" fn() ->}5  >;rpe I_TRAACODDELETE_VCP NND =t 50OpI_TR<unsafe extern "servic" fn() ->}5  >;rpe I_TRAA_INIT_N_ACODUCTIV],
_VC 50OpI_TR<unsafe extern "servic" fn(mt_P*mutvccoOtext880coOs::ffi::c_void,
    0 callpaunt_tT,,
 0re::CO_CNAGP ND_S{
   ) ->}5  >;rpe I_TRAA_INIT_N_ACODCRE],
_VC 50OpI_TR<unsafe extern "servic" fn(mt_P*mutaObjectcoOtext880coOs::ffi::c_void,
    0 ndisvchkeFler:0coOs::ffi::c_void,
    0 mt_P*mutvccoOtext880re::0re::ffi::c_void,
    ) ->}5  >;rpe I_TRAA_INIT_N_ACODETACTIV],
_VC 50OpI_TR<unsafe extern "servic" fn(mt_P*mutvccoOtext880coOs::ffi::c_void,
    ) ->}5  >;rpe I_TRAA_INIT_N_ACODETLETE_VC 50OpI_TR<unsafe extern "servic" fn(mt_P*mutvccoOtext880coOs::ffi::c_void,
    ) ->}5  >;rpe I_TRAAS_PHYOLIC 50OpI_TR<unsafe extern "servic" fn()>;rpe I_TRAAS_PHYOLIC_CNAGBA   e;OpI_TR<unsafe extern "servic" fn(g::Wiyste80coOs::OA2_NAFRAOFTEM0 coOtext880coOs::ffi::c_void,
    )>;rpe I_TRAAS_PHY_MSARASTP_ACi  e;OpI_TR<unsafe extern "servic" fn(servicsed: suc1r:0coOs::ffi::c_void,
    0 funcI_TRcoOtext880coOs::ffi::c_void,
    0 servicsed: suc2880coOs::ffi::c_void,
    0 servicsed: suc3880coOs::ffi::c_void,
    )>;rpe I_TRAAPS_PHY_MSARASTP_ACi  e;OpI_TR<unsafe extern "servic" fn()>;rpe I_TRAAPROTEPSo
ODUSA_EGISset:NOTIFY e;OpI_TR<unsafe extern "servic" fn()>;rpe I_TRAAPROTEEPSo
HYC_TC NDPYtCOMPLETE e;OpI_TR<unsafe extern "servic" fn(saI_TRA85#[r protocolpautycoOtext880coOs::ffi::c_void,
    0 ndispautyhkeFler:0coOs::ffi::c_void,
    0 callpaunt_tT,,
 0coOs::CO_CNAGP ND_S{
   )>;rpe I_TRAAPROTEEPSo
HYANAGPI_SMTDIED e;OpI_TR<unsafe extern "servic" fn(protocolvccoOtext880coOs::ffi::c_void,
    )>;rpe I_TRAAPROTEEPSo
HYALOSEMUSACOMPLETE e;OpI_TR<unsafe extern "servic" fn(saI_TRA85#[r protocolafcoOtext880coOs::ffi::c_void,
    )>;rpe I_TRAAPROTEEPSo
HYALOSEMANAGPI_MPLETE e;OpI_TR<unsafe extern "servic" fn(saI_TRA85#[r protocolvccoOtext880coOs::ffi::c_void,
    0 protocolpautycoOtext880coOs::ffi::c_void,
    )>;rpe I_TRAAPROTEEPSo
HYET_EGISset:SAPPI_MPLETE e;OpI_TR<unsafe extern "servic" fn(saI_TRA85#[r protocolsapcoOtext880coOs::ffi::c_void,
    )>;rpe I_TRAAPROTEEPSo
HYEROPC NDPYtCOMPLETE e;OpI_TR<unsafe extern "servic" fn(saI_TRA85#[r protocolpautycoOtext880coOs::ffi::c_void,
    )>;rpe I_TRAAPROTEEPSo
HYINCOM   MANAG e;OpI_TR<unsafe extern "servic" fn(protocolsapcoOtext880coOs::ffi::c_void,
    r protocolvccoOtext880coOs::ffi::c_void,
    0 callpaunt_tT,,
 0re::CO_CNAGP ND_S{
   ) ->}5  >;rpe I_TRAAPROTEEPSo
HYINCOM   MANAGPQOSATERNGE e;OpI_TR<unsafe extern "servic" fn(protocolvccoOtext880coOs::ffi::c_void,
    0 callpaunt_tT,,
 0coOs::CO_CNAGP ND_S{
   )>;rpe I_TRAAPROTEEPSo
HYINCOM   MALOSEMANAG e;OpI_TR<unsafe extern "servic" fn(closesaI_TRA85#[r protocolvccoOtext880coOs::ffi::c_void,
    0 closedu8; 10coOs::ffi::c_void,
    0 sRT,
    )>;rpe I_TRAAPROTEEPSo
HYINCOM   MEROPC NDPY e;OpI_TR<unsafe extern "servic" fn(dropsaI_TRA85#[r protocolpautycoOtext880coOs::ffi::c_void,
    0 closedu8; 10coOs::ffi::c_void,
    0 sRT,
    )>;rpe I_TRAAPROTEEPSo
HYMLA_CANAGPI_MPLETE e;OpI_TR<unsafe extern "servic" fn(saI_TRA85#[r protocolvccoOtext880coOs::ffi::c_void,
    0 ndispautyhkeFler:0coOs::ffi::c_void,
    0 callpaunt_tT,,
 0coOs::CO_CNAGP ND_S{
   )>;rpe I_TRAAPROTEEPSo
HYMODIFYMANAGPQOSAT_MPLETE e;OpI_TR<unsafe extern "servic" fn(saI_TRA85#[r protocolvccoOtext880coOs::ffi::c_void,
    0 callpaunt_tT,,
 0coOs::CO_CNAGP ND_S{
   )>;rpe I_TRAAPROTEEPSo
HYHA_FDUSACOMPLETE e;OpI_TR<unsafe extern "servic" fn(saI_TRA85#[r protocolafcoOtext880coOs::ffi::c_void,
    0 ndisafhkeFler:0coOs::ffi::c_void,
    )>;rpe I_TRAAPROTEEPSo
HY_EGISset:SAPPI_MPLETE e;OpI_TR<unsafe extern "servic" fn(saI_TRA85#[r protocolsapcoOtext880coOs::ffi::c_void,
    0 sap
 0coOs::CO_SAP0 ndissaphkeFler:0coOs::ffi::c_void,
    )>;rpe I_TRAAPROTEEPSo
M_ACTIV],
_VCPI_MPLETE e;OpI_TR<unsafe extern "servic" fn(saI_TRA85#[r callmgrvccoOtext880coOs::ffi::c_void,
    0 callpaunt_tT,,
 0coOs::CO_CNAGP ND_S{
   )>;rpe I_TRAAPROTEEPSo
M_A_TC NDPY e;OpI_TR<unsafe extern "servic" fn(callmgrvccoOtext880coOs::ffi::c_void,
    0 callpaunt_tT,,
 0re::CO_CNAGP ND_S{
   0 ndispautyhkeFler:0coOs::ffi::c_void,
    0 callmgrpautycoOtext880re::0re::ffi::c_void,
    ) ->}5  >;rpe I_TRAAPROTEEPSo
M_ALOSEMUS e;OpI_TR<unsafe extern "servic" fn(callmgrafcoOtext880coOs::ffi::c_void,
    ) ->}5  >;rpe I_TRAAPROTEEPSo
M_ALOSEMANAG e;OpI_TR<unsafe extern "servic" fn(callmgrvccoOtext880coOs::ffi::c_void,
    0 callmgrpautycoOtext880coOs::ffi::c_void,
    0 closedu8; 10coOs::ffi::c_void,
    0 sRT,
    ) ->}5  >;rpe I_TRAAPROTEEPSo
M_ETACTIV],
_VCPI_MPLETE e;OpI_TR<unsafe extern "servic" fn(saI_TRA85#[r callmgrvccoOtext880coOs::ffi::c_void,
    )>;rpe I_TRAAPROTEEPSo
M_ET_EGISset:SAP e;OpI_TR<unsafe extern "servic" fn(callmgrsapcoOtext880coOs::ffi::c_void,
    ) ->}5  >;rpe I_TRAAPROTEEPSo
M_EROPC NDPY e;OpI_TR<unsafe extern "servic" fn(callmgrpautycoOtext880coOs::ffi::c_void,
    0 closedu8; 10coOs::ffi::c_void,
    0 sRT,
    ) ->}5  >;rpe I_TRAAPROTEEPSo
M_INCOM   MANAGPI_MPLETE e;OpI_TR<unsafe extern "servic" fn(saI_TRA85#[r callmgrvccoOtext880coOs::ffi::c_void,
    0 callpaunt_tT,,
 0coOs::CO_CNAGP ND_S{
   )>;rpe I_TRAAPROTEEPSo
M_MLA_CANAG e;OpI_TR<unsafe extern "servic" fn(callmgrvccoOtext880coOs::ffi::c_void,
    0 callpaunt_tT,,
 0re::CO_CNAGP ND_S{
   0 ndispautyhkeFler:0coOs::ffi::c_void,
    0 callmgrpautycoOtext880re::0re::ffi::c_void,
    ) ->}5  >;rpe I_TRAAPROTEEPSo
M_MODIFYMQOSATNAG e;OpI_TR<unsafe extern "servic" fn(callmgrvccoOtext880coOs::ffi::c_void,
    0 callpaunt_tT,,
 0coOs::CO_CNAGP ND_S{
   ) ->}5  >;rpe I_TRAAPROTEEPSo
M_HA_FDUS e;OpI_TR<unsafe extern "servic" fn(callmgrbinfo: coOtext880coOs::ffi::c_void,
    0 a: [u8;family
 0coOs::CO_C_T_MUSDFAMILY0 ndisafhkeFler:0coOs::ffi::c_void,
    0 callmgrafcoOtext880re::0re::ffi::c_void,
    ) ->}5  >;rpe I_TRAAPROTEEPSo
M__EG_SAP e;OpI_TR<unsafe extern "servic" fn(callmgrafcoOtext880coOs::ffi::c_void,
    0 sap
 0coOs::CO_SAP0 ndissaphkeFler:0coOs::ffi::c_void,
    0 callmgrsapcoOtext880re::0re::ffi::c_void,
    ) ->}5  >;rpe I_TRAAPROTEEPSo
ODUSA_EGISset:NOTIFY e;OpI_TR<unsafe extern "servic" fn(protocolbinfo: coOtext880coOs::ffi::c_void,
    0 a: [u8;family
 0coOs::CO_C_T_MUSDFAMILY)>;rpe I_TRAAPROTEEPSo
ODCRE],
_VC 50OpI_TR<unsafe extern "servic" fn(protocolafcoOtext880coOs::ffi::c_void,
    0 ndisvchkeFler:0coOs::ffi::c_void,
    0 protocolvccoOtext880re::0re::ffi::c_void,
    ) ->}5  >;rpe I_TRAAPROTEEPSo
ODETLETE_VC 50OpI_TR<unsafe extern "servic" fn(protocolvccoOtext880coOs::ffi::c_void,
    ) ->}5  >;rpe I_TRAATDIN_NPC NND =t 50OpI_TR<unsafe extern "servic" fn(upin3componeT,
 0coOs:::super::super::Win32::Foundation_:UNI_I_P_STst O,
    0 lown3componeT,
 0coOs:::super::super::Win32::Foundation_:UNI_I_P_STst O,
    0 binflis,
 0coOs:::super::super::Win32::Foundation_:UNI_I_P_STst O,
    0 recoOfigbist: 880coOs::ffi::c_void,
    0 recoOfigbist: sRT,
    , opTraI_TRAV   ) ->}:super::super::Win32::Foundation_:UNI_I_NT{
  US>;rpe I_TRAATDIN_EGISset:CNAGBA   e;OpI_TR<unsafe extern "servic" fn(descrinamer:0coOs:::super::super::Win32::Foundation_:UNI_I_P_STst O,
    0 tdihkeFler:0re:::super::super::Win32::Foundation_:UNI_I_ NND =) ->}:super::super::Win32::Foundation_:UNI_I_NT{
  US>;rpe I_TRAAWACODUCTIV],
_VCP NND =t 50OpI_TR<unsafe extern "servic" fn() ->}5  >;rpe I_TRAAW_CO_CRE],
_VCP NND =t 50OpI_TR<unsafe extern "servic" fn() ->}5  >;rpe I_TRAAWACODETACTIV],
_VCP NND =t 50OpI_TR<unsafe extern "servic" fn() ->}5  >;rpe I_TRAAWACODETLETE_VCP NND =t 50OpI_TR<unsafe extern "servic" fn() ->}5  >;r      