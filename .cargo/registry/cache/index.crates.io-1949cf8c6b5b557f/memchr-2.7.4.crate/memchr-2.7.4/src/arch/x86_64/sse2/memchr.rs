/*!
This module defines 128-bit vector implementations of `memchr` and friends.

The main types in this module are [`One`], [`Two`] and [`Three`]. They are for
searching for one, two or three distinct bytes, respectively, in a haystack.
Each type also has corresponding double ended iterators. These searchers are
typically much faster than scalar routines accomplishing the same task.

The `One` searcher also provides a [`One::count`] routine for efficiently
counting the number of times a single byte occurs in a haystack. This is
useful, for example, for counting the number of lines in a haystack. This
routine exists because it is usually faster, especially with a high match
count, then using [`One::find`] repeatedly. ([`OneIter`] specializes its
`Iterator::count` implementation to use this routine.)

Only one, two and three bytes are supported because three bytes is about
the point where one sees diminishing returns. Beyond this point and it's
probably (but not necessarily) better to just use a simple `[bool; 256]` array
or similar. However, it depends mightily on the specific work-load and the
expected match frequency.
*/

use core::arch::x86_64::__m128i;

use crate::{arch::generic::memchr as generic, ext::Pointer, vector::Vector};

/// Finds all occurrences of a single byte in a haystack.
#[derive(Clone, Copy, Debug)]
pub struct One(generic::One<__m128i>);

impl One {
    /// Create a new searcher that finds occurrences of the needle byte given.
    ///
    /// This particular searcher is specialized to use SSE2 vector instructions
    /// that typically make it quite fast.
    ///
    /// If SSE2 is unavailable in the current environment, then `None` is
    /// returned.
    #[inline]
    pub fn new(needle: u8) -> Option<One> {
        if One::is_available() {
            // SAFETY: we check that sse2 is available above.
            unsafe { Some(One::new_unchecked(needle)) }
        } else {
            None
        }
    }

    /// Create a new finder specific to SSE2 vectors and routines without
    /// checking that SSE2 is available.
    ///
    /// # Safety
    ///
    /// Callers must guarantee that it is safe to execute `sse2` instructions
    /// in the current environment.
    ///
    /// Note that it is a common misconception that if one compiles for an
    /// `x86_64` target, then they therefore automatically have access to SSE2
    /// instructions. While this is almost always the case, it isn't true in
    /// 100% of cases.
    #[target_feature(enable = "sse2")]
    #[inline]
    pub unsafe fn new_unchecked(needle: u8) -> One {
        One(generic::One::new(needle))
    }

    /// Returns true when this implementation is available in the current
    /// environment.
    ///
    /// When this is true, it is guaranteed that [`One::new`] will return
    /// a `Some` value. Similarly, when it is false, it is guaranteed that
    /// `One::new` will return a `None` value.
    ///
    /// Note also that for the lifetime of a single program, if this returns
    /// true then it will always return true.
    #[inline]
    pub fn is_available() -> bool {
        #[cfg(target_feature = "sse2")]
        {
            true
        }
        #[cfg(not(target_feature = "sse2"))]
        {
            false
        }
    }

    /// Return the first occurrence of one of the needle bytes in the given
    /// haystack. If no such occurrence exists, then `None` is returned.
    ///
    /// The occurrence is reported as an offset into `haystack`. Its maximum
    /// value is `haystack.len() - 1`.
    #[inline]
    pub fn find(&self, haystack: &[u8]) -> Option<usize> {
        // SAFETY: `find_raw` guarantees that if a pointer is returned, it
        // falls within the bounds of the start and end pointers.
        unsafe {
            generic::search_slice_with_raw(haystack, |s, e| {
                self.find_raw(s, e)
            })
        }
    }

    /// Return the last occurrence of one of the needle bytes in the given
    /// haystack. If no such occurrence exists, then `None` is returned.
    ///
    /// The occurrence is reported as an offset into `haystack`. Its maximum
    /// value is `haystack.len() - 1`.
    #[inline]
    pub fn rfind(&self, haystack: &[u8]) -> Option<usize> {
        // SAFETY: `rfind_raw` guarantees that if a pointer is returned, it
        // falls within the bounds of the start and end pointers.
        unsafe {
            generic::search_slice_with_raw(haystack, |s, e| {
                self.rfind_raw(s, e)
            })
        }
    }

    /// Counts all occurrences of this byte in the given haystack.
    #[inline]
    pub fn count(&self, haystack: &[u8]) -> usize {
        // SAFETY: All of our pointers are derived directly from a borrowed
        // slice, which is guaranteed to be valid.
        unsafe {
            let start = haystack.as_ptr();
            let end = start.add(haystack.len());
            self.count_raw(start, end)
        }
    }

    /// Like `find`, but accepts and returns raw pointers.
    ///
    /// When a match is found, the pointer returned is guaranteed to be
    /// `>= start` and `< end`.
    ///
    /// This routine is useful if you're already using raw pointers and would
    /// like to avoid converting back to a slice before executing a search.
    ///
    /// # Safety
    ///
    /// * Both `start` and `end` must be valid for reads.
    /// * Both `start` and `end` must point to an initialized value.
    /// * Both `start` and `end` must point to the same allocated object and
    /// must either be in bounds or at most one byte past the end of the
    /// allocated object.
    /// * Both `start` and `end` must be _derived from_ a pointer to the same
    /// object.
    /// * The distance between `start` and `end` must not overflow `isize`.
    /// * The distance being in bounds must not rely on "wrapping around" the
    /// address space.
    ///
    /// Note that callers may pass a pair of pointers such that `start >= end`.
    /// In that case, `None` will always be returned.
    #[inline]
    pub unsafe fn find_raw(
        &self,
        start: *const u8,
        end: *const u8,
    ) -> Option<*const u8> {
        if start >= end {
            return None;
        }
        if end.distance(start) < __m128i::BYTES {
            // SAFETY: We require the caller to pass valid start/end pointers.
            return generic::fwd_byte_by_byte(start, end, |b| {
                b == self.0.needle1()
            });
        }
        // SAFETY: Building a `One` means it's safe to call 'sse2' routines.
        // Also, we've checked that our haystack is big enough to run on the
        // vector routine. Pointer validity is caller's responsibility.
        //
        // Note that we could call `self.0.find_raw` directly here. But that
        // means we'd have to annotate this routine with `target_feature`.
        // Which is fine, because this routine is `unsafe` anyway and the
        // `target_feature` obligation is met by virtue of building a `One`.
        // The real problem is that a routine with a `target_feature`
        // annotation generally can't be inlined into caller code unless the
        // caller code has the same target feature annotations. Which is maybe
        // okay for SSE2, but we do the same thing for AVX2 where caller code
        // probably usually doesn't have AVX2 enabled. That means that this
        // routine can be inlined which will handle some of the short-haystack
        // cases above without touching the architecture specific code.
        self.find_raw_impl(start, end)
    }

    /// Like `rfind`, but accepts and returns raw pointers.
    ///
    /// When a match is found, the pointer returned is guaranteed to be
    /// `>= start` and `< end`.
    ///
    /// This routine is useful if you're already using raw pointers and would
    /// like to avoid converting back to a slice before executing a search.
    ///
    /// # Safety
    ///
    /// * Both `start` and `end` must be valid for reads.
    /// * Both `start` and `end` must point to an initialized value.
    /// * Both `start` and `end` must point to the same allocated object and
    /// must either be in bounds or at most one byte past the end of the
    /// allocated object.
    /// * Both `start` and `end` must be _derived from_ a pointer to the same
    /// object.
    /// * The distance between `start` and `end` must not overflow `isize`.
    /// * The distance being in bounds must not rely on "wrapping around" the
    /// address space.
    ///
    /// Note that callers may pass a pair of pointers such that `start >= end`.
    /// In that case, `None` will always be returned.
    #[inline]
    pub unsafe fn rfind_raw(
        &self,
        start: *const u8,
        end: *const u8,
    ) -> Option<*const u8> {
        if start >= end {
            return None;
        }
        if end.distance(start) < __m128i::BYTES {
            // SAFETY: We require the caller to pass valid start/end pointers.
            return generic::rev_byte_by_byte(start, end, |b| {
                b == self.0.needle1()
            });
        }
        // SAFETY: Building a `One` means it's safe to call 'sse2' routines.
        // Also, we've checked that our haystack is big enough to run on the
        // vector routine. Pointer validity is caller's responsibility.
        //
        // See note in forward routine above for why we don't just call
        // `self.0.rfind_raw` directly here.
        self.rfind_raw_impl(start, end)
    }

    /// Counts all occurrences of this byte in the given haystack represented
    /// by raw pointers.
    ///
    /// This routine is useful if you're already using raw pointers and would
    /// like to avoid converting back to a slice before executing a search.
    ///
    /// # Safety
    ///
    /// * Both `start` and `end` must be valid for reads.
    /// * Both `start` and `end` must point to an initialized value.
    /// * Both `start` and `end` must point to the same allocated object and
    /// must either be in bounds or at most one byte past the end of the
    /// allocated object.
    /// * Both `start` and `end` must be _derived from_ a pointer to the same
    /// object.
    /// * The distance between `start` and `end` must not overflow `isize`.
    /// * The distance being in bounds must not rely on "wrapping around" the
    /// address space.
    ///
    /// Note that callers may pass a pair of pointers such that `start >= end`.
    /// In that case, `0` will always be returned.
    #[inline]
    pub unsafe fn count_raw(&self, start: *const u8, end: *const u8) -> usize {
        if start >= end {
            return 0;
        }
        if end.distance(start) < __m128i::BYTES {
            // SAFETY: We require the caller to pass valid start/end pointers.
            return generic::count_byte_by_byte(start, end, |b| {
                b == self.0.needle1()
            });
        }
        // SAFETY: Building a `One` means it's safe to call 'sse2' routines.
        // Also, we've checked that our haystack is big enough to run on the
        // vector routine. Pointer validity is caller's responsibility.
        self.count_raw_impl(start, end)
    }

    /// Execute a search using SSE2 vectors and routines.
    ///
    /// # Safety
    ///
    /// Same as [`One::find_raw`], except the distance between `start` and
    /// `end` must be at least the size of an SSE2 vector (in bytes).
    ///
    /// (The target feature safety obligation is automatically fulfilled by
    /// virtue of being a method on `One`, which can only be constructed
    /// when it is safe to call `sse2` routines.)
    #[target_feature(enable = "sse2")]
    #[inline]
    unsafe fn find_raw_impl(
        &self,
        start: *const u8,
        end: *const u8,
    ) -> Option<*const u8> {
        self.0.find_raw(start, end)
    }

    /// Execute a search using SSE2 vectors and routines.
    ///
    /// # Safety
    ///
    /// Same as [`One::rfind_raw`], except the distance between `start` and
    /// `end` must be at least the size of an SSE2 vector (in bytes).
    ///
    /// (The target feature safety obligation is automatically fulfilled by
    /// virtue of being a method on `One`, which can only be constructed
    /// when it is safe to call `sse2` routines.)
    #[target_feature(enable = "sse2")]
    #[inline]
    unsafe fn rfind_raw_impl(
        &self,
        start: *const u8,
        end: *const u8,
    ) -> Option<*const u8> {
        self.0.rfind_raw(start, end)
    }

    /// Execute a count using SSE2 vectors and routines.
    ///
    /// # Safety
    ///
    /// Same as [`One::count_raw`], except the distance between `start` and
    /// `end` must be at least the size of an SSE2 vector (in bytes).
    ///
    /// (The target feature safety obligation is automatically fulfilled by
    /// virtue of being a method on `One`, which can only be constructed
    /// when it is safe to call `sse2` routines.)
    #[target_feature(enable = "sse2")]
    #[inline]
    unsafe fn count_raw_impl(
        &self,
        start: *const u8,
        end: *const u8,
    ) -> usize {
        self.0.count_raw(start, end)
    }

    /// Returns an iterator over all occurrences of the needle byte in the
    /// given haystack.
    ///
    /// The iterator returned implements `DoubleEndedIterator`. This means it
    /// can also be used to find occurrences in reverse order.
    #[inline]
    pub fn iter<'a, 'h>(&'a self, haystack: &'h [u8]) -> OneIter<'a, 'h> {
        OneIter { searcher: self, it: generic::Iter::new(haystack) }
    }
}

/// An iterator over all occurrences of a single byte in a haystack.
///
/// This iterator implements `DoubleEndedIterator`, which means it can also be
/// used to find occurrences in reverse order.
///
/// This iterator is created by the [`One::iter`] method.
///
/// The lifetime parameters are as follows:
///
/// * `'a` refers to the lifetime of the underlying [`One`] searcher.
/// * `'h` refers to the lifetime of the haystack being searched.
#[derive(Clone, Debug)]
pub struct OneIter<'a, 'h> {
    lf, it: ge_slic,Fand r Iter<'a, 'h> {
           sm8> {
    // SAoccurrences in reverse order: u8,
    > {re(enaunsafe fn count_raw_sm8> {b unsafe frc 'h>(&'a sel) -> xt(&nce  The callSAFETY: `rfind_raw` guarantees thatss vad and the
{
    / [`One::iton
/// of f           rally can't beafe {
        for AVX2 o execute `sse2anyteed to be
    ///a metho can't '
    ///' the start and end pointers.
        unsafe {
           let start = had)
   it.> xt(lf.rfin)
    to the l})
        }
 )d`, but acceptrc 'h>(&'a sel) -]) ->  The caller doesn't need )
   it.]) -> lf.rfind_raw(s, e)
  antees thatss vad and to r{
    / [`One::iton
by_byte           rally can can't beafe {
        (One::new_unchecked(nee)
    to the l

    /// R }
      None
  ), but acceptrc 'h>(&'a sel) -r do_ ant// The call(   endlSAFETY: `rfin)esn't need )
   it.r do_ ant/ tests {
   in reverse o means it can also ,
    > {re(enaunsafe fn corc 'h>(&'a sel) -> xt_: u8)&nce  The callSAFETY: `rfind_raw` guarantees thatss vad and the
{
    / [`One::iton
/// of f           rally can't beafe {
        for AVX2 o execute `sse2anyteed to be
    ///a metho can't 'r
    ///' the start and end pointers.
        unsafe {
           let start = had)
   it.> xt_: u8)lf.rfin)
    to the lr})
        }
 )d`, but a
   in reverse o;

usei}

//F revan also ,
    > {re(enaunsafe } of a single byte in a haystackporthaystack.erator implements `Douent
 ,then it ay tor retuystackthe giveort        /haystis ennumber ofaystacree distinct `f tct `bhe c `ffoobar`d convit ay tr retuystgh ted to c`0`faysta`4ow `isi5`ug)]
pub struct One(generic::One<__m128i>);Two
    }

  Two /// Create a new Tworcher that finds occurrences of the needle byte given.
    ///
    /// Thiss particular searcher is specialized to use SSE2 vector instructions
    /// that typically make it quite fast.
    ///
    /// If SSE2 is unavailable in the current environment, then `None` is
    /// returned.
    #[inline]
    pub fn new(needle: u8) -> Option<One> {
    d: *con respec    if One::is_aTwo {
            lways  // SAFETY: we check that sse2 is available above.
            unsafe { Some(One::new_unchecked(needle))lways> One {
        One(1on respec       None
        }
    }

    /// Create a new finder specific to SSE2 vectors and routines without
    /// checking that SSE2 is available.
    ///
    /// # Safety
    ///
    /// Callers must guarantee that it is safe to execute `sse2` instructions
    /// in the current environment.
    ///
    /// Note that it is a common misconception that if one compiles for an
    /// `x86_64` target, then they therefore automatically have access to SSE2
    /// instructions. While this is almost always the case, it isn't true in
    /// 100% of cases.
    #[target_feature(enable = "sse2")]
    #[inline]
    pub unsafe fn new_unchecked(needle: u8) -> One {
        One(d: *con respec    if OnTworcher t
      
    }

  Two// Returns t1on respec  e when this implementation is available in the current
    /// environment.
    ///
    /// When this is true, it is guaranteed that [`One::new`] will return
    Two// Reome` value. Similarly, when it is false, it is guaranteed that
    /// `One::new` will return a `NoTwo// Reo.
    ///
    /// Note also that for the lifetime of a single program, if this returns
    /// true then it will always return true.
    #[inline]
    pub fn is_available() -> bool {
        #[cfg(target_feature = "sse2")]
        {
            true
        }
        #[cfg(not(target_feature = "sse2"))]
        {
            false
        }
    }

    /// Return the first occurrence of one of the needle bytes in the given
    /// haystack. If no such occurrence exists, then `None` is returned.
    ///
    /// The occurrence is reported as an offset into `haystack`. Its maximum
    /// value is `haystack.len() - 1`.
    #[inline]
    pub fn find(&self, haystack: &[u8]) -> Option<usize> {
        // SAFETY: `find_raw` guarantees that if a pointer is returned, it
        // falls within the bounds of the start and end pointers.
        unsafe {
            generic::search_slice_with_raw(haystack, |s, e| {
                self.find_raw(s, e)
            })
        }
    }

    /// Return the last occurrence of one of the needle bytes in the given
    /// haystack. If no such occurrence exists, then `None` is returned.
    ///
    /// The occurrence is reported as an offset into `haystack`. Its maximum
    /// value is `haystack.len() - 1`.
    #[inline]
    pub fn find(&sellf, haystack: &[u8]) -> Option<usize> {
        // SAFETY: `rfind_raw` guarantees that if a pointer is returned, it
        // falls within the bounds of the start and end pointers.
        unsafe {
            generic::search_slice_with_raw(haystack, |s, e| {
                self.rfind_raw(s, e)
            })
        }
    }

    /// Counts all occurrences of td returns raw pointers.
    ///
    /// When a match is found, the pointer returned is guaranteed to be
    /// `>= start` and `< end`.
    ///
    /// This routine is useful if you're already using raw pointers and would
    /// like to avoid converting back to a slice before executing a search.
    ///
    /// # Safety
    ///
    /// * Both `start` and `end` must be valid for reads.
    /// * Both `start` and `end` must point to an initialized value.
    /// * Both `start` and `end` must point to the same allocated object and
    /// must either be in bounds or at most one byte past the end of the
    /// allocated object.
    /// * Both `start` and `end` must be _derived from_ a pointer to the same
    /// object.
    /// * The distance between `start` and `end` must not overflow `isize`.
    /// * The distance being in bounds must not rely on "wrapping around" the
    /// address space.
    ///
    /// Note that callers may pass a pair of pointers such that `start >= end`.
    /// In that case, `0` will always bs be returned.
    #[inline]
    pub unsafe fn find_raw(
        &self,
        start: *const u8,
        end: *const u8,
    ) -> Option<*const u8> {
        if start >= end {
            return None;
        }
        if end.distance(start) < __m128i::BYTES {
            // SAFETY: We require the caller to pass valid start/end pointers.
            return generic::fwd_byte_by_byte(start, end, |b| {
                b == self.0.needle1()
            });
        }
 ||        });
       2}
        // SAFETY: Building a `One` means it's safe to calre fse2' routines.
        // Also, we've checked that our haystack is big enough to run on the
        // vector routine. Pointer validity is caller's responsibility.
        //
        // Note that we could call `self.0.find_raw` directly here. But that
        // means we'd have to annotate this routine with `target_feature`.
        // Which is fine, because this routine is `unsafe` anyway and the
        // `target_feature` obligation is met by virtue of building a `One`.
        // The real pre fem is that a routine with a `target_feature`
        // annotation generally can't be inlined into caller code unless the
        // caller code has the same target feature annotations. Which is maybe
        // okay for SSE2, but we do the same thing for AVX2 where caller code
        // probably usually doesn't have AVX2 enabled. That means that this
        // routine can be inlined which will handle some of the short-haystack
        // cases above without touching the architecture specific code.
        self.find_raw_impl(start, end)
    }

    /// Like `rfind`, but accepts and returns raw pointers.
    ///
    /// When a match is found, the pointer returned is guaranteed to be
    /// `>= start` and `< end`.
    ///
    /// This routine is useful if you're already using raw pointers and would
    /// like to avoid converting back to a slice before executing a search.
    ///
    /// # Safety
    ///
    /// * Both `start` and `end` must be valid for reads.
    /// * Both `start` and `end` must point to an initialized value.
    /// * Both `start` and `end` must point to the same allocated object and
    /// must either be in bounds or at most one byte past the end of the
    /// allocated object.
    /// * Both `start` and `end` must be _derived from_ a pointer to the same
    /// object.
    /// * The distance between `start` and `end` must not overflow `isize`.
    /// * The distance being in bounds must not rely on "wrapping around" the
    /// address space.
    ///
    /// Note that callers may pass a pair of pointers such that `start >= end`.
    /// In that case, `None` will always be returned.
    #[inline]
    pub unsafe fn rfind_raw(
        &self,
        start: *const u8,
        end: *const u8,
    ) -> Option<*const u8> {
        if start >= end {
            return None;
        }
        if end.distance(start) < __m128i::BYTES {
            // SAFETY: We require the caller to pass valid start/end pointers.
            return generic::rev_byte_by_byte(start, end, |b| {
                b == self.0.needle1()
            });
        }
 ||        });
       2}
        // SAFETY: Building a `One` means it's safe to calre fse2' routines.
        // Also, we've checked that our haystack is big enough to run on the
        // vector routine. Pointer validity is caller's responsibility.
        //
        // See note in forward routine above for why we don't just call
        // `self.0.rfind_raw` directly here.
        self.rfind_raw_impl(start, end)
    }

    /// Counts all occurrences of t vectors and routines.
    ///
    /// # Safety
    ///
    /// Same as [`One::rfind_raw`], except thways)]
pub(craeen `start` and
    /// `end` must be at least the size of an SSE2 vector (in bytes).
    ///
    /// (The target feature safety obligation is automatically fulfilled by
    /// virtue of being a method on `One`, which can only be conre fcted
    /// when it is safe to call `sse2` routines.)
    #[target_feature(enable = "sse2")]
    #[inline]
    unsafe fn find_raw_impl(
        &self,
        start: *const u8,
        end: *const u8,
    ) -> Option<*const u8> {
        self.0.find_raw(start, end)
    }

    /// Execute a search using SSE2 vectors and routines.
    ///
    /// # Safety
    ///
    /// Same as [`One::rfind_raw`], except thlways)]
pub(craeen `start` and
    /// `end` must be at least the size of an SSE2 vector (in bytes).
    ///
    /// (The target feature safety obligation is automatically fulfilled by
    /// virtue of being a method on `One`, which can only be conre fcted
    /// when it is safe to call `sse2` routines.)
    #[target_feature(enable = "sse2")]
    #[inline]
    unsafe fn rfind_raw_impl(
        &self,
        start: *const u8,
        end: *const u8,
    ) -> Option<*const u8> {
        self.0.rfind_raw(start, end)
    }

  d /// Returns an iterator over all occurrences of the needle byte in the
    /// given haystsack.
    ///
    /// The iterator returned implements `DoubleEndedIterator`. This means it
    /// can also be used to find occurrences in reverse order.
    #[inline]
    pub fn iter<'a, 'h>(&'a self, haystack: &'h [u8]) -> OneIter<'a, 'h> {
        Ore ter { searcher: self, ire ter ric::Iter::new(haystack) }
    }
}

/// An iterator over all occurrences of a single byte in a haystackeort        /haysts iterator implements `DoubleEndedIterator`, which means it can also be
/// used to find occurrences in reverse order.
///
/// This iterator is created by the [`One::iter`] method.
///
///lways ifetime parameters are as follows:
///
/// * `'a` refers to the lifetime of the underlying [`One`] searcher.
/// * `'h` re for to the lifetime of the haystack being searched.
#[derive(Clone, Debug)]
pub struct OneIter<'a, 'h> {
    lf, ire ter { searcher: sel<'a, 'h> {
        unsam8> {
    // SAoccurrences in reverse order: u8,
   re ter { searcher: selunt_raw_sm8> {b unsafe frc 'h>(&'a sel) -> xt(&nce  The callSAFETY: `rfind_raw` guarantees thatss vad and the
{
    / [`One::iton
/// of f           rally can't beafe {
        for AVX2 o execute `sse2anyteed to be
    ///a metho can't '
    ///' the start and end pointers.
        unsafe {
           let start = had)
   it.> xt(lf.rfin)
    to the l})
        }
 )d`, but acceptrc 'h>(&'a sel) -r do_ ant// The call(   endlSAFETY: `rfin)esn't need )
   it.r do_ ant/ tests {
   in reverse o means it can also ,
   re ter { searcher: selrc 'h>(&'a sel) -> xt_: u8)&nce  The callSAFETY: `rfind_raw` guarantees thatss vad and the
{
    / [`One::iton
/// of f           rally can't beafe {
        for AVX2 o execute `sse2anyteed to be
    ///a metho can't 'r
    ///' the start and end pointers.
        unsafe {
           let start = had)
   it.> xt_: u8)lf.rfin)
    to the lr})
        }
 )d`, but a
   in reverse o;

usei}

//F revan also ,
   re ter { searcher} of a single byte in a haystackpnt where onek.erator implements `Douent
 ,then it ay tor retuystackthe givent wh        /haystis ennumber ofaystacree distinct `f , `bhect `ohe c `ffoobar`d convit ay tr retuystgh ted to aysta`0 , `2 , `3 , `4ow `isi5`ug)]
pub struct One(generic::One<__m128i>);Tnt w
    }

  Tnt w /// Create a new Tnt whcher that finds occurrences of the needle byte given.
    ///
    /// Thiss particular searcher is specialized to use SSE2 vector instructions
    /// that typically make it quite fast.
    ///
    /// If SSE2 is unavailable in the current environment, then `None` is
    /// returned.
    #[inline]
    pub fn new(needle: u8) -> Option<One> {
    d: *con respec    on respe3    if One::is_aTnt w {
            lalways  // SAFETY: we check that sse2 is available above.
            unsafe { Some(One::new_unchecked(needle))lalways> One {
        One(1on respecon respe3       None
        }
    }

    /// Create a new finder specific to SSE2 vectors and routines without
    /// checking that SSE2 is available.
    ///
    /// # Safety
    ///
    /// Callers must guarantee that it is safe to execute `sse2` instructions
    /// in the current environment.
    ///
    /// Note that it is a common misconception that if one compiles for an
    /// `x86_64` target, then they therefore automatically have access to SSE2
    /// instructions. While this is almost always the case, it isn't true in
    /// 100% of cases.
    #[target_feature(enable = "sse2")]
    #[inline]
    pub unsafe fn new_unchecked(needle: u8) -> One {
                
    d: *co          
    2: *co          
    ,
    end:     Ornt whcher tw,
      
    }

  Tnt w// Returns t1on respecon respe3  e when this implementation is available in the current
    /// environment.
    ///
    /// When this is true, it is guaranteed that [`One::new`] will return
    Tnt w// Reome` value. Similarly, when it is false, it is guaranteed that
    /// `One::new` will return a `NoTnt w// Reo.
    ///
    /// Note also that for the lifetime of a single program, if this returns
    /// true then it will always return true.
    #[inline]
    pub fn is_available() -> bool {
        #[cfg(target_feature = "sse2")]
        {
            true
        }
        #[cfg(not(target_feature = "sse2"))]
        {
            false
        }
    }

    /// Return the first occurrence of one of the needle bytes in the given
    /// haystack. If no such occurrence exists, then `None` is returned.
    ///
    /// The occurrence is reported as an offset into `haystack`. Its maximum
    /// value is `haystack.len() - 1`.
    #[inline]
    pub fn find(&self, haystack: &[u8]) -> Option<usize> {
        // SAFETY: `find_raw` guarantees that if a pointer is returned, it
        // falls within the bounds of the start and end pointers.
        unsafe {
            generic::search_slice_with_raw(haystack, |s, e| {
                self.find_raw(s, e)
            })
        }
    }

    /// Return the last occurrence of one of the needle bytes in the given
    /// haystack. If no such occurrence exists, then `None` is returned.
    ///
    /// The occurrence is reported as an offset into `haystack`. Its maximum
    /// value is `haystack.len() - 1`.
    #[inline]
    pub fn find(&sellf, haystack: &[u8]) -> Option<usize> {
        // SAFETY: `rfind_raw` guarantees that if a pointer is returned, it
        // falls within the bounds of the start and end pointers.
        unsafe {
            generic::search_slice_with_raw(haystack, |s, e| {
                self.rfind_raw(s, e)
            })
        }
    }

    /// Counts all occurrences of td returns raw pointers.
    ///
    /// When a match is found, the pointer returned is guaranteed to be
    /// `>= start` and `< end`.
    ///
    /// This routine is useful if you're already using raw pointers and would
    /// like to avoid converting back to a slice before executing a search.
    ///
    /// # Safety
    ///
    /// * Both `start` and `end` must be valid for reads.
    /// * Both `start` and `end` must point to an initialized value.
    /// * Both `start` and `end` must point to the same allocated object and
    /// must either be in bounds or at most one byte past the end of the
    /// allocated object.
    /// * Both `start` and `end` must be _derived from_ a pointer to the same
    /// object.
    /// * The distance between `start` and `end` must not overflow `isize`.
    /// * The distance being in bounds must not rely on "wrapping around" the
    /// address space.
    ///
    /// Note that callers may pass a pair of pointers such that `start >= end`.
    /// In that case, `0` will always bs be returned.
    #[inline]
    pub unsafe fn find_raw(
        &self,
        start: *const u8,
        end: *const u8,
    ) -> Option<*const u8> {
        if start >= end {
            return None;
        }
        if end.distance(start) < __m128i::BYTES {
            // SAFETY: We require the caller to pass valid start/end pointers.
            return generic::fwd_byte_by_byte(start, end, |b| {
                b == self.0.needle1()
            });
        }
        // SAAAAAAAAA||        });
       2}
        // SAAAAAAAAA||        });
       3}
        // SAFETY: Building a `One` means it's safe to calring fse2' routines.
        // Also, we've checked that our haystack is big enough to run on the
        // vector routine. Pointer validity is caller's responsibility.
        //
        // Note that we could call `self.0.find_raw` directly here. But that
        // means we'd have to annotate this routine with `target_feature`.
        // Which is fine, because this routine is `unsafe` anyway and the
        // `target_feature` obligation is met by virtue of building a `One`.
        // The real pring fem is that a routine with a `target_feature`
        // annotation generally can't be inlined into caller code unless the
        // caller code has the same target feature annotations. Which is maybe
        // okay for SSE2, but we do the same thing for AVX2 where caller code
        // probably usually doesn't have AVX2 enabled. That means that this
        // routine can be inlined which will handle some of the short-haystack
        // cases above without touching the architecture specific code.
        self.find_raw_impl(start, end)
    }

    /// Like `rfind`, but accepts and returns raw pointers.
    ///
    /// When a match is found, the pointer returned is guaranteed to be
    /// `>= start` and `< end`.
    ///
    /// This routine is useful if you're already using raw pointers and would
    /// like to avoid converting back to a slice before executing a search.
    ///
    /// # Safety
    ///
    /// * Both `start` and `end` must be valid for reads.
    /// * Both `start` and `end` must point to an initialized value.
    /// * Both `start` and `end` must point to the same allocated object and
    /// must either be in bounds or at most one byte past the end of the
    /// allocated object.
    /// * Both `start` and `end` must be _derived from_ a pointer to the same
    /// object.
    /// * The distance between `start` and `end` must not overflow `isize`.
    /// * The distance being in bounds must not rely on "wrapping around" the
    /// address space.
    ///
    /// Note that callers may pass a pair of pointers such that `start >= end`.
    /// In that case, `None` will always be returned.
    #[inline]
    pub unsafe fn rfind_raw(
        &self,
        start: *const u8,
        end: *const u8,
    ) -> Option<*const u8> {
        if start >= end {
            return None;
        }
        if end.distance(start) < __m128i::BYTES {
            // SAFETY: We require the caller to pass valid start/end pointers.
            return generic::rev_byte_by_byte(start, end, |b| {
                b == self.0.needle1()
            });
        }
        // SAAAAAAAAA||        });
       2}
        // SAAAAAAAAA||        });
       3}
        // SAFETY: Building a `One` means it's safe to calring fse2' routines.
        // Also, we've checked that our haystack is big enough to run on the
        // vector routine. Pointer validity is caller's responsibility.
        //
        // See note in forward routine above for why we don't just call
        // `self.0.rfind_raw` directly here.
        self.rfind_raw_impl(start, end)
    }

    /// Counts all occurrences of t vectors and routines.
    ///
    /// # Safety
    ///
    /// Same as [`One::rfind_raw`], except thwnt w//]
pub(craeen `start` and
    /// `end` must be at least the size of an SSE2 vector (in bytes).
    ///
    /// (The target feature safety obligation is automatically fulfilled by
    /// virtue of being a method on `One`, which can only be conring fcted
    /// when it is safe to call `sse2` routines.)
    #[target_feature(enable = "sse2")]
    #[inline]
    unsafe fn find_raw_impl(
        &self,
        start: *const u8,
        end: *const u8,
    ) -> Option<*const u8> {
        self.0.find_raw(start, end)
    }

    /// Execute a search using SSE2 vectors and routines.
    ///
    /// # Safety
    ///
    /// Same as [`One::rfind_raw`], except thlnt w//r]
pub(craeen `start` and
    /// `end` must be at least the size of an SSE2 vector (in bytes).
    ///
    /// (The target feature safety obligation is automatically fulfilled by
    /// virtue of being a method on `One`, which can only be conring fcted
    /// when it is safe to call `sse2` routines.)
    #[target_feature(enable = "sse2")]
    #[inline]
    unsafe fn rfind_raw_impl(
        &self,
        start: *const u8,
        end: *const u8,
    ) -> Option<*const u8> {
        self.0.rfind_raw(start, end)
    }

  d /// Returns an iterator over all occurrences of the needle byte in the
    /// given haystack.
    ///
    /// The iterator returned implements `DoubleEndedIterator`. This means it
    /// can also be used to find occurrences in reverse order.
    #[inline]
    pub fn iter<'a, 'h>(&'a self, haystack: &'h [u8]) -> OneIter<'a, 'h> {
        Oring ter { searcher: self, iring ter ric::Iter::new(haystack) }
    }
}

/// An iterator over all occurrences of a single byte in a haystackent wh        /haysts iterator implements `DoubleEndedIterator`, which means it can also be
/// used to find occurrences in reverse order.
///
/// This iterator is created by the [`One::iter`] method.
///
///lalways ifetime parameters are as follows:
///
/// * `'a` refers to the lifetime of the underlying [`One`] searcher.
/// * `'h` ring for to the lifetime of the haystack being searched.
#[derive(Clone, Debug)]
pub struct OneIter<'a, 'h> {
    lf, iring ter { searcher: sel<'a, 'h> {
    ing   unsam8> {
    // SAoccurrences in reverse order: u8,
   ring ter { searcher: selunt_raw_sm8> {b unsafe frc 'h>(&'a sel) -> xt(&nce  The callSAFETY: `rfind_raw` guarantees thatss vad and the
{
    / [`One::iton
/// of f           rally can't beafe {
        for AVX2 o execute `sse2anyteed to be
    ///a metho can't '
    ///' the start and end pointers.
        unsafe {
           let start = had)
   it.> xt(lf.rfin)
    to the l})
        }
 )d`, but acceptrc 'h>(&'a sel) -r do_ ant// The call(   endlSAFETY: `rfin)esn't need )
   it.r do_ ant/ tests {
   in reverse o means it can also ,
   ring ter { searcher: selrc 'h>(&'a sel) -> xt_: u8)&nce  The callSAFETY: `rfind_raw` guarantees thatss vad and the
{
    / [`One::iton
/// of f           rally can't beafe {
        for AVX2 o execute `sse2anyteed to be
    ///a metho can't 'r
    ///' the start and end pointers.
        unsafe {
           let start = had)
   it.> xt_: u8)lf.rfin)
    to the lr})
        }
 )d`, but a
   in reverse o;

usei}

//F revan also ,
   ring ter { searcher
  2")]
  esth> m be estsd_raw` ` ansup

//*nsafe fdeis `_memchr_lidcks big!(sup

)nsafe frc est'a sel) -hy we d_Ite we check thacalsuse ests::memchr::Runn

/// An1).hy we d_i}

(        // SA|        segiven slf.0.needle1()
     dle)) The  Returns ts[0])?.i}

( iterator.crs    ()
        // SAF   ) -> Op), but acceptrc est'a sel) - iterat_Ite we check thacalsuse ests::memchr::Runn

/// An1). iterat_i}

(        // SA|        segiven slf.0.needle1()
     dle)) The  Returns ts[0])?.i}

( iterator. it(r.crs    ()
        // SAF   ) -> Op), but acceptrc est'a sel) -

    Ite we check thacalsuse ests::memchr::Runn

/// An1).

    i}

(|        segiven slf.0.needle1()
 dle)) The  Returns ts[0])?.i}

( iterator.cr -> )
        /}), but acceptrc est'a sel) -hy we d_two we check thacalsuse ests::memchr::Runn

/// An2).hy we d_i}

(        // SA|        segiven slf.0.needle1()
     ln in1m8>given s.)]
(0r.crpied()?;0.needle1()
     ln in2m8>given s.)]
(1r.crpied()?;0.needle1()
     dle))lways> O(n1on 2)?.i}

( iterator.crs    ()
        // SAF   ) -> Op), but acceptrc est'a sel) - iterat_two we check thacalsuse ests::memchr::Runn

/// An2). iterat_i}

(        // SA|        segiven slf.0.needle1()
     ln in1m8>given s.)]
(0r.crpied()?;0.needle1()
     ln in2m8>given s.)]
(1r.crpied()?;0.needle1()
     dle))lways> O(n1on 2)?.i}

( iterator. it(r.crs    ()
        // SAF   ) -> Op), but acceptrc est'a sel) -hy we d_t    
we check thacalsuse ests::memchr::Runn

/// An3).hy we d_i}

(        // SA|        segiven slf.0.needle1()
     ln in1m8>given s.)]
(0r.crpied()?;0.needle1()
     ln in2m8>given s.)]
(1r.crpied()?;0.needle1()
     ln in3m8>given s.)]
(2r.crpied()?;0.needle1()
     dle))lnt w// Retu1on 2on 3)?.i}

( iterator.crs    ()
        // SAF   ) -> Op), but acceptrc est'a sel) - iterat_t    
we check thacalsuse ests::memchr::Runn

/// An3). iterat_i}

(        // SA|        segiven slf.0.needle1()
     ln in1m8>given s.)]
(0r.crpied()?;0.needle1()
     ln in2m8>given s.)]
(1r.crpied()?;0.needle1()
     ln in3m8>given s.)]
(2r.crpied()?;0.needle1()
     dle))lnt w// Retu1on 2on 3)?.i}

( iterator. it(r.crs    ()
       