//! A Rust library for build scripts to automatically configure code based on
//! compiler support.  Code snippets are dynamically tested to see if the `rustc`
//! will accept them, rather than hard-coding specific version support.
//!
//!
//! ## Usage
//!
//! Add this to your `Cargo.toml`:
//!
//! ```toml
//! [build-dependencies]
//! autocfg = "1"
//! ```
//!
//! Then use it in your `build.rs` script to detect compiler features.  For
//! example, to test for 128-bit integer support, it might look like:
//!
//! ```rust
//! extern crate autocfg;
//!
//! fn main() {
//! #   // Normally, cargo will set `OUT_DIR` for build scripts.
//! #   std::env::set_var("OUT_DIR", "target");
//!     let ac = autocfg::new();
//!     ac.emit_has_type("i128");
//!
//!     // (optional) We don't need to rerun for anything external.
//!     autocfg::rerun_path("build.rs");
//! }
//! ```
//!
//! If the type test succeeds, this will write a `cargo:rustc-cfg=has_i128` line
//! for Cargo, which translates to Rust arguments `--cfg has_i128`.  Then in the
//! rest of your Rust code, you can add `#[cfg(has_i128)]` conditions on code that
//! should only be used when the compiler supports it.
//!
//! ## Caution
//!
//! Many of the probing methods of `AutoCfg` document the particular template they
//! use, **subject to change**. The inputs are not validated to make sure they are
//! semantically correct for their expected use, so it's _possible_ to escape and
//! inject something unintended. However, such abuse is unsupported and will not
//! be considered when making changes to the templates.

#![deny(missing_debug_implementations)]
#![deny(missing_docs)]
// allow future warnings that can't be fixed while keeping 1.0 compatibility
#![allow(unknown_lints)]
#![allow(bare_trait_objects)]
#![allow(ellipsis_inclusive_range_patterns)]

/// Local macro to avoid `std::try!`, deprecated in Rust 1.39.
macro_rules! try {
    ($result:expr) => {
        match an hard_AiEecated iT in Rust 1.t for 128-bitompliexed whilCw match a        match an ha", "han }
    }
}

#[der    :str;

///var::fmt;
use sfi),
sSt, th::fmt;
use ss::io;
use std::{use, ", Wargo}::io;
use sld.r::{Pd.r,icenhBuf}::io;
use slroit w::{Comy cd, Stdio}::#lipsis_d in Rust ocastr;

/// ync::a[buInfoATOMIC_USIZE_INIT;astr;

/// ync::a[buInfo{A[buInUsizs _Orbug)ng}::
mod e std::om_sstr;ror> {
     ::
mod upport.;astr;upport.has_port.;a
_i128)eedsocamod eedsscommon Helpl, selmpiler features.  For
//r exp`e.
#[outnot1.39ipts.
//! #   sDebug)]
eCy coive  struct Error {
 rror"
   iT inoutget":icenhBuf }
   =has_:icenhBuf }
   =has_1, i);
 :2.0, ([L }
   
//!  :error::E
sSt, th> }
   is nee:p col }
   =hasflags:2.0c<St, th> }}ommon Wargoof thiode  flagonable.0
  t.
/he ag snout ## /mmon ect i:
//s!
//! ustc-cfg=has_i128`CFG`## /mmon l automaticfile excepies`--cfg hafor has_,!
//!as_i128`CFG`.rom_str(type(n_pa     / Normalrgo:rln!("tc-cfg=has_i128` i));nimu;}}ommon Wargoof tfor  eels, sol autofor anythets!)pts.
//! # o_stdendenco the t ## /mmon ect i:
//s!
//! ustc-cfg=hanged=PATH`.


## Mi## /mmon ect int.  Ifs one
     l set 0.7ENSEor thity,dwarning8.0
    6.0n tEarlentimon of Cargo andl set `OUT_Datioy ignore
//!n or manve.rom_str(h("build.rsld.r:     / Normalrgo:rln!("tc-cfg=hanged=PATH`.


 i));ld.ru;}}ommon Wargoof tfor  eels, sol autofor anythets!)pts.
//! # o_stets!varironcfg imon oarYou fo`oarnco the t ## /mmon ect i:
//s!
//! ustc-cfg=hanged=Ped=ENV`.
  -VARi## /mmon ect int.  Ifs one
     l set 0.21ENSEor thity,dwarning8.0
    ac.en tEarlentimon of Cargo andl set `OUT_Datioy ignore
//!n or manve.rom_str(h("bui to oar:     / Normalrgo:rln!("tc-cfg=hanged=Ped=ENV`.
  - i));oaru;}}ommon C a maf t!  ` document ipressce ## /mmon # ", "hs## /mmon ", "hso_stdwith_dir(!    `match as.
  - Improom_str(!     {
 rror"
   iT inwith_dir(!    ;
    forfmt::Disprror"
   iT inmon C a maf t!  ` document ipressce #T inmoniT inmon #ilit type fors#T inmoniT inmon -version ifixed whi   with ,er rusS` whC`lity ttc`
//## MiniT inmon -vs arf the Worutnot1r rusSrsion ifixed whipror)dniT inmon -v for buildtended DIR` ttc`
/varironcfg ms astended a`cargou fo or maory #T inmoniT inom_str(!     {
 , fmt::Smut f        match self.kindvar("oar_os", "target)d iT in Rust 1.     d(e),
 mutr("target")d      ErrorKind    e),
 ha", "hae s: &'stat"no  "targe versioned!")  }
    }
}

#[deriiT inmon C a maf t!  ` document ipressce License.
versionedorutnot1 or maory #T inmoniT inmon #ilit type fors#T inmoniT inmon -version ifixed whi   with ,er rusS` whC`lity ttc`
//## MiniT inmon -vs arf the Worutnot1r rusSrsion ifixed whipror)dniT inmon -v  or`stended a`cargou fo or maory #T inmoniT inom_str("target"<T: Into<cenhBuf>>(et":iT  {
 , fmt::Smut f        match selauto8.0
  =dvar("oar_os",` whC();
    f_or_else(|| "build".o:ro(
}
      selauto8.0
 :icenhBuf =d 0.1.4o:ro(

      selauto8.0
 _ "1.1.0"
aprec(Vpport.has: &'8.0
 (&8.0
 )/ rustc  selauto
//!   =dvar("oar_os",
- 0.1"/ rustc  selon Saor oco eckinal vutnot1 or maoryustc  selauto or =d or4o:ro(

      selautonina"
aprec(fsnualtamaka(& or).m f_eha", "hae s: &'io
}
      sel_st!alta.iveet")) || alta.ns and
limi  ;copysed ()d iT in Rust 1.atch an ha", "hae s: &'stat"vutnot1ld.rstended a`cargou fo or maory"
}
      sel}rustc  selautoFormcfg::rror"
   iT in Rust 1.ahasflags:2ahasflags(&
//!  , & or)     ErrorKindoutget":iet",iT in Rust 1.ahasc:r has_,iT in Rust 1.ahasc1, i);
 :2ahasc1, i);
 ,iT in Rust 1.
//!  :e
//!  ,iT in Rust 1.is nee:pfals  }
    }
}
 rustc  selon Saor oco eckiversiondrestricti_std`.      sel_st!ac.mit_s("();
    f_or(fals )d iT in Rust 1.ac.is nee"
aprue;iT in Rust 1._st!ac.mit_s("();
    f_or(fals )d iT in Rust 1.rmally, 

 * Ap/mash ,esony
   rierein sc.emit_hT in Rust 1.ac.is nee"
afals ;mit_hT in Rust 1.autonstead o= b"nstead := "1"
//!c be uin toit_sr exp`std`\n";mit_hT in Rust 1.use, "  ;cargo
}
 (nstead ).ok(

      sel }
}

#[de }
}

#[de }
}t fac)
#[deriiT inmon Tur Rn tort (ler s or :rerrsion iy = /!
/arf the Wog a mard-codiT inmon nce,qgal ing"`aking`.`minor`".iT inom_str(stant`sion(1, i);
   &mut faking: redzs _minor: redzs  {
  cold iT in Rus {
  8.0
 _ "1.1.0">= Vpport.ha!   aking _minor, 0)
#[deriiT inmon Synamip`e.
#[ompliollowing prusSrsion_aking_minor`,!
//!asrsion_1_29`,iT inmon _stets!s or :rerrsion iis one
     t be  "1.1.0.iT inom_str(c_version(1, i);
   &mut faking: redzs _minor: redzs  {      sel_st {
  stant`sion(1, i);
  aking _minor)d iT in Rust 1.type("i{}", 1 <sion(1{}_ i));aking _minor)}
      sel}r  fn cause(&sestant<T: AsRef<[u8]>>( &mut f
//!:iT  {
 , fmt:: col f        match sel#lipsis_d in Rust oca ating that Yc ID: A[buInUsizsg::rTOMIC_USIZE_INIT;austc  selautoie"
aID.fekin_add   }Orbug)ng::d`/`nt o;ustc  selautoFormcomy cd"
aComy cdha!   & {
  8.0
 o;ustc  selcomy cdiT in Rust 1..//!("_i1cfg;-opyr")iT in Rust 1..//!(i{}", 1 <stant i));id))iT in Rust 1..//!("_i1cfg;- suc=lib")iT in Rust 1..//!("_iict-et"")iT in Rust 1..//!(& {
  outget")iT in Rust 1..//!("_itype=llvm-t"");austc  sel_stauto     
//!  (e)t {
  
//!  .as_ref()d iT in Rust 1.comy cd.//!("_iunwrap();//!(
//!  (
      sel}rustc  selcomy cd.//!s & {
  8.0
flags);austc  selcomy cd.//!("_();usein(Stdio::piped(
}
      selautoFormchts.

aprec(comy cd.spawn().m f_eha", "hae s: &'io
}
      selautoFormusein

achts.;usein 
/ke().use, s <sion(musein");austc  sel_st {
  is nee" iT in Rust 1.prec(usein cargo
}
 (b"]` is need\n").m f_eha", "hae s: &'io
}
      sel

#[de }
}prec(usein cargo
}
 (
//!.as_ref()).m f_eha", "hae s: &'io
}
      sel    (usein/ rustc  selautottps:/

aprec(chts.;w:all).m f_eha", "hae s: &'io
}
      selt fttps:/. thissi  )
#[deriiT inmon Tur sRn tort (ler othen by @robtocfg;
#[cfhen the #T inmoniT inmon shouldyou can
- 1. change**. The iexclu!s or :ror b
//s!
//! #T inmoniT inmon ```ignoreiT inmon ate autocfg;
CRATEof thtant;iT inmon ```iT inom_str(stant`rate`, by @le( &mut fopyr:     / {
  cold iT in Rus {
  mit_s(i{}", 1 <ate autocfg;
{}of thtant;" fopyr))lly,`f t_`ittexed ttp[allzeithetil9.
macro_3iT in Rust 1..
    f_or(fals )
#[deriiT inmon Emitof thiode  omplio`]` cCRATE`o_stdetant`rate`, by @le`match as.prue.iT inom_str(c_verrate`, by @le( &mut fopyr:     / {      sel_st {
  stant`rate`, by @le(the in iT in Rust 1.type("i{}", 1 <]` c i));akngle(the i)}
      sel}r  fn cause(mon Tur sRn tort (ler othen ld.rs#[cfhen the #T inmoniT inmon shouldyou can
- 1. change**. The iexclu!s or :ror b
//s!
//! #T inmoniT inmon ```ignoreiT inmon om_sstr;## M;iT inmon ```iT inom_str(stant`ld.rs &mut fld.r:     / {
  cold iT in Rus {
  mit_s(i{}", 1 <om_sstr;{};));ld.ru).
    f_or(fals )
#[deriiT inmon Emitof thiode  omplio`]` c## Mio_stdetant`endencatch as.prue.iT inmoniT inmon Anyusiveation wicialarising sy ttc`
//endencxtremelywith your owniT inmon `_`y ttc`
/ by the Dehiode  ompli.iT inom_str(c_ver"std::ptr &mut fld.r:     / {      sel_st {
  stant`ld.rsld.rin iT in Rust 1.type("i{}", 1 <]` c i));akngle(ld.ru)}
      sel}r  fn cause(mon Emitofler othen `e.
#[omplio_stdetant`endencatch as.prue.iT inom_str(c_ver"std::ptr &mut fld.r:     );nim:     / {      sel_st {
  stant`ld.rsld.rin iT in Rust 1.type(nimu;}     sel}r  fn cause(mon Tur sRn tort (ler othen ameter#[cfhen the #T inmoniT inmon shouldyou can
- 1. change**. The iexclu!s or :ror b
//s!
//! #T inmoniT inmon ```ignoreiT inmon om_sameterPtant:iTRAIT + Slzeit{}iT inmon ```iT inom_str(stant`d::all &mut fopyr:     / {
  cold iT in Rus {
  mit_s(i{}", 1 <om_sameterPtant:i{}o+ Slzeit{{}}" fopyr))iT in Rust 1..
    f_or(fals )
#[deriiT inmon Emitof thiode  omplio`]` cTRAITio_stdetant`ametencatch as.prue.iT inmoniT inmon Anyusiveation wicialarising sy ttc`
/ameter`opyrncxtremelywith your owniT inmon `_`y ttc`
/ by the Dehiode  ompli.iT inom_str(c_ver"stdd::all &mut fopyr:     / {      sel_st {
  stant`d::allthe in iT in Rust 1.type("i{}", 1 <]` c i));akngle(the i)}
      sel}r  fn cause(mon Emitofler othen `e.
#[omplio_stdetant`ametencatch as.prue.iT inom_str(c_ver("std::all &mut fopyr:     );nim:     / {      sel_st {
  stant`d::allthe in iT in Rust 1.type(nimu;}     sel}r  fn cause(mon Tur sRn tort (ler othen asucc#[cfhen the #T inmoniT inmon shouldyou can
- 1. change**. The iexclu!s or :ror b
//s!
//! #T inmoniT inmon ```ignoreiT inmon om_sasuccPtant

aTYPE;iT inmon ```iT inom_str(stant`mat!("&mut fopyr:     / {
  cold iT in Rus {
  mit_s(i{}", 1 <om_sasuccPtant

a{};));opyr))iT in Rust 1..
    f_or(fals )
#[deriiT inmon Emitof thiode  omplio`]` cTYPEio_stdetant`asucncatch as.prue.iT inmoniT inmon Anyusiveation wicialarising sy ttc`
/asucc`opyrncxtremelywith your owniT inmon `_`y ttc`
/ by the Dehiode  ompli.iT inom_str(c_ver"stddat!("&mut fopyr:     / {      sel_st {
  stant`dat!(the in iT in Rust 1.type("i{}", 1 <]` c i));akngle(the i)}
      sel}r  fn cause(mon Emitofler othen `e.
#[omplio_stdetant`asucncatch as.prue.iT inom_str(c_ver(suc::all &mut fopyr:     );nim:     / {      sel_st {
  stant`dat!(the in iT in Rust 1.type(nimu;}     sel}r  fn cause(mon Tur sRn tort (ler othen ns.

- 0.1c#[cfhen the #T inmoniT inmon shouldyou can
- 1. change**. The iexclu!s or :ror b
//s!
//! #T inmoniT inmon ```ignoreiT inmon om_str(stant()d lauto_

aR IM; }iT inmon ```iT inom_str(stant`ns.

- 0.1l &mut fns.
:     / {
  cold iT in Rus {
  mit_s(i{}", 1 <om_str(stant()d  lauto_

a{}; }}" f{
   )iT in Rust 1..
    f_or(fals )
#[deriiT inmon Emitofler othen `e.
#[omplio_stdetant`n` and `emitatch as.prue.iT inom_str(c_vern_cfg` to testl &mut fns.
:     );nim:     / {      sel_st {
  stant`ns.

- 0.1l{
     iT in Rust 1.type(nimu;}     sel}r  fn cause(mon Tur sRn tort (ler othen expressions.

- 0.1c#[cfhen the #T inmoniT inmon shouldyou can
- 1. change**. The iexclu!s or :ror b
//s!
//! #T inmoniT inmon ```ignoreiT inmon om_sexpre "ASBE: ((e)t(ErroR IM).0;iT inmon ```iT inom_str(stant`expressil &mut fns.
:     / {
  cold iT in Rus {
  mit_s(i{}", 1 <om_sexpre "ASBE: ((e)t(Erro{}).0;" f{
   )iT in Rust 1..
    f_or(fals )
#[deriiT inmon Emitofler othen `e.
#[omplio_stdetant` and `emitatch as.prue.iT inom_str(c_vercfg` to testl &mut fns.
:     );nim:     / {      sel_st {
  stant`expressil{
     iT in Rust 1.type(nimu;}     sel}r  fn c}() {
  ngle(s:     / {
 St, th  iT ins.laris()iT in Rus.m f(|c|lf.kindc  iT in Rust 1.'A'...'Z' | 'a'...'z' | '0'...'9'e),
_,iT in Rust 1._e),
'_' }
    }
}
)iT in Rus.coll, s )c}() {
dir_
      tdd//!  (}
   
//!  :e&rror::E
sSt, th> }
   et":i&Pd.r,}
   tc-cfdd//!  get":irror::E
sSt, th> }/ {
  cold iT ind//!  iT in Rus.as_ref()iT in Rus.and_Deri(|d//!  |  iT in Rust 1. or4to'stat).and_Deri(| or|d iT in Rust 1.rmalautoFormcc-cfdd//!  get"

acc-cfdd//!  get"iT in Rust 1.rmal Rus.m f(cenhBufe s: &)iT in Rust 1.rmal Rus.
    f_or_else(|| cenhBufe s: &).unwrap());mit_hT in Rust 1.cc-cfdd//!  get".push(
//!  (
 mit_hT in Rust 1.cc-cfdd//!  get"iT in Rust 1.rmal Rus.to'stat)iT in Rust 1.rmal Rus.m f(|cc-cfdd//!  get"|. or4
      t(&cc-cfdd//!  get" )iT in Rust 1.
)iT in Rus
)iT in Rus.
    f_or(fals )
}() {
ahasflags(
//!  :e&rror::E
sSt, th>  et":i&Pd.r/ {
 .0c<St, th> Normally,St temhe Derivahas-gove/cc-cf#9601ny Ce dy 1.39.
macro55,ol autoalway 1.0.s#T inmo ODED_RUSTFLAGS` when itliabilityhost/
//!   )pts.
//! # o_nvocon't inTcense. nmo a "NOTICE"arram or
 of flags,Rn tort (Work, provarironcfg ms[buiehiode or any snmo whhe ses.e to ngs  ttc`
/rningsuts aromplio_sf

 * Ap
  -mpttherrware
abilny snmo lir Rusts`--cfg halicense DerivativASCIIed. talicenseabi(USrro0x1f.iT in_stautot fa) =dvar("oar("ODED_RUSTFLAGS` when itt)d iT in Rusatch an    .ive-mptt()d iT in Rust 1.V "ha!    iT in Rus
 elsed iT in Rust 1.a.splpe('\x1f').m f8Errorto'staad ).coll, s )c
    }
}
 r#[deriiT inmostaticunles webe provid
/kebreaore
heurir icate
  achpermitweed to ince anciand wirompliwer rus[buiehiode  oneall #T inmo#T inmo O auto      ph
   t` when itliabi)pts.mhe  $HOST` temf   oidiT inmo c neg-featur rightvarironcfg . Sad wilweed to be pro insy selmpilerny snmo when we'rei)pts.mhe inly` temf   oidf th neg-featur rightvarironcfg ,ince ancioliabinowlwee      ph
yt` when itlwhen h neg-featuruch wa` temf    #T inmo#T inmo icenithub.com/cuviper/autocfg/workflowspull/10#issuthat a
t-527575030.iT in_st*
//!   !=dvar("oar_os",inly")iT in Rus||
dir_
      tdd//!  (
//!  , et",dvar("oar_os",ODED_R $HOSTarget))iT in{ustc  sel_stautot f8.0
flags) =dvar("oar("` when itt)d iT in RusT inmo Ter deemmear modif.kindhowll set Thedlrk (and` when itlvarironcfg  oarYou f.iT in RusT inmo icenithub.com/cuviper/aahas-gove/cc-cf/blob/69aea5b6f69add7c51cca939a79644080c0b0ba.rs   cc-cf/core/features/)pts._
   ext/
//!  
    .rs#L434-L441iT in Rust 1.atch an8.0
flagsiT in Rust 1.rmal.splpe(' ')iT in Rust 1.rmal.m f8Errortri&)iT in Rust 1.rmal.filter(|s| !s.ive-mptt())iT in Rust 1.rmal.m f8Errorto'staad )iT in Rust 1.rmal.coll, s );}     sel}r  fn cause(V "h