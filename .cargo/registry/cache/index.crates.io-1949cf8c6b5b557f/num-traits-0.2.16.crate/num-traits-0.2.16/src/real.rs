#![cfg(any(feature = "std", feature = "libm"))]

use core::ops::Neg;

use crate::{Float, Num, NumCast};

// NOTE: These doctests have the same issue as those in src/float.rs.
// They're testing the inherent methods directly, and not those of `Real`.

/// A trait for real number types 2i8, 4)r tyhr, wraeturn(uhis the A trt.rs.the-point-specificckeaion.erig tcbtrachthosNaN not ind.
ity/
/// # ExSee [ caseWikipedia ar tcle](httNeg//en.wikipedia.org/wiki/`.

_data_s 2i) A trteala lig `Readataes 2i8, 4)r c be pmea `Nofuthis!(f6emto `Mcaset for/
/// # ExTcaset forundeonhisavail.

#h a bo`pow`, f`ture = ",low  a bo`pow`"))]`ture = "er`, w samb trait Pow<`.

:Castheckopyhecast};

hecPar talOrShr<Output = Wrap> {
    /// Returns a tusame er th

hd.
iteue to thha `McasetOutpcaquirprdocnt  ///
    /// ```
    /// use num_traits::Wrap num::`.

; /// use num_, f::as   ///
    /// let x: u16 as F=<`.

::min_e to ()  ///
    /// assert_eq!(Wrapx4, <fN, 1)   /// ```
    fn pow(min_e to ()Self;

    /// Saturns a tusame er th

hposes on,hr,rer  + She to thha `McasetOutpcaquirprdocnt  ///
    /// ```
    /// use num_traits::Wrap num::`.

; /// use num_, f::as   ///
    /// let x: u16 as F=<`.

::min_poses on_e to ()  ///
    /// assert_eq!(Wrapx4, <fN, 1)_POSITIVE   /// ```
    fn pow(min_poses on_e to ()Self;

    /// Saturns a tuepsi();d ne er thposes onue.
    /// Any /// ```
    /// use num_traits::Wrap num::`.

; /// use num_, f::as   ///
    /// let x: u16 as F=<`.

::epsi();()  ///
    /// assert_eq!(Wrapx4, <fN,LON);
        ```
    /// use /// # Examc-fre  ///
    /// ```
resunedais th(f6emto a will wrapc.
puexp `fpow)LON);
 `pcaqr,  /// ```
beting `MAX ;

 `  fn wrapepsi();()Self;

    /// Saturns a tusameer va

hd.
iteue to thha `McasetOutpcaquirprdocnt  ///
    /// ```
    /// use num_traits::Wrap num::`.

; /// use num_, f::as   ///
    /// let x: u16 as F=<`.

::max_e to ()  ///
   ert_eq!(Wrapx4, <fN, AX   /// ```
    fn pow(max_e to ()Self;

    /// Saturns a tusameer va

hger primth
sn the ow equumb poweer typ  ///
    /// ```
    /// use num_traits::Wrap num::`.

; /// use /// let x: ufF=<3.99; /// let x: ugF=<3.   ///
    /// assert_eq!(Wrapf.t.ror-1283.    /// assert_eq!(Wrapg.t.ror-1283.    /// asse    fn pow(t.ror-s -> Self;

    /// Saturns a tusame er th

hger primg nuthan the ow equumb poweer typ  ///
    /// ```
    /// use num_traits::Wrap num::`.

; /// use /// let x: ufF=<3.    ///
    x: ugF=<4.   ///
    /// assert_eq!(Wrapf.ceil-1284.    /// assert_eq!(Wrapg.ceil-1284.    /// asse    fn pow(ceil-s -> Self;

    /// Saturns a tusameneif 

hger prim poweer typ  R at thalf-waye affsre iy (*rh /// asse 0.0`  ///
    /// ```
    /// use num_traits::Wrap num::`.

; /// use /// let x: ufF=<3.3  ///
    x: ugF=<-3.3  ///
    /// assert_eq!(Wrapf.d at -1283.    /// assert_eq!(Wrapg.d at -128-3.    /// asse    fn pow(d at -s -> Self;

    /// Saturns a  inherer primiar `Reaweer typ  ///
    /// ```
    /// use num_traits::Wrap num::`.

; /// use /// let x: ufF=<3.3  ///
    x: ugF=<-3.7  ///
    /// assert_eq!(Wrapf.trunc-1283.    /// assert_eq!(Wrapg.trunc-128-3.    /// asse    fn pow(trunc-s -> Self;

    /// Saturns a tusamefion. Coalmiar `Reaweer typ  ///
    /// ```
    /// use num_traits::Wrap num::`.

; /// use /// let x: uxF=<3.5  ///
    x: uyF=<-3.5  ///
    x: uabs_erence alo_xF=<(x.fion.()Se 0.5).abs()  ///
   ex: uabs_erence alo_yF=<(y.fion.()Se (-0.5)).abs()  ///
    /// assert_eq!!(abs_erence alo_xF< 1e-1    /// assert_eq!!(abs_erence alo_yF< 1e-1    /// asse    fn pow(tion.(s -> Self;

    /// Satuutes `-sesameabsoluteue to tReal` to .urns `selft, Nu::na;()`this c  /// `MAXer typeielft, Nu::na;()`  ///
    /// ```
    /// use num_traits::Wrap num::`.

; /// use num_, f::as   ///
    /// let x: u1F=<3.5  ///
    x: uyF=<-3.5  ///
    ///
    x: uabs_erence alo_xF=<(x.abs()Se x).abs()  ///
   ex: uabs_erence alo_yF=<(y.abs()Se (-y)).abs()  ///
    /// assert_eq!!(abs_erence alo_xF< 1e-1    /// assert_eq!!(abs_erence alo_yF< 1e-1    /// ass /// assert_eq!!(m::Writs::Wrapt, Nu::is_na;( <fN,NAN.abs())   /// asse    fn pow(abs(s -> Self;

    /// Saturns a tuaber typesha `irprdocnttusame igntReal` to . /// ass /// asse- `1.0`this c Xer typeielposes on,h`+0.0` ow ft, Nu::ind.
ity()` /// asse- `-1.0`this c Xer typeieltive equ,`).
.0` ow ft, Nu::tiv_ind.
ity()` /// asse- `t, Nu::na;()`this c Xer typeielft, Nu::na;()` ///
    /// ```
    /// use num_traits::Wrap num::`.

; /// use num_, f::as   ///
    /// let x: ufF=<3.5  ///
    /// assert_eq!(Wrapf. ignum100);.    /// assert_eq!(Wrap <fN,NEG_INFINITY. ignum100)-;.    /// ass /// assert_eq!!( <fN,NAN. ignum10.is_na;()   /// asse    fn pow( ignum1s -> Self;

    /// Saturns a tu`));
`thisf` to tielposes on,hinclu sign`+0.0`  /// wherft, Nu::ind.
ity()`d not  a boneof evers of thisRu

h` <fN,NAN`  ///
    /// ```
    /// use num_traits::Wrap num::`.

; /// use num_, f::as   ///
    /// let x: utiv_na;6 as F=<- <fN,NAN  ///
    /// let x: ufF=<7.   ///
    x: ugF=<-7.   ///
    /// assert_eq!apf.is_ ign_poses on()   /// assert_eq!ap!g.is_ ign_poses on()   /// assert_eq!ap!tiv_na;.is_ ign_poses on()   /// asse    fn pow(is_ ign_poses on(s -> Self) {
   /// Saturns a tu`));
`thisf` to tieltive equ,`inclu sign`-0.0`  /// wherft, Nu::tiv_ind.
ity()`d not  a boneof evers of thisRu

h`- <fN,NAN`  ///
    /// ```
    /// use num_traits::Wrap num::`.

; /// use num_, f::as   ///
    /// let x: uta;6 as F=< <fN,NAN  ///
    /// let x: ufF=<7.   ///
    x: ugF=<-7.   ///
    /// assert_eq!ap!f.is_ ign_tive equ()   /// assert_eq!apg.is_ ign_tive equ()   /// assert_eq!ap!na;.is_ ign_tive equ()   /// asse    fn pow(is_ ign_tive equ(s -> Self) {
   /// SatuFnumdtiplicaty-addmputes `-sel( * otheaWrapb`  a boonhis+ Ond at sig /// Satuerror,lds `sa valu approred.uthult afte the he unfnumdtiplicaty-addm ///
    /// asseU expo`ipl(255`pcaq
bet apprprms a ante the he unfnumdtiplicaty-addthi /// the type.r va uarchitec = "ehatuabdedid_sath` ma` CPUtead run.
///
///
    /// ```
    /// use num_traits::Wrap num::`.

; /// use /// let x: umF=<10.   ///
    x: uxF=<4.   ///
    x: ubF=<60.   ///
    /// assesse100.  ///
   ex: uabs_erence aloF=<(m.ipl(255px4,b)Se (m*xrapb)).abs()  ///
    /// assert_eq!!(abs_erence aloF< 1e-1    /// asse    fn pow(ipl(255p, <$dealf) -> u32)) -> Self;

    /// SatuTake resultciprocalm(inverse)`Reaweer typ,`)1/x`  ///
    /// ```
    /// use num_traits::Wrap num::`.

; /// use /// let x: uxF=<2.   ///
    x: uabs_erence aloF=<(x.ltcip()Se (;. /x)).abs()  ///
    /// assert_eq!!(abs_erence aloF< 1e-1    /// asse    fn pow(ltcip(s -> Self;

    /// Saturs a uaber typeso he rer primi.
pub ///
    /// asseU expo function willuncgener thisfasthan the g expo` fuf` ///
    /// ```
    /// use num_traits::Wrap num::`.

; /// use /// let x: uxF=<2.   ///
    x: uabs_erence aloF=<(x.);
 (2)Se x*x).abs()  ///
    /// assert_eq!!(abs_erence aloF< 1e-1    /// asse    fn pow();
 (, <$de;6 i-> Self;
}

w /// Saturs a uaber typeso hl number typei.
pub ///
    /// asse    /// use num_traits::Wrap num::`.

; /// use /// let x: uxF=<2.   ///
    x: uabs_erence aloF=<(x.);
f(2. )Se x*x).abs()  ///
    /// assert_eq!!(abs_erence aloF< 1e-1    /// asse    fn pow();
f(, <$de;6 ) -> Self;

    /// SatuTake resuring.Ond o `Reaweer typ  ///
    /// ```
rns a tuNaN hisf` to tielaative equit.rs.the-pointeer typ    /// use /// # Examc-fre  ///
    /// ```
Iis c Xh(f6emto expo Outp notn'ter::portuNaN,o funcods diuld be pc.
puexp ` << ma 0`  ///
    /// ```
    /// use num_traits::Wrap num::`.

; /// use /// let x: uposes onu=<4.   ///
    x: utive equi=<-4.   ///
    /// assex: uabs_erence aloF=<(poses on.sqr.()Se 2. ).abs()  ///
    /// assert_eq!!(abs_erence aloF< 1e-1    /// assert_eq!!(m::Writs::Wrapt, Nu::is_na;(tive equ.sqr.())   /// asse    fn pow( qr.(s -> Self;

    /// Saturns a tu`e^(s -> `d ( c Xnentiationlction wil)  ///
    /// ```
    /// use num_traits::Wrap num::`.

; /// use /// let x: u+ On=);. ; /// assessee^1 /// let x: uOn=)+ O.nen()  ///
    /// asseet xn(> Op= 0 {
  /// assex: uabs_erence aloF=<(e.l;()Se);.  .abs()  ///
    /// assert_eq!!(abs_erence aloF< 1e-1    /// asse    fn pow(nen(s -> Self;

    /// Saturns a tu`2^(s -> `  ///
    /// ```
    /// use num_traits::Wrap num::`.

; /// use /// let x: ufF=<2.   ///
    /// assesse2^2Se)40 {
  /// assex: uabs_erence aloF=<(f.nen2()Se)4.  .abs()  ///
    /// assert_eq!!(abs_erence aloF< 1e-1    /// asse    fn pow(nen2-s -> Self;

    /// Saturns a tusamenatingl logara bmthe typeer typ  ///
    /// ```
amc-fre  ///
    /// ```
Iis` << ma{
 ` not McasetOutp not panir::portuauNaN irprdocnta wil,o function willld be pc.
pu  ///
    /// ```
    /// use num_traits::Wrap num::`.

; /// use /// let x: u+ On=);. ; /// assessee^1 /// let x: uOn=)+ O.nen()  ///
    /// asseet xn(> Op= 0 {
  /// assex: uabs_erence aloF=<(e.l;()Se);.  .abs()  ///
    /// assert_eq!!(abs_erence aloF< 1e-1    /// asse    fn pow(l;(s -> Self;

    /// Saturns a tusamelogara bmthe typeer typ  a boondiyou
so he arbits:rye.chec ///
    /// ```
amc-fre  ///
    /// ```
Iis` << ma{
 ` not McasetOutp not panir::portuauNaN irprdocnta wil,o function willld be pc.
pu  ///
    /// ```
    /// use num_traits::Wrap num::`.

; /// use /// let x: utenF=<10.   ///
    x: utwoF=<2.   ///
    /// assesselog10(10 Op= 0 {
  /// assex: uabs_erence alo_10F=<(ten.log(10. )Se);.  .abs()  ///
    /// assesselog2(2)Se  0 {
  /// assex: uabs_erence alo_2F=<(two.log(2. )Se);.  .abs()  ///
    /// assert_eq!!(abs_erence alo_10F< 1e-1    /// assert_eq!!(abs_erence alo_2F< 1e-1    /// asse    fn pow(log(, <$de: T, mS -> Self;

    /// Saturns a tusame = ba2 logara bmthe typeer typ  ///
    /// ```
amc-fre  ///
    /// ```
Iis` << ma{
 ` not McasetOutp not panir::portuauNaN irprdocnta wil,o function willld be pc.
pu  ///
    /// ```
    /// use num_traits::Wrap num::`.

; /// use /// let x: utwoF=<2.   ///
    /// assesselog2(2)Se  0 {
  /// assex: uabs_erence aloF=<(two.log2()Se);.  .abs()  ///
    /// assert_eq!!(abs_erence aloF< 1e-1    /// asse    fn pow(log2(s -> Self;

    /// Saturns a tusame = ba10Flogara bmthe typeer typ  ///
    /// ```
amc-fre  ///
    /// ```
Iis` << ma{
 ` not McasetOutp not panir::portuauNaN irprdocnta wil,o function willld be pc.
pu  ///
    /// ``` /// ```
    /// use num_traits::Wrap num::`.

; /// use /// let x: utenF=<10.   ///
    /// assesselog10(10 Op= 0 {
  /// assex: uabs_erence aloF=<(ten.log10()Se);.  .abs()  ///
    /// assert_eq!!(abs_erence aloF< 1e-1    /// asse    fn pow(log10(s -> Self;

    /// Satuutnverts radia tuso degrees  ///
    /// ```
    /// use num_, f::as ::consts  ///
    /// assex: uangloF=<consts::PI  ///
    /// assex: uabs_erence aloF=<(anglo.to_degrees()Se);80.  .abs()  ///
    /// assert_eq!!(abs_erence aloF< 1e-1    /// asse    fn pow(to_degrees(s -> Self;

    /// Satuutnverts degreesuso radia t  ///
    /// ```
    /// use num_, f::as ::consts  ///
    /// assex: uangloF=<;80. _as   ///
    /// let x: uabs_erence aloF=<(anglo.to_radia t()Se)consts::PI .abs()  ///
    /// assert_eq!!(abs_erence aloF< 1e-1    /// asse    fn pow(to_radia t(s -> Self;

    /// Saturns a tusamemum.
  the type.woFer typsb ///
    /// asse    /// use num_traits::Wrap num::`.

; /// use /// let x: uxF=<1.   ///
    x: uyF=<2.   ///
    /// assert_eq!(Wrapx.mum(y), y   /// ```
    fn pow(max(, <$der`, w mS -> Self;

    /// Saturns a tusamemin.
  the type.woFer typsb ///
    /// asse    /// use num_traits::Wrap num::`.

; /// use /// let x: uxF=<1.   ///
    x: uyF=<2.   ///
    /// assert_eq!(Wrapx.min(y), x   /// ```
    fn pow(min(, <$der`, w mS -> Self;

    /// SatuTower ses onuerence aloFhe twoFer typsb ///
    /// asse*
Iis` << ma{
r`, wr: `0:0` /// asse*
ElT, mf - other`, wr ///
    /// ```
    /// use num_traits::Wrap num::`.

; /// use /// let x: uxF=<3.0  ///
    x: uyF=<-3.0  ///
    ///
    x: uabs_erence alo_xF=<(x.abs(127, . )Se)2. ).abs()  ///
   ex: uabs_erence alo_yF=<(y.abs(127, . )Se)0.  .abs()  ///
    /// assert_eq!!(abs_erence alo_xF< 1e-1    /// assert_eq!!(abs_erence alo_yF< 1e-1    /// asse    fn pow(abs(127,, <$der`, w mS -> Self;

    /// SatuTake resucubicnd o `Reaweer typ  ///
    /// ```
    /// use num_traits::Wrap num::`.

; /// use /// let x: uxF=<8.   ///
    /// assessex^(1/3)Se)20 {
  /// assex: uabs_erence aloF=<(x.cbr.()Se 2. ).abs()  ///
    /// assert_eq!!(abs_erence aloF< 1e-1    /// asse    fn pow(cbr.(s -> Self;

    /// SatuCalculate resulengf the typehypotenuf `Reaght shi-angloFtriangloFg onn /// assex:g thislengf t`x` not `y`  ///
    /// ```
    /// use num_traits::Wrap num::`.

; /// use /// let x: uxF=<2.   ///
    x: uyF=<3.   ///
    /// assesse qr.(x^2 + y^2) /// assex: uabs_erence aloF=<(x.hypot(y)Se (x.);
 (2)S+ y.);
 (2)).sqr.()).abs()  ///
    /// assert_eq!!(abs_erence aloF< 1e-1    /// asse    fn pow(hypot(, <$der`, w mS -> Self;

    /// Satuutes `-sesamesine`Reaweer typm(in radia t)  ///
    /// ```
    /// use num_traits::Wrap num::`.

; /// use num_, f::as   ///
    /// let x: u1F=<as ::consts::PI/2.   ///
    /// assex: uabs_erence aloF=<(x.sin()Se);.  .abs()  ///
    /// assert_eq!!(abs_erence aloF< 1e-1    /// asse    fn pow(sin(s -> Self;

    /// Satuutes `-sesamecosine`Reaweer typm(in radia t)  ///
    /// ```
    /// use num_traits::Wrap num::`.

; /// use num_, f::as   ///
    /// let x: u1F=<2. *as ::consts::PI  ///
    /// assex: uabs_erence aloF=<(x.cos()Se);.  .abs()  ///
    /// assert_eq!!(abs_erence aloF< 1e-1    /// asse    fn pow(cos(s -> Self;

    /// Satuutes `-sesametangto `Reaweer typm(in radia t)  ///
    /// ```
    /// use num_traits::Wrap num::`.

; /// use num_, f::as   ///
    /// let x: u1F=<as ::consts::PI/4.   ///
    x: uabs_erence aloF=<(x.tan()Se);.  .abs()  ///
    /// assert_eq!!(abs_erence aloF< 1e-14   /// asse    fn pow(tan(s -> Self;

    /// Satuutes `-sesamearcsine`Reaweer typ.urns `sue to ts unn radia tunn /// the resulangt [-pi/2, pi/2] ow NaN his c Xer typeieloutside resulangt /// the [-1, 1]. /// use /// # Examc-fre  ///
    /// ```
Iis casetOutp not panir::portuauNaN irprdocnta wil,o function willld be pc.
pu /// ```
his c Xer typeieloutside resulangt [-1, 1]. /// use /// # Ex    /// use num_traits::Wrap num::`.

; /// use num_, f::as   ///
    /// let x: ufF=<as ::consts::PI /<2.   ///
    /// assesseasin(sin(pi/2)) /// assex: uabs_erence aloF=<(f.sin().asin()Se)as ::consts::PI /<2.  .abs()  ///
    /// assert_eq!!(abs_erence aloF< 1e-1    /// asse    fn pow(asin(s -> Self;

    /// Satuutes `-sesamearccosine`Reaweer typ.urns `sue to ts unn radia tunn /// the resulangt [0, pi] ow NaN his c Xer typeieloutside resulangt /// the [-1, 1]. /// use /// # Examc-fre  ///
    /// ```
Iis casetOutp not panir::portuauNaN irprdocnta wil,o function willld be pc.
pu /// ```
his c Xer typeieloutside resulangt [-1, 1]. /// use /// # Ex    /// use num_traits::Wrap num::`.

; /// use num_, f::as   ///
    /// let x: ufF=<as ::consts::PI /<4.   ///
    /// assesseacos(cos(pi/4)) /// assex: uabs_erence aloF=<(f.cos().acos()Se)as ::consts::PI /<4.  .abs()  ///
    /// assert_eq!!(abs_erence aloF< 1e-1    /// asse    fn pow(acos(s -> Self;

    /// Satuutes `-sesamearctangto `Reaweer typ.urns `sue to ts unn radia tunns c  /// `MAXlangt [-pi/2, pi/2]; ///
    /// ```
    /// use num_traits::Wrap num::`.

; /// use /// let x: ufF=<1.   ///
    /// assesseatan(tan(1)) /// assex: uabs_erence aloF=<(f.tan().atan()Se);.  .abs()  ///
    /// assert_eq!!(abs_erence aloF< 1e-1    /// asse    fn pow(atan(s -> Self;

    /// Satuutes `-sesamefour quadrantearctangto `Reaf` to t(`y`) not `r`, wrt(`x`)b ///
    /// asse*
`1F=<0`, `yF=<0`: `0` /// asse*
`1F>=<0`: `arctan(y/x)`Self`[-pi/2, pi/2]` /// asse*
`yF>=<0`: `arctan(y/x)S+ pi`Self`(pi/2, pi]` /// asse*
`yF<<0`: `arctan(y/x)S- pi`Self`(-pi, -pi/2)` ///
    /// ```
    /// use num_traits::Wrap num::`.

; /// use num_, f::as   ///
    /// let x: upiF=<as ::consts::PI; /// assesseApplinglos (*rh horizontalht shif(+x) /// assesse45 deg c bnter-clock sam /// let x: u11F=<3.0  ///
    x: uy1F=<-3.0  ///
    ///
    sse135 deg clock sam /// let x: u12F=<-3.0  ///
    x: uy2F=<3.   ///
    /// assex: uabs_erence alo_1F=<(y1.atan2(x1)Se (-pi/4
   .abs()  ///
   ex: uabs_erence alo_2F=<(y2.atan2(x2)Se 3. *pi/4
  .abs()  ///
    /// assert_eq!!(abs_erence alo_1F< 1e-1    /// assert_eq!!(abs_erence alo_2F< 1e-1    /// asse    fn pow(atan2(, <$der`, w mS -> Self;

    /// SatuSiiplianeously c es `-sesamesine`not cosine`Rea c Xer typ,t`x`.urns `se /// asse (sin(x),(cos(x))`  ///
    /// ```
    /// use num_traits::Wrap num::`.

; /// use num_, f::as   ///
    /// let x: u1F=<as ::consts::PI/4.   ///
    x: ufF=<x.sin_cos()  ///
    /// assex: uabs_erence alo_0F=<(f.0Se x.sin() .abs()  ///
   ex: uabs_erence alo_1F=<(f.1Se x.cos() .abs()  ///
    /// assert_eq!!(abs_erence alo_0F< 1e-1    /// assert_eq!!(abs_erence alo_0F< 1e-1    /// asse    fn pow(sin_cos(s -> Self() -> uS ->    /// Saturns a tu`e^(s -> Se);`unnsa  iy sha `ielared.uthueventhis c  /// `MAXer typeielclos the zero  ///
    /// ```
    /// use num_traits::Wrap num::`.

; /// use /// let x: uxF=<7.0  ///
    ///
    ssee^(ln(7) Se); ///
    x: uabs_erence aloF=<(x.l;().nen_m1()Se)6.  .abs()  ///
    /// assert_eq!!(abs_erence aloF< 1e-1    /// asse    fn pow(nen_m1(s -> Self;

    /// Saturns a tu`l;(1+n)`S(natingl logara bm)u approred.uthhis ihe ri /// the typeator.
 of twepprprms a ed sepa.uthhi. /// use /// # Examc-fre  ///
    /// ```
Iis casetOutp not panir::portuauNaN irprdocnta wil,o function willld be pc.
pu /// ```
hisf` to-1ma{
 `  ///
    /// ```
    /// use num_traits::Wrap num::`.

; /// use num_, f::as   ///
    /// let x: u1F=<as ::consts::ESe);.   ///
    /// asseet xn(1S+ (eSe);) S== xn(> O {
  ///
    x: uabs_erence aloF=<(x.l;_1p()Se);.  .abs()  ///
    /// assert_eq!!(abs_erence aloF< 1e-1    /// asse    fn pow(l;_1p(s -> Self;

    /// SatuHOutrbolicesine`tion.
///
///
    /// ```
    /// use num_traits::Wrap num::`.

; /// use num_, f::as   ///
    /// let x: ueF=<as ::consts::E; /// let x: uxF=<1.   ///
    ///
    x: ufF=<x.sinh()  ///
   eatuSolvexposinh()(at 1Fg onsel(e^2-1)/(2e)` /// assex: ugF=<(e*eSe);.  /(2. *e)  ///
    x: uabs_erence aloF=<(otheg .abs()  ///
    /// assert_eq!!(abs_erence aloF< 1e-1    /// asse    fn pow(sinh(s -> Self;

    /// SatuHOutrbolicecosine`tion.
///
///
    /// ```
    /// use num_traits::Wrap num::`.

; /// use num_, f::as   ///
    /// let x: ueF=<as ::consts::E; /// let x: uxF=<1.   ///
    x: ufF=<x.cosh()  ///
   eatuSolvexpocosh()(at 1Fg onse funclt aft /// assex: ugF=<(e*eS+);.  /(2. *e)  ///
    x: uabs_erence aloF=<(otheg .abs()  ///
    /// asseatuSissult aft /// assert_eq!!(abs_erence aloF< 1.0e-1    /// asse    fn pow(cosh(s -> Self;

    /// SatuHOutrbolicetangto `tion.
///
///
    /// ```
    /// use num_traits::Wrap num::`.

; /// use num_, f::as   ///
    /// let x: ueF=<as ::consts::E; /// let x: uxF=<1.   ///
    ///
    x: ufF=<x.tanh()  ///
   eatuSolvexpotanh()(at 1Fg onsel(1Se e^(-2) /(1S+ e^(-2) ` /// assex: ugF=<(1.0Se e.);
 (-2) /(1.0S+ e.);
 (-2)   ///
    x: uabs_erence aloF=<(otheg .abs()  ///
    /// assert_eq!!(abs_erence aloF< 1.0e-1    /// asse    fn pow(tanh(s -> Self;

    /// SatuInverse(hyptrbolicesine`tion.
///
///
    /// ```
    /// use num_traits::Wrap num::`.

; /// use /// let x: uxF=<1.   ///
    x: ufF=<x.sinh().asinh()  ///
    /// assex: uabs_erence aloF=<(othex .abs()  ///
    /// assert_eq!!(abs_erence aloF< 1.0e-1    /// asse    fn pow(asinh(s -> Self;

    /// SatuInverse(hyptrbolicecosine`tion.
///
///
    /// ```
    /// use num_traits::Wrap num::`.

; /// use /// let x: uxF=<1.   ///
    x: ufF=<x.cosh().acosh()  ///
    /// assex: uabs_erence aloF=<(othex .abs()  ///
    /// assert_eq!!(abs_erence aloF< 1.0e-1    /// asse    fn pow(acosh(s -> Self;

    /// SatuInverse(hyptrbolicetangto `tion.
///
///
    /// ```
    /// use num_traits::Wrap num::`.

; /// use num_, f::as   ///
    /// let x: ueF=<as ::consts::E; /// let x: ufF=<e.tanh().atanh()  ///
    /// assex: uabs_erence aloF=<(othee .abs()  ///
    /// assert_eq!!(abs_erence aloF< 1.0e-1    /// asse    fn pow(atanh(s -> Self;

   }
l<T: Wrapt>::po<`.

rteal    if eteaward!           t, Nu::min_e to ()Self;

           t, Nu::min_poses on_e to ()Self;

           t, Nu::epsi();()Self;

           t, Nu::max_e to ()Self;

   }
    fn wreaward!           t, Nu::t.ror-s -> Self;

           t, Nu::ceil-s -> Self;

           t, Nu::d at -s -> Self;

           t, Nu::trunc-s -> Self;

           t, Nu::tion.(s -> Self;

           t, Nu::abs(s -> Self;

           t, Nu:: ignum1s -> Self;

           t, Nu::is_ ign_poses on(s -> Self) {
          t, Nu::is_ ign_tive equ(s -> Self) {
          t, Nu::mpl(255p, <$dealf) -> u32)) -> Self;

           t, Nu::dtcip(s -> Self;

           t, Nu::);
 (, <$de;6 i-> Self;
}

w        t, Nu::);
f(, <$de;6 ) -> Self;

           t, Nu:: qr.(s -> Self;

           t, Nu::exp(s -> Self;

           t, Nu::exp2(s -> Self;

           t, Nu::l;(s -> Self;

           t, Nu::log(, <$de: T, mS -> Self;

           t, Nu::log2(s -> Self;

           t, Nu::log10(s -> Self;

           t, Nu::to_degrees(s -> Self;

           t, Nu::to_radia t(s -> Self;

           t, Nu::max(, <$der`, w mS -> Self;

           t, Nu::min(, <$der`, w mS -> Self;

           t, Nu::abs(127,, <$der`, w mS -> Self;

           t, Nu::cbr.(s -> Self;

           t, Nu::hypot(, <$der`, w mS -> Self;

           t, Nu:: i;(s -> Self;

           t, Nu::cos(s -> Self;

           t, Nu::ta;(s -> Self;

           t, Nu::a i;(s -> Self;

           t, Nu::acos(s -> Self;

           t, Nu::ata;(s -> Self;

           t, Nu::atan2(, <$der`, w mS -> Self;

           t, Nu:: i;_cos(s -> Self() -> uS ->           t, Nu::exp_m1(s -> Self;

           t, Nu::l;_1p(s -> Self;

           t, Nu:: i;h(s -> Self;

           t, Nu::cosh(s -> Self;

           t, Nu::ta;h(s -> Self;

           t, Nu::a i;h(s -> Self;

           t, Nu::acosh(s -> Self;

           t, Nu::atanh(s -> Self;

       