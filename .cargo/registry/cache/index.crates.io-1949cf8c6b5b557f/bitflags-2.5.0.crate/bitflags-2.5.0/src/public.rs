//! Generate the user-facing flags type.
//!
//! The code here belongs to the end-user, so new trait implementations and methods can't be
//! added without potentially breaking users.

/// Declare the user-facing bitflags struct.
///
/// This type is guaranteed to be a newtype with a `bitflags`-facing type as its single field.
#[macro_export]
#[doc(hidden)]
macro_rules! __declare_public_bitflags {
    (
        $(#[$outer:meta])*
        $vis:vis struct $PublicBitFlags:ident
    ) => {
        $(#[$outer])*
        $vis struct $PublicBitFlags(<$PublicBitFlags as $crate::__private::PublicFlags>::Internal);
    };
}

/// Implement functions on the public (user-facing) bitflags type.
///
/// We need to be careful about adding new methods and trait implementations here because they
/// could conflict with items added by the end-user.
#[macro_export]
#[doc(hidden)]
macro_rules! __impl_public_bitflags_forward {
    (
        $PublicBitFlags:ident: $T:ty, $InternalBitFlags:ident
    ) => {
        $crate::__impl_bitflags! {
            $PublicBitFlags: $T {
                fn empty() {
                    Self($InternalBitFlags::empty())
                }

                fn all() {
                    Self($InternalBitFlags::all())
                }

                fn bits(f) {
                    f.0.bits()
                }

                fn from_bits(bits) {
                    match $InternalBitFlags::from_bits(bits) {
                        $crate::__private::core::option::Option::Some(bits) => $crate::__private::core::option::Option::Some(Self(bits)),
                        $crate::__private::core::option::Option::None => $crate::__private::core::option::Option::None,
                    }
                }

                fn from_bits_truncate(bits) {
                    Self($InternalBitFlags::from_bits_truncate(bits))
                }

                fn from_bits_retain(bits) {
                    Self($InternalBitFlags::from_bits_retain(bits))
                }

                fn from_name(name) {
                    match $InternalBitFlags::from_name(name) {
                        $crate::__private::core::option::Option::Some(bits) => $crate::__private::core::option::Option::Some(Self(bits)),
                        $crate::__private::core::option::Option::None => $crate::__private::core::option::Option::None,
                    }
                }

                fn is_empty(f) {
                    f.0.is_empty()
                }

                fn is_all(f) {
                    f.0.is_all()
                }

                fn intersects(f, other) {
                    f.0.intersects(other.0)
                }

                fn contains(f, other) {
                    f.0.contains(other.0)
                }

                fn insert(f, other) {
                    f.0.insert(other.0)
                }

                fn remove(f, other) {
                    f.0.remove(other.0)
                }

                fn toggle(f, other) {
                    f.0.toggle(other.0)
                }

                fn set(f, other, value) {
                    f.0.set(other.0, value)
                }

                fn intersection(f, other) {
                    Self(f.0.intersection(other.0))
                }

                fn union(f, other) {
                    Self(f.0.union(other.0))
                }

                fn difference(f, other) {
                    Self(f.0.difference(other.0))
                }

                fn symmetric_difference(f, other) {
                    Self(f.0.symmetric_difference(other.0))
                }

                fn complement(f) {
                    Self(f.0.complement())
                }
            }
        }
    };
}

/// Implement functions on the public (user-facing) bitflags type.
///
/// We need to be careful about adding new methods and trait implementations here because they
/// could conflict with items added by the end-user.
#[macro_export]
#[doc(hidden)]
macro_rules! __impl_public_bitflags {
    (
        $BitFlags:ident: $T:ty, $PublicBitFlags:ident {
            $(
                $(#[$inner:ident $($args:tt)*])*
                const $Flag:tt = $value:expr;
            )*
        }
    ) => {
        $crate::__impl_bitflags! {
            $BitFlags: $T {
                fn empty() {
                    Self(<$T as $crate::Bits>::EMPTY)
                }

                fn all() {
                    let mut truncated = <$T as $crate::Bits>::EMPTY;
                    let mut i = 0;

                    $(
                        $crate::__bitflags_expr_safe_attrs!(
                            $(#[$inner $($args)*])*
                            {{
                                let flag = <$PublicBitFlags as $crate::Flags>::FLAGS[i].value().bits();

                                truncated = truncated | flag;
                                i += 1;
                            }}
                        );
                    )*

                    let _ = i;
                    Self::from_bits_retain(truncated)
                }

                fn bits(f) {
                    f.0
                }

                fn from_bits(bits) {
                    let truncated = Self::from_bits_truncate(bits).0;

                    if truncated == bits {
                        $crate::__private::core::option::Option::Some(Self(bits))
                    } else {
                        $crate::__private::core::option::Option::None
                    }
                }

                fn from_bits_truncate(bits) {
                    Self(bits & Self::all().bits())
                }

                fn from_bits_retain(bits) {
                    Self(bits)
                }

                fn from_name(name) {
                    $(
                        $crate::__bitflags_flag!({
                            name: $Flag,
                            named: {
                                $crate::__bitflags_expr_safe_attrs!(
                                    $(#[$inner $($args)*])*
                                    {
                                        if name == $crate::__private::core::stringify!($Flag) {
                                            return $crate::__private::core::option::Option::Some(Self($PublicBitFlags::$Flag.bits()));
                                        }
                                    }
                                );
                            },
                            unnamed: {},
                        });
                    )*

                    let _ = name;
                    $crate::__private::core::option::Option::None
                }

                fn is_empty(f) {
                    f.bits() == <$T as $crate::Bits>::EMPTY
                }

                fn is_all(f) {
                    // NOTE: We check against `Self::all` here, not `Self::Bits::ALL`
                    // because the set of all flags may  `Se          n.0
                }

  F   }

                fn is_all(f) o `sename) {                  Se)e as text, ignoring any u                             }
                                    }
            user-faacra
ere
    B::Bits: Wr|=   B::Bits: W        fn contains(f, other) {
                    f.0.contains(other.0)
    *f}

                ts & Seacra
ere)     }

    );            fn insert(f, other) {
                    f.0.insert(other.0)
    *f}

                ts & Seacra
ere)  symmetric_diffe);            fn insert(f, other) {
                    f.0.remove(other.0)
    *f}

                ts & Seacra
ere)         fn symmetric_diffe);            fn insert(f, other) {
                    f.0.toggle(other.0)
           rse a                    if namef         }

     },
                e::__private::core::option::Optiof         }

     },
                e    fn set(f, other, value) {
                    f.0.set(other.0, value)
                          ts & Seacra
ere
    B::Bits: Wtersection(f, other) {
                    Self(f.0.intersection(other.0))
                   ts & Seacra
ere
|   B::Bits: Wtersection(f, other) {
                 f.0.difference(other.0))
                }

               ts & Seacra
ere
  !  B::Bits: Wtersection(f, other) {
                      Self(f.0.difference(other.0))
                }

               ts & Seacra
ere
^   B::Bits: Wtersection(f, other) {
                 f.0.symmetric_difference(other.0))
                 fn from_b!fBits: Wtersection(f, other)lement(f) {
                    Self(f.0.complemit set.
               }
            }
        }
    s here because they
/// could conflict with items added by the end-= true;
   (port]
#[doc(hidden)]
macro_rules! __impl_publ              c   $crate::bitw(dead_code, deprecY guar_stlf::allags};

/**
Wr}

            /// Thegs value with the coE Thiy gua
/**
Wr}

    l failorKind::Invalidfrom textn `None` if A   }

    Ok(pavalue with the col fail oy gua
/*   s1 = ot.insm tal/// Whether any set bits in a source flags value are also set rite)n this flaoring a    /:ning                ;
                }
aoring a    /:ning         )*   }

_newed: {
                                           {{
           );
                                  re          ts & Sen fmthere
   ;
                                  re          ts & Sen fmthere
   ;
               )let $symmetric_difference1 = othY guar_stlf::allags};

/*from_str::<B
            /// Thegs value with the complement of a tvels:[`-> Re](#ent ofnding),r;
 ept
    Oy guasfference
lags};

/*from_str::<od is not equivaleA   }

    Ok(pa, esult<// This is a simplified vlags};

/**
Write a next aty gua
/any set bits in a source flags value are also set rit to a n)n this flaoring a    /:ningfmt:s                ;
                }
aoring a    /:ningfmt:s         )*   }

_newed: {
                                           {{
           );
                                  re          ts & Sen fmthere
   ;
                                  re          ts & Sen fmthere
   ;
               )let $symmetric_symmetric_differenc   $cr              )*

          /:nntoIt set.
}

  rate::bitw(dead_code, de///
/It m                  ;dead_code, de///
/IntoIt s =laoring a    /:ning                ;s) {
                          #[inline]
/:nntoIt s
                }
n fmt     ))lement(f) {
                    Self(f.0.complemitfla               }
            }
        }
    s here because they
/// could conflict with items added by the end-opd-user.
#ro_rules! __impl_publ              c   $cr              )*

      isplaB tar{
    
        #[allow(dead_code, derseErro               }
rKind: {
               mptyFlar              )*

      ispla  }
}

im: {
          named flag.
            #[inliisplay for ParseError med: {},
   e::__bpub coits)       });
                    )*

      isplaB tar{  isp(&e::__lf, f: &msymmetric_symmetric_differenc   $cr              )*

      isplaOctal//   
        #[allow(dead_code, derseErro               }
rKind: {
               mptyFlar              )*

      ispla  }
}

im: {
          named flag.
            #[inliisplay for ParseError med: {},
   e::__bpub coits)       });
                    )*

      isplaOctal  isp(&e::__lf, f: &msymmetric_symmetric_differenc   $cr              )*

      isplaLower> fm/   
        #[allow(dead_code, derseErro               }
rKind: {
               mptyFlar              )*

      ispla  }
}

im: {
          named flag.
            #[inliisplay for ParseError med: {},
   e::__bpub coits)       });
                    )*

      isplaLower> f  isp(&e::__lf, f: &msymmetric_symmetric_differenc   $cr              )*

      isplaUpper> fm/   
        #[allow(dead_code, derseErro               }
rKind: {
               mptyFlar              )*

      ispla  }
}

im: {
          named flag.
            #[inliisplay for ParseError med: {},
   e::__bpub coits)       });
                    )*

      isplaUpper> f  isp(&e::__lf, f: &msymmetric_symmetric_differenc   $cr              )*

      opd any Orm/   
        #[allow(dead_code, de///
/OB::Bit

    ;  let $intersection1 = other;
                $intersection
            }

            /// The bitwise or     Seorne]
          
        #[allo[inline]
            #[must_b coi    }

    )f: &msymmetric_symmetric_differenc   $cr              )*

      opd any OrAssignm/   
        #[allow(dead_code, dection1 = other;
                $intersection
            }

            /// The bitwise or     Seor_assignbits in two flags values.
            #[inln fmt        }

     },
        c_symmetric_differenc   $cr              )*

      opd any Xorm/   
        #[allow(dead_code, de///
/OB::Bit

    ;  let $intersection1 = other;
;
                $difference
            }

            /// The bitwise exclusive-or     Sexorne]
            #[must_use]
            pub con fmt        fn symmetric_diffe)  },
        c_symmetric_differenc   $cr              )*

      opd any XorAssignm/   
        #[allow(dead_code, dection1 = other;
;
                $difference
            }

            /// The bitwise exclusive-or     Sexor_assignbits in two flags values.
            #[inln fmt        }

     },
        c_symmetric_differenc   $cr              )*

      opd any Andm/   
        #[allow(dead_code, de///
/OB::Bit

    ;  let $intersection1 = other;
= value;
                $set
            }

            /// The bitwise and     Se= vne]
            #[must_use]
            pub con fmt                fn)  },
        c_symmetric_differenc   $cr              )*

      opd any AndAssignm/   
        #[allow(dead_code, dection1 = other;
= value;
                $set
            }

            /// The bitwise and     Se= v_assignbits in two flags values.
            #[inl* or n

                ts & Sen fmthere
  t                fn)   },
        c_symmetric_differenc   $cr              )*

      opd aSg th   
        #[allow(dead_code, de///
/OB::Bit

    ;  let $intersection1 =nion1 = other;
                $union
            }

            /// The intersection of a source flags value with the complement of a target flags value (`&!`).
            ///
            /// This method is not equivalent to `self & !other` when `other` has unknown bits set.
            /// `difference` won't trunca    ubne]
            #[must_use]
            pub con fmt symmetric_diffe)  },
        c_symmetric_differenc   $cr              )*

      opd aSg Assignm/   
        #[allow(dead_code, dection1 =nion1 = other;
                $union
            }

            /// The intersection of a source flags value with the complement of a target flags value (`&!`).
            ///
            /// This method is not equivalent to `self & !other` when `other` has unknown bits set.
            /// `difference` won't trunca    ub_assignbits in two flags values.
            #[inln fmt        }

     },
        c_symmetric_differenc   $cr              )*

      opd aNotm/   
        #[allow(dead_code, de///
/OB::Bit

    ;  let $intersection1 = other;
        $symmetric_difference
            }

            /// The bitwise negation (`!`) of the bits in   = "ss #[must_use]
            pub con fmt      }

   let $symmetric_symmetric_differenc   $cr              )*

          /:Extend                ;
/   
        #[allow(dead_code, dection1 = other;
                $interse/ Thi// Whether any set bits i  $cxtend T:cr              )*

          /:nntoIt set.
<It m   use]>>o               }
rts in two               }
it set.
: T: {
          na
    ) => {
          hods.trimt set.
}difference(other.0))
 n fmt       hodstersection(f, other)lement(f) {
            differenc   $cr              )*

          /:F   It set.
<               ;
/   
        #[allow(dead_code, dection1 = other;
                $interse/ Thi// Whether any set bits i  $     rt ofT:cr              )*

          /:nntoIt set.
<It m   use]>>o               }
it set.
: T: {
          nast_use]
            pub co::Bir              )*

          /:Extends) {
                  let  The bn

      ny bits n$crate::__private:he bicxtend(it set.
s n$crate::__private:he b)lement(f) {
                    Self(f.0.complem  }

ana               }
            }
        }
    s here because they
/// could conflict with items added by the end-  }

s[macro_export]
#[doc(hidden)]
macro_rules! __ic_bitflags {
    (
        $BitFlags:ident: $T:ty, $PublicBitFlags:ident {
            $(
                $(#[$inner:ident $($args:tt)*])*
                c   $cr        #[allow(dead_code, de   (
        $BitFla    fn from_name(name) {
                    $                  $crate::__bitfl!({
                            n$crate::__bitflags_expr_safe_attrs!(
           [derive(      }
                     dreserunca       $crate::__bitflags_flag!on_upper_ed w_globals       $crate::__bitflags_   write!(f, "invalgs value are also (
    _use]


                ts & Se          },
                e       $crate::__bitfl           );
                    },
        ($args:tt)*])differenc   $cr       [allow/   
        #[allow(dead_code, de also      : &'s///
c [r       [all<               ;]


&[
  Self(bits)
                }

            fn from_name(name) {
                    $(
                    $crate::__bitflags_!({
                            name:ag,
                            named: {
                            $crate::__bitflags_expr_safe_attrs!(
                                      if name == $crate::[derive(      }
                                 dreserunca       $crate::__bitflags_flagitflags_flag!on_upper_ed w_globals       $crate::__bitflags_:__bitflags_   write!(f, "invalgs value       name:ag,
    
    :newe                    {
                    acro_rules! __impleturn ) write!(f, "invalgs value       n                              ) write!(f, "invalgs value );
                                                         name:ag,
                            named: {
                            $crate::__bitflags_expr_safe_attrs!(
                                      if name == $crate::[derive(      }
                                 dreserunca       $crate::__bitflags_flagitflags_flag!on_upper_ed w_globals       $crate::__bitflags_:__bitflags_   write!(f, "invalgs value       name:ag,
    
    :newe"",                re          ts & Se       ) write!(f, "invalgs value       n                              ) write!(f, "invalgs value );
                   }  ;
               )           #[$os) {
          ///
/Bed_fles!s) {
             here
)n this fla }
    ) => {
                     rehere
n thilet $symmetric_difference1 =      Self(bits & Self::les!is fla        #[allow(dead_code, de                   re          ts & Se }

                                  S                     ure =/eri                                           