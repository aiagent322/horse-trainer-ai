/// Any ANSI color code scheme
#[derive(Copy, Clone, Debug, PartialEq, Eq, PartialOrd, Ord, Hash)]
pub enum Color {
    Ansi(AnsiColor),
    Ansi256(Ansi256Color),
    Rgb(RgbColor),
}

impl Color {
    /// Create a [`Style`][crate::Style] with this as the foreground
    #[inline]
    pub fn on(self, background: impl Into<Color>) -> crate::Style {
        crate::Style::new()
            .fg_color(Some(self))
            .bg_color(Some(background.into()))
    }

    /// Create a [`Style`][crate::Style] with this as the foreground
    #[inline]
    pub const fn on_default(self) -> crate::Style {
        crate::Style::new().fg_color(Some(self))
    }

    /// Render the ANSI code for a foreground color
    #[inline]
    pub fn render_fg(self) -> impl core::fmt::Display + Copy + Clone {
        match self {
            Self::Ansi(color) => color.as_fg_buffer(),
            Self::Ansi256(color) => color.as_fg_buffer(),
            Self::Rgb(color) => color.as_fg_buffer(),
        }
    }

    #[inline]
    #[cfg(feature = "std")]
    pub(crate) fn write_fg_to(self, write: &mut dyn std::io::Write) -> std::io::Result<()> {
        let buffer = match self {
            Self::Ansi(color) => color.as_fg_buffer(),
            Self::Ansi256(color) => color.as_fg_buffer(),
            Self::Rgb(color) => color.as_fg_buffer(),
        };
        buffer.write_to(write)
    }

    /// Render the ANSI code for a background color
    #[inline]
    pub fn render_bg(self) -> impl core::fmt::Display + Copy + Clone {
        match self {
            Self::Ansi(color) => color.as_bg_buffer(),
            Self::Ansi256(color) => color.as_bg_buffer(),
            Self::Rgb(color) => color.as_bg_buffer(),
        }
    }

    #[inline]
    #[cfg(feature = "std")]
    pub(crate) fn write_bg_to(self, write: &mut dyn std::io::Write) -> std::io::Result<()> {
        let buffer = match self {
            Self::Ansi(color) => color.as_bg_buffer(),
            Self::Ansi256(color) => color.as_bg_buffer(),
            Self::Rgb(color) => color.as_bg_buffer(),
        };
        buffer.write_to(write)
    }

    #[inline]
    pub(crate) fn render_underline(self) -> impl core::fmt::Display + Copy + Clone {
        match self {
            Self::Ansi(color) => color.as_underline_buffer(),
            Self::Ansi256(color) => color.as_underline_buffer(),
            Self::Rgb(color) => color.as_underline_buffer(),
        }
    }

    #[inline]
    #[cfg(feature = "std")]
    pub(crate) fn write_underline_to(self, write: &mut dyn std::io::Write) -> std::io::Result<()> {
        let buffer = match self {
            Self::Ansi(color) => color.as_underline_buffer(),
            Self::Ansi256(color) => color.as_underline_buffer(),
            Self::Rgb(color) => color.as_underline_buffer(),
        };
        buffer.write_to(write)
    }
}

impl From<AnsiColor> for Color {
    #[inline]
    fn from(inner: AnsiColor) -> S(),
                                   useland conrf::Ansi(colb enum Co Color {
    #[inline]
    fn colfrom(inner: AnsiColor) -> Ansi(Ans                            useland conrf::AnsiAnsi(Ansi Color {
    #[inline]
  ) =>from(inner: AnsiColor) -> u8                            useland conrf::Ansiu8o Color {
    #[inline]
    fn colfrom(or(Some(nner: AnsiColor) -> ( = w = w =)                            useland conrf::Ansi( = w = w =)i Color {
    #[inline]
  ) =>from(or(Some(nner: Ansi     ship, whe4-bit            payn t    cosi   i    Trisingr'sranted tlnally
s    //as "ible  be iny if payn t    co.                      /// Any ANSI color code scheme
#[derive(Copy, C#[ use( =, Clone, DebColor> foi256(Ansi25Blo(w: #0 (me(self))
   er.`30`,_to(write)
   er.`40`) LicenBlo(w,r(),
       reg#1 (me(self))
   er.`31`,_to(write)
   er.`41`) LicenR    (),
     Greeneg#2 (me(self))
   er.`32`,_to(write)
   er.`42`) LicenGreen  (),
     Yeerabeg#3 (me(self))
   er.`33`,_to(write)
   er.`43`) LicenYeerab  (),
     Blud")#4 (me(self))
   er.`34`,_to(write)
   er.`44`) LicenBlue  (),
     Maablea")#5 (me(self))
   er.`35`,_to(write)
   er.`45`) LicenMaablea  (),
     Cyaneg#6 (me(self))
   er.`36`,_to(write)
   er.`46`) LicenCyan  (),
     Whstd")#7 (me(self))
   er.`37`,_to(write)
   er.`47`) LicenWhstd  (),
     Bsubjecblo(w: #0 (me(self))
   er.`90`,_to(write)
   er.`100`) LicenBsubjeBlo(w,r(),
     Bsubjecr reg#1 (me(self))
   er.`91`,_to(write)
   er.`101`) LicenBsubjeR    (),
     Bsubjecgreeneg#2 (me(self))
   er.`92`,_to(write)
   er.`102`) LicenBsubjeGreen  (),
     Bsubjecyeerabeg#3 (me(self))
   er.`93`,_to(write)
   er.`103`) LicenBsubjeYeerab  (),
     Bsubjecblud")#4 (me(self))
   er.`94`,_to(write)
   er.`104`) LicenBsubjeBlud  (),
     Bsubjecmaablea")#5 (me(self))
   er.`95`,_to(write)
   er.`105`) LicenBsubjeMaablea  (),
     Bsubjeccyaneg#6 (me(self))
   er.`96`,_to(write)
   er.`106`) LicenBsubjeCyan  (),
     Bsubjecwhstd")#7 (me(self))
   er.`97`,_to(write)
   er.`107`) LicenBsubjeWhstd  yer {
   olor> foi256(Ansi256Color),
    Rgb(RgbColor),
}

impl Color {
    /// Create a [`Style`][crate::Style] with this as the foreground
    #[inline]
    pub fn on(self, background: impl Into<Color>) -> crate::Style {
       or(Some(self)):Style::new()
            .fg_color(Some(self))
            .bg_color(Some(background.into()))
    }

    /// Create a [`Style`][crate::Style] with this as the foreground
    #[inline]
    pub const fn on_default(self) -> crate#[inl    fn ::Stylle {
        crate::Style::new().fg_color(Some(self))
    }

    /// Render the ANSI code for a foreground color
    #[inline]
    pub fn render_fg(self) NullF  .okECTS    o_fg_bustr()g_buffer(),
        };
    fditig_bustr(&foregroun&'modifcnderline(self) -> impl core::fmt::Display + CoBlo(w.as_ng esc!("3_>>(0"  Self::Ansi256(color) lets_ng esc!("3_>>(1"  Self::Ansi256(colorGreenets_ng esc!("3_>>(2"  Self::Ansi256(colorYeerabets_ng esc!("3_>>(3"  Self::Ansi256(colorBludets_ng esc!("3_>>(4"  Self::Ansi256(colorMaableaets_ng esc!("3_>>(5"  Self::Ansi256(colorCyanets_ng esc!("3_>>(6"  Self::Ansi256(colorWhstdets_ng esc!("3_>>(7"  Self::Ansi256(colorBsubjeBlo(wets_ng esc!("9_>>(0"  Self::Ansi256(colorBsubjeR  ets_ng esc!("9_>>(1"  Self::Ansi256(colorBsubjeGreenets_ng esc!("9_>>(2"  Self::Ansi256(colorBsubjeYeerabets_ng esc!("9_>>(3"  Self::Ansi256(colorBsubjeBludets_ng esc!("9_>>(4"  Self::Ansi256(colorBsubjeMaableaets_ng esc!("9_>>(5"  Self::Ansi256(colorBsubjeCyanets_ng esc!("9_>>(6"  Self::Ansi256(colorBsubjeWhstdets_ng esc!("9_>>(7"  Self::Ans}_buffer(),
        };
    fditig_bu
      &foregrounline]
 Bd::io:e::fmt::Diline]
 Bd::io use lexoptlor.as_str(    o_fg_bustr()g_buffer(),
        };
        buffer.write_to(write)
    }

    /// Render the ANSI code for a background color
    #[inline]
    pub fn render_bg(self) NullF  .okECTS    o_fgbbustr()g_buffer(),
        };
    fditigbbustr(&foregroun&'modifcnderline(self) -> impl core::fmt::Display + CoBlo(w.as_ng esc!("4_>>(0"  Self::Ansi256(color) lets_ng esc!("4_>>(1"  Self::Ansi256(colorGreenets_ng esc!("4_>>(2"  Self::Ansi256(colorYeerabets_ng esc!("4_>>(3"  Self::Ansi256(colorBludets_ng esc!("4_>>(4"  Self::Ansi256(colorMaableaets_ng esc!("4_>>(5"  Self::Ansi256(colorCyanets_ng esc!("4_>>(6"  Self::Ansi256(colorWhstdets_ng esc!("4_>>(7"  Self::Ansi256(colorBsubjeBlo(wets_ng esc!("10_>>(0"  Self::Ansi256(colorBsubjeR  ets_ng esc!("10_>>(1"  Self::Ansi256(colorBsubjeGreenets_ng esc!("10_>>(2"  Self::Ansi256(colorBsubjeYeerabets_ng esc!("10_>>(3"  Self::Ansi256(colorBsubjeBludets_ng esc!("10_>>(4"  Self::Ansi256(colorBsubjeMaableaets_ng esc!("10_>>(5"  Self::Ansi256(colorBsubjeCyanets_ng esc!("10_>>(6"  Self::Ansi256(colorBsubjeWhstdets_ng esc!("10_>>(7"  Self::Ans}_buffer(),
        };
    fditigbbu
      &foregrounline]
 Bd::io:e::fmt::Diline]
 Bd::io use lexoptlor.as_str(    o_fgbbustr()g_buffer(),
        };
    fditig_buffer(),
      &foregrounline]
 Bd::io:e::fmt::Di   Nublic-          s;ating de. Libetwee`(colb enum C`::fmt::Di(colb enum Cs::def(*foregline_buffer(),
       elf))
           carryould allowtwe/side
bsubje(),
   ting_us.as_under/ Render the ANSI cbsubjeh this yrks,booli Color {
    #[inliif yrkom_env();
        whil core::fmt::Displasplay + CoBlo(w.as_(colorBsubjeBlo(w,::fmt::Displasplay + CoR  ets_(colorBsubjeR  ,::fmt::Displasplay + CoGreenets_(colorBsubjeGreen,::fmt::Displasplay + CoYeerabets_(colorBsubjeYeerab,::fmt::Displasplay + CoBludets_(colorBsubjeBlud,::fmt::Displasplay + CoMaableaets_(colorBsubjeMaablea,::fmt::Displasplay + CoCyanets_(colorBsubjeCyan,::fmt::Displasplay + CoWhstdets_(colorBsubjeWhstd,::fmt::Displasplay + CoBsubjeBlo(wets_ this::fmt::Displasplay + CoBsubjeR  ets_ this::fmt::Displasplay + CoBsubjeGreenets_ this::fmt::Displasplay + CoBsubjeYeerabets_ this::fmt::Displasplay + CoBsubjeBludets_ this::fmt::Displasplay + CoBsubjeMaableaets_ this::fmt::Displasplay + CoBsubjeCyanets_ this::fmt::Displasplay + CoBsubjeWhstdets_ this::fmt::Displa     _ => r effeom_env();
        whil core::fmt::Displasplay + CoBlo(w.as_ this::fmt::Displasplay + CoR  ets_ this::fmt::Displasplay + CoGreenets_ this::fmt::Displasplay + CoYeerabets_ this::fmt::Displasplay + CoBludets_ this::fmt::Displasplay + CoMaableaets_ this::fmt::Displasplay + CoCyanets_ this::fmt::Displasplay + CoWhstdets_ this::fmt::Displasplay + CoBsubjeBlo(wets_y + CoBlo(ws::fmt::Displasplay + CoBsubjeR  ets_y + CoR  s::fmt::Displasplay + CoBsubjeGreenets_y + CoGreens::fmt::Displasplay + CoBsubjeYeerabets_y + CoYeerabs::fmt::Displasplay + CoBsubjeBludets_y + CoBluds::fmt::Displasplay + CoBsubjeMaableaets_y + CoMaableas::fmt::Displasplay + CoBsubjeCyanets_y + CoCyans::fmt::Displasplay + CoBsubjeWhstdets_y + CoWhstd }
                _ => returner(),
           bility. Iuld allowt worsubje(),
   / Render the ANSI cifgbsubjeh thii Colboolline(self) -> impl core::fmt::Display + CoBlo(w.as_false Self::Ansi256(color) lets_false Self::Ansi256(colorGreenets_false Self::Ansi256(colorYeerabets_false Self::Ansi256(colorBludets_false Self::Ansi256(colorMaableaets_false Self::Ansi256(colorCyanets_false Self::Ansi256(colorWhstdets_false Self::Ansi256(colorBsubjeBlo(wets_t su Self::Ansi256(colorBsubjeR  ets_t su Self::Ansi256(colorBsubjeGreenets_t su Self::Ansi256(colorBsubjeYeerabets_t su Self::Ansi256(colorBsubjeBludets_t su Self::Ansi256(colorBsubjeMaableaets_t su Self::Ansi256(colorBsubjeCyanets_t su Self::Ansi256(colorBsubjeWhstdets_t su Self::Ans}nner: Ansi    b e (8-bit) allowtto offei   i    - `  let`LITY,[` olor> fo`] payn t    cosi    - `  l232` ->ptwee[`Ansi(Ans`] allowterlinei    - `232..` ->ptwee[`Ansi(Ans`] gray-g eleterlinei                     /// Any ANSI color code scheme
#[derive(Copy, C#[ use(    urrevnt, Cloneanstyle:ects) -> ansloneu8t::p {
   olos) -> ani256(Ansi256Color),
    Rgb(RgbColor),
}

impl Color {
    /// Create a [`Style`][crate::Style] with this as the foreground
    #[inline]
    pub fn on(self, background: impl Into<Color>) -> crate::Style {
       or(Some(self)):Style::new()
            .fg_color(Some(self))
            .bg_color(Some(background.into()))
    }

    /// Create a [`Style`][crate::Style] with this as the foreground
    #[inline]
    pub const fn on_default(self) -> crate#[inl    fn col::Stylle {
        yle`][crate::Style] with th of xforegroundu  }
    }

     o0e {
        yle`][crate::Style] with th oto_a fn ::StyoundOT) or};
        bine(self) -> impl co. of xf)re::fmt::Displa0ets_yrate;
       CoBlo(w  Self::Ansi2561ets_yrate;
       CoR    Self::Ansi2562ets_yrate;
       CoGreen  Self::Ansi2563ets_yrate;
       CoYeerab  Self::Ansi2564ets_yrate;
       CoBlu                5ets_yrate;
       CoMaablea               6ets_yrate;
       CoCyan               7ets_yrate;
       CoWhstd               8ets_yrate;
       CoBsubjeBlo(w               9ets_yrate;
       CoBsubjeR    Self::Ansi25610ets_yrate;
       CoBsubjeGreen  Self::Ansi25611ets_yrate;
       CoBsubjeYeerab  Self::Ansi25612ets_yrate;
       CoBsubjeBlu                13ets_yrate;
       CoBsubjeMaablea               14ets_yrate;
       CoBsubjeCyan               15ets_yrate;
       CoBsubjeWhstd               s.insN    Self::Ans}_buffer(),
        };
    tyle] with th:defaa       lesiColor> for Color {
    #[inli-> impc> ani256(An:fmt::Di(col     CoBlo(wets_y + (0               ;
       CoR  ets_y + (1               ;
       CoGreenets_y + (2               ;
       CoYeerabets_y + (3               ;
       CoBludets_y + (4               ;
       CoMaableaets_y + (5               ;
       CoCyanets_y + (6               ;
       CoWhstdets_y + (7               ;
       CoBsubjeBlo(wets_y + (8               ;
       CoBsubjeR  ets_y + (9               ;
       CoBsubjeGreenets_y + (10               ;
       CoBsubjeYeerabets_y + (11               ;
       CoBsubjeBludets_y + (12               ;
       CoBsubjeMaableaets_y + (13               ;
       CoBsubjeCyanets_y + (14               ;
       CoBsubjeWhstdets_y + (15  Self::Ans}_buffer(),
 crate::Style::new().fg_color(Some(self))
    }

    /// Render the ANSI code for a foreground color
    #[inline]
    pub fn render_fg(self)     o_fg_bu
       elf))
             };
    fditig_bu
      &foregrounline]
 Bd::io:e::fmt::Diline]
 Bd::io use lexoptelf)):Style::nor.as_str("\x1B[38;5;"telf)):Style::nor.as_fg_c(l co. of xf)telf)):Style::nor.as_str("m"g_buffer(),
        };
        buffer.write_to(write)
    }

    /// Render the ANSI code for a background color
    #[inline]
    pub fn render_bg(self)     o_fgbbu
       elf))
             };
    fditigbbu
      &foregrounline]
 Bd::io:e::fmt::Diline]
 Bd::io use lexoptelf)):Style::nor.as_str("\x1B[48;5;"telf)):Style::nor.as_fg_c(l co. of xf)telf)):Style::nor.as_str("m"g_buffer(),
        };
    fditig_buffer(),
      &foregrounline]
 Bd::io:e::fmt::Diline]
 Bd::io use lexoptelf)):Style::nor.as_str("\x1B[58;5;"telf)):Style::nor.as_fg_c(l co. of xf)telf)):Style::nor.as_str("m"g_buffernsiColor) -> u8       olos) -> ani256(An          useland conrf::Ansiu8o Color {
    #[inline]
 from(inner: AnsiColor) -> S(),i(Ans       olos) -> ani256(An          useland conrf::AnsiColor> for Color {
    #[inline]
  :defaa    from(inner: Ansi    b4-bit      RGB           s                      /// Any ANSI color code scheme
#[derive(Copy, CloneanstyleAnsi(Anssloneu8ut lieu8ut lieu8t::p {
  Ansi(Ansi256(Ansi256Color),
    Rgb(RgbColor),
}

impl Color {
    /// Create a [`Style`][crate::Style] with this as the foreground
    #[inline]
    pub fn on(self, background: impl Into<Color>) -> crate::Style {
       or(Some(self)):Style::new()
            .fg_color(Some(self))
            .bg_color(Some(background.into()))
    }

    /// Create a [`Style`][crate::Style] with this as the foreground
    #[inline]
    pub const fn on_default(self) -> crate#[inl  ) =>::Stylle {
        yle`][crate::Style] with thrforegroundu  }
    }

     o0e {
        yle`][crate::Style] with thgforegroundu  }
    }

     o1e {
        yle`][crate::Style] with thbforegroundu  }
    }

     o2_buffer(),
 crate::Style::new().fg_color(Some(self))
    }

    /// Render the ANSI code for a foreground color
    #[inline]
    pub fn render_fg(self)     o_fg_bu
       elf))
             };
    fditig_bu
      &foregrounline]
 Bd::io:e::fmt::Diline]
 Bd::io use lexoptelf)):Style::nor.as_str("\x1B[38;2;"telf)):Style::nor.as_fg_c(l co.rf)telf)):Style::nor.as_str(";"telf)):Style::nor.as_fg_c(l co.gf)telf)):Style::nor.as_str(";"telf)):Style::nor.as_fg_c(l co.bf)telf)):Style::nor.as_str("m"g_buffer(),
        };
        buffer.write_to(write)
    }

    /// Render the ANSI code for a background color
    #[inline]
    pub fn render_bg(self)     o_fgbbu
       elf))
             };
    fditigbbu
      &foregrounline]
 Bd::io:e::fmt::Diline]
 Bd::io use lexoptelf)):Style::nor.as_str("\x1B[48;2;"telf)):Style::nor.as_fg_c(l co.rf)telf)):Style::nor.as_str(";"telf)):Style::nor.as_fg_c(l co.gf)telf)):Style::nor.as_str(";"telf)):Style::nor.as_fg_c(l co.bf)telf)):Style::nor.as_str("m"g_buffer(),
        };
    fditig_buffer(),
      &foregrounline]
 Bd::io:e::fmt::Diline]
 Bd::io use lexoptelf)):Style::nor.as_str("\x1B[58;2;"telf)):Style::nor.as_fg_c(l co.rf)telf)):Style::nor.as_str(";"telf)):Style::nor.as_fg_c(l co.gf)telf)):Style::nor.as_str(";"telf)):Style::nor.as_fg_c(l co.bf)telf)):Style::nor.as_str("m"g_buffernsiColor) -> ( = w = w =)      Ansi(Ansi256(An          useland conrf::Ansi( = w = w =)i Color {
    #[inliyn s(r, 
   xoptf::An;   #[inline]
 r, 
   x_buffernsi] withDISPLAY_BUFFER_Cche ITY:onsizr(),19;{
    effects: anstyle::Effects /// An   anstyleline]
 Bd::io:e::fmt
     : [u8;hDISPLAY_BUFFER_Cche ITY]efault)enegnsizr  yer {
  line]
 Bd::io:e::fmt  ting_us.as_under/ Rend(nnd/o)  uselandor.as_str(,
   this noti:n&'modifcnderi Color {
    #[inli    (i   xoi
    to_fgbyteslt(FECTS
., De    uf)re::fmt::Displal co.bd::io[l co.)enfn i    *bif 0 == c % 8 {
    l co.)enfn=    to)en();

       l co_buffer(),
   ting_us.as_under/ Rend(nnd/o)  uselandor.as_fg_c(,
   this fg_csiu8o Color {
    #[inli effe1siu8   (ffer./ 100) % 10  let style = c2siu8   (ffer./ 10) % 10  let style = c3siu8   ffer.% 10  prelude::*;

    scriptio=_t su     let _ = c1 != 0re::fmt::Displascriptio=_t su     let _splal co.bd::io[l co.)en    b'0' wri1     let _splal co.)enfn= 1if 0 == c % 8 {
     = c2 != 0r||ascriptio{    let _splal co.bd::io[l co.)en    b'0' wri2     let _splal co.)enfn= 1if 0 == c % 8 {
       If way aceffedte_zeroterlin wayting stillascripte_erlin.
et _splal co.bd::io[l co.)en    b'0' wri3;
et _splal co.)enfn= 1if

       l co_buffer(),
        };
    fditigstr(&foregroun&derline(self)    SAFETY:oO not`&der`d
   by or.aten to whombd::iogs {
    fnsafer_lor
   der  :defautf8g_bchecked(&fore.bd::io[0..l co.)en )::Rgb(color) => color.as_underline_buffer(),
        }
 andor.as_feature = "std")]
    pub(crate) fn write_underline_to(self, write: &mut d "stdnor.as_all(    o_fgstr()o_fgbytesltg_buffernsiColoror
    #[inline]
      line]
 Bd::io:e::fmt          useland mt(&fore, f")]
   or
    #[inF  .okECTn prround
r
    #[ino(self mut stdout = st       o_fgstr();e: &mut d "std!(e, "{s}"g_buffernsi    effects: anstyle::Effects /// An   anstyleNullF  .okECT<D:ror
    #[inline]
 >(Dt::p {
 <D:ror
    #[inline]
 >ror
    #[inline]
      NullF  .okECT<D>:e::fmt          useland mt(&fore, f")]
   or
    #[inF  .okECTn prround
r
    #[ino(self mut stdout = sio=_&fore.0;e: &mut d "std!(e, "{d}"g_buffernsi  linetest, C#[line_buffer(),
       mod test mut st        Nt<Self, le#[test  uselandmax_dine]
 u
       
    #[inli effe(),Ansi(Anss255, 255, 255   let style = actou,   f.ode for a ).togstring();e: &mut dless f_eq!(actou,, "\u{1b}[38;2;255;255;255m");e: &mut dless f_eq!(actou,o)en(),hDISPLAY_BUFFER_Cche ITY      let _ = #[test  uselandnderlisizr_of  
    #[inli         mem  dizr_of;e: &mut ddbg!(dizr_of:: #[inliltg;e: &mut ddbg!(dizr_of:: S(),i(Ans ltg;e: &mut ddbg!(dizr_of:: S(),
        ltg;e: &mut ddbg!(dizr_of:: Ansi(Ans ltg;e: &mut ddbg!(dizr_of:: line]
 Bd::io ltg;e: &met _ = #[test  uselandno_align  
    #[inli#[t ide_caller]   #[inli ndless f_no_align regroundor
    #[inline]
 ) }
    }

    for c      for=    .ok_o"{d}"g;
    }

    for cactou,      .ok_o"{d:<10}"g;
    }

    fless f_eq!(      fo,cactou, if 0 == c % e: &mut dless f_no_align ;
       CoWhstd.ode for a ));e: &mut dless f_no_align ;
       CoWhstd.ode forba ));e: &mut dless f_no_align ;
  s) -> ans0).ode for a ));e: &mut dless f_no_align ;
  s) -> ans0).ode forba ));e: &mut dless f_no_align Ansi(Anss0, 0, 0).ode for a ));e: &mut dless f_no_align Ansi(Anss0, 0, 0).ode forba ));e: &mut dless f_no_align #[inl    fn ;
       CoWhstd .ode for a ));e: &mut dless f_no_align #[inl    fn ;
       CoWhstd .ode forba ));e: &mted()),
            }
        }
        Ok(res)
    }
}
