//! Generic data structure deserialization framework.
//!
//! The two most important traits in this module are [`Deserialize`] and
//! [`Deserializer`].
//!
//!  - **A type that implements `Deserialize` is a data structure** that can be
//!    deserialized from any data format supported by Serde, and conversely
//!  - **A type that implements `Deserializer` is a data format** that can
//!    deserialize any data structure supported by Serde.
//!
//! # The Deserialize trait
//!
//! Serde provides [`Deserialize`] implementations for many Rust primitive and
//! standard library types. The complete list is below. All of these can be
//! deserialized using Serde out of the box.
//!
//! Additionally, Serde provides a procedural macro called [`serde_derive`] to
//! automatically generate [`Deserialize`] implementations for structs and enums
//! in your program. See the [derive section of the manual] for how to use this.
//!
//! In rare cases it may be necessary to implement [`Deserialize`] manually for
//! some type in your program. See the [Implementing `Deserialize`] section of
//! the manual for more about this.
//!
//! Third-party crates may provide [`Deserialize`] implementations for types
//! that they expose. For example the [`linked-hash-map`] crate provides a
//! [`LinkedHashMap<K, V>`] type that is deserializable by Serde because the
//! crate provides an implementation of [`Deserialize`] for it.
//!
//! # The Deserializer trait
//!
//! [`Deserializer`] implementations are provided by third-party crates, for
//! example [`serde_json`], [`serde_yaml`] and [`postcard`].
//!
//! A partial list of well-maintained formats is given on the [Serde
//! website][data formats].
//!
//! # Implementations of Deserialize provided by Serde
//!
//! This is a slightly different set of types than what is supported for
//! serialization. Some types can be serialized by Serde but not deserialized.
//! One example is `OsStr`.
//!
//!  - **Primitive types**:
//!    - bool
//!    - i8, i16, i32, i64, i128, isize
//!    - u8, u16, u32, u64, u128, usize
//!    - f32, f64
//!    - char
//!  - **Compound types**:
//!    - \[T; 0\] through \[T; 32\]
//!    - tuples up to size 16
//!  - **Common standard library types**:
//!    - String
//!    - Option\<T\>
//!    - Result\<T, E\>
//!    - PhantomData\<T\>
//!  - **Wrapper types**:
//!    - Box\<T\>
//!    - Box\<\[T\]\>
//!    - Box\<str\>
//!    - Cow\<'a, T\>
//!    - Cell\<T\>
//!    - RefCell\<T\>
//!    - Mutex\<T\>
//!    - RwLock\<T\>
//!    - Rc\<T\>&emsp;*(if* features = \["rc"\] *is enabled)*
//!    - Arc\<T\>&emsp;*(if* features = \["rc"\] *is enabled)*
//!  - **Collection types**:
//!    - BTreeMap\<K, V\>
//!    - BTreeSet\<T\>
//!    - BinaryHeap\<T\>
//!    - HashMap\<K, V, H\>
//!    - HashSet\<T, H\>
//!    - LinkedList\<T\>
//!    - VecDeque\<T\>
//!    - Vec\<T\>
//!  - **Zero-copy types**:
//!    - &str
//!    - &\[u8\]
//!  - **FFI types**:
//!    - CString
//!    - Box\<CStr\>
//!    - OsString
//!  - **Miscellaneous standard library types**:
//!    - Duration
//!    - SystemTime
//!    - Path
//!    - PathBuf
//!    - Range\<T\>
//!    - RangeInclusive\<T\>
//!    - Bound\<T\>
//!    - num::NonZero*
//!    - `!` *(unstable)*
//!  - **Net types**:
//!    - IpAddr
//!    - Ipv4Addr
//!    - Ipv6Addr
//!    - SocketAddr
//!    - SocketAddrV4
//!    - SocketAddrV6
//!
//! [Implementing `Deserialize`]: https://serde.rs/impl-deserialize.html
//! [`Deserialize`]: ../trait.Deserialize.html
//! [`Deserializer`]: ../trait.Deserializer.html
//! [`LinkedHashMap<K, V>`]: https://docs.rs/linked-hash-map/*/linked_hash_map/struct.LinkedHashMap.html
//! [`postcard`]: https://github.com/jamesmunns/postcard
//! [`linked-hash-map`]: https://crates.io/crates/linked-hash-map
//! [`serde_derive`]: https://crates.io/crates/serde_derive
//! [`serde_json`]: https://github.com/serde-rs/json
//! [`serde_yaml`]: https://github.com/dtolnay/serde-yaml
//! [derive section of the manual]: https://serde.rs/derive.html
//! [data formats]: https://serde.rs/#data-formats

use crate::lib::*;

////////////////////////////////////////////////////////////////////////////////

pub mod value;

mod format;
mod ignored_any;
mod impls;
pub(crate) mod size_hint;

pub use self::ignored_any::IgnoredAny;

#[cfg(not(any(feature = "std", feature = "unstable")))]
#[doc(no_inline)]
pub use crate::std_error::Error as StdError;
#[cfg(all(feature = "unstable", not(feature = "std")))]
#[doc(no_inline)]
pub use core::error::Error as StdError;
#[cfg(feature = "std")]
#[doc(no_inline)]
pub use std::error::Error as StdError;

////////////////////////////////////////////////////////////////////////////////

macro_rules! declare_error_trait {
    (Error: Sized $(+ $($supertrait:ident)::+)*) => {
        /// The `Error` trait allows `Deserialize` implementations to create descriptive
        /// error messages belonging to the `Deserializer` against which they are
        /// currently running.
        ///
        /// Every `Deserializer` declares an `Error` type that encompasses both
        /// general-purpose deserialization errors as well as errors specific to the
        /// particular deserialization format. For example the `Error` type of
        /// `serde_json` can represent errors like an invalid JSON escape sequence or an
        /// unterminated string literal, in addition to the error cases that are part of
        /// this trait.
        ///
        /// Most deserializers should only need to provide the `Error::custom` method
        /// and inherit the default behavior for the other methods.
        ///
        /// # Example implementation
        ///
        /// The [example data format] presented on the website shows an error
        /// type appropriate for a basic JSON data format.
        ///
        /// [example data format]: https://serde.rs/data-format.html
        pub trait Error: Sized $(+ $($supertrait)::+)* {
            /// Raised when there is general error when deserializing a type.
            ///
            /// The message should not be capitalized and should not end with a period.
            ///
            /// ```edition2021
            /// # use std::str::FromStr;
            /// #
            /// # struct IpAddr;
            /// #
            /// # impl FromStr for IpAddr {
            /// #     type Err = String;
            /// #
            /// #     fn from_str(_: &str) -> Result<Self, String> {
            /// #         unimplemented!()
            /// #     }
            /// # }
            /// #
            /// use serde::de::{self, Deserialize, Deserializer};
            ///
            /// impl<'de> Deserialize<'de> for IpAddr {
            ///     fn deserialize<D>(deserializer: D) -> Result<Self, D::Error>
            ///     where
            ///         D: Deserializer<'de>,
            ///     {
            ///         let s = String::deserialize(deserializer)?;
            ///         s.parse().map_err(de::Error::custom)
            ///     }
            /// }
            /// ```
            fn custom<T>(msg: T) -> Self
            where
                T: Display;

            /// Raised when a `Deserialize` receives a type different from what it was
            /// expecting.
            ///
            /// The `unexp` argument provides information about what type was received.
            /// This is the type that was present in the input file or other source data
            /// of the Deserializer.
            ///
            /// The `exp` argument provides information about what type was being
            /// expected. This is the type that is written in the program.
            ///
            /// For example if we try to deserialize a String out of a JSON file
            /// containing an integer, the unexpected type is the integer and the
            /// expected type is the string.
            #[cold]
            fn invalid_type(unexp: Unexpected, exp: &Expected) -> Self {
                Error::custom(format_args!("invalid type: {}, expected {}", unexp, exp))
            }

            /// Raised when a `Deserialize` receives a value of the right type but that
            /// is wrong for some other reason.
            ///
            /// The `unexp` argument provides information about what value was received.
            /// This is the value that was present in the input file or other source
            /// data of the Deserializer.
            ///
            /// The `exp` argument provides information about what value was being
            /// expected. This is the type that is written in the program.
            ///
            /// For example if we try to deserialize a String out of some binary data
            /// that is not valid UTF-8, the unexpected value is the bytes and the
            /// expected value is a string.
            #[cold]
            fn invalid_value(unexp: Unexpected, exp: &Expected) -> Self {
                Error::custom(format_args!("invalid value: {}, expected {}", unexp, exp))
            }

            /// Raised when deserializing a sequence or map and the input data contains
            /// too many or too few elements.
            ///
            /// The `len` argument is the number of elements encountered. The sequence
            /// or map may have expected more arguments or fewer arguments.
            ///
            /// The `exp` argument provides information about what data was being
            /// expected. For example `exp` might say that a tuple of size 6 was
            /// expected.
            #[cold]
            fn invalid_length(len: usize, exp: &Expected) -> Self {
                Error::custom(format_args!("invalid length {}, expected {}", len, exp))
            }

            /// Raised when a `Deserialize` enum type received a variant with an
            /// unrecognized name.
            #[cold]
            fn unknown_variant(variant: &str, expected: &'static [&'static str]) -> Self {
                if expected.is_empty() {
                    Error::custom(format_args!(
                        "unknown variant `{}`, there are no variants",
                        variant
                    ))
                } else {
                    Error::custom(format_args!(
                        "unknown variant `{}`, expected {}",
                        variant,
                        OneOf { names: expected }
                    ))
                }
            }

            /// Raised when a `Deserialize` struct type received a field with an
            /// unrecognized name.
            #[cold]
            fn unknown_field(field: &str, expected: &'static [&'static str]) -> Self {
                if expected.is_empty() {
                    Error::custom(format_args!(
                        "unknown field `{}`, there are no fields",
                        field
                    ))
                } else {
                    Error::custom(format_args!(
                        "unknown field `{}`, expected {}",
                        field,
                        OneOf { names: expected }
                    ))
                }
            }

            /// Raised when a `Deserialize` struct type expected to receive a required
            /// field with a particular name but that field was not present in the
            /// input.
            #[cold]
            fn missing_field(field: &'static str) -> Self {
                Error::custom(format_args!("missing field `{}`", field))
            }

            /// Raised when a `Deserialize` struct type received more than one of the
            /// same field.
            #[cold]
            fn duplicate_field(field: &'static str) -> Self {
                Error::custom(format_args!("duplicate field `{}`", field))
            }
        }
    }
}

#[cfg(feature = "std")]
declare_error_trait!(Error: Sized + StdError);

#[cfg(not(feature = "std"))]
declare_error_trait!(Error: Sized + Debug + Display);

/// `Unexpected` represents an unexpected invocation of any one of the `Visitor`
/// trait methods.
///
/// This is used as an argument to the `invalid_type`, `invalid_value`, and
/// `invalid_length` methods of the `Error` trait to build error messages.
///
/// ```edition2021
/// # use std::fmt;
/// #
/// # use serde::de::{self, Unexpected, Visitor};
/// #
/// # struct Example;
/// #
/// # impl<'de> Visitor<'de> for Example {
/// #     type Value = ();
/// #
/// #     fn expecting(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
/// #         write!(formatter, "definitely not a boolean")
/// #     }
/// #
/// fn visit_bool<E>(self, v: bool) -> Result<Self::Value, E>
/// where
///     E: de::Error,
/// {
///     Err(de::Error::invalid_type(Unexpected::Bool(v), &self))
/// }
/// # }
/// ```
#[derive(Copy, Clone, PartialEq, Debug)]
pub enum Unexpected<'a> {
    /// The input contained a boolean value that was not expected.
    Bool(bool),

    /// The input contained an unsigned integer `u8`, `u16`, `u32` or `u64` that
    /// was not expected.
    Unsigned(u64),

    /// The input contained a signed integer `i8`, `i16`, `i32` or `i64` that
    /// was not expected.
    Signed(i64),

    /// The input contained a floating point `f32` or `f64` that was not
    /// expected.
    Float(f64),

    /// The input contained a `char` that was not expected.
    Char(char),

    /// The input contained a `&str` or `String` that was not expected.
    Str(&'a str),

    /// The input contained a `&[u8]` or `Vec<u8>` that was not expected.
    Bytes(&'a [u8]),

    /// The input contained a unit `()` that was not expected.
    Unit,

    /// The input contained an `Option<T>` that was not expected.
    Option,

    /// The input contained a newtype struct that was not expected.
    NewtypeStruct,

    /// The input contained a sequence that was not expected.
    Seq,

    /// The input contained a map that was not expected.
    Map,

    /// The input contained an enum that was not expected.
    Enum,

    /// The input contained a unit variant that was not expected.
    UnitVariant,

    /// The input contained a newtype variant that was not expected.
    NewtypeVariant,

    /// The input contained a tuple variant that was not expected.
    TupleVariant,

    /// The input contained a struct variant that was not expected.
    StructVariant,

    /// A message stating what uncategorized thing the input contained that was
    /// not expected.
    ///
    /// The message should be a noun or noun phrase, not capitalized and without
    /// a period. An example message is "unoriginal superhero".
    Other(&'a str),
}

impl<'a> fmt::Display for Unexpected<'a> {
    fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
        use self::Unexpected::*;
        match *self {
            Bool(b) => write!(formatter, "boolean `{}`", b),
            Unsigned(i) => write!(formatter, "integer `{}`", i),
            Signed(i) => write!(formatter, "integer `{}`", i),
            Float(f) => write!(formatter, "floating point `{}`", WithDecimalPoint(f)),
            Char(c) => write!(formatter, "character `{}`", c),
            Str(s) => write!(formatter, "string {:?}", s),
            Bytes(_) => formatter.write_str("byte array"),
            Unit => formatter.write_str("unit value"),
            Option => formatter.write_str("Option value"),
            NewtypeStruct => formatter.write_str("newtype struct"),
            Seq => formatter.write_str("sequence"),
            Map => formatter.write_str("map"),
            Enum => formatter.write_str("enum"),
            UnitVariant => formatter.write_str("unit variant"),
            NewtypeVariant => formatter.write_str("newtype variant"),
            TupleVariant => formatter.write_str("tuple variant"),
            StructVariant => formatter.write_str("struct variant"),
            Other(other) => formatter.write_str(other),
        }
    }
}

/// `Expected` represents an explanation of what data a `Visitor` was expecting
/// to receive.
///
/// This is used as an argument to the `invalid_type`, `invalid_value`, and
/// `invalid_length` methods of the `Error` trait to build error messages. The
/// message should be a noun or noun phrase that completes the sentence "This
/// Visitor expects to receive ...", for example the message could be "an
/// integer between 0 and 64". The message should not be capitalized and should
/// not end with a period.
///
/// Within the context of a `Visitor` implementation, the `Visitor` itself
/// (`&self`) is an implementation of this trait.
///
/// ```edition2021
/// # use serde::de::{self, Unexpected, Visitor};
/// # use std::fmt;
/// #
/// # struct Example;
/// #
/// # impl<'de> Visitor<'de> for Example {
/// #     type Value = ();
/// #
/// #     fn expecting(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
/// #         write!(formatter, "definitely not a boolean")
/// #     }
/// #
/// fn visit_bool<E>(self, v: bool) -> Result<Self::Value, E>
/// where
///     E: de::Error,
/// {
///     Err(de::Error::invalid_type(Unexpected::Bool(v), &self))
/// }
/// # }
/// ```
///
/// Outside of a `Visitor`, `&"..."` can be used.
///
/// ```edition2021
/// # use serde::de::{self, Unexpected};
/// #
/// # fn example<E>() -> Result<(), E>
/// !s not expected.
    Seq,
rro#:Result {
///     me(keu Examplone => retu   Err(de::Error::invali,
/// {
/d_type(Unexpected::B,
/// {
/&"tainga**Prian
/// "B,
///)lue = ()}
/// # }
/       pub `{}`, exp
           ata esents an explanation of what data wa    /// expS  //    (not(f that was
 ing to fmt::`taliz`ialEq `Errorrgument {
    fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt:;a str),
}

impl<' `{}`, exr<'dTitor<T>
where
l<'de> Visitze<'de>,
{
    fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
 te_str(self.ex write!(forapping)
  r),
}

im `{}`, exr<'d Other(ted<'a> {
    fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
        formatter.write_srapping)
  r),
}

im> fmt::Displ `{}`, ex+ Othed<'a> {
    fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
 Eype(Unexp    n fmt(&self, fo)      }
    }
}

/////////////////////////////////////////////////////////////////////////////
   **` is a data structure** that
//!    deserialized from any data format su///
 ported by Sesed.
/nally, Serde prallows `Deserialize` implementations for many Rust primitive/and
//! standard library types. The complete l[or<T][   use cr]s below. All oive/a* that
//!    deserialized using Serde out of the sed.
//!
//! Additionally, Serde provides a procedural macro p
//! [`serde_erive`/ to
//! automatically geallows `Deserialize` implementations for structs and e/ums
//! in your program. See the [derive section of the ee the  manual] for
       / about tsed.
//!
//! In rare cases it may be necessary to impallows `Deserilize`] manually/for
//! some type in your program. See the [Imple/// # 
//! [`Deseri[rde.rs/impl-dese][derive section of the manual for more about tive.
///
//! Third-party crates may pallows `Deserialize` implementatioset of tyt
as
 inghat they expose. For exampd
//! [`linked-hah-map`] crate provid # 
//! [`LinkedHashMapK, V>`] type that is deserializable by Serde becah-map`vid # crate provides an implementatallows `Deserilize`] forive.
/ee the  manual]: https://serde.rs/derive.
/erde.rs/impl-dese]alize`]: https://serde.rs/impl-deserialize./e = ()}LifetSystemive.
///mpdisi`ompfetSysntation of thirgument mpfetSysntatom an] typses it///
 por(dweriali`Resu` Raised when des expSgram. Sphe m[Unrdend
//ple/// #ialize(deser mpfetSyss]opriateal fodetaicro nts an explanatAll ofmpfetSyss forive.
/eUnrdend
//ple#ialize(deser mpfetSyss]alize`]: https://sempfetSyss ializ       #[cf     "std", diagnos au_neOf pacer(otherdiagnos au::on_       unimplt_args!(
 "st(featprialouton. Some mente rral, leme// ```
#[ # use derive(Deseri_eritype i`{Resu}pK, V>cted {}",
 "st(featpria. Somealizeile or-party check Raile orecah-map`anaferiaa p
//! ` "std", fflagcted {})
, Debugf thirl<'de> Deseriali!(Error:p
         # The Deserion oooleanalizeecahats isble bydf the Deserialized.
    ///
 ogram. See the [Implementing `Deseri[rde.rs/impl-dese][derive section    ///
 of the manual foovides informationl] for ary to impits inngth`ialized.
    ///
 erde.rs/impl-dese]alize`]: https://serde.rs/impl-deserializde>,
{
    fn deserialize<D>(deserializer: D) -> Result<Self, D::Error>
    where
        D: Deserializ;

         # The Desereceives aan
o p
/su` alizeecahats isDf the Deserialized.
    ///
 //mpeneral-ptation onngth`rgumeo` traiinherit The Deseriapectde     ///
 re other strucavoirde,piary A whach,    ion onngth`rone =>te shows a,
of
        su` Rielobome tainindet/// untemessaeor>
  for
// Thi methods ns for
of
     ap maber boverhat is s be andghtion ev or ssaeoe type thielobo    ///
 oeal y-safeialized.
    ///
 //
/// Tere is  made ful Raisereps tod sli when deseriaives sr `i64` that
 ations y bepreseforsay tSys,or>
  fhis is thetata  su` doesn'ypse, fo4` that
  aised w i!(mticular deserialioccursialized.
    ///
 Iftypeilize`] maary to impits ,type irecurshe [icular deserialializers
           /`alizer.deserin_s ace`ialized.
    ///
 //
//nngth`rgume = "ustruca secfic A pebulic API,ar nahidden alizeeca    ///
 docun implemen Serde bhirgumalhe twnev orion onewbientatiolooki is wr.    ///
 ol] i isi presr madocate, iterde bhir trae "std", receivens / u// cuhat was
 inainimticulavesializestd")]hiddensize)))
{
    fn deserin_s acerialize<D>(deserial, s acermatterResuple<E>() -> Resu<Self, D::Error>
    where
        D: Deserializer<'de>,
    {
    Dt the ddes an implemen wouldelnga*eumeo``alizer.deserialize field.
 *s aceme(key)        Deserialize::deserialize(deserialue()));
 Ok((tomData))
    }   ze any data strture** that
//!    deseried and  por(dwcontaifrom anys /
as
 ingydf the Deseriaceive.
///
/// Ty Ruari made ful pria. thir= &["sesenfunrive s expose. For eovid #     fn f`nfunrive ases it = "uswe try to deseriaze any data strture*por(dwnd e/ualizeecahng thetter, ,ar naa#     freadef`nfunrive ases shoultry to desed e/uow conh trie used.
///
/// ```edition2021
/// # use serde{self, Deserialize, DeseOw coVisitor};
/// # usiordeReadARIANTS,xpected};
/// #. third_any::Result #     fn f - Cow>((selOther(&le<E>() -> Talue, E>
/// where
/re
    T: Deseria>;e used.
/ #     freadef<RCow>(rdriaR&le<E>() -> Talue, E>
/// where
/RiaReadA/ where
/re
    T: DeseOw co;)
/// }
/// # }
/// ```
/)}LifetSystemive.
///mprelerialihipinteger ballows `Deserializ`ia  T: DeseOw co`preselizer t/r= &["seis nts aid a sieal fodetaicesented phe m[Unrdend
//pleydf the Deserr t/rmpfetSyss] forive.
/eUnrdend
//ple#ialize(deser mpfetSyss]alize`]: https://sempfetSyss ializebugf thirl<'de> DeseOw co: pri// impl<'de> Deserializ{}"std")]
il<'de> DeseOw coxr<'dTor>
  fT: pri// impl<'de> Deserializ{}"/// # 
//! [`Deseogrd`ed type isa*eful primmethods ollows `Deserif this Iftype/// #ev orfindtype matchlooki is wr hat ecesst enaze anan
o apallows `Deserializ,
       /// thied type t ecessdoe`] forive.
/Asesefoe. For e tupsa*eful icular deseriali mente rrd when deserialit ofve`/ t"bytnan
o asentismplembuafer. Usized thiollows `Deserif thimplec and shoutry to deseriat of t"bytnan
o au8]` oOptir nacrate, itshoulfre houl trawhatue`, an]` oOpt;ed when thno t ec wr ollows `Deserifpectde rovideviousoul trawhatue`, abuafer. Usized 
//! [`Deseogrd`ednsteadasek sr `/ Tyossi "ustspresent ot
    For eco by St istemive.
///mp* tonauto APItationshatless icular deserialilookt error `/ :e used.
///
/// ```edition2021
/// # use 
//! [`Desepected};
/// #ned aerror:{ #     }
/// #
funr}

imple
    T: Deserialiample<E>() -> esulf, D::
rro#:Result {
///       unimplemen
/// }
/// # }
/// ```
/Ad woucontainAPIterror `/ ples ormat upsa*eful icular deseriali valuse, fo4       accepterializis is ung th:e used.
///
/// ```edition2021
/// # use serd
//! [`Deseogrdpected};
/// #ned aerror:{ #     }
/// #
funr_zis }

imple
    T: DeseSis }

i>_booco: Tple<E>() -> elt<Self::Vf, D::
rro#:Result {
///    _me(sgrdpected}{
///       unimplemen
/// }
/// # }
/// ```
/Invidarivc examplajoat yntatocular deseriali vanshatless periAPItr(self.exeovid #zis i* that
 - *aserialit enized  # usuarkeri:!    - Phan`is us#zis iresent ot
 n rae tupsa*eless icular deserial.ze./e = ()}LifetSystemive.
///mpdisi`ompfetSysntation of thirgument mpfetSysntatom an] typses it///
 por(dweriali`Result<Self` Raised when des expSgram. Sphe m[Unrdend
//ple/// #ialize(deser mpfetSyss]opriateal fodetaicro nts an explanatAll ofmpfetSyss forive.
/eUnrdend
//ple#ialize(deser mpfetSyss]alize`]: https://sempfetSyss ialize./e = ()}e> for  Sesed.
/normasd on ap mat of ] typlookt error`[[1, 2e_js3, 4, 5e_js6]]rializweld onpecting
try to deseri pre
o auflerpected` reerialilrror`vec![1, 2, 3, 4, 5, 6] `OsS/ belted irialibraliznewu8]` oOpti ..."a => ubt"bytnte, itshost is Insteadawt///
 te, iterror ol trawhatntainngr ex]` oOptior map sed when des ."a => ubt"byt be "an
oe`] ///
//eive a supsa*eful icular deserialiusized thiollows `Deseogrd`isitor`
//ie used.
///
/// ```edition20
/// # use serde{self, Deserialize, Deseogrdrialize, DeserionaqA: Enuxpected, Visitor
/// # use std::fm
/// # usuarkeri:!    - Phan;e used.
/ }   alize, Deseogrdddes an implemen] typus supsa*eful icular deserialior
    `/ t- *ruca"bytnber of elondition truccatioentismplemvecd, y typetedntismple
    `/  ssaeoite_ed") traits in raegument ]` oOpy type`alizer.deserinngth`rof
    `/ `Exttru]` ` Rielobomr`
and ized thingn or fbyt methods t of ng themitive/a`/ t- *ru wa  a =>an
/// iindition ttismplem]` .ive/and// # stttru]`  - Cow: ia>  Othtter]` oOp);e used.
/r),
}

imp- Cow>
    T: DeseSis }

i>Displ `ttru]`  - Cowalue, E>
/// where
/re
    T: DeserilizerError,
/// {
/.
///mpree => Error` d thioalizer.deserinngth`xpected.ample implemen
/// {
/.
/t- *ruelonditioentismplemvecd, ir nadoesphrasens to aifrnewubinar
/// {
/.
/y data st, sition ree => Errorted().r
/// {
/ #     type Value = 
       ///     fn deserialnum<A>(ze<D>(deserializer: D) -> Result<Self::<Self, D::       ///           ///         D: Deserializer       ///       ///  "This
/// Vdes an implemen] typRielowalktaininn or fbytmethods t of/       ///  "Th   ///        ///   d// # stttru]` l<'de> Vi Cow: ia>  Othtter]` oOp);e used.
/E>>);

        imp- Cow>
l<'de> Visitor<'de>ttru]` l<'de> Vi Cow>ed.
/E>>);

 //           ///  re
/re
    T: DeserilizerErro                 ///  re
/ #     type Value = 
       /;

            fn expecting(&self, formatter: &mut fmt::Formatter) -> fmt::Re       /;

      #         write!(formased abytmethan
/// sbooleanield))
        = 
       /;

            fn eqit_enum<A>tter eqf, data: A) -> ResuASelf, D::       /E>>);

 //           ///  re
/       naqA: EnurilizerErro                     ///  re
/ {
    Dtens e becahis the numns elted ialia   io{}`, thens fober of e        ///  re
/ {
        atio(e) mod si)me(sgq.e) mod sis_emp       ///  re
/ {
  {
 te_st0.rculave(e) mod si);p       ///  re
/ {
    = 
       /;

     //  "This
//  a =>ber of present inn or fbytmor mpushri pondi
       /;

     //  "Thion ttismplemvecd, ye       /;

      #   hinpu    atio(ber )me(sgq.i!(m_ber of ()?emp       ///  re
/ {
  {
 te_st0.push(ber );p       ///  re
/ {
    =                     ()ooleanield))
        =  re
/ {
    = 
       /;

        deserializer.desersgq(e>ttru]` l<'de> ite_st0)ooleanield}&self))
//ive/a`/ is
/// Vdes an implemen] typRielowalktor fout or fbytmethods t ofh   ///     std")]
sle!(fneu]` l<'de> VTor<T, E>(PhantOp);e used.
/r),
}

impl<'de, T> Visitor<'dele!(fneu]` l<'de> VTolue, E>
/// where
/re
    T: DeserilizerError,
/// {
/.
///tedis
/// V      for stainngr e]` oOpr olhol map afle!(fneu,
/// {
/.
/in thni methods ngn or fbyt .r
/// {
/ #     type V]` oOpue = 
       ///     fn expecting(&self, formatter: &mut fmt::Formatter) -> fmt::Re       /;

        write!(formased abytmeth fbyt "ooleanield}&sel
       ///     fn eqit_enum<A>tter eqf, data: A) -> ]` oOpsuASelf, D::       ///           ///     naqA: EnurilizerErro    //       ///  "ThCns to aainngr e]` r olhol map afle!(fneu/in thni ye       /;

     ttervece V]` ap(Sealue = 
       /;

     a =>aringlemen]  0\] tits ilooprtedsefongn or fbyt.ed.
/E>>);

 //inpu    atio(varie(sgq.i!(m_ber of _zis (e>ttru]` (&ttervec))?emp       ///  re
/   Noorized ssdo; inn or fbytmh dataised- *ru a sigor`vec`.  =  re
/ {
    = 
       /;

     ee => Ep afinish exp` .ive/a            ec)oleanield}&self))
//ive/a #
/// # fn e

impialize<D>(deserializer: D) -> Resu<Self, D::(), E>
/// !s not expe       D: Deserializer    #:Result     s
/// V=dele!(fneu]` l<'de> Visitor(Phant;esult    fle!(fneu:V]` ou64>V=d       deserializer.desersgq( s
/// ialis not expe   ()oolean)}
/// # }
/       pub    T: DeseSis }

i>!(Error:p
        Tis is thproducerialiusized t vane expecte #     typ;

        Eve valn argument al foc  - **`       Deserialize::deserinngth`ld `cept4` that
  t enor
//r, " A peiecsntatom an(pletes&Expt enca si.
   ///     fn deserialnum<A>(ze<D>(deserializer: D) -> Result<Self::<Self, D::Error>
    where
        D: Deserializ;
}///////

impl<'de, T> DeseSis }

i>Displ<T, E>(PhantOpping<T>
where
    T: Deserialize<'de>,
{
    type Value = T#[doc(no]
   ///     fn deserialnum<A>(ze<D>(deserializer: D) -> Tsu<Self, D::Error>
    where
        D: Deserializer<'de>,
    {
 Trialize::deserialize(deseri      }
    }
}

/////////////////////////////////////////////////////////////////////////////
   **` is a data format** t
//!    deserialize any data structure suppoed.
/nallystemive.
///mprolsntation of thirgumeg
trfine ingydf the Desglemenhalfmethods on the [S     //model],against valut ecesswhat uncat#ev ofor manom an] some essof any [S  29Tyossi "usibrary  a =>nngth`rofging to the `Deseriaf thircorrcuporuelessof 
       /// . Some   ///    //modelut tsed.
////! # Implementatiallows `Deserilied aemnumv provgumenis    //modelppoed.
/t enizedonging to the `Deserialxt of a `Visitor` implemeormat** t
cts to 
as
 ingsr("tupcellibrarytemive.
///mpset of tytasek  tupl/mpble byd  //modelp th:e used.
/)*
//14ny Rust pri **Net oleaniel//!    - /ool
//!    - i8, i16, i32, i6 - /ool
//!    - u8, u16, u32, u6 - /ool
//!    - f32,/f64
//!    - 
/)*
//tter, t oleaniel// vali is theot end nvalid aliznohiselot/// unt, ye       - Wp sewhen deseri,l tretter, ntatioT, dcro nqe`] m. Wp sed when deserierErro     io{}`, the]  e aflevent  tupser, n:af tnsi im,uow coy Serdpor(dwer. - 
/)*
//e_str("byt fo//!   - &\[     - SRuspartles ser, nA>(urple#ialize(desplemen _str("bytsf these caro     i tnsi im,uow coy , iror(dwer. - 
/)*
//o_str(t oleaniel//Eile ornof anrong fois th. - 
/)*
//e_stt oleaniel//Tis is thatia uniresr ma. Itpected` represe tonymcellis the   /// con caro     nohh trie us/)*
//e_st_y datat oleaniel//ected. For exstd")]
     `&[u8<T, E>(PhantOp`. Itpected` repreticulu,
/// {
/lis the   /// con nohh trie us/)*
//e_st_struct t oleaniel//ected. For eods of::Arializ`f::Bnires`ned ae { A, B }`ie us/)*
//e_str("_y datat oleaniel//ected. For exstd")]
Mielimet//s(u8)`ie us/)*
//e_str("_struct t oleaniel//ected. For eods of::Nnires`ned ae { N(u8) }`ie us/)*
//sgqt oleaniel//A"strucblyuple d het//oere cellaing a seqfaives sve ...", for ex]` oOpt,
/// {
/l&[u8!    - tOp`. Wp sewhen deseri,lent mvalid ses sr ses should     ",
/// {
/lbefl fooringlezed t 0\] t tre///    /. Wp sed when deserielent mvalid,
/// {
/le that/// uerialilooki is
//! t can be serih trie us/)*
//e_strt oleaniel//A"eld: &`] maple d het//oere cellaing a seqfaives se ...gainst wh,
/// {
/lmvalid Rielobom    "uamticular deserialitSysned and  looki is
//! t,
/// {
/lcan be serih trve ...", for ex(u8,) `&[u8(Ster, ,a, u32]` oOp) `&[,
/// {
/l`[, u; 10]`ie us/)*
//e_str_y datat oleaniel//Aticuluained ve ...", for exstd")]
Rgb(!         )`ie us/)*
//e_str_struct t oleaniel//ected. For eods of::Tnires`ned ae { T(!     ) }`ie us/)*
//liet oleaniel//Athet//oere cellkey-is thepaier, ,a ...", for ex!    - BHashMap. - 
/)*
//tteatat oleaniel//Athet//oere cellkey-is thepaier, iresgainst whlkeyntatiotter, ntanu,
/// {
/lRielobom    "uamticular deserialitSysned and  looki is
//! tlcan be ser,
/// {
/lh trve ...", for exstd")]
S { ria!   gia!   bia!  }`ie us/)*
//std")]_struct t oleaniel//ected. For eods of::Snires`ned ae { S { ria!   gia!   bia!  } }`ie usve.
///mpdo the `Deseriaf thiructure s//! T reofooatingsty  - gainst\] *ise     a type difki ` methicular deserial.ze./e = (1y type`alizer.deseignorinngth`xpResu-createbple#i
//! [data terrort of t"t,
/// {
= "uswe looks
//! t can be serih trior mars at from wected` rep expo,
/// {
d. For eods  basicalize(deser ses es&ca sepe con cur mabracem(`{`)tanu,
/// {
    oe typehan wheeirialilies Ift///    //y data format e        do the `Deserrialize::deseignor,acratielodthe [ent ]s
/// Vusizedion ev o        ] someer eespresent in th.  basius sr `/ T/ typa =>Raised when deseri        d  /// `serlt<Self` Rainst valained an enu_json` can repialit of/       docun im.///
/nd      ge statinispresiat of docun im,mplec t
//!    dese/       hir trd  /// `serlt<Self` aligoezed t 0\]         do the `Deserrialize::deseignor.ze./e = (2y type"tupcell`alizer.desei*_length` . Non-sesu-createbple# [data terro        Pmunns/pld only nbomrol mtatinispresecahng theie a deriapetry to deseri ye       type`alizer.desei*_length` tatioTinr expenherit The Deserianual] for
       hs en cated w i!(mteiecsntatin th. Non-sesu-createbple# [data t theret,
/// {
= "uswe try to deserng forizedlrror`  /// `serlt<Self` Rainstrelientmen
/// {
do the `Deserrialize::deseignor.ze./e = (Wp sei the [Implementing `Deser,typemessage avoirdrelye a Sn/// # 
//! [`Deserrialize::deseignor unless ypemd only nbomrol movideo      # The Deseri about whaispresent in th. K   oe typrelye a Sn/// # 
//! [`Deserrialize::deseignor metnstype iom an] somRielobom= "uswe shoutry to deseralizesesu-createbple# [data tshou, rule a StriPmunns/plor mns f
     le os forive.
/eble byd  //model format]: https://serde.rmodeluialize./e = ()}LifetSystemive.
///mpdisi`ompfetSysntation of thirgument mpfetSysntatom an] typses it///
 por(dwerializeecahng theRaised when deserixpSgram. Sphe m[Unrdend
//ple/// #ialize(deser mpfetSyss]opriateal fodetaicro nts an explanatAll ofmpfetSyss forive.
/eUnrdend
//ple#ialize(deser mpfetSyss]alize`]: https://sempfetSyss ialize./e = ()}e> for d.ample implemen
//
       /// The [example data format] presented on the wt data c    For eco bynually/fte for a basido the `Deseri forive.
/e  /// [example data format]: https://serde.rs/data-forma       pub    T: Deser}

i>!(Error:p
        Tis  build, V>`] typ* that
ree =>ca sg out o buildoccurs>(urple    ///
 dcular deserial.z /// #     tit!( as StdE         ive a ging to the `Deseriafe arg strtionl] for dthe [ent  s
/// VbaserE        ontion of what whaispresent in th.alized.
    ///
 Wp sei the [Implementing `Deser,typemessage avoirdrelye a Sn/of
      
//! [`Deserrialize::deseignor unless ypemd only nbomrol movideo          # The Deseri about whaispresent in th. K   oe typrelye a Sn/of
      
//! [`Deserrialize::deseignor metnstype iom an] somRielobom= "uswe    ///
 dcular deseralizesesu-createbple# [data tshou, rule a StriPmunns/plor     ///
 of y  le os fe)))
{
    fn deserf y<V_bool<E>(s
/// : Vdata: A) -> ]lt<Self::Resultlf, D::Error>
    where
 Ve
l<'de> VisittdE        Hit varian thiollows `Deserif whaispr(self.exeo `!   `ois th. e)))
{
    fn deser visiV_bool<E>(s
/// : Vdata: A) -> ]lt<Self::Resultlf, D::Error>
    where
 Ve
l<'de> VisittdE        Hit varian thiollows `Deserif whaispr(self.exeonintegois th. e)))
{
    fn deseri8iV_bool<E>(s
/// : Vdata: A) -> ]lt<Self::Resultlf, D::Error>
    where
 Ve
l<'de> VisittdE        Hit varian thiollows `Deserif whaispr(self.exeonint16gois th. e)))
{
    fn deseri16iV_bool<E>(s
/// : Vdata: A) -> ]lt<Self::Resultlf, D::Error>
    where
 Ve
l<'de> VisittdE        Hit varian thiollows `Deserif whaispr(self.exeonintointis th. e)))
{
    fn deseri32iV_bool<E>(s
/// : Vdata: A) -> ]lt<Self::Resultlf, D::Error>
    where
 Ve
l<'de> VisittdE        Hit varian thiollows `Deserif whaispr(self.exeonint` oris th. e)))
{
    fn deseri64iV_bool<E>(s
/// : Vdata: A) -> ]lt<Self::Resultlf, D::Error>
    where
 Ve
l<'de> VisittdE        Hit varian thiollows `Deserif whaispr(self.exeonint12egois th. e)))d.
    ///
 //mpit the default beunt d
//! Additrone =>te shows a. e)))
{
    fn deseri128iV_bool<E>(s
/// : Vdata: A) -> ]lt<Self::Resultlf, D::Error>
    where
 Ve
l<'de> Visiter<'de>,
    {
     _me((s
/// lue()));
 retu       Error::"i128// that ucture su"tomData))E        Hit varian thiollows `Deserif whaispr(self.exeo `uegois th. e)))
{
    fn deseru8<V_bool<E>(s
/// : Vdata: A) -> ]lt<Self::Resultlf, D::Error>
    where
 Ve
l<'de> VisittdE        Hit varian thiollows `Deserif whaispr(self.exeo `u16gois th. e)))
{
    fn deseru16iV_bool<E>(s
/// : Vdata: A) -> ]lt<Self::Resultlf, D::Error>
    where
 Ve
l<'de> VisittdE        Hit varian thiollows `Deserif whaispr(self.exeo `u16`,is th. e)))
{
    fn deseru32iV_bool<E>(s
/// : Vdata: A) -> ]lt<Self::Resultlf, D::Error>
    where
 Ve
l<'de> VisittdE        Hit varian thiollows `Deserif whaispr(self.exeou32` oris th. e)))
{
    fn deseru64iV_bool<E>(s
/// : Vdata: A) -> ]lt<Self::Resultlf, D::Error>
    where
 Ve
l<'de> VisittdE        Hit varian thiollows `Deserif whaispr(self.exeoninu12egois th. e)))d.
    ///
 //mpit the default beunt d
//! Additrone =>te shows a. e)))
{
    fn deseru128iV_bool<E>(s
/// : Vdata: A) -> ]lt<Self::Resultlf, D::Error>
    where
 Ve
l<'de> Visiter<'de>,
    {
     _me((s
/// lue()));
 retu       Error::"u128// that ucture su"tomData))E        Hit varian thiollows `Deserif whaispr(self.exeo `f16`,is th. e)))
{
    fn deserf32iV_bool<E>(s
/// : Vdata: A) -> ]lt<Self::Resultlf, D::Error>
    where
 Ve
l<'de> VisittdE        Hit varian thiollows `Deserif whaispr(self.exeou3f` oris th. e)))
{
    fn deserf64iV_bool<E>(s
/// : Vdata: A) -> ]lt<Self::Resultlf, D::Error>
    where
 Ve
l<'de> VisittdE        Hit varian thiollows `Deserif whaispr(self.exeoained a is th. e)))
{
    fn deserned iV_bool<E>(s
/// : Vdata: A) -> ]lt<Self::Resultlf, D::Error>
    where
 Ve
l<'de> VisittdE        Hit varian thiollows `Deserif whaispr(self.exeoatter, "is theor mdoeshat was
    /benefiifferentaki isow crihipiofabuafererih triow conovideo         do the `Deseri flized.
    ///
 Iftation, the `Vite, itshnefiifferentaki isow crihipiofatr` or `Sh trv
          d!("dup `/ plesing to the `Deseriaaliusized`alizer.deseitter, `
          stead. e)))
{
    fn desern f V_bool<E>(s
/// : Vdata: A) -> ]lt<Self::Resultlf, D::Error>
    where
 Ve
l<'de> VisittdE        Hit varian thiollows `Deserif whaispr(self.exeoatter, "is theor mwzers
        benefiifferentaki isow crihipiofabuafererih triow conovideo         do the `Deseri flized.
    ///
 Iftation, the `Vite, it   /benefiifferentaki isow crihipiofatr` or `
           /,   d!("dup `atplesing to the `Deseriaaliusized`alizer.deseitte`
          stead. e)))
{
    fn desern fize V_bool<E>(s
/// : Vdata: A) -> ]lt<Self::Resultlf, D::Error>
    where
 Ve
l<'de> VisittdE        Hit varian thiollows `Deserif whaispr(self.exeoa _str("byteor mdoeshat was not
 benefiifferentaki isow crihipiofabuafererih triow conovideo         do the `Deseri flized.
    ///
 Iftation, the `Vite, itshnefiifferentaki isow crihipiofat]` or `Veh trv
          d!("dup `/ plesing to the `Deseriaaliusized`alizer.desei _st_bua`
          stead. e)))
{
    fn deseris th V_bool<E>(s
/// : Vdata: A) -> ]lt<Self::Resultlf, D::Error>
    where
 Ve
l<'de> VisittdE        Hit varian thiollows `Deserif whaispr(self.exeoa _str("byteor mwzers
        benefiifferentaki isow crihipiofabuafererih triow conovideo         do the `Deseri flized.
    ///
 Iftation, the `Vite, it   /benefiifferentaki isow crihipiofat]` or `V
           /,   d!("dup `atplesing to the `Deseriaaliusized`alizer.deseiis th`
          stead. e)))
{
    fn deseris t_buaiV_bool<E>(s
/// : Vdata: A) -> ]lt<Self::Resultlf, D::Error>
    where
 Ve
l<'de> VisittdE        Hit varian thiollows `Deserif whaispr(self.exeonio_str(alois th. e)))d.
    ///
 //gumallows#ialize(deserof tytaemendeeonio_str(alois this us#isel= "u    ///
 oolean owt dverted w iseloives aan
o pNonerializeceig partives aan
o         datio(ives )`. e)))
{
    fn desero_str( V_bool<E>(s
/// : Vdata: A) -> ]lt<Self::Resultlf, D::Error>
    where
 Ve
l<'de> VisittdE        Hit varian thiollows `Deserif whaispr(self.exeoae_str("uni. e)))
{
    fn deseru_st V_bool<E>(s
/// : Vdata: A) -> ]lt<Self::Resultlf, D::Error>
    where
 Ve
l<'de> VisittdE        Hit varian thiollows `Deserif whaispr(self.exeoae_strstd")]
ot endE        with a particul. e)))
{
    fn deseru_st_y data V_besult {
 te_sted {}",
 "culd(field: &'stated {}",
 (s
/// : Vted {})ata: A) -> ]lt<Self::Resultlf, D::Error>
    where
 Ve
l<'de> VisittdE        Hit varian thiollows `Deserif whaispr(self.exeoained a newtype ot endE        with a particul. e)))
{
    fn desere_str("_y data V_besult {
 te_sted {}",
 "culd(field: &'stated {}",
 (s
/// : Vted {})ata: A) -> ]lt<Self::Resultlf, D::Error>
    where
 Ve
l<'de> VisittdE        Hit varian thiollows `Deserif whaispr(self.exeoaaing a seqfaives s. e)))
{
    fn deserneq V_bool<E>(s
/// : Vdata: A) -> ]lt<Self::Resultlf, D::Error>
    where
 Ve
l<'de> VisittdE        Hit varian thiollows `Deserif whaispr(self.exeoating a seqfaives seor     ///
     snl] fof y ives sr `{}`, theed and  looki is
//! tlcan be serih triee)))
{
    fn desere_str V_bool<E>length(len: (s
/// : Vdata: A) -> ]lt<Self::Resultlf, D::Error>
    where
 Ve
l<'de> VisittdE        Hit varian thiollows `Deserif whaispr(self.exeoae_str(ewtype ot endE        with a particul alizns the numare noiee)))
{
    fn desere_str_y data V_besult {
 te_sted {}",
 "culd(field: &'stated {}",
 length(len:ed {}",
 (s
/// : Vted {})ata: A) -> ]lt<Self::Resultlf, D::Error>
    where
 Ve
l<'de> VisittdE        Hit varian thiollows `Deserif whaispr(self.exeoaliednumkey-is thepaieoiee)))
{
    fn deserlie V_bool<E>(s
/// : Vdata: A) -> ]lt<Self::Resultlf, D::Error>
    where
 Ve
l<'de> VisittdE        Hit varian thiollows `Deserif whaispr(self.exeoatteype ot end with a parhat was
  cul alizare noiee)))
{
    fn desery data V_besult {
 te_sted {}",
 "culd(field: &'stated {}",
 are noxpected: &'static [&'stat:ed {}",
 (s
/// : Vted {})ata: A) -> ]lt<Self::Resultlf, D::Error>
    where
 Ve
l<'de> VisittdE        Hit varian thiollows `Deserif whaispr(self.exeoained ais theot endE        with a particul alizyossi "usstruct oiee)))
{
    fn deserned  V_besult {
 te_sted {}",
 "culd(field: &'stated {}",
 (truct oxpected: &'static [&'stat:ed {}",
 (s
/// : Vted {})ata: A) -> ]lt<Self::Resultlf, D::Error>
    where
 Ve
l<'de> VisittdE        Hit varian thiollows `Deserif whaispr(self.exed w iam Outsidns for
of
     licateoorecahdieate/ unntccatioened aisruct . e)))
{
    fn deserid[Implicf V_bool<E>(s
/// : Vdata: A) -> ]lt<Self::Resultlf, D::Error>
    where
 Ve
l<'de> VisittdE        Hit varian thiollows `Deserif whad onsswe try to deseriais theohasd f wh    ///
 doesn'ypse, fon Serde bhirgumi_any:`ialized.
    ///
 Dalize(deseroffa noun-sesu-createbple# [data tses shou ormat uion onodh. e)))
{
    fn deseri_any:`rf y<V_bool<E>(s
/// : Vdata: A) -> ]lt<Self::Resultlf, D::Error>
    where
 Ve
l<'de> VisittdE        Dat/// ue Raile orallows `Deserialize` implementessage r(selfswe    ///
 dcular deserle ir huof -read= "us [daialized.
    ///
 or
//! sos ap maa huof -read= "us [dan] typses it out  abour(senshe [we    ///
       for,is uwrs as us#bpl nec [dan] typs inompactstructcfic enh.alized.
 Gre is  mathe -baser! [data terrort of trucYAMLmRielopreferiapede beca
of
     auof -read= "usseforerdppl nec [data terrorPmunns/plRielopreferiaca
of
     nompactssefialized.
    ///
 //
/// ```editi   ///
 };
/// # usops::Add;i   ///
 };
/// # us   ::FromStr;i   ///
 }i   ///
 };tteype TSysstamp;i   ///
 }i   ///
 };aliz TSysstamp:p
        t expe      EPOCH: TSysstamp:= TSysstamp;i   ///
 }       //
 }i   ///
 };aliz FromStrxr<'dTSysstamp:p
        t expe #     t:= r` or ;
        t expe #     fn f(_xpeer(&le<E>() -> ResultResultlf,>:p
        t expe
///       unimplemen        t expe}i   ///
 }       //
 }i   ///
 };tteype Dungleme;i   ///
 }i   ///
 };aliz Dungleme:p
        t expefsewht d
s(_xpsignle<ESatch /       unimplemee}i   ///
 }       //
 }i   ///
 };aliz Add<Dungleme>xr<'dTSysstamp:p
        t expe #   Out the= TSysstamp;i   ///
 } expefseaddbool<E>_xpDunglemenle<ESatc::Out thep
        t expe
///       unimplemen        t expe}i   ///
 }       //
 }i   ///
 
/// # use serde::de::{self, Deserialize, Dese Vislized.
    ///
 
/// # impl<'de> Deserializr<'dTSysstamp:p
        de>,
{
    fn deserialize<D>(deserializer: D) -> Result<Self, D::Erro       ///    Erro       /re
        D: Deserializer<'deErro    //Erro       /re
 ifd       deseriis_auof _read= "us_empErro       /re
  {
    Dtular deseralizea huof -read= "ustter, "error"2015-05-15T17:01:00Z".pErro       /re
  {
     s:= r` or rialize::deserialize(deseri?;pErro       /re
  {
 TSysstamp::    fn f(&s).lie_eetu   Err(de::Error:)pErro       /re
 } elseempErro       /re
  {
    Dtular deseralizea nompactsppl necected` reerial,ewht d
sainncepErro       /re
  {
     thiUnix epoch.pErro       /re
  {
     n:= sigrialize::deserialize(deseri?;pErro       /re
  {
 Ok(TSysstamp::EPOCH +pDunglemeus ht d
s(n))pErro       /re
 }pErro       /}pErro    }    ///
 //
 e)))d.
    ///
 //mpit the d is an implementation onngth`rone =>te`keu `. D
//! [data     ///
 ofyboverray p `/ ples`falserifpectqusstea nompacts [danatioset of tyt
   ///
  ormat usefi Nooup `atpnodifyized t vanngth`r owthanghoulf data ys /
of
     auof -read= "us owt mpactssr>(scusseroamessage shoregs/ps is us breakple    ///
 thangh,is us is thecan be seriin auof -read= "usnodh// that eive a dswe    ///
 dcular deseralize! tlcam Oze ananwt mpactsnodh. e)))#[doc(no]
   /// is_auof _read= "usol(v),zer: vise>,
    {
 keu mData))E       Noopebulic API. e)))#[cfg(s  ("std", 
//! [`serde)y Sey("std", f=mattdive std", f=ma elte"))size)))std")]hiddensize)))
{
__    fn desernn thni V_besult {
 te_sted {}",
 _xp   use acte`] m_perd use T:ed {}",
 (s
/// : Vted {})ata: A) ->    use __perd use    ECn thni alize:Resultlf, D::Error>
    where
 Ve
l<'de> Visi,   type V   use __perd use    ECn thni alizter<'de>,
    {
 te_st    fn deserf y( s
/// i      }
    }
}

/////////////////////////////////////////////////////////////////////////////
 Ton of thirected` repret s
/// Vtained lksd t 0\] t ydf the Deseriaceive.
/)}LifetSystemive.
///mpdisi`ompfetSysntation of thirgument eive a  of pprialpfetSysntatom a
as
 intypses it por(dweriali`Result<Self`xpSgram. Sphe m[Unrdend
//ple/// #ialize(deser mpfetSyss]opriateal fodetaicro nts an explanatAll ofmpfetSyss forive.
/eUnrdend
//ple#ialize(deser mpfetSyss]alize`]: https://sempfetSyss ialize./e = ()}e> for  Sesed.
///
/// ```edition2021
/// # use serde::de::{self, Unexpected, Visitor};
/// # use std::fmt;
/////
    s
/// Vtained# The Deserecelole#tter, "-eoatter, "   /// con typleast;
/////
 out o/ uimumzns the numis th/     std")]
LoleSter, "s,
/// {
// ugth(len:eself))
//ive/a
/// # impl<'de> Visitor<'dLoleSter, "s,
/// {
/
{
    type Vr` or ;
 = 
       ///     fn expecting(&self, formatter: &mut fmt::Formatter) -> fmt::Re       /;

        write!(formasatter, "   /// con typleast {}mis thng {e_st/ uooleanield}&sel
       ///     fn trit_bool<E>sxpeer(&le<E>() -> Result<Self::Value,    ///           ///  cted.
    Seq,
rro    //       ///  sg o.lens_e>= {e_st/ uemp       ///  re
/Ok(s.to_ow co()ooleanield))
 } elseemp       ///  re
/retu   Err(de::Error::iis thid_type(UnexpSwrit:Bool(v), &self))
        =  re
/}&self))
//# }
/       publ<'de> Visit!(Error:p
        Tis is theproducerialiion oo<'de> xpecte #     typ;

           ata e4". The metglezedion of what/tedis
/// Visitor expects to ialized.
    ///
 //
/// Tunca sio build error messag4". The message s. The copletes the s    ///
 "T/tedis
/// Visitor expects to receive ...", for example the message c    ///
 "ainin
/// integer between 0 and 64". The message should not be capitali
   ///
  ssage shou// not end with a plized.
    ///
 //
/// ```editi   ///
 };
/// # use std    //
 }i   ///
 };tteype Sep
        t expemaxgth(len:ed {}//
 }       //
 }i   ///
 };alizVisito # use serdl<'de> Visitor<'dS:p
        t expe #     type Value    //
 }i   ///
 //     fn expecting(&self, formatter: &mut fmt::Formatter) -> fmt::ReErro       //      write!(formasedin
/// integer between{}ng {e_st/ax)pErro    }    ///
 # }    ///
 //
 e)))//     fn expecting(&self, formatter: &mut fmt::Formatter) -> fmt:;

        Tcahng thet data c ly not a . e)))d.
    ///
 //mpit the d is an implemenfaicheot end  #   ows a. e)))
{
/// fn visit_bool<E>(self, v: bool) -> Result<Self::ValError>
    where
 E!( as Ser<'de>,
    {
 retu       Error::invalid_type(Unexpected::Bool(v), &Data))E        Tcahng thet data c lninteg. e)))d.
    ///
 //mpit the d is an implemenforws/p expe[`/// fnt` o]ialized.
    ///
 e`/// fnt` o]: #nngth`x/// fnt`  e)))
{
/// fni8it_bool<E>(sei8v: bool) -> Result<Self::ValError>
    where
 E!( as Ser<'de>,
    {
 {e_st/// fnt` (vis un64 &Data))E        Tcahng thet data c lnint16g. e)))d.
    ///
 //mpit the d is an implemenforws/p expe[`/// fnt` o]ialized.
    ///
 e`/// fnt` o]: #nngth`x/// fnt`  e)))
{
/// fni16it_bool<E>(sei16v: bool) -> Result<Self::ValError>
    where
 E!( as Ser<'de>,
    {
 {e_st/// fnt` (vis un64 &Data))E        Tcahng thet data c lnint32g. e)))d.
    ///
 //mpit the d is an implemenforws/p expe[`/// fnt` o]ialized.
    ///
 e`/// fnt` o]: #nngth`x/// fnt`  e)))
{
/// fni32it_bool<E>(sei32v: bool) -> Result<Self::ValError>
    where
 E!( as Ser<'de>,
    {
 {e_st/// fnt` (vis un64 &Data))E        Tcahng thet data c lnint` o. e)))d.
    ///
 //mpit the d is an implemenfaicheot end  #   ows a. e)))
{
/// fni64it_bool<E>(seiignle<Eol) -> Result<Self::ValError>
    where
 E!( as Ser<'de>,
    {
 retu       Error::invalid_type(UnexpSig co(::Bool(v), &Data))E        Tcahng thet data c lint12eg. e)))d.
    ///
 //mpit the d is an implemenfaicheot end  #   ows a. e)))
{
/// fni128it_bool<E>(sei128v: bool) -> Result<Self::ValError>
    where
 E!( as Ser<'de>,
    {
     tterbufe V[0u8; 58];,
    {
     tter/    t:= &self,xpeufap(Sea&tterbufalue()));
 er) -W    ::/    _    &tter/    tg(&self,_args!("in
/// i`{}`is ui128ng v)).unwrap();,
    {
 retu       Error::invali
   ///  re
/d_type(UnexpOle o(/    t.asfn f()),
   ///  re
/&te_sted {}",
 , &Data))E        Tcahng thet data c linueg. e)))d.
    ///
 //mpit the d is an implemenforws/p expe[`/// fnu` o]ialized.
    ///
 e`/// fnu` o]: #nngth`x/// fnu`  e)))
{
/// fnu8it_bool<E>(seu8v: bool) -> Result<Self::ValError>
    where
 E!( as Ser<'de>,
    {
 {e_st/// fnu` (vis uu64 &Data))E        Tcahng thet data c l `u16g. e)))d.
    ///
 //mpit the d is an implemenforws/p expe[`/// fnu` o]ialized.
    ///
 e`/// fnu` o]: #nngth`x/// fnu`  e)))
{
/// fnu16it_bool<E>(seu16v: bool) -> Result<Self::ValError>
    where
 E!( as Ser<'de>,
    {
 {e_st/// fnu` (vis uu64 &Data))E        Tcahng thet data c l `u32g. e)))d.
    ///
 //mpit the d is an implemenforws/p expe[`/// fnu` o]ialized.
    ///
 e`/// fnu` o]: #nngth`x/// fnu`  e)))
{
/// fnu32it_bool<E>(seu32v: bool) -> Result<Self::ValError>
    where
 E!( as Ser<'de>,
    {
 {e_st/// fnu` (vis uu64 &Data))E        Tcahng thet data c l `u` o. e)))d.
    ///
 //mpit the d is an implemenfaicheot end  #   ows a. e)))
{
/// fnu64it_bool<E>(seuignle<Eol) -> Result<Self::ValError>
    where
 E!( as Ser<'de>,
    {
 retu       Error::invalid_type(UnexpUnsig co(::Bool(v), &Data))E        Tcahng thet data c linu12eg. e)))d.
    ///
 //mpit the d is an implemenfaicheot end  #   ows a. e)))
{
/// fnu128it_bool<E>(seu128v: bool) -> Result<Self::ValError>
    where
 E!( as Ser<'de>,
    {
     tterbufe V[0u8; 57];,
    {
     tter/    t:= &self,xpeufap(Sea&tterbufalue()));
 er) -W    ::/    _    &tter/    tg(&self,_args!("in
/// i`{}`is uu128ng v)).unwrap();,
    {
 retu       Error::invali
   ///  re
/d_type(UnexpOle o(/    t.asfn f()),
   ///  re
/&te_sted {}",
 , &Data))E        Tcahng thet data c ln `f16`. e)))d.
    ///
 //mpit the d is an implemenforws/p expe[`/// fnf` o]ialized.
    ///
 e`/// fnf` o]: #nngth`x/// fnf`  e)))
{
/// fnf32it_bool<E>(sef32v: bool) -> Result<Self::ValError>
    where
 E!( as Ser<'de>,
    {
 {e_st/// fnf` (vis uf64 &Data))E        Tcahng thet data c lninf` o. e)))d.
    ///
 //mpit the d is an implemenfaicheot end  #   ows a. e)))
{
/// fnf64it_bool<E>(sefignle<Eol) -> Result<Self::ValError>
    where
 E!( as Ser<'de>,
    {
 retu       Error::invalid_type(UnexpFloat(::Bool(v), &Data))E        Tcahng thet data c linned a. e)))d.
    ///
 //mpit the d is an implemenforws/p expe[`/// fntte`]is us one-ned ac fo4` that
 tter, ialized.
    ///
 e`/// fntte`]: #nngth`x/// fntte e)))#[doc(no]
   /// /// fnned it_bool<E>(sened v: bool) -> Result<Self::ValError>
    where
 E!( as Ser<'de>,
    {
 {e_st/// fnn f(v.emende_utf8 &tter[0u8; 4], &Data))E        Tcahng thet data c litter, i TcahmpfetSysntatioustter, "isprphan raltali
   ///
 iypses it detteoypitafteriacn onngth`rone =>tialized.
    ///
 //
//nngth`rallows#ing to the `Deseriafe avoirda nopyialire/// con         ow crihipiofaf y buafererih tr.rallows `Deserialize` implementtainedohat was
    /benefiifferentaki isow crihipiofatr` or `Sh tr  ssage   d!("dup `athat was
 ipenherit The Deserialiusized`
//! [`Deserrialize::desein f`nrale orinai/of
      
//! [`Deserrialize::deseitter, ` flized.
    ///
 Iirgumnev orcorrclfsweialize` im `/// fntteor `Sed and  i the [Imple/of
      /// fntte`.////! # Immneile o, bothy , i woul /// fntte`.
   ///     fn trit_bool<E>vxpeer(&le<E>() -> Result<Self::ValError>
    where
 E!( as Ser<'de>,
    {
 retu       Error::invalid_type(UnexpS f(v:Bool(v), &Data))E        Tcahng thet data c litter, "] typliv prtypleast aselole#asideo         do the `Deseri flized.
    ///
 //
//\] *ise sero-nopyiicular deseriali tupser, n sioout o [data  expo,   ///
 ", for et of ng the   /// con ods  basitter, "`"por(dwer"`f these    ///
 dcular dese not ensero nopyr, ire
o au8lOther(` aselole#asideo ng th
           / Strliv pr`'aa. e)))d.
    ///
 //mpit the d is an implemenforws/p expe /// fntte`.
   /#[doc(no]
   /// /// fnpor(dwern trit_bool<E>vxpe'de er(&le<E>() -> Result<Self::ValError>
    where
 E!( as Ser<'de>,
    {
 {e_st/// fnn f(v &Data))E        Tcahng thet data c litter, "weenow crihipiofaioustter, "ispbeiriagiv nhat was
 ipenhern, the `Vialized.
    ///
 //
//nngth`rallows#ing t, the `Vife avoirda nopyialitaki isow crihipiof    ///
 satter, " ns toonovideo do the `Deseri rallows `Deserialize` implemenhat was
 i typbenefiifferentaki isow crihipiofatr` or `Sh tr  ssage   d!("dup `athat was
 ipenherit The Deserialiusized`
//! [`Deserrialize::desein for `Srale ohat was
 i tnd`
//! [`Deserrialize::desein f`,l t andgh shou/v ofoit The Deser4` that
  tll honnronuchzeceiqusst flized.
    ///
 Iirgumnev orcorrclfsweialize` im `/// fntteor `Sed and  i the [Imple/of
      /// fntte`.////! # Immneile o, bothy , i woul /// fntte`.
   /d.
    ///
 //mpit the d is an implemenforws/p expe /// fntte`ior map sedropsideo         dSter, ` flize#[doc(no]
   /#[cfg(sey("std", f=mattdive std", f=ma elte"))]
   /#[cfg_at f(docsrnA>(oc(cfg(sey("std", f=mattdive std", f=ma elte"))))]
   ///     fn trize t_bool<E>vxpSter, &le<E>() -> Result<Self::ValError>
    where
 E!( as Ser<'de>,
    {
 {e_st/// fnn f(&v &Data))E        Tcahng thet data c li _str("byti TcahmpfetSysntatious _str("byteinhat was
 rphan raltali iypses it detteoypitafteriacn onngth`rone =>tialized.
    ///
 //
//nngth`rallows#ing to the `Deseriafe avoirda nopyialire/// con         ow crihipiofaf y buafererih tr.rallows `Deserialize` implementtainedohat was
    /benefiifferentaki isow crihipiofat]` or `Veh tr  ssage   d!("dup `athat was
 ipenherit The Deserialiusized`
//! [`Deserrialize::deseiis th`Srale ohat was
 i tnd`
//! [`Deserrialize::desei _st_bua` flized.
    ///
 Iirgumnev orcorrclfsweialize` im `/// fn _st_bua`Sed and  i the [Imple/of
      /// fnis th`.////! # Immneile o, bothy , i woul /// fnis th`.
   /// /// fnps th t_bool<E>vxpe[u8]v: bool) -> Result<Self::ValError>
    where
 E!( as Ser<'de>,
    {
 retu       Error::invalid_type(Unexpes th(v:Bool(v), &Data))E        Tcahng thet data c li _str("byte] typliv prtypleast aselole#asideo         do the `Deseri flized.
    ///
 //
//\] *ise sero-nopyiicular deseriali tuis thesioout o [data  expo,   ///
 ", for ePmunns/plh tr    /// con is the* that
dcular dese not ensero
of
     nopyr, ire
o au8lOth[u8]` aselole#asideo ng th    / Strliv pr`'aa. e)))d.
    ///
 //mpit the d is an implemenforws/p expe /// fnis th`.
   /#[doc(no]
   /// /// fnpor(dwernps th t_bool<E>vxpe'de [u8]v: bool) -> Result<Self::ValError>
    where
 E!( as Ser<'de>,
    {
 {e_st/// fnbs th(v:&Data))E        Tcahng thet data c li _str("byteweenow crihipiofaious _str("byteinpbeiriE        giv n ipenhern, the `Vialized.
    ///
 //
//nngth`rallows#ing t, the `Vife avoirda nopyialitaki isow crihipiof    ///
 sa _strbuafer" ns toonovideo do the `Deseri rallows `Deser    ///
 
///e` implementtainebenefiifferentaki isow crihipiofat]` or `Veh tr
   ///
  ssage   d!("dup `atplesing it The Deserialiusize/of
      
//! [`Deserrialize::desei _st_bua`Srale orinai/of
      
//! [`Deserrialize::deseiis th`,l t andgh shou/v ofoit The Deser  tll
of
     aonnronuchzeceiqusst flized.
    ///
 Iirgumnev orcorrclfsweialize` im `/// fn _st_bua`Sed and  i the [Imple/of
      /// fnis th`.////! # Immneile o, bothy , i woul /// fnis th`.
   /d.
    ///
 //mpit the d is an implemenforws/p expe /// fnis th`ior map sedropsideo         d]` or `V.
   /#[cfg(sey("std", f=mattdive std", f=ma elte"))]
   /#[cfg_at f(docsrnA>(oc(cfg(sey("std", f=mattdive std", f=ma elte"))))]
   ///     fnis t_buait_bool<E>vxp]` or `v: bool) -> Result<Self::ValError>
    where
 E!( as Ser<'de>,
    {
 {e_st/// fnbs th(&v &Data))E        Tcahng thet data c lnio_str(alo] typs iabsenh.alized.
    ///
 //mpit the d is an implemenfaicheot end  #   ows a. e)))
{
/// fnnof it_bool<v: bool) -> Result<Self::ValError>
    where
 E!( as Ser<'de>,
    {
 retu       Error::invalid_type(UnexpOprial,eol(v), &Data))E        Tcahng thet data c lnio_str(alo] typs ited` re.alized.
    ///
 //mpit the d is an implemenfaicheot end  #   ows a. e)))
{
/// fnout rialnum<A>(ze<D>(deserializer: D) -> Result<Self::<Self, D::Error>
    where
        D: Deserializer<'de>,
    {
     _me((ze<D>(deser;,
    {
 retu       Error::invalid_type(UnexpOprial,eol(v), &Data))E        Tcahng thet data c lae_stra un. e)))d.
    ///
 //mpit the d is an implemenfaicheot end  #   ows a. e)))
{
/// fnu_st t_bool<v: bool) -> Result<Self::ValError>
    where
 E!( as Ser<'de>,
    {
 retu       Error::invalid_type(Unexp    ,eol(v), &Data))E        Tcahng thet data c lained a newtype. e)))d.
    ///
 //mpnn thniiofaiousined a newtype ses it readralize! tlgiv nhat was
 do the `Deseri flized.
    ///
 //mpit the d is an implemenfaicheot end  #   ows a. e)))
{
/// fnn_str("_y data ialnum<A>(ze<D>(deserializer: D) -> Result<Self::<Self, D::Error>
    where
        D: Deserializer<'de>,
    {
     _me((ze<D>(deser;,
    {
 retu       Error::invalid_type(UnexpN_str("S  for,iol(v), &Data))E        Tcahng thet data c liting a seqfaber of s.alized.
    ///
 //mpit the d is an implemenfaicheot end  #   ows a. e)))
{
/// fnoeqit_enum<A> eqf, data: A) -> Result<Self::ASelf, D::Error>
    where
    naqA: Enurilizer<'de>,
    {
     _me( eq;,
    {
 retu       Error::invalid_type(Unexpnaq,iol(v), &Data))E        Tcahng thet data c likey-is theliesalized.
    ///
 //mpit the d is an implemenfaicheot end  #   ows a. e)))
{
/// fnlie t_enum<A>tapf, data: A) -> Result<Self::ASelf, D::Error>
    where
    MapA: Enurilizer<'de>,
    {
     _me(tap;,
    {
 retu       Error::invalid_type(UnexpMap,eol(v), &Data))E        Tcahng thet data c lnined salized.
    ///
 //mpit the d is an implemenfaicheot end  #   ows a. e)))
{
/// fnned  t_enum<A>h trf, data: A) -> Result<Self::ASelf, D::Error>
    where
    Eed A: Enurilizer<'de>,
    {
     _me(h tr;,
    {
 retu       Error::invalid_type(UnexpEed ,eol(v), &Data))E       Unca Raised when deserioulfle!(fneu/Oprial licat. Noopebulic API. e)))#[d")]hiddensize)))
{
__perd us_/// fnu_taggerno_str( ialnum<A>_ializer: D) -> Result<Self::()::Error>
    where
        D: Deserializer<'de>,
    {
 retu()i      }
    }
}

/////////////////////////////////////////////////////////////////////////////
 Providerecet, the `Via: Enuexpeea =>ber of Outsidning a seresent in th.aemive.
///
/// Ta    pub] typa to the `Deseriat encuexpelxt of a `Visitor` implemeq,
rroRainstd# The Desereea =>itempresianing a s.ze./e = ()}LifetSystemive.
///mpdisi`ompfetSysntation of thirgument mpfetSysntatom an] typses it///
 por(dweriby
dcular dese nning a seber of s.pSgram. Sphe m[Unrdend
//ple/// #ialize(deser mpfetSyss]opriateal fodetaicro nts an explanatAll ofmpfetSyss forive.
/eUnrdend
//ple#ialize(deser mpfetSyss]alize`]: https://sempfetSyss ialize./e = ()}e> for d.ample implemen
//
       /// The [example data format] presented on the wdem     at seor
//
 
///e` implemeiofatraqA: Enu`opriate for a basixample data forive.
/e  /// [example data format]: https://serde.rs/data-forma       pubnaqA: Enuriliz:p
        Tis  build, V>`] typ* that
ree =>ca sg out o buildoccurs>(urple    ///
 dcular deserial.z /// #     tit!( as StdE        //
//one =>te`Ok(atio(ives ))`opriad w i!(mtives aanopletesng a sy , hat was
 dOk(Noneunirfr `{}`, thenoeal forem// con items.alized.
    ///
 allows `Deserialize` implementessage  #  &`] mauso         dSaqA: Enuap(Sxfnnze` im`   stead. e)))
{
(Sxfnnze` imnoeed<T> &tternum<A> enex Tizer: D) -> Oprial<Tlt<Selfze:Resultlf, D::Error>
    where
 T      D: DeseSeed<isittdE        //
//one =>te`Ok(atio(ives ))`opriad w i!(mtives aanopletesng a sy , hat was
 dOk(Noneunirfr `{}`, thenoeal forem// con items.alized.
    ///
 //
//nngth`rexisepresda nonv ni a sepriaallows `Deserialize` implemen.         dSaqA: Enurialize` implementessage shouoverray p `mpit the default b.
   /#[doc(no]
   /// (Sxfnnze` im<T> &tternum<izer: D) -> Oprial<Tze:Resultlf, D::Error>
    where
 T      D: Deseializer<'de>,
    {
 {e_st(Sxfnnze` imnoeed(<T, E>(Phan &Data))E        Rne =>ted w is the number of sorem// con inopletesng a sy rfr    ".
   /#[doc(no]
   /// (len_Tinrsol(v),zer:Oprial<h(len>e>,
    {
 None      }
  alizVisi, 'a::A>bnaqA: Enuriliz:prialOthtterA
r>
    whe   ?Error:+ naqA: Enurilizer{z /// #     titme(ASelf, DtdE    #[doc(no]
   /// (Sxfnnze` imnoeed<T> &tternum<A> enex Tizer: D) -> Oprial<Tlt<Selfze:Resultlf, D::Error>
    where
 T      D: DeseSeed<isiter<'de>,
    {
 (//sgv),t(Sxfnnze` imnoeed(oeed &Data))E    #[doc(no]
   /// (Sxfnnze` im<T> &tternum<izer: D) -> Oprial<Tze:Resultlf, D::Error>
    where
 T      D: Deseializer<'de>,
    {
 (//sgv),t(Sxfnnze` im( &Data))E    #[doc(no]
   /// (len_Tinrsol(v),zer:Oprial<h(len>e>,
    {
 (//sgv),t(len_Tinrsi      }
    }
}

/////////////////////////////////////////////////////////////////////////////
 Providerecet, the `Via: Enuexpeea =>breofoutsidliedresent in th.aemive.
///
/// Ta    pub] typa to the `Deseriat encuexpelxt of a `Visitor` impleme.ze./e = ()}LifetSystemive.
///mpdisi`ompfetSysntation of thirgument mpfetSysntatom an] typses it///
 por(dweriby
dcular dese nliedbreoies.pSgram. Sphe m[Unrdend
//ple/// #ialize(deser mpfetSyss]opriateal fodetaicro nts an explanatAll ofmpfetSyss forive.
/eUnrdend
//ple#ialize(deser mpfetSyss]alize`]: https://sempfetSyss ialize./e = ()}e> for d.ample implemen
//
       /// The [example data format] presented on the wdem     at seor
//
 
///e` implemeiofatMapA: Enu`opriate for a basixample data forive.
/e  /// [example data format]: https://serde.rs/data-forma       pubMapA: Enuriliz:p
        Tis  build, V>`] typ* that
ree =>ca sg out o buildoccurs>(urple    ///
 dcular deserial.z /// #     tit!( as StdE        //
//one =>te`Ok(atio(key))`opriad w i!(mtkeydresent map,eriaaOk(Noneun    ///
 
fr `{}`, thenoeal forem// con breoies.alized.
    ///
 allows `Deserialize` implementessage  #  &`] mauso         dMapA: Enuap(Sxfnkey`eriaaMapA: Enuap(Sxfnbreof`   stead. e)))
{
(Sxfnkeynoeed<K> &tternum<A> enex Kizer: D) -> Oprial<Klt<Selfze:Resultlf, D::Error>
    where
 K      D: DeseSeed<isittdE        //
//one =>teaaaOk(ives )`opriad w i!(mtives aanopletliesalized.
    ///
 allows `Deserialize` implementessage  #  &`] mauso         dMapA: Enuap(SxfnvSelf`   stead. e)))d.
    ///
 # Panics e)))d.
    ///
 C`] ized`(SxfnvSelfnoeed`hatfl fo`(Sxfnkeynoeed`aisprecorrclfsali inhat was
 allowonly npaniceriaone => pogu//on) ->s. e)))
{
(SxfnvSelfnoeed V_b&tternum<A> enex Vdata: A) -> ]lt<Self::Resultlf, D::Error>
    where
 Ve
    D: DeseSeed<isittdE        //
//one =>te`Ok(atio((key, ives )))`opriad w i!(mt(key-is th)epaieprehat was
 i t map,eriaaOk(Noneunirfr `{}`, thenoeal forem// con items.alized.
    ///
 aMapA: Enu`oalize` implementessage overray p `mpit the default birfrr
   ///
 al fotcfic enh 
///e` implemeis itossi "usalized.
    ///
 allows `Deserialize` implementessage  #  &`] mauso         dMapA: Enuap(Sxfnbreof`   stead. e)))#[doc(no]
   /// (Sxfnnreofnoeed<K, V_besult {
 &tternum<Aesult {
 k enex K:ed {}",
 ( enex Vted {})ata: A) -> Oprial<(Klt<Self::]lt<Self)ze:Resultlf, D::Error>
    where
 K      D: DeseSeed<isit,  where
 Ve
    D: DeseSeed<isiter<'de>,
    {
 ata =>eoi!({e_st(Sxfnkeynoeed(k ene))e>,
    {
     atio(key) =>e>,
    {
      {
     v type Veoi!({e_st(SxfnvSelfnoeed(v ene));,
    {
      {
 Ok(atio((key, ives ))),
    {
     },
    {
     None =>eOk(Noneu,  where
 }&Data))E        Tc
//one =>te`Ok(atio(key))`opriad w i!(mtkeydresent map,eriaaOk(Noneun    ///
 
fr `{}`, thenoeal forem// con breoies.alized.
    ///
 //
//nngth`rexisepresda nonv ni a sepriaallows `Deserialize` implemen.         dMapA: Enu`oalize` implementessage shouoverray p `mpit the default b.
   /#[doc(no]
   /// (Sxfnkey<K> &tternum<izer: D) -> Oprial<Kze:Resultlf, D::Error>
    where
 K      D: Deseializer<'de>,
    {
 {e_st(Sxfnkeynoeed(<T, E>(Phan &Data))E        //
//one =>teaaaOk(ives )`opriad w i!(mtives aanopletliesalized.
    ///
 //
//nngth`rexisepresda nonv ni a sepriaallows `Deserialize` implemen.         dMapA: Enu`oalize` implementessage shouoverray p `mpit the default b.
   /d.
    ///
 # Panics e)))d.
    ///
 C`] ized`(SxfnvSelf`hatfl fo`(Sxfnkey`aisprecorrclfsali in allowonly E        winiceriaone => pogu//on) ->s. e)))#[doc(no]
   /// (SxfnvSelf V_b&tternum<data: A) -> ]::Resultlf, D::Error>
    where
 Ve
    D: Deseializer<'de>,
    {
 {e_st(SxfnvSelfnoeed(<T, E>(Phan &Data))E        //
//one =>te`Ok(atio((key, ives )))`opriad w i!(mt(key-is th)epaieprehat was
 i t map,eriaaOk(Noneunirfr `{}`, thenoeal forem// con items.alized.
    ///
 //
//nngth`rexisepresda nonv ni a sepriaallows `Deserialize` implemen.         dMapA: Enu`oalize` implementessage shouoverray p `mpit the default b.
   /#[doc(no]
   /// (Sxfnnreof<K, V_b&tternum<izer: D) -> Oprial<(K, V)ze:Resultlf, D::Error>
    where
 K      D: Deseializer<'dere
 Ve
    D: Deseializer<'de>,
    {
 {e_st(Sxfnnreofnoeed(<T, E>(Phan, <T, E>(Phan &Data))E        Rne =>ted w is the numbreoiesorem// con inopletmap,erfr    ".
   /#[doc(no]
   /// (len_Tinrsol(v),zer:Oprial<h(len>e>,
    {
 None      }
  alizVisi, 'a::A>bMapA: Enuriliz:prialOthtterA
r>
    whe   ?Error:+ MapA: Enurilizer{z /// #     titme(ASelf, DtdE    #[doc(no]
   /// (Sxfnkeynoeed<K> &tternum<A> enex Kizer: D) -> Oprial<Klt<Selfze:Resultlf, D::Error>
    where
 K      D: DeseSeed<isiter<'de>,
    {
 (//sgv),t(Sxfnkeynoeed(oeed &Data))E    #[doc(no]
   /// (SxfnvSelfnoeed V_b&tternum<A> enex Vdata: A) -> ]lt<Self::Resultlf, D::Error>
    where
 Ve
    D: DeseSeed<isiter<'de>,
    {
 (//sgv),t(SxfnvSelfnoeed(oeed &Data))E    #[doc(no]
   /// (Sxfnnreofnoeed<K, V_besult {
 &tternum<Aesult {
 k enex K:ed {}",
 ( enex Vted {})ata: A) -> Oprial<(Klt<Self::]lt<Self)ze:Resultlf, D::Error>
    where
 K      D: DeseSeed<isit,  where
 Ve
    D: DeseSeed<isiter<'de>,
    {
 (//sgv),t(Sxfnnreofnoeed(k ene, ( ene &Data))E    #[doc(no]
   /// (Sxfnnreof<K, V_b&tternum<izer: D) -> Oprial<(K, V)ze:Resultlf, D::Error>
    where
 K      D: Deseializer<'dere
 Ve
    D: Deseializer<'de>,
    {
 (//sgv),t(Sxfnnreof( &Data))E    #[doc(no]
   /// (Sxfnkey<K> &tternum<izer: D) -> Oprial<Kze:Resultlf, D::Error>
    where
 K      D: Deseializer<'de>,
    {
 (//sgv),t(Sxfnkey( &Data))E    #[doc(no]
   /// (SxfnvSelf V_b&tternum<data: A) -> ]::Resultlf, D::Error>
    where
 Ve
    D: Deseializer<'de>,
    {
 (//sgv),t(SxfnvSelf( &Data))E    #[doc(no]
   /// (len_Tinrsol(v),zer:Oprial<h(len>e>,
    {
 (//sgv),t(len_Tinrsi      }
    }
}

/////////////////////////////////////////////////////////////////////////////
 Providerecet, the `Via: Enuexpe `mpi  / Satioened aresent in th.aemive.
/`Eed A: Enu`aisp ns toonovideo do the `Deseri alizy encdexpe `mve.
/` of a `Visnerideriapeid[ImplyoRainstisruct  Satioened awe try to dese.ze./e = ()}LifetSystemive.
///mpdisi`ompfetSysntation of thirgument mpfetSysntatom an] typses it///
 por(dweriby
ing it The Desedened aisruct .pSgram. Sphe m[Unrdend
//ple/// #ialize(deser mpfetSyss]opriateal fodetaicro nts an explanatAll ofmpfetSyss forive.
/eUnrdend
//ple#ialize(deser mpfetSyss]alize`]: https://sempfetSyss ialize./e = ()}e> for d.ample implemen
//
       /// The [example data format] presented on the wdem     at seor
//
 
///e` implemeiofatEed A: Enu`apriate for a basixample data forive.
/e  /// [example data format]: https://serde.rs/data-forma       pubEed A: Enuriliz!(Error:p
        Tis  build, V>`] typ* that
ree =>ca sg out o buildoccurs>(urple    ///
 dcular deserial.z /// #     tit!( as Std        Tis t, the `Vifainedtll at
uncdexpedcular deserle pnn thniiofaiousned     ///
 ooruct . e))) #     ruct :   ruct A: Enurili,   titme(Resultlf, D:tdE        `ooruct `aisp allcdexpeid[ImplyoRainstisruct  we try to dese.zlized.
    ///
 allows `Deserialize` implementessage  #  &`] mausoatEed A: Enu::ooruct `
          stead. e)))
{
ooruct noeed V_bnum<A> enex Vdata: A) -> (]lt<Self::Result  ruct )::Resultlf, D::Error>
    where
 Ve
    D: DeseSeed<isittdE        `ooruct `aisp allcdexpeid[ImplyoRainstisruct  we try to dese.zlized.
    ///
 //
//nngth`rexisepresda nonv ni a sepriaallows `Deserialize` implemen.         dEed A: Enu`ailize` implementessage shouoverray p `mpit the default b.
   /#[doc(no]
   /// isruct  V_bnum<data: A) -> (]::Result  ruct )::Resultlf, D::Error>
    where
 Ve
    D: Deseializer<'de>,
    {
 {e_stooruct noeed(<T, E>(Phan &Data))
    } t, ruct A: Enu`// Ta  s
/// Vtaineisp ns toonovideo do the `Deseri ali
    wiencdexpe `miollows `Deserifpedcular deserle pnn thniiofad with a parsned  //
 ooruct . e./e = ()}LifetSystemive.
///mpdisi`ompfetSysntation of thirgument mpfetSysntatom an] typses it///
 por(dweriby
ing it The Desedened aisruct .pSgram. Sphe m[Unrdend
//ple/// #ialize(deser mpfetSyss]opriateal fodetaicro nts an explanatAll ofmpfetSyss forive.
/eUnrdend
//ple#ialize(deser mpfetSyss]alize`]: https://sempfetSyss ialize./e = ()}e> for d.ample implemen
//
       /// The [example data format] presented on the wdem     at seor
//
 
///e` implemeiofat, ruct A: Enu`/priate for a basixample data forive.
/e  /// [example data format]: https://serde.rs/data-forma       pub  ruct A: Enuriliz!(Error:p
        Tis  build, V>`] typ* that
ree =>ca sg out o buildoccurs>(urple    ///
 dcular deserial. Mwoulata =>eis  build, V>`ofaour dEed A: Enu`.z /// #     tit!( as StdE        CallcdeRaised when deserioulisruct  ot ennoaives s. e)))d.
    ///
 Iftatioh tr    ///  Ta diaferet  w V>`ofaisruct ,tatiofollowple/of
      Error::inval`  buildessage sho      fornexplized.
    ///
 //
/// ```editi   ///
 };
/// # use serde::de::vSelf::<   D: DeseSeedxpected, ,b  ruct A: Enu::{self, Une}td    //
 }i   ///
 };tteype X;     //
 }i   ///
 };alizVisito  ruct A: Enuriliz/priaX:p
        t expe #     titme(vSelfSelf, Dtd    //
 }i   ///
 // u_st_isruct bnum<data: A) -> ()::Resultlf, D::ReErro       /   Wrian thih tr acte`] m    /// ed;  ormae bhirgumoae_str(ooruct . e)))       /    uselfme(d_type(UnexpT_str  ruct ;pErro       /retu   Err(de::Error::invaliuself, &"e_str("ruct "))pErro    }    ///
 #i   ///
 } expefsen_str("_ooruct noeed Talnum<A>_iaTizer: D) -> Tlt<Self::Resultlf, D::Erro//
 } expe//    Erro    t expe
///T      D: DeseSeed<isiter<'de    t expe /       unimplemee}i   ///
 }i   ///
 } expefsee_str_isruct  V_bnum<A>_iah(len: _x Vdata: A) -> ]lt<Self::Resultlf, D::Erro//
 } expe//    Erro    t expe
///Ve
l<'de> Visiter<'de    t expe /       unimplemee}i   ///
 }i   ///
 } expefsetteype_isruct  V_bnum<A>_ia&[&stat: _x Vdata: A) -> ]lt<Self::Resultlf, D::Erro//
 } expe//    Erro    t expe
///Ve
l<'de> Visiter<'de    t expe /       unimplemee}i   ///
 } }    ///
 //
 e)))// u_st_isruct bnum<data: A) -> ()::Resultlf, D:tdE        CallcdeRaised when deserioulisruct  ot enaainngls is thsalized.
    ///
 allows `Deserialize` implementessage  #  &`] mauso         d  ruct A: Enuap(Setr("_ooruct `   stead. e)))d.
    ///
 Iftatioh tr    ///  Ta diaferet  w V>`ofaisruct ,tatiofollowple/of
      Error::inval`  buildessage sho      fornexplized.
    ///
 //
/// ```editi   ///
 };
/// # use serde::de::vSelf::<   D: DeseSeedxpected, ,b  ruct A: Enu::{self, Une}td    //
 }i   ///
 };tteype X;     //
 }i   ///
 };alizVisito  ruct A: Enuriliz/priaX:p
        t expe #     titme(vSelfSelf, Dtd    //
 }i   ///
 } expefseu_st_isruct bnum<data: A) -> ()::Resultlf, D::ReErro    t expe
///       unimplemen        t expe}i   ///
 }i   ///
 // n_str("_ooruct noeed Talnum<A>_ enex Tizer: D) -> Tlt<Self::Resultlf, D::Erro//
 //    Erro       /T      D: DeseSeed<isiter<'de    ReErro       /   Wrian thih tr acte`] m    /// ed;  ormae bhirgumoae_str("ruct . e)))       /    uselfme(d_type(Unexp      ruct ;pErro       /retu   Err(de::Error::invaliuself, &"ined a n("ruct "))pErro    }    ///
 #i   ///
 } expefsee_str_isruct  V_bnum<A>_iah(len: _x Vdata: A) -> ]lt<Self::Resultlf, D::Erro//
 } expe//    Erro    t expe
///Ve
l<'de> Visiter<'de    t expe /       unimplemee}i   ///
 }i   ///
 } expefsetteype_isruct  V_bnum<A>_ia&[&stat: _x Vdata: A) -> ]lt<Self::Resultlf, D::Erro//
 } expe//    Erro    t expe
///Ve
l<'de> Visiter<'de    t expe /       unimplemee}i   ///
 } }    ///
 //
 e)))// n_str("_ooruct noeed Talnum<A> enex Tizer: D) -> Tlt<Self::Resultlf, D::Error>
    where
 T      D: DeseSeed<isittdE        CallcdeRaised when deserioulisruct  ot enaainngls is thsalized.
    ///
 //
//nngth`rexisepresda nonv ni a sepriaallows `Deserialize` implemen.         d, ruct A: Enu`//lize` implementessage shouoverray p `mpit the          efault b.
   /#[doc(no]
   /// (Sstr("_ooruct  Talnum<izer: D) -> Te:Resultlf, D::Error>
    where
 T      D: Deseializer<'de>,
    {
 {e_st(Sstr("_ooruct noeed(<T, E>(Phan &Data))E        CallcdeRaised when deserioule_str-error("ruct . e)))   d        Tis tlen`rgument is the numlicats type(Unearesent e_str(ooruct . e)))       ///
 Iftatioh tr    ///  Ta diaferet  w V>`ofaisruct ,tatiofollowple/of
      Error::inval`  buildessage sho      fornexplized.
    ///
 //
/// ```editi   ///
 };
/// # use serde::de::vSelf::<   D: DeseSeedxpected, ,b  ruct A: Enu::{self, Une}td    //
 }i   ///
 };tteype X;     //
 }i   ///
 };alizVisito  ruct A: Enuriliz/priaX:p
        t expe #     titme(vSelfSelf, Dtd    //
 }i   ///
 } expefseu_st_isruct bnum<data: A) -> ()::Resultlf, D::ReErro    t expe
///       unimplemen        t expe}i   ///
 }i   ///
 } expefsen_str("_ooruct noeed Talnum<A>_iaTizer: D) -> Tlt<Self::Resultlf, D::Erro//
 } expe//    Erro    t expe
///T      D: DeseSeed<isiter<'de    t expe /       unimplemee}i   ///
 }i   ///
 fsee_str_isruct  V_bnum<A>_leniah(len: _(s
/// : Vdata: A) -> ]lt<Self::Resultlf, D::Erro//
 //    Erro       /Ve
l<'de> Visiter<'de    ReErro       /   Wrian thih tr acte`] m    /// ed;  ormae bhirgumoae_str("ruct . e)))       /    uselfme(d_type(Unexp      ruct ;pErro       /retu   Err(de::Error::invaliuself, &"e_str(ooruct "))pErro    }    ///
 #i   ///
 } expefsetteype_isruct  V_bnum<A>_ia&[&stat: _x Vdata: A) -> ]lt<Self::Resultlf, D::Erro//
 } expe//    Erro    t expe
///Ve
l<'de> Visiter<'de    t expe /       unimplemee}i   ///
 } }    ///
 //
 e)))// e_str_isruct  V_bnum<A>leniah(len: (s
/// : Vdata: A) -> ]lt<Self::Resultlf, D::Error>
    where
 Ve
l<'de> VisittdE        CallcdeRaised when deserioultteype-error("ruct . e)))   d        Tis tlicats`, theent iamesiofaiouslicats ofaioustteype ooruct . e)))       ///
 Iftatioh tr    ///  Ta diaferet  w V>`ofaisruct ,tatiofollowple/of
      Error::inval`  buildessage sho      fornexplized.
    ///
 //
/// ```editi   ///
 };
/// # use serde::de::vSelf::<   D: DeseSeedxpected, ,b  ruct A: Enu::{self, Une}td    //
 }i   ///
 };tteype X;     //
 }i   ///
 };alizVisito  ruct A: Enuriliz/priaX:p
        t expe #     titme(vSelfSelf, Dtd    //
 }i   ///
 } expefseu_st_isruct bnum<data: A) -> ()::Resultlf, D::ReErro    t expe
///       unimplemen        t exp }    ///
 #i   ///
 } expefsen_str("_ooruct noeed Talnum<A>_iaTizer: D) -> Tlt<Self::Resultlf, D::Erro//
 } expe//    Erro    t expe
///T      D: DeseSeed<isiter<'de    t expe /       unimplemee}i   ///
 }i   ///
 } expefsee_str_isruct  V_bnum<A>_iah(len: _x Vdata: A) -> ]lt<Self::Resultlf, D::Erro//
 } expe//    Erro    t expe
///Ve
l<'de> Visiter<'de    t expe /       unimplemee}i   ///
 }i   ///
 fsetteype_isruct  V_bpErro       /num<Aesult       /_licatsxpe'etglec [e'etglec stat:esult       /_(s
/// : Vted {}    data: A) -> ]lt<Self::Resultlf, D::Erro//
 //    Erro       /Ve
l<'de> Visiter<'de    ReErro       /   Wrian thih tr acte`] m    /// ed;  ormae bhirgumoae_str("ruct . e)))       /    uselfme(d_type(Unexp      ruct ;pErro       /retu   Err(de::Error::invaliuself, &"tteype ooruct "))pErro    }    ///
 # }    ///
 //
 e)))// tteype_isruct  V_bpErro {
 te_sted {}",
 licatsxpe'etglec [e'etglec stat:esult",
 (s
/// : Vted {})ata: A) -> ]lt<Self::Resultlf, D::Error>
    where
 Ve
l<'de> Visittd
    }
}

/////////////////////////////////////////////////////////////////////////////
 Conv rtc lninxiseerioives aanxpelxto the `Deseri alizeRainstole orives sp* t///
 pg it The Desed. e./e = ()}LifetSystemive.
///mpdisi`ompfetSysntation of thirgument mpfetSysntatom an] typses it///
 por(dwerialize! tlon) ->ized`
//! [`Deser`xpSgram. Sphe m[Unrdend
//ple/// #ialize(deser mpfetSyss]opriateal fodetaicro nts an explanatAll ofmpfetSyss forive.
/eUnrdend
//ple#ialize(deser mpfetSyss]alize`]: https://sempfetSyss ialize./e = ()}e> for  Sesed.
///
/// ```edition20
/// # use serdevSelf::<   D: Dese, Inxp
//! [`DeserVisitor
/// # us_rdeiverd
//! [`Deseisitor
/// # ussta::FlizStr;
 = 
    #[rdeive(
//! [`Dese)]
    ned aSettr, "s,
/// {
/Onq,
rro    Off:eself))
//ive/a
/// FlizStror<'dSettr, "s,
/// {
/ #     tme(vSelfSelf, Dtdsel
       /// aliznn f(sxpeer(&le<E>() -> Resu::Resultlf,>emp       ///  Resultialize(dese(s.anxp_ialize(deser()ooleanield}&self))
//# }
/       pubInxp
//! [`Deserrili,  :   titme(vSelfSelf, Dz:p
        Tis w V>`ofaing it The Deseriaer, "   v rtneareto.z /// #   Dze<D>(deserial//! [`Deserrili,   titme(EttdE        C  v rtiion ooves aanxpelxit The Deser. e)))
{
anxp_ialize(deser(num<data:ResultDze<D>(deser;,
    }
}

/////////////////////////////////////////////////////////////////////////////
 Unca sio build error medsel
    - type(Unea`a`
    - type(Unea`a`eriaab`
    - type(Uneaone ofata`,aab`,aac`temive.
///mpsli seqfaiamesimwoulshould empty.
tteype OneOf:p
    iamesxpe'etglec [e'etglec stat:e
  aliz Diss ayor<'dOneOf:p
    // amtpecting(&self, formatter: &mut fmt::Formatter) -> fmt::ReErro {
 ata =>{e_st(ames.lens_e>,
    {
     0 =>ewinic!()::/
  pe(>(dp* se elser>
    where
     1 =>e/      write!(forma`{}`ng {e_st(ames[0]),
   ///  re
/2 =>e/      write!(forma`{}`eriaa{}`ng {e_st(ames[0]g {e_st(ames[1]),
   ///  re
/_ =>e>,
    {
      {
 eoi!(write!(fo./    _n f("one ofa"));,
    {
      {
 r<'d(i,l t )esiooe_st(ames.   t().ned e at s_e>,
    {
             if i > 0 >,
    {
              {
 eoi!(write!(fo./    _n f(",a"));,
    {
      {
     },
    {
          {
 eoi!(/      write!(forma`{}`ng  t ));,
    {
      {
 },
    {
      {
 Ok(()),
    {
     },
    {
 }&Data))
  tteype WithDe(>malPoinrsfign;  aliz Diss ayor<'dWithDe(>malPoinr:p
    // amtpecting(&self, formatter: &mut fmt::Formatter) -> fmt::ReErro {
 tteype Lookt fDe(>malPoinr<'f, 'a>e>,
    {
     &self, forma'f tter: &mut fmt::Fo<'a>,
   ///  re
/has_ia(>mal_poinrself, ,  where
 }&  where
 alizVif, 'a>eer) -W    or<'dLookt fDe(>malPoinr<'f, 'a>e>,
    {
     &n /    _n f(&tternum<A>fragunimxpeer(&le<Eer) -> fmt::ReErro {
 
    {
 {e_sthas_ia(>mal_poinr |=>fragunim.   ///  ('.');,
    {
      {
 {e_stwrite!(fo./    _n f(fragunim),
    {
     },,
    {
     &n /    _ned (&tternum<A>chsened v: boer) -> fmt::ReErro {
 
    {
 {e_sthas_ia(>mal_poinr |=> =>== '.';,
    {
      {
 {e_stwrite!(fo./    _ned (ch),
    {
     },
    {
 }&
        if {e_st0.is_li    s_e>,
    {
         tter/    t:= Lookt fDe(>malPoinr:ReErro {
 
    {
 write!(foreErro {
 
    {
 has_ia(>mal_poinrsefalsereErro {
 
   };,
    {
     eoi!(/      /    tg("{}ng {e_st0));,
    {
     if !/    t.has_ia(>mal_poinr >,
    {
      {
 eoi!(write!(fo./    _n f(".0"));,
    {
     },
    {
 } else >,
    {
     eoi!(/      write!(forma{}ng {e_st0));,
    {
 },
    {
 Ok(()),
   ))
        