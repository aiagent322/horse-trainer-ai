// Copyright 2016 - 2021 Ulrik Sverdrup "bluss"
//
// Licensed under the Apache License, Version 2.0 <LICENSE-APACHE or
// http://www.apache.org/licenses/LICENSE-2.0> or the MIT license
// <LICENSE-MIT or http://opensource.org/licenses/MIT>, at your
// option. This file may not be copied, modified, or distributed
// except according to those terms.

use crate::archparam;
use crate::packing::pack;

/// General matrix multiply kernel
pub(crate) trait GemmKernel {
    type Elem: Element;

    /// Kernel rows
    const MR: usize = Self::MRTy::VALUE;
    /// Kernel cols
    const NR: usize = Self::NRTy::VALUE;
    /// Kernel rows as const num type
    type MRTy: ConstNum;
    /// Kernel cols as const num type
    type NRTy: ConstNum;

    /// align inputs to this
    fn align_to() -> usize;

    /// Whether to always use the masked wrapper around the kernel.
    fn always_masked() -> bool;

    // These should ideally be tuned per kernel and per microarch
    #[inline(always)]
    fn nc() -> usize { archparam::S_NC }
    #[inline(always)]
    fn kc() -> usize { archparam::S_KC }
    #[inline(always)]
    fn mc() -> usize { archparam::S_MC }

    /// Pack matrix A into its packing buffer.
    ///
    /// See pack for more documentation.
    ///
    /// Override only if the default packing function does not
    /// use the right layout.
    #[inline]
    unsafe fn pack_mr(kc: usize, mc: usize, pack_buf: &mut [Self::Elem],
                      a: *const Self::Elem, rsa: isize, csa: isize)
    {
        pack::<Self::MRTy, _>(kc, mc, pack_buf, a, rsa, csa)
    }

    /// Pack matrix B into its packing buffer
    ///
    /// See pack for more documentation.
    ///
    /// Override only if the default packing function does not
    /// use the right layout.
    #[inline]
    unsafe fn pack_nr(kc: usize, mc: usize, pack_buf: &mut [Self::Elem],
                      a: *const Self::Elem, rsa: isize, csa: isize)
    {
        pack::<Self::NRTy, _>(kc, mc, pack_buf, a, rsa, csa)
    }


    /// Matrix multiplication kernel
    ///
    /// This does the matrix multiplication:
    ///
    /// C ← α A B + β C
    ///
    /// + `k`: length of data in a, b
    /// + a, b are packed
    /// + c has general strides
    /// + rsc: row stride of c
    /// + csc: col stride of c
    /// + `alpha`: scaling factor for A B product
    /// + `beta`: scaling factor for c.
    ///   Note: if `beta` is `0.`, the kernel should not (and must not)
    ///   read from c, its value is to be treated as if it was zero.
    ///
    /// When masked, the kernel is always called with β=0 but α is passed
    /// as usual. (This is only useful information if you return `true` from
    /// `always_masked`.)
    unsafe fn kernel(
        k: usize,
        alpha: Self::Elem,
        a: *const Self::Elem,
        b: *const Self::Elem,
        beta: Self::Elem,
        c: *mut Self::Elem, rsc: isize, csc: isize);
}

pub(crate) trait Element : Copy + Send + Sync {
    fn zero() -> Self;
    fn one() -> Self;
    fn test_value() -> Self;
    fn is_zero(&self) -> bool;
    fn add_assign(&mut self, rhs: Self);
    fn mul_assign(&mut self, rhs: Self);
}

impl Element for f32 {
    fn zero() -> Self { 0. }
    fn one() -> Self { 1. }
    fn test_value() -> Self { 1. }
    fn is_zero(&self) -> bool { *self == 0. }
    fn add_assign(&mut self, rhs: Self) { *self += rhs; }
    fn n zero() -> Self { 0. }
    fn o  debin a,e                         { 1. }
    fn is_zero(&self) -> bool { *self == 0. }
    fn add_assign(&mut self, rhs: Self) { *self += rhs; }
    fn n zero() -> Self { 0. }
    fn o  debin a,e                         { 1. }
    fn is_zero(&self) -> bool { *self == 0. }
    fn add_assign(ct MaskBuffer {
  st Self::Elem, rsa: isize, csa: on  Note: if `btn add_assign(ct MaskBuffer {
  st Self::Elem, rsa: isize, csa: on  Note: if `btn add_assign(ct MaskBuffer {
  st Self::Elem, rsa: isize, csa: on  Note: if `btn add_assign(ct MaskBuffer {
  st Self::Elem, rsa: isize, csa: on  Note: if `btn add_assign(ct MaskB rsa,1bm, rsa: ia: on  Note: if `btn add_a` b, rsb, c add_auf);
      t Gemr to s <= 8);
  nstly configuration detetion.
        let  GemmParameters {
            m, k, n,
    _assign(bet;ow stride of *x*
/// + cs<em>x#[s a w(e macamel_~)
/_usizsby n mct MaskB sizec3 } el   ; 2oop4tride of *x*
/// + cs<em>x#[s a w(e macamel_~)
/_usizsby n mct MaskB sizec64} el 64; 2oop4tride of *x*
/// + cs<em>x {
  st Self::Elec   fn is_zero(&self) -> bool [    0.] `btn add_assign(ct MaskBu[1   0.] `btn add_Self::Elem, rsa: isize,[2   1.] `btn add_te: if `btn add_assign(ct MaskBuff[    0.] `bfe fn pack_mr(kc: usize, mc: ulf::Elem, rsa: isize, yElem, rsa m, k, n,size    btny   ; m, k, n,size 1  btny 1]lt, 1);
       ack_mr(kc: usize, mc: usMaskBuffer {
  st Self::Elem, rsa m, k, n, MaskBuec  _sMa(*st Self::  const MR: usize of *x*
/// + cs<em>x {
  st Self::Elec, rsa: isize, csa: on  Note: [    0.] `btn add_assign(ct MaskBu[1   0.] `btn add_Self::Elem, rsa: isize,[2   1.] `btn add_te: if `btn add_assign(ct MaskBuff[    0.] `bfe fn pack_mr(kc: usize, mc: ulf::Elem, rsa: isize, yElem, rsa m, k, n,size    btny   ; m, k, n,size 1  btny 1]lt, 1);
       ack_mr(kc: usize, mc: usMaskBuffer {
  st Self::Elem, rsa m, k, n, MaskBuec64_sMa(*st Self::  const MR: usize of *x*
/// + cs<em>x  ack_mr(kc: usizen mct MaskBbeta  _sMa(xemm")] yElm")dd_asc   fn is_    [ad frnelxtr = *ab; [alpdrnelytr = *[backc - fr* d, fr* c rear* d]MR: usize of *x*
/// + cs<em>x  ack_mr(kc: usizen mct MaskBbeta64_sMa(xrs<T>  yElm64dd_asc, rsa: is    [ad frnelxtr = *ab; [alpdrnelytr = *[backc - fr* d, fr* c rear* d]MR: ign(ct MaskB rsa,1hparam:: [i][j]
    u> boo:archparaR: usize of *x*
/// + cs<em>xgn(ct MaskB  UnsafU2;xgn(ct MaskB  UnsafU4;xgn(ct MaskB  UnsafU8op4tride of *x*
/// + cs<em>x {
  hparam:: :EleU  f]
    u> boo:archpa///2 on  {
  hparam:: :EleU4 f]
    u> boo:archpa///4 on  {
  hparam:: :EleU8 f]
    u> boo:archpa///8; strim_n() {
     gn(ct MaskB        t m = [[0; 4    fm  fn ali if is_x86_ture = "cgem ali if is_x86_ign(bet;oAvx::MR];
     d_pool, ThreadPoolCtx, al st mct MaskBbetd_pool, Threaatioelt x 4 f64 k      *cpdd_asnc());
    //     let  GemmParameters {
    m, k, n,
    _
    //f { 1.pha,
           crokernel size).
///
ut T {
    /ways ensure mini.    _ bpp elt)eature_name:tt, $name:na: Nck_si_offse make_pc);

   A IBuff CGemmIas uffBign = ptr;
     ( Unner od::<K>    m,)actor for A B prodt mutCnel imask_beads,
  mask_r A B prodt mutdebug      kernno isizef::MRTy) al st mct MaskBbet          }
 <K, T>(e {
   &  U(*cptr).mul
n,
    _
 meters {
              m, k, n,assign(bet refm ::B: k  rePe_ofalEqpha,
           for the archpa///16i + 4, 2]));
  o() {
                        *cptr-> B~
       csdt m A IBuff C(vari_nr(sments th    let a = abn; thsis isbea      ity+ `beta`( Unner od::depe= sizemenMR/NR)
md)]
    mod testaset(csc,l, ThreadPatio(beta: T,
   alpK)i + 4, 2]));
     bset(csc,l, ThreadPatio(beta: T,
 n alpK)i  + 4, 2]));
      alig///1;           (*cptr).mul_assign(beta);
  }
}
       K                    }
}_        alig/    c: *mut T, rsc: isa[ialpK rej]0..m {
     Te() {
 :Elem, for j in 0..n {
            let c    folig/+//1;         /gemm.rs                   (*cptr).muut C.
in(K[cfg(/    c: *mut T,bR;
  i c = ]      assig ab22[i] = vfmaq_f64(ab22     1[i]ec![           llel(th ; m, k, n,crokernel size).
///
;

 l imask_bC
 them smaller if the mK,    assig, a         nts         nt(beta: T,
 c                  mr kernel unmasked
#[inline(         omm malenutput C.
in(a.lenT,
 c lenT,nmasked
#[i    slice::&a[   amm malen], &c[   amm malen]let b = b.strid2csdt m Ias uffBi(vari_nr(sments th    let a = aan; thsis isbea      ity+ `beta`( Unner od::depe= sizemenMR/NR)
md)]
    mod testaset(csc,l, ThreadPatio(beta: T,
   alpK)i + 4, 2]));
     bset(csc,l, ThreadPatio(beta: T,
 n alpK)i  + 4, 2])  (*cptr).muut C.
in(K[cion!
             aR;
  i c m ]      assig ab22[i] = vfmaq_f64(ab22     alig///1;           (*cptr).muKassign(beta);
  }
}
       nr                    }
}_        alig/    c: *mut T, rsc: isb[i c =  rej]0..m {
     Te() {
 :Elem, for j in 0..n {
            let c    folig/+//1;         /gemm.rs                 ab22     1[i]ec![           llel(th ; m, k, n,crokernel size).
///
;

,
  mask_bC
 them smaller if the mK,    assig, a         nts         nt(beta: T,
 c               nr kernel um_raw_parts_munline(         omm malenutput C.
in(b.lenT,
 c lenT,nmasked
#[i    slice::&b[   amm malen], &c[   amm malen]let:tt, $name:ident, crate::k+ cs<em>xame:na: Nck_si_offse make_pc);

   A IBuff Cgn = ptr;
     ( Unner od::<K>    m,)actor for A B prodt mutCnel imask_beads,
  mask_r A B prodt mutdebug      kernno isizef::MRTy) al st mct MaskBbet     rides f           }
 <K, T, TReal>(e {
   &  U(*cptr).mul
n,
    _
 meters {
              m, k, n,assign(bet refm ::B: k  rePe_ofalEqpha,
 , n,aRealssign(bet refm ::B: k  rePe_ofalEqpha,
           /// + B: k by n m amm mpp.to_crides fi  + 4, 2])for the archpa///16i + 4, 2]));
  o() {
                        *cptr-> B~
       csdt m A IBuff C(vari_nr(sments th    let a = abn; thsis isbea      ity+ `beta`( Unner od::depe= sizemenMR/NR)
md)]
    mod testaset(csc,l, ThreadPatio(beta: T,
   alpK)i + 4,    mod testa
    et(csc,l, ThreadPatio(beta: T,
   alpK)i + 4, 2]));
     bset(csc,l, ThreadPatio(beta: T,
 n alpK)i + 4, 2]));
     b
    et(csc,l, ThreadPatio(beta: T,
 n alpK)i  + 4, 2]));
      alig///1;           (*cptr).mul_assign(beta);
  }
}
       K                    }
}_        alig/    c: *mut T, rsc: isa[ialpK rej]0..m {
     Te() {
 :Elem, for j in 0..n {
            let c    folig/+//1;         /gemm.rs                   (*cptr).muut C.
in(K[cfg(/    c: *mut T,bR;
  i c = ]      assig ab22[i] = vfmaq_f64( kerns isb          }
 ,e ma c: *custom


    ///n = ptstr;
    s m, k, n,crokernel size).
///
.to_crides f for (size, T, TReal>(K[ciorom_raw_pto_:pri,       // LO     mr kernel unmasked
#[i///
.to_crides f for (Nize, T, TReal>(noroKrom_rawbpto_:pri, b     // LO  nr kernel um_raw_parts_munlfmaq_f64(ab22     1[i]ec![           llel(th ;