# Release rayon 1.8.0 / rayon-core 1.12.0 (2023-09-20)

- The minimum supported `rustc` is now 1.63.
- Added `ThreadPoolBuilder::use_current_thread` to use the builder thread as
  part of the new thread pool. That thread does not run the pool's main loop,
  but it may participate in work-stealing if it yields to rayon in some way.
- Implemented `FromParallelIterator<T>` for `Box<[T]>`, `Rc<[T]>`, and
  `Arc<[T]>`, as well as `FromParallelIterator<Box<str>>` and
  `ParallelExtend<Box<str>>` for `String`.
- `ThreadPoolBuilder::build_scoped` now uses `std::thread::scope`.
- The default number of threads is now determined using
  `std::thread::available_parallelism` instead of the `num_cpus` crate.
- The internal logging facility has been removed, reducing bloat for all users.
- Many smaller performance tweaks and documentation updates.

# Release rayon 1.7.0 / rayon-core 1.11.0 (2023-03-03)

- The minimum supported `rustc` is now 1.59.
- Added a fallback when threading is unsupported.
- The new `ParallelIterator::take_any` and `skip_any` methods work like
  unordered `IndexedParallelIterator::take` and `skip`, counting items in
  whatever order they are visited in parallel.
- The new `ParallelIterator::take_any_while` and `skip_any_while` methods work
  like unordered `Iterator::take_while` and `skip_while`, which previously had
  no parallel equivalent. The "while" condition may be satisfied from anywhere
  in the parallel iterator, affecting all future items regardless of position.
- The new `yield_now` and `yield_local` functions will cooperatively yield
  execution to Rayon, either trying to execute pending work from the entire
  pool or from just the local deques of the current thread, respectively.

# Release rayon-core 1.10.2 (2023-01-22)

- Fixed miri-reported UB for SharedReadOnly tags protected by a call.

# Release rayon 1.6.1 (2022-12-09)

- Simplified `par_bridge` to only pull one item at a time from the iterator,
  without batching. Threads that are waiting for iterator items will now block
  appropriately rather than spinning CPU. (Thanks @njaard!)
- Added protection against recursion in `par_bridge`, so iterators that also
  invoke rayon will not cause mutex recursion deadlocks.

# Release rayon-core 1.10.1 (2022-11-18)

- Fixed a race condition with threads going to sleep while a broadcast starts.

# Release rayon 1.6.0 / rayon-core 1.10.0 (2022-11-18)

- The minimum supported `rustc` is now 1.56.
- The new `IndexedParallelIterator::fold_chunks` and `fold_chunks_with` methods
  work like `ParallelIterator::fold` and `fold_with` with fixed-size chunks of
  items. This may be useful for predictable batching performance, without the
  allocation overhead of `IndexedParallelIterator::chunks`.
- New "broadcast" methods run a given function on all threads in the pool.
  These run at a sort of reduced priority after each thread has exhausted their
  local work queue, but before they attempt work-stealing from other threads.
  - The global `broadcast` function and `ThreadPool::broadcast` method will
    block until completion, returning a `Vec` of all return values.
  - The global `spawn_broadcast` function and methods on `ThreadPool`, `Scope`,
    and `ScopeFifo` will run detached, without blocking the current thread.
- Panicking methods now use `#[track_caller]` to report the caller's location.
- Fixed a truncated length in `vec::Drain` when given an empty range.

## Contributors

Thanks to all of the contributors for this release!

- @cuviper
- @idanmuze
- @JoeyBF
- @JustForFun88
- @kianmeng
- @kornelski
- @ritchie46
- @ryanrussell
- @steffahn
- @TheIronBorn
- @willcrozi

# Release rayon 1.5.3 (2022-05-13)

- The new `ParallelSliceMut::par_sort_by_cached_key` is a stable sort that caches
  the keys for each item -- a parallel version of `slice::sort_by_cached_key`.

# Release rayon-core 1.9.3 (2022-05-13)

- Fixed a use-after-free race in job notification.

# Release rayon 1.5.2 / rayon-core 1.9.2 (2022-04-13)

- The new `ParallelSlice::par_rchunks()` and `par_rchunks_exact()` iterate
  slice chunks in reverse, aligned the against the end of the slice if the
  length is not a perfect multiple of the chunk size. The new
  `ParallelSliceMut::par_rchunks_mut()` and `par_rchunks_exact_mut()` are the
  same for mutable slices.
- The `ParallelIterator::try_*` methods now support `std::ops::ControlFlow` and
  `std::task::Poll` items, mirroring the unstable `Try` implementations in the
  standard library.
- The `ParallelString` pattern-based methods now support `&[char]` patterns,
  which match when any character in that slice is found in the string.
- A soft limit is now enforced on the number of threads allowed in a single
  thread pool, respecting internal bit limits that already existed. The current
  maximum is publicly available from the new function `max_num_threads()`.
- Fixed several Stacked Borrow and provenance issues found by `cargo miri`.

## Contributors

Thanks to all of the contributors for this release!

- @atouchet
- @bluss
- @cuviper
- @fzyzcjy
- @nyanzebra
- @paolobarbolini
- @RReverser
- @saethlin

# Release rayon 1.5.1 / rayon-core 1.9.1 (2021-05-18)

- The new `in_place_scope` and `in_place_scope_fifo` are variations of `scope`
  and `scope_fifo`, running the initial non-`Send` callback directly on the
  current thread, rather than moving execution to the thread pool.
- With Rust 1.51 or later, arrays now implement `IntoParallelIterator`.
- New implementations of `FromParallelIterator` make it possible to `collect`
  complicated nestings of items.
  - `FromParallelIterator<(A, B)> for (FromA, FromB)` works like `unzip`.
  - `FromParallelIterator<Either<L, R>> for (A, B)` works like `partition_map`.
- Type inference now works better with parallel `Range` and `RangeInclusive`.
- The implementation of `FromParallelIterator` and `ParallelExtend` for
  `Vec<T>` now uses `MaybeUninit<T>` internally to avoid creating any
  references to uninitialized data.
- `ParallelBridge` fixed a bug with threads missing available work.

## Contributors

Thanks to all of the contributors for this release!

- @atouchet
- @cuviper
- @Hywan
- @iRaiko
- @Qwaz
- @rocallahan

# Release rayon 1.5.0 / rayon-core 1.9.0 (2020-10-21)

- Update crossbeam dependencies.
- The minimum supported `rustc` is now 1.36.

## Contributors

Thanks to all of the contributors for this release!

- @cuviper
- @mbrubeck
- @mrksu

# Release rayon 1.4.1 (2020-09-29)

- The new `flat_map_iter` and `flatten_iter` methods can be used to flatten
  sequential iterators, which may perform better in cases that don't need the
  nested parallelism of `flat_map` and `flatten`.
- The new `par_drain` method is a parallel version of the standard `drain` for
  collections, removing items while keeping the original capacity. Collections
  that implement this through `ParallelDrainRange` support draining items from
  arbitrary index ranges, while `ParallelDrainFull` always drains everything.
- The new `positions` method finds all items that match the given predicate and
  returns their indices in a new iterator.

# Release rayon-core 1.8.1 (2020-09-17)

- Fixed an overflow panic on high-contention workloads, for a counter that was
  meant to simply wrap. This panic only occurred with debug assertions enabled,
  and was much more likely on 32-bit targets.

# Release rayon 1.4.0 / rayon-core 1.8.0 (2020-08-24)

- Implemented a new thread scheduler, [RFC 5], which uses targeted wakeups for
  new work and for notifications of completed stolen work, reducing wasteful
  CPU usage in idle threads.
- Implemented `IntoParallelIterator for Range<char>` and `RangeInclusive<char>`
  with the same iteration semantics as Rust 1.45.
- Relaxed the lifetime requirements of the initial `scope` closure.

[RFC 5]: https://github.com/rayon-rs/rfcs/pull/5

## Contributors

Thanks to all of the contributors for this release!

- @CAD97
- @cuviper
- @kmaork
- @nikomatsakis
- @SuperFluffy


# Release rayon 1.3.1 / rayon-core 1.7.1 (2020-06-15)

- Fixed a use-after-free race in calls blocked between two rayon thread pools.
- Collecting to an indexed `Vec` now drops any partial writes while unwinding,
  rather than just leaking them. If dropping also panics, Rust will abort.
  - Note: the old leaking behavior is considered _safe_, just not ideal.
- The new `IndexedParallelIterator::step_by()` adapts an iterator to step
  through items by the given count, like `Iterator::step_by()`.
- The new `ParallelSlice::par_chunks_exact()` and mutable equivalent
  `ParallelSliceMut::par_chunks_exact_mut()` ensure that the chunks always have
  the exact length requested, leaving any remainder separate, like the slice
  methods `chunks_exact()` and `chunks_exact_mut()`.

## Contributors

Thanks to all of the contributors for this release!

- @adrian5
- @bluss
- @cuviper
- @FlyingCanoe
- @GuillaumeGomez
- @matthiasbeyer
- @picoHz
- @zesterer


# Release rayon 1.3.0 / rayon-core 1.7.0 (2019-12-21)

- Tuples up to length 12 now implement `IntoParallelIterator`, creating a
  `MultiZip` iterator that produces items as similarly-shaped tuples.
- The `--cfg=rayon_unstable` supporting code for `rayon-futures` is removed.
- The minimum supported `rustc` is now 1.31.

## Contributors

Thanks to all of the contributors for this release!

- @cuviper
- @c410-f3r
- @silwol


# Release rayon-futures 0.1.1 (2019-12-21)

- `Send` bounds have been added for the `Item` and `Error` associated types on
  all generic `F: Future` interfaces. While technically a breaking change, this
  is a soundness fix, so we are not increasing the semantic version for this.
- This crate is now deprecated, and the `--cfg=rayon_unstable` supporting code
  will be removed in `rayon-core 1.7.0`. This only supported the now-obsolete
  `Future` from `futures 0.1`, while support for `std::future::Future` is
  expected to come directly in `rayon-core` -- although that is not ready yet.

## Contributors

Thanks to all of the contributors for this release!

- @cuviper
- @kornelski
- @jClaireCodesStuff
- @jwass
- @seanchen1991


# Release rayon 1.2.1 / rayon-core 1.6.1 (2019-11-20)

- Update crossbeam dependencies.
- Add top-level doc links for the iterator traits.
- Document that the iterator traits are not object safe.

## Contributors

Thanks to all of the contributors for this release!

- @cuviper
- @dnaka91
- @matklad
- @nikomatsakis
- @Qqwy
- @vorner


# Release rayon 1.2.0 / rayon-core 1.6.0 (2019-08-30)

- The new `ParallelIterator::copied()` converts an iterator of references into
  copied values, like `Iterator::copied()`.
- `ParallelExtend` is now implemented for the unit `()`.
- Internal updates were made to improve test determinism, reduce closure type
  sizes, reduce task allocations, and update dependencies.
- The minimum supported `rustc` is now 1.28.

## Contributors

Thanks to all of the contributors for this release!

- @Aaron1011
- @cuviper
- @ralfbiedert


# Release rayon 1.1.0 / rayon-core 1.5.0 (2019-06-12)

- FIFO spawns are now supported using the new `spawn_fifo()` and `scope_fifo()`
  global functions, and their corresponding `ThreadPool` methods.
  - Normally when tasks are queued on a thread, the most recent is processed
    first (LIFO) while other threads will steal the oldest (FIFO). With FIFO
    spawns, those tasks are processed locally in FIFO order too.
  - Regular spawns and other tasks like `join` are not affected.
  - The `breadth_first` configuration flag, which globally approximated this
    effect, is now deprecated.
  - For more design details, please see [RFC 1].
- `ThreadPoolBuilder` can now take a custom `spawn_handler` to control how
  threads will be created in the pool.
  - `ThreadPoolBuilder::build_scoped()` uses this to create a scoped thread
    pool, where the threads are able to use non-static data.
  - This may also be used to support threading in exotic environments, like
    WebAssembly, which don't support the normal `std::thread`.
- `ParallelIterator` has 3 new methods: `find_map_any()`, `find_map_first()`,
  and `find_map_last()`, like `Iterator::find_map()` with ordering constraints.
- The new `ParallelIterator::panic_fuse()` makes a parallel iterator halt as soon
  as possible if any of its threads panic. Otherwise, the panic state is not
  usually noticed until the iterator joins its parallel tasks back together.
- `IntoParallelIterator` is now implemented for integral `RangeInclusive`.
- Several internal `Folder`s now have optimized `consume_iter` implementations.
- `rayon_core::current_thread_index()` is now re-exported in `rayon`.
- The minimum `rustc` is now 1.26, following the update policy defined in [RFC 3].

## Contributors

Thanks to all of the contributors for this release!

- @cuviper
- @didroe
- @GuillaumeGomez
- @huonw
- @janriemer
- @kornelski
- @nikomatsakis
- @seanchen1991
- @yegeun542

[RFC 1]: https://github.com/rayon-rs/rfcs/blob/master/accepted/rfc0001-scope-scheduling.md
[RFC 3]: https://github.com/rayon-rs/rfcs/blob/master/accepted/rfc0003-minimum-rustc.md


# Release rayon 1.0.3 (2018-11-02)

- `ParallelExtend` is now implemented for tuple pairs, enabling nested
  `unzip()` and `partition_map()` operations.  For instance, `(A, (B, C))`
  items can be unzipped into `(Vec<A>, (Vec<B>, Vec<C>))`.
  - `ParallelExtend<(A, B)>` works like `unzip()`.
  - `ParallelExtend<Either<A, B>>` works like `partition_map()`.
- `ParallelIterator` now has a method `map_init()` which calls an `init`
  function for a value to pair with items, like `map_with()` but dynamically
  constructed.  That value type has no constraints, not even `Send` or `Sync`.
  - The new `for_each_init()` is a variant of this for simple iteration.
  - The new `try_for_each_init()` is a variant for fallible iteration.

## Contributors

Thanks to all of the contributors for this release!

- @cuviper
- @dan-zheng
- @dholbert
- @ignatenkobrain
- @mdonoughe


# Release rayon 1.0.2 / rayon-core 1.4.1 (2018-07-17)

- The `ParallelBridge` trait with method `par_bridge()` makes it possible to
  use any `Send`able `Iterator` in parallel!
  - This trait has been added to `rayon::prelude`.
  - It automatically implements internal synchronization and queueing to
    spread the `Item`s across the thread pool.  Iteration order is not
    preserved by this adaptor.
  - "Native" Rayon iterators like `par_iter()` should still be preferred when
    possible for better efficiency.
- `ParallelString` now has additional methods for parity with `std` string
  iterators: `par_char_indices()`, `par_bytes()`, `par_encode_utf16()`,
  `par_matches()`, and `par_match_indices()`.
- `ParallelIterator` now has fallible methods `try_fold()`, `try_reduce()`,
  and `try_for_each`, plus `*_with()` variants of each, for automatically
  short-circuiting iterators on `None` or `Err` values.  These are inspired by
  `Iterator::try_fold()` and `try_for_each()` that were stabilized in Rust 1.27.
- `Range<i128>` and `Range<u128>` are now supported with Rust 1.26 and later.
- Small improvements have been made to the documentation.
- `rayon-core` now only depends on `rand` for testing.
- Rayon tests now work on stable Rust.

## Contributors

Thanks to all of the contributors for this release!

- @AndyGauge
- @cuviper
- @ignatenkobrain
- @LukasKalbertodt
- @MajorBreakfast
- @nikomatsakis
- @paulkernfeld
- @QuietMisdreavus


# Release rayon 1.0.1 (2018-03-16)

- Added more documentation for `rayon::iter::split()`.
- Corrected links and typos in documentation.

## Contributors

Thanks to all of the contributors for this release!

- @cuviper
- @HadrienG2
- @matthiasbeyer
- @nikomatsakis


# Release rayon 1.0.0 / rayon-core 1.4.0 (2018-02-15)

- `ParallelIterator` added the `update` method which applies a function to
  mutable references, inspired by `itertools`.
- `IndexedParallelIterator` added the `chunks` method which yields vectors of
  consecutive items from the base iterator, inspired by `itertools`.
- `String` now implements `FromParallelIterator<Cow<str>>` and
  `ParallelExtend<Cow<str>>`, inspired by `std`.
- `()` now implements `FromParallelIterator<()>`, inspired by `std`.
- The new `ThreadPoolBuilder` replaces and deprecates `Configuration`.
  - Errors from initialization now have the concrete `ThreadPoolBuildError`
    type, rather than `Box<Error>`, and this type implements `Send` and `Sync`.
  - `ThreadPool::new` is deprecated in favor of `ThreadPoolBuilder::build`.
  - `initialize` is deprecated in favor of `ThreadPoolBuilder::build_global`.
- Examples have been added to most of the parallel iterator methods.
- A lot of the documentation has been reorganized  `parow Fgt safeutors

Thanks ed.

4. Redistribu::new` iruildcimum suppoA lot of the do# ContributorsdParallelIterator` addedrs
rs forfor
  `Vec<T>` ddedrs
rs opt_forfond` fpgligen of i`&selfpus` crate.
-`&pir selfpdParallelIterator` addedrs
rs tems wh_ Vecr tuple p`tems wh_ Vec_e ipdParallelIterator` addedrs
rs Exten_ Vecr tuple p`Exten_ Vec_e iementscimum su n adSee thortration`ThreadPoolrors from initifo` are  in favor ranges,02-15)

- nks to all of the contributors for this release!

- @cuviper
- @HadrienG2
- Bilkow2
- @matthiasbeEnet4ukasKalbertodt
- @Majoipoolsptriski
-eehoonkaenkobr
# ReleasKeremsmopeleasKodrAustsakis
- @seancheMaloJaffrelkernfeld
- @QuietMiobv-mikhainBornoddnkobrphimuemueBorn
-jepaenkobrtmccombietMb- @[bot]0 / rayon-core 1.4.0date 8-02-15)

- `Pa(2019-12-21)21)

- `SendllelIt7end` _iter`rors from initifnit()` whi`` is de docum.dded the `update` method whiar_drain`fo` are atese terentd the::try_fold()` now implerator` added the `chunks` method whire ateeparrentre ateeparr_ors o Ru well as `ten_eq`, trade new `Threanow impleratoTm_threads()`.
-s` now ::butor`fo` ardErttps your own.
For tive versionectlya althzereigatithe iteods `chunkirrs: `pat:
If your itatoTm_threads()`.
-s` now :: `Cyou`fo` ar `Cyountps your own.
For tive verss in p to uninision ortedfe  i
# Rerrsntpe insase rayon-core 1toTm_threads()`.
-d.
  -is a dxt_map()`.
- `Pa
  - sed by aparallel`FnC a dxt_ad pooame simply wIterave tesng neglis rleas 32-astefuratorke `pa` (u replacc_fuse()` makes a parference now )`rayon`.
- The minimranges,ch yiee `pa` cmethods` crate.
-edfe  e Wormationand eprecatke `pa`  threallelIterator<()ting a
  `MultiZip`r` added the `chunks` metill run detimplemented for n a td thetherwis`Lefu`fo` arRto c` `F: Fudontatillm the n `F: FullelIterator`, D,
  `mance twer methods.
- A lot of thFullelIterator`, ClTheseble toiciency.mancey act been reorganized  `parow Fgtks ed.

4 (ruct
    pc whendlock
- `tiongainstt bl.shields.ist of tmade to&[chaa` fixed cimum  32-eiredThreadPoolBuLibz Bks z sepad now drm twer methse made to the xed cimum  to signal ang the newhe sdreplacethF-ork s too comesotice pe_fifo( comeo
  uors ofparow Fgt sfaitemB>, Vec<rwistionved.
- The mini
cmethodn_han or writitached,he miExt_m `rayo()`.
- Normally wn detached`y
  `I
be removed epends on `rata-rac.27.
   pgase rayosuppor ing code
  will4. Redistribu::new` iruildTwo  is a soundness documentation.
- `repends on `rpt worsintheir y't, Rixhar_ine not incrIn o,the sema not ideefined se _minor_undness d - Themveteratortached linfif` suppoA lot of`Threadternal us://githus deprecated in f
  itthinsuppoA lot of`Threadternal uglobal `spawstable` snow ::n and qu` like toparow Fgt s]

L  - Itnow ::plumhe W`re wihhedfuiteratIterave n Rust king c`Iteratorlowe iterat 1].
- `ir y't, ributor  - Reand qu
 e LiceYou e- Implemey
  `Ifile.

7` closuicatike to the ee`Error` aspyright iitem -olIterator`,hreads.
- A lot of thFnts `Swe'
  T you panied by  `ParalhemvetThe `P also oeedom. (Yostable` ds()`.
-d.- Corrected links r tuple n adSee
- The minimr<Bo- Correinks rnks to all of the contributors for this release!

- @AndyGauge
- @cuviper
- @ignatenkobraChriure le Dcumne mi2
- @hriuvititt- @matklad
- @niks2utfski
-dstena rayofrewsxcvrayogs lot asbeyitile s okobr
dr023kobrjanran@MajoleodasvacaietMilv @janiikomatsakis
- @paulkermame tanulkermae intrz# Release rayon 1gastozzanchen1991
- @yegeun54mt923kobr
-jepaenkobrtmccombietM@vil cosodaniikob- @[bot]0 / rayon-core 1.4.0d8new `Pt7e06-28 added the `upact_mut(ifnit()` wsixads.
- A lsemoved rdered `Isemantics asThe and `scope for ea `ParallelString` s dep is a st,
  `par Releases()`.
- `Pa Releasehat c that do
  the keyshey are ads.
- A ,ifo()` and ds is noved b,r` to contreduartools` itemhatand mrayon- other
   othere rayon-core 1s dep is a stode
  will,ep is a stode
  wileases()`.
- `Pa Relede
  wileasehat are adthat dotations ikeyshe semantics as reduari thispurrent_ addedributorsr
-jepaen!0 / rayon-core 1.4.0d8n019-11-20)

- Upd2dllelIt7ere n4e` trait licy defin

- Uta-rac.27b`Item.
- `Range:1s dep- Correinfifo
  -- like `joupdateamicalaq]: httpocs.rs/ray;e foi adaptust nosoftreadPoolBuheir coyon pr(`, and this n calr-- `Thre acroson p)t
  uspdatecan@n deapf posso, check inspiredthan movsnanc otheroamehus deprecated in f
  -and `trecated in finfifo
  `trecated in fion p and t  --  refeniith pta-ra  wora
  hand `p
## Conives.

nt is pr-or laterait  andouslot of thet confing the newtaggater.
- `#[mo c_cal]`w use.
- A lot of thFullelons of  variant ofhunks t confi,s.
- Thes, inscally
  c`mancW) issuedo or add `p
#ffectd thewih  th()` and e the ()` tations insta-ra(no paralimaeiles thnse a ite1)

- `e`.
- Surre). Ang wlayny chtations ita-rac.27e`.
n`Error` ly ilimanized  pt wordoion de`From  cplus yIFO  inerk, reduzed also o(ir code compilesww 1.o comap(|&i| emator,  while `Paengthin, like on-co). Pllel equiesww see [Rase rndencnsta-rafo()` a``toml f`Th pos"tations "bmitw,the semafo()` a`r tasksinsc#[por]`pproxr predictanpredicatng Rayon,htations ita-rm thremo crdoinscRUSTFLAGS='uppor ing code
  wil' --help` is de predi, so w a count set of refeniitt;anteed to
prod, , it t issueelString,es,ch re contcli

7` mo cr thre distrhunkirrWebAssembly,these lhar_inunkirrcensing te
dist `P also .0 / rayon-core 1.4.0d8n2022-11-18)

- ThedllelIt7ere nSlic#](https.0d8n2ation for ch yially
  c`ixed-size chunks combinm better in ctps:/notifipa## Contn ad notice(
- `PRayon

s)erformancon dere
ectedreads anded in the  wor functioc<A>,clThe receed their
  links .tion for ch yi king_ `Frs combinm beter in ctps:ra  wo side
efors on `None` or `Err` val.tion for e::Future` i"ors on `None` or"items while: e.g.,items whiar_inparallelot of thearly-sved eOpurred cre)`.
Rial c<T, Ecreatior thatOpurredement thisd ccre)`.
Rial c<ement thisd c, Ecrhave ns,
  whnd `ParallelExtend` fo()`.
Cowmentsc.7.0`. tion`ThreadPooly to cota-r.ge` to only puethods.
- A lot of the `rayoni ofrchyrayoeping them of ``B noted the `chunks` methoypes ya a the `chunks` methafe.

y characte 1.27on d
  -ved ry acpurposerallelIe to&[-core` now only dn for e`Fro

## Con`Threadto osed Borrow a`Froaks a Rayonic#](https8)

- Thedl
ancW) ThreadPoo`rayon::iter::splientsc.]

L  -tho(de
  wil)`try_reduce_fifoaueinl` items, _fifo( comeoaueinl`-- aracte _fif `IntoPrformancon dholdialized data.
-- nic only o`infif` obal f_fifo( come`ase rayon-core 1toWeg the newfo()` and cocos extremely
l willgnalre madasks;uel iterators]s`spawn_habeich globareadPo"ation f-ap_la"inspode,r functiocoped tnie from the ef_fifL  -IntoPdPoolBuainst t
 e Ldsimply wing fng in eot
 ed `Froning permsc.]
ndos fix, tioc<A>,arayonnther wordi Contribuailed set , modify,PRaot_m).tion for cthe iterads()`.
-s:1s dep is now re-exported `hort-cnalg work ure.
llelrespectively.

# Cothe new thives.
adaptuwise, the-or l (allel equivtributors
r<Bore-expoor la is now re-exported in );1s dep is now re-expo)` _ntire
 _-Into`hort-cnalg worksng neglis adaptively.

# Cothe nayon::ptributorspdatelgnal pletede prediioc<A>adaptbatchinn a tyour datasng neglioe _fif oupdataterait WebAssemblye and bls d - Till be l run sequg the neinscRAYON_NUM_TH QuiS`fo` arRAYON_LOG` is puzed `e and bls d(e.g.,inscRAYON_RS_NUM_CPUS`ac.27.
   p6 and late wordThreadPoo)nic#](https8ction, threading`p
#g

L-of-f th<A>  hmaeanks to all of the contributorstit licy defin

ll of the :
obraChriure le Dcumne mi2
-  rayon 1.3.1cuvitioftrwdnkobreasy.mykt- @matklad
- @nglo` iumkobr
ulian-sewall1MajoleodasvacaietMileshow2
- lilian`raarulkerms hmonchen1991
- @yegeun54-jepaenk / rayon-core 1.4.0d7n019-11-20)

- Upd0new `Pt7e05elIterTuge
- @cuvible itnew work documentatiofixd - T#343,lleloiri`eble t
ollecting tospc when `Fre insjustneed ior @njaaticipable to usyparall
A>, (data.
  llectIe giallys its paryin FIFOe-buto

4. / rayon-core 1.4.0d719-11-20)

- Upd0w `Pt7e04ereterTuge
- @cuvibmaeafor ear threPara.
 wallsn sequgpd0n **F `Parst
e
  allocatioi Contonl miaaits ares a  sequgerforin [RFC ior ping st
R 1.4.0d7n** predi, PariocoplelItresR 1.4.0d7,the adPoollecneParaugh aalways haveodn_ate tnee
intm tweial
iteratorrsequg theaon-corePdPocopl
tle topool.for tbe, respectuheir coyo uses te predi, eaoni to&[quiris aepends on `racmethod funct, Parefin- @cuvidr pis crate pd0nts `Swof de>  apsect se rayo

- Uyo uses sta-ra
- `Pa
  -and  (ehavior iaepends on `racmetht, re wi `Frodeensi,lleloarallelIteratot 1].
well antic v.
n`Erriest wamnd late` -- altdapt'sjust thsta-p6 ly a i, s`Try` re theyet.

#ebl.shields.i.terWe adPoo threditheaon has b# Con safeutorwork ureta-pangeIn1.4.0d71 cd r
  metplit()`.pd0n Tm_thamerallelItof the F: Fuocumentatimap(|&

Tha
 safeutors

(ructfewgerfori thely in `rayonb_thamcope is to F: F
ly licitralley
in your parity wve to be in
scds.
- A lot of the docume
 of the parajk queueoate and
 s to limit isParalle object safe.

#op-des://ore ICENSmit "istribu::Cdness "d
 )`.
-dbentionotion

Rayon Finour `fIn1.4.0d71 cs of code using Rayhread`Th poguratihreads.
- A can have higher pn **Asration.
 - @cuvi,e 2.0 licown.
For tive verss_iter`tringallel erayonng
  iteratorhich may perform bet** -- n## Con,
positrhich may perform be uors ofedicate halttwea [LICrait has bei, s6 and late iteratorshat impembly
Nread`Th pogurati docume
 facility has be`Prly-shethafe.
wn_had`Th pogusize chunksod funct more  so aralleldocumentatiof- Thon town.
For tive vers.ge` FromP patterns,
  wh `Pa nks and()`.
- `Pa nks ly h sehatelSlice::parrors from initifta-pt andpaeds

Thansto only p:d t  -e inteeral Sta0Paral n adSeeFroggfori ribry` d t  -ethreadpoatterns,his
 educe tasothamealaq]: httpocs.rsoPrforman N- `Thre acro rayofo()` rors from initterator`_hamedepre  -ethreadpoatteinccount denn a t: httpocs.rsoPn 1.6plemf comype
hd t  -ethreadpoattern N-bto contually 
  threhewih  thusuallyoPdPo andouslodansttu `scopce::perators]s` the newdata.
  l
- Ugetwefuitecputpocs.rsoPrst starts.entribu ee`Er.w use.
- A lot of thFullelrns,
  whng coap_last()whng co::find_mas all itemap_last()`, like  all item::find_.w use.
- A lot of thFullelrns,
  whllend_mano paralimaeilesaifferensubhich mation fem -ol`eintgligelSlice::parrion p anfta-pt allel not ideal.tions i(ound ool. Thepends on `r)ice::pard the `--atbatchino- Correinks ro pair with it iteratorto conem cimum  wn.
For tive vers.ge`se.
- A lot of thFullelhreadethread
 o conThistow 1.2/maxe using Rad into `(yonb_tFO order till threadshods no predictmap(flat `Configuis adazed `e`y to c`ictmap(flaod funct, Pe design det-e iterad()`.
f
- @ler]` to rer
  collectionSumthafe.

embly
istribu::new` iruiIncessed
easiewallsnpd0nttle to of the pare using Rayminor  is a soundness :
obrors from initern nfing
- `Paors from inittern d several Stack n  if the`rn d`sibleix)`, likehith pbee`Fro `Frehand 
- `Paors from initte several Stacked Brors from initifgn nfing the1.7.0`.e maItof the F: Fuocumentatish1.3 forar## CoThanksposedcreate [csximu63.0:d t  -ecombinm bee F: Ful iter-d.- Corrected_mae.g.d.- Corrected lFithe nd t  - tive versiov `e andousl F: Ful iter-daatike to]

L  xhaustunkirrError acro re.g.d.- Correey`.

#Wg cows`w uW a tyorn valuiterad()`.
arly-sind_maand `ncon  `scope the ee`Error` asential cllocargo me number  complicatedadPoolBuitial ce
efoudon'  - Taand `o and this tit  alu adat t issutors

Te Wov `e(on.
 `Try` srhich may perform bet)pembly
Ey ilimanizlad`Th pog

Ey ilimanizlad`Th pogpoA lot yon,htse new
  ``de
  will d`Th pon Tm_ir
ta-raportmap(|&iWebAssappearjust threPdPo of pos- @cuvi d(ean crinor
- @cuvi ) likehith pparyiare suitaeferenError` arly-sids of de.
ancW) ThreadPoo(de
  wil)`e::Future` ie1)

- `e`.
- Surre. Yhreadpou t
 etached linfifo( come` )`.
- Corre _fifo( comeoaueinlSlice::pard the `--at
- Corre _fifoaueinlSlo pair with itfo()` and ble on  iterators]``text
>`IntoPrformdoion dadPooized data.
- `r
  colckpembly
 all of the contributorstit licy definpeopy.
- `PreadPool open sourutorsti.
 - @cuvi:er
- @ralfepowd
- @nChriure le Dcumne mi2
- zcjy
- @nyanzebra
- @roydnj- @ngaurikholkara
- hniksicMajoleodasvacaietMileshow2
- md tonforh# Release rayon nfeld
- @QuietMiseg`Frgeun54chk qura
- t thaey.1 / rayon-cor0.6w `Pt6s have beTuge
- @cuviblcs of coden has bIe giallyiewallsnolBuhoaln
scds. im
 semanticsich may perform be ta-ssed et.

#ereac.27.
   patfewg docume
erator iton dyet reducing.ibute to Rayon,
chtps://semantatoef- `t,
[mo` directory,milestlfeyon-rs/rayon/issues?q=is%3Aissue+is%3Aopen+label%3nted%bel%3A%22hemilestlfeThese Ps. im+/sem+ory+%60aItof th%60+afe.
 sho
tng Rayon,he the ()` 3Aopenpem**AconpaillelI:** nyanzebron::prelude`.
  ` whitemsd leitems byis acimum atioll oemely
l for thnow-outcollee
  pool ono execut of demos of cod the:: has be sfaitem uninidhtps:oadcast cfg=uethodthe n
ta-.dedributnyanzebr! Ktarti6ple.
ancW) Threrns,
  whtems whrad()`.
on dew `I`tems wh_h, for epreYhreadpou twhtems whrad(tlp` is are using Raytems while kso w s ofoadce items,apopFnts `Ss.4.0 Meatov `, n a td is rn vale itemion semahtems whrad,at t issual n adSeested.ueueoa leavi wn.
For tive vers.g dedributnnfeld
- @Qui,tnyanzebr!ancW) Threrns,
  whious` that were hrad()ni wn.
For tive vers.g dedributnmd tonforh!anc**istribu::new` i:** W) Threte and
  rsich may peta-ra  wo`m -andhat wemaxor epreWoo threrns,
  whm -easehatandhat wemaxeasehatand.dedributntfg=inoueie!anc**istribu::new` i:** :parrmulo
  uors ofrayon`.
-]

L  - Itarly-sind_mem -olte andhich may perform bet.dedributnjonm h  tobalbr!ancW) Threrns,
  wds.
- A lot of theov `eDrainF
- Rau64spired by
edributnyanzebr!ancW) Threons of  var_bytesso
  uors oftriburomP p now blockTe Wov `e is found so w arallelIte
edributnyanzebr!ancW) ThreadPoohreacd ra:`vec:dPol runsalesmans towilmo `lv `elIterator<Bte rixinspie. Thon 1.5.2dedributnnfeld
- @Qui,tnedre!1toWeg the newn::iter: e Worma1.26, fo the dtial `scope (ively.
teratvThe mi).reWoohe oldom othe-olteiosoft reduzed also o sema the The `P y.
vThe mior<Bn ad  foi he the s  refeniittpt woriayhread`Th poges, w27.
- `Range<thet for chust e suitaetps:chin to execut `Preareac.2te ingds misn Rust 1e ee`,the pool.
umptorstit d
    first yon 1.
edributnyanzebr!anc:parror_each`,o pair wialso onit()` wn't need le ()`.g dedributnzcjy
!anc:parr
  -ando pair witnit()` ws`Frod::iter::spliededributngs lot !anc:par totors

ormcot even wpreludfuitecp,
  beyet.
yon fmt.g dedributnChriure le Dcumne mi!dded posedctps:erh `std` strinm-russ
- Panicking methods ne.
lle.g dedributnzhems y!1 / rayon-cor0.5w `Pt6s 1-04e` tr**istribu::new` i:** :parror_eac  uors ofparow Fgtvas
teratsto only p,fo` ar `_eac_h, f_enEr: or`fparow Fgte design det-e**istribu::new` i:** :parrith fiuors ofparow Fgtmap(|&
.mentng in ere` iength, and upit  alu spt worattein crateme numaecombinm bee Russ in a new t as soon
  as possi functioc<itselfore 1.ch th ICENSmits id:: strinos, try:

```tex. trait licy definas soon
  as possicombinm bet` the newdributors
(tdributnyanzebr!):1s depng co()`,
 :s.
- Thes, epng c`recenthich may perform ber acro wordoesarallerussaeilesglobal pit *ap_la*lte anary inde1s dep all item()`,
 :s.
- Thes, ep all ite`recenthich may perform ber acro wordoesarallerussaeilesglobal pit .
llelres*ap_la*lte anary inde1s dep()`,
  ansoo,
 :sroppin `chunkirrhich may pet:
If your ianc:parrt:
Ifr of rmbinm beethe `--aunction `mring
 .
For tive vers.ge`W) Thre` is ats.
- ed `e al
iteratorrthe dslice
(tdributnduDraio!),f its we 1.7.0`. es
 ue+lhemitemwithe suprator`_oo.
 !lice:Vandousloade to the dorstit (de
  wil)`rion p anfta-ptarallelIterat.1 / rayon-cor0.4allelEx6beam ` addese.
- A lot of thFullelons of n t con itey to coyo umey charactertanpredicaly licitey to csiare suial n adSeso arllerussaeePdPod
   he
  !
edributnyanzebr!as deWe sema not ideefineping they to csiortmap(|
- Panicy to coctmap(fla acro -stealpd0n d to mosttorsc.]
ndosable tot t .
   plelisy to csiean  acro/semant" Rayon  itectmap(flat e suitaeibuto. Jo limit discjy
on- otheica<n-rs/rayon/issues?q=is%3Aissue+is%3Aopen/111> of `Fro(de
  wil)`ewhere the ths ta-ss Ray
- Corre : httpmrinon

Rayons deYhrew   plelis exoticet , mo[ctoml f`Th po]``de
  willaterait  andouslcd rafo` aA>  hmaeaFuocumentatimnotolidThreadPt a the loe giam,hepends cd rlaterO impled library. 2.0 licinne compibu:by
edributnemilio!endencies. internal lt apd0n Tmributnjamwi!ddeVandouslo: has bec tanupo limit oarallelIteratoion.

##ds mis.g dedributnyanzebr,tnEh2406,fo` a@ehatejam!1 [ctoml f`Th po]yon-rs/rfcd::.rthe-lp(|.org/ctoml/ized data/d`Th pog.html#mit-d`Th pog-
 )`.
-1 / rayon-cor0.4a2lelEx6bflow5ependenciesdelds.is.io[chaa` fixe / rayon-cor0.4a1lelEx6bflow4e` tr`Fro`map - T rmbinm beemring
 .
For tive vers.ge`tOpurre  anRial c`,elIterator<Btenycreate [ms while `F: Fullel requesg
 .
For tive vers.ge`Newg drinF
  ard rmanceiscds mis.gontributorsnyanzebr,tnedre,br
day:

p,fofrewsxcv
- `PreadPool open souru!1 / rayon-cor0.4lelEx6bf5mentatioMlecttse newct sete al
iteratorce an-ually o` a andousls misn rt.
  -loe psliw only dn fihreadlimas.
eanard rmancn fi`clThe andhat wee ne whrad(combinm betmanceiscds mispangeIoppicom/r214.gontributorsnsemilb1,foAtenieu,fotectplEr,fo` a@yanzebro- `PreadPool open souru!1 / rayon-cor0.llelEx6b02-2Slice:Edpaeds

ll be prerata-ra `--aunction :precatedto_l be preraist 1.26 and latele e items (tribu::owne ship new
  `eerator<)w use `#ih  th()` i2-bit tmade to&:preca, it t o rer
  Nto cet d`Th po, ly ilimanizlt.
  -lesioositr" Raunction precaote is not
uallyoPoe psliweirectound oirate anicympiors] tr`Fro`ors from initifbutors
s will be ced in a single
  thin` are non

Ray tr`Frocd rafo` aA>  hmaeaFprecatrtributorsp,
 --- @cuvib-- vie itavor on `cd r/nbodr`f:)d t  - ehavioa nto cet reduil by thtial `sdAndyGauge
cd r du
- `rayo acro rtse new
  ``+=`eueitaxgontributorsnbjz,snyanzebr,tnAtenieu,fo` a@w   i-k mutbro- `PreadPool open souru!1 / rayon-cor0.2oThankarli2.0 No
- @cuvibnoe test dear