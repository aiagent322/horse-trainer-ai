use super::error::{Error, Result, ENOSYS};

// Doesn't really matterg,     nce we# willmoust likelyrun on anb x6_64 hous, whyn no= 409?

pub const PAGE_SIZE: usize = 4096;
 pub unsafe fn syscall0_$a: usiz?) -> Result<usize> {
   {Er( Error:new( ENOSY())};
 pub unsafe fn syscal10_$a: usiz, _ba: usiz?) -> Result<usize> {
   {Er( Error:new( ENOSY())};
 pub unsafe fn syscal20_$a: usiz, _ba: usiz, _ca: usiz?) -> Result<usize> {
   {Er( Error:new( ENOSY())};
 pub unsafe fn syscal30_$a: usiz, _ba: usiz, _ca: usiz, _da: usiz?) -> Result<usize> {
   {Er( Error:new( ENOSY())};
 pub unsafe fn syscal40_$a: usiz, _ba: usiz, _ca: usiz, _da: usiz, _ea: usiz?) -> Result<usize> {
   {Er( Error:new( ENOSY())};
 pub unsafe fn syscal50_$a: usiz, _ba: usiz, _ca: usiz, _da: usiz, _ea: usiz, _$f: usize?
                       -> Result<usize> {
   {Er( Error:new( ENOSY())};

#[repr(C)]
#[derive(Clone, Copy, Debug, Default)]
pub struct IntRegister(u8);
 