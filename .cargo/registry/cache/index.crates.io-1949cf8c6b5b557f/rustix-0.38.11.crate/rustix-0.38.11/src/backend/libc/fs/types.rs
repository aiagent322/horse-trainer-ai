use crate::backend::c;
use bitflags::bitflags;

#[cfg(not(target_os = "espidf"))]
bitflags! {
    /// `*_OK` constants for use with [`accessat`].
    ///
    /// [`accessat`]: fn.accessat.html
    #[repr(transparent)]
    #[derive(Copy, Clone, Eq, PartialEq, Hash, Debug)]
    pub struct Access: c::c_int {
        /// `R_OK`
        const READ_OK = c::R_OK;

        /// `W_OK`
        const WRITE_OK = c::W_OK;

        /// `X_OK`
        const EXEC_OK = c::X_OK;

        /// `F_OK`
        const EXISTS = c::F_OK;

        /// <https://docs.rs/bitflags/latest/bitflags/#externally-defined-flags>
        const _ = !0;
    }
}

#[cfg(not(any(target_os = "espidf", target_os = "redox")))]
bitflags! {
    /// `AT_*` constants for use with [`openat`], [`statat`], and other `*at`
    /// functions.
    ///
    /// [`openat`]: crate::fs::openat
    /// [`statat`]: crate::fs::statat
    #[repr(transparent)]
    #[derive(Copy, Clone, Eq, PartialEq, Hash, Debug)]
    pub struct AtFlags: u32 {
        /// `AT_SYMLINK_NOFOLLOW`
        const SYMLINK_NOFOLLOW = bitcast!(c::AT_SYMLINK_NOFOLLOW);

        /// `AT_EACCESS`
        #[cfg(not(any(target_os = "emscripten", target_os = "android")))]
        const EACCESS = bitcast!(c::AT_EACCESS);

        /// `AT_REMOVEDIR`
        const REMOVEDIR = bitcast!(c::AT_REMOVEDIR);

        /// `AT_SYMLINK_FOLLOW`
        const SYMLINK_FOLLOW = bitcast!(c::AT_SYMLINK_FOLLOW);

        /// `AT_NO_AUTOMOUNT`
        #[cfg(any(linux_like, target_os = "fuchsia"))]
        const NO_AUTOMOUNT = bitcast!(c::AT_NO_AUTOMOUNT);

        /// `AT_EMPTY_PATH`
        #[cfg(any(
            linux_kernel,
            target_os = "freebsd",
            target_os = "fuchsia",
        ))]
        const EMPTY_PATH = bitcast!(c::AT_EMPTY_PATH);

        /// `AT_RESOLVE_BENEATH`
        #[cfg(target_os = "freebsd")]
        const RESOLVE_BENEATH = bitcast!(c::AT_RESOLVE_BENEATH);

        /// `AT_STATX_SYNC_AS_STAT`
        #[cfg(all(target_os = "linux", target_env = "gnu"))]
        const STATX_SYNC_AS_STAT = bitcast!(c::AT_STATX_SYNC_AS_STAT);

        /// `AT_STATX_FORCE_SYNC`
        #[cfg(all(target_os = "linux", target_env = "gnu"))]
        const STATX_FORCE_SYNC = bitcast!(c::AT_STATX_FORCE_SYNC);

        /// `AT_STATX_DONT_SYNC`
        #[cfg(all(target_os = "linux", target_env = "gnu"))]
        const STATX_DONT_SYNC = bitcast!(c::AT_STATX_DONT_SYNC);

        /// <https://docs.rs/bitflags/latest/bitflags/#externally-defined-flags>
        const _ = !0;
    }
}

bitflags! {
    /// `S_I*` constants for use with [`openat`], [`chmodat`], and [`fchmod`].
    ///
    /// [`openat`]: crate::fs::openat
    /// [`chmodat`]: crate::fs::chmodat
    /// [`fchmod`]: crate::fs::fchmod
    #[repr(transparent)]
    #[derive(Copy, Clone, Eq, PartialEq, Hash, Debug)]
    pub struct Mode: RawMode {
        /// `S_IRWXU`
        #[cfg(not(any(target_os = "espidf", target_os = "wasi")))] // WASI doesn't have Unix-style mode flags.
        const RWXU = c::S_IRWXU as RawMode;

        /// `S_IRUSR`
        #[cfg(not(any(target_os = "espidf", target_os = "wasi")))] // WASI doesn't have Unix-style mode flags.
        const RUSR = c::S_IRUSR as RawMode;

        /// `S_IWUSR`
        #[cfg(not(any(target_os = "espidf", target_os = "wasi")))] // WASI doesn't have Unix-style mode flags.
        const WUSR = c::S_IWUSR as RawMode;

        /// `S_IXUSR`
        #[cfg(not(any(target_os = "espidf", target_os = "wasi")))] // WASI doesn't have Unix-style mode flags.
        const XUSR = c::S_IXUSR as RawMode;

        /// `S_IRWXG`
        #[cfg(not(any(target_os = "espidf", target_os = "wasi")))] // WASI doesn't have Unix-style mode flags.
        const RWXG = c::S_IRWXG as RawMode;

        /// `S_IRGRP`
        #[cfg(not(any(target_os = "espidf", target_os = "wasi")))] // WASI doesn't have Unix-style mode flags.
        const RGRP = c::S_IRGRP as RawMode;

        /// `S_IWGRP`
        #[cfg(not(any(target_os = "espidf", target_os = "wasi")))] // WASI doesn't have Unix-style mode flags.
        const WGRP = c::S_IWGRP as RawMode;

        /// `S_IXGRP`
        #[cfg(not(any(target_os = "espidf", target_os = "wasi")))] // WASI doesn't have Unix-style mode flags.
        const XGRP = c::S_IXGRP as RawMode;

        /// `S_IRWXO`
        #[cfg(not(any(target_os = "espidf", target_os = "wasi")))] // WASI doesn't have Unix-style mode flags.
        const RWXO = c::S_IRWXO as RawMode;

        /// `S_IROTH`
        #[cfg(not(any(target_os = "espidf", target_os = "wasi")))] // WASI doesn't have Unix-style mode flags.
        const ROTH = c::S_IROTH as RawMode;

        /// `S_IWOTH`
        #[cfg(not(any(target_os = "espidf", target_os = "wasi")))] // WASI doesn't have Unix-style mode flags.
        const WOTH = c::S_IWOTH as RawMode;

        /// `S_IXOTH`
        #[cfg(not(any(target_os = "espidf", target_os = "wasi")))] // WASI doesn't have Unix-style mode flags.
        const XOTH = c::S_IXOTH as RawMode;

        /// `S_ISUID`
        #[cfg(not(any(target_os = "espidf", target_os = "wasi")))] // WASI doesn't have Unix-style mode flags.
        const SUID = c::S_ISUID as RawMode;

        /// `S_ISGID`
        #[cfg(not(any(target_os = "espidf", target_os = "wasi")))] // WASI doesn't have Unix-style mode flags.
        const SGID = c::S_ISGID as RawMode;

        /// `S_ISVTX`
        #[cfg(not(any(target_os = "espidf", target_os = "wasi")))] // WASI doesn't have Unix-style mode flags.
        const SVTX = c::S_ISVTX as RawMode;

        /// <https://docs.rs/bitflags/latest/bitflags/#externally-defined-flags>
        const _ = !0;
    }
}

#[cfg(not(target_os = "espidf"))]
impl Mode {
    /// Construct a `Mode` from the mode bits of the `st_mode` field of a
    /// `Stat`.
    #[inline]
    pub const fn from_raw_mode(st_mode: RawMode) -> Self {
        Self::from_bits_truncate(st_mode)
    }

    /// Construct an `st_mode` value from `Stat`.
    #[inline]
    pub const fn as_raw_mode(self) -> RawMode {
        self.bits()
    }
}

#[cfg(not(target_os = "espidf"))]
impl From<RawMode> for Mode {
    /// Support conversions from raw mode values to `Mode`.
    ///
    /// ```
    /// use rustix::fs::{Mode, RawMode};
    /// assert_eq!(Mode::from(0o700), Mode::RWXU);
    /// ```
    #[inline]
    fn from(st_mode: RawMode) -> Self {
        Self::from_raw_mode(st_mode)
    }
}

#[cfg(not(target_os = "espidf"))]
impl From<Mode> for RawMode {
    /// Support conversions from `Mode` to raw mode values.
    ///
    /// ```
    /// use rustix::fs::{Mode, RawMode};
    /// assert_eq!(RawMode::from(Mode::RWXU), 0o700);
    /// ```
    #[inline]
    fn from(mode: Mode) -> Self {
        mode.as_raw_mode()
    }
}

bitflags! {
    /// `O_*` constants for use with [`openat`].
    ///
    /// [`openat`]: crate::fs::openat
    #[repr(transparent)]
    #[derive(Copy, Clone, Eq, PartialEq, Hash, Debug)]
    pub struct OFlags: u32 {
        /// `O_ACCMODE`
        const ACCMODE = bitcast!(c::O_ACCMODE);

        /// Similar to `ACCMODE`, but just includes the read/write flags, and
        /// no other flags.
        ///
        /// Some implementations include `O_PATH` in `O_ACCMODE`, when
        /// sometimes we really just want the read/write bits. Caution is
        /// indicated, as the presence of `O_PATH` may mean that the read/write
        /// bits don't have their usual meaning.
        const RWMODE = bitcast!(c::O_RDONLY | c::O_WRONLY | c::O_RDWR);

        /// `O_APPEND`
        const APPEND = bitcast!(c::O_APPEND);

        /// `O_CREAT`
        #[doc(alias = "CREAT")]
        const CREATE = bitcast!(c::O_CREAT);

        /// `O_DIRECTORY`
        #[cfg(not(target_os = "espidf"))]
        const DIRECTORY = bitcast!(c::O_DIRECTORY);

        /// `O_DSYNC`
        #[cfg(not(any(target_os = "dragonfly", target_os = "espidf", target_os = "l4re", target_os = "redox")))]
        const DSYNC = bitcast!(c::O_DSYNC);

        /// `O_EXCL`
        const EXCL = bitcast!(c::O_EXCL);

        /// `O_FSYNC`
        #[cfg(any(
            bsd,
            all(target_os = "linux", not(target_env = "musl")),
        ))]
        const FSYNC = bitcast!(c::O_FSYNC);

        /// `O_NOFOLLOW`
        #[cfg(not(target_os = "espidf"))]
        const NOFOLLOW = bitcast!(c::O_NOFOLLOW);

        /// `O_NONBLOCK`
        const NONBLOCK = bitcast!(c::O_NONBLOCK);

        /// `O_RDONLY`
        const RDONLY = bitcast!(c::O_RDONLY);

        /// `O_WRONLY`
        const WRONLY = bitcast!(c::O_WRONLY);

        /// `O_RDWR`
        ///
        /// This is not equal to `RDONLY | WRONLY`. It's a distinct flag.
        const RDWR = bitcast!(c::O_RDWR);

        /// `O_NOCTTY`
        #[cfg(not(any(target_os = "espidf", target_os = "l4re", target_os = "redox")))]
        const NOCTTY = bitcast!(c::O_NOCTTY);

        /// `O_RSYNC`
        #[cfg(any(
            linux_kernel,
            netbsdlike,
            target_os = "emscripten",
            target_os = "wasi",
        ))]
        const RSYNC = bitcast!(c::O_RSYNC);

        /// `O_SYNC`
        #[cfg(not(any(target_os = "l4re", target_os = "redox")))]
        const SYNC = bitcast!(c::O_SYNC);

        /// `O_TRUNC`
        const TRUNC = bitcast!(c::O_TRUNC);

        /// `O_PATH`
        #[cfg(any(
            linux_kernel,
            target_os = "emscripten",
            target_os = "freebsd",
            target_os = "fuchsia",
            target_os = "redox",
        ))]
        const PATH = bitcast!(c::O_PATH);

        /// `O_CLOEXEC`
        const CLOEXEC = bitcast!(c::O_CLOEXEC);

        /// `O_TMPFILE`
        #[cfg(any(
            linux_kernel,
            target_os = "emscripten",
            target_os = "fuchsia",
        ))]
        const TMPFILE = bitcast!(c::O_TMPFILE);

        /// `O_NOATIME`
        #[cfg(any(
            linux_kernel,
            target_os = "fuchsia",
        ))]
        const NOATIME = bitcast!(c::O_NOATIME);

        /// `O_DIRECT`
        #[cfg(any(
            linux_kernel,
            target_os = "emscripten",
            target_os = "freebsd",
            target_os = "fuchsia",
            target_os = "netbsd",
        ))]
        const DIRECT = bitcast!(c::O_DIRECT);

        /// `O_RESOLVE_BENEATH`
        #[cfg(target_os = "freebsd")]
        const RESOLVE_BENEATH = bitcast!(c::O_RESOLVE_BENEATH);

        /// `O_EMPTY_PATH`
        #[cfg(target_os = "freebsd")]
        const EMPTY_PATH = bitcast!(c::O_EMPTY_PATH);

        /// <https://docs.rs/bitflags/latest/bitflags/#externally-defined-flags>
        const _ = !0;
    }
}

#[cfg(apple)]
bitflags! {
    /// `CLONE_*` constants for use with [`fclonefileat`].
    ///
    /// [`fclonefileat`]: crate::fs::fclonefileat
    #[repr(transparent)]
    #[derive(Copy, Clone, Eq, PartialEq, Hash, Debug)]
    pub struct CloneFlags: u32 {
        /// `CLONE_NOFOLLOW`
        const NOFOLLOW = 1;

        /// `CLONE_NOOWNERCOPY`
        const NOOWNERCOPY = 2;

        /// <https://docs.rs/bitflags/latest/bitflags/#externally-defined-flags>
        const _ = !0;
    }
}

#[cfg(apple)]
mod copyfile {
    pub(super) const ACL: u32 = 1 << 0;
    pub(super) const STAT: u32 = 1 << 1;
    pub(super) const XATTR: u32 = 1 << 2;
    pub(super) const DATA: u32 = 1 << 3;
    pub(super) const SECURITY: u32 = STAT | ACL;
    pub(super) const METADATA: u32 = SECURITY | XATTR;
    pub(super) const ALL: u32 = METADATA | DATA;
}

#[cfg(apple)]
bitflags! {
    /// `COPYFILE_*` constants for use with [`fcopyfile`].
    ///
    /// [`fcopyfile`]: crate::fs::fcopyfile
    #[repr(transparent)]
    #[derive(Copy, Clone, Eq, PartialEq, Hash, Debug)]
    pub struct CopyfileFlags: c::c_uint {
        /// `COPYFILE_ACL`
        const ACL = copyfile::ACL;

        /// `COPYFILE_STAT`
        const STAT = copyfile::STAT;

        /// `COPYFILE_XATTR`
        const XATTR = copyfile::XATTR;

        /// `COPYFILE_DATA`
        const DATA = copyfile::DATA;

        /// `COPYFILE_SECURITY`
        const SECURITY = copyfile::SECURITY;

        /// `COPYFILE_METADATA`
        const METADATA = copyfile::METADATA;

        /// `COPYFILE_ALL`
        const ALL = copyfile::ALL;

        /// <https://docs.rs/bitflags/latest/bitflags/#externally-defined-flags>
        const _ = !0;
    }
}

#[cfg(linux_kernel)]
bitflags! {
    /// `RESOLVE_*` constants for use with [`openat2`].
    ///
    /// [`openat2`]: crate::fs::openat2
    #[repr(transparent)]
    #[derive(Default, Copy, Clone, Eq, PartialEq, Hash, Debug)]
    pub struct ResolveFlags: u64 {
        /// `RESOLVE_NO_XDEV`
        const NO_XDEV = 0x01;

        /// `RESOLVE_NO_MAGICLINKS`
        const NO_MAGICLINKS = 0x02;

        /// `RESOLVE_NO_SYMLINKS`
        const NO_SYMLINKS = 0x04;

        /// `RESOLVE_BENEATH`
        const BENEATH = 0x08;

        /// `RESOLVE_IN_ROOT`
        const IN_ROOT = 0x10;

        /// `RESOLVE_CACHED` (since Linux 5.12)
        const CACHED = 0x20;

        /// <https://docs.rs/bitflags/latest/bitflags/#externally-defined-flags>
        const _ = !0;
    }
}

#[cfg(linux_kernel)]
bitflags! {
    /// `RENAME_*` constants for use with [`renameat_with`].
    ///
    /// [`renameat_with`]: crate::fs::renameat_with
    #[repr(transparent)]
    #[derive(Copy, Clone, Eq, PartialEq, Hash, Debug)]
    pub struct RenameFlags: c::c_uint {
        /// `RENAME_EXCHANGE`
        const EXCHANGE = bitcast!(c::RENAME_EXCHANGE);

        /// `RENAME_NOREPLACE`
        const NOREPLACE = bitcast!(c::RENAME_NOREPLACE);

        /// `RENAME_WHITEOUT`
        const WHITEOUT = bitcast!(c::RENAME_WHITEOUT);

        /// <https://docs.rs/bitflags/latest/bitflags/#externally-defined-flags>
        const _ = !0;
    }
}

/// `S_IF*` constants for use with [`mknodat`] and [`Stat`]'s `st_mode` field.
///
/// [`mknodat`]: crate::fs::mknodat
/// [`Stat`]: crate::fs::Stat
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum FileType {
    /// `S_IFREG`
    RegularFile = c::S_IFREG as isize,

    /// `S_IFDIR`
    Directory = c::S_IFDIR as isize,

    /// `S_IFLNK`
    Symlink = c::S_IFLNK as isize,

    /// `S_IFIFO`
    #[cfg(not(target_os = "wasi"))] // TODO: Use WASI's `S_IFIFO`.
    #[doc(alias = "IFO")]
    Fifo = c::S_IFIFO as isize,

    /// `S_IFSOCK`
    #[cfg(not(target_os = "wasi"))] // TODO: Use WASI's `S_IFSOCK`.
    Socket = c::S_IFSOCK as isize,

    /// `S_IFCHR`
    CharacterDevice = c::S_IFCHR as isize,

    /// `S_IFBLK`
    BlockDevice = c::S_IFBLK as isize,

    /// An unknown filesystem object.
    Unknown,
}

impl FileType {
    /// Construct a `FileType` from the `S_IFMT` bits of the `st_mode` field of
    /// a `Stat`.
    #[inline]
    pub const fn from_raw_mode(st_mode: RawMode) -> Self {
        match (st_mode as c::mode_t) & c::S_IFMT {
            c::S_IFREG => Self::RegularFile,
            c::S_IFDIR => Self::Directory,
            c::S_IFLNK => Self::Symlink,
            #[cfg(not(target_os = "wasi"))] // TODO: Use WASI's `S_IFIFO`.
            c::S_IFIFO => Self::Fifoarget_os = "redox",
        ))]
        const PATH = bitcast!(c::O_PATHx   connt!(c::O_PATHx   connt!(c::O_PATHx   connt!   connt!(c::O_PATHx   connt!   connt!(c::O_PATHx   connt!       const PATH =e user is provast!(c::O_EMPTY_PATH);

        /// <https://docs.rs/bitflags/latest/bitflags/#externally-defined-flags>
        const _ = !0;
    }
}

#[cfg(apple)]
bitflags! {
    /// `CLONE_*` constants for use with [`fclonefileat`].
    ///
    /// [`fclonefileat`]: cranstruct a `Mode` fro( {
 // [`fclo::mode_t) &nstruct a `Mod_ // [`fclo   c::S_Ibitmapcount: ATTR_BIT_MMode, RawMode};
    /// assert_eq!(Mode::from(0o700), Mode::RWXU);
    /// ```
    #[inline]
    fn from(st_mode:       ss = "redox",
 e]
    fn OCK`
    #[cf>g(not(target_os fn fro,redox",
 e]
    fn 's `S_IFSOC>K`.
    Socket  fn fro,redox",
 e]
    fn // `S_IFC>HR`
    Charact fn fro,redox",
 e]
 is provast!(c::O_EMPTY_PATH);

        /// <https://docs.rs/bitflags/latesternally-deFC>HR`
    own,
}
 fn fro,redox",
 e]
 is provast!(c::O_EMPTY_PATH);

        /// <https://docs.   /// `CLONE_*` co with [`fcloFC>HR`
        #[in fn fro,redox",
 e]
    fn w_mode(st_mode: R>awMode) -> Self fn fro,redox",
 e]
    fn ::mode_t) & c>::S_IFMT {
     fn fro,redox",
 e]
    fn    c::S c>::S_IFMTt!(    fn fro,redox",
 unt: ATTR_BIT_MMode, RawMode::S_IFLNK => Self::Symd_tNK => t_os = "e `:S_diT`
 `.ATX__RESERVED {
   st_mode: Ro
  iTEO
st!(c::O_RESOLVE_BENEA::O_RSY
st!(c::O_RESOLVE_BENEhaikuSY
st!(c::O_RESOLVE_BENEntoSY
st!(c::O_RESOLVE_BENETMPFILe {
          co0), Mode::RWXU)t_sizes(.
            diT`
 _d_tNK (d_tNK    8rget_os = "redox",
       d_tNK (c::O_PATHx   connD_FORO_PATHx   connt!(c::O_PATHx   connt!   D_Ft!(c::O_PATHx   connt!   connt!(c::O_PAD_F  connt!       const PATH =e user is provast!(c::O_EMPTY_PATH);

        /// <https://dD_F   /// `CLONE_*` constD_F   / use with [`fclonefileat`].
  is provast!(c::O_EMPTY_PATH);

        /// <https://dD_F.rs/bitflags/latest/biD_F.rs/#externally-defined-flags>
 /biD_F   /// [`fclonefileat`]: cranstruct a `Mode` D_F {
 // [`fclo::mode_t) &nstruct a `Mod   e` D_FUNKNOWN |struct a `Mod_ // [`fclo   c::S_Ibitmapcount: ATTry = c::POSIX_FADVT`
        const STAT = copyfim the        /// `S_im the          const Xm the 
RESERVED {
   st_mo))
   
onst TRUNC = bitcastRo
  iTEO
st!(t_env = "musl")),
      
c::O_RESOLVE_BENEA::O_RSY
st!(_RESOLVE_BENEhaikuSY
st!(       const TMPFILE        /// `RESOaliasTEOUT = bitcast!(c::RENAMEio::Resultu32  Fifo = c::Adt) & s isize,

 POSIX_FADVTdatMAparent)Nesull c::S_POSIX_FADVTdatMApATTR_CMN_lloc() isize,

 POSIX_FADVTSEQUENTIAparent)Sequ`
 ill c::S_POSIX_FADVTSEQUENTIApATTR_CMN_lloc() isize,

 POSIX_FADVTRANDOM`S_IFSOymlelfc::S_POSIX_FADVTRANDOMATTR_CMN_lloc() isize,

 POSIX_FADVTdat`USEarent)NeReTAT c::S_POSIX_FADVTdat`USEATTR_CMN_lloc() isize,

 POSIX_FADVTWILLNEEfg(not(WillNern "C:S_POSIX_FADVTWILLNEEfATTR_CMN_lloc() isize,

 POSIX_FADVT  //NEEfg(not(DontNern "C:S_POSIX_FADVT  //NEEfATTR_CMN_lloc()e.as_ptr(), 0VE_BENEATH = PTY_PATH`
        #[cf {
        /// `AT_SYMLINMFDT`
        const STAT = copyfmemfd_crap()     const NOREPLACE =memfd_crap()    #[cfg(not(taemfd_crap()_IRUSR`
        #[cfg(not(any(target_os = "espidf", target_os = "wasi")))] // WASI doesn't have Uemfds.rs/bitflags/latest/bitflags/#eMFDT            linux_kernel,
       tflMFDT       te::fs::mknodat
MFDTA(supTSEALINGarent)]
    #[derivupTSEALING   tflMFDTrivupTSEALINGte::fs::mknodat
MFDTHUGETLBenameat_with
  4.14repr(transparentHUGETLB   tflMFDTHUGETLBte::fs::mknodat
MFDTHUGE_64KB`epr(transparentHUGE_64KB   tflMFDTHUGE_64KB;::fs::mknodat
MFDTHUGE_512JB`epr(transparentHUGE_512KB   tflMFDTHUGE_512KB;::fs::mknodat
MFDTHUGE_1MB`epr(transparentHUGE_1MB   tflMFDTHUGE_1MB;::fs::mknodat
MFDTHUGE_2MB`epr(transparentHUGE_2MB   tflMFDTHUGE_2MB;::fs::mknodat
MFDTHUGE_8MB`epr(transparentHUGE_8MB   tflMFDTHUGE_8MB;::fs::mknodat
MFDTHUGE_16MB`epr(transparentHUGE_16MB   tflMFDTHUGE_16MB;::fs::mknodat
MFDTHUGE_32MB`epr(transparentHUGE_32MB   tflMFDTHUGE_32MB;::fs::mknodat
MFDTHUGE_256MB`epr(transparentHUGE_256MB   tflMFDTHUGE_256MB;::fs::mknodat
MFDTHUGE_512MB`epr(transparentHUGE_512MB   tflMFDTHUGE_512MB;::fs::mknodat
MFDTHUGE_1GB`epr(transparentHUGE_1GB   tflMFDTHUGE_1GB;::fs::mknodat
MFDTHUGE_2GB`epr(transparentHUGE_2GB   tflMFDTHUGE_2GB;::fs::mknodat
MFDTHUGE_16GB`epr(transparentHUGE_16GB   tflMFDTHUGE_16GB 3;
    pub(super) const SECURITY: u32 = STAT | ACL;
    pub(super) const METADATA: u32 = SECURITY | XATTR;
    pub(super), 0VE_BENEATH = PTY_PATH`
        #[cf  /// `AT_RESOLVE_BENEATH`
       /// `AT_SYMLINFTSEALT`
        const STAT = copyfilnts.add_seals  Syml/// `COPYFILEnts.
`ATseals  
        /// `COPYFILEnts.add_seals         const XAnts.add_seals/// `COPYFILEnts.
`ATseals         const XAnts.
`ATseals_IRUSR`
        #[cfg(not(any(target_os = "espidf", target_os = "wasi")))] // WASI doesn't have Seal2 = 1 << 0;
    pub(super)FTSEALTSEAL`ine]
    pub consEALClone, Copy, DeFTSEALTSEAL);    pub(super)FTSEALTSHRINK`ine]
    pub consHRINKClone, Copy, DeFTSEALTSHRINK);    pub(super)FTSEALTGROW`ine]
    pub conGROWClone, Copy, DeFTSEALTGROW);    pub(super)FTSEALTgs! {`ine]
    pub congs! {Clone, Copy, DeFTSEALTgs! {);    pub(super)FTSEALTFUTURETgs! {`nameat_with
    #)// [`fclonefileassert!(core::mem::
        //UTURETgs! {Clone, Copy, DeFTSEALT/UTURETgs! {lone, Eq, PartialEq, Hash, Debug)]
    pub struct CloneFlags: u32 {
        /// `CLONE_NOFOLLOW`
        const NOFOLLOW = 1`fchmod`].
    ///
    /// [`openat`]: crate::truct Mode: RawMode {
at
  `
        const STAT = copyf"andx  
        /// `COPYFI"andx   target_os = "andx_IRUSR`
        #[cfg(not(any(target_os = "espidf", target_os = "wasi")))] // WASI doesn't have Sandx2 = 1 << 0;
    pub(super)
at
  TYP] and [`Stat`]'s TYP] c::S_Iat
  TYP]arget_os = "espidat
  s. Caution is
      onst DI:S_Iat
  onstarget_os = "espidat
  Ncons and [`Stat`]'s `LINKClo:S_Iat
  `LINKarget_os = "espidat
  nst SGID = c:t`]'s  doesn't hat
  nstarget_os = "espidat
  Gst SGID = c:t`]'s Gdoesn't hat
  Gstarget_os = "espidat
  get_os = "fuchs::timeva    //'t hat
  At Attrget_os = "espidat
  set_os = "fuchs::timeMa    //'t hat
  Mt Attrget_os = "espidat
  Cet_os = "fuchs::timeCa    //'t hat
  Ct Attrget_os = "espidat
  INOmeat_with`].
    /O //'t hat
   /Otrget_os = "espidat
  SIZos = "fuchs::timeSIZo //'t hat
  SIZotrget_os = "espidat
     //defined-flags>
     //d //'t hat
     //dtrget_os = "espidat
   ASICMETADdefined-flags>
   ASICMETADd //'t hat
   ASICMETADdtrget_os = "espidat
   et_os = "fuchs::timeBa    //'t hat
  Bt Attrget_os = "espidat
  sNT_Irenameat_with
    8repr(transparentsNT_Ir //'t hat
  MNT_Irtrget_os = "espidat
  DIOALIGNenameat_with
  6 #)// [`fclo/ <httpsOALIGN //'t hat
  psOALIGNarget_os = "espidat
  gsparent)]
    #[derive(Det hat
  Ay, Clone, Eq, PartialEq, Hash, Debug)]
    pub struct ResolveFlags: u64 {
        /// `RESOLVE_NO_XDEV`
        const NO_XD
   st_moux_like, target_os = Y
st!(       /// `O_RDONLY`
        const RDONLY  crateE   ::truct Mode: RawMode {
at
  `
        const STAT = copyf"andx  
        /// `COPYFI"andx   target_os = "andx_IRUSR`
        #[cfg(not(any(target_os = "espidf", target_os = "wasi")))] // WASI doesn't have Sandx2 = 1 << 0;
    pub(super)
at
  TYP] and [`Stat`]'s TYP] c:   le1arget_os = "espidat
  s. Caution is
      onst DI   le2arget_os = "espidat
  Ncons and [`Stat`]'s `LINKClo   le4arget_os = "espidat
  nst SGID = c:t`]'s  doesn   le8arget_os = "espidat
  Gst SGID = c:t`]'s Gdoesn   l [`renameat_with`]dat
  get_os = "fuchs::timeva    //   l20trget_os = "espidat
  set_os = "fuchs::timeMa    //   l40trget_os = "espidat
  Cet_os = "fuchs::timeCa    //   l80trget_os = "espidat
  INOmeat_with`].
    /O //ce L00trget_os = "espidat
  SIZos = "fuchs::timeSIZo ///bit00trget_os = "espidat
     //defined-flags>
     //d //= !000trget_os = "espidat
   ASICMETADdefined-flags>
   ASICMETADd //= !7fftrget_os = "espidat
   et_os = "fuchs::timeBa    //0x800trget_os = "espidat
  sNT_Irenameat_with
    8repr(transparentsNT_Ir //// [00trget_os = "espidat
  gsparent)]
    #[derive(D0xffftrget_os = "espfs::openat
    /// [`statat`]: crate::fs::statat
    #[repr(transparent)]
    #[derive(Copy, Clone, Eq, PartialEq,
onst TRUNC = bitcastRo
  iTEO
st!(t_env = "muslaix  
c::O_RESOLVE_BENEA::O_RSY
st!(_RESOLVE_BENEntoSY
st!(_RESOLVE_BENETMPFILe2 {
        /// `AT_SYMLINFrivuC_FLT`
        const STAT = copyfi   ocp()     const NOREPLACE =i   ocp()         const Xm  ocp()_IRUSR`
        #[cfg(not(any(target_os = "espidf", target_os = "wasi")))] // WASI doesn't have Fm  ocp()2 = 1 << 0;
    pub(super)FrivuC_FLTKEEP SIZos = "fuchsRESERVED {
   st_mode: t!(c::O_NONBLOCK);

 t_env = "muslaix  
c::Ost!(c::O_RESOLVE_BENEhaikuSY
st!(c::O   #[cfg(any(
            linux_ke::mem::
        /KEEP SIZoClone, Copy, DeFrivuC_FLTKEEP SIZo);    pub(super)FrivuC_FLTPUNCH_HOLos = "fuchsRESERVED {
   st_mode: t!(c::O_NONBLOCK);

 t_env = "muslaix  
c::Ost!(c::O_RESOLVE_BENEhaikuSY
st!(c::O   #[cfg(any(
            linux_ke::mem::
        /PUNCH_HOLoClone, Copy, DeFrivuC_FLTPUNCH_HOLo);    pub(super)FrivuC_FLTNO_HID METALos = "fuchsRESERVED {
   st_mode: t!(c::O_NONBLOCK);

 t_env = "muslaix  
c::Ost!(c::O_RESOLVE_BENE #[cfg(any(
            linux_kernel,
            targetc::O_RESOLVE_BENEhaikuSY
st!(c::O   #[cfg(any(
   "fuchs
st!(c::O   #[cfg(any(
   "LY`
  
st!(c::O   #[cfg(any(
            linux_ke::mem::
        /NO_HID METALoClone, Copy, DeFrivuC_FLTNO_HID METALo);    pub(super)FrivuC_FLTCOLLAPSETRANGos = "fuchsRESERVED {
   st_mode: t!(c::O_NONBLOCK);

 t_env = "muslaix  
c::Ost!(c::O_RESOLVE_BENEhaikuSY
st!(c::O   #[cfg(any(
      /// `O_PATH`
        #[cfg(any(
            linux_ke
        const DSYOLLAPSETRANGoClone, Copy, DeFrivuC_FLTYOLLAPSETRANGo);    pub(super)FrivuC_FLTZEROTRANGos = "fuchsRESERVED {
   st_mode: t!(c::O_NONBLOCK);

 t_env = "muslaix  
c::Ost!(c::O_RESOLVE_BENEhaikuSY
st!(c::O   #[cfg(any(
      /// `O_PATH`
        #[cfg(any(
            linux_ke
        const DSZEROTRANGoClone, Copy, DeFrivuC_FLTZEROTRANGo);    pub(super)FrivuC_FLTINSERTTRANGos = "fuchsRESERVED {
   st_mode: t!(c::O_NONBLOCK);

 t_env = "muslaix  
c::Ost!(c::O_RESOLVE_BENEhaikuSY
st!(c::O   #[cfg(any(
      /// `O_PATH`
        #[cfg(any(
            linux_ke
        const DSINSERTTRANGoClone, Copy, DeFrivuC_FLTINSERTTRANGo);    pub(super)FrivuC_FLTUNSHARETRANGos = "fuchsRESERVED {
   st_mode: t!(c::O_NONBLOCK);

 t_env = "muslaix  
c::Ost!(c::O_RESOLVE_BENEhaikuSY
st!(c::O   #[cfg(any(
      /// `O_PATH`
        #[cfg(any(
            linux_ke
        const DSUNSHARETRANGoClone, Copy, DeFrivuC_FLTUNSHARETRANGo)enat`]: crate::fs::openat
    /// [`statat`]: crate::fs::statat
    #[repr(transparent)]
    #[derive(Copy, Clone, Eq, PartialEq, Hash, Debug)haikuSY(       const TMPFILEhe mode bits of the `st:truct Mode: RawMode {
aT`
        const STAT = copyfSandVfs  
     R`
        #[cfg(not(any(target_os = "espidf", target_os = "wasi")))] // WASI doesn't have SandVfsMountT`
        const IN_ROOT =
aTMAND        const (super), 0VE_BENEATH = PTY_PATH`
    #[cfg(any(linux_like, targVE_BENEATH`
        #[cfg(MAND    e(Det haTMAND    ATTR   trget_os = "espidatarget_os = "fuchsia",
     VE_BENEATH = PTY_PATH`
    #[cfg(any(linux_like, targVE_BENEATH`
        #[cfg(        //et haT        TTR   trget_os = "espidatar    /// `RESO")]
        const RESOLVE_BENEATH = bitcast!(c::O_RESOLVE_BENEaix  
c::Ost!(c::O_RESOLVE_BENE #[cfg(any(
            linux_kernel,
         = bitcast!(c::O_DIRECT);

  ` (sinet haT  ` (sTTR   trget_os = "espidatar IRget_os = "fuchsia",
     VE_BENEATH = PTY_PATH`
    #[cfg(any(linux_like, targVE_BENEATH`
        #[cfg(   IRget_osinet haT  `IRget_osTTR   trget_os = "espidatar         linuxia",
     VE_BENEATH = PTY_PATH`
    #[cfg(any(linux_like, targVE_BENEATH`
        #[cfg(         tfldatar    sTTR   trget_os = "espidataronst SGID = c::S_ISGID aO_RDWR`
        ///
        /// This is I doesn't hataronstsTTR   trget_os = "espidat  #[cfg(not(any(:S_ISGID aO_RDWR`
        ///
        /// This i_os = "es't hat_os = "TTR   trget_os = "espidat ELget_os = "fuchsia",
     ux_like, target_os = Y 1`fchmod`].
    ///
    /// [`openat`]: crateg(apple)]
bitflags!Lget_osinet haTs!Lget_osTTR   trget_os = "espidatnst HRONOUS     linuxia",
     VE_BENEATH = PTY_PATH`
    #[cfg(any(linux_like, targVE_BENEATH`
        #[cfg(nst HRONOUSsinet haTnst HRONOUSsTTR   trget_os = "espileType {
    /// `S_IFREG`
    RegularFile = c::S_IFREG as isize,

    /// `S_IFDIR`
    Directory = c::    T`
        const STAT = copyfi:mod  SymlinkXAnts.:mod       /// `S_i:mod         const X:mod
COPYFILEnts.:mod         const XEnts.:mod
{
    /// Construct a `Mode` from the mode bits of the `stI's `S_IFIFO`.
    #[doc(alias = "IFO")]
    F:Resultu32  Fifo = c::F:modOperY | ce: RawMode {    TS]
bitflLmodShcfgdClone, Copy, De    TS]ast!(c:ode {    TEX
bitflLmodExclus_IFClone, Copy, De    TEXast!(c:ode {    TUN`       :modClone, Copy, De    TUNast!(c:ode {    TSH |     TNBarent)Nen::modingLmodShcfgdClone, Copy, De    TS];

       TNBast!(c:ode {    TEX |     TNBarent)Nen::modingLmodExclus_IFClone, Copy, De    TEX;

       TNBast!(c:ode {    TUN |     TNBarent)Nen::moding  :modClone, Copy, De    TUN;

       TNBastry = c::t have "and`nst STAT = copyf"and    Symlinkf"and`      /// `S_ripten", target_os = "androiCOPYFILsten", target_os = Lsten
{
    /// );

      
fn tes      Sandsinet sten;y = c::t have "and`nst STAT = copyf"and    Symlinkf"and`      /// `S_ripten", target_os = "androiCOPYFILsten", target_os = Lsten
{
    
   st_mo)`fcVE_BENEATH = PTY_PATHpoin c:_widcops o64") 
c::O_RESOLVE_BENEA#[cfg(any(
     [cfg(any(
   "fuchs

fn tes      Sandsinet sten  trg= c::t have "and`nst STAT = copyf"and    Symlinkf"and`      /// `S_ripten", target_os = "androiCOPYFILsten", target_os = Lsten
OPYOn 32-ne,,with
 S_IFLNhave "and64());
}a 32-ne,;
    = bi`Symlifriends, so
OPYweSTAT our ::S LNhave, popu`
  d_eq!(Mo"andx 
   re possib    to at.asf::S
         ali.LLOW = 1`fcVE_BENEATH = PTY_PATHpoin c:_widcops o32")  F:ResultC     /// `RESOaliasTEOUT = bit     m  ow(missing_
   fn tes t have SandETADATA |  t _dev     ,ADATA |  t _> Selfu32,ADATA |  t _), Mklfu32,ADATA |  t _uidlfu32,ADATA |  t _gidlfu32,ADATA |  t _rdev     ,ADATA |  t _    : i  ,ADATA |  t _blk    : u32,ADATA |  t _b:mods     ,ADATA |  t _a= bi     ,ADATA |  t _a= bi_nsec: u32,ADATA |  t _m= bi     ,ADATA |  t _m= bi_nsec: u32,ADATA |  t _c= bi     ,ADATA |  t _c= bi_nsec: u32,ADATA |  t _ino     ,Ary = c::t have "andfs nst STAT = copyf"andfs  Symlinkf"andfs  
    /// `S_riptfs", target_os = "andfsiCOPYFILstenfs", target_os = Lstenfs Eq, PartialEq,
onst);

       tcastRo
  iTEO
st!(t_env = "muslA::O_RSY
st!(_RESOLVE_BENEhaikuSY
st!(       const c::O_EMPTY_PA_RESOLVE_BENEntoSY
st!(_RESOLVE_BENETMPFILY
st!(_RESOLVE_BENE        `stI'sm  ow(clippyconstuli_nabi_esueti | c:fn tes      SandFssinet stenfs;y = c::t have "andfs nst STAT = copyf"andfs  Symlinkf"andfs  
    /// `S_riptfs", target_os = "andfsiCOPYFILstenfs", target_os = Lstenfs Eq, Pa);

      
n tes      SandFssinet stenfs  trg= c::t have "andvfs nst STAT = copyf"andvfs  Symlinkf"andvfs  
    /// `S_riptvfs", target_os = "andvfsiCOPYFILstenvfs", target_os = Lstenvfs Eq, PartialEq, Hash, Debug)haikuSY(       const TMPFILEhe mode bits of the `st:  m  ow(missing_
   fn tes t have SandVfsETADATA |  f_b    : u  ,ADATA |  f_fr    : u  ,ADATA |  f_b:mods     ,ADATA |  f_b         ,ADATA |  f_bavail: u  ,ADATA |  f_fRegu: u  ,ADATA |  f_f         ,ADATA |  f_favail: u  ,ADATA |  f_fsidlfu  ,ADATA |  f_fze,: SandVfsMountT`
  ,ADATA |  f_nabimax     ,Ary = c::t have "andx`nst STAT = copyf"andx  
    /// `S_riptx   target_os = "andx_LOW = 1`fchmod`].
    ///
    /// [`openat`]: crate::/ `/ <h::Syg0000::t have "andx`. tes      Sandxsinet stenxtrg= c::t have "andx_t        `nst STAT = copyfSandx  
 LOW = 1`fchmod`].
    ///
    /// [`openat`]: crate::/ `/ <h::Syg0000::t have "andx_t        `. tes      Sandx         sinet stenxtrg= c::t have "andx`nst STAT = copyf"andx  
    /// `S_riptx   target_os = "andx_/ `Nen-g0000:ABI       #curfg(nly dec
  e"e `t have "andx`, soYweSdec
  e"in
OPY    elvcrat NO_XD
   st_moux_like, target_os = Y
st!(       /// `O_RDONLY`
        const RDONLY  crateE   :::ResultC     m  ow(missing_
   fn tes t have SandxETADATA |  t x_masklfu32,ADATA |  t x_blk    : u32,ADATA |  t x_a=tributes     ,ADATA |  t x_), Mklfu32,ADATA |  t x_uidlfu32,ADATA |  t x_gidlfu32,ADATA |  t x_> Selfu16,ADATA__"andx_pad1: [u16; 1],ADATA |  t x_ino     ,ADATA |  t x_    : u  ,ADATA |  t x_blmods     ,ADATA |  t x_a=tributes_masklfu  ,ADATA |  t x_a= bi  Sandx         ,ADATA |  t x_b= bi  Sandx         ,ADATA |  t x_c= bi  Sandx         ,ADATA |  t x_m= bi  Sandx         ,ADATA |  t x_rdev_majorlfu32,ADATA |  t x_rdev_minorlfu32,ADATA |  t x_dev_majorlfu32,ADATA |  t x_dev_minorlfu32,ADATA |  t x_mn _idlfu  ,ADATA__"andx_pad2lfu  ,ADATA__"andx_pad3: [u  t 12],Ary = c::t have "andx_t        `nst STAT = copyfSandx  
 / `Nen-g0000:ABI       #curfg(nly dec
  e"e `t have "andx_t        `, soYwe / `dec
  e"inY    elvcrat NO_XD
   st_moux_like, target_os = Y
st!(       /// `O_RDONLY`
        const RDONLY  crateE   :::ResultC     m  ow(missing_
   fn tes t have Sandx         sTADATA |  tv_sec: i  ,ADATA |  tv_nsec: u32,ADATA |  __"andx_t        _pad1: [i32; 1],Ary = c::nst PA` Eq, Partial      /// `O_RDOet_os = Y TY_PATHpoin c:_widcops o32") 
n tes       fn from=  const PA;y = c::nst PA` Eq, Pal      /// `O_RDOet_os = Y TY_PATHpoin c:_widcops o32") n tes       fn from=  coags/la;y = c::dev_A` Eq, Partial      /// `O_RDOet_os = Y TY_PATHpoin c:_widcops o32") 
n tes      Devm=  codev_A;y = c::dev_A` Eq, Pal      /// `O_RDOet_os = Y TY_PATHpoin c:_widcops o32") n tes      Devm=  coags big big;y = c::__fsword_A` Eq, Pal   
   #[cfg(any(
   "LY`
  
st!(     const RDONLY = bitc 
st!(     const arcops os390x")s

fn tes      FsWordm=  co__fsword_A;y = c::__fsword_A` Eq, Pal   
   #    ux_like, target_os = Y 1`fchmod`].
    ///
    /// [`openat`]:= bitcast!(c:TY_PATHpoin c:_widcops o32"s

fn tes      FsWordm= u32;y = c::__fsword_A` Eq, Pal   
   #    ux_like, target_os = Y 1`fchmod`].
    ///
    /// [`openat`]:= bitcast!(c:     const arcops os390x")s
!(c:TY_PATHpoin c:_widcops o64"s

fn tes      FsWordm= u  trg= c::__fsword_A` APPE390xSTATs `u32`nst S_riptfs" g(nriTs onyg0000, eve_CREough::__fsword_A`  #[ c::u  `
 LOW = 1`fchmod`].
    ///
    /// [`oparcops os390x" /// [`openat`]: crate::tes      FsWordm= u32;y = c::__fsword_A` APPE390xSTATs `u64()st S_riptfs" g(nriTs ony= bi
 LOW = 1`fchmod`].
    ///
    /// [`oparcops 