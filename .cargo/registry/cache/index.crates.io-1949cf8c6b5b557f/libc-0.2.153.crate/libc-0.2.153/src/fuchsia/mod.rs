//! Definitions found commonly among almost all Unix derivatives
//!
//! More functions and definitions can be found in the more specific modules
//! according to the platform in question.

// PUB_TYPE

pub type c_schar = i8;
pub type c_uchar = u8;
pub type c_short = i16;
pub type c_ushort = u16;
pub type c_int = i32;
pub type c_uint = u32;
pub type c_float = f32;
pub type c_double = f64;
pub type c_longlong = i64;
pub type c_ulonglong = u64;
pub type intmax_t = i64;
pub type uintmax_t = u64;

pub type locale_t = *mut ::c_void;

pub type size_t = usize;
pub type ptrdiff_t = isize;
pub type intptr_t = isize;
pub type uintptr_t = usize;
pub type ssize_t = isize;

pub type pid_t = i32;
pub type uid_t = u32;
pub type gid_t = u32;
pub type in_addr_t = u32;
pub type in_port_t = u16;
pub type sighandler_t = ::size_t;
pub type cc_t = ::c_uchar;
pub type sa_family_t = u16;
pub type pthread_key_t = ::c_uint;
pub type speed_t = ::c_uint;
pub type tcflag_t = ::c_uint;
pub type clockid_t = ::c_int;
pub type key_t = ::c_int;
pub type id_t = ::c_uint;
pub type useconds_t = u32;
pub type dev_t = u64;
pub type socklen_t = u32;
pub type pthread_t = c_ulong;
pub type mode_t = u32;
pub type ino64_t = u64;
pub type off64_t = i64;
pub type blkcnt64_t = i64;
pub type rlim64_t = u64;
pub type mqd_t = ::c_int;
pub type nfds_t = ::c_ulong;
pub type nl_item = ::c_int;
pub type idtype_t = ::c_uint;
pub type loff_t = ::c_longlong;

pub type __u8 = ::c_uchar;
pub type __u16 = ::c_ushort;
pub type __s16 = ::c_short;
pub type __u32 = ::c_uint;
pub type __s32 = ::c_int;

pub type Elf32_Half = u16;
pub type Elf32_Word = u32;
pub type Elf32_Off = u32;
pub type Elf32_Addr = u32;

pub type Elf64_Half = u16;
pub type Elf64_Word = u32;
pub type Elf64_Off = u64;
pub type Elf64_Addr = u64;
pub type Elf64_Xword = u64;

pub type clock_t = c_long;
pub type time_t = c_long;
pub type suseconds_t = c_long;
pub type ino_t = u64;
pub type off_t = i64;
pub type blkcnt_t = i64;

pub type shmatt_t = ::c_ulong;
pub type msgqnum_t = ::c_ulong;
pub type msglen_t = ::c_ulong;
pub type fsblkcnt_t = ::c_ulonglong;
pub type fsfilcnt_t = ::c_ulonglong;
pub type rlim_t = ::c_ulonglong;

pub type c_long = i64;
pub type c_ulong = u64;

// FIXME: why are these uninhabited types? that seems... wrong?
// Presumably these should be `()` or an `extern type` (when that stabilizes).
#[cfg_attr(feature = "extra_traits", derive(Debug))]
pub enum timezone {}
impl ::Copy for timezone {}
impl ::Clone for timezone {
    fn clone(&self) -> timezone {
        *self
    }
}
#[cfg_attr(feature = "extra_traits", derive(Debug))]
pub enum DIR {}
impl ::Copy for DIR {}
impl ::Clone for DIR {
    fn clone(&self) -> DIR {
        *self
    }
}

#[cfg_attr(feature = "extra_traits", derive(Debug))]
pub enum fpos64_t {} // FIXME: fill this out with a struct
impl ::Copy for fpos64_t {}
impl ::Clone for fpos64_t {
    fn clone(&self) -> fpos64_t {
        *self
    }
}

// PUB_STRUCT

s! {
    pub struct group {
        pub gr_name: *mut ::c_char,
        pub gr_passwd: *mut ::c_char,
        pub gr_gid: ::gid_t,
        pub gr_mem: *mut *mut ::c_char,
    }

    pub struct utimbuf {
        pub actime: time_t,
        pub modtime: time_t,
    }

    pub struct timeval {
        pub tv_sec: time_t,
        pub tv_usec: suseconds_t,
    }

    pub struct timespec {
        pub tv_sec: time_t,
        pub tv_nsec: ::c_long,
    }

    // FIXME: the rlimit and rusage related functions and types don't exist
    // within zircon. Are there reasons for keeping them around?
    pub struct rlimit {
        pub rlim_cur: rlim_t,
        pub rlim_max: rlim_t,
    }

    pub struct rusage {
        pub ru_utime: timeval,
        pub ru_stime: timeval,
        pub ru_maxrss: c_long,
        #[cfg(all(target_arch = "x86_64", target_pointer_width = "32"))]
        __pad1: u32,
        pub ru_ixrss: c_long,
        #[cfg(all(target_arch = "x86_64", target_pointer_width = "32"))]
        __pad2: u32,
        pub ru_idrss: c_long,
        #[cfg(all(target_arch = "x86_64", target_pointer_width = "32"))]
        __pad3: u32,
        pub ru_isrss: c_long,
        #[cfg(all(target_arch = "x86_64", target_pointer_width = "32"))]
        __pad4: u32,
        pub ru_minflt: c_long,
        #[cfg(all(target_arch = "x86_64", target_pointer_width = "32"))]
        __pad5: u32,
        pub ru_majflt: c_long,
        #[cfg(all(target_arch = "x86_64", target_pointer_width = "32"))]
        __pad6: u32,
        pub ru_nswap: c_long,
        #[cfg(all(target_arch = "x86_64", target_pointer_width = "32"))]
        __pad7: u32,
        pub ru_inblock: c_long,
        #[cfg(all(target_arch = "x86_64", target_pointer_width = "32"))]
        __pad8: u32,
        pub ru_oublock: c_long,
        #[cfg(all(target_arch = "x86_64", target_pointer_width = "32"))]
        __pad9: u32,
        pub ru_msgsnd: c_long,
        #[cfg(all(target_arch = "x86_64", target_pointer_width = "32"))]
        __pad10: u32,
        pub ru_msgrcv: c_long,
        #[cfg(all(target_arch = "x86_64", target_pointer_width = "32"))]
        __pad11: u32,
        pub ru_nsignals: c_long,
        #[cfg(all(target_arch = "x86_64", target_pointer_width = "32"))]
        __pad12: u32,
        pub ru_nvcsw: c_long,
        #[cfg(all(target_arch = "x86_64", target_pointer_width = "32"))]
        __pad13: u32,
        pub ru_nivcsw: c_long,
        #[cfg(all(target_arch = "x86_64", target_pointer_width = "32"))]
        __pad14: u32,
    }

    pub struct in_addr {
        pub s_addr: in_addr_t,
    }

    pub struct in6_addr {
        pub s6_addr: [u8; 16],
    }

    pub struct ip_mreq {
        pub imr_multiaddr: in_addr,
        pub imr_interface: in_addr,
    }

    pub struct ip_mreqn {
        pub imr_multiaddr: in_addr,
        pub imr_address: in_addr,
        pub imr_ifindex: ::c_int,
    }

    pub struct ipv6_mreq {
        pub ipv6mr_multiaddr: in6_addr,
        pub ipv6mr_interface: ::c_uint,
    }

    pub struct hostent {
        pub h_name: *mut ::c_char,
        pub h_aliases: *mut *mut ::c_char,
        pub h_addrtype: ::c_int,
        pub h_length: ::c_int,
        pub h_addr_list: *mut *mut ::c_char,
    }

    pub struct iovec {
        pub iov_base: *mut ::c_void,
        pub iov_len: ::size_t,
    }

    pub struct pollfd {
        pub fd: ::c_int,
        pub events: ::c_short,
        pub revents: ::c_short,
    }

    pub struct winsize {
        pub ws_row: ::c_ushort,
        pub ws_col: ::c_ushort,
        pub ws_xpixel: ::c_ushort,
        pub ws_ypixel: ::c_ushort,
    }

    pub struct linger {
        pub l_onoff: ::c_int,
        pub l_linger: ::c_int,
    }

    pub struct sigval {
        // Actually a union of an int and a void*
        pub sival_ptr: *mut ::c_void
    }

    // <sys/time.h>
    pub struct itimerval {
        pub it_interval: ::timeval,
        pub it_value: ::timeval,
    }

    // <sys/times.h>
    pub struct tms {
        pub tms_utime: ::clock_t,
        pub tms_stime: ::clock_t,
        pub tms_cutime: ::clock_t,
        pub tms_cstime: ::clock_t,
    }

    pub struct servent {
        pub s_name: *mut ::c_char,
        pub s_aliases: *mut *mut ::c_char,
        pub s_port: ::c_int,
        pub s_proto: *mut ::c_char,
    }

    pub struct protoent {
        pub p_name: *mut ::c_char,
        pub p_aliases: *mut *mut ::c_char,
        pub p_proto: ::c_int,
    }

    pub struct aiocb {
        pub aio_fildes: ::c_int,
        pub aio_lio_opcode: ::c_int,
        pub aio_reqprio: ::c_int,
        pub aio_buf: *mut ::c_void,
        pub aio_nbytes: ::size_t,
        pub aio_sigevent: ::sigevent,
        __td: *mut ::c_void,
        __lock: [::c_int; 2],
        __err: ::c_int,
        __ret: ::ssize_t,
        pub aio_offset: off_t,
        __next: *mut ::c_void,
        __prev: *mut ::c_void,
        #[cfg(target_pointer_width = "32")]
        __dummy4: [::c_char; 24],
        #[cfg(target_pointer_width = "64")]
        __dummy4: [::c_char; 16],
    }

    pub struct sigaction {
        pub sa_sigaction: ::sighandler_t,
        pub sa_mask: ::sigset_t,
        pub sa_flags: ::c_int,
        pub sa_restorer: ::Option<extern fn()>,
    }

    pub struct termios {
        pub c_iflag: ::tcflag_t,
        pub c_oflag: ::tcflag_t,
        pub c_cflag: ::tcflag_t,
        pub c_lflag: ::tcflag_t,
        pub c_line: ::cc_t,
        pub c_cc: [::cc_t; ::NCCS],
        pub __c_ispeed: ::speed_t,
        pub __c_ospeed: ::speed_t,
    }

    pub struct flock {
        pub l_type: ::c_short,
        pub l_whence: ::c_short,
        pub l_start: ::off_t,
        pub l_len: ::off_t,
        pub l_pid: ::pid_t,
    }

    pub struct ucred {
        pub pid: ::pid_t,
        pub uid: ::uid_t,
        pub gid: ::gid_t,
    }

    pub struct sockaddr {
        pub sa_family: sa_family_t,
        pub sa_data: [::c_char; 14],
    }

    pub struct sockaddr_in {
        pub sin_family: sa_family_t,
        pub sin_port: ::in_port_t,
        pub sin_addr: ::in_addr,
        pub sin_zero: [u8; 8],
    }

    pub struct sockaddr_in6 {
        pub sin6_family: sa_family_t,
        pub sin6_port: ::in_port_t,
        pub sin6_flowinfo: u32,
        pub sin6_addr: ::in6_addr,
        pub sin6_scope_id: u32,
    }

    pub struct addrinfo {
        pub ai_flags: ::c_int,
        pub ai_family: ::c_int,
        pub ai_socktype: ::c_int,
        pub ai_protocol: ::c_int,
        pub ai_addrlen: socklen_t,

        pub ai_addr: *mut ::sockaddr,

        pub ai_canonname: *mut c_char,

        pub ai_next: *mut addrinfo,
    }

    pub struct sockaddr_ll {
        pub sll_family: ::c_ushort,
        pub sll_protocol: ::c_ushort,
        pub sll_ifindex: ::c_int,
        pub sll_hatype: ::c_ushort,
        pub sll_pkttype: ::c_uchar,
        pub sll_halen: ::c_uchar,
        pub sll_addr: [::c_uchar; 8]
    }

    pub struct fd_set {
        fds_bits: [::c_ulong; FD_SETSIZE / ULONG_SIZE],
    }

    pub struct tm {
        pub tm_sec: ::c_int,
        pub tm_min: ::c_int,
        pub tm_hour: ::c_int,
        pub tm_mday: ::c_int,
        pub tm_mon: ::c_int,
        pub tm_year: ::c_int,
        pub tm_wday: ::c_int,
        pub tm_yday: ::c_int,
        pub tm_isdst: ::c_int,
        pub tm_gmtoff: ::c_long,
        pub tm_zone: *const ::c_char,
    }

    pub struct sched_param {
        pub sched_priority: ::c_int,
        pub sched_ss_low_priority: ::c_int,
        pub sched_ss_repl_period: ::timespec,
        pub sched_ss_init_budget: ::timespec,
        pub sched_ss_max_repl: ::c_int,
    }

    pub struct Dl_info {
        pub dli_fname: *const ::c_char,
        pub dli_fbase: *mut ::c_void,
        pub dli_sname: *const ::c_char,
        pub dli_saddr: *mut ::c_void,
    }

    pub struct epoll_event {
        pub events: u32,
        pub u64: u64,
    }

    pub struct lconv {
        pub decimal_point: *mut ::c_char,
        pub thousands_sep: *mut ::c_char,
        pub grouping: *mut ::c_char,
        pub int_curr_symbol: *mut ::c_char,
        pub currency_symbol: *mut ::c_char,
        pub mon_decimal_point: *mut ::c_char,
        pub mon_thousands_sep: *mut ::c_char,
        pub mon_grouping: *mut ::c_char,
        pub positive_sign: *mut ::c_char,
        pub negative_sign: *mut ::c_char,
        pub int_frac_digits: ::c_char,
        pub frac_digits: ::c_char,
        pub p_cs_precedes: ::c_char,
        pub p_sep_by_space: ::c_char,
        pub n_cs_precedes: ::c_char,
        pub n_sep_by_space: ::c_char,
        pub p_sign_posn: ::c_char,
        pub n_sign_posn: ::c_char,
        pub int_p_cs_precedes: ::c_char,
        pub int_p_sep_by_space: ::c_char,
        pub int_n_cs_precedes: ::c_char,
        pub int_n_sep_by_space: ::c_char,
        pub int_p_sign_posn: ::c_char,
        pub int_n_sign_posn: ::c_char,
    }

    pub struct rlimit64 {
        pub rlim_cur: rlim64_t,
        pub rlim_max: rlim64_t,
    }

    pub struct glob_t {
        pub gl_pathc: ::size_t,
        pub gl_pathv: *mut *mut c_char,
        pub gl_offs: ::size_t,
        pub gl_flags: ::c_int,

        __unused1: *mut ::c_void,
        __unused2: *mut ::c_void,
        __unused3: *mut ::c_void,
        __unused4: *mut ::c_void,
        __unused5: *mut ::c_void,
    }

    pub struct ifaddrs {
        pub ifa_next: *mut ifaddrs,
        pub ifa_name: *mut c_char,
        pub ifa_flags: ::c_uint,
        pub ifa_addr: *mut ::sockaddr,
        pub ifa_netmask: *mut ::sockaddr,
        pub ifa_ifu: *mut ::sockaddr, // FIXME This should be a union
        pub ifa_data: *mut ::c_void
    }

    pub struct passwd {
        pub pw_name: *mut ::c_char,
        pub pw_passwd: *mut ::c_char,
        pub pw_uid: ::uid_t,
        pub pw_gid: ::gid_t,
        pub pw_gecos: *mut ::c_char,
        pub pw_dir: *mut ::c_char,
        pub pw_shell: *mut ::c_char,
    }

    pub struct spwd {
        pub sp_namp: *mut ::c_char,
        pub sp_pwdp: *mut ::c_char,
        pub sp_lstchg: ::c_long,
        pub sp_min: ::c_long,
        pub sp_max: ::c_long,
        pub sp_warn: ::c_long,
        pub sp_inact: ::c_long,
        pub sp_expire: ::c_long,
        pub sp_flag: ::c_ulong,
    }

    pub struct statvfs {
        pub f_bsize: ::c_ulong,
        pub f_frsize: ::c_ulong,
        pub f_blocks: ::fsblkcnt_t,
        pub f_bfree: ::fsblkcnt_t,
        pub f_bavail: ::fsblkcnt_t,
        pub f_files: ::fsfilcnt_t,
        pub f_ffree: ::fsfilcnt_t,
        pub f_favail: ::fsfilcnt_t,
        #[cfg(target_endian = "little")]
        pub f_fsid: ::c_ulong,
        #[cfg(all(target_pointer_width = "32", not(target_arch = "x86_64")))]
        __f_unused: ::c_int,
        #[cfg(target_endian = "big")]
        pub f_fsid: ::c_ulong,
        pub f_flag: ::c_ulong,
        pub f_namemax: ::c_ulong,
        __f_spare: [::c_int; 6],
    }

    pub struct dqblk {
        pub dqb_bhardlimit: u64,
        pub dqb_bsoftlimit: u64,
        pub dqb_curspace: u64,
        pub dqb_ihardlimit: u64,
        pub dqb_isoftlimit: u64,
        pub dqb_curinodes: u64,
        pub dqb_btime: u64,
        pub dqb_itime: u64,
        pub dqb_valid: u32,
    }

    pub struct signalfd_siginfo {
        pub ssi_signo: u32,
        pub ssi_errno: i32,
        pub ssi_code: i32,
        pub ssi_pid: u32,
        pub ssi_uid: u32,
        pub ssi_fd: i32,
        pub ssi_tid: u32,
        pub ssi_band: u32,
        pub ssi_overrun: u32,
        pub ssi_trapno: u32,
        pub ssi_status: i32,
        pub ssi_int: i32,
        pub ssi_ptr: u64,
        pub ssi_utime: u64,
        pub ssi_stime: u64,
        pub ssi_addr: u64,
        pub ssi_addr_lsb: u16,
        _pad2: u16,
        pub ssi_syscall: i32,
        pub ssi_call_addr: u64,
        pub ssi_arch: u32,
        _pad: [u8; 28],
    }

    pub struct itimerspec {
        pub it_interval: ::timespec,
        pub it_value: ::timespec,
    }

    pub struct fsid_t {
        __val: [::c_int; 2],
    }

    pub struct cpu_set_t {
        #[cfg(all(target_pointer_width = "32",
                  not(target_arch = "x86_64")))]
        bits: [u32; 32],
        #[cfg(not(all(target_pointer_width = "32",
                      not(target_arch = "x86_64"))))]
        bits: [u64; 16],
    }

    pub struct if_nameindex {
        pub if_index: ::c_uint,
        pub if_name: *mut ::c_char,
    }

    // System V IPC
    pub struct msginfo {
        pub msgpool: ::c_int,
        pub msgmap: ::c_int,
        pub msgmax: ::c_int,
        pub msgmnb: ::c_int,
        pub msgmni: ::c_int,
        pub msgssz: ::c_int,
        pub msgtql: ::c_int,
        pub msgseg: ::c_ushort,
    }

    pub struct mmsghdr {
        pub msg_hdr: ::msghdr,
        pub msg_len: ::c_uint,
    }

    pub struct sembuf {
        pub sem_num: ::c_ushort,
        pub sem_op: ::c_short,
        pub sem_flg: ::c_short,
    }

    pub struct input_event {
        pub time: ::timeval,
        pub type_: ::__u16,
        pub code: ::__u16,
        pub value: ::__s32,
    }

    pub struct input_id {
        pub bustype: ::
        pub value: ut_ sfsffFdr,
 
        pub bustype: ::
rs            pub buvalue: ::__s32,
    }

 avfs
    pub struct ms:__u16,
        pub _hdr: ::minim {
          pub _hdr: ::maxim {
          pub _hdr: ::fuzz
          pub _hdr: ::flat
          pub _hdr: ::treamut              pub value: ::__s32,
    }

 keyint   try  pub struct star,
     long  pub l_len: ::en    long  pub l_len: :ex {
         pub bustype: :key:__u16,
     pub ssi_syscallcan:__u16[  long]
        bvalue: ::__s32,
    }

 
   b struct input_emeval,
      pub ssi_syscal:__uslong,
        pub ssi_syscal:__usl32,
      ,
        pub u64: u64,
  ff    pay  pub struct st_int,
         pub bustype: :delt,
        pub buvalue: ::__s32,
      rig

    pub struct lbutt           pub buposn: ::c_c{
            pub buvalue: ::__s32,
     envelop   pub struct wiatly *__int,
         pub bustype: :atly *__ivel         pub bustype: :fade__int,
         pub bustype: :fade__ivel         pub buvalue: ::__s32,
         pab feffect  pub struct st_ivel      s  pub bustype: :envelop :    envelop         pub u64: u64,
  ff  ampfeffect  pub struct sthort,__ivel      s  pub bustype: :end__ivel      s  pub bustype: :envelop :    envelop         pub u64: u64,
  ff    p funcfeffect  pub struct st that_s  }
ati           pub buposn: ::left_s  }
ati           pupub struct st that_coe
       s  pub bustype: :left_coe
       s  puub bustype: :dead32,
  
        pub type_: ::e_c{
      s  pub bu  pub u64: u64,
  ff   pub icfeffect  pub struct stwaveccor    pub value: ut_ sfsff pub schepub value: ut_ sfsfmagnitu_u16,
  s  pub bustype: :_t,
    ,
  s  pub bustype: :ph,
          pupub struct stenvelop :    envelop   mbol: *mut ::c_stom_:en    lon  pub ssi_syscal:_stom_ion
        p  s  pub bu  pub u64: u64,
  ff rumblefeffect  pub struct sthopes?_magnitu_u16,
  b value: ut_ sfsfweak_magnitu_u16,
  b value: value: ::__s32,
     effect  pub struct stimeval,
        pub type_: :id  ,
  s  pub bustype: :directi           pub buposn: :: rig

 :     rig

   pub _hdr: ::trplt,
 ff    payally very res*mut :tI for taigval {
       my4: [::c_char; 24],
        #[cfg(target_pointer_widvents4"))))]
dummy4: [::c_char; 24],
        #[cfg(target_pointer_widvents4"))))]
7f_spare: [::c_int; 6],
   l_ph   pu    pub struc_char; 24],
        #[cfg(target_pointer_widventdlp u64,
  Off = u64;mmy4: [::c_char; 24],
        #[cfg(target_pointer_widventdlp u64,
  Off = u32;puub bustype: :dlp ud,
        pub dli_snampub struc_char; 24],
        #[cfg(target_pointer_widventdlp upr {
      puOff = Ph4;mmy4: [::c_char; 24],
        #[cfg(target_pointer_widventdlp upr {
      puOff = Ph4;mmpub struc_char; 24],
        #[cfg(target_pointer_widventdlp uprf {
 dr = u32;
mmy4: [::c_char; 24],
        #[cfg(target_pointer_widventdlp uprf {
 dr c_int;
puub bustype: :dlp u64,s:g;
pub type rl,ub bustype: :dlp usubs:g;
pub type rl,ub bustype: :dlp utlsno_tid  ,
     pub gl_offs: ::dlp utlsnion
        pub ifa_spare: [::c_int; 6],
  Off = Ph4; pub struct protoid {
 alf = u16;p_by_space: ::c__t,
    ord = u32p_by_space: ::c_v64,
  Off = u32;pu*mut *mut ::c_c64,
  Off = u32;pu*mut *mut ::c_nt_t,z
 alf = u16;p_by_space: ::c_mem,z
 alf = u16;p_by_space: ::c_ar,
   alf = u16;p_by_space: ::c_       alf = u16;p_by_s: [::c_int; 6],
  Off = Ph4; pub struct protoid {
 alf = u16;p_by_space: ::c_ar,
   alf = u16;p_by_space: ::c__t,
    ord = u32p_by_space: ::c_v64,
  Off = u64;mmy4: [::ct ::c_c64,
  Off = u64;mmy4: [::ct ::c_nt_t,z
 alf = u64;
p_by_space: ::c_mem,z
 alf = u64;
p_by_space: ::c_       alf = u64;
p_by_slag: ::c_ulong,
    }
fs   pub struct rliflock {
      pub f_frsize: ::c_ulng,
        pub f_frsize: ::c_ulong,
        pub f_blocks: ::fsblkcnt_t,
        pub f_bfree: ::fsblkcnt_t,
        pub f_bavail: ::fsblkcnt_t,
        pub f_files: ::fsfilcnt_t,
        pub f_ffree: ::fsfilcng")]
    }

 ub f_flag: ::c_ulongdr,
        pub f_bsize: ::c_ulong,
        pub f_frsize: ::c_uar,
         pub f_frsize: ::c_u_ulong,
         fd4]b sp_flag: ::c_ulong,
    }

     pub struct rliflvfs {
        pub f_bsize: ::c_ulong,
        pub f_frsize: ::c_ulong,
   pub ssi_call_addkcnt_t,
  pub ssi_call_addkcnt_t,
   pub ssi_call_addkcnt_t,
  pub ssi_call_addkcnt_t,
  pub ssi_call_addkcft_t,
   pub ssi_call_addkcng")]
        pub f_fsid: ::c_ulong,
        pub f_flag: ::c_ulong,
        pub f_namemax: ::c_ulong,
        __f_spare: [::c_int; 6],
  lly *
    pub struct gsslop       pub dli_fbase: *mut ::sslt_t,
        pub sa_flags: ::slong,
        p_data: *mut ::c_void
   _t = u3 struct pthread_c__t {
    ))]
7] pub dqb_valid: u32,
    }
    pub struct ct fsid_t {
     fd_dummy4: [::c_char; 16],
   hm}

d   pub struct st hm {
       rm {
  ,pub struct st hm segnt,
       pub gl_offs: :: hm t_t,
        pub st_atime: ::thm d_t,
        pub st_atime: ::thm c_t,
        pub st_atime: ::thm cucred {
        pub pid: :thm lucred {
        pub pid: :thm n stch       pub f_namemax: :lksize_t,
 pub f_namemax: :lks2
        pub sp_flag: ::c_ulong,
  msq}

d   pub struct stmsgh{
       rm {
  ,pub struct stmsghs_t,
        pub st_atime: ::msghr_t,
        pub st_atime: ::msghc_t,
        pub st_atime__msghcd,
            pub f_flag: ::cmsghqf {
   ::c_ulongub f_flag: ::cmsghqd,
      ::c_ulonub msg_hdr: ::msghdsucred {
        pub pid: :msghdrucred {
        pub pi :lksize_t,
 pub f_namemax: :lks2
        pub sp_flag: ::c_ulong,
    }
fs pub struct rliflock {
      pub f_frsize: ::c_ulng,
        pub f_frsize: ::c_ulong,
        pub f_blocks: ::fsblkcnt_t,
        pub f_bfree: ::fsblkcnt_t,
        pub f_bavail: ::fsblkcnt_t,
        pub f_files: ::fsfilcnt_t,
        pub f_ffree: ::fsfilcng")]
    }

 ub f_flag: ::c_ulongdr,
        pub f_bsize: ::c_ulong,
        pub f_frsize: ::c_uar,
         pub f_frsize: ::c_u_ulong,
         fd4]b sp_flag: ::c_ulong,
   }

    pub struct mmsghdint,
        pudli_fbase: *mut ::sghdint,id,
       pub ai_ase: *mut ::sghdio_void,
     }

i_ase: *mut ::sghdio_dr,
     
        __err:lksize_t,
        __pad1: :msghcontr   pub currendli_fbase: *mut ::sghdcontr  id,
       pub ai_ase: *mu :lks2
       pub ai_ase: *mut ::sghdt_t,
        pub sa_: [::c_int; 2],
    }

    pub struct mmcmsghdr,
       pub ai_ase: *mut ::r:lksize_t,
        __pad1: :cmsghdrvelze_t,
        __pad1: :cmsgh
        pub ai_soc_len: ::c_uint,
    }
    pub struct fsid_t {
     8ummy4: [::c_char; 16],
    }pu  
    pub struct gsnfo {
         pub sa_flags: :: u32,
         pub sa_flags: :: u      pub aio_lio_opcode: :_arch: t {
      9 __lock: [::       [ub typ 0]:Option<extern fn()>,
    }

  2  pub struct termios {
        pub c_iflag: ::tcflag_t,
        pub c_oflag: ::tcflag_t,
        pub c_cflag: ::tcflag_t,
        pub c_lflag: ::tcflag_t,
        pub c_line: ::cc_t,
       19]  pub c_line: ::S],
        pub __c_ispeed: ::sed_t,
        pub __c_ospeed: ::speed_t,
  ily_tkts
    pub struct msipiu32,
        pub sin6_addr: ::inipiu3rt,
        p   pub msg_leed
        }

        s_no_ar; 16],
   yfs
    pub struct msup,
          pub f_frsize: ::cloadet {
        fd3]  pub c_line: totalram        pub f_frsize: ::c__t,ram        pub f_frsize: ::cshlondram        pub f_frsize: ::cbuff32,am        pub f_frsize: ::ctotal32,
        pub f_frsize: ::c__t,32,
        pub f_frsize: ::cprocs
        pub sem_num: ::c_arch:       pub sem_num: ::c_totalhigh        pub f_frsize: ::c__t,high        pub f_frsize: ::cng,_unit        pub if_index: ::r: :  }

d")]
        __56pub sin_zero: [u8; 8],
    }

    uub struct sockaddu_in {
        pub sin_family: sa_famu_ie_t,
        pub s0l_addr: [::c_uchar; 8]
    }

    t,
 

    pub struct rsslt {
        pub sin_family: s_c,
 lks2
       28 - 2 - 8]_family: s_c,
               pub iov_len: ::size_t,
  utid,
    pub struct rsyid,
          pub 65]  pub c_line:     d,
          pub 65]  pub c_line: r,id,
          pub 65]  pub c_line: :
rs            pub 65]  pub c_line: machg_t,
       pub 65]  pub c_line: doe/fud,
          pub 65]spare: [::c_int; 6],
   ir pub struct input_dev_t,
        pub st_ino: :d_,
            pub l_len: :d: :cdr,
        pub sem_num: ::c_d_
        pub sll_pkttype: ::cd_d,
          pub _56pub sin_zero: [u8; 8],
   ir pu   pub struct rlidev_t,
       pub rlim_cur: rld_,
          pub rlim_cur: rld_ :cdr,
        pub sem_num: ::c_d_
        pub sll_pkttype: ::cd_d,
          pub _56pub sin_zero: // x32/! De_titypetymut ::c_ceeng,
    }From hwlon.org/bugzilla/  pw_bug.cgi?id=21279g: ::c_ulong,
   q3 strpub struct cpu_set_t {
        #[cfg(all(target_arch = "x86_64", target_pointer_widtne: mqdt_t,
  ipub ssi_callcpu_set_t {
        #[cfg(all(target_arch = "x86_64", target_pointer_widtne: mqdmaxmsg  ipub ssi_callcpu_set_t {
        #[cfg(all(target_arch = "x86_64", target_pointer_widtne: mqdmsgng,
  ipub ssi_callcpu_set_t {
        #[cfg(all(target_arch = "x86_64", target_pointer_widtne: mqdcurmsgn  ipub ssi_callcpu_set_t {
        #[cfg(all(target_arch = "x86_64", target_pointer_widtnrch: i))]
dumm    bits: [u32; 32],
        #   #[cfg(all(target_arch = "x86_64", target_poointer_widtne: mqdt_t,
       pub sp_expire [u32; 32],
        #   #[cfg(all(target_arch = "x86_64", target_poointer_widtne: mqdmaxmsg       pub sp_expire [u32; 32],
        #   #[cfg(all(target_arch = "x86_64", target_poointer_widtne: mqdmsgng,
       pub sp_expire [u32; 32],
        #   #[cfg(all(target_arch = "x86_64", target_poointer_widtne: mqdcurmsgn       pub sp_expire [u32; 32],
        #   #[cfg(all(target_arch = "x86_64", target_poointer_widtnrch: t {
    fd4]b sp_flag: ::c_ulong,
    }

    nub struct sockadn_ll {
          pub sin_family: snl_arch:       pub sem_num: ::c_nli32,
        pub ssi_pinliar,
  {
   my4: [::c_char; 16],
    }   pub struct input_  }  spec,
      }

 ,struct input_  }  so {
         pub sa_flags: :: }  s 32ify        pub sa_flags: :: }  s 32ify_ and rus:rer:    }

 )ub sa_flags: :: }  s 32ify_ stribut
         _t = u3 struci_ase: *mut ::r:lks         pub 56 - 3 * 8 /* 8 == ::c_of(    ) */]ub msg_leed
        }

  g_if! {
            if #[cfg(feature = "extra_ }

                yfs
    pub struclone fo                 f yfs
  r: &pthread_rwlock_t) -> boo     up,
   ==       up,
  ointer_width = "32",
&&o     loade ==       loadeointer_width = "32",
&&o     totalram ==       totalramointer_width = "32",
&&o     __t,ram ==       __t,ramointer_width = "32",
&&o     shlondram ==       shlondramointer_width = "32",
&&o     buff32,am ==       buff32,amointer_width = "32",
&&o     total32,
 ==       total32,
ointer_width = "32",
&&o     __t,32,
 ==       __t,32,
ointer_width = "32",
&&o     procs ==       procsointer_width = "32",
&&o     pad ==       padointer_width = "32",
&&o     totalhigh ==       totalhighointer_width = "32",
&&o     __t,high ==       __t,highointer_width = "32",
&&o     ng,_unit ==       ng,_unitointer_width = "32",
&&o    lf, state: &mut H) {
    .r: :  }

dlf, state: &mut H) {
    .                   .iter()
               r: :  }

d     .zip(other.size.iter())
                        .all(|(a,b)|       }
        tra_ }

         yfs
          tra_ }

                im yfs
    pub struclone fo                 fn fmt(&self, f: &mut ::fmt::Formatter) -> ::fmt::Resul                 yfs
  ct("pthread_rwlock_t")
        up,
   FIXME: .up,
  t("pthread_rwlock_t")
        loade FIXME: .loadet("pthread_rwlock_t")
        totalram FIXME: .totalramt("pthread_rwlock_t")
        __t,ram FIXME: .__t,ramt("pthread_rwlock_t")
        shlondram FIXME: .fhlondramt("pthread_rwlock_t")
        buff32,am FIXME: .buff32,amt("pthread_rwlock_t")
        total32,
 FIXME: .total32,
t("pthread_rwlock_t")
        __t,32,
 FIXME: .__t,32,
t("pthread_rwlock_t")
        procs FIXME: .procst("pthread_rwlock_t")
        pad FIXME: .padt("pthread_rwlock_t")
        totalhigh FIXME: .totalhight("pthread_rwlock_t")
        __t,high FIXME: .__t,hight("pthread_rwlock_t")
        ng,_unit FIXME: .ng,_unitt("pthread_rwlock_t")
                  r: :  }

d FIXME: .r: :  }

dt("pthread_rwlock_t")
                    .f      }
        tra_ }

                im yfs
    pub struclone fo                 fn hash<H: ::hash::Hasher>(&self, state: &mut HME: .up,
             self.size.hash(statME: .loade           self.size.hash(statME: .totalram           self.size.hash(statME: .__t,ram           self.size.hash(statME: .fhlondram           self.size.hash(statME: .buff32,am           self.size.hash(statME: .total32,
           self.size.hash(statME: .__t,32,
           self.size.hash(statME: .procs           self.size.hash(statME: .pad           self.size.hash(statME: .totalhigh           self.size.hash(statME: .__t,high           self.size.hash(statME: .ng,_unit           self.size.hash(statME: .r: :  }

d           self.size.hash(OND_T],
            } }

                 }

    uub struct solone fo                 f  }

    uur: &pthread_rwlock_t) -> boo     du_in {
   ==       su_in {
  ointer_width = "32",
&&o    lf, state: &mut H) {
.mu_ie_t,
tate: &mut H) {
    .                   .iter()
            u_ie_t,     .zip(other.size.iter())
                    .all(|(a,b)|       }
        tra_ }

          }

    uub       tra_ }

                im  }

    uub struct solone fo                 fn fmt(&self, f: &mut ::fmt::Formatter) -> ::fmt::Resul                  }

    uuct("pthread_rwlock_t")
        su_in {
   FIXME: .fu_in {
  t("pthread_rwlock_t")
                   u_ie_t, FIXME: .fu_ie_t,t("pthread_rwlock_t")
                    .f      }
        tra_ }

                im  }

    uub struct solone fo                 fn hash<H: ::hash::Hasher>(&self, state: &mut HME: .fu_in {
             self.size.hash(statME: .fu_ie_t,           self.size.hash(OND_T],
            } }

                 }

    t,
 

    pub strulone fo                 f  }

    t,
 

 r: &pthread_rwlock_t) -> boo     dsin {
   ==       ssin {
  ointer_width = "32",
&&o    ._c,
       ==       _c,
      ointer_width = "32",
&&o    lf, state: &mut H) {
._c,
 lks2
tate: &mut H) {
    .                   .iter()
           _c,
 lks2     .zip(other.size.iter())
                     .all(|(a,b)|       }
        tra_ }

          }

    t,
 

         tra_ }

                im  }

    t,
 

    pub strulone fo                 fn fmt(&self, f: &mut ::fmt::Formatter) -> ::fmt::Resul                  }

    t,
 

 ct("pthread_rwlock_t")
        ssin {
   FIXME: .fsin {
  t("pthread_rwlock_t")
        r:,
       FIXME: .r:,
      t("pthread_rwlock_t")
                  r:,
 lks2 FIXME: .r:,
 lks2t("pthread_rwlock_t")
                    .f      }
        tra_ }

                im  }

    t,
 

    pub strulone fo                 fn hash<H: ::hash::Hasher>(&self, state: &mut HME: .fsin {
             self.size.hash(statME: .r:,
                 self.size.hash(statME: .r:,
 lks2           self.size.hash(OND_T],
            } }

               utid,
    pub strulone fo                 futid,
 r: &pthread_rwlock_t) -> boo     dyid,
 
tate: &mut H) {
    .                   .iter()
            yid,
      .zip(other.size.iter())
                    .all(|(a,b)| = "32",
&&o    lf, state: &mut H) {
.    d,
 
tate: &mut H) {
    .                   .iter()
               d,
      .zip(other.size.iter())
                    .all(|(a,b)| = "32",
&&o    lf, state: &mut H) {
.r,id,
 
tate: &mut H) {
    .                   .iter()
           r,id,
      .zip(other.size.iter())
                    .all(|(a,b)| = "32",
&&o    lf, state: &mut H) {
.:
rs   
tate: &mut H) {
    .                   .iter()
           :
rs        .zip(other.size.iter())
                    .all(|(a,b)| = "32",
&&o    lf, state: &mut H) {
.machg_t
tate: &mut H) {
    .                   .iter()
           machg_t     .zip(other.size.iter())
                    .all(|(a,b)|       }
        tra_ }

        utid,
         tra_ }

                imutid,
    pub strulone fo                 fn fmt(&self, f: &mut ::fmt::Formatter) -> ::fmt::Resul                utid,
 "t("pthread_rwlock_t")
                   yid,
  FIXME: .fyid,
 t("pthread_rwlock_t")
                      d,
  FIXME: .    d,
 t("pthread_rwlock_t")
                  r,id,
  FIXME: .r,id,
 t("pthread_rwlock_t")
                  :
rs    FIXME: .:
rs   t("pthread_rwlock_t")
                  machg_t FIXME: .nachg_tt("pthread_rwlock_t")
                    .f      }
        tra_ }

                imutid,
    pub strulone fo                 fn hash<H: ::hash::Hasher>(&self, state: &mut HME: .fyid,
            self.size.hash(statME: .    d,
            self.size.hash(statME: .r,id,
            self.size.hash(statME: .:
rs              self.size.hash(statME: .nachg_t           self.size.hash(OND_T],
            } }

                ir pub struct inlone fo                 f ir pur: &pthread_rwlock_t) -> boo     dev_t ==       dev_tointer_width = "32",
&&o    .d_,
  ==       de,
 ointer_width = "32",
&&o    .d_ :cdr, ==       de :cdr,ointer_width = "32",
&&o    .d_e c_l==       dee c_.all(|(a,b)| = "32",
&&o    lf, state: &mut H) {
.d_d,
 
tate: &mut H) {
    .                   .iter()
           d_d,
      .zip(other.size.iter())
                    .all(|(a,b)|       }
        tra_ }

         ir pub       tra_ }

                im ir pub struct inlone fo                 fn fmt(&self, f: &mut ::fmt::Formatter) -> ::fmt::Resul                 ir puct("pthread_rwlock_t")
        dev_t FIXME: .dev_tt("pthread_rwlock_t")
        de,
  FIXME: .de,
 t("pthread_rwlock_t")
        de :cdr, FIXME: .de :cdr,t("pthread_rwlock_t")
        dee c_ FIXME: .dee c_t("pthread_rwlock_t")
                  d_d,
  FIXME: .ded,
 t("pthread_rwlock_t")
                    .f      }
        tra_ }

                im ir pub struct inlone fo                 fn hash<H: ::hash::Hasher>(&self, state: &mut HME: .dev_t           self.size.hash(statME: .de,
            self.size.hash(statME: .de :cdr,           self.size.hash(statME: .dee c_           self.size.hash(statME: .ded,
            self.size.hash(OND_T],
            } }

                ir pu   pub structlone fo                 f ir pu64r: &pthread_rwlock_t) -> boo     dev_t ==       dev_tointer_width = "32",
&&o    .d_,
  ==       de,
 ointer_width = "32",
&&o    .d_ :cdr, ==       de :cdr,ointer_width = "32",
&&o    .d_e c_l==       dee c_.all(|(a,b)| = "32",
&&o    lf, state: &mut H) {
.d_d,
 
tate: &mut H) {
    .                   .iter()
           d_d,
      .zip(other.size.iter())
                    .all(|(a,b)|       }
        tra_ }

         ir pu   p      tra_ }

                im ir pu   pub structlone fo                 fn fmt(&self, f: &mut ::fmt::Formatter) -> ::fmt::Resul                 ir puet_p("pthread_rwlock_t")
        dev_t FIXME: .dev_tt("pthread_rwlock_t")
        de,
  FIXME: .de,
 t("pthread_rwlock_t")
        de :cdr, FIXME: .de :cdr,t("pthread_rwlock_t")
        dee c_ FIXME: .dee c_t("pthread_rwlock_t")
                  d_d,
  FIXME: .ded,
 t("pthread_rwlock_t")
                    .f      }
        tra_ }

                im ir pu   pub structlone fo                 fn hash<H: ::hash::Hasher>(&self, state: &mut HME: .dev_t           self.size.hash(statME: .de,
            self.size.hash(statME: .de :cdr,           self.size.hash(statME: .dee c_           self.size.hash(statME: .ded,
            self.size.hash(OND_T],
            } }

                q3 strpub struct lone fo                 f q3 strr: &pthread_rwlock_t) -> boo     mqdt_t,
 ==       nqdt_t,
 &&_rwlock_t) -> boo     mqdmaxmsg ==       nqdmaxmsg &&_rwlock_t) -> boo     mqdmsgng,
 ==       nqdmsgng,
 &&_rwlock_t) -> boo     mqdcurmsgn ==       nqdcurmsgn.all(|(a,b)|       }
        tra_ }

         q3 strpu      tra_ }

                im q3 strpub struct lone fo                 fn fmt(&self, f: &mut ::fmt::Formatter) -> ::fmt::Resul                 q3 str_p("pthread_rwlock_t")
        nqdt_t,
 FIXME: .nqdt_t,
p("pthread_rwlock_t")
        nqdmaxmsg FIXME: .nqdmaxmsgp("pthread_rwlock_t")
        nqdmsgng,
 FIXME: .nqdmsgng,
p("pthread_rwlock_t")
        nqdcurmsgn FIXME: .nqdcurmsgnt("pthread_rwlock_t")
                    .f      }
        tra_ }

                im q3 strpub struct lone fo                 fn hash<H: ::hash::Hasher>(&self, state: &mut HME: .nqdt_t,
           self.size.hash(statME: .nqdmaxmsg           self.size.hash(statME: .nqdmsgng,
           self.size.hash(statME: .nqdcurmsgn           self.size.hash(OND_T],
            } }

                 }

    nl   pub strulone fo                 f  }

    nlr: &pthread_rwlock_t) -> boo     n_ll {
   ==       n_ll {
   &&_rwlock_t) -> boo     nli32, ==       n_l32, &&_rwlock_t) -> boo     nliar,
   ==       n_lar,
  .all(|(a,b)|       }
        tra_ }

          }

    nl        tra_ }

                im  }

    nl   pub strulone fo                 fn fmt(&self, f: &mut ::fmt::Formatter) -> ::fmt::Resul                  }

    nl_p("pthread_rwlock_t")
        n_ll {
   FIXME: . lin {
  t("pthread_rwlock_t")
        n_l32, FIXME: . li32,t("pthread_rwlock_t")
        n_lar,
   FIXME: . liar,
  t("pthread_rwlock_t")
                    .f      }
        tra_ }

                im  }

    nl   pub strulone fo                 fn hash<H: ::hash::Hasher>(&self, state: &mut HME: . lin {
             self.size.hash(statME: . li32,           self.size.hash(statME: . liar,
             self.size.hash(OND_T],
            } }

                 }   pub struct inlone fo                 f  }   pur: &pthread_rwlock_t) -> boo     d }  spec,
 ==       s }  spec,
ointer_width = "32",
&&o     s }  so {
  ==       s }  so {
 ointer_width = "32",
&&o     s }  s 32ify ==       s }  s 32ifyointer_width = "32",
&&o     s }  s 32ify_ and rusp(other.size.iter())
    ==       s }  s 32ify_ and rusp(other.size.iter())
&&o     s }  s 32ify_ stribut
 p(other.size.iter())
    ==       s }  s 32ify_ stribut
 p(other.size.      }
        tra_ }

          }   pub       tra_ }

                im  }   pub struct inlone fo                 fn fmt(&self, f: &mut ::fmt::Formatter) -> ::fmt::Resul                  }   puct("pthread_rwlock_t")
        s }  spec,
 FIXME: .f }  spec,
t("pthread_rwlock_t")
        s }  so {
  FIXME: .f }  so {
 t("pthread_rwlock_t")
        s }  s 32ify FIXME: .f }  s 32ifyt("pthread_rwlock_t")
        s }  s 32ify_ and rus FIXME: .f }  s 32ify_ and rust("pthread_rwlock_t")
        s }  s 32ify_ stribut
 _pointer_width = "32",
  r())
&     s }  s 32ify_ stribut
 t("pthread_rwlock_t")
                    .f      }
        tra_ }

                im  }   pub struct inlone fo                 fn hash<H: ::hash::Hasher>(&self, state: &mut HME: .f }  spec,
           self.size.hash(statME: .f }  so {
            self.size.hash(statME: .f }  s 32ify           self.size.hash(statME: .f }  s 32ify_ and rus           self.size.hash(statME: .f }  s 32ify_ stribut
            self.size.hash(OND_T],
    ,
          PUB_CONST

scal:_  puINT_MIN:     p = -2147483648;
scal:_  puINT_MAX:     p = 2147483647;

scal:_  puSIG_DFL: pub sa_sigac = 0 as pub sa_sigac;
scal:_  puSIG_IGN: pub sa_sigac = 1 as pub sa_sigac;
scal:_  puSIG_ERR: pub sa_sigac = !0 as pub sa_sigac;

scal:_  puDT_UNKNOWN: u8 = 0;
scal:_  puDT_FIFO: u8 = 1;
scal:_  puDT_CHR: u8 = 2;
scal:_  puDT_DIR: u8 = 4;
scal:_  puDT_BLK: u8 = 6;
scal:_  puDT_REG: u8 = 8;
scal:_  puDT_LNK: u8 = 10;
scal:_  puDT_SOCK: u8 = 12;

scal:_  puFD_CLOEXEC        p = 0x1;

scal:_  puUSRQUOTA        p = 0;
scal:_  puGRPQUOTA        p = 1;

scal:_  puSIGIOT        p = 6;

scal:_  puS_ISUID        p = 0x800;
scal:_  puS_ISGID        p = 0x400;
scal:_  puS_ISVTX        p = 0x200;

scal:_  puIF_NAME FD_         p = 16;
scal:_  puIFNAM FD         p = IF_NAME FD_;

scal:_  puLOG_EMERG        p = 0;
scal:_  puLOG_ALERT        p = 1;
scal:_  puLOG_CRIT        p = 2;
scal:_  puLOG_ERR:       p = 3;
scal:_  puLOG_WARNING        p = 4;
scal:_  puLOG_NOTICE        p = 5;
scal:_  puLOG_INFO:       p = 6;
scal:_  puLOG_DEBUG        p = 7;

scal:_  puLOG_KERN        p = 0;
scal:_  puLOG_USER:       p = 1 << 3;
scal:_  puLOG_MAIL        p = 2 << 3;
scal:_  puLOG_DAEMON        p = 3 << 3;
scal:_  puLOG_AUTH        p = 4 << 3;
scal:_  puLOG_SYSLOG        p = 5 << 3;
scal:_  puLOG_LPR:       p = 6 << 3;
scal:_  puLOG_NEWS        p = 7 << 3;
scal:_  puLOG_UUCP        p = 8 << 3;
scal:_  puLOG_LOCAL0:       p = 16 << 3;
scal:_  puLOG_LOCAL1:       p = 17 << 3;
scal:_  puLOG_LOCAL2:       p = 18 << 3;
scal:_  puLOG_LOCAL3:       p = 19 << 3;
scal:_  puLOG_LOCAL4        p = 20 << 3;
scal:_  puLOG_LOCAL5        p = 21 << 3;
scal:_  puLOG_LOCAL6        p = 22 << 3;
scal:_  puLOG_LOCAL7        p = 23 << 3;

scal:_  puLOG_PID        p = 0x01;
scal:_  puLOG_CONS        p = 0x02;
scal:_  puLOG_ODELAY        p = 0x04;
scal:_  puLOG_NDELAY        p = 0x08;
scal:_  puLOG_NOWAIT        p = 0x10;

scal:_  puLOG_PRIMASK        p = 7;
scal:_  puLOG_FACMASK        p = 0x3f8;

scal:_  puPRIO_PROCESS        p = 0;
scal:_  puPRIO_PGRP        p = 1;
scal:_  puPRIO_USER:       p = 2;

scal:_  puPRIO_MIN:       p = -20;
scal:_  puPRIO_MAX:       p = 20;

scal:_  puIPPROTO_ICMP        p = 1;
scal:_  puIPPROTO_ICMPV6        p = 58;
scal:_  puIPPROTO_TCP        p = 6;
scal:_  puIPPROTO_UDP        p = 17;
scal:_  puIPPROTO_IP        p = 0;
scal:_  puIPPROTO_IPV6        p = 41;

scal:_  puINADDR_LOOPBACK:     pub_p = 2130706433;
scal:_  puINADDR_ANY:     pub_p = 0;
scal:_  puINADDR_BROADCAST:     pub_p = 4294967295;
scal:_  puINADDR_NONE:     pub_p = 4294967295;

scal:_  puEXIT_FAILURE        p = 1;
scal:_  puEXIT_SUCCESS        p = 0;
scal:_  puRAND_MAX:       p = 2147483647;
scal:_  puEOF:       p = -1;
scal:_  puSEEKbits        p = 0;
scal:_  puSEEKbCUR        p = 1;
scal:_  puSEEKbEND        p = 2;
scal:_  pu_IOFBF        p = 0;
scal:_  pu_IONBF        p = 2;
scal:_  pu_IOLBF        p = 1;

scal:_  puF_DUPFD        p = 0;
scal:_  puF_GETFD        p = 1;
scal:_  puF_SETFD        p = 2;
scal:_  puF_GETFL:       p = 3;
scal:_  puF_SETFL        p = 4;
    Linux-pub ific fcntls
scal:_  puF_SETLEASE        p = 1024;
scal:_  puF_GETLEASE        p = 1025;
scal:_  puF_NOTIFY        p = 1026;
scal:_  puF_CANCELLK        p = 1029;
scal:_  puF_DUPFD_CLOEXEC        p = 1030;
scal:_  puF_SETPIPE_SZ        p = 1031;
scal:_  puF_GETPIPE_SZ        p = 1032;
scal:_  puF_ADD_SEALS        p = 1033;
scal:_  puF_GET_SEALS        p = 1034;

scal:_  puF_SEAL_SEAL        p = 0x0001;
scal:_  puF_SEAL_SHRINK        p = 0x0002;
scal:_  puF_SEAL_GROW        p = 0x0004;
scal:_  puF_SEAL_WRITE        p = 0x0008;
         (#235): Include nt_ttMEaling fcntls once weo  v FIXway to :
rify them.

scal:_  puSIGTRAP        p = 5;

scal:_  puPTHREAD_CREATE_JOINABLE        p = 0;
scal:_  puPTHREAD_CREATE_DETACHED        p = 1;

scal:_  puCLOCK_REALTIME     ong,}

  = 0;
scal:_  puCLOCK_MONOTONIC     ong,}

  = 1;
scal:_  puCLOCK_PROCESS_CPUTIME_ID     ong,}

  = 2;
scal:_  puCLOCK_THREAD_CPUTIME_ID     ong,}

  = 3;
scal:_  puCLOCK_MONOTONIC_RAW     ong,}

  = 4;
scal:_  puCLOCK_REALTIME_COARSE     ong,}

  = 5;
scal:_  puCLOCK_MONOTONIC_COARSE     ong,}

  = 6;
scal:_  puCLOCK_BOOTTIME     ong,}

  = 7;
scal:_  puCLOCK_REALTIME_ALARM     ong,}

  = 8;
scal:_  puCLOCK_BOOTTIME_ALARM     ong,}

  = 9;
scal:_  puCLOCK_SGI_CYCLE     ong,}

  = 10;
scal:_  puCLOCK_TAI     ong,}

  = 11;
scal:_  puTIMER_ABSTIME        p = 1;

scal:_  puRLIMIT_CPU        p = 0;
scal:_  puRLIMIT_F FD_        p = 1;
scal:_  puRLIMIT_DATA        p = 2;
scal:_  puRLIMIT_STACK:       p = 3;
scal:_  puRLIMIT_CORE        p = 4;
scal:_  puRLIMIT_LOCKS        p = 10;
scal:_  puRLIMIT_SIGPENDING        p = 11;
scal:_  puRLIMIT_MSGQUEU_        p = 12;
scal:_  puRLIMIT_NICE        p = 13;
scal:_  puRLIMIT_RTPRIO        p = 14;

scal:_  puRUSAGE_SELF        p = 0;

scal:_  puO_RDONLY        p = 0;
scal:_  puO_WRONLY        p = 1;
scal:_  puO_RDWR:       p = 2;

scal:_  puS_IFIFO: ::mod  p = 4096;
scal:_  puS_IFCHR: ::mod  p = 8192;
scal:_  puS_IFBLK    mod  p = 24576;
scal:_  puS_IFDIR:   mod  p = 16384;
scal:_  puS_IFREG:   mod  p = 32768;
scal:_  puS_IFLNK: ::mod  p = 40960;
scal:_  puS_IFSOCK: ::mod  p = 49152;
scal:_  puS_IFMT: ::mod  p = 61440;
scal:_  puS_IRWXU: ::mod  p = 448;
scal:_  puS_IXUSR:   mod  p = 64;
scal:_  puS_IWUSR:   mod  p = 128;
scal:_  puS_IRUSR:   mod  p = 256;
scal:_  puS_IRWXG:   mod  p = 56;
scal:_  puS_IXGRP    mod  p = 8;
scal:_  puS_IWGRP    mod  p = 16;
scal:_  puS_IRGRP    mod  p = 32;
scal:_  puS_IRWXO: ::mod  p = 7;
scal:_  puS_IXOTH    mod  p = 1;
scal:_  puS_IWOTH    mod  p = 2;
scal:_  puS_IROTH    mod  p = 4;
scal:_  puF_OK        p = 0;
scal:_  puR_OK        p = 4;
scal:_  puW_OK        p = 2;
scal:_  puX_OK        p = 1;
scal:_  puSTDIN_FILENO        p = 0;
scal:_  puSTDOUT_FILENO        p = 1;
scal:_  puSTDERR_FILENO        p = 2;
scal:_  puSIGHUP        p = 1;
scal:_  puSIGINT        p = 2;
scal:_  puSIGQUIT        p = 3;
scal:_  puSIGILL        p = 4;
scal:_  puSIGABRT        p = 6;
scal:_  puSIGFPE        p = 8;
scal:_  puSIGKILL        p = 9;
scal:_  puSIGSEGV        p = 11;
scal:_  puSIGPIPE        p = 13;
scal:_  puSIGALRM        p = 14;
scal:_  puSIGTERM        p = 15;

scal:_  puPROT_NONE:       p = 0;
scal:_  puPROT_READ        p = 1;
scal:_  puPROT_WRITE        p = 2;
scal:_  puPROT_EXEC        p = 4;

scal:_  puLC_CTYPE:       p = 0;
scal:_  puLC_NUMERIC        p = 1;
scal:_  puLC_TIME        p = 2;
scal:_  puLC_COLLATE        p = 3;
scal:_  puLC_MONETARY        p = 4;
scal:_  puLC_MESSAGES        p = 5;
scal:_  puLC_ALL:       p = 6;
scal:_  puLC_CTYPE_MASK        p = 1 << LC_CTYPE;
scal:_  puLC_NUMERIC_MASK        p = 1 << LC_NUMERIC;
scal:_  puLC_TIME_MASK        p = 1 << LC_TIME;
scal:_  puLC_COLLATE_MASK        p = 1 << LC_COLLATE;
scal:_  puLC_MONETARY_MASK        p = 1 << LC_MONETARY;
scal:_  puLC_MESSAGES_MASK        p = 1 << LC_MESSAGES;    LC_ALL_MASK definedff p platccor

scal:_  puMAP_FILE        p = 0x0000;
scal:_  puMAP_SHARED        p = 0x0001;
scal:_  puMAP_PRIVATE        p = 0x0002;
scal:_  puMAP_FIXED        p = 0x0010;

scal:_  puMAP_FAILED pub currendli_ = !0 as ub currendli_;
    MS_tar,
    im sync(2)
scal:_  puMS_ASYNC        p = 0x0001;
scal:_  puMS_INVALIDATE        p = 0x0002;
scal:_  puMS_SYNC        p = 0x0004;
    MS_tar,
    im ount(2)
scal:_  puMS_RDONLY        pub = 0x01;
scal:_  puMS_NOSUID        pub = 0x02;
scal:_  puMS_NODEV        pub = 0x04;
scal:_  puMS_NOEXEC        pub = 0x08;
scal:_  puMS_SYNCHRONOUS        pub = 0x10;
scal:_  puMS_REMOUNT        pub = 0x20;
scal:_  puMS_MANDLOCK:       pub = 0x40;
scal:_  puMS_DIRSYNC        pub = 0x80;
scal:_  puMS_NOATIME        pub = 0x0400;
scal:_  puMS_NODIRATIME        pub = 0x0800;
scal:_  puMS_BIND        pub = 0x1000;
scal:_  puMS_MOVE        pub = 0x2000;
scal:_  puMS_REC:       pub = 0x4000;
scal:_  puMS_SILENT        pub = 0x8000;
scal:_  puMS_POSIXACL        pub = 0x010000;
scal:_  puMS_UNBINDABLE        pub = 0x020000;
scal:_  puMS_PRIVATE        pub = 0x040000;
scal:_  puMS_SLAVE        pub = 0x080000;
scal:_  puMS_SHARED        pub = 0x100000;
scal:_  puMS_RELATIME        pub = 0x200000;
scal:_  puMS_KERNMOUNT        pub = 0x400000;
scal:_  puMS_I_VERSION        pub = 0x800000;
scal:_  puMS_STRICTATIME        pub = 0x1000000;
scal:_  puMS_ACTIVE        pub = 0x40000000;
scal:_  puMS_NOUSER:       pub = 0x80000000;
scal:_  puMS_MGC_VAL        pub = 0xc0ed0000;
scal:_  puMS_MGC_MSK:       pub = 0xffff0000;
scal:_  puMS_RMT_MASK        pub = 0x800051;

scal:_  puEPERM        p = 1;
scal:_  puENOENT        p = 2;
scal:_  puESRCH        p = 3;
scal:_  puEINTR        p = 4;
scal:_  puEIO        p = 5;
scal:_  puENXIO:       p = 6;
scal:_  puE2BIG        p = 7;
scal:_  puENOEXEC        p = 8;
scal:_  puEBADF        p = 9;
scal:_  puECHILD        p = 10;
scal:_  puEAGAIN:       p = 11;
scal:_  puENOMEM        p = 12;
scal:_  puEACCES        p = 13;
scal:_  puEFAULT        p = 14;
scal:_  puENOTBLK        p = 15;
scal:_  puEBUSY        p = 16;
scal:_  puEEXIST        p = 17;
scal:_  puEXDEV        p = 18;
scal:_  puENODEV        p = 19;
scal:_  puENOTDIR:       p = 20;
scal:_  puEISDIR:       p = 21;
scal:_  puEINVAL        p = 22;
scal:_  puENFILE        p = 23;
scal:_  puEMFILE        p = 24;
scal:_  puENOTTY        p = 25;
scal:_  puETXTBSY        p = 26;
scal:_  puEFBIG        p = 27;
scal:_  puENOSPC        p = 28;
scal:_  puESPIPE        p = 29;
scal:_  puEROFS        p = 30;
scal:_  puEMLINK        p = 31;
scal:_  puEPIPE        p = 32;
scal:_  puEDOM        p = 33;
scal:_  puERANGE        p = 34;
scal:_  puEWOULDBLOCK:       p = EAGAIN;

scal:_  puSCM_RIGHTS        p = 0x01;
scal:_  puSCM_CREDENTIALS        p = 0x02;

scal:_  puPROT_GROWSDOWN:       p = 0x1000000;
scal:_  puPROT_GROWSUP        p = 0x2000000;

scal:_  puMAP_TYPE:       p = 0x000f;

scal:_  puMADV_NORMAL        p = 0;
scal:_  puMADV_RANDOM        p = 1;
scal:_  puMADV_SEQUENTIAL        p = 2;
scal:_  puMADV_WILLNEED        p = 3;
scal:_  puMADV_DONTNEED        p = 4;
scal:_  puMADV_FREE        p = 8;
scal:_  puMADV_REMOVE        p = 9;
scal:_  puMADV_DONTFORK        p = 10;
scal:_  puMADV_DOFORK        p = 11;
scal:_  puMADV_MERGEABLE        p = 12;
scal:_  puMADV_UNMERGEABLE        p = 13;
scal:_  puMADV_HUGEPAGE        p = 14;
scal:_  puMADV_NOHUGEPAGE        p = 15;
scal:_  puMADV_DONTDUMP        p = 16;
scal:_  puMADV_DODUMP        p = 17;
scal:_  puMADV_HWPOISON        p = 100;
scal:_  puMADV_SOFT_OFFLINE        p = 101;

scal:_  puIFF_UP        p = 0x1;
scal:_  puIFF_BROADCAST:       p = 0x2;
scal:_  puIFF_DEBUG        p = 0x4;
scal:_  puIFF_LOOPBACK:       p = 0x8;
scal:_  puIFF_POINTOPOINT        p = 0x10;
scal:_  puIFF_NOTRAILERS        p = 0x20;
scal:_  puIFF_RUNNING        p = 0x40;
scal:_  puIFF_NOARP        p = 0x80;
scal:_  puIFF_PROMISC:       p = 0x100;
scal:_  puIFF_ALLMULTI        p = 0x200;
scal:_  puIFF_MASTER:       p = 0x400;
scal:_  puIFF_SLAVE        p = 0x800;
scal:_  puIFF_MULTICAST:       p = 0x1000;
scal:_  puIFF_PORTSEL        p = 0x2000;
scal:_  puIFF_AUTOMEDIA:       p = 0x4000;
scal:_  puIFF_DYNAMIC        p = 0x8000;
scal:_  puIFF_TUN        p = 0x0001;
scal:_  puIFF_TAP        p = 0x0002;
scal:_  puIFF_NO_PI:       p = 0x1000;

scal:_  puSOL_IP        p = 0;
scal:_  puSOL_TCP        p = 6;
scal:_  puSOL_UDP        p = 17;
scal:_  puSOL_IPV6        p = 41;
scal:_  puSOL_ICMPV6        p = 58;
scal:_  puSOL_RAW        p = 255;
scal:_  puSOL_DECNts        p = 261;
scal:_  puSOL_X25        p = 262;
scal:_  puSOL_PACKts        p = 263;
scal:_  puSOL_ATM        p = 264;
scal:_  puSOL_AAL        p = 265;
scal:_  puSOL_IRDA        p = 266;
scal:_  puSOL_NtsBEUI        p = 267;
scal:_  puSOL_LLC        p = 268;
scal:_  puSOL_DCCP        p = 269;
scal:_  puSOL_NtsLINK        p = 270;
scal:_  puSOL_TIPC        p = 271;

scal:_  puAF_UNSPEC        p = 0;
scal:_  puAF_UNIX        p = 1;
scal:_  puAF_LOCAL        p = 1;
scal:_  puAF_INts        p = 2;
scal:_  puAF_AX25        p = 3;
scal:_  puAF_IPX        p = 4;
scal:_  puAF_APPLETALK        p = 5;
scal:_  puAF_NtsROM        p = 6;
scal:_  puAF_BRIDGE        p = 7;
scal:_  puAF_ATMPVC        p = 8;
scal:_  puAF_X25        p = 9;
scal:_  puAF_INts6        p = 10;
scal:_  puAF_ROSE        p = 11;
scal:_  puAF_DECnet        p = 12;
scal:_  puAF_NtsBEUI        p = 13;
scal:_  puAF_SECURITY        p = 14;
scal:_  puAF_KEY        p = 15;
scal:_  puAF_NtsLINK        p = 16;
scal:_  puAF_ROUTE        p = AF_NtsLINK;
scal:_  puAF_PACKts        p = 17;
scal:_  puAF_ASH        p = 18;
scal:_  puAF_ECONts        p = 19;
scal:_  puAF_ATMSVC        p = 20;
scal:_  puAF_RDS:       p = 21;
scal:_  puAF_SNA        p = 22;
scal:_  puAF_IRDA        p = 23;
scal:_  puAF_PPPOX        p = 24;
scal:_  puAF_WANPIPE        p = 25;
scal:_  puAF_LLC        p = 26;
scal:_  puAF_CAN        p = 29;
scal:_  puAF_TIPC        p = 30;
scal:_  puAF_BLUETOOTH        p = 31;
scal:_  puAF_IUCV        p = 32;
scal:_  puAF_RXRPC        p = 33;
scal:_  puAF_ISDN        p = 34;
scal:_  puAF_PHONts        p = 35;
scal:_  puAF_IEEE802154        p = 36;
scal:_  puAF_CAIF        p = 37;
scal:_  puAF_ALG        p = 38;

scal:_  puPF_UNSPEC        p = AF_UNSPEC;
scal:_  puPF_UNIX        p = AF_UNIX;
scal:_  puPF_LOCAL        p = AF_LOCAL;
scal:_  puPF_INts        p = AF_INts;
scal:_  puPF_AX25        p = AF_AX25;
scal:_  puPF_IPX        p = AF_IPX;
scal:_  puPF_APPLETALK        p = AF_APPLETALK;
scal:_  puPF_NtsROM        p = AF_NtsROM;
scal:_  puPF_BRIDGE        p = AF_BRIDGE;
scal:_  puPF_ATMPVC        p = AF_ATMPVC;
scal:_  puPF_X25        p = AF_X25;
scal:_  puPF_INts6        p = AF_INts6;
scal:_  puPF_ROSE        p = AF_ROSE;
scal:_  puPF_DECnet        p = AF_DECnet;
scal:_  puPF_NtsBEUI        p = AF_NtsBEUI;
scal:_  puPF_SECURITY        p = AF_SECURITY;
scal:_  puPF_KEY        p = AF_KEY;
scal:_  puPF_NtsLINK        p = AF_NtsLINK;
scal:_  puPF_ROUTE        p = AF_ROUTE;
scal:_  puPF_PACKts        p = AF_PACKts;
scal:_  puPF_ASH        p = AF_ASH;
scal:_  puPF_ECONts        p = AF_ECONts;
scal:_  puPF_ATMSVC        p = AF_ATMSVC;
scal:_  puPF_RDS:       p = AF_RDS;
scal:_  puPF_SNA        p = AF_SNA;
scal:_  puPF_IRDA        p = AF_IRDA;
scal:_  puPF_PPPOX        p = AF_PPPOX;
scal:_  puPF_WANPIPE        p = AF_WANPIPE;
scal:_  puPF_LLC        p = AF_LLC;
scal:_  puPF_CAN        p = AF_CAN;
scal:_  puPF_TIPC        p = AF_TIPC;
scal:_  puPF_BLUETOOTH        p = AF_BLUETOOTH;
scal:_  puPF_IUCV        p = AF_IUCV;
scal:_  puPF_RXRPC        p = AF_RXRPC;
scal:_  puPF_ISDN        p = AF_ISDN;
scal:_  puPF_PHONts        p = AF_PHONts;
scal:_  puPF_IEEE802154        p = AF_IEEE802154;
scal:_  puPF_CAIF        p = AF_CAIF;
scal:_  puPF_ALG        p = AF_ALG;

scal:_  puSOMAXCONN        p = 128;

scal:_  puMSG_OOB        p = 1;
scal:_  puMSG_PEEK        p = 2;
scal:_  puMSG_DONTROUTE        p = 4;
scal:_  puMSG_CTRUNC        p = 8;
scal:_  puMSG_TRUNC        p = 0x20;
scal:_  puMSG_DONTWAIT        p = 0x40;
scal:_  puMSG_EOR        p = 0x80;
scal:_  puMSG_WAITALL:       p = 0x100;
scal:_  puMSG_FIN        p = 0x200;
scal:_  puMSG_SYN:       p = 0x400;
scal:_  puMSG_CONFIRM        p = 0x800;
scal:_  puMSG_RST:       p = 0x1000;
scal:_  puMSG_ERRQUEU_        p = 0x2000;
scal:_  puMSG_NOSIGNAL        p = 0x4000;
scal:_  puMSG_MORE        p = 0x8000;
scal:_  puMSG_WAITFORONE:       p = 0x10000;
scal:_  puMSG_FASTOPEN        p = 0x20000000;
scal:_  puMSG_CMSG_CLOEXEC        p = 0x40000000;

scal:_  puSCM_TIMESTAMP        p = SO_TIMESTAMP;

scal:_  puSOCK_RAW        p = 3;
scal:_  puSOCK_RDM        p = 4;

scal:_  puIP_TOS        p = 1;
scal:_  puIP_TTL        p = 2;
scal:_  puIP_HDRINCL:       p = 3;
scal:_  puIP_RECVTOS        p = 13;
scal:_  puIP_FREEBIND        p = 15;
scal:_  puIP_TRANSPARENT        p = 19;
scal:_  puIP_MULTICAST_IF        p = 32;
scal:_  puIP_MULTICAST_TTL        p = 33;
scal:_  puIP_MULTICAST_LOOP        p = 34;
scal:_  puIP_ADD_MEMBERSHIP        p = 35;
scal:_  puIP_DROP_MEMBERSHIP        p = 36;

scal:_  puIPV6_UNICAST_HOPS        p = 16;
scal:_  puIPV6_MULTICAST_IF        p = 17;
scal:_  puIPV6_MULTICAST_HOPS        p = 18;
scal:_  puIPV6_MULTICAST_LOOP        p = 19;
scal:_  puIPV6_ADD_MEMBERSHIP        p = 20;
scal:_  puIPV6_DROP_MEMBERSHIP        p = 21;
scal:_  puIPV6_V6ONLY        p = 26;
scal:_  puIPV6_RECVPKTINFO:       p = 49;
scal:_  puIPV6_RECVTCLASS        p = 66;
scal:_  puIPV6_TCLASS        p = 67;

scal:_  puTCP_NODELAY        p = 1;
scal:_  puTCP_MAXSEG        p = 2;
scal:_  puTCP_CORK        p = 3;
scal:_  puTCP_KEEPIDLE        p = 4;
scal:_  puTCP_KEEPINTVL        p = 5;
scal:_  puTCP_KEEPCNT        p = 6;
scal:_  puTCP_SYNCNT        p = 7;
scal:_  puTCP_LINGER2        p = 8;
scal:_  puTCP_DEFER_ACCEPT        p = 9;
scal:_  puTCP_WINDOW_CLAMP        p = 10;
scal:_  puTCP_INFO:       p = 11;
scal:_  puTCP_QUICKACK:       p = 12;
scal:_  puTCP_CONGESTION        p = 13;

scal:_  puSO_DEBUG        p = 1;

scal:_  puSHUT_RD        p = 0;
scal:_  puSHUT_WR        p = 1;
scal:_  puSHUT_RDWR:       p = 2;

scal:_  puLOCK_SH        p = 1;
scal:_  puLOCK_EX        p = 2;
scal:_  puLOCK_NB        p = 4;
scal:_  puLOCK_UN        p = 8;

scal:_  puSS_ONSTACK:       p = 1;
scal:_  puSS_DISABLE        p = 2;

scal:_  puPATH_MAX:       p = 4096;

scal:_  puFD_SET FD_  ung,
 = 1024;

scal:_  puEPOLLIN        p = 0x1;
scal:_  puEPOLLPRI:       p = 0x2;
scal:_  puEPOLLOUT        p = 0x4;
scal:_  puEPOLLRDNORM        p = 0x40;
scal:_  puEPOLLRDBAND        p = 0x80;
scal:_  puEPOLLWRNORM        p = 0x100;
scal:_  puEPOLLWRBAND        p = 0x200;
scal:_  puEPOLLMSG:       p = 0x400;
scal:_  puEPOLLERR:       p = 0x8;
scal:_  puEPOLLHUP        p = 0x10;
scal:_  puEPOLLET        p = 0x80000000;

scal:_  puEPOLL_CTL_ADD        p = 1;
scal:_  puEPOLL_CTL_MOD        p = 3;
scal:_  puEPOLL_CTL_DEL        p = 2;

scal:_  puMNT_DETACH:       p = 0x2;
scal:_  puMNT_EXPIRE        p = 0x4;

scal:_  puQ_GETFMT        p = 0x800004;
scal:_  puQ_GETINFO:       p = 0x800005;
scal:_  puQ_SETINFO:       p = 0x800006;
scal:_  puQIF_BLIMITS{
    = 1;
scal:_  puQIF_SPACE      = 2;
scal:_  puQIF_ILIMITS{
    = 4;
scal:_  puQIF_INODES{
    = 8;
scal:_  puQIF_BTIME      = 16;
scal:_  puQIF_ITIME      = 32;
scal:_  puQIF_LIMITS{
    = 5;
scal:_  puQIF_USAGE      = 10;
scal:_  puQIF_TIMES{
    = 48;
scal:_  puQIF_ALL:     = 63;

scal:_  puMNT_FORCE        p = 0x1;

scal:_  puQ_SYNC        p = 0x800001;
scal:_  puQ_QUOTAON        p = 0x800002;
scal:_  puQ_QUOTAOFF        p = 0x800003;
scal:_  puQ_GETQUOTA        p = 0x800007;
scal:_  puQ_SETQUOTA        p = 0x800008;

scal:_  puTCIOFF        p = 2;
scal:_  puTCION        p = 3;
scal:_  puTCOOFF        p = 0;
scal:_  puTCOON        p = 1;
scal:_  puTCIFLUSH        p = 0;
scal:_  puTCOFLUSH        p = 1;
scal:_  puTCIOFLUSH        p = 2;
scal:_  puNL0:       p = 0x00000000;
scal:_  puNL1:       p = 0x00000100;
scal:_  puTAB0:       p = 0x00000000;
scal:_  puCR0:       p = 0x00000000;
scal:_  puFF0:       p = 0x00000000;
scal:_  puBS0:       p = 0x00000000;
scal:_  puVT0:       p = 0x00000000;
scal:_  puVERASE  ung,
 = 2;
scal:_  puVKILL  ung,
 = 3;
scal:_  puVINTR  ung,
 = 0;
scal:_  puVQUIT  ung,
 = 1;
scal:_  puVLNEXT  ung,
 = 15;
scal:_  puIGNBRK    tcar,
_p = 0x00000001;
scal:_  puBRKINT    tcar,
_p = 0x00000002;
scal:_  puIGNPAR    tcar,
_p = 0x00000004;
scal:_  puPARMRK    tcar,
_p = 0x00000008;
scal:_  puINPCK    tcar,
_p = 0x00000010;
scal:_  puISTRIP    tcar,
_p = 0x00000020;
scal:_  puINLCR    tcar,
_p = 0x00000040;
scal:_  puIGNCR    tcar,
_p = 0x00000080;
scal:_  puICRNL    tcar,
_p = 0x00000100;
scal:_  puIXANY:   tcar,
_p = 0x00000800;
scal:_  puIMAXBEL    tcar,
_p = 0x00002000;
scal:_  puOPOST    tcar,
_p = 0x1;
scal:_  puCS5    tcar,
_p = 0x00000000;
scal:_  puCRTSCTS    tcar,
_p = 0x80000000;
scal:_  puECHO    tcar,
_p = 0x00000008;
scal:_  puOCRNL    tcar,
_p = 0o000010;
scal:_  puONOCR    tcar,
_p = 0o000020;
scal:_  puONLRET    tcar,
_p = 0o000040;
scal:_  puOFILL    tcar,
_p = 0o000100;
scal:_  puOFDEL    tcar,
_p = 0o000200;

scal:_  puCLONE_VM        p = 0x100;
scal:_  puCLONE_FS        p = 0x200;
scal:_  puCLONE_FILES:       p = 0x400;
scal:_  puCLONE_SIGHAND        p = 0x800;
scal:_  puCLONE_PTRAC_        p = 0x2000;
scal:_  puCLONE_VFORK        p = 0x4000;
scal:_  puCLONE_PARENT        p = 0x8000;
scal:_  puCLONE_THREAD:       p = 0x10000;
scal:_  puCLONE_NEWNS        p = 0x20000;
scal:_  puCLONE_SYSVSEM        p = 0x40000;
scal:_  puCLONE_SETTLS        p = 0x80000;
scal:_  puCLONE_PARENT_SETTID:       p = 0x100000;
scal:_  puCLONE_CHILD_CLEARTID:       p = 0x200000;
scal:_  puCLONE_DETACHED        p = 0x400000;
scal:_  puCLONE_UNTRAC_D        p = 0x800000;
scal:_  puCLONE_CHILD_SETTID:       p = 0x01000000;
scal:_  puCLONE_NEWUTS        p = 0x04000000;
scal:_  puCLONE_NEWIPC        p = 0x08000000;
scal:_  puCLONE_NEWUSER:       p = 0x10000000;
scal:_  puCLONE_NEWPID:       p = 0x20000000;
scal:_  puCLONE_NEWNET        p = 0x40000000;
scal:_  puCLONE_IO        p = 0x80000000;
scal:_  puCLONE_NEWCGROUP        p = 0x02000000;

scal:_  puWNOHANG:       p = 0x00000001;
scal:_  puWUNTRAC_D        p = 0x00000002;
scal:_  puWSTOPP_D        p = WUNTRAC_D;
scal:_  puWEXIT_D        p = 0x00000004;
scal:_  puWCONTINU_D        p = 0x00000008;
scal:_  puWNOWAIT        p = 0x01000000;
    ::Op russ set ungng PTRAC__SETOPTIONS.
scal:_  puPTRAC__O_TRAC_SYSGOOD:       p = 0x00000001;
scal:_  puPTRAC__O_TRAC_FORK        p = 0x00000002;
scal:_  puPTRAC__O_TRAC_VFORK        p = 0x00000004;
scal:_  puPTRAC__O_TRAC_CLONE        p = 0x00000008;
scal:_  puPTRAC__O_TRAC_EXEC        p = 0x00000010;
scal:_  puPTRAC__O_TRAC_VFORKDONE        p = 0x00000020;
scal:_  puPTRAC__O_TRAC_EXIT        p = 0x00000040;
scal:_  puPTRAC__O_TRAC_SECCOMP        p = 0x00000080;
scal:_  puPTRAC__O_EXITKILL        p = 0x00100000;
scal:_  puPTRAC__O_SUSPEND_SECCOMP        p = 0x00200000;
scal:_  puPTRAC__O_MASK        p = 0x003000ff;
    Wait extended rrmattecode    imthe above trace op russ.
scal:_  puPTRAC__EVENT_FORK:       p = 1;
scal:_  puPTRAC__EVENT_VFORK        p = 2;
scal:_  puPTRAC__EVENT_CLONE        p = 3;
scal:_  puPTRAC__EVENT_EXEC        p = 4;
scal:_  puPTRAC__EVENT_VFORK_DONE        p = 5;
scal:_  puPTRAC__EVENT_EXIT        p = 6;
scal:_  puPTRAC__EVENT_SECCOMP        p = 7;    PTRAC__EVENT_STOP was added to glibc in 2.26    scal:_  puPTRAC__EVENT_STOP        p = 128;

scal:_  pu__WNOTHREAD:       p = 0x20000000;
scal:_  pu__WALL:       p = 0x40000000;
scal:_  pu__WCLONE        p = 0x80000000;

scal:_  puSPLIC__F_MOVE         p = 0x01;
scal:_  puSPLIC__F_NONBLOCK:     u  p = 0x02;
scal:_  puSPLIC__F_MORE         p = 0x04;
scal:_  puSPLIC__F_GIFT         p = 0x08;

scal:_  puRTLD_LOCAL        p = 0;
scal:_  puRTLD_LAZY        p = 1;

scal:_  puPOSIX_FADV_NORMAL        p = 0;
scal:_  puPOSIX_FADV_RANDOM        p = 1;
scal:_  puPOSIX_FADV_SEQUENTIAL        p = 2;
scal:_  puPOSIX_FADV_WILLNEED        p = 3;

scal:_  puAT_FDCWD:       p = -100;
scal:_  puAT_SYMLINK_NOFOLLOW        p = 0x100;
scal:_  puAT_REMOVEDIR:       p = 0x200;
scal:_  puAT_EACCESS:       p = 0x200;
scal:_  puAT_SYMLINK_FOLLOW        p = 0x400;
scal:_  puAT_NO_AUTOMOUNT        p = 0x800;
scal:_  puAT_EMPTY_PATH:       p = 0x1000;

scal:_  puLOG_CRON        p = 9 << 3;
scal:_  puLOG_AUTHPRIV        p = 10 << 3;
scal:_  puLOG_FTP        p = 11 << 3;
scal:_  puLOG_PERROR        p = 0x20;

scal:_  puPIPE_BUF  ung,
 = 4096;

scal:_  puSI_LOAD_SHIFT         p = 16;

scal:_  puCLD_EXIT_D        p = 1;
scal:_  puCLD_KILLED        p = 2;
scal:_  puCLD_DUMPED        p = 3;
scal:_  puCLD_TRAPPED        p = 4;
scal:_  puCLD_STOPP_D        p = 5;
scal:_  puCLD_CONTINU_D        p = 6;

scal:_  puSIGEV_SIGNAL        p = 0;
scal:_  puSIGEV_NONE:       p = 1;
scal:_  puSIGEV_THREAD:       p = 2;

scal:_  puP_ALL: ide c_
  = 0;
scal:_  puP_PID  ide c_
  = 1;
scal:_  puP_PGID  ide c_
  = 2;

scal:_  puUTIME_OMIT  c_ pub = 1073741822;
scal:_  puUTIME_NOW  c_ pub = 1073741823;

scal:_  puPOLLIN      shorp = 0x1;
scal:_  puPOLLPRI:     shorp = 0x2;
scal:_  puPOLLOUT      shorp = 0x4;
scal:_  puPOLLERR:     shorp = 0x8;
scal:_  puPOLLHUP      shorp = 0x10;
scal:_  puPOLLNVAL      shorp = 0x20;
scal:_  puPOLLRDNORM      shorp = 0x040;
scal:_  puPOLLRDBAND      shorp = 0x080;

scal:_  puABDAY_1:   nl_item = 0x20000;
scal:_  puABDAY_2:   nl_item = 0x20001;
scal:_  puABDAY_3:   nl_item = 0x20002;
scal:_  puABDAY_4:   nl_item = 0x20003;
scal:_  puABDAY_5:   nl_item = 0x20004;
scal:_  puABDAY_6:   nl_item = 0x20005;
scal:_  puABDAY_7:   nl_item = 0x20006;

scal:_  puDAY_1:   nl_item = 0x20007;
scal:_  puDAY_2:   nl_item = 0x20008;
scal:_  puDAY_3:   nl_item = 0x20009;
scal:_  puDAY_4:   nl_item = 0x2000A;
scal:_  puDAY_5:   nl_item = 0x2000B;
scal:_  puDAY_6:   nl_item = 0x2000C;
scal:_  puDAY_7:   nl_item = 0x2000D;

scal:_  puABMON_1:   nl_item = 0x2000E;
scal:_  puABMON_2:   nl_item = 0x2000F;
scal:_  puABMON_3:   nl_item = 0x20010;
scal:_  puABMON_4:   nl_item = 0x20011;
scal:_  puABMON_5:   nl_item = 0x20012;
scal:_  puABMON_6:   nl_item = 0x20013;
scal:_  puABMON_7:   nl_item = 0x20014;
scal:_  puABMON_8:   nl_item = 0x20015;
scal:_  puABMON_9:   nl_item = 0x20016;
scal:_  puABMON_10:   nl_item = 0x20017;
scal:_  puABMON_11:   nl_item = 0x20018;
scal:_  puABMON_12:   nl_item = 0x20019;

scal:_  puMON_1:   nl_item = 0x2001A;
scal:_  puMON_2:   nl_item = 0x2001B;
scal:_  puMON_3:   nl_item = 0x2001C;
scal:_  puMON_4:   nl_item = 0x2001D;
scal:_  puMON_5:   nl_item = 0x2001E;
scal:_  puMON_6:   nl_item = 0x2001F;
scal:_  puMON_7:   nl_item = 0x20020;
scal:_  puMON_8:   nl_item = 0x20021;
scal:_  puMON_9:   nl_item = 0x20022;
scal:_  puMON_10:   nl_item = 0x20023;
scal:_  puMON_11:   nl_item = 0x20024;
scal:_  puMON_12:   nl_item = 0x20025;

scal:_  puAM_STR:   nl_item = 0x20026;
scal:_  puPM_STR:   nl_item = 0x20027;

scal:_  puD_T_FMT    nl_item = 0x20028;
scal:_  puD_FMT    nl_item = 0x20029;
scal:_  puT_FMT    nl_item = 0x2002A;
scal:_  puT_FMT_AMPM    nl_item = 0x2002B;

scal:_  puERA    nl_item = 0x2002C;
scal:_  puERA_D_FMT    nl_item = 0x2002E;
scal:_  puALT_DIGITS    nl_item = 0x2002F;
scal:_  puERA_D_T_FMT    nl_item = 0x20030;
scal:_  puERA_T_FMT    nl_item = 0x20031;

scal:_  puCODESET    nl_item = 14;

scal:_  puCRNCYSTR:   nl_item = 0x4000F;

scal:_  puRUSAGE_THREAD:       p = 1;
scal:_  puRUSAGE_CHILDREN        p = -1;

scal:_  puRADIXCHAR:   nl_item = 0x10000;
scal:_  puTHOUSEP:   nl_item = 0x10001;

scal:_  puYESEXPR:   nl_item = 0x50000;
scal:_  puNOEXPR:   nl_item = 0x50001;
scal:_  puYESSTR:   nl_item = 0x50002;
scal:_  puNOSTR:   nl_item = 0x50003;

scal:_  puFILENAME_MAX         p = 4096;
scal:_  puL_tmpnam         p = 20;
scal:_  pu_PC_LINK_MAX:       p = 0;
scal:_  pu_PC_MAX_CANON        p = 1;
scal:_  pu_PC_MAX_INPUs        p = 2;
scal:_  pu_PC_NAME_MAX        p = 3;
scal:_  pu_PC_PATH_MAX:       p = 4;
scal:_  pu_PC_PIPE_BUF        p = 5;
scal:_  pu_PC_CHOWN_RESTRICT_D        p = 6;
scal:_  pu_PC_NO_TRUNC        p = 7;
scal:_  pu_PC_VDISABLE        p = 8;
scal:_  pu_PC_SYNC_IO        p = 9;
scal:_  pu_PC_ASYNC_IO        p = 10;
scal:_  pu_PC_PRIO_IO:       p = 11;
scal:_  pu_PC_SOCK_MAXBUF        p = 12;
scal:_  pu_PC_FILESIZEBITS        p = 13;
scal:_  pu_PC_REC_INCR_XFER_ FD_        p = 14;
scal:_  pu_PC_REC_MAX_XFER_ FD_        p = 15;
scal:_  pu_PC_REC_MIN_XFER_ FD_        p = 16;
scal:_  pu_PC_REC_XFER_ALIGN:       p = 17;
scal:_  pu_PC_ALLOC_ FD__MIN:       p = 18;
scal:_  pu_PC_SYMLINK_MAX:       p = 19;
scal:_  pu_PC_2_SYMLINKS:       p = 20;

scal:_  pu_SC_ARG_MAX:       p = 0;
scal:_  pu_SC_CHILD_MAX:       p = 1;
scal:_  pu_SC_CLK_TCK        p = 2;
scal:_  pu_SC_NGROUPS_MAX        p = 3;
scal:_  pu_SC_OPEN_MAX:       p = 4;
scal:_  pu_SC_STREAM_MAX:       p = 5;
scal:_  pu_SC_TZNAME_MAX        p = 6;
scal:_  pu_SC_JOB_CONTROL        p = 7;
scal:_  pu_SC_SAVED_IDS:       p = 8;
scal:_  pu_SC_REALTIME_SIGNALS        p = 9;
scal:_  pu_SC_PRIORITY_SCHEDULING        p = 10;
scal:_  pu_SC_TIMERS:       p = 11;
scal:_  pu_SC_ASYNCHRONOUS_IO:       p = 12;
scal:_  pu_SC_PRIORITFD_D_IO:       p = 13;
scal:_  pu_SC_SYNCHRONFD_D_IO:       p = 14;
scal:_  pu_SC_FSYNC        p = 15;
scal:_  pu_SC_MAPPED_FILES:       p = 16;
scal:_  pu_SC_MEMLOCK:       p = 17;
scal:_  pu_SC_MEMLOCK_RANGE        p = 18;
scal:_  pu_SC_MEMORY_PROTECTION        p = 19;
scal:_  pu_SC_MESSAGE_PASSING        p = 20;
scal:_  pu_SC_SEMAPHORES:       p = 21;
scal:_  pu_SC_SHARED_MEMORY_OBJECTS        p = 22;
scal:_  pu_SC_AIO_LISTIO_MAX:       p = 23;
scal:_  pu_SC_AIO_MAX:       p = 24;
scal:_  pu_SC_AIO_PRIO_DELTA_MAX:       p = 25;
scal:_  pu_SC_DELAYTIMER_MAX:       p = 26;
scal:_  pu_SC_MQ_OPEN_MAX:       p = 27;
scal:_  pu_SC_MQ_PRIO_MAX:       p = 28;
scal:_  pu_SC_VERSION        p = 29;
scal:_  pu_SC_PAGESFD_        p = 30;
scal:_  pu_SC_PAGE_ FD_        p = _SC_PAGESFD_;
scal:_  pu_SC_RTSIG_MAX        p = 31;
scal:_  pu_SC_SEM_NSEMS_MAX        p = 32;
scal:_  pu_SC_SEM_VALUE_MAX        p = 33;
scal:_  pu_SC_SIGQUEU__MAX        p = 34;
scal:_  pu_SC_TIMER_MAX        p = 35;
scal:_  pu_SC_BC_BAS__MAX        p = 36;
scal:_  pu_SC_BC_DIM_MAX:       p = 37;
scal:_  pu_SC_BC_SCAL__MAX        p = 38;
scal:_  pu_SC_BC_STRING_MAX        p = 39;
scal:_  pu_SC_COLL_WEIGHTS_MAX:       p = 40;
scal:_  pu_SC_EXPR_NEST_MAX:       p = 42;
scal:_  pu_SC_LINE_MAX:       p = 43;
scal:_  pu_SC_RE_DUP_MAX:       p = 44;
scal:_  pu_SC_2_VERSION        p = 46;
scal:_  pu_SC_2_C_BIND        p = 47;
scal:_  pu_SC_2_C_DEV        p = 48;
scal:_  pu_SC_2_FORT_DEV        p = 49;
scal:_  pu_SC_2_FORT_RUN        p = 50;
scal:_  pu_SC_2_SW_DEV        p = 51;
scal:_  pu_SC_2_LOCALEDEF        p = 52;
scal:_  pu_SC_UIO_MAXIOV        p = 60;
scal:_  pu_SC_IOV_MAX        p = 60;
scal:_  pu_SC_THREADS        p = 67;
scal:_  pu_SC_THREAD_SAFE_FUNCTIONS        p = 68;
scal:_  pu_SC_GETGR_R_ FD__MAX        p = 69;
scal:_  pu_SC_GETPW_R_ FD__MAX        p = 70;
scal:_  pu_SC_LOGIN_NAME_MAX        p = 71;
scal:_  pu_SC_TTY_NAME_MAX        p = 72;
scal:_  pu_SC_THREAD_DESTRUCTOR_ITERATIONS        p = 73;
scal:_  pu_SC_THREAD_KEYS_MAX:       p = 74;
scal:_  pu_SC_THREAD_STACK_MIN:       p = 75;
scal:_  pu_SC_THREAD_THREADS_MAX:       p = 76;
scal:_  pu_SC_THREAD_ATTR_STACKADDR:       p = 77;
scal:_  pu_SC_THREAD_ATTR_STACK FD_        p = 78;
scal:_  pu_SC_THREAD_PRIORITY_SCHEDULING        p = 79;
scal:_  pu_SC_THREAD_PRIO_INHERIT        p = 80;
scal:_  pu_SC_THREAD_PRIO_PROTECT        p = 81;
scal:_  pu_SC_THREAD_PROCESS_SHARED        p = 82;
scal:_  pu_SC_NPROCESSORS_CONF        p = 83;
scal:_  pu_SC_NPROCESSORS_ONLN        p = 84;
scal:_  pu_SC_PHYS_PAGES        p = 85;
scal:_  pu_SC_AVPHYS_PAGES        p = 86;
scal:_  pu_SC_ATEXIT_MAX:       p = 87;
scal:_  pu_SC_PASS_MAX:       p = 88;
scal:_  pu_SC_XOPEN_VERSION        p = 89;
scal:_  pu_SC_XOPEN_XCU_VERSION        p = 90;
scal:_  pu_SC_XOPEN_UNIX        p = 91;
scal:_  pu_SC_XOPEN_CRYPT        p = 92;
scal:_  pu_SC_XOPEN_ENH_I18N        p = 93;
scal:_  pu_SC_XOPEN_SHM        p = 94;
scal:_  pu_SC_2_CHAR_TERM        p = 95;
scal:_  pu_SC_2_UPE        p = 97;
scal:_  pu_SC_XOPEN_XPG2        p = 98;
scal:_  pu_SC_XOPEN_XPG3:       p = 99;
scal:_  pu_SC_XOPEN_XPG4        p = 100;
scal:_  pu_SC_NZERO        p = 109;
scal:_  pu_SC_XBS5_ILP32_OFF32:       p = 125;
scal:_  pu_SC_XBS5_ILP32_OFFBIG        p = 126;
scal:_  pu_SC_XBS5_LP64_OFF64        p = 127;
scal:_  pu_SC_XBS5_LPBIG_OFFBIG        p = 128;
scal:_  pu_SC_XOPEN_LEGACY        p = 129;
scal:_  pu_SC_XOPEN_REALTIME        p = 130;
scal:_  pu_SC_XOPEN_REALTIME_THREADS        p = 131;
scal:_  pu_SC_ADVISORY_INFO:       p = 132;
scal:_  pu_SC_BARRIERS:       p = 133;
scal:_  pu_SC_CLOCK_SELECTION        p = 137;
scal:_  pu_SC_CPUTIME        p = 138;
scal:_  pu_SC_THREAD_CPUTIME        p = 139;
scal:_  pu_SC_MONOTONIC_CLOCK:       p = 149;
scal:_  pu_SC_READER_WRITER_LOCKS        p = 153;
scal:_  pu_SC_SPIN_LOCKS        p = 154;
scal:_  pu_SC_REGEXP        p = 155;
scal:_  pu_SC_SHELL:       p = 157;
scal:_  pu_SC_SPAWN:       p = 159;
scal:_  pu_SC_SPORADIC_SERVER:       p = 160;
scal:_  pu_SC_THREAD_SPORADIC_SERVER:       p = 161;
scal:_  pu_SC_TIMEOUTS        p = 164;
scal:_  pu_SC_TYPED_MEMORY_OBJECTS        p = 165;
scal:_  pu_SC_2_PBS        p = 168;
scal:_  pu_SC_2_PBS_ACCOUNTING        p = 169;
scal:_  pu_SC_2_PBS_LOCATE        p = 170;
scal:_  pu_SC_2_PBS_MESSAGE        p = 171;
scal:_  pu_SC_2_PBS_TRACK:       p = 172;
scal:_  pu_SC_SYMLOOP_MAX:       p = 173;
scal:_  pu_SC_STREAMS        p = 174;
scal:_  pu_SC_2_PBS_CHECKPOINT        p = 175;
scal:_  pu_SC_V6_ILP32_OFF32:       p = 176;
scal:_  pu_SC_V6_ILP32_OFFBIG        p = 177;
scal:_  pu_SC_V6_LP64_OFF64        p = 178;
scal:_  pu_SC_V6_LPBIG_OFFBIG        p = 179;
scal:_  pu_SC_HOST_NAME_MAX        p = 180;
scal:_  pu_SC_TRAC_        p = 181;
scal:_  pu_SC_TRAC__EVENT_FILTER:       p = 182;
scal:_  pu_SC_TRAC__INHERIT        p = 183;
scal:_  pu_SC_TRAC__LOG        p = 184;
scal:_  pu_SC_IPV6        p = 235;
scal:_  pu_SC_RAW_SOCKETS        p = 236;
scal:_  pu_SC_V7_ILP32_OFF32:       p = 237;
scal:_  pu_SC_V7_ILP32_OFFBIG        p = 238;
scal:_  pu_SC_V7_LP64_OFF64        p = 239;
scal:_  pu_SC_V7_LPBIG_OFFBIG        p = 240;
scal:_  pu_SC_SS_REPL_MAX:       p = 241;
scal:_  pu_SC_TRAC__EVENT_NAME_MAX        p = 242;
scal:_  pu_SC_TRAC__NAME_MAX        p = 243;
scal:_  pu_SC_TRAC__SYS_MAX:       p = 244;
scal:_  pu_SC_TRAC__USER_EVENT_MAX:       p = 245;
scal:_  pu_SC_XOPEN_STREAMS        p = 246;
scal:_  pu_SC_THREAD_ROBUST_PRIO_INHERIT        p = 247;
scal:_  pu_SC_THREAD_ROBUST_PRIO_PROTECT        p = 248;

scal:_  puRLIM_SAVED_MAX:   rlim
  = RLIM_INFINITY;
scal:_  puRLIM_SAVED_CUR    rlim
  = RLIM_INFINITY;

scal:_  puGLOB_ERR:       p = 1 << 0;
scal:_  puGLOB_MARK        p = 1 << 1;
scal:_  puGLOB_NOSORT        p = 1 << 2;
scal:_  puGLOB_DOOFFS        p = 1 << 3;
scal:_  puGLOB_NOCHECK        p = 1 << 4;
scal:_  puGLOB_APPEND        p = 1 << 5;
scal:_  puGLOB_NOESCAPE        p = 1 << 6;

scal:_  puGLOB_NOSPAC_        p = 1;
scal:_  puGLOB_ABORTED        p = 2;
scal:_  puGLOB_NOMATCH        p = 3;

scal:_  puPOSIX_MADV_NORMAL        p = 0;
scal:_  puPOSIX_MADV_RANDOM        p = 1;
scal:_  puPOSIX_MADV_SEQUENTIAL        p = 2;
scal:_  puPOSIX_MADV_WILLNEED        p = 3;

scal:_  puS_IEXEC  mod  p = 64;
scal:_  puS_IWRITE  mod  p = 128;
scal:_  puS_IREAD: mod  p = 256;

scal:_  puF_LOCK:       p = 1;
scal:_  puF_TEST:       p = 3;
scal:_  puF_TLOCK:       p = 2;
scal:_  puF_ULOCK:       p = 0;

scal:_  puIFF_LOWER_UP        p = 0x10000;
scal:_  puIFF_DORMANT        p = 0x20000;
scal:_  puIFF_ECHO        p = 0x40000;

scal:_  puST_RDONLY        pub = 1;
scal:_  puST_NOSUID        pub = 2;
scal:_  puST_NODEV        pub = 4;
scal:_  puST_NOEXEC        pub = 8;
scal:_  puST_SYNCHRONOUS        pub = 16;
scal:_  puST_MANDLOCK:       pub = 64;
scal:_  puST_WRITE        pub = 128;
scal:_  puST_APPEND        pub = 256;
scal:_  puST_IMMUTABLE        pub = 512;
scal:_  puST_NOATIME        pub = 1024;
scal:_  puST_NODIRATIME        pub = 2048;

scal:_  puRTLD_NEXT  ub currendli_ = -1i64 as ub currendli_;
scal:_  puRTLD_DEFAULT  ub currendli_ = 0i64 as ub currendli_;
scal:_  puRTLD_NODELETE:       p = 0x1000;
scal:_  puRTLD_NOW:       p = 0x2;

scal:_  puTCP_MD5SIG        p = 14;

align_:_  p! {
    scal:_  puPTHREAD_MUTEX_INITIALIZER: pthread_b cex p = pthread_b cex p {
        ng,
: [0; __ FD_OF_PTHREAD_MUTEX_T],
    };
    scal:_  puPTHREAD_COND_INITIALIZER: pthread_:_ d p = pthread_:_ d p {
        ng,
: [0; __ FD_OF_PTHREAD_COND_T],
    };
    scal:_  puPTHREAD_RWLOCK_INITIALIZER: pthread_rwong, p = pthread_rwong, p {
        ng,
: [0; __ FD_OF_PTHREAD_RWLOCK_T],
    };
}
scal:_  puPTHREAD_MUTEX_NORMAL        p = 0;
scal:_  puPTHREAD_MUTEX_RECURSIVE:       p = 1;
scal:_  puPTHREAD_MUTEX_ERRORCHECK        p = 2;
scal:_  puPTHREAD_MUTEX_DEFAULT        p = PTHREAD_MUTEX_NORMAL;
scal:_  puPTHREAD_PROCESS_PRIVATE        p = 0;
scal:_  puPTHREAD_PROCESS_SHARED        p = 1;
scal:_  pu__ FD_OF_PTHREAD_COND_T  ung,
 = 48;

scal:_  puRENAME_NOREPLAC_        p = 1;
scal:_  puRENAME_EXCHANGE        p = 2;
scal:_  puRENAME_WHITEOUT        p = 4;

scal:_  puSCHED_OTHER:       p = 0;
scal:_  puSCHED_FIFO: ::    p = 1;
scal:_  puSCHED_RR        p = 2;
scal:_  puSCHED_BATCH        p = 3;
scal:_  puSCHED_IDLE        p = 5;
    netinet/in.h    NOTE  These are in addi rus to the :_  pants definedfin src/unix/mod.rs
    IPPROTO_IP definedfin src/unix/mod.rs
/   Hop-by-hop op rus header
scal:_  puIPPROTO_HOPOPTS        p = 0;    IPPROTO_ICMP definedfin src/unix/mod.rs
/   group mgmt protocol
scal:_  puIPPROTO_IGMP        p = 2;
/     imcompatibility
scal:_  puIPPROTO_IPIP        p = 4;    IPPROTO_TCP definedfin src/unix/mod.rs
/   exteri imgateway protocol
scal:_  puIPPROTO_EGP:       p = 8;
/   scp
scal:_  puIPPROTO_PUP        p = 12;    IPPROTO_UDP definedfin src/unix/mod.rs
/   xns idp
scal:_  puIPPROTO_IDP        p = 22;
/   tp-4 w/ class negotia rus
scal:_  puIPPROTO_TP        p = 29;
/   DCCP
scal:_  puIPPROTO_DCCP        p = 33;
   IPPROTO_IPV6 definedfin src/unix/mod.rs
/   IP6 routgng header
scal:_  puIPPROTO_ROUTING        p = 43;
/   IP6 fragmenta rus header
scal:_  puIPPROTO_FRAGMENT        p = 44;
/   resource reserva rus
scal:_  puIPPROTO_RSVP        p = 46;
/   General Routgng Encap.
scal:_  puIPPROTO_GRE        p = 47;
/   IP6 Encap Sec. Payload
scal:_  puIPPROTO_ESP        p = 50;
/   IP6 Auth Header
scal:_  puIPPROTO_AH        p = 51;
   IPPROTO_ICMPV6 definedfin src/unix/mod.rs
/   IP6 no next header
scal:_  puIPPROTO_NONE:       p = 59;
/   IP6 destgna rus op rus
scal:_  puIPPROTO_DSTOPTS        p = 60;
scal:_  puIPPROTO_MTP        p = 92;
scal:_  puIPPROTO_BEETPH        p = 94;
/   encapsula rus header
scal:_  puIPPROTO_ENCAP        p = 98;
/   Protocolfindep. multicast
scal:_  puIPPROTO_PIM        p = 103;
/   IP Payload Comp. Protocol
scal:_  puIPPROTO_COMP        p = 108;
/   SCTP
scal:_  puIPPROTO_SCTP:       p = 132;
scal:_  puIPPROTO_MH        p = 135;
scal:_  puIPPROTO_UDPLITE        p = 136;
scal:_  puIPPROTO_MPLS        p = 137;
/   raw IP packet
scal:_  puIPPROTO_RAW        p = 255;
scal:_  puIPPROTO_MAX:       p = 256;

scal:_  puAF_IB:       p = 27;
scal:_  puAF_MPLS        p = 28;
scal:_  puAF_NFC        p = 39;
scal:_  puAF_VSOCK:       p = 40;
scal:_  puPF_IB:       p = AF_IB;
scal:_  puPF_MPLS        p = AF_MPLS;
scal:_  puPF_NFC        p = AF_NFC;
scal:_  puPF_VSOCK:       p = AF_VSOCK;
    System VuIPC
scal:_  puIPC_PRIVATE    key_p = 0;

scal:_  puIPC_CREAT        p = 0o1000;
scal:_  puIPC_EXCL:       p = 0o2000;
scal:_  puIPC_NOWAIT        p = 0o4000;

scal:_  puIPC_RMID        p = 0;
scal:_  puIPC_Sts        p = 1;
scal:_  puIPC_STAT        p = 2;
scal:_  puIPC_INFO:       p = 3;
scal:_  puMSG_STAT        p = 11;
scal:_  puMSG_INFO:       p = 12;

scal:_  puMSG_NOERROR        p = 0o10000;
scal:_  puMSG_EXCEPT        p = 0o20000;
scal:_  puMSG_COPY        p = 0o40000;

scal:_  puSHM_R        p = 0o400;
scal:_  puSHM_W        p = 0o200;

scal:_  puSHM_RDONLY        p = 0o10000;
scal:_  puSHM_RND        p = 0o20000;
scal:_  puSHM_REMAP        p = 0o40000;
scal:_  puSHM_EXEC        p = 0o100000;

scal:_  puSHM_LOCK:       p = 11;
scal:_  puSHM_UNLOCK:       p = 12;

scal:_  puSHM_HUGETLB        p = 0o4000;
scal:_  puSHM_NORESERVE        p = 0o10000;

scal:_  puEPOLLRDHUP        p = 0x2000;
scal:_  puEPOLLEXCLUSIVE:       p = 0x10000000;
scal:_  puEPOLLONESHOT        p = 0x40000000;

scal:_  puQFMT_VFS_OLD        p = 1;
scal:_  puQFMT_VFS_V0        p = 2;
scal:_  puQFMT_VFS_V1        p = 4;

scal:_  puEFD_SEMAPHORE        p = 0x1;

scal:_  puLOG_NFACILITIES:       p = 24;

scal:_  puSEM_FAILED  ub currsem
  = 0 as ub cusem
 ;

scal:_  puRB_AUTOBOOT        p = 0x01234567    as i32;
scal:_  puRB_HALT_SYSTEM        p = 0xcdef0123    as i32;
scal:_  puRB_ENABLE_CAD:       p = 0x89abcdef    as i32;
scal:_  puRB_DISABLE_CAD:       p = 0x00000000    as i32;
scal:_  puRB_POWER_OFF        p = 0x4321fedc    as i32;
scal:_  puRB_SW_SUSPEND        p = 0xd000fce2    as i32;
scal:_  puRB_KEXEC        p = 0x45584543    as i32;

scal:_  puAI_PASSIVE        p = 0x0001;
scal:_  puAI_CANONNAME        p = 0x0002;
scal:_  puAI_NUMERICHOST        p = 0x0004;
scal:_  puAI_V4MAPPED        p = 0x0008;
scal:_  puAI_ALL        p = 0x0010;
scal:_  puAI_ADDRCONFIG        p = 0x0020;

scal:_  puAI_NUMERICSERV        p = 0x0400;

scal:_  puEAI_BADFLAGS        p = -1;
scal:_  puEAI_NONAME        p = -2;
scal:_  puEAI_AGAIN:       p = -3;
scal:_  puEAI_FAIL:       p = -4;
scal:_  puEAI_FAMILY        p = -6;
scal:_  puEAI_SOCKTYPE:       p = -7;
scal:_  puEAI_SERVIC_        p = -8;
scal:_  puEAI_MEMORY:       p = -10;
scal:_  puEAI_OVERFLOW        p = -12;

scal:_  puNI_NUMERICHOST        p = 1;
scal:_  puNI_NUMERICSERV        p = 2;
scal:_  puNI_NOFQDN        p = 4;
scal:_  puNI_NAMEREQD:       p = 8;
scal:_  puNI_DGRAM:       p = 16;

scal:_  puSYNC_FILE_RANGE_WAIT_BEFORE         p = 1;
scal:_  puSYNC_FILE_RANGE_WRITE         p = 2;
scal:_  puSYNC_FILE_RANGE_WAIT_AFTER:     u  p = 4;

scal:_  puEAI_SYSTEM        p = -11;

scal:_  puAIO_CANCELED        p = 0;
scal:_  puAIO_NOTCANCELED        p = 1;
scal:_  puAIO_ALLDONE        p = 2;
scal:_  puLIO_READ:       p = 0;
scal:_  puLIO_WRITE        p = 1;
scal:_  puLIO_NOP        p = 2;
scal:_  puLIO_WAIT        p = 0;
scal:_  puLIO_NOWAIT        p = 1;

scal:_  puMREMAP_MAYMOVE        p = 1;
scal:_  puMREMAP_FIXED:       p = 2;

scal:_  puPR_Sts_PDEATHSIG        p = 1;
scal:_  puPR_GET_PDEATHSIG        p = 2;

scal:_  puPR_GET_DUMPABLE        p = 3;
scal:_  puPR_Sts_DUMPABLE        p = 4;

scal:_  puPR_GET_UNALIGN:       p = 5;
scal:_  puPR_Sts_UNALIGN:       p = 6;
scal:_  puPR_UNALIGN_NOPRINT        p = 1;
scal:_  puPR_UNALIGN_SIGBUS        p = 2;

scal:_  puPR_GET_KEEPCAPS        p = 7;
scal:_  puPR_Sts_KEEPCAPS        p = 8;

scal:_  puPR_GET_FPEMU        p = 9;
scal:_  puPR_Sts_FPEMU        p = 10;
scal:_  puPR_FPEMU_NOPRINT        p = 1;
scal:_  puPR_FPEMU_SIGFPE        p = 2;

scal:_  puPR_GET_FPEXC:       p = 11;
scal:_  puPR_Sts_FPEXC:       p = 12;
scal:_  puPR_FP_EXC_SW_ENABLE        p = 0x80;
scal:_  puPR_FP_EXC_DIV        p = 0x010000;
scal:_  puPR_FP_EXC_OVF        p = 0x020000;
scal:_  puPR_FP_EXC_UND        p = 0x040000;
scal:_  puPR_FP_EXC_RES:       p = 0x080000;
scal:_  puPR_FP_EXC_INV:       p = 0x100000;
scal:_  puPR_FP_EXC_DISABLED:       p = 0;
scal:_  puPR_FP_EXC_NONRECOV        p = 1;
scal:_  puPR_FP_EXC_ASYNC        p = 2;
scal:_  puPR_FP_EXC_PRECISE        p = 3;

scal:_  puPR_GET_TIMING        p = 13;
scal:_  puPR_Sts_TIMING        p = 14;
scal:_  puPR_TIMING_STATISTICAL        p = 0;
scal:_  puPR_TIMING_TIMESTAMP        p = 1;

scal:_  puPR_Sts_NAME        p = 15;
scal:_  puPR_GET_NAME        p = 16;

scal:_  puPR_GET_ENDIAN        p = 19;
scal:_  puPR_Sts_ENDIAN        p = 20;
scal:_  puPR_ENDIAN_BIG        p = 0;
scal:_  puPR_ENDIAN_LITTLE        p = 1;
scal:_  puPR_ENDIAN_PPC_LITTLE        p = 2;

scal:_  puPR_GET_SECCOMP        p = 21;
scal:_  puPR_Sts_SECCOMP        p = 22;

scal:_  puPR_CAPBSts_READ:       p = 23;
scal:_  puPR_CAPBSts_DROP:       p = 24;

scal:_  puPR_GET_TSC:       p = 25;
scal:_  puPR_Sts_TSC:       p = 26;
scal:_  puPR_TSC_ENABLE        p = 1 p = 26;
scal:_  p = 26;
scal:_al:_  puPR_TIMILED   _NAME_MAX    TSC: cnuSCHED_RR        prHIAEMORY_OBJECTSCHEDULL        p = 17129;l:_  puPR_FP_EXC_PRECDULL        p = 17130  prHIAEMORY_OBJTASKG_FTF       puSS_ONSTACK:       326;
scal:_  puPR_ASKG_FTF       pts_TSC:       p = 31 p = 26;
scal:_ MCE_p = 0x00000080;
3
scal:_  puPR_CAMCE_p =     p         p = 20;
scal:_  puPRMCE_p =  puIPC_RMID        ;
scal:_  puPRMCE_p =  L_NORMAL;
scal:_  puPTHREAD_PRPRMCE_p =   p LY:       p = 26;
scal:_  puPRMCE_p =          p = 2;
scal1 p = 26;
scal:_ MCE_p = EXC_     p = 33;
scaprHIAEMORY_OBJECTSMM        p = 34;
scal:_  puOBJECTSMMMINGRT_T_FM:       p = 26;
scal:_  puPRECTSMMMp = T_FM:       p = 2;
scal:_  puOBJECTSMMMINGRT_DA       p = 0x836;
scal:_  puPRECTSMMMp = DA       p = 0x84;
scal:_  puOBJECTSMMMINGRT_uLOCK_UN        p4;
scal:_  puOBJECTSMMMINGRT_BRR:       p = 6;
scal:_  puOBJECTSMMMBRR:       p = 7;
scal:_  puOBJECTSMMMSYMLINGRTQDN        p = 4;
scal:_ OBJECTSMMMSYML321fedc    as i96;
scal:_  puPRECTSMMMp VLINGRTQDN        p= 9;
scal:_  puPRECTSMMMp VLK        p = 1 <26;
scal:_  puPRECTSMMMAUXVC:       p = 11;
scal:_  puPRECTSMMMpXONE_FS        p = 3;

scal:_  puPR_GET_M_MAXP        p = 13;
scal:_  puPR_GET_M_MAXP     p = 14;
scal:_  ;
scal:_  puMREMAP__SYS_       p = 11 <59616d626;
scal:_  puPRECTS__SYS_ _    tcapub = 10240xffffffffffffffff  ;
scal:_  puMREMAPD      UBP  P_       p = 1136;l:_  puPR_FP_EXC_PD      UBP  P_       p = 1137l:_  puPR_TIMING_TIMEO    F_VSOS     p = 37;
scal:_  pu_SCpuPR_StsO    F_VSOS     p = 37;
9cal:_  puPR_FP_EXC_PREDuAI_ADIR:       p = 40  prHIAEMORY_OBJECTSCHPpuSS_ONSTACK:       4
scal:_  puPR_Sts_PDCHPpuSS_ONSTACK:       41 p = 26;
scal:_ MPX p = 0xcMANAGEmenta rus header

scal:_  puPR_CAMPX p = 0x89MANAGEmenta rus header
scaprHIAEMORY_OBJECTSP_EM_FM:       p = 4 1;

scal:_  puPR_StP_EM_FM:       p = 46
scal:_  puPR_FP_EM_FM_Fm
  = RLIM_INFINITY;

scal:_  pR_FP_EM_FM_FmE:       p = 1 << 0;
cal:_  puPR_CAPBS_AMBIenta rus header
7;cal:_  puPR_CAPBS_AMBIent_IS puIPC_RMID        p = 0;
sca_CAPBS_AMBIent_RA        p = 2;
2  p = 0;
sca_CAPBS_AMBIent_puF_U     p = 0x836;
scal:_  puPRPBS_AMBIent_   p 4MAPPED        p  p = 3;
scal:_QUEU__ME          p = 0o4000;

scal:QUEU__VIRTU          p = 1o4000;

scal:QUEU__PROF p = 2;
scal1 p = 26;
scalTFD     p = 0x20000000;O     p =; = 26;
scalTFD E         p = 00000;O E       ; = 26;
scalTFD QUEU__ABS      p = 138;
sc p = 26;
scalXDR:  C_PRIET FD_  ung,
 = 1024;

scal:XDR:  OND_T  ung,
 = 48;
 0x1000;
scal:_ _ADV_SEC_NO_TRUNC   cstem VuIPC
scal:_  FFER_ALFLKEEPC     p = 14;
scal;

scal:_  puSPLFFER_ALFLKPUNCH_HO    p = 12;
scal
scal:_  puAI_FFER_ALFLKTRINAPSECK:       p = 17;
4;
scal:_  puAI_FFER_ALFLKEN_XCK:       p = 17;
4;= 9;
scal:_  pFFER_ALFLKINSET_DE:       p = 17;
4;2 9;
scal:_  pFFER_ALFLKUN     DE:       p = 17;
4;4
scal:_On Linux,  7;  doesn'tOTO_AH  thish    NOTE,  7;attr does i  Nead.puPTRe stillOTO_AH  itcal:_Linux:_  pt'  These arby  7;  O_NOther platal:ms,puPTand pt'  OTO_ioH      in.hman pagx003000getxattr and setxattr      p = 46EMUTATU     p = 0x8::EMUDA  
scal:_  puTCP_CORIGINALP6 d= 79;
scal:_  pu_SC_THREADIUTF8  tcar,
_p = 0x80000000;
scal:_  puCLOMS   tcar,
_p = 0x000o
scal:_ al:_  puEPOLLONEMFD     p = 0x200u    as i32;

scal:_  puAMFD FER_W puA8;
scal:_ u = 0x0001;
scapuPTt     p = us      in.hp_PID  field of Elf32_Phdr and Elf64_Phdr, which haspuPTt   PID  Elf32Word and Elf64Word respectively. Luckily, bOth of tho   p = u32puPTso we can us  that PID  herenet/adli_;havTO_Ret/    rmattecode    _NU puQIF_TIM  puPTHREAD_PROpuPIP    p = 0x800006;
scaROpDYNAMICF_BLIMITS{
    = 1;
sROpINTERPIF_BTIME {
    = 1;
sROpIDLE  SPACE      = 2;
scaROpSHLpuAFITIME      = 32;
scROpPH= 76IF_TIME    = 32;
scROp     IF_TIM7{
    = 1;
sROpIUM_ILIMITS{
    = 4;
scROpuPO   IF_TIM0x6scal:_  puEPOLLEXCLROpGNU_EH frauQIF_BTIME0x6474e55  puEPOLLEXCLROpGNU_uLOCK_U_BTIME0x6474e551 puEPOLLEXCLROpGNU_REL_XPG_BTIME0x6474e55scapuPTEtherneefinedfin  IDrrmattecode  ETH_P       p = 18;
sc001;s
scal:_  puIPETH_P Pp = 0x80000000;
scalscal:_  puIPETH_P Pp AT= 0x80000000;
sca1scal:_  puIPETH_P IP  p = 0x040000;
scscal:_  puIPETH_P X25  p = 0x040000;
s5scal:_  puIPETH_P ARP  p = 0x040000;
s6scal:_  puIPETH_P BPQ  p = 0x040000;
FFscal:_  puIPETH_P IEEPCp = 0x80000000;
sascscal:_  puIPETH_P IEEPCp AT= 0x80000000;
saa1scal:_  puIPETH_P BATMAN00000    as i32;s5scal:_  puIPETH_P D 0xd000fce2    a60scscal:_  puIPETH_P DNA_DLxd000fce2    a60s1scal:_  puIPETH_P DNA_R0xd000fce2    a60s2scal:_  puIPETH_P DNA_RTxd000fce2    a60s3scal:_  puIPETH_P LATxd000fce2    a60s4scal:_  puIPETH_P DIAGxd000fce2    a60s5scal:_  puIPETH_P CUSTxd000fce2    a60s6scal:_  puIPETH_P SCAxd000fce2    a60s7scal:_  puIPETH_P TEBxd000fce2    a6558scal:_  puIPETH_P RARP  p = 0x0400008035scal:_  puIPETH_P ATALK  p = 0x040000809Bscal:_  puIPETH_P AARP  p = 0x04000080F3scal:_  puIPETH_P 8021Q  p = 0x04000081scscal:_  puIPETH_P IPX  p = 0x0400008137scal:_  puIPETH_P IPC__LOG        0086DDscal:_  puIPETH_P PAUS   p = 12;
scal:808scal:_  puIPETH_P S    p = 0x200;
sc:809scal:_  puIPETH_P W   p = 29;
/   sc:83Escal:_  puIPETH_P AF_I_U_FORCE        p 847scal:_  puIPETH_P AF_I_M_FORCE        p 848scal:_  puIPETH_P ATMMPOAFORCE        p 84cscal:_  puIPETH_P PPPpuSS_FORCE        p 863scal:_  puIPETH_P PPPpS    p = 0x040000 864scal:_  puIPETH_P D__MICTL  p = 0x040000 86cscal:_  puIPETH_P ATMFRIET FD_  ung,
 =8884scal:_  puIPETH_P PAET FD_  ung,
 =888Escal:_  puIPETH_P AOET FD_  ung,
 =88A2scal:_  puIPETH_P 8021ef0123    as i32;8A8scal:_  puIPETH_P 802_EX10123    as i32;8B5scal:_  puIPETH_P T    p = 0x040000088CAscal:_  puIPETH_P 8021eH p = 0x040000088E7scal:_  puIPETH_P AVRP  p = 0x04000088F5scal:_  puIPETH_P 1588  p = 0x04000088F7scal:_  puIPETH_P PRP  p = 0x04000088FBscal:_  puIPETH_P FCOET FD_  ung,
 =89s6scal:_  puIPETH_P TD      p = 0x4000090Dscal:_  puIPETH_P FIP  p = 0x0400008914scal:_  puIPETH_P 80221  p = 0x0400008917scal:_  puIPETH_P     BOCK_UN        p0x90scscal:_  puIPETH_P QINQ1  p = 0x04000091scscal:_  puIPETH_P QINQ2  p = 0x04000092scscal:_  puIPETH_P QINQ3  p = 0x04000093scscal:_  puIPETH_P EDSAFORCE        pDADAscal:_  puIPETH_P     UC   p = 0x080000FBFcal:_  puT_FMT_TH_P 802_3     p = 74;
sca;
s6cal:_  puAI_NUMETH_P 802_3584543    as i32;

scal:_  puAETH_P  X25  p = 0x040000;0s2scal:_  puIPETH_P MAPPED        p = 003scal:_  puIPETH_P 802_2   p = 0x0002;
scal:_  puAI_NUETH_P SNA0000040;
scal:_  p5scal:_  puIPETH_P DDC00000040;
scal:_  p6scal:_  puIPETH_P W_LITT0000040;
scal:_  p7scal:_  puIPETH_P PPPp00000040;
scal:_  p8scal:_  puIPETH_P   CALTALK  p = 0x04000020008;
scal:_  pETH_P CAN00000    as i32000B;
scal:_  pETH_P CANF       p = 0x0004;Dscal:_  puIPETH_P PPPTALK  p = 0x040000201cscal:_  puIPETH_P TR 802_2   p = 0x0002;
s1

scal:_  puAETH_P MOBITEX   p = 0x0002;
s15scal:_  puIPETH_P CE_MAX        p = 62;
s16scal:_  puIPETH_P IRDA       p = 62;
s17scal:_  puIPETH_P ECE_E    p = 0x0002;
s18scal:_  puIPETH_P HDL0x00000008;
scal:19scal:_  puIPETH_P ARC_E    p = 0x0002;
s1Ascal:_  puIPETH_P DSAFORCE        p2001A;
scal:_  pETH_P TRILITRFORCE        p2000B;
scal:_  pETH_P PHE_E    p = 0x0002;
sF5scal:_  puIPETH_P IEEP802154   p = 0x0002;
sF6B;
scal:_  pETH_P CAIF   p = 0x0002;
sF7l:_  puPR_TIMSFD     p = 0x20000000;00;
scal:_ 4;
scal:_  CCS_  puVERASEx1000;
scal:_ ESTRICT_D        p 2;
scal:_  puEPOLLEXCLOMMUTABLE       as i32;
sca
scal:_  puIMAXBE     p = 0x20000000;00;0080;
scal:_  puICRESTMPE_FS        p = 80000000;
sc;
scal:_  pEBFOnta rus header= 157;
scal:_ EYESSTR:  us op rus
scal:_  puIPEMUDA  R:  us op rus

scal:_  puAETBLE       as i362157;
scal:_ EYESTR:  us op rus3157;
scal:_ EYE_E    p = 0x00064scal:_  puIPENOPKGxd000fce2   pu_SC_TYPED_MEEOFOLIET FD_  ung,
66scal:_  puIPENOD__MAX        p = 60;
scal:_  EADV67;
scal:_  pu_SC_THREAD_SESRMnta rus header:_  pu_SC_2_PBECEMM        p = 7  puEPOLLEXCLUSPROT   p = 70;
scal:_  pu_SC_LEDOTD= 0 as ub cuse7al:_  puPOSIX_MA= 0i6FTRFORCE        p0000000;
scal:_  pu_MA=TLB TS:       p = 0x400;
s0000;
scal:_  pu_MA=TLBNGRTQDN        p0;
scal:_  puEPOLLEXCLMA= 0CLDlibc in 2.26    :_  puPTRAC_puEPOLLEXCLUSIVE     p = 0x20000000;00
scal:_ 4;
scal:_ EFD     p = 0x20000000;00
scal:_ 4;
scal:_ BUFSIZ

scal:_  puSY12;
scal:_  puSTMP nl_item = 0x5000
scal:_  puPR_FP_FER_MAX:        0x5000
scacal:_  puICREST        p = 0x800scal:_ acal:_  puICRES p = 0x20000000;O T   cal:_  puICRESSEARCH 0x20000000;O T   cal:_  puICRESACCM_FM:       p = 03 |RESSEARCH puEPOLLEXCLOMMDELTA  p = 00000;O E       ; = 26;
scalNIAX: W       socklen_IP packet
scal:_  pP_KEYS_MAX:       p =puVE_IP pa048_  puPOSIX_FADV_SEQUENTDOnt       p = 2;
sc4;= 0;
scal:_  puRTLD_LAZY EUS   p = 12;
sc5 2;
scal:_  puGLOB_NOMATDOnt       p = 2;
sc4;=IM_SAVED_MAX:   l:_  puRRLIM_INFINITY!0LIM_SAVED_MAX:  IT_RT      p = 138;
sc5 2#[deprecated(sincERAS"0.2.64", notERAS"Not stable across OS versed r")]IM_SAVED_MAX:  IT_N:  IT      p = 15;
sca#[allow(deprecated)]I#[deprecated(sincERAS"0.2.64", notERAS"Not stable across OS versed r")]IM_SAVED_MAX:  _N:  IT      p = 15;X:  IT_N:  IT _  puEPOLLONEMBS_AE  YMO       p = 1;
MBS_AE  
scal:_  puTCP_       p = 29;
/   28;
scal:_  pu_   PAV6  QDN        p= 9;00;
scal:_  puRCOOKIE TRINSA  p = 67;
scal:_  15scal:_  puIP puRTH_LOCIN p 4C_SERVER:       p = 16scal:_  puIP puRTH_LODUPAILES:       p = 16;
scal:_   puRAX:  C_SERVE    p = 17;
scal:_  pu_SC_ puRREPA        p = 0x19scal:_  puIP puRREPA  _UE_MA        p = 19;
scal:_  pu puRUE_MAXSEQ       p = 2;

scal:_  puP puRREPA  _000;
  21;
scal:_  pu_SC_SHARED_M puRFAlibcD:       p = 1

scal:_  puPR puRTCAL        p = 0;
sc

scal:_  puLOG_IGUNAX:D     p = 0x8::_ENAYSl:_  puPTRAC__EOCESS_SHARED       DR:  p = 1;
scal:  puPTHREAD_PROCESS_SHARED   HREADDR:  p = 1;
scal:  puPTHREAD_PROCESS_SHARED   p {
  DR:  p = 1;
scal   prHIAEMORY_CPU puI    p = 14;
scal:    prHIAEMORY_O_SYS_M_SYS_MORMAL;
scal:_  puPTHREAD_PROSYS_MPEEKTME    op russ.
scal:_  puPTRAC__EVEPEEKDA  R:  us op ru2cal:_  puPTRAC__EVEPEEK    p = 0x080000cal:_  puPTRAC__EVENPO6  ME    op russ.
4al:_  puPTRAC__EVENPO6 DA  R:  us op ru5al:_  puPTRAC__EVENPO6     p = 0x080000scal:_  puPTRAC__EVECOnta rus header7cal:_  puPTRAC__EVEp = 0x00000080;
TRAC__O_TRAC_CLONE      LL  EPfedc    as i96;
scal:_  puLONE  GETRE      p = 0x0412cal:_  puPTRAC__EVESETRE      p = 0x04136;
scal:_  puLONE  GETFPRE      p = 0x0414cal:_  puPTRAC__EVESETFPRE      p = 0x0415al:_  puPTRAC__EVENDR:ACH 0x20000000;1scal:_  puPTRAC__EVEDE:ACH 0x20000000;176;
scal:_  puLONE  GETFPXRE      p = 0x0418cal:_  puPTRAC__EVESETFPXRE      p = 0x04196;
scal:_  puLONE  AYSCMAPPED        p24cal:_  puPTRAC__EVESET000;
  21;
scal:_   p02__O_SUSPEND_SECCOMP  GET     MSG21;
scal:_   p02_1O_SUSPEND_SECCOMP  GETSIGINFO21;
scal:_   p02_2cal:_  puPTRAC__EVESETSIGINFO21;
scal:_   p02_36;
scal:_  puLONE  GETRE  E    p = 0x0002;02_4cal:_  puPTRAC__EVESETRE  E    p = 0x0002;02_5cal:_  puPTRAC__EVESE   p = 14;
scal;
02_scal:_  puPTRAC__EVEINTERRUP    p = 0x0002;02_76;
scal:_  puLONE  JECTEN   p = 0x0002;02_8cal:_  puPTRAC__EVEPEEKSIGINFO21;
scal:_   p02_9C_puEPOLLEXCLUSIVEWA6  P        p = 128;

scal:_ 4;
scal:_ EFD E         p = 00000;::O E       ; _  puPR_TIMSFD E         p = 00000;::O E       ; _  puPR_TIMTCSALETE:       p = ;_  puPR_TIMTCSADR_NONAME        1;_  puPR_TIMTCSAFLUSH p = 2;
scal1 p = 26;
scalTIOCINQ  p = 00000;::FILED:ADal:_  puST_NODIRATpuGL          p = 0l:_  puAT_SYMLIN_NODELEuPIP  ;
scal:_   p0_  puEPOLLONEMCL  = RENT584543    as i32;

scal:_  puAMCL FUTUR      p = 0x0001;
scaprHIAEMORY_CBAUDtcar,
_p = 0x000o80;
s= 16;
scal:_   AB1 in 2.26    :_  puP
scscal:_  puIP AB2   p = 0x0002;
sc0
scacal:_  puICR AB3   p = 0x0002;
sc0

scscal:_  puIPCR1 in 2.26    :_  puP2scscal:_  puIPCR2   p = 0x0002;
sc004scscal:_  puIPCR3   p = 0x0002;
sc0s6cal:  puPR_FP_FF1 in 2.26    :_  pu8scacal:_  puICRBS1       as i32;
sca
scal:_  puIMAXBVT1        p = 80000000;
sc_  puIMAXBVWERAS    1;
scal14cal:_  puPTRVREPU      1;
scal12cal:_  puPTRV 0x4   1;
scal1
sc_  puIMAXBVBNGRTQD 1;
scal   _  puIMAXBVBNO4   1;
scal96;
scal:_  pC_NOCARD   1;
scal13l:_  puIMAXBVT      1;
scalket
scal:_  puX   p =ar,
_p = 0x80000004scscal:_  puIPuX 000000ar,
_p = 0x800000
scacal:_  puICRENLC tcar,
_p = 0x000= 0x2;
scal:_ C    p = ar,
_p = 0x8000000scal:_  puERA_DCS6p = ar,
_p = 0x8000000s1al:_  puERA_DCS7p = ar,
_p = 0x8000000s2al:_  puERA_DCS8p = ar,
_p = 0x8000000scal:_  puERA_DCSNO4Bp = ar,
_p = 0x8000000s4cscal:_  puIPCR       ar,
_p = 0x8000000s:_  puPR_FP_EXCARENBp = ar,
_p = 0x8000000:_  puAT_SYMLINCAROD     ar,
_p = 0x80000002scscal:_  puIPHUPEAT   ar,
_p = 0x80000004scscal:_  puIPC  CALT   ar,
_p = 0x8000000
scscal:_  puIPECHO6 T   ar,
_p = 0x8000000
scscal:_  puIPECHOEp = ar,
_p = 0x8000000s1al:_  puERA_DECHO6p = ar,
_p = 0x8000000s2al:_  puERA_DECHONLp = ar,
_p = 0x8000000s4cscal:_  puIPECHOPRTQDN ar,
_p = 0x80000004scscal:_  puIPECHOCTL  p ar,
_p = 0x80000002scscal:_  puIPIG      ar,
_p = 0x8000000s;

scal:_  puAINK_MAX:  ar,
_p = 0x8000000s;2cal:_  puPTRADIANN  tcar,
_p = 0x80000000;
scal:_  puCLNOFLSH p =ar,
_p = 0x8000000s:_  puPR_FP_EXCIBAUDtcar,
_p = 0x000o830;
6l:_ acal:_  puICRCBAUDEX   p,
_p = 0x000o8
scal:_  puPR_FP_VSWTC   1;
scal 16;
scal:_  OLCU_FORC,
_p = 0x000o800001;
scal:_  puYLDLY:   ,
_p = 0x000o8004scscal:_  puIPCRDLY:   ,
_p = 0x000o803scacal:_  puICR ABDLY:   ,
_p = 0x000o814scacal:_  puICRBSDLY:   ,
_p = 0x000o8
scal:_  puPR_FP_FFDLY:   ,
_p = 0x000o;
scal:_  puPR_FP_VTDLY:   ,
_p = 0x000o8al:_  puEPOLLEXCLX ABS:   ,
_p = 0x000o814scacaal:_  puICRB_OLD speed 0x000o80000acal:_  puICRB5_OLD speed 0x000o80000

scal:_  puAB75OLD speed 0x000o800001;
scal:_  puB11_OLD speed 0x000o800003;
scal:_  puB134OLD speed 0x000o800004;
scal:_  puB15_OLD speed 0x000o80000ket
scal:_  pB
scOLD speed 0x000o80000scal:_  puPTRB3scOLD speed 0x000o80000 16;
scal:_  B6scOLD speed 0x000o80001al:_  puERA_DB1
scOLD speed 0x000o80001

scal:_  puAB

scOLD speed 0x000o800011;
scal:_  puB24scOLD speed 0x000o800013;
scal:_  puB4
scOLD speed 0x000o800014;
scal:_  puB96scOLD speed 0x000o80001ket
scal:_  pB19
scOLD speed 0x000o80001scal:_  puPTRB384scOLD speed 0x000o80001 60;
scal:_  EX  R:  speed 0x00B19
sc60;
scal:_  EX BR:  speed 0x00B384sccal:_  puICRB576scOLD speed 0x000o81000

scal:_  puAB1152scOLD speed 0x000o810001;
scal:_  puB2304scOLD speed 0x000o810003;
scal:_  puB4608scOLD speed 0x000o810004cal:_  puICRB5_____OLD speed 0x000o810005cal:_  puICRB576sc_OLD speed 0x000o81000scal:_  puPTRB9216scOLD speed 0x000o81000 16;
scal:_  B
scal:_OLD speed 0x000o81001al:_  puERA_DB1152sc_OLD speed 0x000o810011;
scal:_  puB15_al:_OLD speed 0x000o810012et
scal:_  pB
scal:_OLD speed 0x000o810013;
scal:_  puB25_al:_OLD speed 0x000o810014cal:_  puPTRB3scal:_OLD speed 0x000o810015cal:_  puICRB35_al:_OLD speed 0x000o81001scal:_  puPTRB4scal:_OLD speed 0x000o810017
scal:_  puTCP_CRSIOTT_NOKTYPE:       p = 24;

scal:_ P_CTCAL        p = 0;
sc
924;

scal:_ P_C_ERR:       p = 328;
scal:_  pu__RXQ    LF_NFC        p = 39;
scal:u__PEEKx00000000    as pu_SC_TRAC__EVP_CRUSY_SIVE:       p = 46
s puPTHREAD_PROCESS_SHARED   p {
   p = 1;
scal128;
scal:_  p = pthread_b cex p {
    = 1;
scal:01000;
scal:_ ESECOV        p = 180000004scsc
scal:_  puNOOCLEX   p = 0x0002;5451 puEPOLLEXCLFILEBIO   p = 0x0002;5421;=IM_SAVED_MAX:  IT_RIR:       p = 5LIM_SAVED_MAX:  IT_NOF_FS        p = 7LIM_SAVED_MAX:  IT_A   p = 8;
scal:_  pu_SC_REX:  IT_NRIVAp = 0x080000scal:_  puPTRX:  IT_PED_FILES:       p 81000;
scal:_ ESEP4321fedc    as i3200
scacal:_  puIMAXBE  _PRIVATE    key_px000
scaacal:_  puICRES pCPPED        p = 002l:_  puEPOLLEXCLOMMUCTTY in 2.26    :_  puP2scscal:_  puIPO E         p = 00000;8000000s1al:_  puERA_DO_COV        p = 1800000004s |RESDCOV l:_  puERA_DO_RCOV        p = 1O_COV l:_  puERA_DO_DCOV        p = 180000000scal:_  puAI_ADu_       p = 0x20000000;0o2cal:_  puEPOLLEXCLM_   E         p = 00000;82000;
scal:_  puIPMBS_AE      p = 0x0010;
scalal:_  puIPMBS_GROWSDOWN      p = 0x80;
scalal:_  puIPMBS_DENYpuLIO_READ:      00;
scscal:_  puIPMBS_ p =PEND        p = 0x80;
scascal:_  puIPMBS_            p = 0x0002scascal:_  puIPMBS_GETLB        p = 0o400x000;
scal:_  puCLMBS_POPUL_NORMAL;
scal:_ xu8scacal:_  puICRMBS_GE        p = 00000;8002;

scal:_  puMSG_XP  TOCK_UN        p0x02l:_  ppuEPOLLEXCLM_   AX:   THER:       p = 0;
scal:_ _    I_NAMEREQD:     2 = 0;
scal:_ _   SEQPAV6  QDN        p5 ppuEPOLLEXCLM_L_IPV6    p = 138;
sc p = 26;
scalEDcexLK  p = 0x040035scal:_  puIPEs_NATOOLONG        p = 36scal:_  puIPENOD       p = 17137157;
scal:_ EYESYS     p = 37;
scal:_  pu_SCEIDLEMPTY in 2.26       p = 28;
scaE      p = 18;
sc4
scal:_  puIPEMUMSG21;
scal:_  pu_SC_TRAC__EVEID        p = 94

scal:_  puPRECHR routgng header4scal:_  puIPEL2NCOV        p = 14 1;

scal:_  EL3H   p = 2;
scal46
scal:_  puPEL3RSta rus header
7;cal:_  puPRELNR routgng headerscal:_  pu_SCEUNCHED_RR        p4 157;
scal:_ EYECSI       p = 49;
scal:_  pu_EL2H   p = 2;
scal51 puEPOLLEXCLEBAFM:       p = ;
scal:_  pu_SEBAF p = 0x080000 pu_SC_READER_EXFUVE:       p = 54scal:_  puIPENOAE :       p = 55scal:_  pu_SEBAF Q        p = 1128;
scal:_  pEBAFS   p = 2;
scal57;cal:_  puPREDcexL     p = 00000;EDcexLK;cal:_  puPREMULTIH    p = 18;
sc7
scal:_  pu_SEBAFMSG21;
scal:_  173;
scal:_  pEI_MEMORY:       p = 75cal:_  pu_SCEIDLUNIQ = 75;
scal:_  pu_SC_THREAEBAFF       p = 0xl:_  pu_SC_V6_EOFOCHG77;
scal:_  pu_SC_THREAD_AELIBACCcal:_  pu_SC_THREAD_PRIORIELIBBIP  ;
scal:_  80HREAD_PRIORIELIBSCN= 80;
scal:_  pu_SC_THREADELIB_MAX:       p = 2pu_SC_THREADELIB p = 0x20000000;cal:_  pu_SC_TEILSEQ       p = 284scal:_  puIPETLBNGRTQDN        p4;
scal:_  pu_X   PIT        p = 1
scal:_  pu_SC     S       p = 86;
scal:_  pu_EIDLF_NFC        p = 87;
scal:_  pEAX  AI_AREQ       p = 28THREAD_PRIORIEMSG    p = 14;
scal9  puEPOLLEXCLUSPROTAMILY        p =0;
scal:_  pu_ENOPPROTO        p = 91;
scal:_  pu_SUSPROTST_RPPK        p = 1 cal:_  pu_SC_XEAI_FAST_RPPK        p = 1 c73;
scal:_  pEIPIDLFUT0000040;
scal95cal:_  pu_SCEIDLS P        p = EIPIDLFUT0scal:_  pu_SUSFST_RPPK        p = 1 c= -4;
scal:_  pFST_RPPK        p = 1 c 60;
scal:_  EADDRINUS   p = 12;
sc9860;
scal:_  EADDRIDLAVAI_AGAIN:      9 157;
scal:_ EYETDOWN      p = 0x1scscal:_  puIPEYETUED:ACH 0x20000000;1;

scal:_  puAENETREpuIPC_RMID      s2scal:_  puIPECIVE _NOSPAC_        p 103scal:_  puIPECIVEREpuIPC_RMID      s4scal:_  puIPENOBUFSPC_RMID      s5cal:_  pu_SCEISCIVEPC_RMID      s6scal:_  puIPENOTCIVEPC_RMID      s 60;
scal:_  ESHUTDOWN      p = 0x1s8scal:_  puIPETOOMANYREFSPC_RMID      s9
scal:_  puAETBLEDRVE    p = 17;
s1al:_  puERA_DECIVEREFAX:D     p = 0x811

scal:_  puAEW   DOWN      p = 0x112et
scal:_  pEW   UED:ACH 0x20000000;11 = -2;
scal:_  L cexY:       p = 214scal:_  puIPEINRIVGADIR:       p = 11;
scal:_  pu_X  AFS        p = 316scal:_  puIPEU   pN      p = 0x11;
scal:_  pu_EIDLN  THER:       p18scal:_  puIPENAVAI_AGAIN:      119scal:_  puIPEISN  THER:       p2al:_  puERA_DEOFOLIEIG_STAT        pal:_  pu_SC_LEDQU= 0 as ub cuse122157;
scal:_ EYELEDIU THER:       p2 = -2;
scal:_ LEDIU AMILY        p =124cal:_  puPTREANCELED        p = 0;25cal:_  pu_SCEIDKEY = 125;
scal:_  pu_SC_XBS5_EKEYEXPI   p = 0;
scal:_TIMILED   _NAMEKEYREVOK  p = 0;
scal:_T8MILED   _NAMEKEYRE p =  p = 0;
scal:_T9scal:_  puIPEOWNERD        p = 22;cal:_  pu_SC_XOEIDLD:   ER_TSC:       p = 2326;
scal:_  pMEMp = 0x00000080;
SCTP
scal:_  puEHWPOIS   p = 133;
scal3
scal:_  puTCP_C EUS p = 76;
scal:_  u_SC_TRAC__EVP_CAMILY        p =3_SC_TRAC__EVP_CG_INFO:       p =4_SC_TRAC__EVP_CDE_MAXUTE:       p = 5LIM_SAVED_MAP_CRROADCASta rus header28;
scal:_  pu__SNDBUF        p = 7LIM_SAVED_MAP_C CVBUF        p = 8LIM_SAVED_MAP_CEEPCALx45584543    as924;

scal:_ P_COOBINCIN QDN        p= 9;
scal:_  pSO E _FS        p = 1 <<1 = 39;
scal:u__PRIORITY    p = 0x0412cal:_  puPTRu__8;
sp = 181;
scal:_3_SC_TRAC__EVP_CBSDOMP IPC_INFO:      4_SC_TRAC__EVP_C EUS PK        p = 1 15LIM_SAVED_MAP_C = 0C   p = 0;
scal:_6 = 39;
scal:u__PEERC   p = 0;
scal:_7LIM_SAVED_MAP_C CVORYAE    p = 17;
scal:_  pu_SC_u__SNDORYAE    p = 17;
s9LIM_SAVED_MAP_C CVC_SER        p = 19;
scal:_  puu__SNDC_SER        p = 11 = 39;
scal:u__ACCEPTCIVEPC_RMID     308;
scal:_  pu__SNDBUFFORCC:       p = 31 pM_SAVED_MAP_C CVBUFFORCC:       p = 33 = 39;
scal:u__PRROTCX        p = 638_SC_TRAC__EVP_CDEM_NONAME        
9cal:_  puPR_FSA_ON TOCK_UN        p0x08cal:_  puEPOLLEXCLMA=SIGINFO21;
scal:_   p00000s;4 puEPOLLEXCLMA= 0CLD puLIO_NOP       000000s;2caal:_  puLOG_IGCHL p = 0;
scal:_7LIM_SAVED_MAPNT        p = 1;
7LIM_SAVED_MAPNTTTNONAME        11 = 39;
scal:uNTTTOU21;
scal:_  pu_SC_SHARED_MuNTXCPUPED        p24cal:_  puPTRuNTXFSZPE:       p = 24;

scal:_ PIGV AF        p = 94_  pu_SC_XBS5_PIGPROF p = 2;
scal17LIM_SAVED_MAPNTWINCH 0x20000000;= 64;
scal:_  pIGUSR1 in 2.26    = 9;
scal:_  pSIGUSR2    p = 0x0412cal:_  puPTRuIGCOnta rus header1 64;
scal:_  pIGlibc in 2.26    s9LIM_SAVED_MAPNTTSw/ class negoti 9;
scal:_  pSIGURG       p = 1

scal:_  puPRSIGIO   p = 0;
sc
924;

scal:_ PENAYSTACK:       326;
scal:_  ppIGliKF   p = 2;
scal1  pu_SC_XBS5_PIGPIVE:       p = 
924;

scal:_ PENPWRPC_RMID     308;
scal:_  puIGESETMAS = 1;
scal:_  puPTHREAD_MUuIGE       p = 00000;8000000spuPTHREAD_MUuIGEU        p = 00000;8002 p = 26;
scalEXTRIVAp = ar,
_p = 0x80000;
scal:_  puSHM_NO_XP M_UNLOCK:       p = 0;
scal:_ p = 3;
scal:UNLOK_UN        p4;
scal:_  pul:UNLOWN      p = 0x9;
scal:_  pul:SNLOK_UN        p6;
scal:_  pul:SNLOKW     p = 1;
7LIM_SAVED_MAl:SNLOWN      p = 0x81000;
scal:_ VEOF p 1;
scal:  puPTHREAD_VEOL   1;
scal11  puPTHREAD_VEOL2   1;
scal16;
scal:_  puV    p 1;
scalscal:_  puIPPREXTEN  tcar,
_p = 0x8000008scacal:_  puICRTOlibc in ar,
_p = 0x8000000:_  puAT_SYMLINFLUSHO0000ar,
_p = 0x800000
scaca_  puPR_TIMTCG        p = 2352;5401;_  puPR_TIMTCS        p = 2352;5402;_  puPR_TIMTCS   W     p = 2352;5403;_  puPR_TIMTCS   F     p = 2352;540;
scal:_  puSTCG  A     p = 2352;5405;_  puPR_TIMTCS  A     p = 2352;5406;_  puPR_TIMTCS  AW     p = 2352;5407;_  puPR_TIMTCS  AF     p = 2352;540cal:_  pu_SC_ pSBRR:       p = 2;5409scal:_  puIP pXOV        p = 180540Ascal:_  puIP pFLSH p =   p = 1805401A;
scal:_  pTIOCGSOFTCA       p = 11 <5419scal:_  puIP IOCSSOFTCA       p = 11 <541Ascal:_  puIP IOC8;
UX   p = 0x0002;5400B;
scal:_  pTIOCGSERI          p = 0l540EB;
scal:_  pTIOC pCPPED        p =5400B;
scal:_  pTIOCNpCPPED        p =540Dscal:_  puIP IOCSCTTY in 2.26    :_540EB;
scal:_  pTIOCGPGRP  p = 0x040000540Fscal:_  puIP IOCSPGRP  p = 0x04000054= 9;
scal:_  p IOCXUTQ  p = 0x04000054=1scal:_  puIP IOCSTI  p = 0x04000054=2B;
scal:_  pTIOCGWINSZPE:       p 0054=3scal:_  puIP IOCSWINSZPE:       p 0054=4scal:_  puIP IOCMGE    p = 0x0002;54=5scal:_  puIP IOCMBI      p = 2352;5416scal:_  puIP IOCMBI        p = 18054= 16;
scal:_   IOCMSE    p = 0x0002;54=8 puEPOLLEXCLFILEIO_ALLDONE       ;54=1A;
scal:_  pTIOCC
  21;
scal:_   p54=D 2;
scal:_  puGLLWRMUTE21;
scshorp = 0l:_  puAT_SYMLINuGLLWRB:       pshorp = 0l = 0o400;
scal:_ IOCM_FS        p = 80001scal:_  puIP IOCM_DTRFORCE        p202scal:_  puIP IOCM_R       p = 2352;s;4 puEPOLLEXCL IOCM_     p = 0x0002;
s8 puEPOLLEXCL IOCM_ R  p = 00000;8002; puEPOLLEXCL IOCM_C       p = 2352;s2; puEPOLLEXCL IOCM_CA       p = 11 <s4cscal:_  puIP IOCM_RNG_UN        p0x08cscal:_  puIP IOCM_D R  p = 00000;80:_  puAT_SYMLIN IOCM_CALLDONE       IOCM_CA scal:_  puIP IOCM_RILLDONE       IOCM_RNG1000;
scal:_ ESDID: TERVIC_        p:_  p8l:_  puEPOLLEXCLOMDID: T in 2.26    :_  puP
scscal:_  puIP__8ARGEE_FS        p = 8000001:_  puEPOLLEXCLOMMUFIVE:W  p = 00000;8000000s8 0o400;
scal:_M_UNLOC_V    enc_FM_SHIFTF_BLIMITS6;_  puSHM_NO_XP M_UN_SHIFTF_BLIMITS6;_puPT000TO_ioHally not0; _lic, only us   3000fd_set
cfg_ifuTCP_MD5if #[cfg(target_po000Tr_widthRAS"32")]ER: pthreadSHM_NOULONG     p  puVERASEx10 ng,
 else5if #[cfg(target_po000Tr_widthRAS"64")]ER: pthreadSHM_NOULONG     p  puVERAS64sc ng,
 else5R: pthreaduPTUnknown target_po000Tr_widthc ng,

}apuPTEND_PUBECOnST

fuTCP_MD5SIG fn FD   R(fd  p = 000, setES:    fd_set) -> ()5R: pthreadle  fdRASfdRas  puVE;: pthreadle  puVERAS::mem =puVE_of_val(&(*set).fds_bits[0]) *x810 pthread(*set).fds_bits[fdR/ puVE] &= !(1 << (fd % puVE))10 pthreadreturnc ng,

P_MD5SIG fn FD ISSE (fd  p = 000, setES:SHM_NOfd_set) -> bool5R: pthreadle  fdRASfdRas  puVE;: pthreadle  puVERAS::mem =puVE_of_val(&(*set).fds_bits[0]) *x810 pthreadreturn ((*set).fds_bits[fdR/ puVE] & (1 << (fd % puVE))) !0;8c ng,

P_MD5SIG fn FD SE (fd  p = 000, setES:    fd_set) -> ()5R: pthreadle  fdRASfdRas  puVE;: pthreadle  puVERAS::mem =puVE_of_val(&(*set).fds_bits[0]) *x810 pthread(*set).fds_bits[fdR/ puVE] |= 1 << (fd % puVE)10 pthreadreturnc ng,

P_MD5SIG fn FD EN_X(setES:    fd_set) -> ()5R: pthread3000slot0ind(*set).fds_bits.i0Tr_   ()5R: pthreaddddd*slot0 = ;_readdddd}c ng,

P_MD5SIG fn CPU EN_X(cpusetES&    cpu_set_t) -> ()5R: pthread3000slot0indcpuset.bits.i0Tr_   ()5R: pthreaddddd*slot0 = ;_readdddd}c ng,

P_MD5SIG fn CPU SE (cpup  puVE, cpusetES&    cpu_set_t) -> ()5R: pthreadle  puVE 00_bits: pthreaddddd0x8 *x::mem =puVE_of_val(&cpuset.bits[0]);duPT32,S64 etc: pthreadle  (idx, offset) = (cpuR/ puVE 00_bits, cpu % puVE 00_bits)10 pthreadcpuset.bits[idx] |= 1 << offset10 pthread()c ng,

P_MD5SIG fn CPU   R(cpup  puVE, cpusetES&    cpu_set_t) -> ()5R: pthreadle  puVE 00_bits: pthreaddddd0x8 *x::mem =puVE_of_val(&cpuset.bits[0]);duPT32,S64 etc: pthreadle  (idx, offset) = (cpuR/ puVE 00_bits, cpu % puVE 00_bits)10 pthreadcpuset.bits[idx] &= !(1 << offset)10 pthread()c ng,

P_MD5SIG fn CPU ISSE (cpup  puVE, cpusetES&cpu_set_t) -> bool5R: pthreadle  puVE 00_bitsd0x8 *x::mem =puVE_of_val(&cpuset.bits[0]);: pthreadle  (idx, offset) = (cpuR/ puVE 00_bits, cpu % puVE 00_bits)10 pthread0 !0;(cpuset.bits[idx] & (1 << offset))c ng,

P_MD5SIG fn CPU EQUAL(set1ES&cpu_set_t, set2ES&cpu_set_t) -> bool5R: pthreadset1.bitsd0= set2.bits: pth

P_MD5SIG fn major(dev  p dev_t) ->      0x50R: pthreadle      major0 = ;_readddddmajor0|= (dev & 2;
scal:_ 
scaff00) >>x810 pthreadmajor0|= (dev & 2;fffff
scal:_ 
sc) >>xEx10 ng,readmajor0as      0x5: pth

P_MD5SIG fn minor(dev  p dev_t) ->      0x50R: pthreadle      minor0 = ;_readddddminor0|= (dev & 2;
scal:_ 
sc
scaf) >>x ;_readddddminor0|= (dev & 2;
scalffffff
scal) >>x12;_readddddminor0as      0x5: pth

P_MD5SIG fn CG_EXDA  (cmsgES:SHM_NOcmsghdr) -> :       charER: pthreadSmsg.offset(1)
scal:_     char: pth

P_MD5SIG fn CG_EXNXTHDR(mhdrES:SHM_NOmsghdr, cmsgES:SHM_NOcmsghdr): pthread-> :     msghdr: pthR: pthreadif ((* msg). msg_len0as   puVE_I) <x::mem =puVE_of::< msghdr>()5R: pthreaddddd

scal:_   msghdr: pth ng,
 else5if __CG_EXNEXT( msg).add(::mem =puVE_of::< msghdr>()): pthreaddddd>= __MHDRLK  (mhdr)5R: pthreaddddd

scal:_   msghdr: pth ng,
 else5R: pthreaddddd__CG_EXNEXT( msg).    ()_readdddd}c ng,

P_MD5SIG fn CG_EXFIRSTHDR(mhdrES:SHM_NOmsghdr)d-> :     msghdrhR: pthreadif (*mhdr).msg_SHMtrollen0as   puVE_Id>= ::mem =puVE_of::< msghdr>()5R: pthreaddddd(*mhdr).msg_SHMtrol.    ()_readdddd} else5R: pthreaddddd

scal:_   msghdr: pth ng,
c ng,

P_MD5SIG {SHM_N} fn CG_EXN_NOP(len:   puVE_I) ->   puVE_IdR: pthread(len + ::mem =puVE_of::<  puVE_I>()5- 1): pthreaddddd& !(::mem =puVE_of::<  puVE_I>()5- 1): pth

P_MD5SIG {SHM_N} fn CG_EXSPACE(len:      0x5) ->      0x50R: pthread(CG_EXN_NOP(len0as   puVE_I) + CG_EXN_NOP(::mem =puVE_of::< msghdr>())): pthreadddddas      0x5: pth

P_MD5SIG {SHM_N} fn CG_EXLEN(len:      0x5) ->      0x50R: pthread(CG_EXN_NOP(::mem =puVE_of::< msghdr>()) + len0as   puVE_I) as      0x5: pth



Psafe_fuTCP_MD5SIG {SHM_N} fn WIFlibcPED(status  p = 000) -> bool5R: pthread(status & 2;ff)d0= 0x7f: pth

P_MD5SIG {SHM_N} fn WlibcSIG(status  p = 000) -> p = 0000R: pthread(status >>x8) & 2;ff: pth

P_MD5SIG {SHM_N} fn WIFCOntINUED(status  p = 000) -> bool5R: pthreadstatus =240xffff: pth

P_MD5SIG {SHM_N} fn WIFSIGNALED(status  p = 000) -> bool5R: pthread((status & 2;7f) + 1)
scai8d>= 2: pth

P_MD5SIG {SHM_N} fn WTERMSIG(status  p = 000) -> p = 0000R: pthreadstatus & 2;7f: pth

P_MD5SIG {SHM_N} fn WIFEXITED(status  p = 000) -> bool5R: pthread(status & 2;7f)d0= 0: pth

P_MD5SIG {SHM_N} fn WEXITING US(status  p = 000) -> p = 0000R: pthread(status >>x8) & 2;ff: pth

P_MD5SIG {SHM_N} fn WCOREUMPA(status  p = 000) -> bool5R: pthread(status & 2;80) !0;8c ng,

P_MD5SIG {SHM_N} fn QCMD( md  p = 000, PID _  p = 000) -> p = 0000R: pthread( md << 8) | (PID _ & 2;
sff)c ng,

P_MD5SIG {SHM_N} fn makedev(major:      0x5,dminor:      0x5) ->   dev_t0R: pthreadle   ajor0 =major0as   dev_t;: pthreadle  minor0 =minor0as   dev_t;: pthreadle  mutOTOv0 = ;_readddddTOv0|= (major0& 2;
scalfff) << 8;_readddddTOv0|= (major0& 2;fffff
sc) << Ex10 ng,readTOv0|= (minor0& 2;
scal:ff) << 010 ng,readTOv0|= (minor0& 2;ffffff
s) << 1x10 ng,readTOv: pth



Pfn __CG_EXLEN(cmsgES:SHM_NOcmsghdr) ->   ppuVE_IdR: pth((unsafe { (* msg). msg_len0as   puVE_Id} + ::mem =puVE_of::<  c_ = 1>()5- 1): pthread& !(::mem =puVE_of::<  c_ = 1>()5- 1)) as   ppuVE_I


Pfn __CG_EXNEXT( msgES:SHM_NOcmsghdr) -> :       charER: pth(unsafe { Smsg.offset(__CG_EXLEN(cmsg)) })
scal:_     char:

Pfn __MHDRLK  (mhdrES:SHM_NOmsghdr)d-> :       charER: pthunsafe { (*mhdr).msg_SHMtrol.offset((*mhdr).msg_SHMtrollen0as ipuVE) }.    ()_}apuPTEXTERN_FN

#[link(namERAS"c")]I#[link(namERAS"fdio")]Iextern "C" {}

#[cfg_attr(featurERAS"extra_traits",dTOrive(Debug))]IM_SAenum E_FS {}
impl   Copyd3000E_FS {}
impl   C = ed3000E_FS {: pthfn c = e(&self)d-> E_FS {: pthdddd*self: pth



#[cfg_attr(featurERAS"extra_traits",dTOrive(Debug))]IM_SAenum fpos_IdR}duPTFIX    fillOthisho   with adstruct
impl   Copyd3000fpos_IdR}
impl   C = ed3000fpos_IdR: pthfn c = e(&self)d-> fpos_IdR: pthdddd*self: pth



Iextern "C" {P_MD5SIG fn isalnum(c: = 000) -> = 000;P_MD5SIG fn isalpha(c: = 000) -> = 000;P_MD5SIG fn iscMtrl(c: = 000) -> = 000;P_MD5SIG fn isdigit(c: = 000) -> = 000;P_MD5SIG fn isgraph(c: = 000) -> = 000;P_MD5SIG fn islower(c: = 000) -> = 000;P_MD5SIG fn ispr000(c: = 000) -> = 000;P_MD5SIG fn ispunc0(c: = 000) -> = 000;P_MD5SIG fn isspace(c: = 000) -> = 000;P_MD5SIG fn isupper(c: = 000) -> = 000;P_MD5SIG fn isxdigit(c: = 000) -> = 000;P_MD5SIG fn isblank(c: = 000) -> = 000;P_MD5SIG fn tolower(c: = 000) -> = 000;P_MD5SIG fn toupper(c: = 000) -> = 000;P_MD5SIG fn fopen(filenamEES:SHM_NOc_char,dmodEES:SHM_NOc_char)d-> :    E_FS;P_MD5SIG fn freopen(filenamEES:SHM_NOc_char,dmodEES:SHM_NOc_char, file: :    E_FS)d-> :    E_FS;P_MD5SIG fn fflush(file: :    E_FS)d-> = 000;P_MD5SIG fn fc =se(file: :    E_FS)d-> = 000;P_MD5SIG fn remove(filenamEES:SHM_NOc_char)d-> = 000;P_MD5SIG fn renamE(oldnamEES:SHM_NOc_char,dnewnamEES:SHM_NOc_char)d-> = 000;P_MD5SIG fn tmpfile()d-> :    E_FS;P_MD5SIG fn setvbuf(stream: :    E_FS, buffer: :      char,dmodEES= 000, suVE: puVE_I) -> = 000;P_MD5SIG fn setbuf(stream: :    E_FS, buf: :      char);P_MD5SIG fn getchar() -> = 000;P_MD5SIG fn putchar(c: = 000) -> = 000;P_MD5SIG fn fgetc(stream: :    E_FS) -> = 000;P_MD5SIG fn fgets(buf: :      char,dnES= 000, stream: :    E_FS) -> :      char;P_MD5SIG fn fputc(c: = 000, stream: :    E_FS) -> = 000;P_MD5SIG fn fputs(sES:SHM_NOc_char,dstream: :    E_FS) -> = 000;P_MD5SIG fn puts(sES:SHM_NOc_char) -> = 000;P_MD5SIG fn ungetc(c: = 000, stream: :    E_FS) -> = 000;P_MD5SIG fn fread(ptr: :      dli_, suVE: puVE_I, nobj: puVE_I, stream: :    E_FS) -> puVE_I;P_MD5SIG fn fwrite(ptr: :SHM_NOc_dli_, suVE: puVE_I, nobj: puVE_I, stream: :    E_FS) -> puVE_I;P_MD5SIG fn fseek(stream: :    E_FS, offset: =  = 1, whence: = 000) -> = 000;P_MD5SIG fn ftell(stream: :    E_FS) -> =  = 1;P_MD5SIG fn rewind(stream: :    E_FS);P_MD5SIG fn fgetpos(stream: :    E_FS, ptr: :    fpos_I) -> = 000;P_MD5SIG fn fsetpos(stream: :    E_FS, ptr: :SHM_NOfpos_I) -> = 000;P_MD5SIG fn feof(stream: :    E_FS) -> = 000;P_MD5SIG fn ferror(stream: :    E_FS) -> = 000;P_MD5SIG fn perror(sES:SHM_NOc_char);P_MD5SIG fn atof(sES:SHM_NOc_char) -> = double;P_MD5SIG fn atoi(sES:SHM_NOc_char) -> = 000;P_MD5SIG fn atol(sES:SHM_NOc_char) -> =  = 1;P_MD5SIG fn atoll(sES:SHM_NOc_char) -> =  = 1 = 1;P_MD5SIG fn strtod(sES:SHM_NOc_char,dendp: :    :      char) -> = double;P_MD5SIG fn strtof(sES:SHM_NOc_char,dendp: :    :      char) -> = float;P_MD5SIG fn strtol(sES:SHM_NOc_char,dendp: :    :      char, base: = 000) -> =  = 1;P_MD5SIG fn strtoll(sES:SHM_NOc_char,dendp: :    :      char, base: = 000) -> =  = 1 = 1;P_MD5SIG fn strtoul(sES:SHM_NOc_char,dendp: :    :      char, base: = 000) -> = u = 1;P_MD5SIG fn strtoull(sES:SHM_NOc_char,dendp: :    :      char, base: = 000) -> = u = 1 = 1;P_MD5SIG fn calloc(nobj: puVE_I, suVE: puVE_I) -> :      dli_;P_MD5SIG fn malloc(suVE: puVE_I) -> :      dli_;P_MD5SIG fn realloc(p: :      dli_, suVE: puVE_I) -> :      dli_;P_MD5SIG fn free(p: :      dli_);P_MD5SIG fn abort() -> !;P_MD5SIG fn exit(status  = 000) -> !;P_MD5SIG fn _exit(status  = 000) -> !;P_MD5SIG fn atexit(cb: extern "C" fn()) -> = 000;P_MD5SIG fn system(sES:SHM_NOc_char) -> = 000;P_MD5SIG fn getenv(sES:SHM_NOc_char) -> :      char;PP_MD5SIG fn strcpy(dst: :      char,dsrcES:SHM_NOc_char) -> :      char;P_MD5SIG fn strncpy(dst: :      char,dsrcES:SHM_NOc_char,dnESpuVE_I) -> :      char;P_MD5SIG fn strcat(sES:      char,dctES:SHM_NOc_char) -> :      char;P_MD5SIG fn strncat(sES:      char,dctES:SHM_NOc_char,dnESpuVE_I) -> :      char;P_MD5SIG fn strcmp(csES:SHM_NOc_char,dctES:SHM_NOc_char) -> = 000;P_MD5SIG fn strncmp(csES:SHM_NOc_char,dctES:SHM_NOc_char,dnESpuVE_I) -> = 000;P_MD5SIG fn strcoll(csES:SHM_NOc_char,dctES:SHM_NOc_char) -> = 000;P_MD5SIG fn strchr(csES:SHM_NOc_char,dc  = 000) -> :      char;P_MD5SIG fn strrchr(csES:SHM_NOc_char,dc  = 000) -> :      char;P_MD5SIG fn strspn(csES:SHM_NOc_char,dctES:SHM_NOc_char) -> puVE_I;P_MD5SIG fn strcspn(csES:SHM_NOc_char,dctES:SHM_NOc_char) -> puVE_I;P_MD5SIG fn strdup(csES:SHM_NOc_char) -> :      char;P_MD5SIG fn strpbrk(csES:SHM_NOc_char,dctES:SHM_NOc_char) -> :      char;P_MD5SIG fn strstr(csES:SHM_NOc_char,dctES:SHM_NOc_char) -> :      char;P_MD5SIG fn strlen(csES:SHM_NOc_char) -> puVE_I;P_MD5SIG fn strnlen(csES:SHM_NOc_char,dmaxlen: puVE_I) -> puVE_I;P_MD5SIG fn strerror(n  = 000) -> :      char;P_MD5SIG fn strtok(sES:      char,dtES:SHM_NOc_char) -> :      char;P_MD5SIG fn strxfrm(sES:      char,dctES:SHM_NOc_char,dnESpuVE_I) -> puVE_I;P_MD5SIG fn wcslen(buf: :SHM_NOwchar_I) -> puVE_I;P_MD5SIG fn wcstombs(dest: :      char,dsrcES:SHM_NOwchar_I,dnESpuVE_I) ->   puVE_I;PP_MD5SIG fn memchr(cx: :SHM_NOc_dli_, c: = 000, n: puVE_I) -> :      dli_;P_MD5SIG fn wmemchr(cx: :SHM_NOwchar_I,dc: wchar_I,dnESpuVE_I) -> :    wchar_I;P_MD5SIG fn memcmp(cx: :SHM_NOc_dli_, ct: :SHM_NOc_dli_, nESpuVE_I) -> = 000;P_MD5SIG fn memcpy(dest: :      dli_, srcES:SHM_NOc_dli_, nESpuVE_I) -> :      dli_;P_MD5SIG fn memmove(dest: :      dli_, srcES:SHM_NOc_dli_, nESpuVE_I) -> :      dli_;P_MD5SIG fn memset(dest: :      dli_, c: = 000, n: puVE_I) -> :      dli_;PP_MD5SIG fn abs(i: = 000) -> = 000;P_MD5SIG fn labs(i: =  = 1) -> =  = 1;P_MD5SIG fn rand() -> = 000;P_MD5SIG fn srand(seed: =  0x5);PP_MD5SIG fn getpwnam(namEES:SHM_NO  c_char) -> :    passwd;P_MD5SIG fn getpwuid(uid:   uid_I) -> :    passwd;PP_MD5SIG fn fpr000f(stream: :    ::FIFS, al:matES:SHM_NO  c_char, ...) -> p = 000;P_MD5SIG fn pr000f(al:matES:SHM_NO  c_char, ...) -> p = 000;P_MD5SIG fn snpr000f(s: :    ::c_char,dnES  puVE_I, al:matES:SHM_NO  c_char, ...) -> p = 000;P_MD5SIG fn spr000f(s: :    ::c_char,dal:matES:SHM_NO  c_char, ...) -> p = 000;P_MD5SIG fn fscanf(stream: :    ::FIFS, al:matES:SHM_NO  c_char, ...) -> p = 000;P_MD5SIG fn scanf(al:matES:SHM_NO  c_char, ...) -> p = 000;P_MD5SIG fn sscanf(sES:SHM_NO  c_char, al:matES:SHM_NO  c_char, ...) -> p = 000;P_MD5SIG fn getchar_unlocked() -> p = 000;P_MD5SIG fn putchar_unlocked(c  p = 000) -> p = 000;PP_MD5SIG fn socket(domain  p = 000, PI  p = 000, inedfin   p = 000) -> p = 000;P_MD5SIG fn connect(socket  p = 000, addressES:SHM_NOsockaddr, len: pocklen_I) -> p = 000;P_MD5SIG fn listen(socket  p = 000, backlog  p = 000) -> p = 000;P_MD5SIG fn accept(socket  p = 000, addressES:    sockaddr, address_len: :    socklen_I) -> p = 000;P_MD5SIG fn getpeernamE(: pthreadsocket  p = 000,: pthreadaddressES:    sockaddr,: pthreadaddress_len: :    socklen_I,: pth) -> p = 000;P_MD5SIG fn getsocknamE(: pthreadsocket  p = 000,: pthreadaddressES:    sockaddr,: pthreadaddress_len: :    socklen_I,: pth) -> p = 000;P_MD5SIG fn setsockopt(: pthreadsocket  p = 000,: pthreadlevel  p = 000,: pthreadnamEESp = 000,: pthreadvaluEES:SHM_NO  c_dli_,: pthreadoption_len: pocklen_I,: pth) -> p = 000;P_MD5SIG fn socketpair(: pthreaddomain  p = 000,: pthreadPID _  p = 000,: pthreadinedfin   p = 000,: pthreadsocket_vector: :    ::c_000,: pth) -> p = 000;P_MD5SIG fn sendto(: pthreadsocket  p = 000,: pthreadbuf: :SHM_NO  c_dli_,: pthreadlen:   puVE_I,: pthread,
_ps  p = 000,: pthreadaddrES:SHM_NOsockaddr,: pthreadaddrlen: pocklen_I,: pth) -> p spuVE_I;P_MD5SIG fn shutdown(socket  p = 000, how  p = 000) -> p = 000;PP_MD5SIG fn chmod(pathES:SHM_NOc_char,dmodEESmodE_I) -> p = 000;P_MD5SIG fn fchmod(fd  p = 000, modEESmodE_I) -> p = 000;PP_MD5SIG fn fstat(fildes  p = 000, buf: :    stat) -> p = 000;PP_MD5SIG fn mkdir(pathES:SHM_NOc_char,dmodEESmodE_I) -> p = 000;PP_MD5SIG fn stat(pathES:SHM_NOc_char,dbuf: :    stat) -> p = 000;PP_MD5SIG fn pc =se(stream: :    ::FIFS) -> p = 000;P_MD5SIG fn fdopen(fd  p = 000, modEES:SHM_NOc_char) -> :    ::FIFS;P_MD5SIG fn fileno(stream: :    ::FIFS) -> p = 000;PP_MD5SIG fn open(pathES:SHM_NOc_char,do,
_p  p = 000, ...) -> p = 000;P_MD5SIG fn creat(pathES:SHM_NOc_char,dmodEESmodE_I) -> p = 000;P_MD5SIG fn fcntl(fd  p = 000,  md  p = 000, ...) -> p = 000;PP_MD5SIG fn opendir(dirnamEES:SHM_NOc_char)d-> :    ::DIR;P_MD5SIG fn readdir(dirp: :    ::DIR)d-> :    ::dire00;P_MD5SIG fn readdir_r(dirp: :    ::DIR,dentry: :    ::dire00, result: :    :    ::dire00): pthread-> p = 000;P_MD5SIG fn c =sedir(dirp: :    ::DIR)d-> p = 000;P_MD5SIG fn rewinddir(dirp: :    ::DIR);PP_MD5SIG fn openat(dirfd  p = 000, pathnamEES:SHM_NO  c_char,d,
_ps  p = 000, ...) -> p = 000;P_MD5SIG fn fchmodat(: pthreaddirfd  p = 000,: pthreadiathnamEES:SHM_NO  c_char,_readddddmodEES::modE_I,: pthread,
_ps  p = 000,: pth) -> p = 000;P_MD5SIG fn fchown(fd  p = 000, owner:   uid_I, group:   gid_I) -> p = 000;P_MD5SIG fn fchownat(: pthreaddirfd  p = 000,: pthreadiathnamEES:SHM_NO  c_char,_readddddowner:   uid_I,_readddddgroup:   gid_I,: pthread,
_ps  p = 000,: pth) -> p = 000;P_MD5SIG fn fstatat(: pthreaddirfd  p = 000,: pthreadiathnamEES:SHM_NO  c_char,_readddddbuf: :    stat,: pthread,
_ps  p = 000,: pth) -> p = 000;P_MD5SIG fn linkat(: pthreadolddirfd  p = 000,: pthreadoldpathES:SHM_NO  c_char,_readddddnewdirfd  p = 000,: pthreadnewpathES:SHM_NO  c_char,_readdddd,
_ps  p = 000,: pth) -> p = 000;P_MD5SIG fn mkdirat(dirfd  p = 000, pathnamEES:SHM_NO  c_char,dmodEES::modE_I)d-> p = 000;P_MD5SIG fn readlinkat(: pthreaddirfd  p = 000,: pthreadiathnamEES:SHM_NO  c_char,_readddddbuf: :      c_char,_readddddbufpuV:   puVE_I,: pth) -> p spuVE_I;P_MD5SIG fn renamEat(: pthreadolddirfd  p = 000,: pthreadoldpathES:SHM_NO  c_char,_readddddnewdirfd  p = 000,: pthreadnewpathES:SHM_NO  c_char,_read) -> p = 000;P_MD5SIG fn symlinkat(: pthreadtargetES:SHM_NO  c_char,_readddddnewdirfd  p = 000,: pthreadlinkpathES:SHM_NO  c_char,_read) -> p = 000;P_MD5SIG fn unlinkat(dirfd  p = 000, pathnamEES:SHM_NO  c_char,d,
_ps  p = 000) -> p = 000;PP_MD5SIG fn access(pathES:SHM_NOc_char,damodEES::= 000) -> p = 000;P_MD5SIG fn alarm(seSHMds:      0x5) ->      0x5;P_MD5SIG fn chdir(dirES:SHM_NOc_char)d-> p = 000;P_MD5SIG fn chown(pathES:SHM_NOc_char,duid: uid_I, gid: gid_I) -> p = 000;P_MD5SIG fn lchown(pathES:SHM_NOc_char,duid: uid_I, gid: gid_I) -> p = 000;P_MD5SIG fn c =se(fdES::= 000) -> p = 000;P_MD5SIG fn dup(fdES::= 000) -> p = 000;P_MD5SIG fn dup2(srcESp = 000, dst: ::= 000) -> p = 000;P_MD5SIG fn execl(pathES:SHM_NOc_char,darg0ES:SHM_NOc_char,d...) -> p = 000;P_MD5SIG fn execle(pathES:SHM_NO  c_char,darg0ES:SHM_NO  c_char, ...) -> p = 000;P_MD5SIG fn execlp(file: :SHM_NO  c_char,darg0ES:SHM_NO  c_char, ...) -> p = 000;P_MD5SIG fn execv(inegES:SHM_NOc_char,dargvES:SHM_NO:SHM_NOc_char)d-> p = 000;P_MD5SIG fn execvE(: pthreadinegES:SHM_NOc_char,: pthreadargvES:SHM_NO:SHM_NOc_char,: pthreadenvpES:SHM_NO:SHM_NOc_char,: pth)d-> p = 000;P_MD5SIG fn execvp(cES:SHM_NOc_char,dargvES:SHM_NO:SHM_NOc_char)d-> p = 000;P_MD5SIG fn fork() -> pid_I;P_MD5SIG fn fpathSHMf(filedes  p = 000, namEESp = 000) -> =  = 1;P_MD5SIG fn getcwd(buf: :      char,dsuVE:   puVE_I) -> :      char;P_MD5SIG fn getegid() -> gid_I;P_MD5SIG fn geteuid() -> uid_I;P_MD5SIG fn getgid() -> gid_I;P_MD5SIG fn getgroups(ngroups_max  p = 000, groups: :    gid_I) -> p = 000;P_MD5SIG fn getlogin() -> :      char;P_MD5SIG fn getopt(argcESp = 000, argvES:SHM_NO:      char,doptstrES:SHM_NOc_char)d-> p = 000;P_MD5SIG fn getpgid(pid: pid_I) -> pid_I;P_MD5SIG fn getpgrp() -> pid_I;P_MD5SIG fn getpid() -> pid_I;P_MD5SIG fn getppid() -> pid_I;P_MD5SIG fn getuid() -> uid_I;P_MD5SIG fn isatty(fdES::= 000) -> p = 000;P_MD5SIG fn link(srcES:SHM_NOc_char,ddst: :SHM_NOc_char)d-> p = 000;P_MD5SIG fn lseek(fd  p = 000, offset: off_I, whence: ::= 000) -> off_I;P_MD5SIG fn pathSHMf(pathES:SHM_NOc_char,dnamEESp = 000) -> =  = 1;P_MD5SIG fn pause() -> p = 000;P_MD5SIG fn pipe(fds: :    ::c_000) -> p = 000;P_MD5SIG fn posix_memalign(memptr: :    :    ::c_dli_, alignES  puVE_I, suVE:   puVE_I) -> p = 000;P_MD5SIG fn read(fd  p = 000, buf: :      c_dli_, count:   puVE_I) ->   ppuVE_I;P_MD5SIG fn rmdir(pathES:SHM_NOc_char) -> p = 000;P_MD5SIG fn seteuid(uid: uid_I) -> p = 000;P_MD5SIG fn setegid(gid: gid_I) -> p = 000;P_MD5SIG fn setgid(gid: gid_I) -> p = 000;P_MD5SIG fn setpgid(pid: pid_I, pgid: pid_I) -> p = 000;P_MD5SIG fn setsid() -> pid_I;P_MD5SIG fn setuid(uid: uid_I) -> p = 000;P_MD5SIG fn sleep(seSs:      0x5) ->      0x5;P_MD5SIG fn nanosleep(rqtpES:SHM_NOtimespec, rmtp: :    timespec) -> p = 000;P_MD5SIG fn tcgetpgrp(fdES::= 000) -> pid_I;P_MD5SIG fn tcsetpgrp(fdES::= 000, pgrp:   pid_I) -> p = 000;P_MD5SIG fn ttynamE(fdES::= 000) -> :      char;P_MD5SIG fn unlink(cES:SHM_NOc_char) -> p = 000;P_MD5SIG fn wait(status  :    ::c_000) -> pid_I;P_MD5SIG fn waitpid(pid: pid_I, status  :    ::c_000,doptionsES::= 000) -> pid_I;P_MD5SIG fn write(fd  p = 000, buf: :SHM_NO  c_dli_, count:   puVE_I) ->   ppuVE_I;P_MD5SIG fn pread(fd  p = 000, buf: :      c_dli_, count:   puVE_I, offset: off_I) ->   ppuVE_I;P_MD5SIG fn pwrite(fd  p = 000, buf: :SHM_NO  c_dli_, count:   puVE_I, offset: off_I) ->   ppuVE_I;P_MD5SIG fn umask(maskESmodE_I) -> modE_I;PP_MD5SIG fn utime(file: :SHM_NOc_char,dbuf: :SHM_NOutimbuf) -> p = 000;PP_MD5SIG fn kill(pid: pid_I, sig  p = 000) -> p = 000;PP_MD5SIG fn mlock(addrES:SHM_NO  c_dli_, len:   puVE_I) ->   = 000;P_MD5SIG fn munlock(addrES:SHM_NO  c_dli_, len:   puVE_I) ->   = 000;P_MD5SIG fn mlockall(,
_ps  p = 000) -> p = 000;P_MD5SIG fn munlockall() -> p = 000;PP_MD5SIG fn mmap(: pthreadaddrES:      c_dli_,: pthreadlen:   puVE_I,: pthreadined  p = 000,: pthread,
_ps  p = 000,: pthreadfd  p = 000,: pthreadoffset: off_I,: pth)d-> :      c_dli_;P_MD5SIG fn munmap(addrES:      c_dli_, len:   puVE_I) ->   = 000;PP_MD5SIG fn if_namEtoindex(ifnamEES:SHM_NOc_char)d->      0x5;P_MD5SIG fn if_indextonamE(ifindex:      0x5,difnamEES:      c_char)d-> :      c_char;PP_MD5SIG fn lstat(pathES:SHM_NOc_char,dbuf: :    stat) -> p = 000;PP_MD5SIG fn fsync(fdES::= 000) -> p = 000;PP_MD5SIG fn setenv(namEES:SHM_NOc_char,dvalES:SHM_NOc_char,doverwrite  p = 000) -> p = 000;P_MD5SIG fn unsetenv(namEES:SHM_NOc_char) -> p = 000;PP_MD5SIG fn symlink(path1ES:SHM_NOc_char,dpath2ES:SHM_NOc_char) -> p = 000;PP_MD5SIG fn ftruncate(fd  p = 000, lengthESoff_I) ->   = 000;PP_MD5SIG fn signal(signum  p = 000, handler: sighandler_I) -> pughandler_I;PP_MD5SIG fn realpath(pathnamEES:SHM_NO  c_char,dresolved: :      c_char)d-> :      c_char;PP_MD5SIG fn flock(fd  p = 000, operationES::= 000) -> p = 000;PP_MD5SIG fn gettimeofday(tp: :    ::timeval, tzES:      c_dli_) -> p = 000;P_MD5SIG fn times(buf: :      tms) -> p =lock_I;PP_MD5SIG fn pthread_self() -> p pthread_I;P_MD5SIG fn pthread_join(native  p pthread_I,dvaluEES:    :    ::c_dli_) -> p = 000;P_MD5SIG fn pthread_exit(valuEES:    ::c_dli_) -> !;P_MD5SIG fn pthread_attr 00it(attrES:    ::pthread_attr t) -> p = 000;P_MD5SIG fn pthread_attr destroy(attrES:    ::pthread_attr t) -> p = 000;P_MD5SIG fn pthread_attr getstackpuVE(: pthreadattrES:SHM_NO  pthread_attr t,: pthreadstackpuVEES:    ::puVE_I,: pth) -> p = 000;P_MD5SIG fn pthread_attr setstackpuVE(attrES:    ::pthread_attr t,dstack_suVE:   puVE_I) -> p = 000;P_MD5SIG fn pthread_attr setdetachstatE(attrES:    ::pthread_attr t,dstate  p = 000) -> p = 000;P_MD5SIG fn pthread_detach(thread  p pthread_I) -> p = 000;P_MD5SIG fn sched_yield() -> p = 000;P_MD5SIG fn pthread_key_creatE(: pthreadkeyES:    pthread_key_t,: pthreaddtor:   Option<unsafe extern "C" fn(:    ::c_dli_)>,: pth) -> p = 000;P_MD5SIG fn pthread_key_delete(keyESpthread_key_t) -> p = 000;P_MD5SIG fn pthread_getspecific(keyESpthread_key_t) -> :      c_dli_;P_MD5SIG fn pthread_setspecific(keyESpthread_key_t,dvaluEES:SHM_NO  c_dli_) -> p = 000;P_MD5SIG fn pthread_   ex 00it(: pthreadlockES:    pthread_   ex 0,: pthreadattrES:SHM_NOpthread_   exattr t,: pth) -> p = 000;P_MD5SIG fn pthread_   ex destroy(lockES:    pthread_   ex 0) -> p = 000;P_MD5SIG fn pthread_   ex lock(lockES:    pthread_   ex 0) -> p = 000;P_MD5SIG fn pthread_   ex trylock(lockES:    pthread_   ex 0) -> p = 000;P_MD5SIG fn pthread_   ex unlock(lockES:    pthread_   ex 0) -> p = 000;PP_MD5SIG fn pthread_   exattr 00it(attrES:    pthread_   exattr t) -> p = 000;P_MD5SIG fn pthread_   exattr destroy(attrES:    pthread_   exattr t) -> p = 000;P_MD5SIG fn pthread_   exattr setPID (attrES:    pthread_   exattr t, _PID ES::= 000) -> p = 000;PP_MD5SIG fn pthread_SHMd 00it(SHMdES:    pthread_SHMd 0, attrES:SHM_NOpthread_SHMdattr t): pthread-> p = 000;P_MD5SIG fn pthread_SHMd wait(SHMdES:    pthread_SHMd 0, lockES:    pthread_   ex 0) -> p = 000;P_MD5SIG fn pthread_SHMd 0imedwait(: pthreadSHMdES:    pthread_SHMd 0,: pthreadlockES:    pthread_   ex 0,: pthreadabs0imeES:SHM_NO  timespec,: pth) -> p = 000;P_MD5SIG fn pthread_SHMd signal(SHMdES:    pthread_SHMd 0) -> p = 000;P_MD5SIG fn pthread_SHMd broad    (SHMdES:    pthread_SHMd 0) -> p = 000;P_MD5SIG fn pthread_SHMd destroy(SHMdES:    pthread_SHMd 0) -> p = 000;P_MD5SIG fn pthread_SHMdattr 00it(attrES:    pthread_SHMdattr t) -> p = 000;P_MD5SIG fn pthread_SHMdattr destroy(attrES:    pthread_SHMdattr t) -> p = 000;P_MD5SIG fn pthread_rwlock_00it(: pthreadlockES:    pthread_rwlock_0,: pthreadattrES:SHM_NOpthread_rwlockattr t,: pth) -> p = 000;P_MD5SIG fn pthread_rwlock_destroy(lockES:    pthread_rwlock_0) -> p = 000;P_MD5SIG fn pthread_rwlock_rdlock(lockES:    pthread_rwlock_0) -> p = 000;P_MD5SIG fn pthread_rwlock_tryrdlock(lockES:    pthread_rwlock_0) -> p = 000;P_MD5SIG fn pthread_rwlock_wrlock(lockES:    pthread_rwlock_0) -> p = 000;P_MD5SIG fn pthread_rwlock_trywrlock(lockES:    pthread_rwlock_0) -> p = 000;P_MD5SIG fn pthread_rwlock_unlock(lockES:    pthread_rwlock_0) -> p = 000;P_MD5SIG fn pthread_rwlockattr 00it(attrES:    pthread_rwlockattr t) -> p = 000;P_MD5SIG fn pthread_rwlockattr destroy(attrES:    pthread_rwlockattr t) -> p = 000;P_MD5SIG fn pthread_getnamE_np(thread  p pthread_I,dnamEES:    ::c_char,dlen:   puVE_I) ->   = 000;P_MD5SIG fn pthread_setnamE_np(thread  p pthread_I,dnamEES:SHM_NO  c_char) -> p = 000;P_MD5SIG fn strerror_r(errnum  p = 000, buf: :      char,dbuflen:   puVE_I) ->   = 000;PP_MD5SIG fn getsockopt(: pthreadsockfd  p = 000,: pthreadlevel  p = 000,: pthreadoptnamEESp = 000,: pthreadoptvalES:      c_dli_,: pthreadoptlen: :      pocklen_I,: pth) -> p = 000;P_MD5SIG fn raise(signum  p = 000) -> p = 000;P_MD5SIG fn sigaction(signum  p = 000, act: :SHM_NOsigaction,doldact: :    sigaction) ->   = 000;PP_MD5SIG fn utimes(filenamEES:SHM_NO::c_char,dtimesES:SHM_NO  timeval) -> p = 000;P_MD5SIG fn dlopen(filenamEES:SHM_NO  c_char,d,
_pES::= 000) -> :      c_dli_;P_MD5SIG fn dlerror()d-> :      c_char;P_MD5SIG fn dlsym(handleES:      c_dli_, symbolES:SHM_NO  c_char) -> :      c_dli_;P_MD5SIG fn dlc =se(handleES:      c_dli_) -> p = 000;P_MD5SIG fn dladdr(addrES:SHM_NO  c_dli_, infoES:    Dl_info) ->   = 000;PP_MD5SIG fn getaddrinfo(: pthreadnodEES:SHM_NOc_char,: pthreadservicEES:SHM_NOc_char,: pthreadh000sES:SHM_NOaddrinfo,0 pthreadresES:    :    addrinfo,0 pth)d-> p = 000;P_MD5SIG fn freeaddrinfo(resES:    addrinfo);P_MD5SIG fn gai_strerror(errcodEES::= 000) -> :SHM_NO  c_char;P_MD5SIG fn res 00it() ->   = 000;PP_MD5SIG fn gmtime_r(time_pES:SHM_NOtime_0, result: :    tm) -> :    tm;P_MD5SIG fn localtime_r(time_pES:SHM_NOtime_0, result: :    tm) -> :    tm;P_MD5SIG fn mktime(tm: :    tm) -> time_0;P_MD5SIG fn time(0imeES:    time_I) -> time_0;P_MD5SIG fn gmtime(time_pES:SHM_NOtime_0) -> :    tm;P_MD5SIG fn localtime(time_pES:SHM_NOtime_0) -> :    tm;PP_MD5SIG fn mknod(pathnamEES:SHM_NO  c_char,dmodEES::modE_I,dTOv  p dev_t) ->     000;P_MD5SIG fn unamE(buf: :      utsnamE)d-> p = 000;P_MD5SIG fn gethostnamE(namEES:    ::c_char,dlen:   puVE_I) ->   = 000;P_MD5SIG fn getservbynamE(namEES:SHM_NO  c_char,dinedfES:SHM_NO  c_char) -> :    serve00;P_MD5SIG fn getpnedfbynamE(namEES:SHM_NO  c_char) -> :    pnedfe00;P_MD5SIG fn getpnedfbynumber(inedfES::= 000) -> :    pnedfe00;P_MD5SIG fn usleep(seSs:      0x5) ->     000;P_MD5SIG fn send(socket  p = 000, buf: :SHM_NO  c_dli_, len:   puVE_I,d,
_ps  p = 000) -> p spuVE_I;P_MD5SIG fn recv(socket  p = 000, buf: :      c_dli_, len:   puVE_I,d,
_ps  p = 000) -> p spuVE_I;P_MD5SIG fn putenv(string: :      char) -> p = 000;P_MD5SIG fn poll(,ds: :    pollf_, n,ds: n,ds_I,dtimeout: ::= 000) -> p = 000;P_MD5SIG fn select(: pthreadnfds  p = 000,: pthreadread,ds: :    fd_set,: pthreadwrite,ds: :    fd_set,: pthreaderror,ds: :    fd_set,: pthreadtimeout: :    timeval,: pth) -> p = 000;P_MD5SIG fn setlocale(categorI  p = 000, localeES:SHM_NO  c_char) -> :      c_char;P_MD5SIG fn localeSHMv()d-> :    lSHMv;PP_MD5SIG fn sem destroy(sem: :    sem 0) -> p = 000;P_MD5SIG fn sem wait(sem: :    sem 0) -> p = 000;P_MD5SIG fn sem trywait(sem: :    sem 0) -> p = 000;P_MD5SIG fn sem post(sem: :    sem 0) -> p = 000;P_MD5SIG fn sem 00it(sem: :    sem 0,dishared  p = 000, valuEES     0x5) ->     000;P_MD5SIG fn statvfs(pathES:SHM_NOc_char,dbuf: :    statvfs) -> p = 000;P_MD5SIG fn fstatvfs(fd  p = 000, buf: :    statvfs) -> p = 000;PP_MD5SIG fn readlink(pathES:SHM_NOc_char,dbuf: :    c_char,dbufsz:   puVE_I) ->   ppuVE_I;PP_MD5SIG fn sigemptyset(setES:    sigset_t) -> p = 000;P_MD5SIG fn sigaddset(setES:    sigset_t, signum  p = 000) -> p = 000;P_MD5SIG fn sigfillset(setES:    sigset_t) -> p = 000;P_MD5SIG fn sigdelset(setES:    sigset_t, signum  p = 000) -> p = 000;P_MD5SIG fn sigismember(setES:SHM_NOsigset_t, signum  p = 000) -> p = 000;PP_MD5SIG fn sigpnecmask(how  p = 000, setES:SHM_NOsigset_t, oldsetES:    sigset_t) -> p = 000;P_MD5SIG fn sigpending(setES:    sigset_t) -> p = 000;PP_MD5SIG fn timegm(tm: :      tm) -> time_0;PP_MD5SIG fn getsid(pid: pid_I) -> pid_I;PP_MD5SIG fn sysSHMf(namEESp = 000) ->   c_ = 1;PP_MD5SIG fn mkfifo(pathES:SHM_NOc_char,dmodEESmodE_I) -> p = 000;PP_MD5SIG fn pselect(: pthreadnfds  p = 000,: pthreadread,ds: :    fd_set,: pthreadwrite,ds: :    fd_set,: pthreaderror,ds: :    fd_set,: pthreadtimeout: :SHM_NOtimespec,: pthreadsigmaskES:SHM_NOsigset_t,: pth) -> p = 000;P_MD5SIG fn fseeko(stream: :    ::FIFS, offset: ::off_I, whence: ::= 000) -> p = 000;P_MD5SIG fn ftello(stream: :    ::FIFS) -> p off_I;P_MD5SIG fn tcdrain(fdES::= 000) -> p = 000;P_MD5SIG fn cfgetispeed(termiosES:SHM_NO  termios) ->   ppeed_0;P_MD5SIG fn cfgetospeed(termiosES:SHM_NO  termios) ->   ppeed_0;P_MD5SIG fn cfmakeraw(termiosES:      termios);P_MD5SIG fn cfsetispeed(termiosES:      termios, speed  p ppeed_0) -> p = 000;P_MD5SIG fn cfsetospeed(termiosES:      termios, speed  p ppeed_0) -> p = 000;P_MD5SIG fn cfsetspeed(termiosES:      termios, speed  p ppeed_0) -> p = 000;P_MD5SIG fn tcgetattr(fd  p = 000, PermiosES:      termios) -> p = 000;P_MD5SIG fn tcsetattr(fd  p = 000, optional_actions  p = 000, PermiosES:SHM_NO  termios) ->   = 000;P_MD5SIG fn tcflow(fd  p = 000, actionES::= 000) -> p = 000;P_MD5SIG fn tcflush(fd  p = 000, actionES::= 000) -> p = 000;P_MD5SIG fn tcgetsid(fdES::= 000) -> p pid_I;P_MD5SIG fn tcsendbreak(fd  p = 000, durationES::= 000) -> p = 000;P_MD5SIG fn mkstemp(template  :      c_char)d-> p = 000;P_MD5SIG fn mkdtemp(template  :      c_char)d-> :      c_char;PP_MD5SIG fn tmpnam(ptr  :      c_char)d-> :      c_char;PP_MD5SIG fn openlog(identES:SHM_NO  c_char, logopt  p = 000, faciliPI  p = 000);P_MD5SIG fn c =selog();P_MD5SIG fn setlogmask(maskpri  p = 000) -> p = 000;P_MD5SIG fn syslog(prioriPI  p = 000, messageES:SHM_NO  c_char, ...);PP_MD5SIG fn grantpt(fdES::= 000) -> p = 000;P_MD5SIG fn posix_openpt(f
_ps  p = 000) -> p = 000;P_MD5SIG fn ptsnamE(fdES::= 000) -> :      c_char;P_MD5SIG fn unlockpt(fdES::= 000) -> p = 000;PP_MD5SIG fn fdatasync(fdES::= 000) -> p = 000;P_MD5SIG fn c =ck_getres(clk_id:   c =ckid_I, tp: :    ::timespec) -> p = 000;P_MD5SIG fn c =ck_gettime(clk_id:   c =ckid_I, tp: :    ::timespec) -> p = 000;P_MD5SIG fn c =ck_settime(clk_id:   c =ckid_I, tp: :SHM_NO  timespec) -> p = 000;P_MD5SIG fn dirfd(dirp: :    ::DIR)d-> p = 000;PP_MD5SIG fn pthread_getattr np(native  p pthread_I,dattrES:    ::pthread_attr t) -> p = 000;P_MD5SIG fn pthread_attr getstack(: pthreadattrES:SHM_NO  pthread_attr t,: pthreadstackaddrES:    :      c_dli_,: pthreadstackpuVEES:    ::puVE_I,: pth) -> p = 000;P_MD5SIG fn memalign(alignES  puVE_I, suVE:   puVE_I) -> :      c_dli_;P_MD5SIG fn setgroups(ngroupsES  puVE_I, ptrES:SHM_NO  gid_I) -> p = 000;P_MD5SIG fn pipe2(fds: :    ::c_000,d,
_ps  p = 000) -> p = 000;P_MD5SIG fn statfs(pathES:SHM_NO  c_char, buf: :    statfs) -> p = 000;P_MD5SIG fn fstatfs(fd  p = 000, buf: :    statfs) -> p = 000;P_MD5SIG fn memrchr(cx: :SHM_NO  c_dli_, c  p = 000, n:   puVE_I) -> :      c_dli_;PP_MD5SIG fn posix_fadvise(fd  p = 000, offset: ::off_I, len:   off_I, advise: ::= 000) -> p = 000;P_MD5SIG fn futimens(fd  p = 000, timesES:SHM_NO  timespec) -> p = 000;P_MD5SIG fn utimensat(: pthreaddirfd  p = 000,: pthreadiathES:SHM_NO  c_char,_readddddtimesES:SHM_NO  timespec,: pthread,
_p  p = 000,: pth) -> p = 000;P_MD5SIG fn duplocale(base: ::locale_I) -> p locale_I;P_MD5SIG fn freelocale(loc: ::locale_I);P_MD5SIG fn newlocale(maskESp = 000, localeES:SHM_NO  c_char, base: ::locale_I) -> p locale_I;P_MD5SIG fn uselocale(loc: ::locale_I) -> p locale_I;PP_MD5SIG fn fdopendir(fdES::= 000) -> :      DIR;PP_MD5SIG fn mknodat(: pthreaddirfd  p = 000,: pthreadiathnamEES:SHM_NO  c_char,_readddddmodEES::modE_I,: pthreadTOv  dev_t,: pth) -> p = 000;P_MD5SIG fn pthread_SHMdattr getc =ck(: pthreadattrES:SHM_NOpthread_SHMdattr t,: pthreadc =ck_idES:    c =ckid_I,: pth) -> p = 000;P_MD5SIG fn pthread_SHMdattr setc =ck(: pthreadattrES:    pthread_SHMdattr t,: pthreadc =ck_idES  c =ckid_I,: pth) -> p = 000;P_MD5SIG fn accept4(: pthreadfd  p = 000,: pthreadaddrES:      sockaddr,: pthreadlen: :      pocklen_I,: pthread,
p  p = 000,: pth) -> p = 000;P_MD5SIG fn ptsnamE_r(fd  p = 000, buf: :      c_char,dbuflen:   puVE_I) ->   = 000;P_MD5SIG fn c eareMv()d-> p = 000;P_MD5SIG fn waitid(idPID ESidPID _I, idESid_I, infopES:    ::puginfo_0,doptionsES::= 000): pthread-> p = 000;P_MD5SIG fn setreuid(ruid:   uid_I, euid:   uid_I) -> p = 000;P_MD5SIG fn setregid(rgid:   gid_I, egid:   gid_I) ->   = 000;P_MD5SIG fn getresuid(ruid: :      uid_I, euid: :      uid_I, suid: :      uid_I) ->   = 000;P_MD5SIG fn getresgid(rgid: :      gid_I, egid: :      gid_I, sgid: :      gid_I) -> p = 000;P_MD5SIG fn acct(filenamEES:SHM_NO  c_char) -> p = 000;P_MD5SIG fn brk(addrES:      c_dli_) -> p = 000;P_MD5SIG fn setresgid(rgid:   gid_I, egid:   gid_I, sgid:   gid_I) -> p = 000;P_MD5SIG fn setresuid(ruid:   uid_I, euid:   uid_I, suid:   uid_I) ->   = 000;P_MD5SIG fn openpty(: pthreadamaster: :    ::c_000,: pthddddaslave: :    ::c_000,: pthddddnamEES:    ::c_char,_readddddtermpES:SHM_NOtermios,: pthreadwinp: :SHM_NO  winpuVE,: pth)d-> p = 000;P_MD5SIG fn execvpE(: pthreadfile: :SHM_NO  c_char,: pthreadargvES:SHM_NO:SHM_NO  c_char,: pthreadenvpES:SHM_NO:SHM_NO  c_char,_read) -> p = 000;P_MD5SIG fn fexecvE(: pthreadfd  p = 000,: pthreadargvES:SHM_NO:SHM_NO  c_char,: pthreadenvpES:SHM_NO:SHM_NO  c_char,_read) -> p = 000;PP_MD5SIG fn ioctl(fd  p = 000, request  p = 000, ...) -> p = 000;PP_MD5SIG fn lutimes(fileES:SHM_NO::c_char,dtimesES:SHM_NO  timeval) -> p = 000;PP_MD5SIG fn setpwent();P_MD5SIG fn endpwent();P_MD5SIG fn getpwent() -> :    passwd;PP_MD5SIG fn shm_open(namEES:SHM_NOc_char,do,
_p  p = 000, modEESmodE_I) -> p = 000;PP_MD5// System V IPCP_MD5SIG fn shmget(keyES::key_t,dsuVE:   puVE_I, shm,
p  p = 000) -> p = 000;P_MD5SIG fn shmat(shmid  p = 000, shmaddrES:SHM_NO  c_dli_, shm,
p  p = 000) -> :      c_dli_;P_MD5SIG fn shmdt(shmaddrES:SHM_NO  c_dli_) -> p = 000;P_MD5SIG fn shmctl(shmid  p = 000,  md  p = 000, buf: :      shmid_ds) -> p = 000;P_MD5SIG fn ftok(pathnamEES:SHM_NO  c_char,dproj_idES::= 000) -> p key_t;P_MD5SIG fn semget(keyES::key_t,dnsems  p = 000, sem,
_pES::= 000) -> p = 000;P_MD5SIG fn semop(semid  p = 000, sops: :    ::sembuf,dnsopsES  puVE_I) -> p = 000;P_MD5SIG fn semctl(semid  p = 000, semnum  p = 000,  md  p = 000, ...) -> p = 000;P_MD5SIG fn msgctl(msqid  p = 000,  md  p = 000, buf: :    msqid_ds) -> p = 000;P_MD5SIG fn msgget(keyES::key_t,dmsg,
p  p = 000) -> p = 000;P_MD5SIG fn msgrcv(: pthreadmsqid  p = 000,: pthreadmsgpES:      c_dli_,: pthreadmsgsz:   puVE_I,: pthreadmsgPID:   c_ = 1,: pthreadmsg,
p  p = 000,: pth) -> p spuVE_I;P_MD5SIG fn msgsnd(: pthreadmsqid  p = 000,: pthreadmsgpES:SHM_NO  c_dli_,: pthreadmsgsz:   puVE_I,: pthreadmsg,
p  p = 000,: pth) -> p = 000;PP_MD5SIG fn mpnedect(addrES:      c_dli_, len:   puVE_I,dined  p = 000) -> p = 000;P_MD5SIG fn __errno location()d-> :      c_000;PP_MD5SIG fn fallocate(fd  p = 000, modEES::= 000, offset: ::off_I, len:   off_I) -> p = 000;P_MD5SIG fn posix_fallocate(fd  p = 000, offset: ::off_I, len:   off_I) -> p = 000;P_MD5SIG fn readahead(fd  p = 000, offset: ::off64_I,dcount:   puVE_I) ->   ppuVE_I;P_MD5SIG fn signalfd(fd  p = 000, maskES:SHM_NO::pugset_t, ,
_ps  p = 000) -> p = 000;P_MD5SIG fn timerfd_creatE(c =ckid: ::c_000,d,
_ps  p = 000) -> p = 000;P_MD5SIG fn timerfd_gettime(fd  p = 000,  urr_valuEES:    itimerspec) -> p = 000;P_MD5SIG fn timerfd_settime(: pthreadfd  p = 000,: pthread,
_ps  p = 000,: pthreadnew_valuEES:SHM_NOitimerspec,: pthreadold_valuEES:    itimerspec,: pth) -> p = 000;P_MD5SIG fn pwritev(fd  p = 000, iovES:SHM_NO::iovec, iovcnt  p = 000, offset: ::off_I): pthread-> p ppuVE_I;P_MD5SIG fn preadv(fd  p = 000, iovES:SHM_NO::iovec, iovcnt  p = 000, offset: ::off_I)d-> p ppuVE_I;P_MD5SIG fn quotactl(: pthreadcmd  p = 000,: pthreadspecial: :SHM_NO  c_char,: pthreadid  p = 000,: pthreaddataES:    ::c_char,_read) -> p = 000;P_MD5SIG fn dup3(oldfd  p = 000, newfd: ::c_000,d,
_ps  p = 000) -> p = 000;P_MD5SIG fn mkostemp(template  :      c_char,d,
_ps  p = 000) -> p = 000;P_MD5SIG fn mkostemps(template  :      c_char,dsuffixlen:     000,d,
_ps  p = 000) -> p = 000;P_MD5SIG fn sig0imedwait(: pthreadsetES:SHM_NOsigset_t,: pthreadinfoES:    puginfo_0,: pthreadtimeout: :SHM_NO  timespec,: pth) -> p = 000;P_MD5SIG fn pugwaitinfo(setES:SHM_NOsigset_t, infoES:    puginfo_0) -> p = 000;P_MD5SIG fn nl_langinfo_l(item  p nl_item, localeES::locale_I) -> :      c_char;P_MD5SIG fn getnamEinfo(: pthreadsaES:SHM_NO::pockaddr,: pthreadsalen:   pocklen_I,: pthreadhostES:    ::c_char,_readddddhostlen:   pocklen_I,: pthreadservES:    ::c_char,_readddddservlen:   pocklen_I,: pthread,
_ps  p = 000,: pth) -> p = 000;P_MD5SIG fn reboot(how_dfES::= 000) -> p = 000;P_MD5SIG fn setfsgid(gid:   gid_I) -> p = 000;P_MD5SIG fn setfsuid(uid:   uid_I) -> p = 000;PP_MD5// Not available now on Andrli_P_MD5SIG fn mkfifoat(dirfd  p = 000, pathnamEES:SHM_NO  c_char,dmodEES::modE_I)d-> p = 000;P_MD5SIG fn if_namEindex() -> :    if_namEindex;P_MD5SIG fn if_freenamEindex(ptr  :    if_namEindex);P_MD5SIG fn sync_file_range(: pthreadfd  p = 000,: pthreadoffset: ::off64_I,: pthreadnbytes  p off64_I,: pthread,
_ps  p = u000,: pth) -> p = 000;P_MD5SIG fn getifaddrs(ifapES:    :      ifaddrs)d-> p = 000;P_MD5SIG fn freeifaddrs(ifa: :      ifaddrs);PP_MD5SIG fn glob(: pthreadiatternES:SHM_NOc_char,: pthread,
_ps  p = 000,: pthreaderrfunc:   Option<extern "C" fn(epathES:SHM_NOc_char,derrnoES::= 000) -> p = 000>,: pthreadiglob: :      glob_I,: pth) -> p = 000;P_MD5SIG fn globfree(pglob: :      glob_I);PP_MD5SIG fn posix_madvise(addrES:      c_dli_, len:   puVE_I,dadvic ES::= 000) -> p = 000;PP_MD5SIG fn shm_unlink(namEES:SHM_NO  c_char) -> p = 000;PP_MD5SIG fn seekdir(dirp: :    ::DIR, loc:   c_ = 1);PP_MD5SIG fn telldir(dirp: :    ::DIR)d-> p =  = 1;P_MD5SIG fn madvise(addrES:      c_dli_, len:   puVE_I,dadvic ES::= 000) -> p = 000;PP_MD5SIG fn msync(addrES:      c_dli_, len:   puVE_I,d,
_ps  p = 000) -> p = 000;PP_MD5SIG fn recvfrom(: pthreadsocket  p = 000,: pthreadbuf: :      c_dli_,: pthreadlen:   puVE_I,: pthread,
_ps  p = 000,: pthreadaddrES:      sockaddr,: pthreadaddrlen: :      pocklen_I,: pth) -> p spuVE_I;P_MD5SIG fn mkstemps(template  :      c_char,dsuffixlen:     000) -> p = 000;P_MD5SIG fn futimes(fd  p = 000, timesES:SHM_NO  timeval) -> p = 000;P_MD5SIG fn nl_langinfo(item  p nl_item)d-> :      c_char;PP_MD5SIG fn bind(socket  p = 000, addressES:SHM_NO  sockaddr,daddress_len:   pocklen_I) -> p = 000;PP_MD5SIG fn writev(fd  p = 000, iovES:SHM_NO::iovec, iovcnt  p = 000) -> p spuVE_I;P_MD5SIG fn readv(fd  p = 000, iovES:SHM_NO::iovec, iovcnt  p = 000) ->   ppuVE_I;PP_MD5SIG fn sendmsg(fd  p = 000, msgES:SHM_NO::msghdr,d,
_ps  p = 000) -> p spuVE_I;P_MD5SIG fn recvmsg(fd  p = 000, msgES:      msghdr,d,
_ps  p = 000) -> p spuVE_I;P_MD5SIG fn getdomainnamE(namEES:    ::c_char,dlen:   puVE_I) ->   = 000;P_MD5SIG fn setdomainnamE(namEES:SHM_NO  c_char, len:   puVE_I) ->   = 000;P_MD5SIG fn vhangup() ->     000;P_MD5SIG fn sendmmsg(: pthreadsockfd  p = 000,: pthreadmsgvec: :    mmsghdr,: pthreadvlen:     u000,: pthread,
_ps  p = 000,: pth) -> p = 000;P_MD5SIG fn recvmmsg(: pthreadsockfd  p = 000,: pthreadmsgvec: :    mmsghdr,: pthreadvlen:     u000,: pthread,
_ps  p = 000,: pthreadtimeout: :      timespec,: pth) -> p = 000;P_MD5SIG fn pync();P_MD5SIG fn syscall(num  p =  = 1, ...) -> p =  = 1;P_MD5SIG fn sched_getaffinity(pid: p pid_I, cpusetsiVE:   puVE_I, cpusetES:    cpu_set_t): pthread-> p = 000;P_MD5SIG fn sched_setaffinity(: pthreadiid: p pid_I,: pthreadcpusetsiVE:   puVE_I,: pthreadcpusetES:SHM_NOcpu_set_t,_read) -> p = 000;P_MD5SIG fn umount(targetES:SHM_NO  c_char) -> p = 000;P_MD5SIG fn sched_get_prioriPI_max(policy  p = 000) -> p = 000;P_MD5SIG fn tee(fd_in  p = 000, fd_out: ::= 000, len:   puVE_I,d,
_ps  p = u000) -> p spuVE_I;P_MD5SIG fn settimeofday(tvES:SHM_NO  timeval, tzES:SHM_NO  timezone) -> p = 000;P_MD5SIG fn splice(: pthreadfd_in  p = 000,: pthreadoff_in: :      loff_I,: pthreadfd_out: ::= 000,: pthreadoff_out: :      loff_I,: pthreadlen:   puVE_I,: pthread,
_ps  p = u000,: pth) -> p spuVE_I;P_MD5SIG fn eve00fd(init:      0x5,d,
_ps  p = 000) -> p = 000;P_MD5SIG fn sched_rr get 000erval(pid: p pid_I, tp: :    ::timespec) -> p = 000;P_MD5SIG fn sem 0imedwait(sem: :    sem 0,dabs0imeES:SHM_NO  timespec) -> p = 000;P_MD5SIG fn sem getvaluE(sem: :    sem 0,dsvalES:      c_000) -> p = 000;P_MD5SIG fn sched_setparam(pid: p pid_I, paramES:SHM_NO  sched_param) -> p = 000;P_MD5SIG fn swapoff(puathES:SHM_NO  c_char) ->   = 000;P_MD5SIG fn vmsplice(: pthreadfd: ::= 000,: pthreadiovES:SHM_NO::iovec,: pthreadnr segs:   puVE_I,: pthread,
_ps  p = u000,: pth) -> p spuVE_I;P_MD5SIG fn mount(: pthreadsrcES:SHM_NO::c_char,_readddddtargetES:SHM_NO  c_char,_readddddfsPID ES:SHM_NO  c_char,_readdddd,
_ps  p = u = 1,: pthreaddataES:SHM_NO  c_dli_,: pth) -> p = 000;P_MD5SIG fn personality(persona  p = u = 1) -> p = 000;P_MD5SIG fn sched_getparam(pid: p pid_I, paramES:      pched_param) -> p = 000;P_MD5SIG fn ppoll(: pthreadfds: :    ::pollf_,: pthreadnfds  n,ds_I,: pthreadtimeout: :SHM_NO  timespec,: pthreadsigmaskES:SHM_NOsigset_t,: pth) -> p = 000;P_MD5SIG fn pthread_   ex 0imed =ck(: pthreadlockES:    pthread_   ex 0,: pthreadabs0imeES:SHM_NO  timespec,: pth) -> p = 000;P_MD5SIG fn c = e(: pthreadcb: extern "C" fn(:      c_dli_) -> p = 000,: pthreadchild_stack: :      c_dli_,: pthread,
_ps  p = 000,: pthreadarg: :      c_dli_,: pthread...: pth) -> p = 000;P_MD5SIG fn pched_getpcheduler(iid: p pid_I) -> p = 000;P_MD5SIG fn c =ck_nanosleep(: pthreadc k_idES  c =ckid_I,: pthread,
_ps  p = 000,: pthreadrqtpES:SHM_NO  timespec,: pthreadrmtp: :      timespec,: pth) -> p = 000;P_MD5SIG fn pthread_attr getguardpuVE(: pthreadattrES:SHM_NO  pthread_attr t,: pthreadguardpuVEES:    ::puVE_I,: pth) -> p = 000;P_MD5SIG fn pthread_attr setguardpuVE(attrES:    ::pthread_attr t,dguardpuVEES  puVE_I) ->   = 000;P_MD5SIG fn sethostnamE(namEES:SHM_NO  c_char, len:   puVE_I) ->   = 000;P_MD5SIG fn sched_get_prioriPI_min(policy  p = 000) -> p = 000;P_MD5SIG fn umount2(targetES:SHM_NO  c_char,d,
_ps  p = 000) -> p = 000;P_MD5SIG fn swapon(pathES:SHM_NO  c_char, swap,
_ps  p = 000) -> p = 000;P_MD5SIG fn sched_setpcheduler(: pthreadiid: p pid_I,: pthreadpolicy  p = 000,: pthreadiaramES:SHM_NO  sched_param,: pth) -> p = 000;P_MD5SIG fn pugsuspend(maskES:SHM_NO::pugset_t) -> p = 000;P_MD5SIG fn getgrgid_r(: pthreadgid:   gid_I,_readddddgrp: :      group,_readddddbuf: :      c_char,_readddddbuflen:   puVE_I,: pthreadresult: :    :    ::group,_read) -> p = 000;P_MD5SIG fn sigaltstack(ssES:SHM_NOstack_0, ossES:    stack_0) -> p = 000;P_MD5SIG fn sem c =se(sem: :    sem 0) -> p = 000;P_MD5SIG fn getdtablepuVE() -> p = 000;P_MD5SIG fn getgrnam_r(: pthreadnamEES:SHM_NO  c_char,_readddddgrp: :      group,_readddddbuf: :      c_char,_readddddbuflen:   puVE_I,: pthreadresult: :    :    ::group,_read) -> p = 000;P_MD5SIG fn initgroups(userES:SHM_NO  c_char, group:   gid_I) -> p = 000;P_MD5SIG fn pthread_sigmask(how  p = 000, setES:SHM_NOsigset_t, oldsetES:    sigset_t) -> p = 000;P_MD5SIG fn sem_open(namEES:SHM_NO  c_char, o,
_p  p = 000, ...) -> :    sem 0;P_MD5SIG fn getgrnam(namEES:SHM_NO  c_char) -> :    ::group;P_MD5SIG fn pthread_Sancel(thread  p pthread_I) -> p = 000;P_MD5SIG fn pthread_kill(thread  p pthread_I,dsig  p = 000) -> p = 000;P_MD5SIG fn sem_unlink(namEES:SHM_NO  c_char) -> p = 000;P_MD5SIG fn daemon(nochdir  p = 000, noc =se  p = 000) -> p = 000;P_MD5SIG fn getpwnam_r(: pthreadnamEES:SHM_NO  c_char,_readddddpwdES:    passwd,_readddddbuf: :      c_char,_readddddbuflen:   puVE_I,: pthreadresult: :    :    passwd,_read) -> p = 000;P_MD5SIG fn getpwuid_r(: pthreaduid:   uid_I,_readddddpwdES:    passwd,_readddddbuf: :      c_char,_readddddbuflen:   puVE_I,: pthreadresult: :    :    passwd,_read) -> p = 000;P_MD5SIG fn pugwait(setES:SHM_NOsigset_t, sig: :    ::c_000) -> p = 000;P_MD5SIG fn pthread_atfork(: pthreadinepare:   Option<unsafe extern "C" fn()>,: pthreadiarent  p Option<unsafe extern "C" fn()>,: pthreadchild  p Option<unsafe extern "C" fn()>,: pth) -> p = 000;P_MD5SIG fn getgrgid(gid:   gid_I) -> :    ::group;PP_MD5SIG fn setgrent();P_MD5SIG fn endgrent();P_MD5SIG fn getgrent() -> :    ::group;PP_MD5SIG fn getgrouplist(: pthreaduserES:SHM_NO  c_char,_readddddgroup:   gid_I,: pthreadgroups: :      gid_I,: pthreadngroups: :      = 000,: pth) -> p = 000;P_MD5SIG fn popen(commaMdES:SHM_NOc_char,dmodEES:SHM_NOc_char) -> :    ::FIFS;P_MD5SIG fn faccessat(: pthreaddirfd  p = 000,: pthreadiathnamEES:SHM_NO  c_char,_readddddmodEES::= 000,: pthread,
_ps  p = 000,: pth) -> p = 000;P_MD5SIG fn pthread_SreatE(: pthreadnative  :    ::pthread_0,: pthreadattrES:SHM_NO  pthread_attr t,: pthreadf: extern "C" fn(:      c_dli_) -> :      c_dli_,: pthreadvaluEES:    ::c_dli_,_read) -> p = 000;P_MD5SIG fn dl_iteratE_phdr(: pthreadcallback: p Option<: pthreadreadunsafe extern "C" fn(: pthreadreadreadinfoES:    ::dl_phdr_info,0 pthread pthreadsiVE:   puVE_I,: pthread pthreaddataES:    ::c_dli_,: pthreadread) -> p = 000,: pthread>,: pthreaddataES:    ::c_dli_,_read) -> p = 000;P}

cfg_if! {_readif #[cfg(target_arch = "aarch64")] {_readddddmod aarch64;: pthreadiIG use self::aarch64::*;: pth} elsedif #[cfg(any(target_arch = "x86_64"))] {_readddddmod x86_64;: pthreadiIG use self::x86_64::*;: pth} elsedif #[cfg(any(target_arch = "riscv64"))] {_readddddmod riscv64;: pthreadiIG use self::riscv64::*;: pth} elsed{_readdddd// Unknown target_arch: pth}P}

cfg_if! {_readif #[cfg(libc_align)] {_readdddd#[macro_use]_readddddmod align;: pth} elsed{_readdddd#[macro_use]_readddddmod no_align;: pth}P}
expaMd_align!();P
cfg_if! {_readif #[cfg(libc_core_cdli_)] {_readddddiIG use ::ffi  c_dli_;P_MD5} elsed{_readdddd// Usednepr(u8) as LLVM expects `dli_*` to be the samE as `i8*` to help_readdddd// enable moredoptimizationdopportunities around it recognizing things_readdddd// like malloc/free._readdddd#[nepr(u8)]_readdddd#[allow(missing_copy_implementations)]_readdddd#[allow(missing_debug_implementations)]_readddddiIG enum c_dli_d{_readdddddddd// Two dummydvariants so the #[nepr]dattributedcan be used._readdddddddd#[doc(hidden)]_readdddddddd__variant1,_readdddddddd#[doc(hidden)]_readdddddddd__variant2,_readdddd}: pth}P}
                                                           