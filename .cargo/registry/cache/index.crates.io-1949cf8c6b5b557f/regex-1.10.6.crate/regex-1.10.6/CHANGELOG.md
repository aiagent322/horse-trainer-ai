1.10.6 (2024-08-02)
===================
This is a new patch release with a fix for the `unstable` crate feature that
enables `std::str::Pattern` trait integration.

Bug fixes:

* [BUG #1219](https://github.com/rust-lang/regex/pull/1219):
Fix the `Pattern` trait implementation as a result of nightly API breakage.


1.10.5 (2024-06-09)
===================
This is a new patch release with some minor fixes.

Bug fixes:

* [BUG #1203](https://github.com/rust-lang/regex/pull/1203):
Escape invalid UTF-8 when in the `Debug` impl of `regex::bytes::Match`.


1.10.4 (2024-03-22)
===================
This is a new patch release with some minor fixes.

* [BUG #1169](https://github.com/rust-lang/regex/issues/1169):
Fixes a bug with compiling a reverse NFA automaton in `regex-automata`.
* [BUG #1178](https://github.com/rust-lang/regex/pull/1178):
Clarifies that when `Cow::Borrowed` is returned from replace APIs, it is
equivalent to the input.


1.10.3 (2024-01-21)
===================
This is a new patch release that fixes the feature configuration of optional
dependencies, and fixes an unsound use of bounds check elision.

Bug fixes:

* [BUG #1147](https://github.com/rust-lang/regex/issues/1147):
Set `default-features=false` for the `memchr` and `aho-corasick` dependencies.
* [BUG #1154](https://github.com/rust-lang/regex/pull/1154):
Fix unsound bounds check elision.


1.10.2 (2023-10-16)
===================
This is a new patch release that fixes a search regression where incorrect
matches could be reported.

Bug fixes:

* [BUG #1110](https://github.com/rust-lang/regex/issues/1110):
Revert broadening of reverse suffix literal optimization introduced in 1.10.1.


1.10.1 (2023-10-14)
===================
This is a new patch release with a minor increase in the number of valid
patterns and a broadening of some literal optimizations.

New features:

* [FEATURE 04f5d7be](https://github.com/rust-lang/regex/commit/04f5d7be4efc542864cc400f5d43fbea4eb9bab6):
Loosen ASCII-compatible rules such that regexes like `(?-u:☃)` are now allowed.

Performance improvements:

* [PERF 8a8d599f](https://github.com/rust-lang/regex/commit/8a8d599f9d2f2d78e9ad84e4084788c2d563afa5):
Broader the reverse suffix optimization to apply in more cases.


1.10.0 (2023-10-09)
===================
This is a new minor release of `regex` that adds support for start and end
word boundary assertions. That is, `\<` and `\>`. The minimum supported Rust
version has also been raised to 1.65, which was released about one year ago.

The new word boundary assertions are:

* `\<` or `\b{start}`: a Unicode start-of-word boundary (`\W|\A` on the left,
`\w` on the right).
* `\>` or `\b{end}`: a Unicode end-of-word boundary (`\w` on the left, `\W|\z`
on the right)).
* `\b{start-half}`: half of a Unicode start-of-word boundary (`\W|\A` on the
left).
* `\b{end-half}`: half of a Unicode end-of-word boundary (`\W|\z` on the
right).

The `\<` and `\>` are GNU extensions to POSIX regexes. They have been added
to the `regex` crate because they enjoy somewhat broad support in other regex
engines as well (for example, vim). The `\b{start}` and `\b{end}` assertions
are aliases for `\<` and `\>`, respectively.

The `\b{start-half}` and `\b{end-half}` assertions are not found in any
other regex engine (although regex engines with general look-around support
can certainly express them). They were added principally to support the
implementation of word matching in grep programs, where one generally wants to
be a bit more flexible in what is considered a word boundary.

New features:

* [FEATURE #469](https://github.com/rust-lang/regex/issues/469):
Add support for `\<` and `\>` word boundary assertions.
* [FEATURE(regex-automata) #1031](https://github.com/rust-lang/regex/pull/1031):
DFAs now have a `start_state` method that doesn't use an `Input`.

Performance improvements:

* [PERF #1051](https://github.com/rust-lang/regex/pull/1051):
Unicode character class operations have been optimized in `regex-syntax`.
* [PERF #1090](https://github.com/rust-lang/regex/issues/1090):
Make patterns containing lots of literal characters use less memory.

Bug fixes:

* [BUG #1046](https://github.com/rust-lang/regex/issues/1046):
Fix a bug that could result in incorrect match spans when using a Unicode word
boundary and searching non-ASCII strings.
* [BUG(regex-syntax) #1047](https://github.com/rust-lang/regex/issues/1047):
Fix panics that can occur in `Ast->Hir` translation (not reachable from `regex`
crate).
* [BUG(regex-syntax) #1088](https://github.com/rust-lang/regex/issues/1088):
Remove guarantees in the API that connect the `u` flag with a specific HIR
representation.

`regex-automata` breaking change release:

This release includes a `regex-automata 0.4.0` breaking change release, which
was necessary in order to support the new word boundary assertions. For
example, the `Look` enum has new variants and the `LookSet` type now uses `u32`
instead of `u16` to represent a bitset of look-around assertions. These are
overall very minor changes, and most users of `regex-automata` should be able
to move to `0.4` from `0.3` without any changes at all.

`regex-syntax` breaking change release:

This release also includes a `regex-syntax 0.8.0` breaking change release,
which, like `regex-automata`, was necessary in order to support the new word
boundary assertions. This release also includes some changes to the `Ast`
type to reduce heap usage in some cases. If you are using the `Ast` type
directly, your code may require some minor modifications. Otherwise, users of
`regex-syntax 0.7` should be able to migrate to `0.8` without any code changes.

`regex-lite` release:

The `regex-lite 0.1.1` release contains support for the new word boundary
assertions. There are no breaking changes.


1.9.6 (2023-09-30)
==================
This is a patch release that fixes a panic that can occur when the default
regex size limit is increased to a large number.

* [BUG aa4e4c71](https://github.com/rust-lang/regex/commit/aa4e4c7120b0090ce0624e3c42a2ed06dd8b918a):
Fix a bug where computing the maximum haystack length for the bounded
backtracker could result underflow and thus provoke a panic later in a search
due to a broken invariant.


1.9.5 (2023-09-02)
==================
This is a patch release that hopefully mostly fixes a performance bug that
occurs when sharing a regex across multiple threads.

Issue [#934](https://github.com/rust-lang/regex/issues/934)
explains this in more detail. It is [also noted in the crate
documentation](https://docs.rs/regex/latest/regex/#sharing-a-regex-across-threads-can-result-in-contention).
The bug can appear when sharing a regex across multiple threads simultaneously,
as might be the case when using a regex from a `OnceLock`, `lazy_static` or
similar primitive. Usually high contention only results when using many threads
to execute searches on small haystacks.

One can avoid the contention problem entirely through one of two methods.
The first is to use lower level APIs from `regex-automata` that require passing
state explicitly, such as [`meta::Regex::search_with`](https://docs.rs/regex-automata/latest/regex_automata/meta/struct.Regex.html#method.search_with).
The second is to clone a regex and send it to other threads explicitly. This
will not use any additional memory usage compared to sharing the regex. The
only downside of this approach is that it may be less convenient, for example,
it won't work with things like `OnceLock` or `lazy_static` or `once_cell`.

With that said, as of this release, the contention performance problems have
been greatly reduced. This was achieved by changing the free-list so that it
was sharded across threads, and that ensuring each sharded mutex occupies a
single cache line to mitigate false sharing. So while contention may still
impact performance in some cases, it should be a lot better now.

Because of the changes to how the free-list works, please report any issues you
find with this release. That not only includes search time regressions but also
significant regressions in memory usage. Reporting improvements is also welcome
as well! If possible, provide a reproduction.

Bug fixes:

* [BUG #934](https://github.com/rust-lang/regex/issues/934):
Fix a performance bug where high contention on a single regex led to massive
slow downs.


1.9.4 (2023-08-26)
==================
This is a patch release that fixes a bug where `RegexSet::is_match(..)` could
incorrectly return false (even when `RegexSet::matches(..).matched_any()`
returns true).

Bug fixes:

* [BUG #1070](https://github.com/rust-lang/regex/issues/1070):
Fix a bug where a prefilter was incorrectly configured for a `RegexSet`.


1.9.3 (2023-08-05)
==================
This is a patch release that fixes a bug where some searches could result in
incorrect match offsets being reported. It is difficult to characterize the
types of regexes susceptible to this bug. They generally involve patterns
that contain no prefix or suffix literals, but have an inner literal along with
a regex prefix that can conditionally match.

Bug fixes:

* [BUG #1060](https://github.com/rust-lang/regex/issues/1060):
Fix a bug with the reverse inner literal optimization reporting incorrect match
offsets.


1.9.2 (2023-08-05)
==================
This is a patch release that fixes another memory usage regression. This
particular regression occurred only when using a `RegexSet`. In some cases,
much more heap memory (by one or two orders of magnitude) was allocated than in
versions prior to 1.9.0.

Bug fixes:

* [BUG #1059](https://github.com/rust-lang/regex/issues/1059):
Fix a memory usage regression when using a `RegexSet`.


1.9.1 (2023-07-07)
==================
This is a patch release which fixes a memory usage regression. In the regex
1.9 release, one of the internal engines used a more aggressive allocation
strategy than what was done previously. This patch release reverts to the
prior on-demand strategy.

Bug fixes:

* [BUG #1027](https://github.com/rust-lang/regex/issues/1027):
Change the allocation strategy for the backtracker to be less aggressive.


1.9.0 (2023-07-05)
==================
This release marks the end of a [years long rewrite of the regex crate
internals](https://github.com/rust-lang/regex/issues/656). Since this is
such a big release, please report any issues or regressions you find. We would
also love to hear about improvements as well.

In addition to many internal improvements that should hopefully result in
"my regex searches are faster," there have also been a few API additions:

* A new `Captures::extract` method for quickly accessing the substrings
that match each capture group in a regex.
* A new inline flag, `R`, which enables CRLF mode. This makes `.` match any
Unicode scalar value except for `\r` and `\n`, and also makes `(?m:^)` and
`(?m:$)` match after and before both `\r` and `\n`, respectively, but never
between a `\r` and `\n`.
* `RegexBuilder::line_terminator` was added to further customize the line
terminator used by `(?m:^)` and `(?m:$)` to be any arbitrary byte.
* The `std` Cargo feature is now actually optional. That is, the `regex` crate
can be used without the standard library.
* Because `regex 1.9` may make binary size and compile times even worse, a
new experimental crate called `regex-lite` has been published. It prioritizes
binary size and compile times over functionality (like Unicode) and
performance. It shares no code with the `regex` crate.

New features:

* [FEATURE #244](https://github.com/rust-lang/regex/issues/244):
One can opt into CRLF mode via the `R` flag.
e.g., `(?mR:$)` matches just before `\r\n`.
* [FEATURE #259](https://github.com/rust-lang/regex/issues/259):
Multi-pattern searches with offsets can be done with `regex-automata 0.3`.
* [FEATURE #476](https://github.com/rust-lang/regex/issues/476):
`std` is now an optional feature. `regex` may be used with only `alloc`.
* [FEATURE #644](https://github.com/rust-lang/regex/issues/644):
`RegexBuilder::line_terminator` configures how `(?m:^)` and `(?m:$)` behave.
* [FEATURE #675](https://github.com/rust-lang/regex/issues/675):
Anchored search APIs are now available in `regex-automata 0.3`.
* [FEATURE #824](https://github.com/rust-lang/regex/issues/824):
Add new `Captures::extract` method for easier capture group access.
* [FEATURE #961](https://github.com/rust-lang/regex/issues/961):
Add `regex-lite` crate with smaller binary sizes and faster compile times.
* [FEATURE #1022](https://github.com/rust-lang/regex/pull/1022):
Add `TryFrom` implementations for the `Regex` type.

Performance improvements:

* [PERF #68](https://github.com/rust-lang/regex/issues/68):
Added a one-pass DFA engine for faster capture group matching.
* [PERF #510](https://github.com/rust-lang/regex/issues/510):
Inner literals are now used to accelerate searches, e.g., `\w+@\w+` will scan
for `@`.
* [PERF #787](https://github.com/rust-lang/regex/issues/787),
[PERF #891](https://github.com/rust-lang/regex/issues/891):
Makes literal optimizations apply to regexes of the form `\b(foo|bar|quux)\b`.

(There are many more performance improvements as well, but not all of them have
specific issues devoted to them.)

Bug fixes:

* [BUG #429](https://github.com/rust-lang/regex/issues/429):
Fix matching bugs related to `\B` and inconsistencies across internal engines.
* [BUG #517](https://github.com/rust-lang/regex/issues/517):
Fix matching bug with capture groups.
* [BUG #579](https://github.com/rust-lang/regex/issues/579):
Fix matching bug with word boundaries.
* [BUG #779](https://github.com/rust-lang/regex/issues/779):
Fix bug where some regexes like `(re)+` were not equivalent to `(re)(re)*`.
* [BUG #850](https://github.com/rust-lang/regex/issues/850):
Fix matching bug inconsistency between NFA and DFA engines.
* [BUG #921](https://github.com/rust-lang/regex/issues/921):
Fix matching bug where literal extraction got confused by `$`.
* [BUG #976](https://github.com/rust-lang/regex/issues/976):
Add documentation to replacement routines about dealing with fallibility.
* [BUG #1002](https://github.com/rust-lang/regex/issues/1002):
Use corpus rejection in fuzz testing.


1.8.4 (2023-06-05)
==================
This is a patch release that fixes a bug where `(?-u:\B)` was allowed in
Unicode regexes, despite the fact that the current matching ease rev:$)` m+Ect mnconsi this llounis cont contentiEscapeg bo/issbo/ipotentually
is [incomeannal imp rev:$)` m+Ectl imprpng t cbo/ipotencorrect
matches co change is [incoontentiois thus ere aage rffsekSet`but nusaglic):
DF&ces`.change e thlar regreis [als in `s well.

ary.
* Be8`e `regex` crer coulyat reers Usecbug rrplemeatn what tde) w=====when usinxes a bug re a p where ure 
rissuedtually'se `regex`es a bug wheg., bre armit It is was allowed in
B)` ary.
* Becavementhere c the current maeg., /1088):
Rl.

pectirelease,ting incorrectl imprpng t cbo/ipoten. What can r coulyat  eers Usecbug rrplere 
rissued,ance. It se_terminatoreads, a patces a bug whdid exazes and is [al
ary.
* Be8`e in `s wellfind with t said, as ofary.
* Be8.4or ` `revolve pde
mpatible r`uch as sue(r"s a bug ")` matched_ave been adde <Be8`e `ot vertsf
notnxes a bug. (A `mpl of tions ftchicontecontorrrseazes and itdevoted to them.)

Bug fg/rs:

* [BUG #1046](https://github.com/rust-lang/06gex/issues/1070):
Fes a bug where `(?-u:\B)` was allowed in
Unelated [inco:is_maluses.

Inev:$)` m+Ectl imprpng t cbo/ipotenc now&ces`.chfuzz gexSet`.
5-2.8.4 (2023-06-05)
==================
This is a patch release that fixong rewritwsome seease, e rev:$threse arpo`s well return fain some c exth t saorrectanics thaaese a
te sea accepresewed in
Unuar primystalncies the
imps
Add ues/510):
erforfastegression. T peprd bage (Seixong ust-l "rust-e `ed ttly coThere rof se
icocritd` idevoted to them.)

Bug f99ies.
* [BUG #779](https://github.com/rust-lan99igex/issues/1070):
Fix rev:$threse arpo`s well sa rrpthreadsatches couldfuzz 2exSet`.
5-228.4 (2023-06-05)
==================
This is a patch release that fixrewritees ans the
orrectthus 
is 
tagsn opt forowed in
B abouincreaorr tde)tcheti boundary convenient`a{2147483516}{2147483416}{5}`oontentens are :Pattease vould re78):
Cr).
Tmatc==========opt mentthus ere ais 
tagsn opt. Dcode regexeunip whminaCr).
at rwitthurehem c==========opte in did exaza This
wie thatlogecbug:
Fixs/issuese
 rrante. It se_tforosues     s this apse_ethod td yet a reproduction.

Bug fi95es.
* [BUG #779](https://github.com/rust-lan995gex/issues/1070):
Frewritees ans the
 abouincreaorr tde)tcheti boun
orrectthus uldfuzz gexSet`.
41.10.3 (2024-01-21)
==================
This is a patch release that fixral alon rev:$orrect
matches co
at fixnffsete_tfouressS of the pritionale thlar rion onlanerally  0.1.1` relts ihing bugg withes046):
Fix a beg where de)_ela_):
`std` is nupport the newis [al
g with a reproduction.

Bug fi8nes.
* [BUG #921](https://github.com/rust-lang81gex/issues/1070):
Fixupport the newFix a tenci, de aboug with
hing bu

Makes literal latluses.

aorrectlpo`s wven conditifuzz 0exSet`.
41..9.6 (2023-09-30)
==============smals arehis is a patceg., bresohe
fo(?-u:\Bbyease thatsmals ar
find withBoern s`but neg., httbirowecloter ctir40g wisimizathave
s latPRs.change o methid, as oficode reis csmal, es `u1iat shou of `u1thanegreer::yw the
mplementrch_witreaking changeceg., bre retubigeas. Namerition said, as ion.
Isize liis relMSRVs.

imum bee0.0 raised to 1.65, which was 1eased about* Upgra notis c`aho-cora heahe `memchr` and ave beerof`u1 shou5, whic1.0located ut* Upgra notis c`aho-cora heahenges at all.

ave beeltiple threadshou5, whi
`
`regocated ubitraBecause of enges at all.

hey were addwhay genbitset o
 a [years lis ching bug where lite. It valid
ncrease ins
Add some mino (lik
Makes literalof is cance-s to utencimediuseda specific HIR (HIRz` on thrch_witreaking changeceg., fo(?-u ~somr1 sh`(?m:$ beerortions.b ct,ceg.,
 pattern==soup-to-nutsf a [years lese argine (althougreatly g., breoffseby
bssinmiza[evel APIs from `es.
* [BUG #921](httpBinctSushi/ns.
* [FEATURE(r):
O
on saidpo`s ::y across etuas achieved bn added
to the` and se t921):
e, pAnch
shimuinyase ll.
p and most users of `'sench` on ts a croemerortion:
Inne the flilderthe
imph was 3
 the e conn-a of afample, patc[bege :Pa thet mnc noMc latSet0crate
internals](https://github.com/rust-lang/reglot better now.

ch aer noBecause They gereis [alseerortion
UnItwsome  We wou
d
also lovetype
n worsee) anEl of bug. Tn somese ic):setues/976owececause Th
 `ot vertsre are many mocecause (po`s wven*or*osuga wveegloM chacecause Thegexes methid, as 
Inneo hot-e `ed dary cplains this free-lis
seixong ust-latlog changec wilyzers, ihoua:$)` mdof`u1 shtues/976owen s ::y
imphllare no brearegex` crate.

New features50nes.
* [BUG #921](https://github.com/rust-lan50ngexParmitb`.

(Thereots of lite` and ex/puld,a retuif` cratfastencesions but ) aoM 9):
 of the priti.

( searc1051):
Unie scalar val[0-9A-Za-z<>] ftchir libe
 x/puld. Also,=======to replofais_ x/puls ar_1051):
Unor d `regex-erminato
enges at all.

aveque ar70) thatac1051):
Uni sa x/puls artsrese r compile time5gex-syntax) #1047](https://github.com/rust-lan5regexex/puuch as ching bs_at`greatlyfg.,rs, hond is [alenchvemente` methooodificat
l optimizi.

( even wused a mprst r compile time595es.
* [BUG #779](https://github.com/rust-lan595gexCne for fastername:
Inner liwas all-awareble to tchir libegie
 abouei thatac`_`
ly c

("alphabrehe"cbo/ipoten. A(?m:$ bees methbo/ipoten,a accequenthbo/ipotense `regexc

(cequencer noalpha-numorschbo/ipotens,n inner litc`_`,ode.,od[o makes]`grNoteregex-aumentation sers ofhe `Lohacecausdx-automata 0.3`ing.
* [PERF #510](https://github.com/rust-lan8/regeex/pu`regewhereemptyres how`regewhlen`Anchore group access05es.
* [BUG #779](https://github.com/rust-lan905egeex/pat din thDccur war va when usi, shares nooccur wt match relempty(cetre group access08es.
* [BUG #779](https://github.com/rust-lan90/rege=====
res::,puuch as Lock` _ching bs_len`r d `regex-erminahangec wtched_aal
ncrease inching bug with is [aleerally  if`s hoease. frese arpo`as we,ting ialways 0.1.1` rew.

came
ncrease in c the cug with captoup access55es.
* [BUG #779](https://github.com/rust-lan955egeNamednching bs tchir libe  [yetet imp`(?<name>re)`s are as well.
es `P<name>re)` capoup acc: enges at all.

r lilease cslempty(1051):
Unicode A and oup acc: enges at all.

r lid Rus
`std` is nx/issuow an opt(eatly g., nts iof enges ` is [alerch_witreaking.)nd oup acc: itraroccur ype been optimized inid Ruhalid
ncrease ins
Add some mino
ma nlof isand oup acc: enges at all.

d Rulease contai======F mode vextracg, `e cue ca
h enables Ceg., bres. The minbeen opti`T peprd is [alerch_witreaking.nd oup acc: enges at all.

r lid Ru peprd lease contai"gine (egex-pectiv.g., `(" intorocc::fhis()` capoup acc: itrarhi):
`Rng bu`==opulew minor reat all.

d Ruegex-ees letee 
ri Unikas beenr lid Ruplainsues/976):
Ad,convenief validdvice capoup acc: itrar`(?-u_/1203):_utf8``std` i been optimized inid Rursion ename have`utf8` across eomeans and aack leondanid Rursionfli.
Tmhe `Regex` type.

Performance im/iss: itraupgra n of e `memchr` anc1.0featur.

Perfay still
impact perf
 usage iy'seeported. It is difficult tonvter whangeces/1090):on saltaneotion m,
mentif` crquux)\baute seancrease ininneish (>= 4e anys)ug with
hing buptionant, fltaneouslDFA engation` matc a reproduction.

Bug f514es.
* [BUG #517](https://github.com/rust-lang/regeI

Perfa-8 when in thr val`regexg the free-te` methosthe chanentionarches ontandaUGS [f516es.
* [BUG #517](https://github.com/rust-lang/6egex#73nes.
* [BUG #921](https://github.com/rust-lan731gex/issuencrease inthave
s aboug tens anroccurUniconce il alongs/1090)ith fallib6ing.
* [PERF #510](https://github.com/rust-lan6/regeex/p other tconveniew minf the f` is [ale resulters ofwith`th fallib62
* [FEATURE #675](https://github.com/rust-lang25regex/pulyible r` usMg., `(whlen`Ae` m`Loha( any ix fy)c wir the or increase iwhere incis [alerct`th fallib6es:

* [BUG #1060](https://github.com/rust-lan6regexex/pulyi"ctibo====opt"m c===esulters ofwits/976):
AdtandaUG x#738es.
* [BUG #921](https://github.com/rust-lan738egex#9e)*`.
* [BUG #850](https://github.com/rust-lan9/regex/is/824):
AL
Change(whg and the free-tpectirues/10word boundagex-syntax) #1047](https://github.com/rust-lan7regexex/pulyisues/976):
Addr valuch as Lomr1este `Regt to `(re)(r3
* [FEATURE #675](https://github.com/rust-lanr3
egex/is/\p{Sc}nd the free-t sa e)+` were not \p{Cfact cy_Symbol}t to `(re)(res:

* [BUG #1046](https://github.com/rust-lan84regex/isThereox/pulys ansues/976):
Add doed bnCes anddTooBien  rrple to a broo `(re)(re
* [FEATURE #824](https://github.com/rust-langg/regex/pulyible r`ebug` itions ft in
"my rstif` cring the ma=====sequencer ns `.` match any
Unico0word bound88
* [FEATURE #824](https://github.com/rust-lang84gex/ieturne`__Nonexha:// a `k` enum ha litc`#[non_exha:// a ] fs/1rimeneword bound89s:

* [BUG #1203](https://github.com/rust-l89segexons havas migfoldat  e/issuiegex pg aact`sed ?-u ct perfob3a6ologecbug apply rd bound89
* [FEATURE #675](https://github.com/rust-lanr95gexR):
UsFes a buW)`s ar`ebug` itions fnchore grBug fi4ty.
* [BUG #1002](https://github.com/rust-lani4tegeex/pafltor qui`cks.` keyupporof indome e "s
thdif
reers"m c=Cench`  grBug fi65es.
* [BUG #779](https://github.com/rust-lan96
egex/is/\p{Lc}nd the free-t sa e)+` were not \p{C whi_Lould } confused by 5es.
* [BUG #779](https://github.com/rust-lan975gexex/pulyisues/976):
Addr val\pX`lters oitifuz7 gexSet`.
3-249.6 (2023-09-30)
==============se seahis is a patch release thinaluch as Lomr1este `Reg_at`
erforFix a betterregex ues/1,l return fa cri)` m+E giretuisn the  a reproduction.

Bug fi

* [FEATURE #469](https://github.com/rust-lan9/rege  /issues/10inathe chana bug wietweto 1rimentar valuch as Lomr1este `Reg_at`gtifuz7 2exSet`.
3-219.6 (2023-09-30)
==============se seahis is a patch releasfhisatch  mncAddFreeBSD a reproduction.

Bug fi
7* [FEATURE #469](https://github.com/rust-lan9/7ege  /iss"s
tthe ma vould r"h  mnchangecex pfhis er in a[alere sea he masmalgtifuz7 gexSet`.
11.10.0 (2023-10-09)
=================tegy than wy were added tode worfx/pull/sue.r==== couatchmplemen
rewrite of he `Regex` type.

Performance improveme930:

* [BUG #1203](https://github.com/rust-l930ege  xons hava`aumentan`greatly and  optise of engmenta`vements asengmenta_aic` orreproduction.

Bug fi45es.
* [BUG #779](https://github.com/rust-lan945ege  MayuslDx/ps://sue=== couatchby?mR:$)`umpressio====t======?tifuz7 0exSet2-11
1.9.0 (2023-07-05)
================= wy were adds release naupgra n of  `.` mat15rearegex` crate.

New features83ty.
* [BUG #1002](https://github.com/rust-lani16ege  Upgra n of  `.` mat15reafuz6 0exSet2-


1.9.0 (2023-07-05)
================= wy were adds release naupgra n of  `.` mat14rearegex` crate.

New features83ty.
* [BUG #1002](https://github.com/rust-l832ege  ex/pulyible r`824):
Add len`As release ., / with,ts asmR:$) c the cug with captoup acces857y.
* [BUG #1002](https://github.com/rust-l857ege  ex/pat dEnvteShavIng br::liin thr valSub824):
AMg., `(ex-automata 0.3`6:

* [PERF #1051](https://github.com/rust-l8/rege  I

Perfa- when usiisues/976):
Addonveniefx-automata 0.3`77* [FEATURE #469](https://github.com/rust-lan`77ege  Upgra n of  `.` mat14 orreproduction.

Bug f79ty.
* [BUG #1002](https://github.com/rust-lan79tege  /iss rrplemomates a  couatchbu in fuz5 change2.
5-209.0 (2023-07-05)
=================s release ave abeproduct,=s releressios/1046):
pptimizatioession where incn onlan andny edy `?`charactplere od tdome minor f68s:

* [BUG #1060](https://github.com/rust-lan680ege  /iselease that fixe[[:alncr:][:^ascii:]] fdro.
Tmxe[:alncr:]to moveong uode roo `(re)(re9* [FEATURE #824](https://github.com/rust-langg9ege  /iselease that fixeocc::ere `Regeemptyre::Borrowe`fault-featu`b(fooo `(re)(r6ty.
* [BUG #1002](https://github.com/rust-lanr6tege  /iselease that fix'ab??'e.g., `(?'ab' now uses `u'a' no?'ab'in fuz5 5hange2.
s.

9.0 (2023-07-05)
================sch release curovers/10inaong rewritees andrgreatlys/10 armitd muvon ss Dtai==ernsalf a servic):
the ma=ng applhat fixong rewrit matchees andd
tlyunts://edtual
assertionsknownion perforat fixong rewritiotis elf ts://ed,
s releress=ng applh `uunts://edarches on smao `SECURITY #GHSA-m5pq-gvj9-9vr8es.
* [BUG #921](https://github.com/re curove/ddvisoith /GHSA-m5pq-gvj9-9vr8ege  /iselease thinaong rewritees andrrat fixempty(cub-n wused o relebatchde) wee   wisimiza cache ificant eturnetoreaDtac):
D default
reonhees anddnsions toe  itraimum S curoverRespfice WG-lite` hasmystadvisoiyso loveon sge  .
* [BUG  with google(httpgps://ithu-e curove-annountations/c/NcNNL1Jq7Ywn fuz5 testin1
1.-069.0 (2023-07-05)
=================h release thatees ans the
fhisg bun onlbs/64atch o sharin thiime,
 bees itiotDtairn fa cri`p19):
Fixhe `std` Caag, `Rd changecssion the css
as a resimum. CIid Rursionupdtching b  mncon sacing.nord boundarty.
* [BUG #1002](https://github.com/rust-lartege  /issbs/64urn falp19):
Fixhe `std` Caag, `Rdin fuz5 3estin1
1.-019.0 (2023-07-05)
================sch release that nlbs/64atch o shex` may be with a s all- arl`
ow an optIt tched_loveon):
Cland CIire obs/64atchon sacs the feature in se_eth
feature ifhisatch her cti ., bs/64uigh cfhisedtees ans the.nord bounda

* [FEATURE #469](https://github.com/rust-lan7/rege  /issbs/64ubeen optimized iniage rffbe with a s all- arl`xhe `std` Caag, `Rdin fuz5 2estin1
1.-019.0 (2023-07-05)
================opefully mostly fixes a page rs when usingg bug with e casesRdinNameritiDtaind suppations appound suppuivalece in'srpo`as we,mplement`Oncietwhaves.
p d
boundary(bettressiot derates.

aosirst ialthou)urn fain e` meth
feature inehing in [PRnda
a`.
* [BUG #1178](https://github.com/rust-la
a)ch release  a  raised to 
oitthoat shou he minbe
[riprd m#18es:

* [BUG #1060](httpBinctSushi/niprd mrust-lang8es)in fuz5 1estin1
14
1.9.6 (2023-09-30)
==================
This is a patch releasees ans the
 rrplern fa cri`post-`Rng bu`
he `std` Cargtaag, `Rdin fuz5 0estin1
14
1.9.6 (2023-09-30)
================= wymwit shupdtchss.

imum 2018 (fhoat s)$)` maumpis relMSRVs.

imum be41es moveimum be28). imum be41eto 1rhea4eb `regex`in'srcontecze log, `y
oldUnelatesn
str'cant Debichicos artite thencludimpllishn in ry assertions. Thidro.):on sae of 'caownibespfkly accessin/675):
Aalgoitthusatc=favertsfsio===
citlmtlm):
Add `TryFrom`l! If po\Bbyeres=false` foe of x::search_with`](halse` /2egexhalse` /tlmtlm/i coeta/sthod.stly g., nissues/102the contention fiiew mi
Fix bug whe,i
Fixze andg10.6/. mu`Rntlepile timendch release thrangesquentritig10.6/. m it should . Pe-lis
elease, plesert wa2the contentiso
significanf or regresues dn fuz4 change1
14
228.4 (2023-06-05)
==============re sea
This is a new patch release ees andr' csmal unsounonathe In s
ses,
much moral alonusage Pwhat was ,ease ees andr didts as corr thmplemen
type to red miex/pull/1051):
Unicode age N-u cn e` me iy'sepo`as we,spite tio
ma `regex
Fix bug wherfhis t ises and featn what was  didtses ande in erforfa.
Tn free-listfiiewe :Pst-l.nord bounOSS-s re#33roups.
* [BUG:
Fi.e` omium.org/p/ing-jectsust-lans this?id=33rouege  SFix bug wherex pu====o cases,
much moationffsetix a n woctdn fuz4 5hange1
131.10.1 (2023-10-14)
==============re sea
This is a new patch relea a memory usis [alermal sfsioations 
is [aleuz4 4lfind withPn in
versi4 4,sioations eto 1552e anyssage regrsi4 4
reaking cin se_ 856e anys er in atencies are no brage re said, as ofioations 
is/476)16e anyssage this bu, [alermal sfsioations egex-auctir
Fixzhatch h apse_e lelly a wivementhegex size limirmal is [aleuz4 4lfind wieserforouldasteconsidd
a sharsholdmendcontentens arthe ma vould rs ct perfobching i.nord bounda50:

* [BUG #1203](https://github.com/rust-l750ege  /iselethe ma vould rs serfnteny bette\Bbyeauincreaations ermal byedeize lat r eis csmaldn fuz4 4hange1
131.10.1 (2023-10-14)
==============re sea
This is a new patc0.1.1` relts abeproductgrNot, `y cin egresdro.):oneaasharde_:
Chl`x(s how`OnceLock` o, into in `s wvove) `aho-corasick`rreproduction.

Bug f36ty.
* [BUG #1002](https://github.com/rust-l36tege  Much mo a ks bette\Bbyeanatencies araundarythe allocrovemenr libe oducd capture gro6y.
* [BUG #1002](https://github.com/rust-l576ege  Ateczene (eracter li
Add `Try `UnwgreSaferes howRefUnwgreSaferword bounda2a`.
* [BUG #1178](https://github.com/rust-la49ege  ex/pltor qui`/ieturn:liin tions
arVec<u8for `Sessinor `Cowor etcdn fuz4 3estin1
11.

9.0 (2023-07-05)
==============re sea
This is a new patcf `rege may or quied withou the 

Add `TryFrom` implege maeracteis [aleeite`cench` oreproduction.

Bug f73es.
* [BUG #1154](https://github.com/rust-l7/rege  ex/p`Ftte\Ing br::lis howEnvteShavIng br::liin talof isractpleeractword bounda3
* [FEATURE #675](https://github.com/rust-l7/5ege  ex/pltor qui`8 when in talof eite`cencheeractwo fuz4 2estin0-11
110.1 (2023-10-14)
==============re seabeprodu is a new patcbanna`\P{ pl}`ssion what was  banroweempty
code agre some[^\w\W]`vementltorenew var\P{ pl}`acing.age regrfu`std raech rehave armitlempty(1ode A anord bounda2ty.
* [BUG #1002](https://github.com/rust-lan72tege  Bat d\P{ pl}`a.

acks.
d thus pinaong rewritees andrgrF/1154)ynOSS-Fectwo fuz4 1estin0-10-130.1 (2023-10-14)
==============re seabeprodu is a new patc`\n`, a\p{cand  thee Pwhat was ,e, fors_maelease," peprd y assertion"l retuegex en`cf`======203):
abbwhat):
Addr va[al
aFcontt`ex engineme egrs userd bounda1
* [FEATURE #469](https://github.com/rust-lan719ege  /iseles/1046):
pphat tde)a\p{cand  move theon in fuz4 0estin0-10-119.0 (2023-07-05)
================scd Rusave ay requsues/976):
Addr relearegex
earege mase are
ove
lso been a feubitraMSRVsrem1` re):
imum be28tforosowvementhegex  a p whminato
e with a .

ato a st imum be41 1esohein ry assertions. Thif `regex` that adOSS-Fectw Kudo gene[@Daf pKorczynski* [FEATURE #469](httpDaf pKorczynski)
mpledoatch hersesvmo iftatchmplemeat!earegex` crate.

New features649* [FEATURE #644](https://github.com/rust-lang/uege  Sex` tha`[or `]lis how.`s=ng ae for fastername:`(?m:$)` behave`@`.
* [PERF #787](https://github.com/rust-lane`@ege  ex/p`ereemptyrepphdome e of e when using?m:$)` behave`9* [FEATURE #644](https://github.com/rust-lang89ege  I

d `Try `C sec`hr valSub824):
AMg., `(ex-automata 0.3715* [FEATURE #469](https://github.com/rust-lan715ege  ex/p`emptyrematcautomin
ver- when usiiDtaint may becc a reproduction.

Bug f69
* [FEATURE #644](https://github.com/rust-lang94ege  /isssue=onveniewr valuceturn:::ngmenta_a.
Tndrword bound69ts:

* [PERF #68](https://github.com/rust-lang98ege  ex/pulyiwithwr vals connectge regressionmpl of tions word bounda1nes.
* [BUG #921](https://github.com/rust-lan711ege  ex/pulyi`ere `Reg`iwithwof indome e e free-tex pThis makerch regrching nin fuz3.9estin0-
5-289.0 (2023-07-05)
================opefully MSRVs(Mand `\>Sex` thaimum Vcated ) a memory usis [alfuz3.8lfind withNameritiCland uz3.8lees andappouimum be28 cin eeature ie` m`Loh
ses and obroad suimum ocated ttate expliimum be39 a reproduction.

Bug f68
* [FEATURE #675](https://github.com/rust-lang85ege  /issuestter no`wit_ust-Tryfoe of ,changecex nt sholine
te matchimum be43in fuz3.8estin0-
5-289.0 (2023-07-05)
================o0.1.1` reaseeuniew miin  thantebeproduct driret
byshould bgex` that adempty-subn wused o reppations adary assertionsbug where someb|like `(?-u:☃)` a Majplemeank gene[@sliqu hotr* [FEATURE #675](httpsliqu hotr)at ad
Add `Try quieease containsisatc=[#677y.
* [BUG #1002](https://github.com/rust-l677)`
returns true).

Bug f52s:

* [BUG #1203](https://github.com/rust-l52sege  ex/pno e of sues/976):
Add  imprpntahes with  x/puldubeenx`n opt.).

Bug f524es.
* [BUG #517](https://github.com/rust-lang2rege  ex/pgex` that adempty(cub-n wused o r,=s releressempty(alncies theh`th fallib6e9* [FEATURE #824](https://github.com/rust-lan6g9ege  /ispThis mntentitte\Bbyeanaempty(cub-n wused o tltoees ans the.nofuz3.7estin0-
4-179.0 (2023-07-05)
================o0.1.1` reasre seabeprodu  patch releor` c opti`Tt awthosae of 
he `stde of enges at all.
.age gression. tion sawnteczeimizireees ans thee Th
 heap usagea reproduction.

Bug f66
* [FEATURE #675](https://github.com/rust-l665ege  /isphe `std`t awthoatch f enges at all.
.nofuz3.6estin0-
3-249.6 (2023-09-30)
================o0.1.1` reasrizs art(~30%)e are many more performactge rxes a bug
 heapeond contancreangeon. Tn wused o rhe `Regex` type.

Performance improvemen57y.
* [BUG #1002](https://github.com/rust-l657ege  Ie performac are many moontors a bug ancreangeon. Tn wused o rhe fuz3.5estin0-
3-129.6 (2023-09-30)
================oupdtchss.n sae of  of  `.` mat13rearegex` crate.

New features653y.
* [BUG #1002](https://github.com/rust-l653ege  Updtchhenges at all.

ave `.` mat13reafuz3.4estin0-
1
1.9.6 (2023-09-30)
==============re seabeprodu is a new patch release th matching bw.

chops and 
onnesh capture grhNameritie matchtatlyfgx,oral alone some (?i)a)b whers_maThis m`aB`nicode regexes, despite`b`crovemenr  sholt::matcas mig` re `s wv`\>`, reproduction.

Bug f64s:

* [BUG #1060](https://github.com/rust-lan640ege  /issbsth matching bw.

chops and  onnesh capture greafuz3.3estin0-
1
.10.0 (2023-10-09)
==============re seam1`  whtentiso a new patcupgra nots noocho-cora hea
asharde_:
Chl`x move to `0 f e1.0fubitramand `\>s. The minimum ocated srem1` r
):
imum be28reafuz3.2estin0-
1
.10.0 (2023-10-09)
==============re seam1`  whtentiso a newex-litheapove==o0leans an)` mauproductgearegex` crate.

New features63nes.
* [BUG #921](https://github.com/rust-lan631ege  ex/paow`regewhr no ptures::eaut ne1022<`rege>ar va  no pt
Add`
returns true).

Bug f52nes.
* [BUG #921](https://github.com/rust-lan521ege  ession s `/-/.rpng n("a", 2)instead[inco`["a"]` now uses `u`["a", ""]`.).

Bug f59es.
* [BUG #1154](https://github.com/rust-l594ege  I

Perfa rrplel optimizatge rllishn )a\p\rword bound6es:

* [BUG #1027](https://github.com/rust-lan627ege  ession s `/-/.rpng ("a-")instead[inco`["a", ""]` now uses `u`["a"]`.).

Bug f633y.
* [BUG #1002](https://github.com/rust-l633ege  Squashoochions the
 arn't womplementastd:: rrpl::Errpl::icocritd` iptures::reafuz3.1esti19.


110.1 (2023-10-14)
==============m1`  whtentiso a newex-linoacecause Thes necessatodessa the bitset
a [with`](he.
* Tust-ly.
* [BUG #1002](https://githubwith`](hust-lang0s)in fuz3 0esti19.


139.6 (2023-09-30)
================of `rearee-es:ras `u====e of  he `stde o6):
parmitlnges, andessionusageng keis csmalematcinec, `y ciddonnissuesmplegivhn )upuei thatile times ove
(te expli `.` matc. The )port unnclude Unicode) anWhat  sea atch e `stde ertidis, `Rd cs noocho-cora htreewr val opti`Tgeng ke of onvter w1ae of 
(enges at all.
)a Mo regrnicod the
o loveoneu====e of  he `stde s with
[rtionpinaong withe
documentation](https:/*/#e of -he `stde)in Noteregex-Cland t=========ne ay requocated sre, as of thimand `\>s. The mi
imum ocated sntainsis=e of  rem1` re):
`be28r0`gearegex` crate.

New features474* [FEATURE #476](https://github.com/rust-lang/4ege  itrarnge_/issuow an oid Rursionochions ldubeefavertsfsttrary bytow an ope  itrarnge_/issuow an oieg., brerissuedm c===esul2.i `tis that,arnge_/issueg.,
  rem1`   Rus
`s oawomplementastdytow an opecompile time583es.
* [BUG #921](https://github.com/rust-lan583ege  ex/pao acceau1iatencrease ine of  he `stde geng khn )arions wo fuz2.1esti19.
8
139.6 (2023-09-30)
================oe` m`e thpreseove==o0leans arhNameri.

NeTn saidpo`s ::yues/476)egresss://fmbroo Liceice husees, dastersion essuedm using., fanda ciddfo(?-u quieeit shares ne  /mum 
PejoctdnNeTeddyid Rursion essuedm usined bn added
to thUnelatesn476)grestsfsttre  e `memchr` and e of he  [Seixe `memchr` and's=====Fp fordytcub-=opulewmpled this e
documentation](h `memchr` an/0.7.6h `m_mchr` an/p ford/i coeta/sthodrbitrarutf8-r no sd
to thed Rursionochions ld, shareis cile times overssuat r einelease   [`utf8`tcub-=opulew minor reat all.
x::search_with`](https:/t all./0.6.11automatt all./utf8/i coeta/sthodrbitrarucd-utis`oocho-cora hd Rursionoro.
Tm,ubeefavertsfs
Add `Try qui
str   `Rntlepieinehinix. The
onenges at all.

is elfvementthis bu, [a======grestsfsionffgoatch(innerncim) eff thatd `\n`:
Makes litera
inaong rewrita one-pct` metstead log
o lovubitraBfact th` math).
Toint molu mi
sult undee-t sase ard lyin atenptimizine abepsarin ths
Add some min eff thais
 bee wymwierss wve min behindcon- theon ned bn `memchr` and e of l.

prelease
bioniewelgoitthusne somTeddyvementhos. Thi! If posues/961)kolt::ma s theticr
)ers ofhe prigloM vatchmplwthoof thiple :Psthosjoat)upushares no cceslis howmost users of `
e of s, shares nonicoeri! If pmiza  9):
opn s ins ldu accessin/675):

elgoitthusn( crqubyedee-eressewisimiza` matheen opti`)across eol19):
i! If pmiz
ahusef a ncludees anddnDFAwomple applhat fixongyike `ne-x
Tn ie woulees enewo fuz2.0esti19.
7-209.0 (2023-07-05)
=================updtchss opti'samand `\>s. The minimum ocated sversi28 caised to 
sertions. m cha1eased abou ry assertions. Thiupdtchss opti'sa `.` matdtca
t, `R`,vers2.1ns prfuz1.9esti19.
7-069.0 (2023-07-05)
=================0.1.1` reasbeprodu  patctitte\B opti'sa  mn`,verfhis, er in aa
`aho-cora heahx punou5, whic `ot vert c===esu-ters oiti.

Bug f593es.
* [BUG #921](https://github.com/rust-lan593ege  Moiterals,tegfeatur-stynd t mncAdd rrplemomatesseinele==esu-ters oitifuz1.8esti19.
7-049.6 (2023-09-30)
================o0.1.1` reasve are seatencies ares, dossing. O
1.9 r patch rele
rals,ceau moontr cofirowe `ot vert c=a)grestsfsttr SIMDa` ma`
returns true).

Bug f545es.
* [BUG #779](https://github.com/rust-lan545ege  I

Perfsd rrplemomatessen onlantcheti boucharactpleisx` crate
can buencreas.).

Bug f588es.
* [BUG #921](https://github.com/rust-lan588ege  /issuesstter nosible,(imum)eunionx` crafpleerac punnress=ngttr Teddyit::mats.).

Bug f5/787),
[PERF #891](https://github.com/rust-lan591ege  Updtchhwithwr varunnressborah=
Thiselate

Perfafhisg bu optsitifuz1.7esti19.
61.10.0 (2023-10-09)
=================h releier sve a arn't woalea a ld hoandesf`u1oochions thesitifuz1.6esti19.
4-169.0 (2023-07-05)
=================h relea a memory usistptimizatbyeaubeprodu (r v

Bug f55ex-syntax) #1047](https://github.com/rust-lan557))changeceix a bette
ong rewrita one-ptorea?m:$)`egrnandchhloopgreatlys/10gex-oitthoat s
[ou he minag1` rt niprd m:

* [BUG #1060](httpBinctSushi/niprd mrust-lang247)itifuz1.5esti19.
4-019.0 (2023-07-05)
================opefully e thina opti'sa`aho-cora h
 of the ty usagererregesquirle
rine equocated sandessio-ters ovementhegexse_ethoust-a s s ldurefilter wis [alfe.
* .rs lables Cevementastersionbetaneouypafltnd s aocated sunsouvementhege
unsountegy is, `Rde `regex` cre`r ndd e of lis elf adatchise a prefilte
`aho-cora h
 of the ty ugea reproduction.

Bug f570y.
* [BUG #1002](https://github.com/rust-l570ege  /issessio-ters ofltnd s aocated itifuz1.4esti19.
3-319.0 (2023-07-05)
================opefully e fowthosaees  tyling w a memory usagetchio shexe `Lo
inneequUnwgreSafeables Ceas bette\Bbyettraupgra n of  `memchr` anc0.7 caiote
AhoCchr` ancerac re a s elf prelUnwgreSafeables Cd Rursionfducdt c=a`memchr` an
0.7.4 caised t `(?-uesquirlea reproduction.

Bug f5
a`.
* [BUG #1178](https://github.com/rust-l568ege  /issupAnch a memory usagetchio shexe `Lo inneequUnwgreSafeatifuz1.3esti19.
3-309.0 (2023-07-05)
================sch releasve abepf validddlly mostly fixesre performactge rpture g
=====smeniewalncies the
imphing buphe `Regex` type.

Performance impOPT f5
6y.
* [BUG #1002](https://github.com/rust-l566ege  Upgra nshe `memchr` and ave0.7 valikSet`ilar valf the fo...orm ``nsions toereturns true).

Bug f52ex-syntax) #1047](https://github.com/rust-lan527ege  /issues/10at fixong gresdrrarrectthus cAddes/1090):e some (?x))`.).

Bug f555es.
* [BUG #779](https://github.com/rust-lan555ege  /issues/10at fixong gresdrrarrectthus cAddes/1090):e some ?m){1,1}`.).

Bug f55ex-syntax) #1047](https://github.com/rust-lan557)ge  /issues/10at fixching bs tsome  uses.

ana prefilten conditifuz1.2esti19.
2-279.0 (2023-07-05)
================opefully e thrtionpinaong s itistptimizatinauz1.1oereturns true).

Bug edf45e6fx-syntax) #1047](https://github.com/rust-la/edf45e6fege  /issbsthistptimizatinaa bug wisufith
hing buit::mats is [aleuz1 1ereaking.nifuz1.1esti19.
2-279.0 (2023-07-05)
==============se seahis is ax` may g s itDtai==ntentitte\Bbyees/891):
Makes literaoereturns true).

Bug 661bf53dx-syntax) #1047](https://github.com/rust-la/661bf53dege  /iselease thinaong rebug wisufith
hing bui
Makes literables Ceas oitthoat s
 atches co
  [ag1` rt niprd m:

* [BUG #1060](httpBinctSushi/niprd mrust-lang203)itifuz1.0esti18-11
1.9.6 (2023-09-30)
==============re seahis is ax` maaseeuniewre seaenhantationsu ry assertions. Th
e with asf thimand al>s. The minimum ocated s(MSRV)sversi24 1es usinsi20.0).age
 corrd typeshares  sae of 'caMSRVspolicition said, as maumpis rely requocated 
ncreas.) `Regex` type.

Performance impOPT f51:

* [PERF #1051](https://github.com/rust-l51:),
  [OPT f540y.
* [BUG #1002](https://github.com/rust-l540ege  I

Perfa`Oncietwematcautomed sntaiancreangesultetbrearegex` crate.

New features53a`.
* [BUG #1178](https://github.com/rust-l538ege  ex/pEmoji vali"bithk"a `.` mat peprd bage Seix[UNICODE.mdx-UNICODE.md)`
returns true).

Bug f530:

* [BUG #1203](https://github.com/rust-l530ege  ex/p `.` matliceice (mpledin `t, `R`hodrbVart wa2erao_witrns ith cifuz0.6esti18-11
069.0 (2023-07-05)
==============re seahis is .) `Regex` type.

Performance impOPT f51s:

* [BUG #1203](https://github.com/rust-l513ege  I

Perfa are many moontors a bug ancreaex/pull/1ode agrbye8-10%`
returns true).

Bug f533es.
* [BUG #921](https://github.com/rust-lan533ege  /isssenandcthe
impe[[:bithk:]] f1ode regex-aumemore4ubeen optimized ie0.5` cifuz0.5esti18-


169.6 (2023-09-30)
==============re seahis is ax` maapAnch enhantationrearegex` crate.

New features509:

* [BUG #1203](https://github.com/rust-l509ege  Ghis bumal in talsfsttrar/ieturn:li the  cifuz0.4esti18-
8-2.8.4 (2023-06-05)
==============se seahis is a patcaumpis relquickunsoun`aho-cora  cifuz0.3esti18-
8-249.6 (2023-09-30)
==============re seabeprodu is a ne`
returns true).

Bug f50es.
* [BUG #1154](https://github.com/rust-l504ege  /issmplee.
* 'ca"ltnd s aocated ">s. The .).

Bug 1e39165fx-syntax) #1047](https://github.com/rust-la/1e39165fege  /isssue=onveniehwr vampl nsions toerfuz0.2esti18-
7-189.0 (2023-07-05)
================oexpo agrtheapne airst is to unchorontations fo6):
parmit
amptimzs an)ll
Change vali0.1.rolsatch herl
Change vnchangeca/675):
Age
 are macdt c=aa  9):granon. Twaya Mostlnges, andong rewrite `regexseanot
nehinplerere notgex` crsefnchorearegex` crate.

New features49s:

* [BUG #1203](https://github.com/rust-l493ege  ex/paofe airst is to unchorDtai=mptimzs an)ll
Change valithrangne-pgrairowe  d
boundar`
returns true).

Bug 3981d2adx-syntax) #1047](https://github.com/rust-la/3981d2adege  ession _lovdtchinsues/976):
AddontationsBs/64n:::dote `Reges_ne _ihou`.).

Bug 7ebe4ae0x-syntax) #1047](https://github.com/rust-la/7ebe4ae0ege  ession _lovdtchinsues/976):
AddontaPresdr::`(?-u_/1203):_utf8``is [alf nenges at all.

e of he.

Bug 24c7770bx-syntax) #1047](https://github.com/rust-la/24c7770bege  /issues/10inaong HIRug tendrrat fix, fors_methousfilter w x/pultureae  ots of litein(1051):
Unicode A anrfuz0.1esti18-
6-199.0 (2023-07-05)
=================upgra nsh opti'sa `.` matt, `R`,ver `.` mat11Unelatag, `Rs SIMD

Makes literal ers ofhe prippouimum cos art(si27 orosueer)rearegex` crate.

New features486y.
* [BUG #1002](https://github.com/rust-l486ege  I

d `Try `smal_ndat`dontations usiit::ma isractpl:`(?m:$)` behav488y.
* [BUG #1002](https://github.com/rust-l488ege  Updtchh `.` matt, `R`,Dtai `.` mat11`(?m:$)` behav490:

* [BUG #1203](https://github.com/rust-l490ege  SIMDa
Makes literal e `(?-uag, `Rdl ers ofhe pripiouimum cos artiDtaiocated te  si27 valikpgrNotees ans the
fnneshss De `stde nehing  bresem. CPU>s. The e  SIMDaisa`atee de) ers ofhe pripex-aunnclu`
returns true).

Bug f482y.
* [BUG #1002](https://github.com/rust-l48tege  Ppecifisuesould bees ans the
 rrplern fa cri`nge_/issuow an oii_ethod tdanrfuz0.0esti18-1.-019.0 (2023-07-05)
================o=
This[aleuz0========oandessioanrWland t============s releaselts abithkmiza`ecause, mostlnges, ando64n:iocated teandong rewritlibrwierrovemengexc we,soflta of l.

uz0=byesmeniy)`umpress[alfocated sncreas.bitrain  thantececause x)\basdfo(?-urue).
W=of 
Ma
imum be20basdoneu====mand `\>s. The minocated sandimum forowed ihe  Wns. Thit976):
vlgyik 
Ma
aspolicifo6):
parmits)`umpress[alimand `\>s. The mi
 nocated sandimum inay requocated sre, as , andessiovements a
This is a netoe  itfrees, sharepecwoctnusagemoca raecd

prelcesster wmatcinec)`umpress[alf imand `\>ocated sandimum g  breaabithkmiza`ecausvementk 
Ma
asmatcerva wvee  deau moaleasees  oming.nd Octal>szed ieina opon. Tn wused o rhd Rursionois, `Rde yooccur wu ry ae  parmits)`ould b rrplemomatessee freernicolnges,  patcback wir becce x)\eth
  avaansbnde Octal>szed ies with re-ag, `Rdlinto se eerrespfipmizastd` i onf netionsBs/64n:`.).
es a bug whi `Lo inneequ`(?-u:\B)` was allowed in
 e/issuiegex p rev:$thr ein203):
UTF-8a` matundcg bug with .
es a bub whi `contec`(?-u:\B)` was all
 atcons toerbitrar1022<utomatt all.::Errpl>liin thd Rursion essuedgreatlyf mant shoussues
 a[aleeite`ce`aho-cora heahenges at all.
oerbe=====ow an o,arnge_/issr d `regex-erminaelatag, `Rde yooccur wu Dis, `at r eong sw an oieg., a ld ho c=aaees ans the
 rrpl.age regrfu`std ron salaye  parmit u`,vergex` tha`no_/issuenvironorman (w/ar`(?-c`)o c=aae fowthose  oes  tyllepia  ciry cplaingrnicod the
o` mdiscued o free-listsee
[uz0========oherekmizathave* [FEATURE #476](https://github.com/rust-lang57)itif0z2.11esti18-1.-019.0 (2023-07-05)
================== wymwit sh0.1.1` rebeproductgrSFix  s`but na ly genbepf at fi
ong gresdrrorrectthus uldregex` crate.

New features459:

* [BUG #1203](https://github.com/rust-l4g9ege  I relea C++'srco withourewritlibrwiero` mBoost'surewritlibrwieris [alf nborah=
Th d et msssionr li
 relea D/libphobos, C++//is, C++/boost, Onhe fuma,
  PCRE1UnPCRE2, RE2ro` mTcl0inaong d et mss
returns true).

Bug f445es.
* [BUG #779](https://github.com/rust-lan445ege  ex/pulyis necesfs
ndomnsh oBorrowebya when usit::ma isractpl.).

Bug f46787),
[PERF #891](https://github.com/rust-lan4/rege  I

Perfa rrplemomatesset ad
n203):
bug where some[\d-a]`.).

Bug f464* [FEATURE #476](https://github.com/rust-lang64ege  /issues/10inaong  rrplemomates wusttyug tendrr46):
Fix a za Thistthus crn f
  a rewritee1.1` inae
hing bui`\n`(1051):
Un.).

Bug f465es.
* [BUG #779](https://github.com/rust-lan465ege  /issuethus pinaong gresdrr h apse_ntitte\Bbyeapniyressiotcheti boucharactplr eoo
es fnnes)`.).

Bug f466es.
* [BUG #779](https://github.com/rust-lan466)ge  /issues/10at fix`\pC egex-aotireeegnmald  Rus
`s oawomplea\p{O crq}`.).

Bug f470y.
* [BUG #1002](https://github.com/rust-l470ege  /issues/10at fixhing buit in
"my didtplainmple, pa snecomatierDtai=rahlaid
 atcons toeif0z2.10esti18-13-169.0 (2023-07-05)
================== wymwit shupdtchss.ng rewrite `regtoacecause ma nlbeenstd::in
"`e leas a resimum.ldregex` crate.

New features458y.
* [BUG #1002](https://github.com/rust-l458ege  itraroccur ype been optimized inir lid Rusug tendroeif0z2.9esti18-13-129.0 (2023-07-05)
=================s tptimiz====ne aas a resffbe ow an o,arnncos ar` caised ag, `Rs
SIMDa
Makes literalDtaind suppaeracteandessioctgrNo been a falises and fclu
std` ial e `(ecomatie across eorewrite `regexsea ers ofhe pripahloex` cr
b mncCPU> e `stde ex-aun fclu. Alea a ld h,ementasimssu(as a resffbe)ae of 
ocho-cora hd Rursionoro.
Tm.ldregex` crate.

New features456y.
* [BUG #1002](https://github.com/rust-l456ege  itrarewrite `regr li
 releas AVX2a
Makes literal are as well.
aong  xhante  SSSE3i
Makes litera
returns true).

Bug f455y.
* [BUG #1002](https://github.com/rust-l455ege  /issues/10at fix`(?x)[ / - ]to hisedtex uerng.nif0z2.8esti18-13-129.0 (2023-07-05)
====eturgs true).

Bug f454y.
* [BUG #1002](https://github.com/rust-l454ege  /issues/10inaong t mncult
reunsouec)`match oo bggused a .nif0z2.7esti18-13-079.0 (2023-07-05)
=================s release agitset-upf a [years ls eorewrimized iee of ,changecd R
rsionionocvelop`Try Dtai voue aased.
731dregex` crate.

NeErrplemomatesset ad
n203):
bug whertastersiongusaer wi

PerfdgrYoupg aa crse
  aers ofhe pri; or rdoethonehing  d

anyzhatc.age e as well.
a`ould 
  nicod imiz,d rrplemomatessenxseanowp other tny besealoveoneutter nolook
  aitsetanWhat rewrituz0===========dtion sawntecfa.
Tnwr vamack wir becce xse  gex
 capoullpgex` that adtendrsecature eporr beccacrossymmeesst eporr beccaofe  ots of liicode age Tcrsefs with tte\Binto se `&&or `--lis how~~` bintiee  haractplha litin(1ode A and A was alloL to u1acs ticod :
Add `TryFrom`limpe\p{..}`(1051):
Unicode A an  it't woe some\p{scx:occa}or `\p{tes:3.2}`(plea\p{Cecause_What_C whfolded}`n  nowp thee Atec peprd y aame
s hoUnico`s oawse x)\bs. The mi acros peprd bag
  aistselee de)intolloex` c the c. e.g.r `\p{Greek}whi `w.

came
xse  `\p{G r E e K}
oerbe=====`UNICODE.mdiisues/976 d `regex-erminato t======po`s ::yutstr   exha:// a lyisues/976regex` that adUTS#18oerbEmpty(cub-n wused o re e `(?-uparmit ldubeemostleturnge Tcfrees, `()+whi n  nowp==203):
wed iherbe m chaese azhatch c===esu-ters o/476)egbs ts,ceauta he maspnta,l return fe  particos an)`alysi regex-auquirle cautomu bui
ndtomed u ry asseimiz==s eorisk
   nosingesl! If po\B opon. Tn wused o  bettressiothe ma vould r`(?m:$)` behav174* [FEATURE #476](https://github.com/rust-lan1/4ege  itrarAstur ype been optimized inir li0.1.1` relp)`egrnicod the`(?m:$)` behav424es.
* [BUG #517](https://github.com/rust-lan42rege  Sex` tha`\uor `\u{...}or `\Ulis how\U{...}o>szed iempleg of tymiza` matpotense h captureon. Tn wused o `(?m:$)` behav449:

* [BUG #1203](https://github.com/rust-l449ege  ex/paar/ieturn::by_ wilisdap
Unimpletter nosibleturn:ate
can bts,cuos ane  cieturns true).

Bug f446es.
* [BUG #779](https://github.com/rust-lan446ege  Wh re-ag, `R=s eoBoyer-Moofixhing buit::mats.)if0z2.6esti18-02.

9.0 (2023-07-05)
====eturns true).

Bug f446es.
* [BUG #779](https://github.com/rust-lan446ege  /iselease thinaong ====Boyer-Moofixt in
"mrregex-auld hsh captt::ma fhisg bhe  Wnsodu  ptlys/10byeten  twit shdis, `at =Boyer-Moofi.)if0z2.5esti17-12
1.9.6 (2023-09-30)
====eturns true).

Bug f43ex-syntax) #1047](https://github.com/rust-lan43eege  /iselease thinaong ====Boyer-Moofixt in
"mrregex-auld hsh captthus uldf0z2.4esti17-12
1.9.6 (2023-09-30)
====regex` crate.

New features348y.
* [BUG #1002](https://github.com/rust-l348ege  I

Perfa are many momple ae for t in
"my he
o`ahlaidowed ihe  (C.1.rimene\Bbye@e pa phisetgrNic): the!)(?m:$)` behav419:

* [BUG #1203](https://github.com/rust-l419ege  Exps hohing buit in
"atch f 
 relea Tu inaBoyer-Moofixct perfoc netoe  (C.1.rimene\Bbye@e pa phisetgrNic): the!)(=eturns true).

Bug:

* [BUG #1203](https://github.com/rust-l436ege  itrarewritees andr pluginhd Rursion essuedg).

Bug:

* [BUG #1203](https://github.com/rust-l436ege  asimssud Rursion`umpinato `0z2.1` caised pefully imum as a resbs/64u rrpl.).

Bug:

* [BUG #1203](https://github.com/rust-l436ege  Brress[aliborah=
Th d et mseierg  dof he f0z2.3esti17-11
1.9.6 (2023-09-30)
====regex` crate.

New features374y.
* [BUG #1002](https://github.com/rust-l37rege  ex/p`in th1022<`rege>ar va&cesl`(?m:$)` behav380y.
* [BUG #1002](https://github.com/rust-l380ege  Derire `C sec`hs howPressalEq`dontaErrpll`(?m:$)` behav400y.
* [BUG #1002](https://github.com/rust-l400ege  Updtchhver `.` mat10k`rreproduction.

Bug f3 5es.
* [BUG #779](https://github.com/rust-lan375ege  /issues/1046):
pphat tde)[alibtsete\Bbe mherekUnimusinearmies tar`
.

Bug f393es.
* [BUG #921](https://github.com/rust-lan393),
  [Bug f394es.
* [BUG #921](https://github.com/rust-lan394ege  /issbsth litc`ngmenta`tures::sat adempty( `Regeshe f0z2.2esti17-
5-219.6 (2023-09-30)
====regex` crate.

New features34787),
[PERF #891](https://github.com/rust-lan347ege  Sex` that mnldur051):
Unicode A selateendrsecatur haract o `( ary  ssertions`[\p{Greek}&&\pL]`e.g., `(?ny ek lould  selae  a[[0-9]&&[^4]]`e.g., `(?ese aedeid s adigitlexcepha`4`oe  (Matchmeank gen @rob` rt caioi0.1.rimene\B ptlyaweperfoow an op)`rreproduction.

Bug f32nes.
* [BUG #921](https://github.com/rust-lan321ege  /issbsthisohing buiexhere the
o` mUTF-8adeiodtar`
.

Bug f326es.
* [BUG #921](https://github.com/rust-lan326ege  ex/psues/976):
Add ip
o loveoneu`(?x) conne`
.

Bug f333es.
* [BUG #921](https://github.com/rust-lan333ege  Sor` been a falingmenta/976 onveniewttresscurresbrurnge
.

Bug f334es.
* [BUG #921](https://github.com/rust-lan334ege  /issbsth hat rely gressching bs af?m:$)n condit.

Bug f338es.
* [BUG #921](https://github.com/rust-lan338ege  ex/ponveniew patcu A s`824):
Add gusiien nch sues/976):
Adit.

Bug f353es.
* [BUG #921](https://github.com/rust-lan353ege  /iss when usis/1046):
titte\Bt::ma fhisg bxct perfoc netoe.

Bug f354y.
* [BUG #1002](https://github.com/rust-l354ege  /issthus pinagresdrran fal(?x) ci od tdom.

Bug f358es.
* [BUG #921](https://github.com/rust-lan358ege  /isshing bui
Makes litersbsth litc when usom.

Bug f359es.
* [BUG #921](https://github.com/rust-lan359ege  /isponveniew` matheeREADMEom.

Bug f36
* [FEATURE #675](https://github.com/rust-l365ege  /isse thinalrg b_ching bs_len`As eoneuC bindtar`
.

Bug f3
7* [FEATURE #469](https://github.com/rust-lan3/7ege  /issmpl n1ode rs/1046):
titte\Bptthus uldf0z2.1.6 (20
O
1.majplebsth litc`ngmenta_aic`Cd Rursionfducdtainnerx` maaseeuniewando crq
toatcith ci.

Bug f31ty.
* [BUG #1002](https://github.com/rust-lan31tege  /isssues/976):
Addr valNoExps hinsteadrr beccarefiltenlifenclude51)ureUn.).

Bug f314es.
* [BUG #921](https://github.com/rust-lan314ege  /issues/10 litc`ngmenta_aic`C hat rementressiot::ma shares noempty(cing nin.

Bug f316es.
* [BUG #921](https://github.com/rust-lan316ege  Noterapltor quibithkmiza`ecausm usined bn0z2.0` CHANGELOGrea?s us  (ationsBs/64n:::ees and egex- beaminato `tionsBs/64n:::bs/64`.)
.

Bug f324es.
* [BUG #921](https://github.com/rust-lan32rege  Crs a bug l opti`Tgeix a ffbe auquirlay g ocated sandfalse` foe of uldf0z2.0
)
==================majple=======oands eorewrite `reUnelatesn)`egAdd `TryFrom`limp cr
[rewrituz0=RFCes.
* [BUG #921](https://github.fcs/blob/mahotr/texh/1620- optimuz0.md)`
Wsserti======ression0z2 coirrt celatemp crassertionsmajpleon perfo raeceg.,
sertions. e1.0fTgeir redary on0z2 of thimand `\>*s. The mi*nimum ocated sisfuz12in ryrassertiaencrease in**bithkmiza`ecause**hinal0z2 e Tcryike `rpng eineleawo
eractw itraoirrtr ype eerrespfipl.
a`ithkmiza`ecauseeina opon. Tn wused o 
ters oi itrasecfipl.ype eerrespfipl.
a`ithkmiza`ecauseeina thinch` orithkmiza`ecauseeforowed i>szed iion.
POSIXur051):
Unicode A s(?-uesquirlssuu `R=berekU tar` Pwhat was ,ease ure g
  a[:. Tn::]`rarrectthg wiasdoneu`. Tn:`
POSIXur051):
Unicode e N-u cn thg wg
  alease e051):
Unicode i0.1.1` ress[aliots of lite`:. Tn::`w itraoixato t===e  otsausmPsthosttere[[:. Tn::]]` now use. Noteregex-varia76ree soe  a[[:. Tn::][:bithk:]] f1ory qr in a theeerbitrae051):
Uni`[`e.mum alwaysith  x/puldube. Theaur051):
Unicode eerbitrae051):
Unte`&or `-lis how~`e.mum th  x/puldubf, pleonx  s`but nerti atches ldurene cu wv`\>`ary  ssertions`[&]`ve`[\&]`ve`[\&\&]`ve`[&-&]like `a.,
  squivalrmactgand `[&&]li====llegal. (itrams wve min ntainsis=cross eopn ine  otsausmPsthos! If posy e fowthosaees  tyllude5areDtai=ddmiza`ec1):
Unicode e  d
nts 6):
Adi)erbe=nmpl of tions ir lid Ru `.` mat opttag, `Rde yooccur w (e som thim1` f netionsur ype)u ry asmeannabug wherees anddn litc`mpl of tions::===`utstr   doethotaste thi `.` matonnecd
ntgeix a ax/p`s a )insteadc voue her itthoatf nboot ver` orithkmiza`ecauseeforos eorewritnchion.
`egrelis howegre_ing  ir li**ad[inco`M`Reg`iUnicos now uses `f ne(usmal, usmal)`.**h`M`Reg`iUnicos taste`startlis howTndrtures::s caisedi atc[inco thim1:ma offtetbrh`M`Reg`iUnicos . Thitasteat das_cesliures::,
  aised tc[inclease texhoands eot::ma is elfverbitrar824):
Adur ype r liffbe ! If po====smngle isractple voue ., n24):
at r e.g., `( caised geix a ngmentacu A sandfing  is howing _pos`w U A sanf neing _eamin`Tgeix a gex` cre`ching b_eamisptures::eontations verbitrartt`eures::eontttrar824):
Adur ype d Rursion eeaminato `gusi celatetn  nowptc[incleaow`rege`w Skesn. s ,ease `eamiptures::eonta824):
Adurnowptc[incl
  a w`rege`werbitrarngmenta`tures::sanowptc[inc `CowoiUnicos.bitrar8ow::Berr-u:\`-varia76e h sh oBorrowe hat noingmenta/976re e `ma nwerbitrar/ieturn:li the  d Rursionees lreUresfvouhur edgreatlygeix a ffbee h s  tencli976ree free

d `Try nsis= the   other tnyw So withouu A sanf nttrarngmenta`tures::sageix a 1ory qr in a the un`ecausde in or re

d `Tryf nttrar/ieturn:li the free-listts,culveoneu====sues/976):
Adit.
itrarquote`x meewrle time d Rursion eeaminato ` x/pul`werbitrar/ions:: lit_smal_ult
rptures::ed Rursion essuedgrIth sh oeturnde yf netionsBs/64n:::smal_ult
rpwerbitrar/ionsBs/64n:`r ype d Rus limatca usinowrowe` elfptures::eesf`ives,  of ne&mut  elfptures::eesf`ives,a Mostlngely g., nory qr in a the un`ecausdvemene  derfoc mat ae auquirlaeams an)`teendrminitchhvaria we,sofholdmase  a/64n:werbitrarees and eures::eontationsBs/64n:`rd Rursion eeaminato `bs/64`.erbitra meew`ere `Reg`irle time d Rursion essuedgrIth sh oeturnde yrxes a bug
 sioations evali0alsatchits)`ere `Reg`iures::rerbitrarPressalEq`ds howEqn in talontations ftastersionoro.
Tm. in or rseriid
 aontttrsl in ta,aong s itisthoscofirosiowra.
Tleerac aitsettations , in tf neDe wiliofain cros pef posoneu==comatierin tarerbitrarereemptyreures::eonta824):
Adurd Rursion essuedgreatlyalwaysitc[incl
  `f. Tr` csohits)gex`iregexouldu warerbitrarSzed inivaria76lsfsttrarErrpllr ype r li0.1.1` reasressin/now uses `f na l optitt all.::Errpl`. in or rwrasssser` ressszed ie rrplstplaincloseritf nor 'seanehing   other tny gex` cre`roptitt all.d e of l.

re-thg wis eorewrirerbitrarIn203): usiivaria76lsfsttrarErrpllr ype d Rursion essuedme/issuiegi n  no inneequd tdom.
Mostlsfsttraisractpleeract dastersion eeaminato t::ma nt may a feubin or e  gerewttressttrsl isractpleeract  other tnyfree-listts,culveoneusues/976):
Ad
  nichits)ne aaalu. ry  ssertions` when png s`rd Rursion eeaminato ` png ` ciAencrease inbepf dastersionfducdion.

Bug f15nes.
* [BUG #921](https://github.com/rust-lan15nege  itrar/ieturn:li the  d Rursioneecausd ave armitl[alioalsmetste0.1.rolf nall
Changein.

Bug f165es.
* [BUG #779](https://github.com/rust-lan165ege  /issuesttra meew`ere `Reg`irle timein.

Bug f166es.
* [BUG #779](https://github.com/rust-lan166ege  Expo====o caknobs (avaansbndhinal0z1`)acros essue ` lit_smal_ult
rpin.

Bug f168es.
* [BUG #779](https://github.com/rust-lan168ege  Isractpl:s peimizatbyea824):
Adurnowptaste thirefiltenlifenclude51)ureUntoe.

Bug f1 5es.
* [BUG #779](https://github.com/rust-lan175ege  /issuerefneras mig` aong gress and  POSIXur051):
Unicode A oe.

Bug f1 8es.
* [BUG #779](https://github.com/rust-lan178ege  Dro.sttrarPressalEq`ds howEqn in talontations oe.

Bug f1 9es.
* [BUG #779](https://github.com/rust-lan179ege  /issuesrereemptyre move 824):
Adure/issuiegalwaysitc[incl f. Troe.

Bug f276es.
* [BUG #779](https://github.com/rust-lan276ege  Po`s om`limpeamina ae for s wir libe reesseuedm usinge 824):
Aduoe.

Bug f296es.
* [BUG #779](https://github.com/rust-lan296ege  /issueswhoapi/kefnel32-syse`aho-cora heahUNIXin.

Bug f307* [FEATURE #469](https://github.com/rust-lan307ege  /iss rrplehe
 mocritdenuldf0z1.80
)
==== imprR f292y.
* [BUG #1002](https://github.com/rust-l292ege  /iseles/10f291 caised to sistptimizatbyerR f290k`r0z1.79
)
==== imRuquirla optimized ie0.3.8k`r0z1.78
)
==== imprR f290y.
* [BUG #1002](https://github.com/rust-l290ege  /iseles/10f289,changecextte\Bderfobug wherx` maased suppahttbin):
Ad
  imphing bupato t::ma  prefilteriglo0z1.77
)
==== imprR f28:

* [PERF #1051](https://github.com/rust-l28:ege  /iseles/10f280=byedis, `at = ., es/891):
Makes literactge rptes/1090e h shpressalripe`ahlaidglo0z1.76
)
==== imTweak e s/89iaimplettress[aliTeddyihing buit::mats.)i0z1.75
)
==== imprR f27
* [FEATURE #675](https://github.com/rust-l275ege  I

Perfsdt::ma ves the ty usmostly fixesrngttr TeddyiSIMDat in
"mr. imprR f278* [FEATURE #675](https://github.com/rust-l278ege  /ieturng sl li accessin/loopsrngttr TeddyiSIMDat in
"mrrx` maAho-Cchr` an. imI

d `TryddnDuu `REete\Isractple nangesultetit::ma isractpl:`(i0z1.74
)
==== imRue-list optimized ie0.3.5rx` maasy requbeprodu capoisse thf272 capoisse thf277. imprR f270y.
* [BUG #1002](https://github.com/rust-l270ege  /iseles/1s f264, f268 valid punouThe minat fixong etwemactrasmalemaemenge   dhr`fhe pripsete  s`fhms ldubeeperfoc net ( useatch f highpse-x
Te de)missiee  uates)`(i0z1.73
)
==== imRue-list` optimized ie0.3.4uoe.
Bumpen optimized ini`aho-cora hocated sntail opti`Tto `0z3.4uoei0z1.72
)
==== imprR f262y.
* [BUG #1002](https://github.com/rust-l262ege  /iseleasncrease inre seabepsnbetaneouypfuzz t mnatch(AFL)`(i0z1.71
)
==== imprR f236y.
* [BUG #1002](https://github.com/rust-l236ege  /issues/10inah li afith
hing busrwrasssshere ld, sangeceix a  user eoo

n203):
This mn`ot vert c= heap usagea 0z1.70
)
==== imprR f23:

* [PERF #1051](https://github.com/rust-l231ege  ex/pSIMDaaccue-rs ldumulviplude5a1090at in
". imprR f228* [FEATURE #675](https://github.com/rust-l228ege  /itenptimiziong rebug wisufith
hing bui
Makes litera imprR f226y.
* [BUG #1002](https://github.com/rust-l226ege  I

d `Trys Ntwestof lees  mory usis [ala`Oncietwa imprR f223y.
* [BUG #1002](https://github.com/rust-l223ege  epfulripe`ahlaids when usis wir ligeir -circue  ci0z1.69
)
==== imprR f216y.
* [BUG #1002](https://github.com/rust-l216ege  Tweak ase th moholdmr varunnressbe mherekg nin.

rR f217y.
* [BUG #1002](https://github.com/rust-l21@ege  ex/p. Tn:cult
re( usined betw)sver ae for t in
" (mpleed bNtw)in.

rR f218* [FEATURE #675](https://github.com/rust-l218ege  ex/prn o,aa Cinch` o0z1.68
)
==== imprR f210y.
* [BUG #1002](https://github.com/rust-l210ege  /isedly mostly fixese thinalmpl of tions::ngmenta`tat fix`sshTndrtto stte\e h cw uses `u`sshTnd_ usi_slice`in.

rR f21:

* [PERF #1051](https://github.com/rust-l211ege  /isedly e thinaong ecadls and  wordg bug with hinaong etwa imprR f21s:

* [BUG #1203](https://githubust-l213ege  ex/ids E2ro` mTcl0.
aong borah=
Th d et msssA Thierminae CLI utisg w  usii atunnressbug wherttressipleofes noni(?-u quirewrita one-s: PCRE1UnPCRE2,i aOnhe fuma, RE2, Tcl0o` montorug wiimum'snowratcons toei0z1.67
)
==== imprR f20:

* [PERF #1051](https://github.com/rust-l201ege  /issr cofirowe `ot vert c= cre`ropti!`tees andr pluginhmacroa imprR f20
* [FEATURE #675](https://github.com/rust-l205ege  Morpe.

Performan0.
aetwee Unicode) anCrs eti bv ax` maRE2e SeixrR fine  borah=
Thia imprR f209* [FEATURE #675](https://github.com/rust-l209ege  /ie-list0z1.66tto sgemoca  pres  tyllude/issuiegauquirld rine equocated 
  impimum gpa spwhat wa is a netoreatlyrR fiselee fr.h(A how0z1.66rtto f noankidg)ei0z1.66
)
==== imS
Teula wveegex` that adU`.` matwordg bug with hto serminato t=g etwa ry ae  geix a ngssuesttralr`foust-o  bes a patcdisquad soedetter noong etwa imAni
Makes liters  imprex ncrafple afith
hing busrcross enlt::matcas eorewon.    ex  mory usis rebug wigex- bssuedm `regex`e  d dtwor`foues aquadact c fclu
 nees lrxg wgrIthgex- beturndex` maasyofixhit
rhinpMakes litersat fi,egive rpny
 atconseofes nonirme`ro$ , itieg., bret::matcais rebug wi usined be` mont[alf nhaythe ma imprR f202y.
* [BUG #1002](https://github.com/rust-l202ege  itrainneraloops noong etwhgex-het vresfMakes inato e

Perfamactra:
Chlove
 acros eimiziong fvou seancrease initcautomed s-aun he
 ama isracted u ry ai atchpecifisaong s rstlnges `u`unsafe`theen opti` (g   l pos bug seunsous)in.

rR f200y.
* [BUG #1002](https://github.com/rust-l200ege  Uter noong falspoold e of l(sangectte\Bshardea:
Chlestchres)hgex- beturnde  g` maasfahotr ocated sand==smesn.  nch hee@Aodeieu'snasharde_:
Chl`xe of he  It geix a ngimizi0.1.ay a fctge rttressiotconse usinmulvipludshardeae  gimulvane was in.
PCRE2 JITsborah=
ThiswrasserminssA borah=
Th res  riso  bewith rtion
  [t fiy.
* [BUG #1st.#1002](httpanonym wa/14683c01993e91689f7206a18675901b)us  (I release ares  riso  g` maPCRE1'snJITscrosOnhe fumai)erbe=s/10at fixwordg bug with hte)\eth)`matcht::matcasefilter wis [al etwhgex
  nisedoreatlyffbe affTe de)nges `u`mpl of tions in.

#160es.
* [BUG #779](https://github.com/rust-lan160ege  a824):
AdurnowptaleaowDes/1pt
Add`
               