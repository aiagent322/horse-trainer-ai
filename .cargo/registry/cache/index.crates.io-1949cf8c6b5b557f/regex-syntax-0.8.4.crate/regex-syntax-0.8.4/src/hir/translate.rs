/*!
Defines a translator that converts an `Ast` to an `Hir`.
*/

use core::cell::{Cell, RefCell};

use alloc::{boxed::Box, string::ToString, vec, vec::Vec};

use crate::{
    ast::{self, Ast, Span, Visitor},
    either::Either,
    hir::{self, Error, ErrorKind, Hir, HirKind},
    unicode::{self, ClassQuery},
};

type Result<T> = core::result::Result<T, Error>;

/// A builder for constructing an AST->HIR translator.
#[derive(Clone, Debug)]
pub struct TranslatorBuilder {
    utf8: bool,
    line_terminator: u8,
    flags: Flags,
}

impl Default for TranslatorBuilder {
    fn default() -> TranslatorBuilder {
        TranslatorBuilder::new()
    }
}

impl TranslatorBuilder {
    /// Create a new translator builder with a default c onfiguration.
    pub fn new() -> TranslatorBuilder {
        TranslatorBuilder {
            utf8: true,
            line_terminator: b'\n',
            flags: Flags::default(),
        }
    }

    /// Build a translator using the current configuration.
    pub fn build(&self) -> Translator {
        Translator {
            stack: RefCell::new(vec![]),
            flags: Cell::new(self.flags),
            utf8: self.utf8,
            line_terminator: self.line_terminator,
        }
    }

    /// When disabled, translation will permit the construction of a regular
    /// expression that may match invalid UTF-8.
    ///
    /// When enabled (the default), the translator is guaranteed to produce an
    /// expression that, for non-empty matches, will only ever produce spans
    /// that are entirely valid UTF-8 (otherwise, the translator will return an
    /// error).
    ///
    /// Perhaps surprisingly, when UTF-8 is enabled, an empty regex or even
    /// a negated ASCII word boundary (uttered as `(?-u:\B)` in the concrete
    /// syntax) will be allowed even though they can produce matches that split
    /// a UTF-8 encoded codepoint. This only applies to zero-width or "empty"
    /// matches, and it is expected that the regex engine itself must handle
    /// these cases if necessary (perhaps by suppressing any zero-width matches
    /// that split a codepoint).
    pub fn utf8(&mut self, yes: bool) -> &mut TranslatorBuilder {
        self.utf8 = yes;
        self
    }

    /// Sets the line terminator for use with `(?u-s:.)` and `(?-us:.)`.
    ///
    /// Namely, instead of `.` (by default) matching everything except for `\n`,
    /// this will cause `.` to match everything except for the byte given.
    ///
    /// If `.` is used in a context where Unicode mode is enabled and this byte
    /// isn't ASCII, then an error will be returned. When Unicode mode is
    /// disabled, then any byte is permitted, but will return an error if UTF-8
    /// mode is enabled and it is a non-ASCII byte.
    ///
    /// In short, any ASCII value for a line terminator is always okay. But a
    /// non-ASCII byte might result in an error depending on whether Unicode
    /// mode or UTF-8 mode are enabled.
    ///
    /// Note that if `R` mode is enabled then it always takes precedence and
    /// the line terminator will be treated as `\r` and `\n` simultaneously.
    ///
    /// Note also that this *doesn't* impact the look-around assertions
    /// `(?m:^)` and `(?m:$)`. That's usually controlled by additional
    /// configuration in the regex engine itself.
    pub fn line_terminator(&mut self, byte: u8) -> &mut TranslatorBuilder {
        self.line_terminator = byte;
        self
    }

    /// Enable or disable the case insensitive flag (`i`) by default.
    pub fn case_insensitive(&mut self, yes: bool) -> &mut TranslatorBuilder {
        self.flags.case_insensitive = if yes { Some(true) } else { None };
        self
    }

    /// Enable or disable the multi-line matching flag (`m`) by default.
    pub fn multi_line(&mut self, yes: bool) -> &mut TranslatorBuilder {
        self.flags.multi_line = if yes { Some(true) } else { None };
        self
    }

    /// Enable or disable the "dot matches any character" flag (`s`) by
    /// default.
    pub fn dot_matches_new_line(
        &mut self,
        yes: bool,
    ) -> &mut TranslatorBuilder {
        self.flags.dot_matches_new_line = if yes { Some(true) } else { None };
        self
    }

    /// Enable or disable the CRLF mode flag (`R`) by default.
    pub fn crlf(&mut self, yes: bool) -> &mut TranslatorBuilder {
        self.flags.crlf = if yes { Some(true) } else { None };
        self
    }

    /// Enable or disable the "swap greed" flag (`U`) by default.
    pub fn swap_greed(&mut self, yes: bool) -> &mut TranslatorBuilder {
        self.flags.swap_greed = if yes { Some(true) } else { None };
        self
    }

    /// Enable or disable the Unicode flag (`u`) by default.
    pub fn unicode(&mut self, yes: bool) -> &mut TranslatorBuilder {
        self.flags.unicode = if yes { None } else { Some(false) };
        self
    }
}

/// A translator maps abstract syntax to a high level intermediate
/// representation.
///
/// A translator may be benefit from reuse. That is, a translator can translate
/// many abstract syntax trees.
///
/// A `Translator` can be configured in more detail via a
/// [`TranslatorBuilder`].
#[derive(Clone, Debug)]
pub struct Translator {
    /// Our call stack, but on the heap.
    stack: RefCell<Vec<HirFrame>>,
    /// The current flag settings.
    flags: Cell<Flags>,
    /// Whether we're allowed to produce HIR that can match arbitrary bytes.
    utf8: bool,
    /// The line terminator to use for `.`.
    line_terminator: u8,
}

impl Translator {
    /// Create a new translator using the default configuration.
    pub fn new() -> Translator {
        TranslatorBuilder::new().build()
    }

    /// Translate the given abstract syntax tree (AST) into a high level
    /// intermediate representation (HIR).
    ///
    /// If there was a problem doing the translation, then an HIR-specific
    /// error is returned.
    ///
    /// The original pattern string used to produce the `Ast` *must* also be
    /// provided. The translator does not use the pattern string during any
    /// correct translation, but is used for error reporting.
    pub fn translate(&mut self, pattern: &str, ast: &Ast) -> Result<Hir> {
        ast::visit(ast, TranslatorI::new(self, pattern))
    }
}

/// An HirFrame is a single stack frame, represented explicitly, which is
/// created for each item in the Ast that we traverse.
///
/// Note that technically, this type doesn't represent our entire stack
/// frame. In particular, the Ast visitor represents any state associated with
/// traversing the Ast itself.
#[derive(Clone, Debug)]
enum HirFrame {
    /// An arbitrary HIR expression. These get pushed whenever we hit a base
    /// case in the Ast. They get popped after an inductive (i.e., recursive)
    /// step is complete.
    Expr(Hir),
    /// A literal that is being constructed, character by character, from the
    /// AST. We need this because the AST gives each individual character its
    /// own node. So as we see characters, we peek at the top-most HirFrame.
    /// If it's a literal, then we add to it. Otherwise, we push a new literal.
    /// When it comes time to pop it, we convert it to an Hir via Hir::literal.
    Literal(Vec<u8>),
    /// A Unicode character class. This frame is mutated as we descend into
    /// the Ast of a character class (which is itself its own mini recursive
    /// structure).
    ClassUnicode(hir::ClassUnicode),
    /// A byte-oriented character class. This frame is mutated as we descend
    /// into the Ast of a character class (which is itself its own mini
    /// recursive structure).
    ///
    /// Byte character classes are created when Unicode mode (`u`) is disabled.
    /// If `utf8` is enabled (the default), then a byte character is only
    /// permitted to match ASCII text.
    ClassBytes(hir::ClassBytes),
    /// This is pushed whenever a repetition is observed. After visiting every
    /// sub-expression in the repetition, the translator's stack is expected to
    /// have this sentinel at the top.
    ///
    /// This sentinel only exists to stop other things (like flattening
    /// literals) from reaching across repetition operators.
    Repetition,
    /// This is pushed on to the stack upon first seeing any kind of capture,
    /// indicated by parentheses (including non-capturing groups). It is popped
    /// upon leaving a group.
    Group {
        /// The old active flags when this group was opened.
        ///
        /// If this group sets flags, then the new active flags are set to the
        /// result of merging the old flags with the flags introduced by this
        /// group. If the group doesn't set any flags, then this is simply
        /// equivalent to whatever flags were set when the group was opened.
        ///
        /// When this group is popped, the active flags should be restored to
        /// the flags set here.
        ///
        /// The "active" flags correspond to whatever flags are set in the
        /// Translator.
        old_flags: Flags,
    },
    /// This is pushed whenever a concatenation is observed. After visiting
    /// every sub-expression in the concatenation, the translator's stack is
    /// popped until it sees a Concat frame.
    Concat,
    /// This is pushed whenever an alternation is observed. After visiting
    /// every sub-expression in the alternation, the translator's stack is
    /// popped until it sees an Alternation frame.
    Alternation,
    /// This is pushed immediately before each sub-expression in an
    /// alternation. This separates the branches of an alternation on the
    /// stack and prevents literal flattening from reaching across alternation
    /// branches.
    ///
    /// It is popped after each expression in a branch until an 'Alternation'
    /// frame is observed when doing a post visit on an alternation.
    AlternationBranch,
}

impl HirFrame {
    /// Assert that the current stack frame is an Hir expression and return it.
    fn unwrap_expr(self) -> Hir {
        match self {
            HirFrame::Expr(expr) => expr,
            HirFrame::Literal(lit) => Hir::literal(lit),
            _ => panic!("tried to unwrap expr from HirFrame, got: {:?}", self),
        }
    }

    /// Assert that the current stack frame is a Unicode class expression and
    /// return it.
    fn unwrap_class_unicode(self) -> hir::ClassUnicode {
        match self {
            HirFrame::ClassUnicode(cls) => cls,
            _ => panic!(
                "tried to unwrap Unicode class \
                 from HirFrame, got: {:?}",
                self
            ),
        }
    }

    /// Assert that the current stack frame is a byte class expression and
    /// return it.
    fn unwrap_class_bytes(self) -> hir::ClassBytes {
        match self {
            HirFrame::ClassBytes(cls) => cls,
            _ => panic!(
                "tried to unwrap byte class \
                 from HirFrame, got: {:?}",
                self
            ),
        }
    }

    /// Assert that the current stack frame is a repetition sentinel. If it
    /// isn't, then panic.
    fn unwrap_repetition(self) {
        match self {
            HirFrame::Repetition => {}
            _ => {
                panic!(
                    "tried to unwrap repetition from HirFrame, got: {:?}",
                    self
                )
            }
        }
    }

    /// Assert that the current stack frame is a group indicator and return
    /// its corresponding flags (the flags that were active at the time the
    /// group was entered).
    fn unwrap_group(self) -> Flags {
        match self {
            HirFrame::Group { old_flags } => old_flags,
            _ => {
                panic!("tried to unwrap group from HirFrame, got: {:?}", self)
            }
        }
    }

    /// Assert that the current stack frame is an alternation pipe sentinel. If
    /// it isn't, then panic.
    fn unwrap_alternation_pipe(self) {
        match self {
            HirFrame::AlternationBranch => {}
            _ => {
                panic!(
                    "tried to unwrap alt pipe from HirFrame, got: {:?}",
                    self
                )
            }
        }
    }
}

impl<'t, 'p> Visitor for TranslatorI<'t, 'p> {
    type Output = Hir;
    type Err = Error;

    fn finish(self) -> Result<Hir> {
        // ... otherwise, we should have exactly one HIR on the stack.
        assert_eq!(self.trans().stack.borrow().len(), 1);
        Ok(self.pop().unwrap().unwrap_expr())
    }

    fn visit_pre(&mut self, ast: &Ast) -> Result<()> {
        match *ast {
            Ast::ClassBracketed(_) => {
                if self.flags().unicode() {
                    let cls = hir::ClassUnicode::empty();
                    self.push(HirFrame::ClassUnicode(cls));
                } else {
                    let cls = hir::ClassBytes::empty();
                    self.push(HirFrame::ClassBytes(cls));
                }
            }
            Ast::Repetition(_) => self.push(HirFrame::Repetition),
            Ast::Group(ref x) => {
                let old_flags = x
                    .flags()
                    .map(|ast| self.set_flags(ast))
                    .unwrap_or_else(|| self.flags());
                self.push(HirFrame::Group { old_flags });
            }
            Ast::Concat(_) => {
                self.push(HirFrame::Concat);
            }
            Ast::Alternation(ref x) => {
                self.push(HirFrame::Alternation);
                if !x.asts.is_empty() {
                    self.push(HirFrame::AlternationBranch);
                }
            }
            _ => {}
        }
        Ok(())
    }

    fn visit_post(&mut self, ast: &Ast) -> Result<()> {
        match *ast {
            Ast::Empty(_) => {
                self.push(HirFrame::Expr(Hir::empty()));
            }
            Ast::Flags(ref x) => {
                self.set_flags(&x.flags);
                // Flags in the AST are generally considered directives and
                // not actual sub-expressions. However, they can be used in
                // the concrete syntax like `((?i))`, and we need some kind of
                // indication of an expression there, and Empty is the correct
                // choice.
                //
                // There can also be things like `(?i)+`, but we rule those out
                // in the parser. In the future, we might allow them for
                // consistency sake.
                self.push(HirFrame::Expr(Hir::empty()));
            }
            Ast::Literal(ref x) => match self.ast_literal_to_scalar(x)? {
                Either::Right(byte) => self.push_byte(byte),
                Either::Left(ch) => match self.case_fold_char(x.span, ch)? {
                    None => self.push_char(ch),
                    Some(expr) => self.push(HirFrame::Expr(expr)),
                },
            },
            Ast::Dot(ref span) => {
                self.push(HirFrame::Expr(self.hir_dot(**span)?));
            }
            Ast::Assertion(ref x) => {
                self.push(HirFrame::Expr(self.hir_assertion(x)?));
            }
            Ast::ClassPerl(ref x) => {
                if self.flags().unicode() {
                    let cls = self.hir_perl_unicode_class(x)?;
                    let hcls = hir::Class::Unicode(cls);
                    self.push(HirFrame::Expr(Hir::class(hcls)));
                } else {
                    let cls = self.hir_perl_byte_class(x)?;
                    let hcls = hir::Class::Bytes(cls);
                    self.push(HirFrame::Expr(Hir::class(hcls)));
                }
            }
            Ast::ClassUnicode(ref x) => {
                let cls = hir::Class::Unicode(self.hir_unicode_class(x)?);
                self.push(HirFrame::Expr(Hir::class(cls)));
            }
            Ast::ClassBracketed(ref ast) => {
                if self.flags().unicode() {
                    let mut cls = self.pop().unwrap().unwrap_class_unicode();
                    self.unicode_fold_and_negate(
                        &ast.span,
                        ast.negated,
                        &mut cls,
                    )?;
                    let expr = Hir::class(hir::Class::Unicode(cls));
                    self.push(HirFrame::Expr(expr));
                } else {
                    let mut cls = self.pop().unwrap().unwrap_class_bytes();
                    self.bytes_fold_and_negate(
                        &ast.span,
                        ast.negated,
                        &mut cls,
                    )?;
                    let expr = Hir::class(hir::Class::Bytes(cls));
                    self.push(HirFrame::Expr(expr));
                }
            }
            Ast::Repetition(ref x) => {
                let expr = self.pop().unwrap().unwrap_expr();
                self.pop().unwrap().unwrap_repetition();
                self.push(HirFrame::Expr(self.hir_repetition(x, expr)));
            }
            Ast::Group(ref x) => {
                let expr = self.pop().unwrap().unwrap_expr();
                let old_flags = self.pop().unwrap().unwrap_group();
                self.trans().flags.set(old_flags);
                self.push(HirFrame::Expr(self.hir_capture(x, expr)));
            }
            Ast::Concat(_) => {
                let mut exprs = vec![];
                while let Some(expr) = self.pop_concat_expr() {
                    if !matches!(*expr.kind(), HirKind::Empty) {
                        exprs.push(expr);
                    }
                }
                exprs.reverse();
                self.push(HirFrame::Expr(Hir::concat(exprs)));
            }
            Ast::Alternation(_) => {
                let mut exprs = vec![];
                while let Some(expr) = self.pop_alt_expr() {
                    self.pop().unwrap().unwrap_alternation_pipe();
                    exprs.push(expr);
                }
                exprs.reverse();
                self.push(HirFrame::Expr(Hir::alternation(exprs)));
            }
        }
        Ok(())
    }

    fn visit_alternation_in(&mut self) -> Result<()> {
        self.push(HirFrame::AlternationBranch);
        Ok(())
    }

    fn visit_class_set_item_pre(
        &mut self,
        ast: &ast::ClassSetItem,
    ) -> Result<()> {
        match *ast {
            ast::ClassSetItem::Bracketed(_) => {
                if self.flags().unicode() {
                    let cls = hir::ClassUnicode::empty();
                    self.push(HirFrame::ClassUnicode(cls));
                } else {
                    let cls = hir::ClassBytes::empty();
                    self.push(HirFrame::ClassBytes(cls));
                }
            }
            // We needn't handle the Union case here since the visitor will
            // do it for us.
            _ => {}
        }
        Ok(())
    }

    fn visit_class_set_item_post(
        &mut self,
        ast: &ast::ClassSetItem,
    ) -> Result<()> {
        match *ast {
            ast::ClassSetItem::Empty(_) => {}
            ast::ClassSetItem::Literal(ref x) => {
                if self.flags().unicode() {
                    let mut cls = self.pop().unwrap().unwrap_class_unicode();
                    cls.push(hir::ClassUnicodeRange::new(x.c, x.c));
                    self.push(HirFrame::ClassUnicode(cls));
                } else {
                    let mut cls = self.pop().unwrap().unwrap_class_bytes();
                    let byte = self.class_literal_byte(x)?;
                    cls.push(hir::ClassBytesRange::new(byte, byte));
                    self.push(HirFrame::ClassBytes(cls));
                }
            }
            ast::ClassSetItem::Range(ref x) => {
                if self.flags().unicode() {
                    let mut cls = self.pop().unwrap().unwrap_class_unicode();
                    cls.push(hir::ClassUnicodeRange::new(x.start.c, x.end.c));
                    self.push(HirFrame::ClassUnicode(cls));
                } else {
                    let mut cls = self.pop().unwrap().unwrap_class_bytes();
                    let start = self.class_literal_byte(&x.start)?;
                    let end = self.class_literal_byte(&x.end)?;
                    cls.push(hir::ClassBytesRange::new(start, end));
                    self.push(HirFrame::ClassBytes(cls));
                }
            }
            ast::ClassSetItem::Ascii(ref x) => {
                if self.flags().unicode() {
                    let xcls = self.hir_ascii_unicode_class(x)?;
                    let mut cls = self.pop().unwrap().unwrap_class_unicode();
                    cls.union(&xcls);
                    self.push(HirFrame::ClassUnicode(cls));
                } else {
                    let xcls = self.hir_ascii_byte_class(x)?;
                    let mut cls = self.pop().unwrap().unwrap_class_bytes();
                    cls.union(&xcls);
                    self.push(HirFrame::ClassBytes(cls));
                }
            }
            ast::ClassSetItem::Unicode(ref x) => {
                let xcls = self.hir_unicode_class(x)?;
                let mut cls = self.pop().unwrap().unwrap_class_unicode();
                cls.union(&xcls);
                self.push(HirFrame::ClassUnicode(cls));
            }
            ast::ClassSetItem::Perl(ref x) => {
                if self.flags().unicode() {
                    let xcls = self.hir_perl_unicode_class(x)?;
                    let mut cls = self.pop().unwrap().unwrap_class_unicode();
                    cls.union(&xcls);
                    self.push(HirFrame::ClassUnicode(cls));
                } else {
                    let xcls = self.hir_perl_byte_class(x)?;
                    let mut cls = self.pop().unwrap().unwrap_class_bytes();
                    cls.union(&xcls);
                    self.push(HirFrame::ClassBytes(cls));
                }
            }
            ast::ClassSetItem::Bracketed(ref ast) => {
                if self.flags().unicode() {
                    let mut cls1 = self.pop().unwrap().unwrap_class_unicode();
                    self.unicode_fold_and_negate(
                        &ast.span,
                        ast.negated,
                        &mut cls1,
                    )?;

                    let mut cls2 = self.pop().unwrap().unwrap_class_unicode();
                    cls2.union(&cls1);
                    self.push(HirFrame::ClassUnicode(cls2));
                } else {
                    let mut cls1 = self.pop().unwrap().unwrap_class_bytes();
                    self.bytes_fold_and_negate(
                        &ast.span,
                        ast.negated,
                        &mut cls1,
                    )?;

                    let mut cls2 = self.pop().unwrap().unwrap_class_bytes();
                    cls2.union(&cls1);
                    self.push(HirFrame::ClassBytes(cls2));
                }
            }
            // This is handled automatically by the visitor.
            ast::ClassSetItem::Union(_) => {}
        }
        Ok(())
    }

    fn visit_class_set_binary_op_pre(
        &mut self,
        _op: &ast::ClassSetBinaryOp,
    ) -> Result<()> {
        if self.flags().unicode() {
            let cls = hir::ClassUnicode::empty();
            self.push(HirFrame::ClassUnicode(cls));
        } else {
            let cls = hir::ClassBytes::empty();
            self.push(HirFrame::ClassBytes(cls));
        }
        Ok(())
    }

    fn visit_class_set_binary_op_in(
        &mut self,
        _op: &ast::ClassSetBinaryOp,
    ) -> Result<()> {
        if self.flags().unicode() {
            let cls = hir::ClassUnicode::empty();
            self.push(HirFrame::ClassUnicode(cls));
        } else {
            let cls = hir::ClassBytes::empty();
            self.push(HirFrame::ClassBytes(cls));
        }
        Ok(())
    }

    fn visit_class_set_binary_op_post(
        &mut self,
        op: &ast::ClassSetBinaryOp,
    ) -> Result<()> {
        use crate::ast::ClassSetBinaryOpKind::*;

        if self.flags().unicode() {
            let mut rhs = self.pop().unwrap().unwrap_class_unicode();
            let mut lhs = self.pop().unwrap().unwrap_class_unicode();
            let mut cls = self.pop().unwrap().unwrap_class_unicode();
            if self.flags().case_insensitive() {
                rhs.try_case_fold_simple().map_err(|_| {
                    self.error(
                        op.rhs.span().clone(),
                        ErrorKind::UnicodeCaseUnavailable,
                    )
                })?;
                lhs.try_case_fold_simple().map_err(|_| {
                    self.error(
                        op.lhs.span().clone(),
                        ErrorKind::UnicodeCaseUnavailable,
                    )
                })?;
            }
            match op.kind {
                Intersection => lhs.intersect(&rhs),
                Difference => lhs.difference(&rhs),
                SymmetricDifference => lhs.symmetric_difference(&rhs),
            }
            cls.union(&lhs);
            self.push(HirFrame::ClassUnicode(cls));
        } else {
            let mut rhs = self.pop().unwrap().unwrap_class_bytes();
            let mut lhs = self.pop().unwrap().unwrap_class_bytes();
            let mut cls = self.pop().unwrap().unwrap_class_bytes();
            if self.flags().case_insensitive() {
                rhs.case_fold_simple();
                lhs.case_fold_simple();
            }
            match op.kind {
                Intersection => lhs.intersect(&rhs),
                Difference => lhs.difference(&rhs),
                SymmetricDifference => lhs.symmetric_difference(&rhs),
            }
            cls.union(&lhs);
            self.push(HirFrame::ClassBytes(cls));
        }
        Ok(())
    }
}

/// The internal implementation of a translator.
///
/// This type is responsible for carrying around the original pattern string,
/// which is not tied to the internal state of a translator.
///
/// A TranslatorI exists for the time it takes to translate a single Ast.
#[derive(Clone, Debug)]
struct TranslatorI<'t, 'p> {
    trans: &'t Translator,
    pattern: &'p str,
}

impl<'t, 'p> TranslatorI<'t, 'p> {
    /// Build a new internal translator.
    fn new(trans: &'t Translator, pattern: &'p str) -> TranslatorI<'t, 'p> {
        TranslatorI { trans, pattern }
    }

    /// Return a reference to the underlying translator.
    fn trans(&self) -> &Translator {
        &self.trans
    }

    /// Push the given frame on to the call stack.
    fn push(&self, frame: HirFrame) {
        self.trans().stack.borrow_mut().push(frame);
    }

    /// Push the given literal char on to the call stack.
    ///
    /// If the top-most element of the stack is a literal, then the char
    /// is appended to the end of that literal. Otherwise, a new literal
    /// containing just the given char is pushed to the top of the stack.
    fn push_char(&self, ch: char) {
        let mut buf = [0; 4];
        let bytes = ch.encode_utf8(&mut buf).as_bytes();
        let mut stack = self.trans().stack.borrow_mut();
        if let Some(HirFrame::Literal(ref mut literal)) = stack.last_mut() {
            literal.extend_from_slice(bytes);
        } else {
            stack.push(HirFrame::Literal(bytes.to_vec()));
        }
    }

    /// Push the given literal byte on to the call stack.
    ///
    /// If the top-most element of the stack is a literal, then the byte
    /// is appended to the end of that literal. Otherwise, a new literal
    /// containing just the given byte is pushed to the top of the stack.
    fn push_byte(&self, byte: u8) {
        let mut stack = self.trans().stack.borrow_mut();
        if let Some(HirFrame::Literal(ref mut literal)) = stack.last_mut() {
            literal.push(byte);
        } else {
            stack.push(HirFrame::Literal(vec![byte]));
        }
    }

    /// Pop the top of the call stack. If the call stack is empty, return None.
    fn pop(&self) -> Option<HirFrame> {
        self.trans().stack.borrow_mut().pop()
    }

    /// Pop an HIR expression from the top of the stack for a concatenation.
    ///
    /// This returns None if the stack is empty or when a concat frame is seen.
    /// Otherwise, it panics if it could not find an HIR expression.
    fn pop_concat_expr(&self) -> Option<Hir> {
        let frame = self.pop()?;
        match frame {
            HirFrame::Concat => None,
            HirFrame::Expr(expr) => Some(expr),
            HirFrame::Literal(lit) => Some(Hir::literal(lit)),
            HirFrame::ClassUnicode(_) => {
                unreachable!("expected expr or concat, got Unicode class")
            }
            HirFrame::ClassBytes(_) => {
                unreachable!("expected expr or concat, got byte class")
            }
            HirFrame::Repetition => {
                unreachable!("expected expr or concat, got repetition")
            }
            HirFrame::Group { .. } => {
                unreachable!("expected expr or concat, got group")
            }
            HirFrame::Alternation => {
                unreachable!("expected expr or concat, got alt marker")
            }
            HirFrame::AlternationBranch => {
                unreachable!("expected expr or concat, got alt branch marker")
            }
        }
    }

    /// Pop an HIR expression from the top of the stack for an alternation.
    ///
    /// This returns None if the stack is empty or when an alternation frame is
    /// seen. Otherwise, it panics if it could not find an HIR expression.
    fn pop_alt_expr(&self) -> Option<Hir> {
        let frame = self.pop()?;
        match frame {
            HirFrame::Alternation => None,
            HirFrame::Expr(expr) => Some(expr),
            HirFrame::Literal(lit) => Some(Hir::literal(lit)),
            HirFrame::ClassUnicode(_) => {
                unreachable!("expected expr or alt, got Unicode class")
            }
            HirFrame::ClassBytes(_) => {
                unreachable!("expected expr or alt, got byte class")
            }
            HirFrame::Repetition => {
                unreachable!("expected expr or alt, got repetition")
            }
            HirFrame::Group { .. } => {
                unreachable!("expected expr or alt, got group")
            }
            HirFrame::Concat => {
                unreachable!("expected expr or alt, got concat marker")
            }
            HirFrame::AlternationBranch => {
                unreachable!("expected expr or alt, got alt branch marker")
            }
        }
    }

    /// Create a new error with the given span and error type.
    fn error(&self, span: Span, kind: ErrorKind) -> Error {
        Error { kind, pattern: self.pattern.to_string(), span }
    }

    /// Return a copy of the active flags.
    fn flags(&self) -> Flags {
        self.trans().flags.get()
    }

    /// Set the flags of this translator from the flags set in the given AST.
    /// Then, return the old flags.
    fn set_flags(&self, ast_flags: &ast::Flags) -> Flags {
        let old_flags = self.flags();
        let mut new_flags = Flags::from_ast(ast_flags);
        new_flags.merge(&old_flags);
        self.trans().flags.set(new_flags);
        old_flags
    }

    /// Convert an Ast literal to its scalar representation.
    ///
    /// When Unicode mode is enabled, then this always succeeds and returns a
    /// `char` (Unicode scalar value).
    ///
    /// When Unicode mode is disabled, then a `char` will still be returned
    /// whenever possible. A byte is returned only when invalid UTF-8 is
    /// allowed and when the byte is not ASCII. Otherwise, a non-ASCII byte
    /// will result in an error when invalid UTF-8 is not allowed.
    fn ast_literal_to_scalar(
        &self,
        lit: &ast::Literal,
    ) -> Result<Either<char, u8>> {
        if self.flags().unicode() {
            return Ok(Either::Left(lit.c));
        }
        let byte = match lit.byte() {
            None => return Ok(Either::Left(lit.c)),
            Some(byte) => byte,
        };
        if byte <= 0x7F {
            return Ok(Either::Left(char::try_from(byte).unwrap()));
        }
        if self.trans().utf8 {
            return Err(self.error(lit.span, ErrorKind::InvalidUtf8));
        }
        Ok(Either::Right(byte))
    }

    fn case_fold_char(&self, span: Span, c: char) -> Result<Option<Hir>> {
        if !self.flags().case_insensitive() {
            return Ok(None);
        }
        if self.flags().unicode() {
            // If case folding won't do anything, then don't bother trying.
            let map = unicode::SimpleCaseFolder::new()
                .map(|f| f.overlaps(c, c))
                .map_err(|_| {
                    self.error(span, ErrorKind::UnicodeCaseUnavailable)
                })?;
            if !map {
                return Ok(None);
            }
            let mut cls =
                hir::ClassUnicode::new(vec![hir::ClassUnicodeRange::new(
                    c, c,
                )]);
            cls.try_case_fold_simple().map_err(|_| {
                self.error(span, ErrorKind::UnicodeCaseUnavailable)
            })?;
            Ok(Some(Hir::class(hir::Class::Unicode(cls))))
        } else {
            if !c.is_ascii() {
                return Ok(None);
            }
            // If case folding won't do anything, then don't bother trying.
            match c {
                'A'..='Z' | 'a'..='z' => {}
                _ => return Ok(None),
            }
            let mut cls =
                hir::ClassBytes::new(vec![hir::ClassBytesRange::new(
                    // OK because 'c.len_utf8() == 1' which in turn implies
                    // that 'c' is ASCII.
                    u8::try_from(c).unwrap(),
                    u8::try_from(c).unwrap(),
                )]);
            cls.case_fold_simple();
            Ok(Some(Hir::class(hir::Class::Bytes(cls))))
        }
    }

    fn hir_dot(&self, span: Span) -> Result<Hir> {
        let (utf8, lineterm, flags) =
            (self.trans().utf8, self.trans().line_terminator, self.flags());
        if utf8 && (!flags.unicode() || !lineterm.is_ascii()) {
            return Err(self.error(span, ErrorKind::InvalidUtf8));
        }
        let dot = if flags.dot_matches_new_line() {
            if flags.unicode() {
                hir::Dot::AnyChar
            } else {
                hir::Dot::AnyByte
            }
        } else {
            if flags.unicode() {
                if flags.crlf() {
                    hir::Dot::AnyCharExceptCRLF
                } else {
                    if !lineterm.is_ascii() {
                        return Err(
                            self.error(span, ErrorKind::InvalidLineTerminator)
                        );
                    }
                    hir::Dot::AnyCharExcept(char::from(lineterm))
                }
            } else {
                if flags.crlf() {
                    hir::Dot::AnyByteExceptCRLF
                } else {
                    hir::Dot::AnyByteExcept(lineterm)
                }
            }
        };
        Ok(Hir::dot(dot))
    }

    fn hir_assertion(&self, asst: &ast::Assertion) -> Result<Hir> {
        let unicode = self.flags().unicode();
        let multi_line = self.flags().multi_line();
        let crlf = self.flags().crlf();
        Ok(match asst.kind {
            ast::AssertionKind::StartLine => Hir::look(if multi_line {
                if crlf {
                    hir::Look::StartCRLF
                } else {
                    hir::Look::StartLF
                }
            } else {
                hir::Look::Start
            }),
            ast::AssertionKind::EndLine => Hir::look(if multi_line {
                if crlf {
                    hir::Look::EndCRLF
                } else {
                    hir::Look::EndLF
                }
            } else {
                hir::Look::End
            }),
            ast::AssertionKind::StartText => Hir::look(hir::Look::Start),
            ast::AssertionKind::EndText => Hir::look(hir::Look::End),
            ast::AssertionKind::WordBoundary => Hir::look(if unicode {
                hir::Look::WordUnicode
            } else {
                hir::Look::WordAscii
            }),
            ast::AssertionKind::NotWordBoundary => Hir::look(if unicode {
                hir::Look::WordUnicodeNegate
            } else {
                hir::Look::WordAsciiNegate
            }),
            ast::AssertionKind::WordBoundaryStart
            | ast::AssertionKind::WordBoundaryStartAngle => {
                Hir::look(if unicode {
                    hir::Look::WordStartUnicode
                } else {
                    hir::Look::WordStartAscii
                })
            }
            ast::AssertionKind::WordBoundaryEnd
            | ast::AssertionKind::WordBoundaryEndAngle => {
                Hir::look(if unicode {
                    hir::Look::WordEndUnicode
                } else {
                    hir::Look::WordEndAscii
                })
            }
            ast::AssertionKind::WordBoundaryStartHalf => {
                Hir::look(if unicode {
                    hir::Look::WordStartHalfUnicode
                } else {
                    hir::Look::WordStartHalfAscii
                })
            }
            ast::AssertionKind::WordBoundaryEndHalf => Hir::look(if unicode {
                hir::Look::WordEndHalfUnicode
            } else {
                hir::Look::WordEndHalfAscii
            }),
        })
    }

    fn hir_capture(&self, group: &ast::Group, expr: Hir) -> Hir {
        let (index, name) = match group.kind {
            ast::GroupKind::CaptureIndex(index) => (index, None),
            ast::GroupKind::CaptureName { ref name, .. } => {
                (name.index, Some(name.name.clone().into_boxed_str()))
            }
            // The HIR doesn't need to use non-capturing groups, since the way
            // in which the data type is defined handles this automatically.
            ast::GroupKind::NonCapturing(_) => return expr,
        };
        Hir::capture(hir::Capture { index, name, sub: Box::new(expr) })
    }

    fn hir_repetition(&self, rep: &ast::Repetition, expr: Hir) -> Hir {
        let (min, max) = match rep.op.kind {
            ast::RepetitionKind::ZeroOrOne => (0, Some(1)),
            ast::RepetitionKind::ZeroOrMore => (0, None),
            ast::RepetitionKind::OneOrMore => (1, None),
            ast::RepetitionKind::Range(ast::RepetitionRange::Exactly(m)) => {
                (m, Some(m))
            }
            ast::RepetitionKind::Range(ast::RepetitionRange::AtLeast(m)) => {
                (m, None)
            }
            ast::RepetitionKind::Range(ast::RepetitionRange::Bounded(
                m,
                n,
            )) => (m, Some(n)),
        };
        let greedy =
            if self.flags().swap_greed() { !rep.greedy } else { rep.greedy };
        Hir::repetition(hir::Repetition {
            min,
            max,
            greedy,
            sub: Box::new(expr),
        })
    }

    fn hir_unicode_class(
        &self,
        ast_class: &ast::ClassUnicode,
    ) -> Result<hir::ClassUnicode> {
        use crate::ast::ClassUnicodeKind::*;

        if !self.flags().unicode() {
            return Err(
                self.error(ast_class.span, ErrorKind::UnicodeNotAllowed)
            );
        }
        let query = match ast_class.kind {
            OneLetter(name) => ClassQuery::OneLetter(name),
            Named(ref name) => ClassQuery::Binary(name),
            NamedValue { ref name, ref value, .. } => ClassQuery::ByValue {
                property_name: name,
                property_value: value,
            },
        };
        let mut result = self.convert_unicode_class_error(
            &ast_class.span,
            unicode::class(query),
        );
        if let Ok(ref mut class) = result {
            self.unicode_fold_and_negate(
                &ast_class.span,
                ast_class.negated,
                class,
            )?;
        }
        result
    }

    fn hir_ascii_unicode_class(
        &self,
        ast: &ast::ClassAscii,
    ) -> Result<hir::ClassUnicode> {
        let mut cls = hir::ClassUnicode::new(
            ascii_class_as_chars(&ast.kind)
                .map(|(s, e)| hir::ClassUnicodeRange::new(s, e)),
        );
        self.unicode_fold_and_negate(&ast.span, ast.negated, &mut cls)?;
        Ok(cls)
    }

    fn hir_ascii_byte_class(
        &self,
        ast: &ast::ClassAscii,
    ) -> Result<hir::ClassBytes> {
        let mut cls = hir::ClassBytes::new(
            ascii_class(&ast.kind)
                .map(|(s, e)| hir::ClassBytesRange::new(s, e)),
        );
        self.bytes_fold_and_negate(&ast.span, ast.negated, &mut cls)?;
        Ok(cls)
    }

    fn hir_perl_unicode_class(
        &self,
        ast_class: &ast::ClassPerl,
    ) -> Result<hir::ClassUnicode> {
        use crate::ast::ClassPerlKind::*;

        assert!(self.flags().unicode());
        let result = match ast_class.kind {
            Digit => unicode::perl_digit(),
            Space => unicode::perl_space(),
            Word => unicode::perl_word(),
        };
        let mut class =
            self.convert_unicode_class_error(&ast_class.span, result)?;
        // We needn't apply case folding here because the Perl Unicode classes
        // are already closed under Unicode simple case folding.
        if ast_class.negated {
            class.negate();
        }
        Ok(class)
    }

    fn hir_perl_byte_class(
        &self,
        ast_class: &ast::ClassPerl,
    ) -> Result<hir::ClassBytes> {
        use crate::ast::ClassPerlKind::*;

        assert!(!self.flags().unicode());
        let mut class = match ast_class.kind {
            Digit => hir_ascii_class_bytes(&ast::ClassAsciiKind::Digit),
            Space => hir_ascii_class_bytes(&ast::ClassAsciiKind::Space),
            Word => hir_ascii_class_bytes(&ast::ClassAsciiKind::Word),
        };
        // We needn't apply case folding here because the Perl ASCII classes
        // are already closed (under ASCII case folding).
        if ast_class.negated {
            class.negate();
        }
        // Negating a Perl byte class is likely to cause it to match invalid
        // UTF-8. That's only OK if the translator is configured to allow such
        // things.
        if self.trans().utf8 && !class.is_ascii() {
            return Err(self.error(ast_class.span, ErrorKind::InvalidUtf8));
        }
        Ok(class)
    }

    /// Converts the given Unicode specific error to an HIR translation error.
    ///
    /// The span given should approximate the position at which an error would
    /// occur.
    fn convert_unicode_class_error(
        &self,
        span: &Span,
        result: core::result::Result<hir::ClassUnicode, unicode::Error>,
    ) -> Result<hir::ClassUnicode> {
        result.map_err(|err| {
            let sp = span.clone();
            match err {
                unicode::Error::PropertyNotFound => {
                    self.error(sp, ErrorKind::UnicodePropertyNotFound)
                }
                unicode::Error::PropertyValueNotFound => {
                    self.error(sp, ErrorKind::UnicodePropertyValueNotFound)
                }
                unicode::Error::PerlClassNotFound => {
                    self.error(sp, ErrorKind::UnicodePerlClassNotFound)
                }
            }
        })
    }

    fn unicode_fold_and_negate(
        &self,
        span: &Span,
        negated: bool,
        class: &mut hir::ClassUnicode,
    ) -> Result<()> {
        // Note that we must apply case folding before negation!
        // Consider `(?i)[^x]`. If we applied negation first, then
        // the result would be the character class that matched any
        // Unicode scalar value.
        if self.flags().case_insensitive() {
            class.try_case_fold_simple().map_err(|_| {
                self.error(span.clone(), ErrorKind::UnicodeCaseUnavailable)
            })?;
        }
        if negated {
            class.negate();
        }
        Ok(())
    }

    fn bytes_fold_and_negate(
        &self,
        span: &Span,
        negated: bool,
        class: &mut hir::ClassBytes,
    ) -> Result<()> {
        // Note that we must apply case folding before negation!
        // Consider `(?i)[^x]`. If we applied negation first, then
        // the result would be the character class that matched any
        // Unicode scalar value.
        if self.flags().case_insensitive() {
            class.case_fold_simple();
        }
        if negated {
            class.negate();
        }
        if self.trans().utf8 && !class.is_ascii() {
            return Err(self.error(span.clone(), ErrorKind::InvalidUtf8));
        }
        Ok(())
    }

    /// Return a scalar byte value suitable for use as a literal in a byte
    /// character class.
    fn class_literal_byte(&self, ast: &ast::Literal) -> Result<u8> {
        match self.ast_literal_to_scalar(ast)? {
            Either::Right(byte) => Ok(byte),
            Either::Left(ch) => {
                if ch.is_ascii() {
                    Ok(u8::try_from(ch).unwrap())
                } else {
                    // We can't feasibly support Unicode in
                    // byte oriented classes. Byte classes don't
                    // do Unicode case folding.
                    Err(self.error(ast.span, ErrorKind::UnicodeNotAllowed))
                }
            }
        }
    }
}

/// A translator's representation of a regular expression's flags at any given
/// moment in time.
///
/// Each flag can be in one of three states: absent, present but disabled or
/// present but enabled.
#[derive(Clone, Copy, Debug, Default)]
struct Flags {
    case_insensitive: Option<bool>,
    multi_line: Option<bool>,
    dot_matches_new_line: Option<bool>,
    swap_greed: Option<bool>,
    unicode: Option<bool>,
    crlf: Option<bool>,
    // Note that `ignore_whitespace` is omitted here because it is handled
    // entirely in the parser.
}

impl Flags {
    fn from_ast(ast: &ast::Flags) -> Flags {
        let mut flags = Flags::default();
        let mut enable = true;
        for item in &ast.items {
            match item.kind {
                ast::FlagsItemKind::Negation => {
                    enable = false;
                }
                ast::FlagsItemKind::Flag(ast::Flag::CaseInsensitive) => {
                    flags.case_insensitive = Some(enable);
                }
                ast::FlagsItemKind::Flag(ast::Flag::MultiLine) => {
                    flags.multi_line = Some(enable);
                }
                ast::FlagsItemKind::Flag(ast::Flag::DotMatchesNewLine) => {
                    flags.dot_matches_new_line = Some(enable);
                }
                ast::FlagsItemKind::Flag(ast::Flag::SwapGreed) => {
                    flags.swap_greed = Some(enable);
                }
                ast::FlagsItemKind::Flag(ast::Flag::Unicode) => {
                    flags.unicode = Some(enable);
                }
                ast::FlagsItemKind::Flag(ast::Flag::CRLF) => {
                    flags.crlf = Some(enable);
                }
                ast::FlagsItemKind::Flag(ast::Flag::IgnoreWhitespace) => {}
            }
        }
        flags
    }

    fn merge(&mut self, previous: &Flags) {
        if self.case_insensitive.is_none() {
            self.case_insensitive = previous.case_insensitive;
        }
        if self.multi_line.is_none() {
            self.multi_line = previous.multi_line;
        }
        if self.dot_matches_new_line.is_none() {
            self.dot_matches_new_line = previous.dot_matches_new_line;
        }
        if self.swap_greed.is_none() {
            self.swap_greed = previous.swap_greed;
        }
        if self.unicode.is_none() {
            self.unicode = previous.unicode;
        }
        if self.crlf.is_none() {
            self.crlf = previous.crlf;
        }
    }

    fn case_insensitive(&self) -> bool {
        self.case_insensitive.unwrap_or(false)
    }

    fn multi_line(&self) -> bool {
        self.multi_line.unwrap_or(false)
    }

    fn dot_matches_new_line(&self) -> bool {
        self.dot_matches_new_line.unwrap_or(false)
    }

    fn swap_greed(&self) -> bool {
        self.swap_greed.unwrap_or(false)
    }

    fn unicode(&self) -> bool {
        self.unicode.unwrap_or(true)
    }

    fn crlf(&self) -> bool {
        self.crlf.unwrap_or(false)
    }
}

fn hir_ascii_class_bytes(kind: &ast::ClassAsciiKind) -> hir::ClassBytes {
    let ranges: Vec<_> = ascii_class(kind)
        .map(|(s, e)| hir::ClassBytesRange::new(s, e))
        .collect();
    hir::ClassBytes::new(ranges)
}

fn ascii_class(kind: &ast::ClassAsciiKind) -> impl Iterator<Item = (u8, u8)> {
    use crate::ast::ClassAsciiKind::*;

    let slice: &'static [(u8, u8)] = match *kind {
        Alnum => &[(b'0', b'9'), (b'A', b'Z'), (b'a', b'z')],
        Alpha => &[(b'A', b'Z'), (b'a', b'z')],
        Ascii => &[(b'\x00', b'\x7F')],
        Blank => &[(b'\t', b'\t'), (b' ', b' ')],
        Cntrl => &[(b'\x00', b'\x1F'), (b'\x7F', b'\x7F')],
        Digit => &[(b'0', b'9')],
        Graph => &[(b'!', b'~')],
        Lower => &[(b'a', b'z')],
        Print => &[(b' ', b'~')],
        Punct => &[(b'!', b'/'), (b':', b'@'), (b'[', b'`'), (b'{', b'~')],
        Space => &[
            (b'\t', b'\t'),
            (b'\n', b'\n'),
            (b'\x0B', b'\x0B'),
            (b'\x0C', b'\x0C'),
            (b'\r', b'\r'),
            (b' ', b' '),
        ],
        Upper => &[(b'A', b'Z')],
        Word => &[(b'0', b'9'), (b'A', b'Z'), (b'_', b'_'), (b'a', b'z')],
        Xdigit => &[(b'0', b'9'), (b'A', b'F'), (b'a', b'f')],
    };
    slice.iter().copied()
}

fn ascii_class_as_chars(
    kind: &ast::ClassAsciiKind,
) -> impl Iterator<Item = (char, char)> {
    ascii_class(kind).map(|(s, e)| (char::from(s), char::from(e)))
}

#[cfg(test)]
mod tests {
    use crate::{
        ast::{parse::ParserBuilder, Position},
        hir::{Look, Properties},
    };

    use super::*;

    // We create these errors to compare with real hir::Errors in the tests.
    // We define equality between TestError and hir::Error to disregard the
    // pattern string in hir::Error, which is annoying to provide in tests.
    #[derive(Clone, Debug)]
    struct TestError {
        span: Span,
        kind: hir::ErrorKind,
    }

    impl PartialEq<hir::Error> for TestError {
        fn eq(&self, other: &hir::Error) -> bool {
            self.span == other.span && self.kind == other.kind
        }
    }

    impl PartialEq<TestError> for hir::Error {
        fn eq(&self, other: &TestError) -> bool {
            self.span == other.span && self.kind == other.kind
        }
    }

    fn parse(pattern: &str) -> Ast {
        ParserBuilder::new().octal(true).build().parse(pattern).unwrap()
    }

    fn t(pattern: &str) -> Hir {
        TranslatorBuilder::new()
            .utf8(true)
            .build()
            .translate(pattern, &parse(pattern))
            .unwrap()
    }

    fn t_err(pattern: &str) -> hir::Error {
        TranslatorBuilder::new()
            .utf8(true)
            .build()
            .translate(pattern, &parse(pattern))
            .unwrap_err()
    }

    fn t_bytes(pattern: &str) -> Hir {
        TranslatorBuilder::new()
            .utf8(false)
            .build()
            .translate(pattern, &parse(pattern))
            .unwrap()
    }

    fn props(pattern: &str) -> Properties {
        t(pattern).properties().clone()
    }

    fn props_bytes(pattern: &str) -> Properties {
        t_bytes(pattern).properties().clone()
    }

    fn hir_lit(s: &str) -> Hir {
        hir_blit(s.as_bytes())
    }

    fn hir_blit(s: &[u8]) -> Hir {
        Hir::literal(s)
    }

    fn hir_capture(index: u32, expr: Hir) -> Hir {
        Hir::capture(hir::Capture { index, name: None, sub: Box::new(expr) })
    }

    fn hir_capture_name(index: u32, name: &str, expr: Hir) -> Hir {
        Hir::capture(hir::Capture {
            index,
            name: Some(name.into()),
            sub: Box::new(expr),
        })
    }

    fn hir_quest(greedy: bool, expr: Hir) -> Hir {
        Hir::repetition(hir::Repetition {
            min: 0,
            max: Some(1),
            greedy,
            sub: Box::new(expr),
        })
    }

    fn hir_star(greedy: bool, expr: Hir) -> Hir {
        Hir::repetition(hir::Repetition {
            min: 0,
            max: None,
            greedy,
            sub: Box::new(expr),
        })
    }

    fn hir_plus(greedy: bool, expr: Hir) -> Hir {
        Hir::repetition(hir::Repetition {
            min: 1,
            max: None,
            greedy,
            sub: Box::new(expr),
        })
    }

    fn hir_range(greedy: bool, min: u32, max: Option<u32>, expr: Hir) -> Hir {
        Hir::repetition(hir::Repetition {
            min,
            max,
            greedy,
            sub: Box::new(expr),
        })
    }

    fn hir_alt(alts: Vec<Hir>) -> Hir {
        Hir::alternation(alts)
    }

    fn hir_cat(exprs: Vec<Hir>) -> Hir {
        Hir::concat(exprs)
    }

    #[allow(dead_code)]
    fn hir_uclass_query(query: ClassQuery<'_>) -> Hir {
        Hir::class(hir::Class::Unicode(unicode::class(query).unwrap()))
    }

    #[allow(dead_code)]
    fn hir_uclass_perl_word() -> Hir {
        Hir::class(hir::Class::Unicode(unicode::perl_word().unwrap()))
    }

    fn hir_ascii_uclass(kind: &ast::ClassAsciiKind) -> Hir {
        Hir::class(hir::Class::Unicode(hir::ClassUnicode::new(
            ascii_class_as_chars(kind)
                .map(|(s, e)| hir::ClassUnicodeRange::new(s, e)),
        )))
    }

    fn hir_ascii_bclass(kind: &ast::ClassAsciiKind) -> Hir {
        Hir::class(hir::Class::Bytes(hir::ClassBytes::new(
            ascii_class(kind).map(|(s, e)| hir::ClassBytesRange::new(s, e)),
        )))
    }

    fn hir_uclass(ranges: &[(char, char)]) -> Hir {
        Hir::class(uclass(ranges))
    }

    fn hir_bclass(ranges: &[(u8, u8)]) -> Hir {
        Hir::class(bclass(ranges))
    }

    fn hir_case_fold(expr: Hir) -> Hir {
        match expr.into_kind() {
            HirKind::Class(mut cls) => {
                cls.case_fold_simple();
                Hir::class(cls)
            }
            _ => panic!("cannot case fold non-class Hir expr"),
        }
    }

    fn hir_negate(expr: Hir) -> Hir {
        match expr.into_kind() {
            HirKind::Class(mut cls) => {
                cls.negate();
                Hir::class(cls)
            }
            _ => panic!("cannot negate non-class Hir expr"),
        }
    }

    fn uclass(ranges: &[(char, char)]) -> hir::Class {
        let ranges: Vec<hir::ClassUnicodeRange> = ranges
            .iter()
            .map(|&(s, e)| hir::ClassUnicodeRange::new(s, e))
            .collect();
        hir::Class::Unicode(hir::ClassUnicode::new(ranges))
    }

    fn bclass(ranges: &[(u8, u8)]) -> hir::Class {
        let ranges: Vec<hir::ClassBytesRange> = ranges
            .iter()
            .map(|&(s, e)| hir::ClassBytesRange::new(s, e))
            .collect();
        hir::Class::Bytes(hir::ClassBytes::new(ranges))
    }

    #[cfg(feature = "unicode-case")]
    fn class_case_fold(mut cls: hir::Class) -> Hir {
        cls.case_fold_simple();
        Hir::class(cls)
    }

    fn class_negate(mut cls: hir::Class) -> Hir {
        cls.negate();
        Hir::class(cls)
    }

    #[allow(dead_code)]
    fn hir_union(expr1: Hir, expr2: Hir) -> Hir {
        use crate::hir::Class::{Bytes, Unicode};

        match (expr1.into_kind(), expr2.into_kind()) {
            (HirKind::Class(Unicode(mut c1)), HirKind::Class(Unicode(c2))) => {
                c1.union(&c2);
                Hir::class(hir::Class::Unicode(c1))
            }
            (HirKind::Class(Bytes(mut c1)), HirKind::Class(Bytes(c2))) => {
                c1.union(&c2);
                Hir::class(hir::Class::Bytes(c1))
            }
            _ => panic!("cannot union non-class Hir exprs"),
        }
    }

    #[allow(dead_code)]
    fn hir_difference(expr1: Hir, expr2: Hir) -> Hir {
        use crate::hir::Class::{Bytes, Unicode};

        match (expr1.into_kind(), expr2.into_kind()) {
            (HirKind::Class(Unicode(mut c1)), HirKind::Class(Unicode(c2))) => {
                c1.difference(&c2);
                Hir::class(hir::Class::Unicode(c1))
            }
            (HirKind::Class(Bytes(mut c1)), HirKind::Class(Bytes(c2))) => {
                c1.difference(&c2);
                Hir::class(hir::Class::Bytes(c1))
            }
            _ => panic!("cannot difference non-class Hir exprs"),
        }
    }

    fn hir_look(look: hir::Look) -> Hir {
        Hir::look(look)
    }

    #[test]
    fn empty() {
        assert_eq!(t(""), Hir::empty());
        assert_eq!(t("(?i)"), Hir::empty());
        assert_eq!(t("()"), hir_capture(1, Hir::empty()));
        assert_eq!(t("(?:)"), Hir::empty());
        assert_eq!(t("(?P<wat>)"), hir_capture_name(1, "wat", Hir::empty()));
        assert_eq!(t("|"), hir_alt(vec![Hir::empty(), Hir::empty()]));
        assert_eq!(
            t("()|()"),
            hir_alt(vec![
                hir_capture(1, Hir::empty()),
                hir_capture(2, Hir::empty()),
            ])
        );
        assert_eq!(
            t("(|b)"),
            hir_capture(1, hir_alt(vec![Hir::empty(), hir_lit("b"),]))
        );
        assert_eq!(
            t("(a|)"),
            hir_capture(1, hir_alt(vec![hir_lit("a"), Hir::empty(),]))
        );
        assert_eq!(
            t("(a||c)"),
            hir_capture(
                1,
                hir_alt(vec![hir_lit("a"), Hir::empty(), hir_lit("c"),])
            )
        );
        assert_eq!(
            t("(||)"),
            hir_capture(
                1,
                hir_alt(vec![Hir::empty(), Hir::empty(), Hir::empty(),])
            )
        );
    }

    #[test]
    fn literal() {
        assert_eq!(t("a"), hir_lit("a"));
        assert_eq!(t("(?-u)a"), hir_lit("a"));
        assert_eq!(t("☃"), hir_lit("☃"));
        assert_eq!(t("abcd"), hir_lit("abcd"));

        assert_eq!(t_bytes("(?-u)a"), hir_lit("a"));
        assert_eq!(t_bytes("(?-u)\x61"), hir_lit("a"));
        assert_eq!(t_bytes(r"(?-u)\x61"), hir_lit("a"));
        assert_eq!(t_bytes(r"(?-u)\xFF"), hir_blit(b"\xFF"));

        assert_eq!(t("(?-u)☃"), hir_lit("☃"));
        assert_eq!(
            t_err(r"(?-u)\xFF"),
            TestError {
                kind: hir::ErrorKind::InvalidUtf8,
                span: Span::new(
                    Position::new(5, 1, 6),
                    Position::new(9, 1, 10)
                ),
            }
        );
    }

    #[test]
    fn literal_case_insensitive() {
        #[cfg(feature = "unicode-case")]
        assert_eq!(t("(?i)a"), hir_uclass(&[('A', 'A'), ('a', 'a'),]));
        #[cfg(feature = "unicode-case")]
        assert_eq!(t("(?i:a)"), hir_uclass(&[('A', 'A'), ('a', 'a')]));
        #[cfg(feature = "unicode-case")]
        assert_eq!(
            t("a(?i)a(?-i)a"),
            hir_cat(vec![
                hir_lit("a"),
                hir_uclass(&[('A', 'A'), ('a', 'a')]),
                hir_lit("a"),
            ])
        );
        #[cfg(feature = "unicode-case")]
        assert_eq!(
            t("(?i)ab@c"),
            hir_cat(vec![
                hir_uclass(&[('A', 'A'), ('a', 'a')]),
                hir_uclass(&[('B', 'B'), ('b', 'b')]),
                hir_lit("@"),
                hir_uclass(&[('C', 'C'), ('c', 'c')]),
            ])
        );
        #[cfg(feature = "unicode-case")]
        assert_eq!(
            t("(?i)β"),
            hir_uclass(&[('Β', 'Β'), ('β', 'β'), ('ϐ', 'ϐ'),])
        );

        assert_eq!(t("(?i-u)a"), hir_bclass(&[(b'A', b'A'), (b'a', b'a'),]));
        #[cfg(feature = "unicode-case")]
        assert_eq!(
            t("(?-u)a(?i)a(?-i)a"),
            hir_cat(vec![
                hir_lit("a"),
                hir_bclass(&[(b'A', b'A'), (b'a', b'a')]),
                hir_lit("a"),
            ])
        );
        assert_eq!(
            t("(?i-u)ab@c"),
            hir_cat(vec![
                hir_bclass(&[(b'A', b'A'), (b'a', b'a')]),
                hir_bclass(&[(b'B', b'B'), (b'b', b'b')]),
                hir_lit("@"),
                hir_bclass(&[(b'C', b'C'), (b'c', b'c')]),
            ])
        );

        assert_eq!(
            t_bytes("(?i-u)a"),
            hir_bclass(&[(b'A', b'A'), (b'a', b'a'),])
        );
        assert_eq!(
            t_bytes("(?i-u)\x61"),
            hir_bclass(&[(b'A', b'A'), (b'a', b'a'),])
        );
        assert_eq!(
            t_bytes(r"(?i-u)\x61"),
            hir_bclass(&[(b'A', b'A'), (b'a', b'a'),])
        );
        assert_eq!(t_bytes(r"(?i-u)\xFF"), hir_blit(b"\xFF"));

        assert_eq!(t("(?i-u)β"), hir_lit("β"),);
    }

    #[test]
    fn dot() {
        assert_eq!(
            t("."),
            hir_uclass(&[('\0', '\t'), ('\x0B', '\u{10FFFF}')])
        );
        assert_eq!(
            t("(?R)."),
            hir_uclass(&[
                ('\0', '\t'),
                ('\x0B', '\x0C'),
                ('\x0E', '\u{10FFFF}'),
            ])
        );
        assert_eq!(t("(?s)."), hir_uclass(&[('\0', '\u{10FFFF}')]));
        assert_eq!(t("(?Rs)."), hir_uclass(&[('\0', '\u{10FFFF}')]));
        assert_eq!(
            t_bytes("(?-u)."),
            hir_bclass(&[(b'\0', b'\t'), (b'\x0B', b'\xFF')])
        );
        assert_eq!(
            t_bytes("(?R-u)."),
            hir_bclass(&[
                (b'\0', b'\t'),
                (b'\x0B', b'\x0C'),
                (b'\x0E', b'\xFF'),
            ])
        );
        assert_eq!(t_bytes("(?s-u)."), hir_bclass(&[(b'\0', b'\xFF'),]));
        assert_eq!(t_bytes("(?Rs-u)."), hir_bclass(&[(b'\0', b'\xFF'),]));

        // If invalid UTF-8 isn't allowed, then non-Unicode `.` isn't allowed.
        assert_eq!(
            t_err("(?-u)."),
            TestError {
                kind: hir::ErrorKind::InvalidUtf8,
                span: Span::new(
                    Position::new(5, 1, 6),
                    Position::new(6, 1, 7)
                ),
            }
        );
        assert_eq!(
            t_err("(?R-u)."),
            TestError {
                kind: hir::ErrorKind::InvalidUtf8,
                span: Span::new(
                    Position::new(6, 1, 7),
                    Position::new(7, 1, 8)
                ),
            }
        );
        assert_eq!(
            t_err("(?s-u)."),
            TestError {
                kind: hir::ErrorKind::InvalidUtf8,
                span: Span::new(
                    Position::new(6, 1, 7),
                    Position::new(7, 1, 8)
                ),
            }
        );
        assert_eq!(
            t_err("(?Rs-u)."),
            TestError {
                kind: hir::ErrorKind::InvalidUtf8,
                span: Span::new(
                    Position::new(7, 1, 8),
                    Position::new(8, 1, 9)
                ),
            }
        );
    }

    #[test]
    fn assertions() {
        assert_eq!(t("^"), hir_look(hir::Look::Start));
        assert_eq!(t("$"), hir_look(hir::Look::End));
        assert_eq!(t(r"\A"), hir_look(hir::Look::Start));
        assert_eq!(t(r"\z"), hir_look(hir::Look::End));
        assert_eq!(t("(?m)^"), hir_look(hir::Look::StartLF));
        assert_eq!(t("(?m)$"), hir_look(hir::Look::EndLF));
        assert_eq!(t(r"(?m)\A"), hir_look(hir::Look::Start));
        assert_eq!(t(r"(?m)\z"), hir_look(hir::Look::End));

        assert_eq!(t(r"\b"), hir_look(hir::Look::WordUnicode));
        assert_eq!(t(r"\B"), hir_look(hir::Look::WordUnicodeNegate));
        assert_eq!(t(r"(?-u)\b"), hir_look(hir::Look::WordAscii));
        assert_eq!(t(r"(?-u)\B"), hir_look(hir::Look::WordAsciiNegate));
    }

    #[test]
    fn group() {
        assert_eq!(t("(a)"), hir_capture(1, hir_lit("a")));
        assert_eq!(
            t("(a)(b)"),
            hir_cat(vec![
                hir_capture(1, hir_lit("a")),
                hir_capture(2, hir_lit("b")),
            ])
        );
        assert_eq!(
            t("(a)|(b)"),
            hir_alt(vec![
                hir_capture(1, hir_lit("a")),
                hir_capture(2, hir_lit("b")),
            ])
        );
        assert_eq!(t("(?P<foo>)"), hir_capture_name(1, "foo", Hir::empty()));
        assert_eq!(t("(?P<foo>a)"), hir_capture_name(1, "foo", hir_lit("a")));
        assert_eq!(
            t("(?P<foo>a)(?P<bar>b)"),
            hir_cat(vec![
                hir_capture_name(1, "foo", hir_lit("a")),
                hir_capture_name(2, "bar", hir_lit("b")),
            ])
        );
        assert_eq!(t("(?:)"), Hir::empty());
        assert_eq!(t("(?:a)"), hir_lit("a"));
        assert_eq!(
            t("(?:a)(b)"),
            hir_cat(vec![hir_lit("a"), hir_capture(1, hir_lit("b")),])
        );
        assert_eq!(
            t("(a)(?:b)(c)"),
            hir_cat(vec![
                hir_capture(1, hir_lit("a")),
                hir_lit("b"),
                hir_capture(2, hir_lit("c")),
            ])
        );
        assert_eq!(
            t("(a)(?P<foo>b)(c)"),
            hir_cat(vec![
                hir_capture(1, hir_lit("a")),
                hir_capture_name(2, "foo", hir_lit("b")),
                hir_capture(3, hir_lit("c")),
            ])
        );
        assert_eq!(t("()"), hir_capture(1, Hir::empty()));
        assert_eq!(t("((?i))"), hir_capture(1, Hir::empty()));
        assert_eq!(t("((?x))"), hir_capture(1, Hir::empty()));
        assert_eq!(
            t("(((?x)))"),
            hir_capture(1, hir_capture(2, Hir::empty()))
        );
    }

    #[test]
    fn line_anchors() {
        assert_eq!(t("^"), hir_look(hir::Look::Start));
        assert_eq!(t("$"), hir_look(hir::Look::End));
        assert_eq!(t(r"\A"), hir_look(hir::Look::Start));
        assert_eq!(t(r"\z"), hir_look(hir::Look::End));

        assert_eq!(t(r"(?m)\A"), hir_look(hir::Look::Start));
        assert_eq!(t(r"(?m)\z"), hir_look(hir::Look::End));
        assert_eq!(t("(?m)^"), hir_look(hir::Look::StartLF));
        assert_eq!(t("(?m)$"), hir_look(hir::Look::EndLF));

        assert_eq!(t(r"(?R)\A"), hir_look(hir::Look::Start));
        assert_eq!(t(r"(?R)\z"), hir_look(hir::Look::End));
        assert_eq!(t("(?R)^"), hir_look(hir::Look::Start));
        assert_eq!(t("(?R)$"), hir_look(hir::Look::End));

        assert_eq!(t(r"(?Rm)\A"), hir_look(hir::Look::Start));
        assert_eq!(t(r"(?Rm)\z"), hir_look(hir::Look::End));
        assert_eq!(t("(?Rm)^"), hir_look(hir::Look::StartCRLF));
        assert_eq!(t("(?Rm)$"), hir_look(hir::Look::EndCRLF));
    }

    #[test]
    fn flags() {
        #[cfg(feature = "unicode-case")]
        assert_eq!(
            t("(?i:a)a"),
            hir_cat(
                vec![hir_uclass(&[('A', 'A'), ('a', 'a')]), hir_lit("a"),]
            )
        );
        assert_eq!(
            t("(?i-u:a)β"),
            hir_cat(vec![
                hir_bclass(&[(b'A', b'A'), (b'a', b'a')]),
                hir_lit("β"),
            ])
        );
        assert_eq!(
            t("(?:(?i-u)a)b"),
            hir_cat(vec![
                hir_bclass(&[(b'A', b'A'), (b'a', b'a')]),
                hir_lit("b"),
            ])
        );
        assert_eq!(
            t("((?i-u)a)b"),
            hir_cat(vec![
                hir_capture(1, hir_bclass(&[(b'A', b'A'), (b'a', b'a')])),
                hir_lit("b"),
            ])
        );
        #[cfg(feature = "unicode-case")]
        assert_eq!(
            t("(?i)(?-i:a)a"),
            hir_cat(
                vec![hir_lit("a"), hir_uclass(&[('A', 'A'), ('a', 'a')]),]
            )
        );
        #[cfg(feature = "unicode-case")]
        assert_eq!(
            t("(?im)a^"),
            hir_cat(vec![
                hir_uclass(&[('A', 'A'), ('a', 'a')]),
                hir_look(hir::Look::StartLF),
            ])
        );
        #[cfg(feature = "unicode-case")]
        assert_eq!(
            t("(?im)a^(?i-m)a^"),
            hir_cat(vec![
                hir_uclass(&[('A', 'A'), ('a', 'a')]),
                hir_look(hir::Look::StartLF),
                hir_uclass(&[('A', 'A'), ('a', 'a')]),
                hir_look(hir::Look::Start),
            ])
        );
        assert_eq!(
            t("(?U)a*a*?(?-U)a*a*?"),
            hir_cat(vec![
                hir_star(false, hir_lit("a")),
                hir_star(true, hir_lit("a")),
                hir_star(true, hir_lit("a")),
                hir_star(false, hir_lit("a")),
            ])
        );
        #[cfg(feature = "unicode-case")]
        assert_eq!(
            t("(?:a(?i)a)a"),
            hir_cat(vec![
                hir_cat(vec![
                    hir_lit("a"),
                    hir_uclass(&[('A', 'A'), ('a', 'a')]),
                ]),
                hir_lit("a"),
            ])
        );
        #[cfg(feature = "unicode-case")]
        assert_eq!(
            t("(?i)(?:a(?-i)a)a"),
            hir_cat(vec![
                hir_cat(vec![
                    hir_uclass(&[('A', 'A'), ('a', 'a')]),
                    hir_lit("a"),
                ]),
                hir_uclass(&[('A', 'A'), ('a', 'a')]),
            ])
        );
    }

    #[test]
    fn escape() {
        assert_eq!(
            t(r"\\\.\+\*\?\(\)\|\[\]\{\}\^\$\#"),
            hir_lit(r"\.+*?()|[]{}^$#")
        );
    }

    #[test]
    fn repetition() {
        assert_eq!(t("a?"), hir_quest(true, hir_lit("a")));
        assert_eq!(t("a*"), hir_star(true, hir_lit("a")));
        assert_eq!(t("a+"), hir_plus(true, hir_lit("a")));
        assert_eq!(t("a??"), hir_quest(false, hir_lit("a")));
        assert_eq!(t("a*?"), hir_star(false, hir_lit("a")));
        assert_eq!(t("a+?"), hir_plus(false, hir_lit("a")));

        assert_eq!(t("a{1}"), hir_range(true, 1, Some(1), hir_lit("a"),));
        assert_eq!(t("a{1,}"), hir_range(true, 1, None, hir_lit("a"),));
        assert_eq!(t("a{1,2}"), hir_range(true, 1, Some(2), hir_lit("a"),));
        assert_eq!(t("a{1}?"), hir_range(false, 1, Some(1), hir_lit("a"),));
        assert_eq!(t("a{1,}?"), hir_range(false, 1, None, hir_lit("a"),));
        assert_eq!(t("a{1,2}?"), hir_range(false, 1, Some(2), hir_lit("a"),));

        assert_eq!(
            t("ab?"),
            hir_cat(vec![hir_lit("a"), hir_quest(true, hir_lit("b")),])
        );
        assert_eq!(t("(ab)?"), hir_quest(true, hir_capture(1, hir_lit("ab"))));
        assert_eq!(
            t("a|b?"),
            hir_alt(vec![hir_lit("a"), hir_quest(true, hir_lit("b")),])
        );
    }

    #[test]
    fn cat_alt() {
        let a = || hir_look(hir::Look::Start);
        let b = || hir_look(hir::Look::End);
        let c = || hir_look(hir::Look::WordUnicode);
        let d = || hir_look(hir::Look::WordUnicodeNegate);

        assert_eq!(t("(^$)"), hir_capture(1, hir_cat(vec![a(), b()])));
        assert_eq!(t("^|$"), hir_alt(vec![a(), b()]));
        assert_eq!(t(r"^|$|\b"), hir_alt(vec![a(), b(), c()]));
        assert_eq!(
            t(r"^$|$\b|\b\B"),
            hir_alt(vec![
                hir_cat(vec![a(), b()]),
                hir_cat(vec![b(), c()]),
                hir_cat(vec![c(), d()]),
            ])
        );
        assert_eq!(t("(^|$)"), hir_capture(1, hir_alt(vec![a(), b()])));
        assert_eq!(
            t(r"(^|$|\b)"),
            hir_capture(1, hir_alt(vec![a(), b(), c()]))
        );
        assert_eq!(
            t(r"(^$|$\b|\b\B)"),
            hir_capture(
                1,
                hir_alt(vec![
                    hir_cat(vec![a(), b()]),
                    hir_cat(vec![b(), c()]),
                    hir_cat(vec![c(), d()]),
                ])
            )
        );
        assert_eq!(
            t(r"(^$|($\b|(\b\B)))"),
            hir_capture(
                1,
                hir_alt(vec![
                    hir_cat(vec![a(), b()]),
                    hir_capture(
                        2,
                        hir_alt(vec![
                            hir_cat(vec![b(), c()]),
                            hir_capture(3, hir_cat(vec![c(), d()])),
                        ])
                    ),
                ])
            )
        );
    }

    // Tests the HIR transformation of things like '[a-z]|[A-Z]' into
    // '[A-Za-z]'. In other words, an alternation of just classes is always
    // equivalent to a single class corresponding to the union of the branches
    // in that class. (Unless some branches match invalid UTF-8 and others
    // match non-ASCII Unicode.)
    #[test]
    fn cat_class_flattened() {
        assert_eq!(t(r"[a-z]|[A-Z]"), hir_uclass(&[('A', 'Z'), ('a', 'z')]));
        // Combining all of the letter properties should give us the one giant
        // letter property.
        #[cfg(feature = "unicode-gencat")]
        assert_eq!(
            t(r"(?x)
                \p{Lowercase_Letter}
                |\p{Uppercase_Letter}
                |\p{Titlecase_Letter}
                |\p{Modifier_Letter}
                |\p{Other_Letter}
            "),
            hir_uclass_query(ClassQuery::Binary("letter"))
        );
        // Byte classes that can truly match invalid UTF-8 cannot be combined
        // with Unicode classes.
        assert_eq!(
            t_bytes(r"[Δδ]|(?-u:[\x90-\xFF])|[Λλ]"),
            hir_alt(vec![
                hir_uclass(&[('Δ', 'Δ'), ('δ', 'δ')]),
                hir_bclass(&[(b'\x90', b'\xFF')]),
                hir_uclass(&[('Λ', 'Λ'), ('λ', 'λ')]),
            ])
        );
        // Byte classes on their own can be combined, even if some are ASCII
        // and others are invalid UTF-8.
        assert_eq!(
            t_bytes(r"[a-z]|(?-u:[\x90-\xFF])|[A-Z]"),
            hir_bclass(&[(b'A', b'Z'), (b'a', b'z'), (b'\x90', b'\xFF')]),
        );
    }

    #[test]
    fn class_ascii() {
        assert_eq!(
            t("[[:alnum:]]"),
            hir_ascii_uclass(&ast::ClassAsciiKind::Alnum)
        );
        assert_eq!(
            t("[[:alpha:]]"),
            hir_ascii_uclass(&ast::ClassAsciiKind::Alpha)
        );
        assert_eq!(
            t("[[:ascii:]]"),
            hir_ascii_uclass(&ast::ClassAsciiKind::Ascii)
        );
        assert_eq!(
            t("[[:blank:]]"),
            hir_ascii_uclass(&ast::ClassAsciiKind::Blank)
        );
        assert_eq!(
            t("[[:cntrl:]]"),
            hir_ascii_uclass(&ast::ClassAsciiKind::Cntrl)
        );
        assert_eq!(
            t("[[:digit:]]"),
            hir_ascii_uclass(&ast::ClassAsciiKind::Digit)
        );
        assert_eq!(
            t("[[:graph:]]"),
            hir_ascii_uclass(&ast::ClassAsciiKind::Graph)
        );
        assert_eq!(
            t("[[:lower:]]"),
            hir_ascii_uclass(&ast::ClassAsciiKind::Lower)
        );
        assert_eq!(
            t("[[:print:]]"),
            hir_ascii_uclass(&ast::ClassAsciiKind::Print)
        );
        assert_eq!(
            t("[[:punct:]]"),
            hir_ascii_uclass(&ast::ClassAsciiKind::Punct)
        );
        assert_eq!(
            t("[[:space:]]"),
            hir_ascii_uclass(&ast::ClassAsciiKind::Space)
        );
        assert_eq!(
            t("[[:upper:]]"),
            hir_ascii_uclass(&ast::ClassAsciiKind::Upper)
        );
        assert_eq!(
            t("[[:word:]]"),
            hir_ascii_uclass(&ast::ClassAsciiKind::Word)
        );
        assert_eq!(
            t("[[:xdigit:]]"),
            hir_ascii_uclass(&ast::ClassAsciiKind::Xdigit)
        );

        assert_eq!(
            t("[[:^lower:]]"),
            hir_negate(hir_ascii_uclass(&ast::ClassAsciiKind::Lower))
        );
        #[cfg(feature = "unicode-case")]
        assert_eq!(
            t("(?i)[[:lower:]]"),
            hir_uclass(&[
                ('A', 'Z'),
                ('a', 'z'),
                ('\u{17F}', '\u{17F}'),
                ('\u{212A}', '\u{212A}'),
            ])
        );

        assert_eq!(
            t("(?-u)[[:lower:]]"),
            hir_ascii_bclass(&ast::ClassAsciiKind::Lower)
        );
        assert_eq!(
            t("(?i-u)[[:lower:]]"),
            hir_case_fold(hir_ascii_bclass(&ast::ClassAsciiKind::Lower))
        );

        assert_eq!(
            t_err("(?-u)[[:^lower:]]"),
            TestError {
                kind: hir::ErrorKind::InvalidUtf8,
                span: Span::new(
                    Position::new(6, 1, 7),
                    Position::new(16, 1, 17)
                ),
            }
        );
        assert_eq!(
            t_err("(?i-u)[[:^lower:]]"),
            TestError {
                kind: hir::ErrorKind::InvalidUtf8,
                span: Span::new(
                    Position::new(7, 1, 8),
                    Position::new(17, 1, 18)
                ),
            }
        );
    }

    #[test]
    fn class_ascii_multiple() {
        // See: https://github.com/rust-lang/regex/issues/680
        assert_eq!(
            t("[[:alnum:][:^ascii:]]"),
            hir_union(
                hir_ascii_uclass(&ast::ClassAsciiKind::Alnum),
                hir_uclass(&[('\u{80}', '\u{10FFFF}')]),
            ),
        );
        assert_eq!(
            t_bytes("(?-u)[[:alnum:][:^ascii:]]"),
            hir_union(
                hir_ascii_bclass(&ast::ClassAsciiKind::Alnum),
                hir_bclass(&[(0x80, 0xFF)]),
            ),
        );
    }

    #[test]
    #[cfg(feature = "unicode-perl")]
    fn class_perl_unicode() {
        // Unicode
        assert_eq!(t(r"\d"), hir_uclass_query(ClassQuery::Binary("digit")));
        assert_eq!(t(r"\s"), hir_uclass_query(ClassQuery::Binary("space")));
        assert_eq!(t(r"\w"), hir_uclass_perl_word());
        #[cfg(feature = "unicode-case")]
        assert_eq!(
            t(r"(?i)\d"),
            hir_uclass_query(ClassQuery::Binary("digit"))
        );
        #[cfg(feature = "unicode-case")]
        assert_eq!(
            t(r"(?i)\s"),
            hir_uclass_query(ClassQuery::Binary("space"))
        );
        #[cfg(feature = "unicode-case")]
        assert_eq!(t(r"(?i)\w"), hir_uclass_perl_word());

        // Unicode, negated
        assert_eq!(
            t(r"\D"),
            hir_negate(hir_uclass_query(ClassQuery::Binary("digit")))
        );
        assert_eq!(
            t(r"\S"),
            hir_negate(hir_uclass_query(ClassQuery::Binary("space")))
        );
        assert_eq!(t(r"\W"), hir_negate(hir_uclass_perl_word()));
        #[cfg(feature = "unicode-case")]
        assert_eq!(
            t(r"(?i)\D"),
            hir_negate(hir_uclass_query(ClassQuery::Binary("digit")))
        );
        #[cfg(feature = "unicode-case")]
        assert_eq!(
            t(r"(?i)\S"),
            hir_negate(hir_uclass_query(ClassQuery::Binary("space")))
        );
        #[cfg(feature = "unicode-case")]
        assert_eq!(t(r"(?i)\W"), hir_negate(hir_uclass_perl_word()));
    }

    #[test]
    fn class_perl_ascii() {
        // ASCII only
        assert_eq!(
            t(r"(?-u)\d"),
            hir_ascii_bclass(&ast::ClassAsciiKind::Digit)
        );
        assert_eq!(
            t(r"(?-u)\s"),
            hir_ascii_bclass(&ast::ClassAsciiKind::Space)
        );
        assert_eq!(
            t(r"(?-u)\w"),
            hir_ascii_bclass(&ast::ClassAsciiKind::Word)
        );
        assert_eq!(
            t(r"(?i-u)\d"),
            hir_ascii_bclass(&ast::ClassAsciiKind::Digit)
        );
        assert_eq!(
            t(r"(?i-u)\s"),
            hir_ascii_bclass(&ast::ClassAsciiKind::Space)
        );
        assert_eq!(
            t(r"(?i-u)\w"),
            hir_ascii_bclass(&ast::ClassAsciiKind::Word)
        );

        // ASCII only, negated
        assert_eq!(
            t_bytes(r"(?-u)\D"),
            hir_negate(hir_ascii_bclass(&ast::ClassAsciiKind::Digit))
        );
        assert_eq!(
            t_bytes(r"(?-u)\S"),
            hir_negate(hir_ascii_bclass(&ast::ClassAsciiKind::Space))
        );
        assert_eq!(
            t_bytes(r"(?-u)\W"),
            hir_negate(hir_ascii_bclass(&ast::ClassAsciiKind::Word))
        );
        assert_eq!(
            t_bytes(r"(?i-u)\D"),
            hir_negate(hir_ascii_bclass(&ast::ClassAsciiKind::Digit))
        );
        assert_eq!(
            t_bytes(r"(?i-u)\S"),
            hir_negate(hir_ascii_bclass(&ast::ClassAsciiKind::Space))
        );
        assert_eq!(
            t_bytes(r"(?i-u)\W"),
            hir_negate(hir_ascii_bclass(&ast::ClassAsciiKind::Word))
        );

        // ASCII only, negated, with UTF-8 mode enabled.
        // In this case, negating any Perl class results in an error because
        // all such classes can match invalid UTF-8.
        assert_eq!(
            t_err(r"(?-u)\D"),
            TestError {
                kind: hir::ErrorKind::InvalidUtf8,
                span: Span::new(
                    Position::new(5, 1, 6),
                    Position::new(7, 1, 8),
                ),
            },
        );
        assert_eq!(
            t_err(r"(?-u)\S"),
            TestError {
                kind: hir::ErrorKind::InvalidUtf8,
                span: Span::new(
                    Position::new(5, 1, 6),
                    Position::new(7, 1, 8),
                ),
            },
        );
        assert_eq!(
            t_err(r"(?-u)\W"),
            TestError {
                kind: hir::ErrorKind::InvalidUtf8,
                span: Span::new(
                    Position::new(5, 1, 6),
                    Position::new(7, 1, 8),
                ),
            },
        );
        assert_eq!(
            t_err(r"(?i-u)\D"),
            TestError {
                kind: hir::ErrorKind::InvalidUtf8,
                span: Span::new(
                    Position::new(6, 1, 7),
                    Position::new(8, 1, 9),
                ),
            },
        );
        assert_eq!(
            t_err(r"(?i-u)\S"),
            TestError {
                kind: hir::ErrorKind::InvalidUtf8,
                span: Span::new(
                    Position::new(6, 1, 7),
                    Position::new(8, 1, 9),
                ),
            },
        );
        assert_eq!(
            t_err(r"(?i-u)\W"),
            TestError {
                kind: hir::ErrorKind::InvalidUtf8,
                span: Span::new(
                    Position::new(6, 1, 7),
                    Position::new(8, 1, 9),
                ),
            },
        );
    }

    #[test]
    #[cfg(not(feature = "unicode-perl"))]
    fn class_perl_word_disabled() {
        assert_eq!(
            t_err(r"\w"),
            TestError {
                kind: hir::ErrorKind::UnicodePerlClassNotFound,
                span: Span::new(
                    Position::new(0, 1, 1),
                    Position::new(2, 1, 3)
                ),
            }
        );
    }

    #[test]
    #[cfg(all(not(feature = "unicode-perl"), not(feature = "unicode-bool")))]
    fn class_perl_space_disabled() {
        assert_eq!(
            t_err(r"\s"),
            TestError {
                kind: hir::ErrorKind::UnicodePerlClassNotFound,
                span: Span::new(
                    Position::new(0, 1, 1),
                    Position::new(2, 1, 3)
                ),
            }
        );
    }

    #[test]
    #[cfg(all(
        not(feature = "unicode-perl"),
        not(feature = "unicode-gencat")
    ))]
    fn class_perl_digit_disabled() {
        assert_eq!(
            t_err(r"\d"),
            TestError {
                kind: hir::ErrorKind::UnicodePerlClassNotFound,
                span: Span::new(
                    Position::new(0, 1, 1),
                    Position::new(2, 1, 3)
                ),
            }
        );
    }

    #[test]
    #[cfg(feature = "unicode-gencat")]
    fn class_unicode_gencat() {
        assert_eq!(t(r"\pZ"), hir_uclass_query(ClassQuery::Binary("Z")));
        assert_eq!(t(r"\pz"), hir_uclass_query(ClassQuery::Binary("Z")));
        assert_eq!(
            t(r"\p{Separator}"),
            hir_uclass_query(ClassQuery::Binary("Z"))
        );
        assert_eq!(
            t(r"\p{se      PaRa ToR}"),
            hir_uclass_query(ClassQuery::Binary("Z"))
        );
        assert_eq!(
            t(r"\p{gc:Separator}"),
            hir_uclass_query(ClassQuery::Binary("Z"))
        );
        assert_eq!(
            t(r"\p{gc=Separator}"),
            hir_uclass_query(ClassQuery::Binary("Z"))
        );
        assert_eq!(
            t(r"\p{Other}"),
            hir_uclass_query(ClassQuery::Binary("Other"))
        );
        assert_eq!(t(r"\pC"), hir_uclass_query(ClassQuery::Binary("Other")));

        assert_eq!(
            t(r"\PZ"),
            hir_negate(hir_uclass_query(ClassQuery::Binary("Z")))
        );
        assert_eq!(
            t(r"\P{separator}"),
            hir_negate(hir_uclass_query(ClassQuery::Binary("Z")))
        );
        assert_eq!(
            t(r"\P{gc!=separator}"),
            hir_negate(hir_uclass_query(ClassQuery::Binary("Z")))
        );

        assert_eq!(t(r"\p{any}"), hir_uclass_query(ClassQuery::Binary("Any")));
        assert_eq!(
            t(r"\p{assigned}"),
            hir_uclass_query(ClassQuery::Binary("Assigned"))
        );
        assert_eq!(
            t(r"\p{ascii}"),
            hir_uclass_query(ClassQuery::Binary("ASCII"))
        );
        assert_eq!(
            t(r"\p{gc:any}"),
            hir_uclass_query(ClassQuery::Binary("Any"))
        );
        assert_eq!(
            t(r"\p{gc:assigned}"),
            hir_uclass_query(ClassQuery::Binary("Assigned"))
        );
        assert_eq!(
            t(r"\p{gc:ascii}"),
            hir_uclass_query(ClassQuery::Binary("ASCII"))
        );

        assert_eq!(
            t_err(r"(?-u)\pZ"),
            TestError {
                kind: hir::ErrorKind::UnicodeNotAllowed,
                span: Span::new(
                    Position::new(5, 1, 6),
                    Position::new(8, 1, 9)
                ),
            }
        );
        assert_eq!(
            t_err(r"(?-u)\p{Separator}"),
            TestError {
                kind: hir::ErrorKind::UnicodeNotAllowed,
                span: Span::new(
                    Position::new(5, 1, 6),
                    Position::new(18, 1, 19)
                ),
            }
        );
        assert_eq!(
            t_err(r"\pE"),
            TestError {
                kind: hir::ErrorKind::UnicodePropertyNotFound,
                span: Span::new(
                    Position::new(0, 1, 1),
                    Position::new(3, 1, 4)
                ),
            }
        );
        assert_eq!(
            t_err(r"\p{Foo}"),
            TestError {
                kind: hir::ErrorKind::UnicodePropertyNotFound,
                span: Span::new(
                    Position::new(0, 1, 1),
                    Position::new(7, 1, 8)
                ),
            }
        );
        assert_eq!(
            t_err(r"\p{gc:Foo}"),
            TestError {
                kind: hir::ErrorKind::UnicodePropertyValueNotFound,
                span: Span::new(
                    Position::new(0, 1, 1),
                    Position::new(10, 1, 11)
                ),
            }
        );
    }

    #[test]
    #[cfg(not(feature = "unicode-gencat"))]
    fn class_unicode_gencat_disabled() {
        assert_eq!(
            t_err(r"\p{Separator}"),
            TestError {
                kind: hir::ErrorKind::UnicodePropertyNotFound,
                span: Span::new(
                    Position::new(0, 1, 1),
                    Position::new(13, 1, 14)
                ),
            }
        );

        assert_eq!(
            t_err(r"\p{Any}"),
            �ues"     y}"),
  assertpertyVa                Position::new(13, 1, 14)
                ),
            }
        e = "uni%reeky}"),
            hir_uclass_query(ClassQuery::Binary(%reek"), hir_uclass_query(ClassQuery::Binary("space")));
        assert_eq!(t(r"\w"), hir_uclass_perl_ni%reeky}"),
            hir\u{212A}', '\u_uclass_query(ClassQuery::Binary(%reek"),, hir_uclass_query(ClassQuery::Binary("space")));
        assert_eq!(t(r"\w"), hir_uclass_perl_Pi%reeky}"),
            hir_query(Clas\u{212A}', '\u_uclass_query(ClassQuery::Binarysert_eq!(
       (%reek"', '\u{10FFFF}))
        );
        assert_eq!(
            t(r"\p{gc:ry::r::ErrorKind::UnicodePropertyNotFound,
                span: Span::new(
                    Position::new(0, 1, 1),
                    Position::new(7, 1, 8)
                ),
            }
        );
        assert_eq!(
            t_err(r"\p{gc:Foo}"),
 o}"),
            TestError {
                kind: hscx::ErrorKind::UnicodePropertyNotFound,
                span: Span::new(
                    Position::new(0, 1, 1),
                    Position::new(7, 1, 8)
                ),
            }
        );
        ass1     )2
            t_err(r"\p{gc:Foo}"),
            TestError {
                kind: hir::ErrorKind::U       PPosition::new(13, 1, 14)
            span: Span::new(
                    Position::new%reeky}"),
           ropertyNotFound,
                span: Span::new(
                    Position::new(0, 1, 1),
                    Position::new(13, 1, 14)
                ),
            }
        );

  ☃"));
        assert_eq!(
            t_err(r"(?-u)\         TestError {
                kind: hscx:%reeky}"),
           ropertyNotFound,
                span: Span::new(
                    Position::new(0, 1, 1),
                    Position::new(13, 1, 14)
                ),
            }
        );

  assert_eq!(
            t_err(r"\p{Separator}"),
              �ues"     y}"),
  assertpertyVa         age Position::new(13, 1, 14)agean: Span::new(
                    Position::newage::ErrorKind::UnicodePropertyNotFound,
                span: Span::new(
                    Position::new(0, 1, 1),
                    Position::new(7, 1, 8)
                ),
            }
        );
        ass1     )2
            t_err(r"\p{gc:Foo}"),
  "),
            TestError {
                kind: hir::ErrorKind::UnicodePerlClassNotFouany_capture            span: Span::newPrator}"),
         (&[],])
        );
        asser      kind: hir::ErrorKind::Uage PPosition::new(13, 1, 14)age       span: Span::new(
                    Position::newage:3.0y}"),
           ropertyNotFound,
                span: Span::new(
                    Position::new(0, 1, 1),
                    Position::new(13, 1, 14)
                ),
            }
        );

  a1     )2
            t_err(r"\p{gc:Foo}"),
  "),
            TestError {
    n::new(13bracket just classes is always
    "[a]>b)"),
            hir_cat(vec![
       "[abt to a single class at("a"),
    hir_cat(vec![
       "[^[a]t to new(13_query(ngle class at("a         hir_cat(vec![
       "[a-zt to a single class at("az),
    hir_cat(vec![
       "[a-fd-ht to a single class at("ah),
    hir_cat(vec![
       "[a-fg-mt to a single class at("am':Look::End);
        let c = [\x00]      hir_uclass(&[
      0':Look::End);
        let c = [\n]      hir_uclass(&[
n     n),
    hir_cat(vec![
       "[\n]      hir_uclass(&[
n     n),
    hir_cat(       ny:ErrorKind::UnicodePerlCl, : hir::ErrorKind::UnicodePropertyV);
        let c = [\d]ir_ascii_bclass(&ast::ClassAsciiKind::Alnum),
               Unicode.)
    #[test]
    fn cat_class_flattened() {
        assert_eq[\pZ]ord());
        #[cfg(feature = "unicode-case")]
     0, 1, 1)"), hir_uclass_query(ClassQuery::Binary("space")  fn cat_class_flattened() {
        assert_eq[\p       );
 ]ord());
        #[cfg(feature = "unicode-case")]
     0, 1, 1)"), hir_uclass_query(ClassQue ny:ErrorKind::UnicodePerlCl, : hir::ErrorKind::UnicodePropertyV);
        let c = [^\D]ir_ascii_bclass(&ast::ClassAsciiKind::Alnum),
               Unicode.)
    #[test]
    fn cat_class_flattened() {
        assert_eq[^\PZ]ord());
        #[cfg(feature = "unicode-case")]
     0, 1, 1)"), hir_uclass_query(ClassQuery::Binary("space")  fn cat_class_flattened() {
        assert_eq[^
        );
 ]ord());
        #[cfg(feature = "unicode-case")]
     0, 1, 1)"), hir_uclass_query(ClassQue      kind: h    ny::Binary("space")));
 d());
         ny:ErrorKind::UnicodePerlCl, : hir::ErrorKind::UnicodePr hir_uclas       assert_eq!(t(r"\w"), hir_uclass_perl[^\D]ir_lassQuery::Binary("digit")));
        assert_eq!(t(r"\s"), hir_uclass_query(ClassQue    ny::Binary("space")));
 d : hir::ErrorKind::U       PPositioassert_eq!(t(r"\w"), hir_uclass_perl[^\P{greeky]}"),
            hir\u{212A}', '\u_uclass_query(ClassQuery::Binary(greek"),, hir_uclass_        assert_eq!(t("(?R    a]>b)"),
 ', 'λ')]),
            t_eq!(t(r"(?m)\z"), hir_look(h[\x00]      hi               (b'\00':Look::End);
        let c           hir[ hir_      hi             yte  // Byte class_        a  hir_negate(hir_uclass_query(ClassQuery::Binary("digi_perl[a]1, hir_bclass(&[(b'A', b'A'), (b'a', b'a'    assert_eq!(
            t("[[:xdigit:]]"),
            hir_ascii_uclass(&ast::Clk]        hir_bclass(&[(b'A', b'AK'a',KA'), (k'a',k', b'a'        );
        #[c_eq!(
            t("(?:a(?i)a)a"),
            hir_cat(vec![
                hir_cat(vec![
  [β]        hir_bclass(&[(b'A', b'AΒt_eq!�   asse�t_eq!�   assϐt_eqϐt!(t("a{1,}?"), hir_range(false, 1, None      k_      hi            K  // K  );
  k  // kb'\t'),
         vec![
       "[^at to new(13_query(ngle class at("a         hir_cat(vec![
       eq[^
x00]    new(13_query(ngle class 
      0':Looang/regex/issues/680
        assert_eq!(
         ^at to       assertnew(13_query(', 'λ')]),
             hir_uclass_query(ClassQue ny:ErrorKind::UnicodePerlCl, : hir::ErrorKind::UnicodePropertyV);
        let         assert_eq[^
d]       t(r"\S"),
            hir_negate(hir_uclass_query(ClassQuery::Binary("space")))
        );
        assert_eq!(t  fn cat_class_flattened() {
        assert_eq[^
pZ]ord());
        #[cf"unicode-case")]
        assert_eq!(
        0, 1, 1)"),ary("space")))
        );
        assert_eq!(t  fn cat_class_flattened() {
        assert_eq[^
p       );
 ]ord());
        #[cf"unicode-case")]
        assert_eq!(
        0, 1, 1)"),ary("space")))
        );
     ny::Binary("space")));
 d : hir::ErrorKind::U       PPositioassert_eq!(t(r"\w"), hir_uclass_perl[^\p{greeky]}"),
            hir_query(Clas\u{212A}', '\u_uclass_query(ClassQuery::Binarysert_eq!(
       (greek"', '\u{10FFFF}))
        );
 )
        );
     ny::Binary("space")));
 d : hir::ErrorKind::U       PPositioassert_eq!(t(r"\w"), hir_uclass_perl[\P{greeky]}"),
            hir_query(Clas\u{212A}', '\u_uclass_query(ClassQuery::Binarysert_eq!(
       (greek"', '\u{10FFFF}))
        );
            trope      weird::Clap{Modifier_Letter}
   t_eq[\[]1, hir_bclass(&[(b'[    [ class_        aLetter}
   t_eq[&]1, hir_bclass(&[(b'&    &':Look::End);
        let c = [\&]1, hir_bclass(&[(b'&    &':Look::End);
        let c = [\&\&]1, hir_bclass(&[(b'&    &':Look::End);
        let c = [\x00-&]      hir_uclass(&[
     &':Look::End);
        let c = [&- hir_      hiclass(&[(b'&       / See: ss_        aLetter}
   t_eq[~_      hiclass(&[(b'~    ~':Look::End);
        let c = [\~_      hiclass(&[(b'~    ~':Look::End);
        let c = [\~\~_      hiclass(&[(b'~    ~':Look::End);
        let c = [\x00-~]      hir_uclass(&[
     ~':Look::End);
        let c = [~- hir_      hiclass(&[(b'~       / See: ss_        aLetter}
   t_eq[-_      hiclass(&[(b'-    -':Look::End);
        let c = [\-_      hiclass(&[(b'-    -':Look::End);
        let c = [\-\-_      hiclass(&[(b'-    -':Look::End);
        let c = [\x00-\-_      hiclass(&[(b'
     -':Look::End);
        let c = [\-- hir_      hiclass(&[(b'-       / See: ss_        aLetter}
   -u)[[:lower:]]"),
        ^at to       assertind::InvalidUtf8,
                span: Span::new(
                    Position::new(5, 1, 6),
                    Position::new(7, 1, 8),
                ),
            },
 ☃"));
        assert_eq!(
            t_err(r"(?-u)\query(ClassQue ny:ErrorKind::UnicodePerlCl, : hir::ErrorKind::U       pertyV);
        let c = [^\s\S]}"),
         (&[],])
     y(ClassQue ny:ErrorKind::UnicodePerlCl, : hir::ErrorKind::U       pertyV);
        let c           hir[^\s\S]}"),
   b     (&[],])
        );
        assern::new(13bracket j    hirst classes is always
    "[a-zlent to a single class corresponding to the union of the  );
        assert_eq!(t  fn cat_class_flattened() {
        assert_eq[a
pZbascii:]]"),
            hir_union(
             ngle class at("a"),
  #[test]
    fn class_ascii_ure = "unicode-case")]
     0, 1, 1)"), hir_ucla"(?-u        );
 )
        );
     ny::Binary("space")  fn cad : hir::ErrorKind::U       PPositioassert_eq!(t(r"\w"), hir_uclass_[\pZnew%reekyascii:]]"),
            hir_union(
             ngle cs_query(ClassQuery::Binary(greek"), #[test]
    fn class_ascii_ure = "unicode-case")]
     0, 1, 1)"), hir_ucla"(?-u        );
 )
        );
       kind: h    ny::Binary("space")age ,  kind: h    ny::Binary("space")  fn cad  kind: h    ny::Binary("space")        hir_uclas       assert_eq!(t(r"\w"), hir_uclass_[newage:3.0y\pZnew%reekyascii:]]"),
            hir_union(
             ngle cs_query(ClassQuery::      lidUtf8,
              // match     : "age ,  kind: h            // match v    : "3.0 ,  kind: h        }, #[test]
    fn class_a  hir_union(
                 ngle cs_query(ClassQuery::Binary(greek"), #[test]
    fn cln class_ascii_ure = "unicode-case")]
     0, 1, 1)"), hir_ucla"(?-"(?-u        )"(?-u        );
 )
        );
       kind: h    ny::Binary("space")age ,  kind: h    ny::Binary("space")  fn cad  kind: h    ny::Binary("space")        hir_uclas       assert_eq!(t(r"\w"), hir_uclass_[[[newage:3.0y\pZ]new%reekya[newCyrillic}]ascii:]]"),
            hir_union(
             ngle cs_query(ClassQuery::      lidUtf8,
              // match     : "age ,  kind: h            // match v    : "3.0 ,  kind: h        }, #[test]
    fn class_a  hir_union(
                 ngle cs_query(Classe-case")]
    cyrillic"), #[test]
    fn cln class_a  hir_union(
                     ngle cs_query(ClassQuery::Binary(greek"), #[test]
    fn cln cln class_ascii_ure = "unicode-case")]
     0, 1, 1)"), hir_ucla"(?-"(?-"(?-u        )"(?-"(?-u        )"(?-u        );
  )
        );
       kind: h    ny::Binary("space")age ,  kind: h    ny::Binary("space")));
 d());
        ny::Binary("space")  fn cad  kind: h    ny::Binary("space")        hir_uclas       assert_eq!(t(r"\w"), hir_uclass_perl[\ewage:3.0y\pZnew%reekyascii:]]"),
         \u{212A}', '\u_  hir_union(
             ngle cs_query(ClassQuery::      lidUtf8,
              // match     : "age ,  kind: h            // match v    : "3.0 ,  kind: h        }, #[test]
    fn class_a  hir_union(
                 ngle cs_query(ClassQuery::Binary(greek"), #[test]
    fn cln class_ascii_ure = "unicode-case")]
     0, 1, 1)"), hir_ucla"(?-"(?-u        )"(?-uu        );
 )
        );
       kind: h    ny::Binary("space")age ,  kind: h    ny::Binary("space")  fn cad  kind: h    ny::Binary("space")        hir_uclas       assert_eq!(t(r"\w"), hir_uclass_[^\ewage:3.0y\pZnew%reekyascii:]]"),
         "unicode-cas  hir_union(
             ngle cs_query(ClassQuery::      lidUtf8,
              // match     : "age ,  kind: h            // match v    : "3.0 ,  kind: h        }, #[test]
    fn class_a  hir_union(
                 ngle cs_query(ClassQuery::Binary(greek"), #[test]
    fn cln class_ascii_ure = "unicode-case")]
     0, 1, 1)"), hir_ucla"(?-"(?-u        )"(?-uu        );
 )
        );
       kind: h    ny::Binary("space")age ,  kind: h    ny::Binary("space")));
 d());
        ny::Binary("space")  fn cad  kind: h    ny::Binary("space")        hir_uclas       assert_eq!(t(r"\w"), hir_uclass_perl[^\ewage:3.0y\pZnew%reekyascii:]]"),
         "unicode-ca\u{212A}', '\u_  hir_union(
             ngle cs_query(ClassQuery::      lidUtf8,
              // match     : "age ,  kind: h            // match v    : "3.0 ,  kind: h        }, #[test]
    fn class_a  hir_union(
                 ngle cs_query(ClassQuery::Binary(greek"), #[test]
    fn cln class_ascii_ure = "unicode-case")]
     0, 1, 1)"), hir_ucla"(?-"(?-u        )"(?-uu)
  "),
            TestError {
    n::new(13bracket j "ust just classes is always
    // e[^c]t to new(13_query(ngle class ct("ac        hir_cat(vec![
       eq[a-b[^c]t to new(13_query(ngle class ct("ac        hir_cat(vec![
       eq[a-c[^c]t to new(13_query(ngle clas]) ss_        aLetter}
   t_eq[^e[^c]t to     ngle class ct("ac       hir_cat(vec![
       eq[^a-b[^c]t to     ngle class ct("ac       _query(ClassQuery::Binary("space")));
        assert_eq!(t(r"\w"), hir_uclass_perl e[^c]t toi:]]"),
         "unicodnew(13\u{212A}',ngle class ct("ac       hir_uclass_query(ClassQuery::Binary("space")));
        assert_eq!(t(r"\w"), hir_uclass_perl[a-b[^c]t toi:]]"),
         "unicodnew(13\u{212A}',ngle class ct("ac       hir_uclass_           hir_negate(hir_uclass_query(ClassQuery::Binary("digit")))
[^e[^c]t to     ngle class Ct("aCpondinct("ac       hir_cat(assQuery::Binary("space")));
        assert_eq!(t(r"\w"), hir_uclass_perl[^a-b[^c]t toi:]]"),
         ngle class Ct("aCpondinct("ac       assert_eq!(
            t(r"\P{se[^a-c[^c]t to     ngle clas],])
     y(ClassQuenegate(hir_uclass_query(ClassQuery::Binary("digit")))
[^e-c[^c]t to     ngle clas],])
        TestError {
    n::new(13bracket j intersectrst classes is always
    "[abc&&b-ct to     ngle class bt("ac       hir_cat(vec![
       "[abc&&[b-ctt to     ngle class bt("ac       hir_cat(vec![
       "[[abc]&&[b-ctt to     ngle class bt("ac       hir_cat(vec![
       "[a-z&&b-y&&c-xt to     ngle class ct("ax       hir_cat(vec![
       "[c-da-b&&a-dt to a single class at("ad       hir_cat(vec![
       "[a-d&&c-da-bt to a single class at("ad       hir_cat(vec![
       r"[a-z&&a-ct to     ngle class at("ac       hir_cat(vec![
       eq[[a-z&&a-ctt to     ngle class at("ac       hir_cat(vec![
       eq[^[a-z&&a-ctt to     "unicode-case")]
lass at("ac     ss_        assert_eq!(t("(?R    abc&&b-ct to     ', 'λ')]),
b     c       hir_cat(vec![
       "?R    abc&&[b-ctt to     ', 'λ')]),
b     c       hir_cat(vec![
       "?R    [abc]&&[b-ctt to     ', 'λ')]),
b     c       hir_cat(vec![
       "?R    a-z&&b-y&&c-xt to     ', 'λ')]),
c     x       hir_cat(vec![
       "?R    c-da-b&&a-dt to a si', 'λ')]),
      d       hir_cat(vec![
       "?R    a-d&&c-da-bt to a si', 'λ')]),
      d            t("(?:a(?i)a)a"),
            hir_cat(vec![
                hir_cat(vec![
  [abc&&b-ct to,
            hir\u{212A}', '\u_uclaslass bt("ac     q!(
            t("(?:a(?i)a)a"),
            hir_cat(vec![
                hir_cat(vec![
  [abc&&[b-ctt to,
            hir\u{212A}', '\u_uclaslass bt("ac     q!(
            t("(?:a(?i)a)a"),
            hir_cat(vec![
                hir_cat(vec![
  [[abc]&&[b-ctt to,
            hir\u{212A}', '\u_uclaslass bt("ac     q!(
            t("(?:a(?i)a)a"),
            hir_cat(vec![
                hir_cat(vec![
  [a-z&&b-y&&c-xt to,
            hir\u{212A}', '\u_uclaslass ct("ax     q!(
            t("(?:a(?i)a)a"),
            hir_cat(vec![
                hir_cat(vec![
  [c-da-b&&a-dt to,
            hir\u{212A}', '\u_uclaslass at("ad     q!(
            t("(?:a(?i)a)a"),
            hir_cat(vec![
                hir_cat(vec![
  [a-d&&c-da-bt to,
            hir\u{212A}', '\u_uclaslass at("ad     q!(
           ('a', 'z'),
                ('\u{17F}', abc&&b-ct to,
            hir\u{212A}', '\u', 'λ')]),
b     c                   ('a', 'z'),
                ('\u{17F}', abc&&[b-ctt to,
            hir\u{212A}', '\u', 'λ')]),
b     c                   ('a', 'z'),
                ('\u{17F}', [abc]&&[b-ctt to,
            hir\u{212A}', '\u', 'λ')]),
b     c                   ('a', 'z'),
                ('\u{17F}', a-z&&b-y&&c-xt to,
            hir\u{212A}', '\u', 'λ')]),
c     x                   ('a', 'z'),
                ('\u{17F}', c-da-b&&a-dt to,
            hir\u{212A}', '\u', 'λ')]),
      d                   ('a', 'z'),
                ('\u{17F}', a-d&&c-da-bt to,
            hir\u{212A}', '\u', 'λ')]),
      d                 r_ascii_bclass(`[a^]`, `^` doesd,
  need
   be escap),
 so it mak somense     r_ascii_bcla`^` , d()so a Posit
   be unescap), af    `&&`{Modifier_Letter}
   t_eq[\^&&^t to     ngle class ^t("a^he union of the br`]` needs
   be escap), af    `&&`  ])ce it'sd,
  at start in     }
Modifier_Letter}
   t_eq[]&&\tt to     ngle class ]t("a]       hir_cat(vec![
       eq[-&&-_      hiclass(&[(b'-    -':Look::End);
        let c = [\&&&&]1, hir_bclass(&[(b'&    &':Look::End);
        let c = [\&&&\&]1, hir_bclass(&[(b'&    &':Look::End);
   trope precede)ce.class_flattened() {
        assert_eq[a-w&&[^c-g]zt toi:]]"),
         ngle class at("a"),ndinht("aw       assert_eq       TestError {
    n::new(13bracket j intersect "unicodst classes i    assert_eq!(
            t_bytes("assert_eq!(t(r"\w"), hir_uclass_[^\w&&
d]       t(r"\S"),
            hir_negate(hir_uclass_query(ClassQuery::Binary("space")))
      vec![
       eq[^[a-z&&a-ctt to     "unicode-case")]
lass at("ac     ss_lasses i    assert_eq!(
            t_bytes("assert_eq!(t(r"\w"), hir_uclass_[^[\w&&
d]]       t(r"\S"),
            hir_negate(hir_uclass_query(ClassQuery::Binary("space")))
        );
        assert_eq!(t   t_bytes("assert_eq!(t(r"\w"), hir_uclass_[^[^\w&&
d]]       t(r"\S"),
   ("digit")));
        assert_eq!(t(r"\s"), hir_uclass_query(ClassQuery::Binary("space")   t_bytes("assert_eq!(t(r"ass_[[[^\w]&&[^
d]tt to     "unicode-case")]
ature = "unicode))
        );
        assert_eq!(t   t_bytes("assert_eq!(t(r"\w"), hir_ucla           hir[^\w&&
d]       t(r"\S"),
            hi:Space)
        );
        assert_eq!(
            t(r"(?i-u)\w"),
            hir_ascii_bclass(&ast:[^[a-z&&a-ctt to    t(r"\S"),
            hi', 'λ')]),
      c                   ('a', 'z'),
                ('\i_bclass(&ast:[^[\w&&
d]]       t(r"\S"),
            hi:Space)
        );
        assert_eq!(
            t(r"(?i-u)\w"),
            hir_ascii_bclass(&ast:[^[^\w&&
d]]       t(r"\S"),
              hir_ascii_bclass(&ast::ClassAsciiKind::Space)
        );
        assert_eq!i_bclass(&ast:[[[^\w]&&[^
d]tt tote(hir_ascii_bclass(&ast::ClassAsciiKind::Digit))
        );
        assert_eq!(
       TestError {
    n::new(13bracket j differe)cedst classes i    assert_eq!(
           fn cat_class_flattened() {
        assert_eq[\pL--[:um:][:^ascii:]]"),
         differe)ced#[test]
    fn class_ascii_ure = "unicode-case")]
    lett      #[test]
    fn class_ascii_multip      x7F       assert"(?-u        );
  )
      I only
        assert_eq!(
          tpha:]--[:u{17F}'),
                ('', 'λ')]),
A     Z       assert_eq       TestError {
    n::new(13bracket j symmetric differe)cedst classes i    assert_eq!(
                Positio_flattened() {
        assert_eq[\p  c:%reeky~~: hscx:%reekyind::Xdigit)
        );

        assert_eq!(
    \u{0342  );
   0342  assAsciiKind::Lower))
  0345  );
   0345  assAsciiKind::Lower))
  1DC) {
      DC1 #[cfg(feature = "unicode-case"hir_cat(vec![
       r"[a-g~~c-jt to a single class at("a"),ndinht("ajee: ss_        aLetter}
   -u)[[:lower:]](
       a-g~~c-jt to               ('', 'λ')]),
      b  );
  h     j       assert_eq       TestError {
    n::ignore_whiror    ust classes is always
    //(?x)\12 3>b)"),
      \n3"  t_eq!(t(r"(?m)\z"), hir_loox)\x { 53 }>b)"),
      S")ord)
        );
        assert_eq!(
     x)\x # comment
{ # comment
eq!(53 # comment
} #comment to               ('     S")   assert_eq!(
            t(r"\P{se  x)\x 53>b)"),
      S")ord)
        );
        assert_eq!(
     x)\x # comment
ert_eq!(53 # comment to               ('     S")   assert_eq(
            t(r"\P{se  x)\x5 3>b)"),
      S")ordclasses i    assert_eq!(
           fn cat_class_flattened() {
        assert_eq  x)\p # comment
{ # comment
eq!((0, 1, 1) # comment
} # comment to               ('g(feature = "unicode-case")]
     0, 1, 1)"), hir_uclass_class_flattened() {
        assert_eq  x)a # comment
{ # comment
eq!(5 # comment
eq!(, # comment
eq!(10 # comment
} # comment to               ('range(true, 5, Some(10b)"),
             assert_eq!(
            t(r"\P{se  x)a\ i "),     e>b)"),
        "code-case")]
        assert_eqanalysis_is_utf8(r"(?i)\S"),
         ve examplap{Modifier_Letter!(// msi_bclass(   .is_utf8(r_eq(
            !(// msi_bclass( b  .is_utf8(r_eq(
            !(// msi_bclass(     a  .is_utf8(r_eq(
            !(// msi_bclass(     ab  .is_utf8(r_eq(
            !(// msi_bclass( hir  .is_utf8(r_eq(
            !(// msi_bclass( hir hir  .is_utf8(r_eq(
            !(// msi_bclass( ^at t.is_utf8(r_eq(
            !(// msi_bclass( ^at ^at t.is_utf8(r_eq(
            !(// msi_bclass(\b  .is_utf8(r_eq(
            !(// msi_bclass( B  .is_utf8(r_eq(
            !(// msi_bclass(     \b  .is_utf8(r_eq(
            !(// msi_bclass(      B  .is_utf8(r_eq?i)\S"),
   NsciiKve examplap{Modifier_Letter!(!// msi_bclass(      hir  .is_utf8(r_eq(
            !(!// msi_bclass(      hir hir  .is_utf8(r_eq(
            !(!// msi_bclass(      ^at t.is_utf8(r_eq(
            !(!// msi_bclass(      ^at ^at t.is_utf8(r_eq(
  e")]
        assert_eqanalysis_capt_eqs_leirst classes is always
  0, // mass(   .explicit_capt_eqs_leirs_eq(
            t(r"\0, // mass((?:a)  .explicit_capt_eqs_leirs_eq(
            t(r"\0, // mass((?i-u:a)  .explicit_capt_eqs_leirs_eq(
            t(r"\0, // mass((?i-u)   .explicit_capt_eqs_leirs_eq(
            t(r"\1, // mass((a)  .explicit_capt_eqs_leirs_eq(
            t(r"\1, // mass((?P<foo>a)  .explicit_capt_eqs_leirs_eq(
            t(r"\1, // mass(()  .explicit_capt_eqs_leirs_eq(
            t(r"\1, // mass(()   .explicit_capt_eqs_leirs_eq(
            t(r"\1, // mass((a)+  .explicit_capt_eqs_leirs_eq(
            t(r"\2, // mass((a)(b)  .explicit_capt_eqs_leirs_eq(
            t(r"\2, // mass((a)|(b)  .explicit_capt_eqs_leirs_eq(
            t(r"\2, // mass(((a))  .explicit_capt_eqs_leirs_eq(
            t(r"\1, // mass(([a&&b])  .explicit_capt_eqs_leirs_eq(
  e")]
        assert_eqanalysis_stiiKc_capt_eqs_leirst classes iletilen!(
|patt  n| // maspatt  n).stiiKc_explicit_capt_eqs_leirseq(
            t(r"\Some(0b)"leirr"")ord)
        );
      Some(0b)"leirr"foo|bar")ord)
        );
      None)"leirr"(foo)|bar")ord)
        );
      None)"leirr"foo|(bar)")ord)
        );
      Some(1))"leirr"(foo|bar)")ord)
        );
      Some(1))"leirr"(a|b|c|d|e|f)")ord)
        );
      Some(1))"leirr"(a)|(b)|(c)|(d)|(e)|(f)")ord)
        );
      Some(2))"leirr"(a)(b)|(c)(d)|(e)(f)")ord)
        );
      Some(6))"leirr"(a)(b)(c)(d)(e)(f)")ord)
        );
      Some(3))"leirr"(a)(b)(extra)|(a)(b)()")ord)
        );
      Some(3))"leirr"(a)(b)((?:extra)?)")ord)
        );
      None)"leirr"(a)(b)(extra)?")ord)
        );
      Some(1))"leirr"(foo)|(bar)")ord)
        );
      Some(2))"leirr"(foo)(bar)")ord)
        );
      Some(2))"leirr"(foo)+(bar)")ord)
        );
      None)"leirr"(foo)*(bar)")ord)
        );
      Some(0))"leirr"(foo)?{0y}"ord)
        );
      None)"leirr"(foo)?{1}")ord)
        );
      Some(1))"leirr"(foo){1}")ord)
        );
      Some(1))"leirr"(foo){1,}")ord)
        );
      Some(1))"leirr"(foo){1,}?}"ord)
        );
      None)"leirr"(foo){1,}??}"ord)
        );
      None)"leirr"(foo){0,}")ord)
        );
      Some(1))"leirr"(foo)(?:bar)")ord)
        );
      Some(2))"leirr"(foo(?:bar)+)(?:baz(boo))")ord)
        );
      Some(2))"leirr"(?P<bar>foo)(?:bar)(bal|loon)")ord)
        );
        assert_eq!(Some(2))  assert_eq!(leirr#"<(a)[^>]+href=(([^"]+)"|<(img)[^>]+src=(([^"]+)""#    assert_eq       TestError {
    n::analysis_is_all_  );
 ions(r"(?i)\S"),
         ve examplap{Modifier_letip!(
// mass(\b  eq(
            !(!/.look_set(t.is_captureord)
        );
      p.minimum_leirs, Some(0r_eq?i)\S"),
letip!(
// mass(\B  eq(
            !(!/.look_set(t.is_captureord)
        );
      p.minimum_leirs, Some(0r_eq?i)\S"),
letip!(
// mass(^  eq(
            !(!/.look_set(t.is_captureord)
        );
      p.minimum_leirs, Some(0r_eq?i)\S"),
letip!(
// mass($  eq(
            !(!/.look_set(t.is_captureord)
        );
      p.minimum_leirs, Some(0r_eq?i)\S"),
letip!(
// mass(\A  eq(
            !(!/.look_set(t.is_captureord)
        );
      p.minimum_leirs, Some(0r_eq?i)\S"),
letip!(
// mass(\z  eq(
            !(!/.look_set(t.is_captureord)
        );
      p.minimum_leirs, Some(0r_eq?i)\S"),
letip!(
// mass($^\z\A\b\B  eq(
            !(!/.look_set(t.is_captureord)
        );
      p.minimum_leirs, Some(0r_eq?i)\S"),
letip!(
// mass($|^|\z|\A|\b|\B  eq(
            !(!/.look_set(t.is_captureord)
        );
      p.minimum_leirs, Some(0r_eq?i)\S"),
letip!(
// mass(^$|$^  eq(
            !(!/.look_set(t.is_captureord)
        );
      p.minimum_leirs, Some(0r_eq?i)\S"),
letip!(
// mass(((\b)+())*^  eq(
            !(!/.look_set(t.is_captureord)
        );
      p.minimum_leirs, Some(0r_eq?i)\S"),
   NsciiKve examplap{Modifier_letip!(
// mass(^a  eq(
            !(!/.look_set(t.is_captureord)
        );
      p.minimum_leirs, Some(1s_eq(
  e")]
        assert_eqanalysis_look_set_prefixuanyrst classes iletip!(
// mass((    (?i:(?:\b|_)win(?:32|64|dows)?(?:\b|_))  eq(
            !(/.look_set_prefixuanyrs.contains(Look           code-case")]
        assert_eqanalysis_is_anchor just classes iletiis_stirt!(
|p| // masp).look_set_prefixrs.contains(Look  Stirt eq(
      letiis_end!(
|p| // masp).look_set_suffixrs.contains(Look  End_eq?i)\S"),
         ve examplap{Modifier_Letter!(is_stirtss(^   eq(
            !(is_endss($  _eq!(
            !(is_stirtss(^^   eq(
            !(// mass($$  .look_set_suffixrs.contains(Look  End__eq!(
            !(is_stirtss(^$   eq(
            !(is_endss(^$  _eq!(
            !(is_stirtss(^foo   eq(
            !(is_endss(foo$  _eq!(
            !(is_stirtss(^foo|^bar")ord)
        );
 !(is_endss(foo$|bar$  _eq!(
            !(is_stirtss(^(foo|bar)")ord)
        );
 !(is_endss((foo|bar)$  _eq!(
            !(is_stirtss(^+   eq(
            !(is_endss($+   eq(
            !(is_stirtss(^++   eq(
            !(is_endss($++   eq(
            !(is_stirtss((^)+   eq(
            !(is_endss(($)+   eqq(
            !(is_stirtss($^   eq(
            !(is_stirtss($^   eq(
            !(is_stirtss($^|^$   eq(
            !(is_endss($^|^$   eqq(
            !(is_stirtss(\b^   eq(
            !(is_endss($\b   eq(
            !(is_stirtss(^(?m:^)")ord)
        );
 !(is_endss((?m:$)$   eq(
            !(is_stirtss((?m:^)^   eq(
            !(is_endss($(?m:$)"r_eq?i)\S"),
   NsciiKve examplap{Modifier_Letter!(!is_stirtss((?m)^   eq(
            !(!is_endss((?m)$   eq(
            !(!is_stirtss((?m:^$)|$^   eq(
            !(!is_endss((?m:^$)|$^   eq(
            !(!is_stirtss($^|(?m:^$)   eq(
            !(!is_endss($^|(?m:^$)   eqq(
            !(!is_stirtss(a^   eq(
            !(!is_stirtss($a   eqq(
            !(!is_endss(a^   eq(
            !(!is_endss($a   eqq(
            !(!is_stirtss(^foo|bar")ord)
        );
 !(!is_endss(foo|bar$  _eq!(
            !(!is_stirtss(^*   eq(
            !(!is_endss($*   eq(
            !(!is_stirtss(^*+   eq(
            !(!is_endss($*+   eq(
            !(!is_stirtss(^+*   eq(
            !(!is_endss($+*   eq(
            !(!is_stirtss((^)*   eq(
            !(!is_endss(($)*"code-case")]
        assert_eqanalysis_is_any_anchor just classes iletiis_stirt!(
|p| // masp).look_setrs.contains(Look  Stirt eq(
      letiis_end!(
|p| // masp).look_setrs.contains(Look  End_eq?i)\S"),
         ve examplap{Modifier_Letter!(is_stirtss(^   eq(
            !(is_endss($  _eq(
            !(is_stirtss(\A   eq(
            !(is_endss(\z  _eq?i)\S"),
   NsciiKve examplap{Modifier_Letter!(!is_stirtss((?m)^   eq(
            !(!is_endss((?m)$   eq(
            !(!is_stirtss($   eq(
            !(!is_endss(^"r_eq(
  e")]
        assert_eqanalysis_can_capture                    ve examplap{Modifier_leti  );
   aptu =  assert_eq!(|p|   );
      Some(0))"// msi_bclasp).minimum_leirsord)
        );
   apturr"")rd)
        );
   apturr"()")rd)
        );
   apturr"()*")rd)
        );
   apturr"()+")rd)
        );
   apturr"()?")rd)
        );
   apturr"a*")rd)
        );
   apturr"a?")rd)
        );
   apturr"a{0y}"rd)
        );
   apturr"a{0,y}"rd)
        );
   apturr"a{0,1y}"rd)
        );
   apturr"a{0,10y}"rd)
          assert_eq!(
           fn cat_class_flattened()apturr"\pL*")rd)
        );
   apturr"a*|b")rd)
        );
   apturr"b|a*")rd)
        );
   apturr"a|")rd)
        );
   apturr"|a")rd)
        );
   apturr"a||b")rd)
        );
   apturr"a*a?(abcd)*")rd)
        );
   apturr"^")rd)
        );
   apturr"$")rd)
        );
   apturr"(?m)^  rd)
        );
   apturr"(?m)$")rd)
        );
   apturr"\A  eq(
              apturr"\z  eq(
              apturr"\B  rd)
        );
   apturr"(?    B  eq(
              apturr"\b  rd)
        );
   apturr"(?    b  rd?i)\S"),
   NsciiKve examplap{Modifier_leti  );
  non  aptu =  assert_eq!(|p|   );
  ne  Some(0))"// msi_bclasp).minimum_leirsord)
        );
  non  apturr"a+")rd)
        );
  non  apturr"a{1y}"rd)
        );
  non  apturr"a{1,y}"rd)
        );
  non  apturr"a{1,2y}"rd)
        );
  non  apturr"a{1,10y}"rd)
        );
  non  apturr"b|a")rd)
        );
  non  apturr"a*a+(abcd)*")rd)
          assert_eq!(
           fn cat_class_flattened(non  apturr"wPrator}"rd)
        );
  non  apturr"[a--at trd)
        );
  non  apturr"[a&&b]"ode-case")]
        assert_eqanalysis_is_literal(r"(?i)\S"),
         ve examplap{Modifier_Letter!(// msss(   .is_literal(r eq(
            !(// mass(ab  .is_literal(r eq(
            !(// mass(abc  .is_literal(r eq(
            !(// mass((?m)abc  .is_literal(r eq(
            !(// mass((?:a)  .is_literal(r eq(
            !(// mass(foo(?:a)  .is_literal(r eq(
            !(// mass((?:a)foo  .is_literal(r eq(
            !(// mass([at t.is_literal(r eq?i)\S"),
   NsciiKve examplap{Modifier_Letter!(!// msrr"").is_literal(r eq(
            !(!// mass(^  .is_literal(r eq(
            !(!// mass(a|b  .is_literal(r eq(
            !(!// mass((a)  .is_literal(r eq(
            !(!// mass(a+  .is_literal(r eq(
            !(!// mass(foo(a)  .is_literal(r eq(
            !(!// mass((a)foo  .is_literal(r eq(
            !(!// mass([ab]  .is_literal(r eq(
     TestError {
    n::analysis_is_alt  na ion_literal(r"(?i)\S"),
         ve examplap{Modifier_Letter!(// msss(   .is_alt  na ion_literal(r eq(
            !(// mass(ab  .is_alt  na ion_literal(r eq(
            !(// mass(abc  .is_alt  na ion_literal(r eq(
            !(// mass((?m)abc  .is_alt  na ion_literal(r eq(
            !(// mass(foo|bar").is_alt  na ion_literal(r eq(
            !(// mass(foo|bar|baz").is_alt  na ion_literal(r eq(
            !(// mass([at t.is_alt  na ion_literal(r eq(
            !(// mass((?:ab)|cd  .is_alt  na ion_literal(r eq(
            !(// mass(ab|(?:cd)  .is_alt  na ion_literal(r eq?i)\S"),
   NsciiKve examplap{Modifier_Letter!(!// msrr"").is_alt  na ion_literal(r eq(
            !(!// mass(^  .is_alt  na ion_literal(r eq(
            !(!// mass((a)  .is_alt  na ion_literal(r eq(
            !(!// mass(a+  .is_alt  na ion_literal(r eq(
            !(!// mass(foo(a)  .is_alt  na ion_literal(r eq(
            !(!// mass((a)foo  .is_alt  na ion_literal(r eq(
            !(!// mass([ab]  .is_alt  na ion_literal(r eq(
            !(!// mass([ab]|b  .is_alt  na ion_literal(r eq(
            !(!// mass(a|[ab]  .is_alt  na ion_literal(r eq(
            !(!// mass((a)|b  .is_alt  na ion_literal(r eq(
            !(!// mass(a|(b)  .is_alt  na ion_literal(r eq(
            !(!// mass(a|b  .is_alt  na ion_literal(r eq(
            !(!// mass(a|b|c  .is_alt  na ion_literal(r eq(
            !(!// mass([a]|b  .is_alt  na ion_literal(r eq(
            !(!// mass(a|[b]  .is_alt  na ion_literal(r eq(
            !(!// mass((?:a)|b  .is_alt  na ion_literal(r eq(
            !(!// mass(a|(?:b)  .is_alt  na ion_literal(r eq(
            !(!// mass((?:z|xx)@|xx  .is_alt  na ion_literal(r eq(
     Test  trhis ror s          smirt!Hpan:repet      constructors doesd     basic Test  tsimplifica ionp{ModifError {
    n::smirt_repet     ust classes is always
    //a{0y}",!Hpan:captureord)
        );
      trr"a{1y}")"),
            hir_cat(vec![
       r"\B{32111y}")"),
  ook(span:Look             Nsciier eq(
     Test  trhis ror s          smirt!Hpan:conca  constructortsimplifies     gKven Test  texprs i::a way we expect{ModifError {
    n::smirt_conca rst classes is always
    "}",!Hpan:captureord)
        );
      tr((?:)}",!Hpan:captureord)
        );
      tr(abc  )"),
       bc  ord)
        );
      tr((?:foo)(?:bar)"))"),
      foobar")ord)
        );
         quux(?:foo)(?:bar)baz"))"),
      quuxfoobarbaz")     ('a', 'z'),
                ('\u{foo(?:bar^baz)quux to,
            hir\ut(vec![#[test]
    fn class_     foobar") #[test]
    fn class_ ook(span:Look  Stirt ,#[test]
    fn class_     bazquux to,
           ]               ('a', 'z'),
                ('\u{foo(?:ba(?:r^b)az)quux to,
            hir\ut(vec![#[test]
    fn class_     foobar") #[test]
    fn class_ ook(span:Look  Stirt ,#[test]
    fn class_     bazquux to,
           ]               ('   Test  trhis ror s          smirt!Hpan:alt  na ion constructortsimplifies     Test  tgKventexprs i::a way we expect{ModifError {
    n::smirt_alt  na ionan: Span::new(
                    Posr((?:foo)|(?:bar)"))    t(r"\S"),
    lt(vec![ass_     foo"))"),
      bar")]               ('a', 'z'),
                ('\u{quux|(?:abc|def|xyz)|baz"))    t(r"\S"),
    lt(vec![#[test]
    fn class_     quux to,
           n class_     abc  ),
           n class_     def  ),
           n class_     xyz" ,#[test]
    fn class_     baz to,
           ]               ('a', 'z'),
                ('\u{quux|(?:abc|(?:def|mno)|xyz)|baz"))    t(r"\S"),
    lt(vec![#[test]
    fn class_     quux to,
           n class_     abc  ),
           n class_     def  ),
           n class_     mno  ),
           n class_     xyz" ,#[test]
    fn class_     baz to,
           ]               ('a', 'z'),
                ('\u{a|b|c|d|e|f|x|y|z toi:]]"),
         ngle class at("af),ndinx to the u,              ('a',   tropes      we lift common prefixes out in a::alt  na ion.class_flattened() {
        assert_"[lentfoo|[lentquux to,
            hir\ut(vec![#[test]
    fn class_ngle class correspo
  #[test]
    fn class_ lt(vec![ass_     foo"))"),
      quux t]to,
           ] ,              ('a', 'z'),
                ('\u{[lent[lent|[lentquux to,
            hir\ut(vec![#[test]
    fn class_ngle class correspo
  #[test]
    fn class_ lt(vec![ass_ngle class correspo
  "),
      quux t]to,
           ] ,              ('a', 'z'),
                ('\u{[lent[lent|[lent[lentquux to,
            hir\ut(vec![#[test]
    fn class_ngle class correspo
  #[test]
    fn class_ngle class correspo
  #[test]
    fn class_ lt(vec![Hpan:capture "),
      quux t]to,
           ] ,              ('a', 'z'),
                ('\u{[lentfoo|[lentfoobar") #[test]
    f hir\ut(vec![#[test]
    fn class_ngle class correspo
  #[test]
    fn class_ lt(vec![ass_     foo"))"),
      foobar")]to,
           ] ,              ('   TestError {
    n::regression_ lt  aptu_conca rst classes iuse criien:aigit{self, Ast}eq?i)\S"),
leti::ne =(5, 1, spla r          },
 0, 0, 0) eq(
      letiaig =(Aigitalt  na ionaaigitAlt  na ion idUtf8,
      ::ned());
         pes: vec![Aigitconca rDigit)onca  { ::ned  pes: vec![] })]d());
    }_eq?i)\S"),
letimut g =(Transl, 1)  },
      ('a', 'z'),
     Ok(Hpan:captureo, t.transl, e "}, :Dig)     ('   TestError {
    n::regression_ aptu_ lt(st classes iuse criien:aigit{self, Ast}eq?i)\S"),
leti::ne =(5, 1, spla r          },
 0, 0, 0) eq(
      letiaig =(Aigitconca rDigit)onca  {dUtf8,
      ::ned());
         pes: vec![Aigitalt  na ionaaigitAlt  na ion idUtf8,
          ::ned());
             pes: vec![]
            t_)]d());
    }_eq?i)\S"),
letimut g =(Transl, 1)  },
      ('a', 'z'),
     Ok(Hpan:failreo, t.transl, e "}, :Dig)     ('   TestError {
    n::regression_singleton_ lt(st classes iuse criien:{());
         peit{self, Ast} #[test]
    f hi::Dotd());
    }eq?i)\S"),
leti::ne =(5, 1, spla r          },
 0, 0, 0) eq(
      letiaig =(Aigitconca rDigit)onca  {dUtf8,
      ::ned());
         pes: vec![Aigitalt  na ionaaigitAlt  na ion idUtf8,
          ::ned());
             pes: vec![Aigitdot(::ne)]
            t_)]d());
    }_eq?i)\S"),
letimut g =(Transl, 1)  },
      ('a', 'z'),
     Ok(Hpan:dot(DotitAnyCharExceptLFeo, t.transl, e "}, :Dig)     ('   Test  tSee: https://bugs.chromium.org/p/oss-fuzz/issues/detail?id=63168 TestError {
    n::regression_fuzz_matchrst classes iletipag =("[(\u{6} \0-\u{afdf5}]  \0 "eq(
      letiaig =(Par'),Builde)  },
              t.octal(false             t.ignore_whiror    utrue             t.build              t.par')spat             t.unwrap( eq(
      leti hi =(Transl, 1)Builde)  },
              t.utf8(true             t.\u{21inmens   ve(false             t.multi   ne(false             t.dot_matche13_qw   ne(false             t.swap_greed(true             t.       utrue             t.build              t.transl, e pat, :Dig)            t.unwrap( eq(
      'z'),
                (' hi
            tHpan:conca (vec![#[test]
    fn class_ngle class p      u{afdf5}po
  #[test]
    fn class_     \0 to,
           ]               ('   Test  tSee: https://bugs.chromium.org/p/oss-fuzz/issues/detail?id=63155
        assert_eq!(
        at_classError {
    n::regression_fuzz_differe)ce1rst classes iletipag =(r"\W\W|\W[^\v--\W\W\P{S     _Extens ons:Pau_Cin_Hau}\u10A1A1-\U{3E3E3}--~~~~--~~~~~~~~------~~~~~~--~~~~~~]*"eq(
      leti_ =(tspat ;t  tshouldn'tipanic Test   Test  tSee: https://bugs.chromium.org/p/oss-fuzz/issues/detail?id=63153classError {
    n::regression_fuzz_char_decrement1rst classes iletipag =("w[w[^w?\rw\rw[^w?\rw[^w?\rw[^w?\rw[^w?\rw[^w?\rw[^w?\r\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0w?\rw[^w?\rw[^w?\rw[^w\0\0\u{1}\0]\0\0-*\0]\0\0\0\0\0\0\u{1}\0]\0\0-*\0]\0\0\0\0\0\u{1}\0]\0\0\0\0\0\0\0\0\0*\0\0\u{1}\0]\0\0-*\0][^w?\rw[^w?\rw[^w?\rw[^w?\rw[^w?\rw[^w?\rw[^w\0\0\u{1}\0]\0\0-*\0]\0\0\0\0\0\0\u{1}\0]\0\0-*\0]\0\0\0\0\0\u{1}\0]\0\0\0\0\0\0\0\0\0x\0\0\u{1}\0]\0\0-*\0]\0\0\0\0\0\0\0\0\0*??\0\u{7f}{2}\u{10}??\0\0\0\0\0\0\0\0\0\u{3}\0\0\0}\0-*\0]\0\0\0\0\0\0\u{1}\0]\0\0-*\0]\0\0\0\0\0\0\u{1}\0]\0\0-*\0]\0\0\0\0\0\u{1}\0]\0\0-*\0]\0\0\0\0\0\0\0\u{1}\0]\0\u{1}\u{1}H-i]-]\0\0\0\0\u{1}\0]\0\0\0\u{1}\0]\0\0-*\0\0\0\0\u{1}9-\u{7f}]\0'|-\u{7f}]\0'|(?i-ux)[-\u{7f}]\0'\u{3}\0\0\0}\0-*\0]<D\0\0\0\0\0\0\u{1}]\0\0\0\0]\0\0-*\0]\0\0 "eq(
      leti_ =(tspat ;t  tshouldn'tipanic Test  }
                                                                                                                                                                                                                                                       