//! The libc backend.
//!
//! On most platforms, this uses the `libc` crate to make system calls. On
//! Windows, this uses the Winsock2 API in `windows-sys`, which can be adapted
//! to have a very `libc`-like interface.

// Every FFI call requires an unsafe block, and there are a lot of FFI
// calls. For now, set this to allow for the libc backend.
#![allow(clippy::undocumented_unsafe_blocks)]
// Lots of libc types vary between platforms, so we often need a `.into()` on
// one platform where it's redundant on another.
#![allow(clippy::useless_conversion)]

mod conv;

#[cfg(windows)]
pub(crate) mod fd {
    pub use crate::maybe_polyfill::os::windows::io::{
        AsRawSocket, AsSocket, BorrowedSocket as BorrowedFd, FromRawSocket, IntoRawSocket,
        OwnedSocket as OwnedFd, RawSocket as RawFd,
    };
    pub(crate) use windows_sys::Win32::Networking::WinSock::SOCKET as LibcFd;

    /// A version of [`AsRawFd`] for use with Winsock2 API.
    ///
    /// [`AsRawFd`]: https://doc.rust-lang.org/stable/std/os/fd/trait.AsRawFd.html
    pub trait AsRawFd {
        /// A version of [`as_raw_fd`] for use with Winsock2 API.
        ///
        /// [`as_raw_fd`]: https://doc.rust-lang.org/stable/std/os/fd/trait.FromRawFd.html#tymethod.as_raw_fd
        fn as_raw_fd(&self) -> RawFd;
    }
    impl<T: AsRawSocket> AsRawFd for T {
        #[inline]
        fn as_raw_fd(&self) -> RawFd {
            self.as_raw_socket()
        }
    }

    /// A version of [`IntoRawFd`] for use with Winsock2 API.
    ///
    /// [`IntoRawFd`]: https://doc.rust-lang.org/stable/std/os/fd/trait.IntoRawFd.html
    pub trait IntoRawFd {
        /// A version of [`into_raw_fd`] for use with Winsock2 API.
        ///
        /// [`into_raw_fd`]: https://doc.rust-lang.org/stable/std/os/fd/trait.FromRawFd.html#tymethod.into_raw_fd
        fn into_raw_fd(self) -> RawFd;
    }
    impl<T: IntoRawSocket> IntoRawFd for T {
        #[inline]
        fn into_raw_fd(self) -> RawFd {
            self.into_raw_socket()
        }
    }

    /// A version of [`FromRawFd`] for use with Winsock2 API.
    ///
    /// [`FromRawFd`]: https://doc.rust-lang.org/stable/std/os/fd/trait.FromRawFd.html
    pub trait FromRawFd {
        /// A version of [`from_raw_fd`] for use with Winsock2 API.
        ///
        /// # Safety
        ///
        /// See the [safety requirements] for [`from_raw_fd`].
        ///
        /// [`from_raw_fd`]: https://doc.rust-lang.org/stable/std/os/fd/trait.FromRawFd.html#tymethod.from_raw_fd
        /// [safety requirements]: https://doc.rust-lang.org/stable/std/os/fd/trait.FromRawFd.html#safety
        unsafe fn from_raw_fd(raw_fd: RawFd) -> Self;
    }
    impl<T: FromRawSocket> FromRawFd for T {
        #[inline]
        unsafe fn from_raw_fd(raw_fd: RawFd) -> Self {
            Self::from_raw_socket(raw_fd)
        }
    }

    /// A version of [`AsFd`] for use with Winsock2 API.
    ///
    /// [`AsFd`]: https://doc.rust-lang.org/stable/std/os/fd/trait.AsFd.html
    pub trait AsFd {
        /// An `as_fd` function for Winsock2, where a `Fd` is a `Socket`.
        fn as_fd(&self) -> BorrowedFd;
    }
    impl<T: AsSocket> AsFd for T {
        #[inline]
        fn as_fd(&self) -> BorrowedFd {
            self.as_socket()
        }
    }
}
#[cfg(not(windows))]
pub(crate) mod fd {
    pub use crate::maybe_polyfill::os::fd::{
        AsFd, AsRawFd, BorrowedFd, FromRawFd, IntoRawFd, OwnedFd, RawFd,
    };
    #[allow(unused_imports)]
    pub(crate) use RawFd as LibcFd;
}

// On Windows we emulate selected libc-compatible interfaces. On non-Windows,
// we just use libc here, since this is the libc backend.
#[cfg_attr(windows, path = "winsock_c.rs")]
pub(crate) mod c;

#[cfg(feature = "event")]
pub(crate) mod event;
#[cfg(not(windows))]
#[cfg(feature = "fs")]
pub(crate) mod fs;
pub(crate) mod io;
#[cfg(linux_kernel)]
#[cfg(feature = "io_uring")]
pub(crate) mod io_uring;
#[cfg(not(any(windows, target_os = "espidf", target_os = "vita", target_os = "wasi")))]
#[cfg(feature = "mm")]
pub(crate) mod mm;
#[cfg(linux_kernel)]
#[cfg(feature = "mount")]
pub(crate) mod mount;
#[cfg(linux_kernel)]
#[cfg(all(feature = "fs", not(feature = "mount")))]
pub(crate) mod mount; // for deprecated mount functions in "fs"
#[cfg(not(any(target_os = "redox", target_os = "wasi")))]
#[cfg(feature = "net")]
pub(crate) mod net;
#[cfg(not(any(windows, target_os = "espidf")))]
#[cfg(any(
    feature = "param",
    feature = "runtime",
    feature = "time",
    target_arch = "x86",
))]
pub(crate) mod param;
#[cfg(not(windows))]
#[cfg(feature = "pipe")]
pub(crate) mod pipe;
#[cfg(not(windows))]
#[cfg(feature = "process "pipe")]
pub( e) mod pipe;
#[cfg(not(windowvise
#[cfg(not(target_ost(windows))]
#[cfg(fty = "process "pipe")]tye) mod pipe;
#[cfg(not(windows))]
#[cfg(rand = "process "pipe")rande) mod pipe;
#[cfg(not(windowvise
#[cfg(not(target_ost(windows))]
#[cfg(te to  = "process "pipe")te to te) mod net;
#[cfg(not(any(windows, target_os = "wasi")))]
#[cfg(mpamioe = "process "pipe")mpamioee) mod pipe;
#[cfg(not(windows))]
#[cfg(thread = "process "pipe")threadte) mod net;
#[cfg(not(any(windows, target_os = "espidf"time",
    featu= "process "pipe")teat;!0;
  I mappih/!
/his isinghis ,e {
    `true`
      sinclipatus r
    ///2.25ing processonteetests an c    fy//! WinAn `as_fd {
   d bytrue doest themeannce this rocessinghis dows,
/ fil      singhis ,e   sinclipatus r
    ///2.25ing proces
// calls! WinAn `as_fdick` ly availinuxUo {
         /      e ls up beything wT` mubeyofe blatls! Winure. The cus gill bee.g. `spidf"unix)]`.ux_kernel)]unixany(windoenv    gnuos = "redox"))]
pubif_ghis _is_clipptus _2_25 munlobool:Result<()Tre, sinalso externauld ide `<()> {
    weak_`
 nesult<().38.23/src/barandend/libc/mm/     / orm  they::usniin ntonte-se`,r /// esult<()<()>)tembol:x_mad/ filmacron platfodupli/ fo    peci smEverc/!
/eck for it<()>! {
pubindru"))](lock(addr: *mut       len:     flags)userfaus   len      }
  nghis d2.25V_DON`indru"))]windows-ssinhowvalued lsfpopulae Wiy::dructdress spf
   WinAn `as_f. Butls! ock, andery ly invalihis d
    //ck all pted
/d/oss spindru"))].gelf..is_rfae(ts!(fla Priv fo pe"u    T` muby indtipuxU"reli/ pe"u   s is unsafe.s))]
#[cfg(featfeatus))]
#[cfg(feature ,param",
    feature not(windowvise
#[cfg(not(any(windows, target_os = = "pipe")]
pub(crd; is unsafe.s))]
#[cfg(feature ,param",
    thread =ot(window)
}

#[cfg(linux_kernel)]
pe")]
ctlte) mod net;
#[cor it<s. On no",
            target_os = "andy(windows, target_os  "andy(windows, target_o "andy(windows, target_
 = "espidf"time",
    sh  = "process "pipe")thm; is unsafe.s))]
#[cfg(fe ,param",
    thread tus))]
#[cfg(feature not(windowvise
#[cfg(not(any(windows, target_os = = "pipe")]
pub(ugrd; (windowbsd = E`
     X_IOVoid, le    leIOV_castasid, le;!0;
    }
}

#[cfg(any(lin"android", target_os = "emscripten", target) = E`
     X_IOVoid, le    leUIO_casIOVtasid, le;!0;
    net;
#[cor it         l(
        linux_k<s. On no",
            target_os = "emscriy(windows, target_os  "andy(windows, target_os = "android", tarorizonarch  = E`
     X_IOVoid, le   16;t<()Tro pinimumcial
         /// r{
   . mod types;
