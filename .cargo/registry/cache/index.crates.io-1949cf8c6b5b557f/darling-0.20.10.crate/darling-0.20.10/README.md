# Darling

[![Build Status](https://github.com/TedDriggs/darling/workflows/CI/badge.svg)](https://github.com/TedDriggs/darling/actions)
[![Latest Version](https://img.shields.io/crates/v/darling.svg)](https://crates.io/crates/darling)
![Rustc Version 1.56+](https://img.shields.io/badge/rustc-1.56+-lightgray.svg)

`darling` is a crate for proc macro authors, which enables parsing attributes into structs. It is heavily inspired by `serde` both in its internals and in its API.

# Benefits

-   Easy and declarative parsing of macro input - make your proc-macros highly controllable with minimal time investment.
-   Great validation and errors, no work required. When users of your proc-macro make a mistake, `darling` makes sure they get error markers at the right place in their source, and provides "did you mean" suggestions for misspelled fields.

# Usage

`darling` provides a set of traits which can be derived or manually implemented.

1. `FromMeta` is used to extract values from a meta-item in an attribute. Implementations are likely reusable for many libraries, much like `FromStr` or `serde::Deserialize`. Trait implementations are provided for primitives, some std types, and some `syn` types.
2. `FromDeriveInput` is implemented or derived by each proc-macro crate which depends on `darling`. This is the root for input parsing; it gets access to the identity, generics, and visibility of the target type, and can specify which attribute names should be parsed or forwarded from the input AST.
3. `FromField` is implemented or derived by each proc-macro crate which depends on `darling`. Structs deriving this trait will get access to the identity (if it exists), type, and visibility of the field.
4. `FromVariant` is implemented or derived by each proc-macro crate which depends on `darling`. Structs deriving this trait will get access to the identity and contents of the variant, which can be transformed the same as any other `darling` input.
5. `FromAttributes` is a lower-level version of the more-specific `FromDeriveInput`, `FromField`, and `FromVariant` traits. Structs deriving this trait get a meta-item extractor and error collection which works for any syntax element, including traits, trait items, and functions. This is useful for non-derive proc macros.

## Additional Modules

-   `darling::ast` provides generic types for representing the AST.
-   `darling::usage` provides traits and functions for determining where type parameters and lifetimes are used in a struct or enum.
-   `darling::util` provides helper types with special `FromMeta` implementations, such as `PathList`.

# Example

```rust,ignore
use darling::{FromDeriveInput, FromMeta};

#[derive(Default, FromMeta)]
#[darling(default)]
pub struct Lorem {
    #[darling(rename = "sit")]
    ipsum: bool,
    dolor: Option<String>,
}

#[derive(FromDeriveInput)]
#[darling(attributes(my_crate), forward_attrs(allow, doc, cfg))]
pub struct MyTraitOpts {
    ident: syn::Ident,
    attrs: Vec<syn::Attribute>,
    lorem: Lorem,
}
```

The above code will then be able to parse this input:

```rust,ignore
/// A doc comment which will be available in `MyTraitOpts::attrs`.
#[derive(MyTrait)]
#[my_crate(lorem(dolor = "Hello", sit))]
pub struct ConsumingType;
```

# Attribute Macros

Non-derive attribute macros are supported.
To parse arguments for attribute macros, derive `FromMeta` on the argument receiver type, then use `darling::ast::NestedMeta::parse_meta_list` to convert the arguments `TokenStream` to a `Vec<NestedMeta>`, then pass that to the derived `from_list` method on your argument receiver type.
This will produce a normal `darling::Result<T>` that can be used the same as a result from parsing a `DeriveInput`.

## Macro Code

```rust,ignore
use darling::{Error, FromMeta};
use darling::ast::NestedMeta;
use syn::ItemFn;
use proc_macro::TokenStream;

#[derive(Debug, FromMeta)]
struct MacroArgs {
    #[darling(default)]
    timeout_ms: Option<u16>,
    path: String,
}

#[proc_macro_attribute]
pub fn your_attr(args: TokenStream, input: TokenStream) -> TokenStream {
    let attr_args = match NestedMeta::parse_meta_list(args.into()) {
        Ok(v) => v,
        Err(e) => { TedDriggs/darling/actions)
[![Latest Version](https://imgude = ["ttp  let attput!(amat::Itese_macro_input!(argut!(ama rmFn;
u
//  let attps = match NesroArgs {
rom_list` t(&r_args = 
        Ok(v) => v,
        Err(e) => { TedDriggs/darling/actions)
[eon](https://imgude = ["ttp = ["tA ddhe ds andh `syns = `= ["tunlemented or!()```

TheMacsumingTypde

```rust,ignore
use darr_attte(lo::r_attr(ar#[derr_attr(argh = "macho", siteout_ms: O"ma15   youdo_stuff(
       mitntln!(llo", s
//``

TheM Fures]
d

ling

['sature flre supld =t work witho",r readinorld usac_mt tos.   `da**ault, Fs**:pport prsruct Co-d funcd`, vel verault)]
derug the same atth = "tax ele`Patde` bo.     itional Molgention<T>` and `Flaling::util::Spag` fields [#1 is
fne rereuions}`al;u meadt addd fordeal
ratie[darling(default)]` on  the oo
- Addda**ld`, name m(de**:plds::in be e a `ferent (anes shoinage in vThi sambing type wi Addda**Auto-poptor`fields.

**:ppcts deriving thiomDeriveInput` is  `FromVarld` is  be l
ratie[perty p or ed `front: s`Froibi`Froty`Frors`.
#nd `Froerics` magtotomatically @ge a mies of the Sofch Ne thiues from a m input AST.
3.iomDeriveInput` is  tional Molgpecto
-sata` to sta access to the idey [#1the Sofiving this, and visomVariant` traecto
-satlds` to.     ddda**Tsformed on of enuwarded froributes(my**:pYmea be a`#[darling(word `s=h =  on the `synrs`.
#eld to inv darastom derctions f the sformed e follorded froributes(myfore `pry ge'provided forther arguct Co.e MSRctions f sorere flaisatln(<Nesribute>,
 > Tokling::Result<T>` th,ere typ`T` the rooe par mead
ratiedr the orinrs`.
#eld to.namning mularrors [om a m ifiletions f l producate `syh all verer `dasing a `ps://i Addda**Ming theetions f**:p `synarling(wormap="h = " on `#[darling(def_then` t="h = " on struify whiarctions f t reliuns the argult froenusing a `Dea-item extld to.ns wil be nge [#1 arguliggs/s, andch enables par meaparse thiso issurnal `fi for prmd content the ato the dere par mead foriner arguct Co.Addda**Skipelds.

**:p `synarling(worpped on strkersfield exp ato uld be addbeadingom a meibute macr-item exi Addda**Miple er-urrences oelds.

**:p `synarling(wortiple er on `OpVec<Ne#eld to invow, dp ato ld to invoppearltiple times forthe Sofr-item ex. E prourrences oel be avapud to o str orin<Ne#.Addda**S foress to**:p `synling::util::SpannedValue` so a struct or sta access to the imost (Apm ex'surce, ade wilns t.ns wil be used the oit codnings and imospoo s thea cific `Frld to m a mr proc-macros, . Gen tional ,r mea be  `darling::ast![Latesn](https://iagtotomatically @ge a mcise errors bremion Warails)

 more compasei Addda**"Dyou mean" suggestions fo**:pCile errors whem a mived `frling to 2t impls [#3lude progestions for misspelled fields.

# ddda**Sct for lemptn(de**:p `synarling(wor lemptn on strrve useone el versyn.ct fo flan dersenting ther prot (Apm ex inv da/i plds::int acceret intwn fiestr orise  (anuct or l be avalorded frostr orin lemptn#eld to.heMacpeSet Vdation an

S `syc-macros higy usek witotruct fowhich errer `dsad form.
-hich attiants are auteir `daunlr enunewe pariants. [#
ling

[kes surs softwrroenuidation andractnteset
lemen.
Ohe argulver type did ves.
"romDeriveInput`, `Fra`#[darling(worported...))]` wit this eitershe sugges [#1e didr proto Coduld be epts `.he| N atttttttttttttt| Dription = """""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""|e| ---------------- | -------------------------------------------------------------------------"|e| `any`tttttttttttt| ept unqany ds a"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""|e| `uct fo_any`ttttt| ept unqanynuct or """"""""""""""""""""""""""""""""""""""""""""""""""""""""|e| `uct fo_ed `f`ttt| ept unqucts when alled `frlds.

, ., c `uct foample

`Tedlds.
tring,
} }`"|e| `uct fo_eewe pa`t| ept unqnewe paruct fowhi., c `uct foample

`(ing,
})`"""""""""""""""""""""|e| `uct fo_tup frott| ept unqtup fruct fowhi., c `uct foample

`(ing,
}, ing,
})`"""""""""""""""|e| `uct fo_unlr`tttt| ept unqunlr uct fowhi., c `uct foample

`;`"""""""""""""""""""""""""""""""|e| `m.
-_any`ttttttt| ept unqanynm and""""""""""""""""""""""""""""""""""""""""""""""""""""""""""|e| `m.
-_ed `f`ttttt| ept unqe variants aren alled `frlds.

""""""""""""""""""""""""""""""""""""|e| `m.
-_eewe pa`t t| ept unqnewe pare variants are"""""""""""""""""""""""""""""""""""""""""""""|e| `m.
-_tup frotttt| ept unqtup fre variants are"""""""""""""""""""""""""""""""""""""""""""""""|e| `m.
-_unlr`tttttt| ept unqunlr e variants are""""""""""""""""""""""""""""""""""""""""""""""""|e
E prouns autotionavsublotersh thioarling(worported...uct fo_any, m.
-_eewe pa` withd be epts `l veructs and varanynm andre typey difiants a a lownewe pariants. THE  wil be o rewused then deriving `FromVariant` [#,thout lim orinm.
-_roviefi