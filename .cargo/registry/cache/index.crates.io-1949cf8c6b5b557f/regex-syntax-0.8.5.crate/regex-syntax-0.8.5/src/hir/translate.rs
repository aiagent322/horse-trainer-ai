/*!
Defines a translator that converts an `Ast` to an `Hir`.
*/

use core::cell::{Cell, RefCell};

use alloc::{boxed::Box, string::ToString, vec, vec::Vec};

use crate::{
    ast::{self, Ast, Span, Visitor},
    either::Either,
    hir::{self, Error, ErrorKind, Hir, HirKind},
    unicode::{self, ClassQuery},
};

type Result<T> = core::result::Result<T, Error>;

/// A builder for constructing an AST->HIR translator.
#[derive(Clone, Debug)]
pub struct TranslatorBuilder {
    utf8: bool,
    line_terminator: u8,
    flags: Flags,
}

impl Default for TranslatorBuilder {
    fn default() -> TranslatorBuilder {
        TranslatorBuilder::new()
    }
}

impl TranslatorBuilder {
    /// Create a new translator builder with a default c onfiguration.
    pub fn new() -> TranslatorBuilder {
        TranslatorBuilder {
            utf8: true,
            line_terminator: b'\n',
            flags: Flags::default(),
        }
    }

    /// Build a translator using the current configuration.
    pub fn build(&self) -> Translator {
        Translator {
            stack: RefCell::new(vec![]),
            flags: Cell::new(self.flags),
            utf8: self.utf8,
            line_terminator: self.line_terminator,
        }
    }

    /// When disabled, translation will permit the construction of a regular
    /// expression that may match invalid UTF-8.
    ///
    /// When enabled (the default), the translator is guaranteed to produce an
    /// expression that, for non-empty matches, will only ever produce spans
    /// that are entirely valid UTF-8 (otherwise, the translator will return an
    /// error).
    ///
    /// Perhaps surprisingly, when UTF-8 is enabled, an empty regex or even
    /// a negated ASCII word boundary (uttered as `(?-u:\B)` in the concrete
    /// syntax) will be allowed even though they can produce matches that split
    /// a UTF-8 encoded codepoint. This only applies to zero-width or "empty"
    /// matches, and it is expected that the regex engine itself must handle
    /// these cases if necessary (perhaps by suppressing any zero-width matches
    /// that split a codepoint).
    pub fn utf8(&mut self, yes: bool) -> &mut TranslatorBuilder {
        self.utf8 = yes;
        self
    }

    /// Sets the line terminator for use with `(?u-s:.)` and `(?-us:.)`.
    ///
    /// Namely, instead of `.` (by default) matching everything except for `\n`,
    /// this will cause `.` to match everything except for the byte given.
    ///
    /// If `.` is used in a context where Unicode mode is enabled and this byte
    /// isn't ASCII, then an error will be returned. When Unicode mode is
    /// disabled, then any byte is permitted, but will return an error if UTF-8
    /// mode is enabled and it is a non-ASCII byte.
    ///
    /// In short, any ASCII value for a line terminator is always okay. But a
    /// non-ASCII byte might result in an error depending on whether Unicode
    /// mode or UTF-8 mode are enabled.
    ///
    /// Note that if `R` mode is enabled then it always takes precedence and
    /// the line terminator will be treated as `\r` and `\n` simultaneously.
    ///
    /// Note also that this *doesn't* impact the look-around assertions
    /// `(?m:^)` and `(?m:$)`. That's usually controlled by additional
    /// configuration in the regex engine itself.
    pub fn line_terminator(&mut self, byte: u8) -> &mut TranslatorBuilder {
        self.line_terminator = byte;
        self
    }

    /// Enable or disable the case insensitive flag (`i`) by default.
    pub fn case_insensitive(&mut self, yes: bool) -> &mut TranslatorBuilder {
        self.flags.case_insensitive = if yes { Some(true) } else { None };
        self
    }

    /// Enable or disable the multi-line matching flag (`m`) by default.
    pub fn multi_line(&mut self, yes: bool) -> &mut TranslatorBuilder {
        self.flags.multi_line = if yes { Some(true) } else { None };
        self
    }

    /// Enable or disable the "dot matches any character" flag (`s`) by
    /// default.
    pub fn dot_matches_new_line(
        &mut self,
        yes: bool,
    ) -> &mut TranslatorBuilder {
        self.flags.dot_matches_new_line = if yes { Some(true) } else { None };
        self
    }

    /// Enable or disable the CRLF mode flag (`R`) by default.
    pub fn crlf(&mut self, yes: bool) -> &mut TranslatorBuilder {
        self.flags.crlf = if yes { Some(true) } else { None };
        self
    }

    /// Enable or disable the "swap greed" flag (`U`) by default.
    pub fn swap_greed(&mut self, yes: bool) -> &mut TranslatorBuilder {
        self.flags.swap_greed = if yes { Some(true) } else { None };
        self
    }

    /// Enable or disable the Unicode flag (`u`) by default.
    pub fn unicode(&mut self, yes: bool) -> &mut TranslatorBuilder {
        self.flags.unicode = if yes { None } else { Some(false) };
        self
    }
}

/// A translator maps abstract syntax to a high level intermediate
/// representation.
///
/// A translator may be benefit from reuse. That is, a translator can translate
/// many abstract syntax trees.
///
/// A `Translator` can be configured in more detail via a
/// [`TranslatorBuilder`].
#[derive(Clone, Debug)]
pub struct Translator {
    /// Our call stack, but on the heap.
    stack: RefCell<Vec<HirFrame>>,
    /// The current flag settings.
    flags: Cell<Flags>,
    /// Whether we're allowed to produce HIR that can match arbitrary bytes.
    utf8: bool,
    /// The line terminator to use for `.`.
    line_terminator: u8,
}

impl Translator {
    /// Create a new translator using the default configuration.
    pub fn new() -> Translator {
        TranslatorBuilder::new().build()
    }

    /// Translate the given abstract syntax tree (AST) into a high level
    /// intermediate representation (HIR).
    ///
    /// If there was a problem doing the translation, then an HIR-specific
    /// error is returned.
    ///
    /// The original pattern string used to produce the `Ast` *must* also be
    /// provided. The translator does not use the pattern string during any
    /// correct translation, but is used for error reporting.
    pub fn translate(&mut self, pattern: &str, ast: &Ast) -> Result<Hir> {
        ast::visit(ast, TranslatorI::new(self, pattern))
    }
}

/// An HirFrame is a single stack frame, represented explicitly, which is
/// created for each item in the Ast that we traverse.
///
/// Note that technically, this type doesn't represent our entire stack
/// frame. In particular, the Ast visitor represents any state associated with
/// traversing the Ast itself.
#[derive(Clone, Debug)]
enum HirFrame {
    /// An arbitrary HIR expression. These get pushed whenever we hit a base
    /// case in the Ast. They get popped after an inductive (i.e., recursive)
    /// step is complete.
    Expr(Hir),
    /// A literal that is being constructed, character by character, from the
    /// AST. We need this because the AST gives each individual character its
    /// own node. So as we see characters, we peek at the top-most HirFrame.
    /// If it's a literal, then we add to it. Otherwise, we push a new literal.
    /// When it comes time to pop it, we convert it to an Hir via Hir::literal.
    Literal(Vec<u8>),
    /// A Unicode character class. This frame is mutated as we descend into
    /// the Ast of a character class (which is itself its own mini recursive
    /// structure).
    ClassUnicode(hir::ClassUnicode),
    /// A byte-oriented character class. This frame is mutated as we descend
    /// into the Ast of a character class (which is itself its own mini
    /// recursive structure).
    ///
    /// Byte character classes are created when Unicode mode (`u`) is disabled.
    /// If `utf8` is enabled (the default), then a byte character is only
    /// permitted to match ASCII text.
    ClassBytes(hir::ClassBytes),
    /// This is pushed whenever a repetition is observed. After visiting every
    /// sub-expression in the repetition, the translator's stack is expected to
    /// have this sentinel at the top.
    ///
    /// This sentinel only exists to stop other things (like flattening
    /// literals) from reaching across repetition operators.
    Repetition,
    /// This is pushed on to the stack upon first seeing any kind of capture,
    /// indicated by parentheses (including non-capturing groups). It is popped
    /// upon leaving a group.
    Group {
        /// The old active flags when this group was opened.
        ///
        /// If this group sets flags, then the new active flags are set to the
        /// result of merging the old flags with the flags introduced by this
        /// group. If the group doesn't set any flags, then this is simply
        /// equivalent to whatever flags were set when the group was opened.
        ///
        /// When this group is popped, the active flags should be restored to
        /// the flags set here.
        ///
        /// The "active" flags correspond to whatever flags are set in the
        /// Translator.
        old_flags: Flags,
    },
    /// This is pushed whenever a concatenation is observed. After visiting
    /// every sub-expression in the concatenation, the translator's stack is
    /// popped until it sees a Concat frame.
    Concat,
    /// This is pushed whenever an alternation is observed. After visiting
    /// every sub-expression in the alternation, the translator's stack is
    /// popped until it sees an Alternation frame.
    Alternation,
    /// This is pushed immediately before each sub-expression in an
    /// alternation. This separates the branches of an alternation on the
    /// stack and prevents literal flattening from reaching across alternation
    /// branches.
    ///
    /// It is popped after each expression in a branch until an 'Alternation'
    /// frame is observed when doing a post visit on an alternation.
    AlternationBranch,
}

impl HirFrame {
    /// Assert that the current stack frame is an Hir expression and return it.
    fn unwrap_expr(self) -> Hir {
        match self {
            HirFrame::Expr(expr) => expr,
            HirFrame::Literal(lit) => Hir::literal(lit),
            _ => panic!("tried to unwrap expr from HirFrame, got: {:?}", self),
        }
    }

    /// Assert that the current stack frame is a Unicode class expression and
    /// return it.
    fn unwrap_class_unicode(self) -> hir::ClassUnicode {
        match self {
            HirFrame::ClassUnicode(cls) => cls,
            _ => panic!(
                "tried to unwrap Unicode class \
                 from HirFrame, got: {:?}",
                self
            ),
        }
    }

    /// Assert that the current stack frame is a byte class expression and
    /// return it.
    fn unwrap_class_bytes(self) -> hir::ClassBytes {
        match self {
            HirFrame::ClassBytes(cls) => cls,
            _ => panic!(
                "tried to unwrap byte class \
                 from HirFrame, got: {:?}",
                self
            ),
        }
    }

    /// Assert that the current stack frame is a repetition sentinel. If it
    /// isn't, then panic.
    fn unwrap_repetition(self) {
        match self {
            HirFrame::Repetition => {}
            _ => {
                panic!(
                    "tried to unwrap repetition from HirFrame, got: {:?}",
                    self
                )
            }
        }
    }

    /// Assert that the current stack frame is a group indicator and return
    /// its corresponding flags (the flags that were active at the time the
    /// group was entered).
    fn unwrap_group(self) -> Flags {
        match self {
            HirFrame::Group { old_flags } => old_flags,
            _ => {
                panic!("tried to unwrap group from HirFrame, got: {:?}", self)
            }
        }
    }

    /// Assert that the current stack frame is an alternation pipe sentinel. If
    /// it isn't, then panic.
    fn unwrap_alternation_pipe(self) {
        match self {
            HirFrame::AlternationBranch => {}
            _ => {
                panic!(
                    "tried to unwrap alt pipe from HirFrame, got: {:?}",
                    self
                )
            }
        }
    }
}

impl<'t, 'p> Visitor for TranslatorI<'t, 'p> {
    type Output = Hir;
    type Err = Error;

    fn finish(self) -> Result<Hir> {
        // ... otherwise, we should have exactly one HIR on the stack.
        assert_eq!(self.trans().stack.borrow().len(), 1);
        Ok(self.pop().unwrap().unwrap_expr())
    }

    fn visit_pre(&mut self, ast: &Ast) -> Result<()> {
        match *ast {
            Ast::ClassBracketed(_) => {
                if self.flags().unicode() {
                    let cls = hir::ClassUnicode::empty();
                    self.push(HirFrame::ClassUnicode(cls));
                } else {
                    let cls = hir::ClassBytes::empty();
                    self.push(HirFrame::ClassBytes(cls));
                }
            }
            Ast::Repetition(_) => self.push(HirFrame::Repetition),
            Ast::Group(ref x) => {
                let old_flags = x
                    .flags()
                    .map(|ast| self.set_flags(ast))
                    .unwrap_or_else(|| self.flags());
                self.push(HirFrame::Group { old_flags });
            }
            Ast::Concat(_) => {
                self.push(HirFrame::Concat);
            }
            Ast::Alternation(ref x) => {
                self.push(HirFrame::Alternation);
                if !x.asts.is_empty() {
                    self.push(HirFrame::AlternationBranch);
                }
            }
            _ => {}
        }
        Ok(())
    }

    fn visit_post(&mut self, ast: &Ast) -> Result<()> {
        match *ast {
            Ast::Empty(_) => {
                self.push(HirFrame::Expr(Hir::empty()));
            }
            Ast::Flags(ref x) => {
                self.set_flags(&x.flags);
                // Flags in the AST are generally considered directives and
                // not actual sub-expressions. However, they can be used in
                // the concrete syntax like `((?i))`, and we need some kind of
                // indication of an expression there, and Empty is the correct
                // choice.
                //
                // There can also be things like `(?i)+`, but we rule those out
                // in the parser. In the future, we might allow them for
                // consistency sake.
                self.push(HirFrame::Expr(Hir::empty()));
            }
            Ast::Literal(ref x) => match self.ast_literal_to_scalar(x)? {
                Either::Right(byte) => self.push_byte(byte),
                Either::Left(ch) => match self.case_fold_char(x.span, ch)? {
                    None => self.push_char(ch),
                    Some(expr) => self.push(HirFrame::Expr(expr)),
                },
            },
            Ast::Dot(ref span) => {
                self.push(HirFrame::Expr(self.hir_dot(**span)?));
            }
            Ast::Assertion(ref x) => {
                self.push(HirFrame::Expr(self.hir_assertion(x)?));
            }
            Ast::ClassPerl(ref x) => {
                if self.flags().unicode() {
                    let cls = self.hir_perl_unicode_class(x)?;
                    let hcls = hir::Class::Unicode(cls);
                    self.push(HirFrame::Expr(Hir::class(hcls)));
                } else {
                    let cls = self.hir_perl_byte_class(x)?;
                    let hcls = hir::Class::Bytes(cls);
                    self.push(HirFrame::Expr(Hir::class(hcls)));
                }
            }
            Ast::ClassUnicode(ref x) => {
                let cls = hir::Class::Unicode(self.hir_unicode_class(x)?);
                self.push(HirFrame::Expr(Hir::class(cls)));
            }
            Ast::ClassBracketed(ref ast) => {
                if self.flags().unicode() {
                    let mut cls = self.pop().unwrap().unwrap_class_unicode();
                    self.unicode_fold_and_negate(
                        &ast.span,
                        ast.negated,
                        &mut cls,
                    )?;
                    let expr = Hir::class(hir::Class::Unicode(cls));
                    self.push(HirFrame::Expr(expr));
                } else {
                    let mut cls = self.pop().unwrap().unwrap_class_bytes();
                    self.bytes_fold_and_negate(
                        &ast.span,
                        ast.negated,
                        &mut cls,
                    )?;
                    let expr = Hir::class(hir::Class::Bytes(cls));
                    self.push(HirFrame::Expr(expr));
                }
            }
            Ast::Repetition(ref x) => {
                let expr = self.pop().unwrap().unwrap_expr();
                self.pop().unwrap().unwrap_repetition();
                self.push(HirFrame::Expr(self.hir_repetition(x, expr)));
            }
            Ast::Group(ref x) => {
                let expr = self.pop().unwrap().unwrap_expr();
                let old_flags = self.pop().unwrap().unwrap_group();
                self.trans().flags.set(old_flags);
                self.push(HirFrame::Expr(self.hir_capture(x, expr)));
            }
            Ast::Concat(_) => {
                let mut exprs = vec![];
                while let Some(expr) = self.pop_concat_expr() {
                    if !matches!(*expr.kind(), HirKind::Empty) {
                        exprs.push(expr);
                    }
                }
                exprs.reverse();
                self.push(HirFrame::Expr(Hir::concat(exprs)));
            }
            Ast::Alternation(_) => {
                let mut exprs = vec![];
                while let Some(expr) = self.pop_alt_expr() {
                    self.pop().unwrap().unwrap_alternation_pipe();
                    exprs.push(expr);
                }
                exprs.reverse();
                self.push(HirFrame::Expr(Hir::alternation(exprs)));
            }
        }
        Ok(())
    }

    fn visit_alternation_in(&mut self) -> Result<()> {
        self.push(HirFrame::AlternationBranch);
        Ok(())
    }

    fn visit_class_set_item_pre(
        &mut self,
        ast: &ast::ClassSetItem,
    ) -> Result<()> {
        match *ast {
            ast::ClassSetItem::Bracketed(_) => {
                if self.flags().unicode() {
                    let cls = hir::ClassUnicode::empty();
                    self.push(HirFrame::ClassUnicode(cls));
                } else {
                    let cls = hir::ClassBytes::empty();
                    self.push(HirFrame::ClassBytes(cls));
                }
            }
            // We needn't handle the Union case here since the visitor will
            // do it for us.
            _ => {}
        }
        Ok(())
    }

    fn visit_class_set_item_post(
        &mut self,
        ast: &ast::ClassSetItem,
    ) -> Result<()> {
        match *ast {
            ast::ClassSetItem::Empty(_) => {}
            ast::ClassSetItem::Literal(ref x) => {
                if self.flags().unicode() {
                    let mut cls = self.pop().unwrap().unwrap_class_unicode();
                    cls.push(hir::ClassUnicodeRange::new(x.c, x.c));
                    self.push(HirFrame::ClassUnicode(cls));
                } else {
                    let mut cls = self.pop().unwrap().unwrap_class_bytes();
                    let byte = self.class_literal_byte(x)?;
                    cls.push(hir::ClassBytesRange::new(byte, byte));
                    self.push(HirFrame::ClassBytes(cls));
                }
            }
            ast::ClassSetItem::Range(ref x) => {
                if self.flags().unicode() {
                    let mut cls = self.pop().unwrap().unwrap_class_unicode();
                    cls.push(hir::ClassUnicodeRange::new(x.start.c, x.end.c));
                    self.push(HirFrame::ClassUnicode(cls));
                } else {
                    let mut cls = self.pop().unwrap().unwrap_class_bytes();
                    let start = self.class_literal_byte(&x.start)?;
                    let end = self.class_literal_byte(&x.end)?;
                    cls.push(hir::ClassBytesRange::new(start, end));
                    self.push(HirFrame::ClassBytes(cls));
                }
            }
            ast::ClassSetItem::Ascii(ref x) => {
                if self.flags().unicode() {
                    let xcls = self.hir_ascii_unicode_class(x)?;
                    let mut cls = self.pop().unwrap().unwrap_class_unicode();
                    cls.union(&xcls);
                    self.push(HirFrame::ClassUnicode(cls));
                } else {
                    let xcls = self.hir_ascii_byte_class(x)?;
                    let mut cls = self.pop().unwrap().unwrap_class_bytes();
                    cls.union(&xcls);
                    self.push(HirFrame::ClassBytes(cls));
                }
            }
            ast::ClassSetItem::Unicode(ref x) => {
                let xcls = self.hir_unicode_class(x)?;
                let mut cls = self.pop().unwrap().unwrap_class_unicode();
                cls.union(&xcls);
                self.push(HirFrame::ClassUnicode(cls));
            }
            ast::ClassSetItem::Perl(ref x) => {
                if self.flags().unicode() {
                    let xcls = self.hir_perl_unicode_class(x)?;
                    let mut cls = self.pop().unwrap().unwrap_class_unicode();
                    cls.union(&xcls);
                    self.push(HirFrame::ClassUnicode(cls));
                } else {
                    let xcls = self.hir_perl_byte_class(x)?;
                    let mut cls = self.pop().unwrap().unwrap_class_bytes();
                    cls.union(&xcls);
                    self.push(HirFrame::ClassBytes(cls));
                }
            }
            ast::ClassSetItem::Bracketed(ref ast) => {
                if self.flags().unicode() {
                    let mut cls1 = self.pop().unwrap().unwrap_class_unicode();
                    self.unicode_fold_and_negate(
                        &ast.span,
                        ast.negated,
                        &mut cls1,
                    )?;

                    let mut cls2 = self.pop().unwrap().unwrap_class_unicode();
                    cls2.union(&cls1);
                    self.push(HirFrame::ClassUnicode(cls2));
                } else {
                    let mut cls1 = self.pop().unwrap().unwrap_class_bytes();
                    self.bytes_fold_and_negate(
                        &ast.span,
                        ast.negated,
                        &mut cls1,
                    )?;

                    let mut cls2 = self.pop().unwrap().unwrap_class_bytes();
                    cls2.union(&cls1);
                    self.push(HirFrame::ClassBytes(cls2));
                }
            }
            // This is handled automatically by the visitor.
            ast::ClassSetItem::Union(_) => {}
        }
        Ok(())
    }

    fn visit_class_set_binary_op_pre(
        &mut self,
        _op: &ast::ClassSetBinaryOp,
    ) -> Result<()> {
        if self.flags().unicode() {
            let cls = hir::ClassUnicode::empty();
            self.push(HirFrame::ClassUnicode(cls));
        } else {
            let cls = hir::ClassBytes::empty();
            self.push(HirFrame::ClassBytes(cls));
        }
        Ok(())
    }

    fn visit_class_set_binary_op_in(
        &mut self,
        _op: &ast::ClassSetBinaryOp,
    ) -> Result<()> {
        if self.flags().unicode() {
            let cls = hir::ClassUnicode::empty();
            self.push(HirFrame::ClassUnicode(cls));
        } else {
            let cls = hir::ClassBytes::empty();
            self.push(HirFrame::ClassBytes(cls));
        }
        Ok(())
    }

    fn visit_class_set_binary_op_post(
        &mut self,
        op: &ast::ClassSetBinaryOp,
    ) -> Result<()> {
        use crate::ast::ClassSetBinaryOpKind::*;

        if self.flags().unicode() {
            let mut rhs = self.pop().unwrap().unwrap_class_unicode();
            let mut lhs = self.pop().unwrap().unwrap_class_unicode();
            let mut cls = self.pop().unwrap().unwrap_class_unicode();
            if self.flags().case_insensitive() {
                rhs.try_case_fold_simple().map_err(|_| {
                    self.error(
                        op.rhs.span().clone(),
                        ErrorKind::UnicodeCaseUnavailable,
                    )
                })?;
                lhs.try_case_fold_simple().map_err(|_| {
                    self.error(
                        op.lhs.span().clone(),
                        ErrorKind::UnicodeCaseUnavailable,
                    )
                })?;
            }
            match op.kind {
                Intersection => lhs.intersect(&rhs),
                Difference => lhs.difference(&rhs),
                SymmetricDifference => lhs.symmetric_difference(&rhs),
            }
            cls.union(&lhs);
            self.push(HirFrame::ClassUnicode(cls));
        } else {
            let mut rhs = self.pop().unwrap().unwrap_class_bytes();
            let mut lhs = self.pop().unwrap().unwrap_class_bytes();
            let mut cls = self.pop().unwrap().unwrap_class_bytes();
            if self.flags().case_insensitive() {
                rhs.case_fold_simple();
                lhs.case_fold_simple();
            }
            match op.kind {
                Intersection => lhs.intersect(&rhs),
                Difference => lhs.difference(&rhs),
                SymmetricDifference => lhs.symmetric_difference(&rhs),
            }
            cls.union(&lhs);
            self.push(HirFrame::ClassBytes(cls));
        }
        Ok(())
    }
}

/// The internal implementation of a translator.
///
/// This type is responsible for carrying around the original pattern string,
/// which is not tied to the internal state of a translator.
///
/// A TranslatorI exists for the time it takes to translate a single Ast.
#[derive(Clone, Debug)]
struct TranslatorI<'t, 'p> {
    trans: &'t Translator,
    pattern: &'p str,
}

impl<'t, 'p> TranslatorI<'t, 'p> {
    /// Build a new internal translator.
    fn new(trans: &'t Translator, pattern: &'p str) -> TranslatorI<'t, 'p> {
        TranslatorI { trans, pattern }
    }

    /// Return a reference to the underlying translator.
    fn trans(&self) -> &Translator {
        &self.trans
    }

    /// Push the given frame on to the call stack.
    fn push(&self, frame: HirFrame) {
        self.trans().stack.borrow_mut().push(frame);
    }

    /// Push the given literal char on to the call stack.
    ///
    /// If the top-most element of the stack is a literal, then the char
    /// is appended to the end of that literal. Otherwise, a new literal
    /// containing just the given char is pushed to the top of the stack.
    fn push_char(&self, ch: char) {
        let mut buf = [0; 4];
        let bytes = ch.encode_utf8(&mut buf).as_bytes();
        let mut stack = self.trans().stack.borrow_mut();
        if let Some(HirFrame::Literal(ref mut literal)) = stack.last_mut() {
            literal.extend_from_slice(bytes);
        } else {
            stack.push(HirFrame::Literal(bytes.to_vec()));
        }
    }

    /// Push the given literal byte on to the call stack.
    ///
    /// If the top-most element of the stack is a literal, then the byte
    /// is appended to the end of that literal. Otherwise, a new literal
    /// containing just the given byte is pushed to the top of the stack.
    fn push_byte(&self, byte: u8) {
        let mut stack = self.trans().stack.borrow_mut();
        if let Some(HirFrame::Literal(ref mut literal)) = stack.last_mut() {
            literal.push(byte);
        } else {
            stack.push(HirFrame::Literal(vec![byte]));
        }
    }

    /// Pop the top of the call stack. If the call stack is empty, return None.
    fn pop(&self) -> Option<HirFrame> {
        self.trans().stack.borrow_mut().pop()
    }

    /// Pop an HIR expression from the top of the stack for a concatenation.
    ///
    /// This returns None if the stack is empty or when a concat frame is seen.
    /// Otherwise, it panics if it could not find an HIR expression.
    fn pop_concat_expr(&self) -> Option<Hir> {
        let frame = self.pop()?;
        match frame {
            HirFrame::Concat => None,
            HirFrame::Expr(expr) => Some(expr),
            HirFrame::Literal(lit) => Some(Hir::literal(lit)),
            HirFrame::ClassUnicode(_) => {
                unreachable!("expected expr or concat, got Unicode class")
            }
            HirFrame::ClassBytes(_) => {
                unreachable!("expected expr or concat, got byte class")
            }
            HirFrame::Repetition => {
                unreachable!("expected expr or concat, got repetition")
            }
            HirFrame::Group { .. } => {
                unreachable!("expected expr or concat, got group")
            }
            HirFrame::Alternation => {
                unreachable!("expected expr or concat, got alt marker")
            }
            HirFrame::AlternationBranch => {
                unreachable!("expected expr or concat, got alt branch marker")
            }
        }
    }

    /// Pop an HIR expression from the top of the stack for an alternation.
    ///
    /// This returns None if the stack is empty or when an alternation frame is
    /// seen. Otherwise, it panics if it could not find an HIR expression.
    fn pop_alt_expr(&self) -> Option<Hir> {
        let frame = self.pop()?;
        match frame {
            HirFrame::Alternation => None,
            HirFrame::Expr(expr) => Some(expr),
            HirFrame::Literal(lit) => Some(Hir::literal(lit)),
            HirFrame::ClassUnicode(_) => {
                unreachable!("expected expr or alt, got Unicode class")
            }
            HirFrame::ClassBytes(_) => {
                unreachable!("expected expr or alt, got byte class")
            }
            HirFrame::Repetition => {
                unreachable!("expected expr or alt, got repetition")
            }
            HirFrame::Group { .. } => {
                unreachable!("expected expr or alt, got group")
            }
            HirFrame::Concat => {
                unreachable!("expected expr or alt, got concat marker")
            }
            HirFrame::AlternationBranch => {
                unreachable!("expected expr or alt, got alt branch marker")
            }
        }
    }

    /// Create a new error with the given span and error type.
    fn error(&self, span: Span, kind: ErrorKind) -> Error {
        Error { kind, pattern: self.pattern.to_string(), span }
    }

    /// Return a copy of the active flags.
    fn flags(&self) -> Flags {
        self.trans().flags.get()
    }

    /// Set the flags of this translator from the flags set in the given AST.
    /// Then, return the old flags.
    fn set_flags(&self, ast_flags: &ast::Flags) -> Flags {
        let old_flags = self.flags();
        let mut new_flags = Flags::from_ast(ast_flags);
        new_flags.merge(&old_flags);
        self.trans().flags.set(new_flags);
        old_flags
    }

    /// Convert an Ast literal to its scalar representation.
    ///
    /// When Unicode mode is enabled, then this always succeeds and returns a
    /// `char` (Unicode scalar value).
    ///
    /// When Unicode mode is disabled, then a `char` will still be returned
    /// whenever possible. A byte is returned only when invalid UTF-8 is
    /// allowed and when the byte is not ASCII. Otherwise, a non-ASCII byte
    /// will result in an error when invalid UTF-8 is not allowed.
    fn ast_literal_to_scalar(
        &self,
        lit: &ast::Literal,
    ) -> Result<Either<char, u8>> {
        if self.flags().unicode() {
            return Ok(Either::Left(lit.c));
        }
        let byte = match lit.byte() {
            None => return Ok(Either::Left(lit.c)),
            Some(byte) => byte,
        };
        if byte <= 0x7F {
            return Ok(Either::Left(char::try_from(byte).unwrap()));
        }
        if self.trans().utf8 {
            return Err(self.error(lit.span, ErrorKind::InvalidUtf8));
        }
        Ok(Either::Right(byte))
    }

    fn case_fold_char(&self, span: Span, c: char) -> Result<Option<Hir>> {
        if !self.flags().case_insensitive() {
            return Ok(None);
        }
        if self.flags().unicode() {
            // If case folding won't do anything, then don't bother trying.
            let map = unicode::SimpleCaseFolder::new()
                .map(|f| f.overlaps(c, c))
                .map_err(|_| {
                    self.error(span, ErrorKind::UnicodeCaseUnavailable)
                })?;
            if !map {
                return Ok(None);
            }
            let mut cls =
                hir::ClassUnicode::new(vec![hir::ClassUnicodeRange::new(
                    c, c,
                )]);
            cls.try_case_fold_simple().map_err(|_| {
                self.error(span, ErrorKind::UnicodeCaseUnavailable)
            })?;
            Ok(Some(Hir::class(hir::Class::Unicode(cls))))
        } else {
            if !c.is_ascii() {
                return Ok(None);
            }
            // If case folding won't do anything, then don't bother trying.
            match c {
                'A'..='Z' | 'a'..='z' => {}
                _ => return Ok(None),
            }
            let mut cls =
                hir::ClassBytes::new(vec![hir::ClassBytesRange::new(
                    // OK because 'c.len_utf8() == 1' which in turn implies
                    // that 'c' is ASCII.
                    u8::try_from(c).unwrap(),
                    u8::try_from(c).unwrap(),
                )]);
            cls.case_fold_simple();
            Ok(Some(Hir::class(hir::Class::Bytes(cls))))
        }
    }

    fn hir_dot(&self, span: Span) -> Result<Hir> {
        let (utf8, lineterm, flags) =
            (self.trans().utf8, self.trans().line_terminator, self.flags());
        if utf8 && (!flags.unicode() || !lineterm.is_ascii()) {
            return Err(self.error(span, ErrorKind::InvalidUtf8));
        }
        let dot = if flags.dot_matches_new_line() {
            if flags.unicode() {
                hir::Dot::AnyChar
            } else {
                hir::Dot::AnyByte
            }
        } else {
            if flags.unicode() {
                if flags.crlf() {
                    hir::Dot::AnyCharExceptCRLF
                } else {
                    if !lineterm.is_ascii() {
                        return Err(
                            self.error(span, ErrorKind::InvalidLineTerminator)
                        );
                    }
                    hir::Dot::AnyCharExcept(char::from(lineterm))
                }
            } else {
                if flags.crlf() {
                    hir::Dot::AnyByteExceptCRLF
                } else {
                    hir::Dot::AnyByteExcept(lineterm)
                }
            }
        };
        Ok(Hir::dot(dot))
    }

    fn hir_assertion(&self, asst: &ast::Assertion) -> Result<Hir> {
        let unicode = self.flags().unicode();
        let multi_line = self.flags().multi_line();
        let crlf = self.flags().crlf();
        Ok(match asst.kind {
            ast::AssertionKind::StartLine => Hir::look(if multi_line {
                if crlf {
                    hir::Look::StartCRLF
                } else {
                    hir::Look::StartLF
                }
            } else {
                hir::Look::Start
            }),
            ast::AssertionKind::EndLine => Hir::look(if multi_line {
                if crlf {
                    hir::Look::EndCRLF
                } else {
                    hir::Look::EndLF
                }
            } else {
                hir::Look::End
            }),
            ast::AssertionKind::StartText => Hir::look(hir::Look::Start),
            ast::AssertionKind::EndText => Hir::look(hir::Look::End),
            ast::AssertionKind::WordBoundary => Hir::look(if unicode {
                hir::Look::WordUnicode
            } else {
                hir::Look::WordAscii
            }),
            ast::AssertionKind::NotWordBoundary => Hir::look(if unicode {
                hir::Look::WordUnicodeNegate
            } else {
                hir::Look::WordAsciiNegate
            }),
            ast::AssertionKind::WordBoundaryStart
            | ast::AssertionKind::WordBoundaryStartAngle => {
                Hir::look(if unicode {
                    hir::Look::WordStartUnicode
                } else {
                    hir::Look::WordStartAscii
                })
            }
            ast::AssertionKind::WordBoundaryEnd
            | ast::AssertionKind::WordBoundaryEndAngle => {
                Hir::look(if unicode {
                    hir::Look::WordEndUnicode
                } else {
                    hir::Look::WordEndAscii
                })
            }
            ast::AssertionKind::WordBoundaryStartHalf => {
                Hir::look(if unicode {
                    hir::Look::WordStartHalfUnicode
                } else {
                    hir::Look::WordStartHalfAscii
                })
            }
            ast::AssertionKind::WordBoundaryEndHalf => Hir::look(if unicode {
                hir::Look::WordEndHalfUnicode
            } else {
                hir::Look::WordEndHalfAscii
            }),
        })
    }

    fn hir_capture(&self, group: &ast::Group, expr: Hir) -> Hir {
        let (index, name) = match group.kind {
            ast::GroupKind::CaptureIndex(index) => (index, None),
            ast::GroupKind::CaptureName { ref name, .. } => {
                (name.index, Some(name.name.clone().into_boxed_str()))
            }
            // The HIR doesn't need to use non-capturing groups, since the way
            // in which the data type is defined handles this automatically.
            ast::GroupKind::NonCapturing(_) => return expr,
        };
        Hir::capture(hir::Capture { index, name, sub: Box::new(expr) })
    }

    fn hir_repetition(&self, rep: &ast::Repetition, expr: Hir) -> Hir {
        let (min, max) = match rep.op.kind {
            ast::RepetitionKind::ZeroOrOne => (0, Some(1)),
            ast::RepetitionKind::ZeroOrMore => (0, None),
            ast::RepetitionKind::OneOrMore => (1, None),
            ast::RepetitionKind::Range(ast::RepetitionRange::Exactly(m)) => {
                (m, Some(m))
            }
            ast::RepetitionKind::Range(ast::RepetitionRange::AtLeast(m)) => {
                (m, None)
            }
            ast::RepetitionKind::Range(ast::RepetitionRange::Bounded(
                m,
                n,
            )) => (m, Some(n)),
        };
        let greedy =
            if self.flags().swap_greed() { !rep.greedy } else { rep.greedy };
        Hir::repetition(hir::Repetition {
            min,
            max,
            greedy,
            sub: Box::new(expr),
        })
    }

    fn hir_unicode_class(
        &self,
        ast_class: &ast::ClassUnicode,
    ) -> Result<hir::ClassUnicode> {
        use crate::ast::ClassUnicodeKind::*;

        if !self.flags().unicode() {
            return Err(
                self.error(ast_class.span, ErrorKind::UnicodeNotAllowed)
            );
        }
        let query = match ast_class.kind {
            OneLetter(name) => ClassQuery::OneLetter(name),
            Named(ref name) => ClassQuery::Binary(name),
            NamedValue { ref name, ref value, .. } => ClassQuery::ByValue {
                property_name: name,
                property_value: value,
            },
        };
        let mut result = self.convert_unicode_class_error(
            &ast_class.span,
            unicode::class(query),
        );
        if let Ok(ref mut class) = result {
            self.unicode_fold_and_negate(
                &ast_class.span,
                ast_class.negated,
                class,
            )?;
        }
        result
    }

    fn hir_ascii_unicode_class(
        &self,
        ast: &ast::ClassAscii,
    ) -> Result<hir::ClassUnicode> {
        let mut cls = hir::ClassUnicode::new(
            ascii_class_as_chars(&ast.kind)
                .map(|(s, e)| hir::ClassUnicodeRange::new(s, e)),
        );
        self.unicode_fold_and_negate(&ast.span, ast.negated, &mut cls)?;
        Ok(cls)
    }

    fn hir_ascii_byte_class(
        &self,
        ast: &ast::ClassAscii,
    ) -> Result<hir::ClassBytes> {
        let mut cls = hir::ClassBytes::new(
            ascii_class(&ast.kind)
                .map(|(s, e)| hir::ClassBytesRange::new(s, e)),
        );
        self.bytes_fold_and_negate(&ast.span, ast.negated, &mut cls)?;
        Ok(cls)
    }

    fn hir_perl_unicode_class(
        &self,
        ast_class: &ast::ClassPerl,
    ) -> Result<hir::ClassUnicode> {
        use crate::ast::ClassPerlKind::*;

        assert!(self.flags().unicode());
        let result = match ast_class.kind {
            Digit => unicode::perl_digit(),
            Space => unicode::perl_space(),
            Word => unicode::perl_word(),
        };
        let mut class =
            self.convert_unicode_class_error(&ast_class.span, result)?;
        // We needn't apply case folding here because the Perl Unicode classes
        // are already closed under Unicode simple case folding.
        if ast_class.negated {
            class.negate();
        }
        Ok(class)
    }

    fn hir_perl_byte_class(
        &self,
        ast_class: &ast::ClassPerl,
    ) -> Result<hir::ClassBytes> {
        use crate::ast::ClassPerlKind::*;

        assert!(!self.flags().unicode());
        let mut class = match ast_class.kind {
            Digit => hir_ascii_class_bytes(&ast::ClassAsciiKind::Digit),
            Space => hir_ascii_class_bytes(&ast::ClassAsciiKind::Space),
            Word => hir_ascii_class_bytes(&ast::ClassAsciiKind::Word),
        };
        // We needn't apply case folding here because the Perl ASCII classes
        // are already closed (under ASCII case folding).
        if ast_class.negated {
            class.negate();
        }
        // Negating a Perl byte class is likely to cause it to match invalid
        // UTF-8. That's only OK if the translator is configured to allow such
        // things.
        if self.trans().utf8 && !class.is_ascii() {
            return Err(self.error(ast_class.span, ErrorKind::InvalidUtf8));
        }
        Ok(class)
    }

    /// Converts the given Unicode specific error to an HIR translation error.
    ///
    /// The span given should approximate the position at which an error would
    /// occur.
    fn convert_unicode_class_error(
        &self,
        span: &Span,
        result: core::result::Result<hir::ClassUnicode, unicode::Error>,
    ) -> Result<hir::ClassUnicode> {
        result.map_err(|err| {
            let sp = span.clone();
            match err {
                unicode::Error::PropertyNotFound => {
                    self.error(sp, ErrorKind::UnicodePropertyNotFound)
                }
                unicode::Error::PropertyValueNotFound => {
                    self.error(sp, ErrorKind::UnicodePropertyValueNotFound)
                }
                unicode::Error::PerlClassNotFound => {
                    self.error(sp, ErrorKind::UnicodePerlClassNotFound)
                }
            }
        })
    }

    fn unicode_fold_and_negate(
        &self,
        span: &Span,
        negated: bool,
        class: &mut hir::ClassUnicode,
    ) -> Result<()> {
        // Note that we must apply case folding before negation!
        // Consider `(?i)[^x]`. If we applied negation first, then
        // the result would be the character class that matched any
        // Unicode scalar value.
        if self.flags().case_insensitive() {
            class.try_case_fold_simple().map_err(|_| {
                self.error(span.clone(), ErrorKind::UnicodeCaseUnavailable)
            })?;
        }
        if negated {
            class.negate();
        }
        Ok(())
    }

    fn bytes_fold_and_negate(
        &self,
        span: &Span,
        negated: bool,
        class: &mut hir::ClassBytes,
    ) -> Result<()> {
        // Note that we must apply case folding before negation!
        // Consider `(?i)[^x]`. If we applied negation first, then
        // the result would be the character class that matched any
        // Unicode scalar value.
        if self.flags().case_insensitive() {
            class.case_fold_simple();
        }
        if negated {
            class.negate();
        }
        if self.trans().utf8 && !class.is_ascii() {
            return Err(self.error(span.clone(), ErrorKind::InvalidUtf8));
        }
        Ok(())
    }

    /// Return a scalar byte value suitable for use as a literal in a byte
    /// character class.
    fn class_literal_byte(&self, ast: &ast::Literal) -> Result<u8> {
        match self.ast_literal_to_scalar(ast)? {
            Either::Right(byte) => Ok(byte),
            Either::Left(ch) => {
                if ch.is_ascii() {
                    Ok(u8::try_from(ch).unwrap())
                } else {
                    // We can't feasibly support Unicode in
                    // byte oriented classes. Byte classes don't
                    // do Unicode case folding.
                    Err(self.error(ast.span, ErrorKind::UnicodeNotAllowed))
                }
            }
        }
    }
}

/// A translator's representation of a regular expression's flags at any given
/// moment in time.
///
/// Each flag can be in one of three states: absent, present but disabled or
/// present but enabled.
#[derive(Clone, Copy, Debug, Default)]
struct Flags {
    case_insensitive: Option<bool>,
    multi_line: Option<bool>,
    dot_matches_new_line: Option<bool>,
    swap_greed: Option<bool>,
    unicode: Option<bool>,
    crlf: Option<bool>,
    // Note that `ignore_whitespace` is omitted here because it is handled
    // entirely in the parser.
}

impl Flags {
    fn from_ast(ast: &ast::Flags) -> Flags {
        let mut flags = Flags::default();
        let mut enable = true;
        for item in &ast.items {
            match item.kind {
                ast::FlagsItemKind::Negation => {
                    enable = false;
                }
                ast::FlagsItemKind::Flag(ast::Flag::CaseInsensitive) => {
                    flags.case_insensitive = Some(enable);
                }
                ast::FlagsItemKind::Flag(ast::Flag::MultiLine) => {
                    flags.multi_line = Some(enable);
                }
                ast::FlagsItemKind::Flag(ast::Flag::DotMatchesNewLine) => {
                    flags.dot_matches_new_line = Some(enable);
                }
                ast::FlagsItemKind::Flag(ast::Flag::SwapGreed) => {
                    flags.swap_greed = Some(enable);
                }
                ast::FlagsItemKind::Flag(ast::Flag::Unicode) => {
                    flags.unicode = Some(enable);
                }
                ast::FlagsItemKind::Flag(ast::Flag::CRLF) => {
                    flags.crlf = Some(enable);
                }
                ast::FlagsItemKind::Flag(ast::Flag::IgnoreWhitespace) => {}
            }
        }
        flags
    }

    fn merge(&mut self, previous: &Flags) {
        if self.case_insensitive.is_none() {
            self.case_insensitive = previous.case_insensitive;
        }
        if self.multi_line.is_none() {
            self.multi_line = previous.multi_line;
        }
        if self.dot_matches_new_line.is_none() {
            self.dot_matches_new_line = previous.dot_matches_new_line;
        }
        if self.swap_greed.is_none() {
            self.swap_greed = previous.swap_greed;
        }
        if self.unicode.is_none() {
            self.unicode = previous.unicode;
        }
        if self.crlf.is_none() {
            self.crlf = previous.crlf;
        }
    }

    fn case_insensitive(&self) -> bool {
        self.case_insensitive.unwrap_or(false)
    }

    fn multi_line(&self) -> bool {
        self.multi_line.unwrap_or(false)
    }

    fn dot_matches_new_line(&self) -> bool {
        self.dot_matches_new_line.unwrap_or(false)
    }

    fn swap_greed(&self) -> bool {
        self.swap_greed.unwrap_or(false)
    }

    fn unicode(&self) -> bool {
        self.unicode.unwrap_or(true)
    }

    fn crlf(&self) -> bool {
        self.crlf.unwrap_or(false)
    }
}

fn hir_ascii_class_bytes(kind: &ast::ClassAsciiKind) -> hir::ClassBytes {
    let ranges: Vec<_> = ascii_class(kind)
        .map(|(s, e)| hir::ClassBytesRange::new(s, e))
        .collect();
    hir::ClassBytes::new(ranges)
}

fn ascii_class(kind: &ast::ClassAsciiKind) -> impl Iterator<Item = (u8, u8)> {
    use crate::ast::ClassAsciiKind::*;

    let slice: &'static [(u8, u8)] = match *kind {
        Alnum => &[(b'0', b'9'), (b'A', b'Z'), (b'a', b'z')],
        Alpha => &[(b'A', b'Z'), (b'a', b'z')],
        Ascii => &[(b'\x00', b'\x7F')],
        Blank => &[(b'\t', b'\t'), (b' ', b' ')],
        Cntrl => &[(b'\x00', b'\x1F'), (b'\x7F', b'\x7F')],
        Digit => &[(b'0', b'9')],
        Graph => &[(b'!', b'~')],
        Lower => &[(b'a', b'z')],
        Print => &[(b' ', b'~')],
        Punct => &[(b'!', b'/'), (b':', b'@'), (b'[', b'`'), (b'{', b'~')],
        Space => &[
            (b'\t', b'\t'),
            (b'\n', b'\n'),
            (b'\x0B', b'\x0B'),
            (b'\x0C', b'\x0C'),
            (b'\r', b'\r'),
            (b' ', b' '),
        ],
        Upper => &[(b'A', b'Z')],
        Word => &[(b'0', b'9'), (b'A', b'Z'), (b'_', b'_'), (b'a', b'z')],
        Xdigit => &[(b'0', b'9'), (b'A', b'F'), (b'a', b'f')],
    };
    slice.iter().copied()
}

fn ascii_class_as_chars(
    kind: &ast::ClassAsciiKind,
) -> impl Iterator<Item = (char, char)> {
    ascii_class(kind).map(|(s, e)| (char::from(s), char::from(e)))
}

#[cfg(test)]
mod tests {
    use crate::{
        ast::{parse::ParserBuilder, Position},
        hir::{Look, Properties},
    };

    use super::*;

    // We create these errors to compare with real hir::Errors in the tests.
    // We define equality between TestError and hir::Error to disregard the
    // pattern string in hir::Error, which is annoying to provide in tests.
    #[derive(Clone, Debug)]
    struct TestError {
        span: Span,
        kind: hir::ErrorKind,
    }

    impl PartialEq<hir::Error> for TestError {
        fn eq(&self, other: &hir::Error) -> bool {
            self.span == other.span && self.kind == other.kind
        }
    }

    impl PartialEq<TestError> for hir::Error {
        fn eq(&self, other: &TestError) -> bool {
            self.span == other.span && self.kind == other.kind
        }
    }

    fn parse(pattern: &str) -> Ast {
        ParserBuilder::new().octal(true).build().parse(pattern).unwrap()
    }

    fn t(pattern: &str) -> Hir {
        TranslatorBuilder::new()
            .utf8(true)
            .build()
            .translate(pattern, &parse(pattern))
            .unwrap()
    }

    fn t_err(pattern: &str) -> hir::Error {
        TranslatorBuilder::new()
            .utf8(true)
            .build()
            .translate(pattern, &parse(pattern))
            .unwrap_err()
    }

    fn t_bytes(pattern: &str) -> Hir {
        TranslatorBuilder::new()
            .utf8(false)
            .build()
            .translate(pattern, &parse(pattern))
            .unwrap()
    }

    fn props(pattern: &str) -> Properties {
        t(pattern).properties().clone()
    }

    fn props_bytes(pattern: &str) -> Properties {
        t_bytes(pattern).properties().clone()
    }

    fn hir_lit(s: &str) -> Hir {
        hir_blit(s.as_bytes())
    }

    fn hir_blit(s: &[u8]) -> Hir {
        Hir::literal(s)
    }

    fn hir_capture(index: u32, expr: Hir) -> Hir {
        Hir::capture(hir::Capture { index, name: None, sub: Box::new(expr) })
    }

    fn hir_capture_name(index: u32, name: &str, expr: Hir) -> Hir {
        Hir::capture(hir::Capture {
            index,
            name: Some(name.into()),
            sub: Box::new(expr),
        })
    }

    fn hir_quest(greedy: bool, expr: Hir) -> Hir {
        Hir::repetition(hir::Repetition {
            min: 0,
            max: Some(1),
            greedy,
            sub: Box::new(expr),
        })
    }

    fn hir_star(greedy: bool, expr: Hir) -> Hir {
        Hir::repetition(hir::Repetition {
            min: 0,
            max: None,
            greedy,
            sub: Box::new(expr),
        })
    }

    fn hir_plus(greedy: bool, expr: Hir) -> Hir {
        Hir::repetition(hir::Repetition {
            min: 1,
            max: None,
            greedy,
            sub: Box::new(expr),
        })
    }

    fn hir_range(greedy: bool, min: u32, max: Option<u32>, expr: Hir) -> Hir {
        Hir::repetition(hir::Repetition {
            min,
            max,
            greedy,
            sub: Box::new(expr),
        })
    }

    fn hir_alt(alts: Vec<Hir>) -> Hir {
        Hir::alternation(alts)
    }

    fn hir_cat(exprs: Vec<Hir>) -> Hir {
        Hir::concat(exprs)
    }

    #[allow(dead_code)]
    fn hir_uclass_query(query: ClassQuery<'_>) -> Hir {
        Hir::class(hir::Class::Unicode(unicode::class(query).unwrap()))
    }

    #[allow(dead_code)]
    fn hir_uclass_perl_word() -> Hir {
        Hir::class(hir::Class::Unicode(unicode::perl_word().unwrap()))
    }

    fn hir_ascii_uclass(kind: &ast::ClassAsciiKind) -> Hir {
        Hir::class(hir::Class::Unicode(hir::ClassUnicode::new(
            ascii_class_as_chars(kind)
                .map(|(s, e)| hir::ClassUnicodeRange::new(s, e)),
        )))
    }

    fn hir_ascii_bclass(kind: &ast::ClassAsciiKind) -> Hir {
        Hir::class(hir::Class::Bytes(hir::ClassBytes::new(
            ascii_class(kind).map(|(s, e)| hir::ClassBytesRange::new(s, e)),
        )))
    }

    fn hir_uclass(ranges: &[(char, char)]) -> Hir {
        Hir::class(uclass(ranges))
    }

    fn hir_bclass(ranges: &[(u8, u8)]) -> Hir {
        Hir::class(bclass(ranges))
    }

    fn hir_case_fold(expr: Hir) -> Hir {
        match expr.into_kind() {
            HirKind::Class(mut cls) => {
                cls.case_fold_simple();
                Hir::class(cls)
            }
            _ => panic!("cannot case fold non-class Hir expr"),
        }
    }

    fn hir_negate(expr: Hir) -> Hir {
        match expr.into_kind() {
            HirKind::Class(mut cls) => {
                cls.negate();
                Hir::class(cls)
            }
            _ => panic!("cannot negate non-class Hir expr"),
        }
    }

    fn uclass(ranges: &[(char, char)]) -> hir::Class {
        let ranges: Vec<hir::ClassUnicodeRange> = ranges
            .iter()
            .map(|&(s, e)| hir::ClassUnicodeRange::new(s, e))
            .collect();
        hir::Class::Unicode(hir::ClassUnicode::new(ranges))
    }

    fn bclass(ranges: &[(u8, u8)]) -> hir::Class {
        let ranges: Vec<hir::ClassBytesRange> = ranges
            .iter()
            .map(|&(s, e)| hir::ClassBytesRange::new(s, e))
            .collect();
        hir::Class::Bytes(hir::ClassBytes::new(ranges))
    }

    #[cfg(feature = "unicode-case")]
    fn class_case_fold(mut cls: hir::Class) -> Hir {
        cls.case_fold_simple();
        Hir::class(cls)
    }

    fn class_negate(mut cls: hir::Class) -> Hir {
        cls.negate();
        Hir::class(cls)
    }

    #[allow(dead_code)]
    fn hir_union(expr1: Hir, expr2: Hir) -> Hir {
        use crate::hir::Class::{Bytes, Unicode};

        match (expr1.into_kind(), expr2.into_kind()) {
            (HirKind::Class(Unicode(mut c1)), HirKind::Class(Unicode(c2))) => {
                c1.union(&c2);
                Hir::class(hir::Class::Unicode(c1))
            }
            (HirKind::Class(Bytes(mut c1)), HirKind::Class(Bytes(c2))) => {
                c1.union(&c2);
                Hir::class(hir::Class::Bytes(c1))
            }
            _ => panic!("cannot union non-class Hir exprs"),
        }
    }

    #[allow(dead_code)]
    fn hir_difference(expr1: Hir, expr2: Hir) -> Hir {
        use crate::hir::Class::{Bytes, Unicode};

        match (expr1.into_kind(), expr2.into_kind()) {
            (HirKind::Class(Unicode(mut c1)), HirKind::Class(Unicode(c2))) => {
                c1.difference(&c2);
                Hir::class(hir::Class::Unicode(c1))
            }
            (HirKind::Class(Bytes(mut c1)), HirKind::Class(Bytes(c2))) => {
                c1.difference(&c2);
                Hir::class(hir::Class::Bytes(c1))
            }
            _ => panic!("cannot difference non-class Hir exprs"),
        }
    }

    fn hir_look(look: hir::Look) -> Hir {
        Hir::look(look)
    }

    #[test]
    fn empty() {
        assert_eq!(t(""), Hir::empty());
        assert_eq!(t("(?i)"), Hir::empty());
        assert_eq!(t("()"), hir_capture(1, Hir::empty()));
        assert_eq!(t("(?:)"), Hir::empty());
        assert_eq!(t("(?P<wat>)"), hir_capture_name(1, "wat", Hir::empty()));
        assert_eq!(t("|"), hir_alt(vec![Hir::empty(), Hir::empty()]));
        assert_eq!(
            t("()|()"),
            hir_alt(vec![
                hir_capture(1, Hir::empty()),
                hir_capture(2, Hir::empty()),
            ])
        );
        assert_eq!(
            t("(|b)"),
            hir_capture(1, hir_alt(vec![Hir::empty(), hir_lit("b"),]))
        );
        assert_eq!(
            t("(a|)"),
            hir_capture(1, hir_alt(vec![hir_lit("a"), Hir::empty(),]))
        );
        assert_eq!(
            t("(a||c)"),
            hir_capture(
                1,
                hir_alt(vec![hir_lit("a"), Hir::empty(), hir_lit("c"),])
            )
        );
        assert_eq!(
            t("(||)"),
            hir_capture(
                1,
                hir_alt(vec![Hir::empty(), Hir::empty(), Hir::empty(),])
            )
        );
    }

    #[test]
    fn literal() {
        assert_eq!(t("a"), hir_lit("a"));
        assert_eq!(t("(?-u)a"), hir_lit("a"));
        assert_eq!(t("☃"), hir_lit("☃"));
        assert_eq!(t("abcd"), hir_lit("abcd"));

        assert_eq!(t_bytes("(?-u)a"), hir_lit("a"));
        assert_eq!(t_bytes("(?-u)\x61"), hir_lit("a"));
        assert_eq!(t_bytes(r"(?-u)\x61"), hir_lit("a"));
        assert_eq!(t_bytes(r"(?-u)\xFF"), hir_blit(b"\xFF"));

        assert_eq!(t("(?-u)☃"), hir_lit("☃"));
        assert_eq!(
            t_err(r"(?-u)\xFF"),
            TestError {
                kind: hir::ErrorKind::InvalidUtf8,
                span: Span::new(
                    Position::new(5, 1, 6),
                    Position::new(9, 1, 10)
                ),
            }
        );
    }

    #[test]
    fn literal_case_insensitive() {
        #[cfg(feature = "unicode-case")]
        assert_eq!(t("(?i)a"), hir_uclass(&[('A', 'A'), ('a', 'a'),]));
        #[cfg(feature = "unicode-case")]
        assert_eq!(t("(?i:a)"), hir_uclass(&[('A', 'A'), ('a', 'a')]));
        #[cfg(feature = "unicode-case")]
        assert_eq!(
            t("a(?i)a(?-i)a"),
            hir_cat(vec![
                hir_lit("a"),
                hir_uclass(&[('A', 'A'), ('a', 'a')]),
                hir_lit("a"),
            ])
        );
        #[cfg(feature = "unicode-case")]
        assert_eq!(
            t("(?i)ab@c"),
            hir_cat(vec![
                hir_uclass(&[('A', 'A'), ('a', 'a')]),
                hir_uclass(&[('B', 'B'), ('b', 'b')]),
                hir_lit("@"),
                hir_uclass(&[('C', 'C'), ('c', 'c')]),
            ])
        );
        #[cfg(feature = "unicode-case")]
        assert_eq!(
            t("(?i)β"),
            hir_uclass(&[('Β', 'Β'), ('β', 'β'), ('ϐ', 'ϐ'),])
        );

        assert_eq!(t("(?i-u)a"), hir_bclass(&[(b'A', b'A'), (b'a', b'a'),]));
        #[cfg(feature = "unicode-case")]
        assert_eq!(
            t("(?-u)a(?i)a(?-i)a"),
            hir_cat(vec![
                hir_lit("a"),
                hir_bclass(&[(b'A', b'A'), (b'a', b'a')]),
                hir_lit("a"),
            ])
        );
        assert_eq!(
            t("(?i-u)ab@c"),
            hir_cat(vec![
                hir_bclass(&[(b'A', b'A'), (b'a', b'a')]),
                hir_bclass(&[(b'B', b'B'), (b'b', b'b')]),
                hir_lit("@"),
                hir_bclass(&[(b'C', b'C'), (b'c', b'c')]),
            ])
        );

        assert_eq!(
            t_bytes("(?i-u)a"),
            hir_bclass(&[(b'A', b'A'), (b'a', b'a'),])
        );
        assert_eq!(
            t_bytes("(?i-u)\x61"),
            hir_bclass(&[(b'A', b'A'), (b'a', b'a'),])
        );
        assert_eq!(
            t_bytes(r"(?i-u)\x61"),
            hir_bclass(&[(b'A', b'A'), (b'a', b'a'),])
        );
        assert_eq!(t_bytes(r"(?i-u)\xFF"), hir_blit(b"\xFF"));

        assert_eq!(t("(?i-u)β"), hir_lit("β"),);
    }

    #[test]
    fn dot() {
        assert_eq!(
            t("."),
            hir_uclass(&[('\0', '\t'), ('\x0B', '\u{10FFFF}')])
        );
        assert_eq!(
            t("(?R)."),
            hir_uclass(&[
                ('\0', '\t'),
                ('\x0B', '\x0C'),
                ('\x0E', '\u{10FFFF}'),
            ])
        );
        assert_eq!(t("(?s)."), hir_uclass(&[('\0', '\u{10FFFF}')]));
        assert_eq!(t("(?Rs)."), hir_uclass(&[('\0', '\u{10FFFF}')]));
        assert_eq!(
            t_bytes("(?-u)."),
            hir_bclass(&[(b'\0', b'\t'), (b'\x0B', b'\xFF')])
        );
        assert_eq!(
            t_bytes("(?R-u)."),
            hir_bclass(&[
                (b'\0', b'\t'),
                (b'\x0B', b'\x0C'),
                (b'\x0E', b'\xFF'),
            ])
        );
        assert_eq!(t_bytes("(?s-u)."), hir_bclass(&[(b'\0', b'\xFF'),]));
        assert_eq!(t_bytes("(?Rs-u)."), hir_bclass(&[(b'\0', b'\xFF'),]));

        // If invalid UTF-8 isn't allowed, then non-Unicode `.` isn't allowed.
        assert_eq!(
            t_err("(?-u)."),
            TestError {
                kind: hir::ErrorKind::InvalidUtf8,
                span: Span::new(
                    Position::new(5, 1, 6),
                    Position::new(6, 1, 7)
                ),
            }
        );
        assert_eq!(
            t_err("(?R-u)."),
            TestError {
                kind: hir::ErrorKind::InvalidUtf8,
                span: Span::new(
                    Position::new(6, 1, 7),
                    Position::new(7, 1, 8)
                ),
            }
        );
        assert_eq!(
            t_err("(?s-u)."),
            TestError {
                kind: hir::ErrorKind::InvalidUtf8,
                span: Span::new(
                    Position::new(6, 1, 7),
                    Position::new(7, 1, 8)
                ),
            }
        );
        assert_eq!(
            t_err("(?Rs-u)."),
            TestError {
                kind: hir::ErrorKind::InvalidUtf8,
                span: Span::new(
                    Position::new(7, 1, 8),
                    Position::new(8, 1, 9)
                ),
            }
        );
    }

    #[test]
    fn assertions() {
        assert_eq!(t("^"), hir_look(hir::Look::Start));
        assert_eq!(t("$"), hir_look(hir::Look::End));
        assert_eq!(t(r"\A"), hir_look(hir::Look::Start));
        assert_eq!(t(r"\z"), hir_look(hir::Look::End));
        assert_eq!(t("(?m)^"), hir_look(hir::Look::StartLF));
        assert_eq!(t("(?m)$"), hir_look(hir::Look::EndLF));
        assert_eq!(t(r"(?m)\A"), hir_look(hir::Look::Start));
        assert_eq!(t(r"(?m)\z"), hir_look(hir::Look::End));

        assert_eq!(t(r"\b"), hir_look(hir::Look::WordUnicode));
        assert_eq!(t(r"\B"), hir_look(hir::Look::WordUnicodeNegate));
        assert_eq!(t(r"(?-u)\b"), hir_look(hir::Look::WordAscii));
        assert_eq!(t(r"(?-u)\B"), hir_look(hir::Look::WordAsciiNegate));
    }

    #[test]
    fn group() {
        assert_eq!(t("(a)"), hir_capture(1, hir_lit("a")));
        assert_eq!(
            t("(a)(b)"),
            hir_cat(vec![
                hir_capture(1, hir_lit("a")),
                hir_capture(2, hir_lit("b")),
            ])
        );
        assert_eq!(
            t("(a)|(b)"),
            hir_alt(vec![
                hir_capture(1, hir_lit("a")),
                hir_capture(2, hir_lit("b")),
            ])
        );
        assert_eq!(t("(?P<foo>)"), hir_capture_name(1, "foo", Hir::empty()));
        assert_eq!(t("(?P<foo>a)"), hir_capture_name(1, "foo", hir_lit("a")));
        assert_eq!(
            t("(?P<foo>a)(?P<bar>b)"),
            hir_cat(vec![
                hir_capture_name(1, "foo", hir_lit("a")),
                hir_capture_name(2, "bar", hir_lit("b")),
            ])
        );
        assert_eq!(t("(?:)"), Hir::empty());
        assert_eq!(t("(?:a)"), hir_lit("a"));
        assert_eq!(
            t("(?:a)(b)"),
            hir_cat(vec![hir_lit("a"), hir_capture(1, hir_lit("b")),])
        );
        assert_eq!(
            t("(a)(?:b)(c)"),
            hir_cat(vec![
                hir_capture(1, hir_lit("a")),
                hir_lit("b"),
                hir_capture(2, hir_lit("c")),
            ])
        );
        assert_eq!(
            t("(a)(?P<foo>b)(c)"),
            hir_cat(vec![
                hir_capture(1, hir_lit("a")),
                hir_capture_name(2, "foo", hir_lit("b")),
                hir_capture(3, hir_lit("c")),
            ])
        );
        assert_eq!(t("()"), hir_capture(1, Hir::empty()));
        assert_eq!(t("((?i))"), hir_capture(1, Hir::empty()));
        assert_eq!(t("((?x))"), hir_capture(1, Hir::empty()));
        assert_eq!(
            t("(((?x)))"),
            hir_capture(1, hir_capture(2, Hir::empty()))
        );
    }

    #[test]
    fn line_anchors() {
        assert_eq!(t("^"), hir_look(hir::Look::Start));
        assert_eq!(t("$"), hir_look(hir::Look::End));
        assert_eq!(t(r"\A"), hir_look(hir::Look::Start));
        assert_eq!(t(r"\z"), hir_look(hir::Look::End));

        assert_eq!(t(r"(?m)\A"), hir_look(hir::Look::Start));
        assert_eq!(t(r"(?m)\z"), hir_look(hir::Look::End));
        assert_eq!(t("(?m)^"), hir_look(hir::Look::StartLF));
        assert_eq!(t("(?m)$"), hir_look(hir::Look::EndLF));

        assert_eq!(t(r"(?R)\A"), hir_look(hir::Look::Start));
        assert_eq!(t(r"(?R)\z"), hir_look(hir::Look::End));
        assert_eq!(t("(?R)^"), hir_look(hir::Look::Start));
        assert_eq!(t("(?R)$"), hir_look(hir::Look::End));

        assert_eq!(t(r"(?Rm)\A"), hir_look(hir::Look::Start));
        assert_eq!(t(r"(?Rm)\z"), hir_look(hir::Look::End));
        assert_eq!(t("(?Rm)^"), hir_look(hir::Look::StartCRLF));
        assert_eq!(t("(?Rm)$"), hir_look(hir::Look::EndCRLF));
    }

    #[test]
    fn flags() {
        #[cfg(feature = "unicode-case")]
        assert_eq!(
            t("(?i:a)a"),
            hir_cat(
                vec![hir_uclass(&[('A', 'A'), ('a', 'a')]), hir_lit("a"),]
            )
        );
        assert_eq!(
            t("(?i-u:a)β"),
            hir_cat(vec![
                hir_bclass(&[(b'A', b'A'), (b'a', b'a')]),
                hir_lit("β"),
            ])
        );
        assert_eq!(
            t("(?:(?i-u)a)b"),
            hir_cat(vec![
                hir_bclass(&[(b'A', b'A'), (b'a', b'a')]),
                hir_lit("b"),
            ])
        );
        assert_eq!(
            t("((?i-u)a)b"),
            hir_cat(vec![
                hir_capture(1, hir_bclass(&[(b'A', b'A'), (b'a', b'a')])),
                hir_lit("b"),
            ])
        );
        #[cfg(feature = "unicode-case")]
        assert_eq!(
            t("(?i)(?-i:a)a"),
            hir_cat(
                vec![hir_lit("a"), hir_uclass(&[('A', 'A'), ('a', 'a')]),]
            )
        );
        #[cfg(feature = "unicode-case")]
        assert_eq!(
            t("(?im)a^"),
            hir_cat(vec![
                hir_uclass(&[('A', 'A'), ('a', 'a')]),
                hir_look(hir::Look::StartLF),
            ])
        );
        #[cfg(feature = "unicode-case")]
        assert_eq!(
            t("(?im)a^(?i-m)a^"),
            hir_cat(vec![
                hir_uclass(&[('A', 'A'), ('a', 'a')]),
                hir_look(hir::Look::StartLF),
                hir_uclass(&[('A', 'A'), ('a', 'a')]),
                hir_look(hir::Look::Start),
            ])
        );
        assert_eq!(
            t("(?U)a*a*?(?-U)a*a*?"),
            hir_cat(vec![
                hir_star(false, hir_lit("a")),
                hir_star(true, hir_lit("a")),
                hir_star(true, hir_lit("a")),
                hir_star(false, hir_lit("a")),
            ])
        );
        #[cfg(feature = "unicode-case")]
        assert_eq!(
            t("(?:a(?i)a)a"),
            hir_cat(vec![
                hir_cat(vec![
                    hir_lit("a"),
                    hir_uclass(&[('A', 'A'), ('a', 'a')]),
                ]),
                hir_lit("a"),
            ])
        );
        #[cfg(feature = "unicode-case")]
        assert_eq!(
            t("(?i)(?:a(?-i)a)a"),
            hir_cat(vec![
                hir_cat(vec![
                    hir_uclass(&[('A', 'A'), ('a', 'a')]),
                    hir_lit("a"),
                ]),
                hir_uclass(&[('A', 'A'), ('a', 'a')]),
            ])
        );
    }

    #[test]
    fn escape() {
        assert_eq!(
            t(r"\\\.\+\*\?\(\)\|\[\]\{\}\^\$\#"),
            hir_lit(r"\.+*?()|[]{}^$#")
        );
    }

    #[test]
    fn repetition() {
        assert_eq!(t("a?"), hir_quest(true, hir_lit("a")));
        assert_eq!(t("a*"), hir_star(true, hir_lit("a")));
        assert_eq!(t("a+"), hir_plus(true, hir_lit("a")));
        assert_eq!(t("a??"), hir_quest(false, hir_lit("a")));
        assert_eq!(t("a*?"), hir_star(false, hir_lit("a")));
        assert_eq!(t("a+?"), hir_plus(false, hir_lit("a")));

        assert_eq!(t("a{1}"), hir_range(true, 1, Some(1), hir_lit("a"),));
        assert_eq!(t("a{1,}"), hir_range(true, 1, None, hir_lit("a"),));
        assert_eq!(t("a{1,2}"), hir_range(true, 1, Some(2), hir_lit("a"),));
        assert_eq!(t("a{1}?"), hir_range(false, 1, Some(1), hir_lit("a"),));
        assert_eq!(t("a{1,}?"), hir_range(false, 1, None, hir_lit("a"),));
        assert_eq!(t("a{1,2}?"), hir_range(false, 1, Some(2), hir_lit("a"),));

        assert_eq!(
            t("ab?"),
            hir_cat(vec![hir_lit("a"), hir_quest(true, hir_lit("b")),])
        );
        assert_eq!(t("(ab)?"), hir_quest(true, hir_capture(1, hir_lit("ab"))));
        assert_eq!(
            t("a|b?"),
            hir_alt(vec![hir_lit("a"), hir_quest(true, hir_lit("b")),])
        );
    }

    #[test]
    fn cat_alt() {
        let a = || hir_look(hir::Look::Start);
        let b = || hir_look(hir::Look::End);
        let c = || hir_look(hir::Look::WordUnicode);
        let d = || hir_look(hir::Look::WordUnicodeNegate);

        assert_eq!(t("(^$)"), hir_capture(1, hir_cat(vec![a(), b()])));
        assert_eq!(t("^|$"), hir_alt(vec![a(), b()]));
        assert_eq!(t(r"^|$|\b"), hir_alt(vec![a(), b(), c()]));
        assert_eq!(
            t(r"^$|$\b|\b\B"),
            hir_alt(vec![
                hir_cat(vec![a(), b()]),
                hir_cat(vec![b(), c()]),
                hir_cat(vec![c(), d()]),
            ])
        );
        assert_eq!(t("(^|$)"), hir_capture(1, hir_alt(vec![a(), b()])));
        assert_eq!(
            t(r"(^|$|\b)"),
            hir_capture(1, hir_alt(vec![a(), b(), c()]))
        );
        assert_eq!(
            t(r"(^$|$\b|\b\B)"),
            hir_capture(
                1,
                hir_alt(vec![
                    hir_cat(vec![a(), b()]),
                    hir_cat(vec![b(), c()]),
                    hir_cat(vec![c(), d()]),
                ])
            )
        );
        assert_eq!(
            t(r"(^$|($\b|(\b\B)))"),
            hir_capture(
                1,
                hir_alt(vec![
                    hir_cat(vec![a(), b()]),
                    hir_capture(
                        2,
                        hir_alt(vec![
                            hir_cat(vec![b(), c()]),
                            hir_capture(3, hir_cat(vec![c(), d()])),
                        ])
                    ),
                ])
            )
        );
    }

    // Tests the HIR transformation of things like '[a-z]|[A-Z]' into
    // '[A-Za-z]'. In other words, an alternation of just classes is always
    // equivalent to a single class corresponding to the union of the branches
    // in that class. (Unless some branches match invalid UTF-8 and others
    // match non-ASCII Unicode.)
    #[test]
    fn cat_class_flattened() {
        assert_eq!(t(r"[a-z]|[A-Z]"), hir_uclass(&[('A', 'Z'), ('a', 'z')]));
        // Combining all of the letter properties should give us the one giant
        // letter property.
        #[cfg(feature = "unicode-gencat")]
        assert_eq!(
            t(r"(?x)
                \p{Lowercase_Letter}
                |\p{Uppercase_Letter}
                |\p{Titlecase_Letter}
                |\p{Modifier_Letter}
                |\p{Other_Letter}
            "),
            hir_uclass_query(ClassQuery::Binary("letter"))
        );
        // Byte classes that can truly match invalid UTF-8 cannot be combined
        // with Unicode classes.
        assert_eq!(
            t_bytes(r"[Δδ]|(?-u:[\x90-\xFF])|[Λλ]"),
            hir_alt(vec![
                hir_uclass(&[('Δ', 'Δ'), ('δ', 'δ')]),
                hir_bclass(&[(b'\x90', b'\xFF')]),
                hir_uclass(&[('Λ', 'Λ'), ('λ', 'λ')]),
            ])
        );
        // Byte classes on their own can be combined, even if some are ASCII
        // and others are invalid UTF-8.
        assert_eq!(
            t_bytes(r"[a-z]|(?-u:[\x90-\xFF])|[A-Z]"),
            hir_bclass(&[(b'A', b'Z'), (b'a', b'z'), (b'\x90', b'\xFF')]),
        );
    }

    #[test]
    fn class_ascii() {
        assert_eq!(
            t("[[:alnum:]]"),
            hir_ascii_uclass(&ast::ClassAsciiKind::Alnum)
        );
        assert_eq!(
            t("[[:alpha:]]"),
            hir_ascii_uclass(&ast::ClassAsciiKind::Alpha)
        );
        assert_eq!(
            t("[[:ascii:]]"),
            hir_ascii_uclass(&ast::ClassAsciiKind::Ascii)
        );
        assert_eq!(
            t("[[:blank:]]"),
            hir_ascii_uclass(&ast::ClassAsciiKind::Blank)
        );
        assert_eq!(
            t("[[:cntrl:]]"),
            hir_ascii_uclass(&ast::ClassAsciiKind::Cntrl)
        );
        assert_eq!(
            t("[[:digit:]]"),
            hir_ascii_uclass(&ast::ClassAsciiKind::Digit)
        );
        assert_eq!(
            t("[[:graph:]]"),
            hir_ascii_uclass(&ast::ClassAsciiKind::Graph)
        );
        assert_eq!(
            t("[[:lower:]]"),
            hir_ascii_uclass(&ast::ClassAsciiKind::Lower)
        );
        assert_eq!(
            t("[[:print:]]"),
            hir_ascii_uclass(&ast::ClassAsciiKind::Print)
        );
        assert_eq!(
            t("[[:punct:]]"),
            hir_ascii_uclass(&ast::ClassAsciiKind::Punct)
        );
        assert_eq!(
            t("[[:space:]]"),
            hir_ascii_uclass(&ast::ClassAsciiKind::Space)
        );
        assert_eq!(
            t("[[:upper:]]"),
            hir_ascii_uclass(&ast::ClassAsciiKind::Upper)
        );
        assert_eq!(
            t("[[:word:]]"),
            hir_ascii_uclass(&ast::ClassAsciiKind::Word)
        );
        assert_eq!(
            t("[[:xdigit:]]"),
            hir_ascii_uclass(&ast::ClassAsciiKind::Xdigit)
        );

        assert_eq!(
            t("[[:^lower:]]"),
            hir_negate(hir_ascii_uclass(&ast::ClassAsciiKind::Lower))
        );
        #[cfg(feature = "unicode-case")]
        assert_eq!(
            t("(?i)[[:lower:]]"),
            hir_uclass(&[
                ('A', 'Z'),
                ('a', 'z'),
                ('\u{17F}', '\u{17F}'),
                ('\u{212A}', '\u{212A}'),
            ])
        );

        assert_eq!(
            t("(?-u)[[:lower:]]"),
            hir_ascii_bclass(&ast::ClassAsciiKind::Lower)
        );
        assert_eq!(
            t("(?i-u)[[:lower:]]"),
            hir_case_fold(hir_ascii_bclass(&ast::ClassAsciiKind::Lower))
        );

        assert_eq!(
            t_err("(?-u)[[:^lower:]]"),
            TestError {
                kind: hir::ErrorKind::InvalidUtf8,
                span: Span::new(
                    Position::new(6, 1, 7),
                    Position::new(16, 1, 17)
                ),
            }
        );
        assert_eq!(
            t_err("(?i-u)[[:^lower:]]"),
            TestError {
                kind: hir::ErrorKind::InvalidUtf8,
                span: Span::new(
                    Position::new(7, 1, 8),
                    Position::new(17, 1, 18)
                ),
            }
        );
    }

    #[test]
    fn class_ascii_multiple() {
        // See: https://github.com/rust-lang/regex/issues/680
        assert_eq!(
            t("[[:alnum:][:^ascii:]]"),
            hir_union(
                hir_ascii_uclass(&ast::ClassAsciiKind::Alnum),
                hir_uclass(&[('\u{80}', '\u{10FFFF}')]),
            ),
        );
        assert_eq!(
            t_bytes("(?-u)[[:alnum:][:^ascii:]]"),
            hir_union(
                hir_ascii_bclass(&ast::ClassAsciiKind::Alnum),
                hir_bclass(&[(0x80, 0xFF)]),
            ),
        );
    }

    #[test]
    #[cfg(feature = "unicode-perl")]
    fn class_perl_unicode() {
        // Unicode
        assert_eq!(t(r"\d"), hir_uclass_query(ClassQuery::Binary("digit")));
        assert_eq!(t(r"\s"), hir_uclass_query(ClassQuery::Binary("space")));
        assert_eq!(t(r"\w"), hir_uclass_perl_word());
        #[cfg(feature = "unicode-case")]
        assert_eq!(
            t(r"(?i)\d"),
            hir_uclass_query(ClassQuery::Binary("digit"))
        );
        #[cfg(feature = "unicode-case")]
        assert_eq!(
            t(r"(?i)\s"),
            hir_uclass_query(ClassQuery::Binary("space"))
        );
        #[cfg(feature = "unicode-case")]
        assert_eq!(t(r"(?i)\w"), hir_uclass_perl_word());

        // Unicode, negated
        assert_eq!(
            t(r"\D"),
            hir_negate(hir_uclass_query(ClassQuery::Binary("digit")))
        );
        assert_eq!(
            t(r"\S"),
            hir_negate(hir_uclass_query(ClassQuery::Binary("space")))
        );
        assert_eq!(t(r"\W"), hir_negate(hir_uclass_perl_word()));
        #[cfg(feature = "unicode-case")]
        assert_eq!(
            t(r"(?i)\D"),
            hir_negate(hir_uclass_query(ClassQuery::Binary("digit")))
        );
        #[cfg(feature = "unicode-case")]
        assert_eq!(
            t(r"(?i)\S"),
            hir_negate(hir_uclass_query(ClassQuery::Binary("space")))
        );
        #[cfg(feature = "unicode-case")]
        assert_eq!(t(r"(?i)\W"), hir_negate(hir_uclass_perl_word()));
    }

    #[test]
    fn class_perl_ascii() {
        // ASCII only
        assert_eq!(
            t(r"(?-u)\d"),
            hir_ascii_bclass(&ast::ClassAsciiKind::Digit)
        );
        assert_eq!(
            t(r"(?-u)\s"),
            hir_ascii_bclass(&ast::ClassAsciiKind::Space)
        );
        assert_eq!(
            t(r"(?-u)\w"),
            hir_ascii_bclass(&ast::ClassAsciiKind::Word)
        );
        assert_eq!(
            t(r"(?i-u)\d"),
            hir_ascii_bclass(&ast::ClassAsciiKind::Digit)
        );
        assert_eq!(
            t(r"(?i-u)\s"),
            hir_ascii_bclass(&ast::ClassAsciiKind::Space)
        );
        assert_eq!(
            t(r"(?i-u)\w"),
            hir_ascii_bclass(&ast::ClassAsciiKind::Word)
        );

        // ASCII only, negated
        assert_eq!(
            t_bytes(r"(?-u)\D"),
            hir_negate(hir_ascii_bclass(&ast::ClassAsciiKind::Digit))
        );
        assert_eq!(
            t_bytes(r"(?-u)\S"),
            hir_negate(hir_ascii_bclass(&ast::ClassAsciiKind::Space))
        );
        assert_eq!(
            t_bytes(r"(?-u)\W"),
            hir_negate(hir_ascii_bclass(&ast::ClassAsciiKind::Word))
        );
        assert_eq!(
            t_bytes(r"(?i-u)\D"),
            hir_negate(hir_ascii_bclass(&ast::ClassAsciiKind::Digit))
        );
        assert_eq!(
            t_bytes(r"(?i-u)\S"),
            hir_negate(hir_ascii_bclass(&ast::ClassAsciiKind::Space))
        );
        assert_eq!(
            t_bytes(r"(?i-u)\W"),
            hir_negate(hir_ascii_bclass(&ast::ClassAsciiKind::Word))
        );

        // ASCII only, negated, with UTF-8 mode enabled.
        // In this case, negating any Perl class results in an error because
        // all such classes can match invalid UTF-8.
        assert_eq!(
            t_err(r"(?-u)\D"),
            TestError {
                kind: hir::ErrorKind::InvalidUtf8,
                span: Span::new(
                    Position::new(5, 1, 6),
                    Position::new(7, 1, 8),
                ),
            },
        );
        assert_eq!(
            t_err(r"(?-u)\S"),
            TestError {
                kind: hir::ErrorKind::InvalidUtf8,
                span: Span::new(
                    Position::new(5, 1, 6),
                    Position::new(7, 1, 8),
                ),
            },
        );
        assert_eq!(
            t_err(r"(?-u)\W"),
            TestError {
                kind: hir::ErrorKind::InvalidUtf8,
                span: Span::new(
                    Position::new(5, 1, 6),
                    Position::new(7, 1, 8),
                ),
            },
        );
        assert_eq!(
            t_err(r"(?i-u)\D"),
            TestError {
                kind: hir::ErrorKind::InvalidUtf8,
                span: Span::new(
                    Position::new(6, 1, 7),
                    Position::new(8, 1, 9),
                ),
            },
        );
        assert_eq!(
            t_err(r"(?i-u)\S"),
            TestError {
                kind: hir::ErrorKind::InvalidUtf8,
                span: Span::new(
                    Position::new(6, 1, 7),
                    Position::new(8, 1, 9),
                ),
            },
        );
        assert_eq!(
            t_err(r"(?i-u)\W"),
            TestError {
                kind: hir::ErrorKind::InvalidUtf8,
                span: Span::new(
                    Position::new(6, 1, 7),
                    Position::new(8, 1, 9),
                ),
            },
        );
    }

    #[test]
    #[cfg(not(feature = "unicode-perl"))]
    fn class_perl_word_disabled() {
        assert_eq!(
            t_err(r"\w"),
            TestError {
                kind: hir::ErrorKind::UnicodePerlClassNotFound,
                span: Span::new(
                    Position::new(0, 1, 1),
                    Position::new(2, 1, 3)
                ),
            }
        );
    }

    #[test]
    #[cfg(all(not(feature = "unicode-perl"), not(feature = "unicode-bool")))]
    fn class_perl_space_disabled() {
        assert_eq!(
            t_err(r"\s"),
            TestError {
                kind: hir::ErrorKind::UnicodePerlClassNotFound,
                span: Span::new(
                    Position::new(0, 1, 1),
                    Position::new(2, 1, 3)
                ),
            }
        );
    }

    #[test]
    #[cfg(all(
        not(feature = "unicode-perl"),
        not(feature = "unicode-gencat")
    ))]
    fn class_perl_digit_disabled() {
        assert_eq!(
            t_err(r"\d"),
            TestError {
                kind: hir::ErrorKind::UnicodePerlClassNotFound,
                span: Span::new(
                    Position::new(0, 1, 1),
                    Position::new(2, 1, 3)
                ),
            }
        );
    }

    #[test]
    #[cfg(feature = "unicode-gencat")]
    fn class_unicode_gencat() {
        assert_eq!(t(r"\pZ"), hir_uclass_query(ClassQuery::Binary("Z")));
        assert_eq!(t(r"\pz"), hir_uclass_query(ClassQuery::Binary("Z")));
        assert_eq!(
            t(r"\p{Separator}"),
            hir_uclass_query(ClassQuery::Binary("Z"))
        );
        assert_eq!(
            t(r"\p{se      PaRa ToR}"),
            hir_uclass_query(ClassQuery::Binary("Z"))
        );
        assert_eq!(
            t(r"\p{gc:Separator}"),
            hir_uclass_query(ClassQuery::Binary("Z"))
        );
        assert_eq!(
            t(r"\p{gc=Separator}"),
            hir_uclass_query(ClassQuery::Binary("Z"))
        );
        assert_eq!(
            t(r"\p{Other}"),
            hir_uclass_query(ClassQuery::Binary("Other"))
        );
        assert_eq!(t(r"\pC"), hir_uclass_query(ClassQuery::Binary("Other")));

        assert_eq!(
            t(r"\PZ"),
            hir_negate(hir_uclass_query(ClassQuery::Binary("Z")))
        );
        assert_eq!(
            t(r"\P{separator}"),
            hir_negate(hir_uclass_query(ClassQuery::Binary("Z")))
        );
        assert_eq!(
            t(r"\P{gc!=separator}"),
            hir_negate(hir_uclass_query(ClassQuery::Binary("Z")))
        );

        assert_eq!(t(r"\p{any}"), hir_uclass_query(ClassQuery::Binary("Any")));
        assert_eq!(
            t(r"\p{assigned}"),
            hir_uclass_query(ClassQuery::Binary("Assigned"))
        );
        assert_eq!(
            t(r"\p{ascii}"),
            hir_uclass_query(ClassQuery::Binary("ASCII"))
        );
        assert_eq!(
            t(r"\p{gc:any}"),
            hir_uclass_query(ClassQuery::Binary("Any"))
        );
        assert_eq!(
            t(r"\p{gc:assigned}"),
            hir_uclass_query(ClassQuery::Binary("Assigned"))
        );
        assert_eq!(
            t(r"\p{gc:ascii}"),
            hir_uclass_query(ClassQuery::Binary("ASCII"))
        );

        assert_eq!(
            t_err(r"(?-u)\pZ"),
            TestError {
                kind: hir::ErrorKind::UnicodeNotAllowed,
                span: Span::new(
                    Position::new(5, 1, 6),
                    Position::new(8, 1, 9)
                ),
            }
        );
        assert_eq!(
            t_err(r"(?-u)\p{Separator}"),
            TestError {
                kind: hir::ErrorKind::UnicodeNotAllowed,
                span: Span::new(
                    Position::new(5, 1, 6),
                    Position::new(18, 1, 19)
                ),
            }
        );
        assert_eq!(
            t_err(r"\pE"),
            TestError {
                kind: hir::ErrorKind::UnicodePropertyNotFound,
                span: Span::new(
                    Position::new(0, 1, 1),
                    Position::new(3, 1, 4)
                ),
            }
        );
        assert_eq!(
            t_err(r"\p{Foo}"),
            TestError {
                kind: hir::ErrorKind::UnicodePropertyNotFound,
                span: Span::new(
                    Position::new(0, 1, 1),
                    Position::new(7, 1, 8)
                ),
            }
        );
        assert_eq!(
            t_err(r"\p{gc:Foo}"),
            TestError {
                kind: hir::ErrorKind::UnicodePropertyValueNotFound,
                span: Span::new(
                    Position::new(0, 1, 1),
                    Position::new(10, 1, 11)
                ),
            }
        );
    }

    #[test]
    #[cfg(not(feature = "unicode-gencat"))]
    fn class_unicode_gencat_disabled() {
        assert_eq!(
            t_err(r"\p{Separator}"),
            TestError {
                kind: hir::ErrorKind::UnicodePropertyNotFound,
                span: Span::new(
                    Position::new(0, 1, 1),
                    Position::new(13, 1, 14)
                ),
            }
        );

        assert_eq!(
            t_err(r"\p{Any}"),
            TestError {
                kind: hir::ErrorKind::UnicodePropertyNotFound,
                span: Span::new(
                    Position::new(0, 1, 1),
                    Position::new(7, 1, 8)
                ),
            }
        );
    }

    #[test]
    #[cfg(feature = "unicode-script")]
    fn class_unicode_script() {
        assert_eq!(
            t(r"\p{Greek}"),
            hir_uclass_query(ClassQuery::Binary("Greek"))
        );
        #[cfg(feature = "unicode-case")]
        assert_eq!(
            t(r"(?i)\p{Greek}"),
            hir_case_fold(hir_uclass_query(ClassQuery::Binary("Greek")))
        );
        #[cfg(feature = "unicode-case")]
        assert_eq!(
            t(r"(?i)\P{Greek}"),
            hir_negate(hir_case_fold(hir_uclass_query(ClassQuery::Binary(
                "Greek"
            ))))
        );

        assert_eq!(
            t_err(r"\p{sc:Foo}"),
            TestError {
                kind: hir::ErrorKind::UnicodePropertyValueNotFound,
                span: Span::new(
                    Position::new(0, 1, 1),
                    Position::new(10, 1, 11)
                ),
            }
        );
        assert_eq!(
            t_err(r"\p{scx:Foo}"),
            TestError {
                kind: hir::ErrorKind::UnicodePropertyValueNotFound,
                span: Span::new(
                    Position::new(0, 1, 1),
                    Position::new(11, 1, 12)
                ),
            }
        );
    }

    #[test]
    #[cfg(not(feature = "unicode-script"))]
    fn class_unicode_script_disabled() {
        assert_eq!(
            t_err(r"\p{Greek}"),
            TestError {
                kind: hir::ErrorKind::UnicodePropertyNotFound,
                span: Span::new(
                    Position::new(0, 1, 1),
                    Position::new(9, 1, 10)
                ),
            }
        );

        assert_eq!(
            t_err(r"\p{scx:Greek}"),
            TestError {
                kind: hir::ErrorKind::UnicodePropertyNotFound,
                span: Span::new(
                    Position::new(0, 1, 1),
                    Position::new(13, 1, 14)
                ),
            }
        );
    }

    #[test]
    #[cfg(feature = "unicode-age")]
    fn class_unicode_age() {
        assert_eq!(
            t_err(r"\p{age:Foo}"),
            TestError {
                kind: hir::ErrorKind::UnicodePropertyValueNotFound,
                span: Span::new(
                    Position::new(0, 1, 1),
                    Position::new(11, 1, 12)
                ),
            }
        );
    }

    #[test]
    #[cfg(feature = "unicode-gencat")]
    fn class_unicode_any_ine_ancge       :e ])
        );
      w(11, 1, 12)3 12)
 0       ;
 [test]
    #[cfg(not(feature = "unicode-script"))]
    fnge")3.0            }
        );

        assert_eq!(
            t_err(r"\p{scx:Greek}"),
            TestError {
                kind: hir::ErrorKind::UnicodePropertyNotFound,
                span: Span::new(
                    Position::new(0, 1, 1),
                    Position::new(2)3 12)
 bracketd others
    // match non-AS"[a]   );
        assert_eq!(t("(?:)"), HiAS"[ab)
    #[test]
    fnaclass(&[(sert_eq!(t("(?:)"), HiAS"[^[a])
    12)
 -case")est]
    fnaclas_cat(vsert_eq!(t("(?:)"), HiAS"[a-z)
    #[test]
    fnaclasz(&[(sert_eq!(t("(?:)"), HiAS"[a-fd-h)
    #[test]
    fnaclash(&[(sert_eq!(t("(?:)"), HiAS"[a-fg-m)
    #[test]
    fnaclasm', hir_cat(vec![a(), b()])));
[\x00]t("(?s)."), hir_uclass(&[(0', hir_cat(vec![a(), b()])));
[\n]t("(?s)."), hir_uclans(&[(n(&[(sert_eq!(t("(?:)"), HiAS"[\n]t("(?s)."), hir_uclans(&[(n(&[(sert_eq!(t(w(2, 1,ny     ),
            }
   , 
                ),
            }
vec![a(), b()])));
[\d]")]
    fn class_perl_unicode() {
        // Unicode
       r properties should give us the one giant
        // letter property.
 [\pZ]   #[cfg(feature = "unicode-case")]
        assert_eq!class_un       t(r"\p{Greek}"),
            hir_uclass_qus the one giant
        // letter property.
 [\pry(ClassQue]   #[cfg(feature = "unicode-case")]
        assert_eq!class_un       t(r"\p{Greek}"),
     ,ny     ),
            }
   , 
                ),
            }
vec![a(), b()])));
[^\D]")]
    fn class_perl_unicode() {
        // Unicode
       r properties should give us the one giant
        // letter property.
 [^\PZ]   #[cfg(feature = "unicode-case")]
        assert_eq!class_un       t(r"\p{Greek}"),
            hir_uclass_qus the one giant
        // letter property.
 [^uery(ClassQue]   #[cfg(feature = "unicode-case")]
        assert_eq!class_un       t(r"\p{Greek}"),
     , 3)
        new(2fold(hir_uclass_query(C #[cfg(feature,ny     ),
            }
   , 
                ),
           t(r"\plassQuery::Binary("Greek")))
        );
   [^\D]")]#[cfg(feature = "unicode-case")]
        assert_eq!(
            t(r"(?i)\d"),
     , 3)2fold(hir_uclass_query(C  
                ),
            }
ry::Binary("Greek")))
        );
   [^\P{g ),
 ]g(feature = "unicode-case")]
        assert_eq!(
            t(r"(?g)\p{Greek}"),
      :Look::End));
        assFF}'a]   );
  t_eq!(
        hir_cat(vodeNegate));
        assert_eq[\x00]t("(?s).ir_bclass(&[(b'\0', 0', hir_cat(vec![a(), b()]))ass(&ast::Clas[are it("(?s).ir_bclass(&[(])|[-\xFF])|[A-Z   :Look::En hir_negate(hir_uclass_query(ClassQuery::Binary("space;
   [a]       t("(?i)(?-i:a)a"),
            hir            hir_negate(hir_ascii_uclass(&ast::ClassAsciiKind::Lower))
        );
   k]β"),);
    }

    #[test]
    K    K
     k    k {
           ('a', 'z'),
   , ('a', 'a')]),
                ]),
                hir_lit("a"),
            ])
        );
  [β]β"),);
    }

    #[test]
    Βbclas�    hir�bclas�    hiϐbclaϐb t("ab?"),
            hir_cat(vec![hir      kit("(?s).ir_bclass(&[K[-\xFK]|(?-u:k[-\xFkxFF'),]));
      "(?:)"), HiAS"[^a)
    12)
 -case")est]
    fnaclas_cat(vsert_eq!(t("(?:)"), HiAS
 [^ux00]t("( 12)
 -case")est]
    fnass(&[(0', hi              hir_uclass(&[('\u{80}', '\u{10FFFF}'^a)
  ss(&[('\u{80} 12)
 -case")t_eq!(
        hir_cat(v    t(r"\p{Greek}"),
     ,ny     ),
            }
   , 
                ),
            }
vec![a(), b()])etter property.
 [^ud]   #[cfg(feature = "unicode-case")]
        assert_eq!(
            t(r"(?i)\D"),
            hir_negate(hir_uclass_quus the one giant
        // letter property.
 [^upZ]   #[cfg(feature = "unicode-case")]
        assert_eq!(
         class_un   (?i)\D"),
            hir_negate(hir_uclass_quus the one giant
        // letter property.
 [^upry(ClassQue]   #[cfg(feature = "unicode-case")]
        assert_eq!(
         class_un   (?i)\D"),
            hir_n, 3)2fold(hir_uclass_query(C  
                ),
            }
ry::Binary("Greek")))
        );
   [^\p{g ),
 ]g(feature = "unicode-case")]
        assert_eq!(
            t(r"(?i)\P{Greek}"),
            hgr_negate(hir_case_fold(hir_uclass_         hir_n, 3)2fold(hir_uclass_query(C  
                ),
            }
ry::Binary("Greek")))
        );
   [\P{g ),
 ]g(feature = "unicode-case")]
        assert_eq!(
            t(r"(?i)\P{Greek}"),
            hgr_negate(hir_case_fold(hir_uclass_.
        //       ])
weird;

  an truly match invalidy.
 [\[]       t("(?i)(?-i:[s(&[[[A-Z   :Look::Entch invalidy.
 [&]       t("(?i)(?-i:&s(&[&', hir_cat(vec![a(), b()])));
[\&]       t("(?i)(?-i:&s(&[&', hir_cat(vec![a(), b()])));
[\&\&]       t("(?i)(?-i:&s(&[&', hir_cat(vec![a(), b()])));
[\x00-&]t("(?s)."), hir_uclass(&[&', hir_cat(vec![a(), b()])));
[&-are it("(?s).("(?i)(?-i:&s(&[, '&ast::C   :Look::Entch invalidy.
 [~it("(?s).("(?i)(?-i:~s(&[~', hir_cat(vec![a(), b()])));
[\~it("(?s).("(?i)(?-i:~s(&[~', hir_cat(vec![a(), b()])));
[\~\~it("(?s).("(?i)(?-i:~s(&[~', hir_cat(vec![a(), b()])));
[\x00-~]t("(?s)."), hir_uclass(&[~', hir_cat(vec![a(), b()])));
[~-are it("(?s).("(?i)(?-i:~s(&[, '&ast::C   :Look::Entch invalidy.
 [-it("(?s).("(?i)(?-i:-s(&[-', hir_cat(vec![a(), b()])));
[\-it("(?s).("(?i)(?-i:-s(&[-', hir_cat(vec![a(), b()])));
[\-\-it("(?s).("(?i)(?-i:-s(&[-', hir_cat(vec![a(), b()])));
[\x00-\-it("(?s).("(?i)(?-i:ass(&[-', hir_cat(vec![a(), b()])));
[\--are it("(?s).("(?i)(?-i:-s(&[, '&ast::C   :Look::Entch invalidhir_ascii_bclass(&ast::Cla^a)
  ss(&[('\u{80} },
        );
        assert_eq!(
            t_err(r"(?-u)\W"),
            TestError {
                kind: hir::ErrorKind::InvalidUtf8,
                span: Span::new(
                    Position::new(0, 1, 1),
          reek}"),
     ,ny     ),
            }
   , 
                ),  #[tes    }
vec![a(), b()])));
[^\s\S]de-gencat")]
    fn class_u}"),
     ,ny     ),
            }
   , 
                ),  #[tes    }
vec![a(), b()]))ass(&ast::Clas[^\s\S]de-gencab")]
    fn class_unicode_any_ine_ancg2)3 12)
 bracketd assert_thers
    // match non-AS"[a-zde.)
    #[test]
    fn cat_class_flattened() {
         hir_negate(hir_uclass_quus the one giant
        // letter property.
 [aupZb
        );
        assert_eq!(
            t_byest]
    fnaclass(&[(      hir_union(
           e-case")]
        assert_eq!class_un       t(r"\     (hir_uclass_         hir_n, 3)2fold(hir_uclass_quus the   
                ),
            }
ry::Binary("Greek")))
        );[\pZ fn class
        );
        assert_eq!(
            t_byest]
 ert_eq!(
            t(r"(?g)\p{Gre      hir_union(
           e-case")]
        assert_eq!class_un       t(r"\     (hir_uclass_         hir_n, 3)
        new(2fold(hir_uclass_qu  w(,
        new(2fold(hir_uclass_quus the  
        new(2fold(hir_uclass_qu
          t(r"\plassQuery::Binary("Greek")))
        );[ fnge")3.0 \pZ fn class
        );
        assert_eq!(
            t_byest]
 ert_eq!(
           ,
       );
        asserrrrrg all ofec![
: "  w(,
        new(sserrrrrg all ofev    : "3.0(,
        new(sser}e      hir_union(
      sert_eq!(
                t_byest]
 ert_eq!(
            t(r"(?g)\p{Gre      hir_union(
 n(
           e-case")]
        assert_eq!class_un       t(r"\         (hir_ucla     (hir_uclass_         hir_n, 3)
        new(2fold(hir_uclass_qu  w(,
        new(2fold(hir_uclass_quus the  
        new(2fold(hir_uclass_qu
          t(r"\plassQuery::Binary("Greek")))
        );[[[ fnge")3.0 \pZ] fn class
[ fnCyrillic}]
        );
        assert_eq!(
            t_byest]
 ert_eq!(
           ,
       );
        asserrrrrg all ofec![
: "  w(,
        new(sserrrrrg all ofev    : "3.0(,
        new(sser}e      hir_union(
      sert_eq!(
                t_byest]
 ert_eq!(
         assert_eqcyrillicGre      hir_union(
 n(
      sert_eq!(
                    t_byest]
 ert_eq!(
            t(r"(?g)\p{Gre      hir_union(
 n(
 n(
           e-case")]
        assert_eq!class_un       t(r"\             (hir_ucla         (hir_ucla     (hir_uclass__         hir_n, 3)
        new(2fold(hir_uclass_qu  w(,
        new(2fold(hir_uclass_query(C #[cfg(feature2fold(hir_uclass_quus the  
        new(2fold(hir_uclass_qu
          t(r"\plassQuery::Binary("Greek")))
        );
   [\fnge")3.0 \pZ fn class
        );
        a      assert_eqsert_eq!(
            t_byest]
 ert_eq!(
           ,
       );
        asserrrrrg all ofec![
: "  w(,
        new(sserrrrrg all ofev    : "3.0(,
        new(sser}e      hir_union(
      sert_eq!(
                t_byest]
 ert_eq!(
            t(r"(?g)\p{Gre      hir_union(
 n(
           e-case")]
        assert_eq!class_un       t(r"\         (hir_ucla      (hir_uclass_         hir_n, 3)
        new(2fold(hir_uclass_qu  w(,
        new(2fold(hir_uclass_quus the  
        new(2fold(hir_uclass_qu
          t(r"\plassQuery::Binary("Greek")))
        );[^\fnge")3.0 \pZ fn class
        );
        aunicode-casesert_eq!(
            t_byest]
 ert_eq!(
           ,
       );
        asserrrrrg all ofec![
: "  w(,
        new(sserrrrrg all ofev    : "3.0(,
        new(sser}e      hir_union(
      sert_eq!(
                t_byest]
 ert_eq!(
            t(r"(?g)\p{Gre      hir_union(
 n(
           e-case")]
        assert_eq!class_un       t(r"\         (hir_ucla      (hir_uclass_         hir_n, 3)
        new(2fold(hir_uclass_qu  w(,
        new(2fold(hir_uclass_query(C #[cfg(feature2fold(hir_uclass_quus the  
        new(2fold(hir_uclass_qu
          t(r"\plassQuery::Binary("Greek")))
        );
   [^\fnge")3.0 \pZ fn class
        );
        aunicode-cas      assert_eqsert_eq!(
            t_byest]
 ert_eq!(
           ,
       );
        asserrrrrg all ofec![
: "  w(,
        new(sserrrrrg all ofev    : "3.0(,
        new(sser}e      hir_union(
      sert_eq!(
                t_byest]
 ert_eq!(
            t(r"(?g)\p{Gre      hir_union(
 n(
           e-case")]
        assert_eq!class_un       t(r"\         (hir_ucla      )
                    Position::new(2)3 12)
 bracketd aunstd others
    // match non-ASCII [^c])
    12)
 -case")est]
    fncclasccat(vsert_eq!(t("(?:)"), HiAS
 [a-b[^c])
    12)
 -case")est]
    fncclasccat(vsert_eq!(t("(?:)"), HiAS
 [a-c[^c])
    12)
 -case")est]
    ])C   :Look::Entch invalidy.
 [^ [^c])
   t_byest]
    fncclasccat(vert_eq!(t("(?:)"), HiAS
 [^a-b[^c])
   t_byest]
    fncclasccat(ver       hir_case_fold(hir_uclass_query(ClassQuery::Binary("Greek")))
        );
   I [^c])
       );
        aunicode 12)
       asseest]
    fncclasccat(vsk}"),
            hir_case_fold(hir_uclass_query(ClassQuery::Binary("Greek")))
        );
   [a-b[^c])
       );
        aunicode 12)
       asseest]
    fncclasccat(vsk}"),
                hir_negate(hir_uclass_query(ClassQuery::Binary("space")))
 [^ [^c])
   t_byest]
    fnCclasClass_fcclasccat(vert_eq!(t(r_case_fold(hir_uclass_query(ClassQuery::Binary("Greek")))
        );
   [^a-b[^c])
       );
        aest]
    fnCclasClass_fcclasccat(eparator}"),
            hir_negate([^a-c[^c])
   t_byest]
    fn class_u}"),
     egate(hir_uclass_query(ClassQuery::Binary("space")))
 [^ -c[^c])
   t_byest]
    fn class_u     Position::new(2)3 12)
 bracketd aintersect_thers
    // match non-AS"[abc&&b-c)
   t_byest]
    fnbclasccat(vert_eq!(t("(?:)"), HiAS"[abc&&[b-c))
   t_byest]
    fnbclasccat(vert_eq!(t("(?:)"), HiAS"[[abc]&&[b-c))
   t_byest]
    fnbclasccat(vert_eq!(t("(?:)"), HiAS"[a-z&&b-y&&c-x)
   t_byest]
    fncclasxcat(vert_eq!(t("(?:)"), HiAS"[c-da-b&&a-d)
    #[test]
    fnaclasdcat(vert_eq!(t("(?:)"), HiAS"[a-d&&c-da-b)
    #[test]
    fnaclasdcat(vert_eq!(t("(?:)"), HiASr"[a-z&&a-c)
   t_byest]
    fnaclasccat(vert_eq!(t("(?:)"), HiAS
 [[a-z&&a-c))
   t_byest]
    fnaclasccat(vert_eq!(t("(?:)"), HiAS
 [^[a-z&&a-c))
   t_byunicode-case")]
    fnaclasccat(v   :Look::End));
        assFF}'abc&&b-c)
   t_byt_eq!(
     b  hirccat(vert_eq!(t("(?:)"), HiAS"ssFF}'abc&&[b-c))
   t_byt_eq!(
     b  hirccat(vert_eq!(t("(?:)"), HiAS"ssFF}'[abc]&&[b-c))
   t_byt_eq!(
     b  hirccat(vert_eq!(t("(?:)"), HiAS"ssFF}'a-z&&b-y&&c-x)
   t_byt_eq!(
     c  hirxcat(vert_eq!(t("(?:)"), HiAS"ssFF}'c-da-b&&a-d)
    #[tt_eq!(
        hirdcat(vert_eq!(t("(?:)"), HiAS"ssFF}'a-d&&c-da-b)
    #[tt_eq!(
        hirdcat(ver),
                ]),
                hir_lit("a"),
            ])
        );
  [abc&&b-c)
  eature = "unicode-case")]
        ass   fnbclasccat(v('a', 'a')]),
                ]),
                hir_lit("a"),
            ])
        );
  [abc&&[b-c))
  eature = "unicode-case")]
        ass   fnbclasccat(v('a', 'a')]),
                ]),
                hir_lit("a"),
            ])
        );
  [[abc]&&[b-c))
  eature = "unicode-case")]
        ass   fnbclasccat(v('a', 'a')]),
                ]),
                hir_lit("a"),
            ])
        );
  [a-z&&b-y&&c-x)
  eature = "unicode-case")]
        ass   fncclasxcat(v('a', 'a')]),
                ]),
                hir_lit("a"),
            ])
        );
  [c-da-b&&a-d)
  eature = "unicode-case")]
        ass   fnaclasdcat(v('a', 'a')]),
                ]),
                hir_lit("a"),
            ])
        );
  [a-d&&c-da-b)
  eature = "unicode-case")]
        ass   fnaclasdcat(v('a', 'a')])wer:]]"),
            hir_ascii_bclass(&astabc&&b-c)
  eature = "unicode-case")]
     t_eq!(
     b  hirccat(v"(?-u)[[:lower:]]"),
            hir_ascii_bclass(&astabc&&[b-c))
  eature = "unicode-case")]
     t_eq!(
     b  hirccat(v"(?-u)[[:lower:]]"),
            hir_ascii_bclass(&ast[abc]&&[b-c))
  eature = "unicode-case")]
     t_eq!(
     b  hirccat(v"(?-u)[[:lower:]]"),
            hir_ascii_bclass(&asta-z&&b-y&&c-x)
  eature = "unicode-case")]
     t_eq!(
     c  hirxcat(v"(?-u)[[:lower:]]"),
            hir_ascii_bclass(&astc-da-b&&a-d)
  eature = "unicode-case")]
     t_eq!(
        hirdcat(v"(?-u)[[:lower:]]"),
            hir_ascii_bclass(&asta-d&&c-da-b)
  eature = "unicode-case")]
     t_eq!(
        hirdcat(v"(?-u)[[:lowd::Word))
     `[a^]`, `^` does  }
 needon obe escapi_bcso it maks(&[ense_uclad::Word))
  `^` [A-Z]so a}"),
 on obe unescapi_ afinin`&&`n truly match invalidy.
 [\^&&^)
   t_byest]
    fn^clas^ed() {
        ass`]` needson obe escapi_ afinin`&&`n otce it's  }
 at starta-z]t to a truly match invalidy.
 []&&\))
   t_byest]
    fn]clas]cat(vert_eq!(t("(?:)"), HiAS
 [-&&-it("(?s).("(?i)(?-i:-s(&[-', hir_cat(vec![a(), b()])));
[\&&&&]       t("(?i)(?-i:&s(&[&', hir_cat(vec![a(), b()])));
[\&&&\&]       t("(?i)(?-i:&s(&[&', hir_cat(vec! //     precedetce.e giant
        // letter property.
 [a-w&&[^c-g]z)
       );
        aest]
    fnaclass(&ss_fhclaswcat(eparator}"),ss_u     Position::new(2)3 12)
 bracketd aintersectyunicodethers
    //hir_bclass(&[(0x80, 0xFF)]),
        ry::Binary("Greek")))
        );[^\w&&ud]   #[cfg(feature = "unicode-case")]
        assert_eq!(
            t(r"(?i)\D"),
           "(?:)"), HiAS
 [^[a-z&&a-c))
   t_byunicode-case")]
    fnaclasccat(v   s
    //hir_bclass(&[(0x80, 0xFF)]),
        ry::Binary("Greek")))
        );[^[\w&&ud]]   #[cfg(feature = "unicode-case")]
        assert_eq!(
            t(r"(?i)\D"),
            hir_negate(hir_uclass_qu]),
        ry::Binary("Greek")))
        );[^[^\w&&ud]]   #[cfg(feature = "unicode-case")]
        assert_eq!(
            t(r"(?i)\d"),
            hir_uclass_q]),
        ry::Binary("Gre  );[[[^\w]&&[^ud]))
   t_byunicode-case")]
 ture = "unicode-          hir_negate(hir_uclass_qu]),
        ry::Binary("Greek")))
       ass(&ast::Clas[^\w&&ud]   #[cfg(feature = "unicode-cas      assert_eq!(
            t_bytes(r"(?-u)\D"),
            hir_negate(hir_ascii_bclass(&ast::Clas[^[a-z&&a-c))
  #[cfg(feature = "unicode-cast_eq!(
        hirccat(v"(?-u)[[:lower:]]"),
            hir_ascii_bcass(&ast::Clas[^[\w&&ud]]   #[cfg(feature = "unicode-cas      assert_eq!(
            t_bytes(r"(?-u)\D"),
            hir_negate(hir_ascii_bclass(&ast::Clas[^[^\w&&ud]]   #[cfg(feature = "d)
        );
        assert_eq!(
            t(r"(?i-u)\d"),
            hir_ascii_bcass(&ast::Clas[[[^\w]&&[^ud]))
  iKind::Space))
        );
        assert_eq!(
            t_bytes(r"(?-u)\W"),
           Position::new(2)3 12)
 bracketd adifferetceethers
    //hir_bclass(&[(0x80, 0xFF)us the one giant
        // letter property.
 [\pL--[:     ),
        );
        adifferetcee     hir_union(
           e-case")]
        assert_eqlett           hir_union(
                hss(&[(x7Fcat(eparator}     (hir_uclass__        
            hir_ascii_bclass(&as')]),pha:]--[:ClassAsciiKind::Lower)
     t_eq!(
     A  hirZcat(eparator}"),ss_u     Position::new(2)3 12)
 bracketd asymmetricadifferetceethers
    //hir_bclass(&[(0x80, 0xFF)  ),
         nt
        // letter property.
 [\pryc   ),
 ~~         ),
 ciiKind::Lower)
  //)]
  ({ind::Lower)
  //////'·'..='·',ind::Lower)
  //////'\u{300}'..='\u{301}',ind::Lower)
  //////'\u{304}'..='\u{304}',ind::Lower)
  //////'\u{306}'..='\u{306}',ind::Lower)
  //////'\u{308}'..='\u{308}',ind::Lower)
  //////'\u{313}'..='\u{313}',ind::Lower)
  //////'\u{342}'..='\u{342}',ind::Lower)
  //////'\u{345}'..='\u{345}',ind::Lower)
  //////'ʹ'..='ʹ',ind::Lower)
  //////'\u{1dc0}'..='\u{1dc1}',ind::Lower)
  //////'⁝'..='⁝',ind::Lower)
  //})ature = "unicode-case")]
        assert_eq!(
·',/'·' ('A', 'Z'),
           0300}'(&[, '0301}' ('A', 'Z'),
           0304}'(&[, '0304}' ('A', 'Z'),
           0306}'(&[, '0306}' ('A', 'Z'),
           0308}'(&[, '0308}' ('A', 'Z'),
           0313}',     0313}' ('A', 'Z'),
           0342}',     0342}' ('A', 'Z'),
           0345}',     0345}' ('A', 'Z'),
        ʹ',/'ʹ'           hir_uclass(&[
DCascii_uclaDC1}' ('A', 'Z'),
        ⁝',/'⁝'               ('\u{17F}', '\t_eq!(t("(?:)"), HiASr"[a-g~~c-j)
    #[test]
    fnaclass(&ss_fhclasjt::C   :Look::Entch invalidhir_ascii_bclalass(&as'a-g~~c-j)
  ind::Lower)
     t_eq!(
        hirb]|(?-u:h  hirjcat(eparator}"),ss_u     Position::new(2)3ignore_whitioeatuothers
    // match non-ASCI(?x)\12 3   );
       \n3"(vodeNegate));
        assertx)\x { 53 }   );
       S")(?i-u)\s"),
            hir_ascii_bclass(x)\x # comment
{ # comment
ii_b53 # comment
} #comment
  ind::Lower)
          S")eparator}"),
            hir_negate(s(x)\x 53   );
       S")(?i-u)\s"),
            hir_ascii_bclass(x)\x # comment
_ascii_b53 # comment
  ind::Lower)
          S")eparator}"),            hir_negate(s(x)\x5 3   );
       S")(?irs
    //hir_bclass(&[(0x80, 0xFF)us the one giant
        // letter property.
 s(x)\p # comment
{ # comment
ii_b class_un # comment
} # comment
  ind::Lower)
     unicode-case")]
        assert_eq!class_un       t(r"\p{Ge giant
        // letter property.
 s(x)a # comment
{ # comment
ii_b5 # comment
ii_b, # comment
ii_b10 # comment
} # comment
  ind::Lower)
     range(true, 5, Some(10  );
        asseparator}"),
            hir_negate(s(x)a\//h);
     e   );
         "ode-case")]
        assert_eq!analysis_is_utf8ir_negate(hir_ucn: Spave exampl an truly match in!(g alsass(&ast: as.is_utf8ir"),            hi!(g alsass(&ast: bas.is_utf8ir"),            hi!(g alsass(&ast:s(&asaas.is_utf8ir"),            hi!(g alsass(&ast:s(&asabas.is_utf8ir"),            hi!(g alsass(&ast:are as.is_utf8ir"),            hi!(g alsass(&ast:are are as.is_utf8ir"),            hi!(g alsass(&ast:a^a)
 .is_utf8ir"),            hi!(g alsass(&ast:a^a)a^a)
 .is_utf8ir"),            hi!(g alsass(&ast:\bas.is_utf8ir"),            hi!(g alsass(&ast:aBas.is_utf8ir"),            hi!(g alsass(&ast:s(&as\bas.is_utf8ir"),            hi!(g alsass(&ast:s(&asaBas.is_utf8ir"),egate(hir_ucN   //ve exampl an truly match in!(!g alsass(&ast:s(&asare as.is_utf8ir"),            hi!(!g alsass(&ast:s(&asare are as.is_utf8ir"),            hi!(!g alsass(&ast:s(&asa^a)
 .is_utf8ir"),            hi!(!g alsass(&ast:s(&asa^a)a^a)
 .is_utf8ir"),    ")]
        assert_eq!analysis_caps(&[s_let_thers
    // match non-0,rg alast: as.explicit_caps(&[s_let_t"),            hir_neg0,rg alast:(?:a)as.explicit_caps(&[s_let_t"),            hir_neg0,rg alast:(?i-u:a)as.explicit_caps(&[s_let_t"),            hir_neg0,rg alast:(?i-u) as.explicit_caps(&[s_let_t"),            hir_neg1,rg alast:(a)as.explicit_caps(&[s_let_t"),            hir_neg1,rg alast:(?P<foo>a)as.explicit_caps(&[s_let_t"),            hir_neg1,rg alast:()as.explicit_caps(&[s_let_t"),            hir_neg1,rg alast:() as.explicit_caps(&[s_let_t"),            hir_neg1,rg alast:(a)+as.explicit_caps(&[s_let_t"),            hir_neg2,rg alast:(a)(b)as.explicit_caps(&[s_let_t"),            hir_neg2,rg alast:(a)|(b)as.explicit_caps(&[s_let_t"),            hir_neg2,rg alast:((a))as.explicit_caps(&[s_let_t"),            hir_neg1,rg alast:([a&&b])as.explicit_caps(&[s_let_t"),    ")]
        assert_eq!analysis_st //c_caps(&[s_let_thers
    //let/len(0x|patt  n|rg alaspatt  n).st //c_explicit_caps(&[s_let_t),            hir_negSome(0  )let_r"")(?i-u)\s"),
          Some(0  )let_r"foo|bar")(?i-u)\s"),
          None )let_r"(foo)|bar")(?i-u)\s"),
          None )let_r"foo|(bar)")(?i-u)\s"),
          Some(1) )let_r"(foo|bar)")(?i-u)\s"),
          Some(1) )let_r"(a|b|c|d|e|f)")(?i-u)\s"),
          Some(1) )let_r"(a)|(b)|(c)|(d)|(e)|(f)")(?i-u)\s"),
          Some(2) )let_r"(a)(b)|(c)(d)|(e)(f)")(?i-u)\s"),
          Some(6) )let_r"(a)(b)(c)(d)(e)(f)")(?i-u)\s"),
          Some(3) )let_r"(a)(b)(extra)|(a)(b)()")(?i-u)\s"),
          Some(3) )let_r"(a)(b)((?:extra)?)")(?i-u)\s"),
          None )let_r"(a)(b)(extra)?")(?i-u)\s"),
          Some(1) )let_r"(foo)|(bar)")(?i-u)\s"),
          Some(2) )let_r"(foo)(bar)")(?i-u)\s"),
          Some(2) )let_r"(foo)+(bar)")(?i-u)\s"),
          None )let_r"(foo)*(bar)")(?i-u)\s"),
          Some(0) )let_r"(foo)?{0   (?i-u)\s"),
          None )let_r"(foo)?{1}")(?i-u)\s"),
          Some(1) )let_r"(foo){1}")(?i-u)\s"),
          Some(1) )let_r"(foo){1,}")(?i-u)\s"),
          Some(1) )let_r"(foo){1,}?  (?i-u)\s"),
          None )let_r"(foo){1,}??  (?i-u)\s"),
          None )let_r"(foo){0,}")(?i-u)\s"),
          Some(1) )let_r"(foo)(?:bar)")(?i-u)\s"),
          Some(2) )let_r"(foo(?:bar)+)(?:baz(boo))")(?i-u)\s"),
          Some(2) )let_r"(?P<bar>foo)(?:bar)(bal|loon)")(?i-u)\s"),
            hir_ascii_bSome(2)   hir_ascii_blet_r#"<(a)[^>]+href=:([^"]+)"|<(img)[^>]+src=:([^"]+)""#(eparator}"),ss_u     Position::new(2)3analysis_is_all_
     ionsir_negate(hir_ucn: Spave exampl an truly malet/p(0xg alast:\bas),            hi!(!g.look_set( .is_

    #(?i-u)\s"),
          p.minimum_let_t, Some(0r"),egate(hirlet/p(0xg alast:\Bas),            hi!(!g.look_set( .is_

    #(?i-u)\s"),
          p.minimum_let_t, Some(0r"),egate(hirlet/p(0xg alast:^as),            hi!(!g.look_set( .is_

    #(?i-u)\s"),
          p.minimum_let_t, Some(0r"),egate(hirlet/p(0xg alast:$as),            hi!(!g.look_set( .is_

    #(?i-u)\s"),
          p.minimum_let_t, Some(0r"),egate(hirlet/p(0xg alast:\Aas),            hi!(!g.look_set( .is_

    #(?i-u)\s"),
          p.minimum_let_t, Some(0r"),egate(hirlet/p(0xg alast:\zas),            hi!(!g.look_set( .is_

    #(?i-u)\s"),
          p.minimum_let_t, Some(0r"),egate(hirlet/p(0xg alast:$^\z\A\b\Bas),            hi!(!g.look_set( .is_

    #(?i-u)\s"),
          p.minimum_let_t, Some(0r"),egate(hirlet/p(0xg alast:$|^|\z|\A|\b|\Bas),            hi!(!g.look_set( .is_

    #(?i-u)\s"),
          p.minimum_let_t, Some(0r"),egate(hirlet/p(0xg alast:^$|$^as),            hi!(!g.look_set( .is_

    #(?i-u)\s"),
          p.minimum_let_t, Some(0r"),egate(hirlet/p(0xg alast:((\b)+())*^as),            hi!(!g.look_set( .is_

    #(?i-u)\s"),
          p.minimum_let_t, Some(0r"),egate(hir_ucN   //ve exampl an truly malet/p(0xg alast:^aas),            hi!(!g.look_set( .is_

    #(?i-u)\s"),
          p.minimum_let_t, Some(1t"),    ")]
        assert_eq!analysis_look_set_prefix    _thers
    //let/p(0xg alast:((&as(?i:(?:\b|_)win(?:32|64|dows)?(?:\b|_))as),            hi!(g.look_set_prefix    _t.containsiLookytes(r     ode-case")]
        assert_eq!analysis_is_anchord others
    //let/is_st rt(0x|p|rg alasp).look_set_prefix_t.containsiLookytSt rts),        let/is_end(0x|p|rg alasp).look_set_suffix_t.containsiLookytEnd"),egate(hir_ucn: Spave exampl an truly match in!(is_st rtst:^ass),            hi!(is_endst:$as"),
            hi!(is_st rtst:^^ass),            hi!(g alast:$$as.look_set_suffix_t.containsiLookytEnd""),
            hi!(is_st rtst:^$ass),            hi!(is_endst:^$as"),
            hi!(is_st rtst:^fooass),            hi!(is_endst:foo$as"),
            hi!(is_st rtst:^foo|^bar")(?i-u)\s"),
     !(is_endst:foo$|bar$as"),
            hi!(is_st rtst:^(foo|bar)")(?i-u)\s"),
     !(is_endst:(foo|bar)$as"),
            hi!(is_st rtst:^+ass),            hi!(is_endst:$+ass),            hi!(is_st rtst:^++ass),            hi!(is_endst:$++ass),            hi!(is_st rtst:(^)+ass),            hi!(is_endst:($)+ass),,            hi!(is_st rtst:$^ass),            hi!(is_st rtst:$^ass),            hi!(is_st rtst:$^|^$ass),            hi!(is_endst:$^|^$ass),,            hi!(is_st rtst:\b^ass),            hi!(is_endst:$\bass),            hi!(is_st rtst:^(?m:^)")(?i-u)\s"),
     !(is_endst:(?m:$)$ass),            hi!(is_st rtst:(?m:^)^ass),            hi!(is_endst:$(?m:$)"r"),egate(hir_ucN   //ve exampl an truly match in!(!is_st rtst:(?m)^ass),            hi!(!is_endst:(?m)$ass),            hi!(!is_st rtst:(?m:^$)|$^ass),            hi!(!is_endst:(?m:^$)|$^ass),            hi!(!is_st rtst:$^|(?m:^$)ass),            hi!(!is_endst:$^|(?m:^$)ass),,            hi!(!is_st rtst:a^ass),            hi!(!is_st rtst:$aass),,            hi!(!is_endst:a^ass),            hi!(!is_endst:$aass),,            hi!(!is_st rtst:^foo|bar")(?i-u)\s"),
     !(!is_endst:foo|bar$as"),
            hi!(!is_st rtst:^*ass),            hi!(!is_endst:$*ass),            hi!(!is_st rtst:^*+ass),            hi!(!is_endst:$*+ass),            hi!(!is_st rtst:^+*ass),            hi!(!is_endst:$+*ass),            hi!(!is_st rtst:(^)*ass),            hi!(!is_endst:($)*"ode-case")]
        assert_eq!analysis_is_any_anchord others
    //let/is_st rt(0x|p|rg alasp).look_set_t.containsiLookytSt rts),        let/is_end(0x|p|rg alasp).look_set_t.containsiLookytEnd"),egate(hir_ucn: Spave exampl an truly match in!(is_st rtst:^ass),            hi!(is_endst:$as"),            hi!(is_st rtst:\Aass),            hi!(is_endst:\zas"),egate(hir_ucN   //ve exampl an truly match in!(!is_st rtst:(?m)^ass),            hi!(!is_endst:(?m)$ass),            hi!(!is_st rtst:$ass),            hi!(!is_endst:^"r"),    ")]
        assert_eq!analysis_can}

    #[test]
    _ucn: Spave exampl an truly malet/
       
    =  hir_ascii_b|p|r
          Some(0) )g alsass(&asp).minimum_let_t(?i-u)\s"),
       
    r"")?i-u)\s"),
       
    r"()")?i-u)\s"),
       
    r"()*")?i-u)\s"),
       
    r"()+")?i-u)\s"),
       
    r"()?")?i-u)\s"),
       
    r"a*")?i-u)\s"),
       
    r"a?")?i-u)\s"),
       
    r"a{0   ?i-u)\s"),
       
    r"a{0,   ?i-u)\s"),
       
    r"a{0,1   ?i-u)\s"),
       
    r"a{0,10   ?i-u)\s"),hir_bclass(&[(0x80, 0xFF)us the one giant
        /
    r"\pL*")?i-u)\s"),
       
    r"a*|b")?i-u)\s"),
       
    r"b|a*")?i-u)\s"),
       
    r"a|")?i-u)\s"),
       
    r"|a")?i-u)\s"),
       
    r"a||b")?i-u)\s"),
       
    r"a*a?(abcd)*")?i-u)\s"),
       
    r"^")?i-u)\s"),
       
    r"$")?i-u)\s"),
       
    r"(?m)^as?i-u)\s"),
       
    r"(?m)$")?i-u)\s"),
       
    r"\Aas),            hi  
    r"\zas),            hi  
    r"\Bas?i-u)\s"),
       
    r"(?&asaBas),            hi  
    r"\bas?i-u)\s"),
       
    r"(?&asabas?iegate(hir_ucN   //ve exampl an truly malet/
      non  
    =  hir_ascii_b|p|r
      ne  Some(0) )g alsass(&asp).minimum_let_t(?i-u)\s"),
      non  
    r"a+")?i-u)\s"),
      non  
    r"a{1   ?i-u)\s"),
      non  
    r"a{1,   ?i-u)\s"),
      non  
    r"a{1,2   ?i-u)\s"),
      non  
    r"a{1,10   ?i-u)\s"),
      non  
    r"b|a")?i-u)\s"),
      non  
    r"a*a+(abcd)*")?i-u)\s"),hir_bclass(&[(0x80, 0xFF)us the one giant
        non  
    r" "unicode?i-u)\s"),
      non  
    r"[a--a)
 ?i-u)\s"),
      non  
    r"[a&&b]"de-case")]
        assert_eq!analysis_is_literalir_negate(hir_ucn: Spave exampl an truly match in!(g alsst: as.is_literalirs),            hi!(g alast:abas.is_literalirs),            hi!(g alast:abcas.is_literalirs),            hi!(g alast:(?m)abcas.is_literalirs),            hi!(g alast:(?:a)as.is_literalirs),            hi!(g alast:foo(?:a)as.is_literalirs),            hi!(g alast:(?:a)fooas.is_literalirs),            hi!(g alast:[a)
 .is_literalirs),egate(hir_ucN   //ve exampl an truly match in!(!g als r"").is_literalirs),            hi!(!g alast:^as.is_literalirs),            hi!(!g alast:a|bas.is_literalirs),            hi!(!g alast:(a)as.is_literalirs),            hi!(!g alast:a+as.is_literalirs),            hi!(!g alast:foo(a)as.is_literalirs),            hi!(!g alast:(a)fooas.is_literalirs),            hi!(!g alast:[ab]as.is_literalirs),         Position::new(2)3analysis_is_alt  na ion_literalir_negate(hir_ucn: Spave exampl an truly match in!(g alsst: as.is_alt  na ion_literalirs),            hi!(g alast:abas.is_alt  na ion_literalirs),            hi!(g alast:abcas.is_alt  na ion_literalirs),            hi!(g alast:(?m)abcas.is_alt  na ion_literalirs),            hi!(g alast:foo|bar").is_alt  na ion_literalirs),            hi!(g alast:foo|bar|baz").is_alt  na ion_literalirs),            hi!(g alast:[a)
 .is_alt  na ion_literalirs),            hi!(g alast:(?:ab)|cdas.is_alt  na ion_literalirs),            hi!(g alast:ab|(?:cd)as.is_alt  na ion_literalirs),egate(hir_ucN   //ve exampl an truly match in!(!g als r"").is_alt  na ion_literalirs),            hi!(!g alast:^as.is_alt  na ion_literalirs),            hi!(!g alast:(a)as.is_alt  na ion_literalirs),            hi!(!g alast:a+as.is_alt  na ion_literalirs),            hi!(!g alast:foo(a)as.is_alt  na ion_literalirs),            hi!(!g alast:(a)fooas.is_alt  na ion_literalirs),            hi!(!g alast:[ab]as.is_alt  na ion_literalirs),            hi!(!g alast:[ab]|bas.is_alt  na ion_literalirs),            hi!(!g alast:a|[ab]as.is_alt  na ion_literalirs),            hi!(!g alast:(a)|bas.is_alt  na ion_literalirs),            hi!(!g alast:a|(b)as.is_alt  na ion_literalirs),            hi!(!g alast:a|bas.is_alt  na ion_literalirs),            hi!(!g alast:a|b|cas.is_alt  na ion_literalirs),            hi!(!g alast:[a]|bas.is_alt  na ion_literalirs),            hi!(!g alast:a|[b]as.is_alt  na ion_literalirs),            hi!(!g alast:(?:a)|bas.is_alt  na ion_literalirs),            hi!(!g alast:a|(?:b)as.is_alt  na ion_literalirs),            hi!(!g alast:(?:z|xx)@|xxas.is_alt  na ion_literalirs),         Po // his tions_ucla     sm rt(H    repetSpan: constructors does   ])
basic   Po //simplifica ionan trulsition::new(2)3sm rt_repetSpan:others
    // match non-ASCIa{0   ,(H    

    #(?i-u)\s"),
          t r"a{1    );
        assert_eq!(t("(?:)"), HiASr"\B{32111    );
   ook(
    Lookytes(rp{scx:GN   /ers),         Po // his tions_ucla     sm rt(H    conca  constructor/simplifies     g/ven   Po //exprs i)3a way we expectn trulsition::new(2)3sm rt_conca _thers
    // match non-AS"  ,(H    

    #(?i-u)\s"),
          t :(?:)  ,(H    

    #(?i-u)\s"),
          t :abcas );
        bcas(?i-u)\s"),
          t :(?:foo)(?:bar)") );
       foobar")(?i-u)\s"),
             quux(?:foo)(?:bar)baz") );
       quuxfoobarbaz")lower:]]"),
            hir_ascii_bclafoo(?:bar^baz)quux
  eature = "unicode-ct(vec![     hir_union(
          foobar")      hir_union(
      ook(
    LookytSt rts,     hir_union(
          bazquux
  eature = "uni]v"(?-u)[[:lower:]]"),
            hir_ascii_bclafoo(?:ba(?:r^b)az)quux
  eature = "unicode-ct(vec![     hir_union(
          foobar")      hir_union(
      ook(
    LookytSt rts,     hir_union(
          bazquux
  eature = "uni]v"(?-u)[[:lower:]     Po // his tions_ucla     sm rt(H    alt  na ion constructor/simplifies       Po //g/ven/exprs i)3a way we expectn trulsition::new(2)3sm rt_alt  na ion  #[cfg(not(feature = "unicode-script" :(?:foo)|(?:bar)") #[cfg(feature = "dlt(vec![         foo") );
       bar")]v"(?-u)[[:lower:]]"),
            hir_ascii_bclaquux|(?:abc|def|xyz)|baz") #[cfg(feature = "dlt(vec![     hir_union(
          quux
  eature = "unin(
          abcas eature = "unin(
          defas eature = "unin(
          xyz"s,     hir_union(
          baz
  eature = "uni]v"(?-u)[[:lower:]]"),
            hir_ascii_bclaquux|(?:abc|(?:def|mno)|xyz)|baz") #[cfg(feature = "dlt(vec![     hir_union(
          quux
  eature = "unin(
          abcas eature = "unin(
          defas eature = "unin(
          mnoas eature = "unin(
          xyz"s,     hir_union(
          baz
  eature = "uni]v"(?-u)[[:lower:]]"),
            hir_ascii_bclaa|b|c|d|e|f|x|y|z
       );
        aest]
    fnaclasf(&ss_fxattened(),"(?-u)[[:lower:]]"), //    s_ucla we lift common prefixes outa-z]a)3alt  na ion.e giant
        // letter property."[de.)foo|[de.)quux
  eature = "unicode-ct(vec![     hir_union(
     est]
    fn cat_cla[(      hir_union(
     dlt(vec![         foo") );
       quux
 ]  eature = "uni]v,"(?-u)[[:lower:]]"),
            hir_ascii_bcla[de.)[de.)|[de.)quux
  eature = "unicode-ct(vec![     hir_union(
     est]
    fn cat_cla[(      hir_union(
     dlt(vec![    est]
    fn cat_cla[( );
       quux
 ]  eature = "uni]v,"(?-u)[[:lower:]]"),
            hir_ascii_bcla[de.)[de.)|[de.)[de.)quux
  eature = "unicode-ct(vec![     hir_union(
     est]
    fn cat_cla[(      hir_union(
     est]
    fn cat_cla[(      hir_union(
     dlt(vec![H    

    # );
       quux
 ]  eature = "uni]v,"(?-u)[[:lower:]]"),
            hir_ascii_bcla[de.)foo|[de.)foobar")      hir_uniocode-ct(vec![     hir_union(
     est]
    fn cat_cla[(      hir_union(
     dlt(vec![         foo") );
       foobar")]  eature = "uni]v,"(?-u)[[:lower:]     Position::new(2)3regression_dlt  
   _conca _thers
    //use cr /e  a!(
 {self, Ast}),egate(hirlet/estE =ror {
 spla _n: Span::new(
0, 0, 0)s),        let/a!( =rA!(
 alt  na ion a!(
 Alt  na ion {ind::Lower)
 estE #[cfg(feature,  s: vec![A!(
 conca _q!(
  onca  { estE e,  s: vec![] })] #[cfg(fea}"),egate(hirlet/muta( =rTransls_un:new(
lower:]]"),
          Ok(H    

    #(, t.transls_eS" , eq!()lower:]     Position::new(2)3regression_ 
   _dlt(thers
    //use cr /e  a!(
 {self, Ast}),egate(hirlet/estE =ror {
 spla _n: Span::new(
0, 0, 0)s),        let/a!( =rA!(
 conca _q!(
  onca  {ind::Lower)
 estE #[cfg(feature,  s: vec![A!(
 alt  na ion a!(
 Alt  na ion {ind::Lower)
 r)
 estE #[cfg(featureture,  s: vec![]n::new(0, 1, 1))] #[cfg(fea}"),egate(hirlet/muta( =rTransls_un:new(
lower:]]"),
          Ok(H    fail #(, t.transls_eS" , eq!()lower:]     Position::new(2)3regression_singleton_dlt(thers
    //use cr /e  {#[cfg(feature,  
 {self, Ast}      hir_uniocod::Dot #[cfg(fea}),egate(hirlet/estE =ror {
 spla _n: Span::new(
0, 0, 0)s),        let/a!( =rA!(
 conca _q!(
  onca  {ind::Lower)
 estE #[cfg(feature,  s: vec![A!(
 alt  na ion a!(
 Alt  na ion {ind::Lower)
 r)
 estE #[cfg(featureture,  s: vec![A!(
 dot(estE)]n::new(0, 1, 1))] #[cfg(fea}"),egate(hirlet/muta( =rTransls_un:new(
lower:]]"),
          Ok(H    dot(Dot
 AnyCharExceptLF#(, t.transls_eS" , eq!()lower:]     Po //See: https://bugs.chromium.org/p/oss-fuzz/issues/detail?id=63168   Position::new(2)3regression_fuzz_match_thers
    //let/pa( =r"[(\u{6} \0-\u{afdf5}]  \0 "),        let/a!( =rPar   Builden:new(
l::new(0, 1, 1.octal(falsel::new(0, 1, 1.ignore_whitioeatuotruel::new(0, 1, 1.build
l::new(0, 1, 1.par  spatl::new(0, 1, 1.unwrap(s),        let/cod =rTransls_unBuilden:new(
l::new(0, 1, 1.utf8itruel::new(0, 1, 1.-casein[ensSpave(falsel::new(0, 1, 1.multi   ne(falsel::new(0, 1, 1.dot_matche
 -cw   ne(falsel::new(0, 1, 1.swap_g)\pditruel::new(0, 1, 1.0, 0xFFotruel::new(0, 1, 1.build
l::new(0, 1, 1.transls_eSpat, eq!()::new(0, 1, 1.unwrap(s),        
            hir_ascii_bcodn::new(0, 1, 1H    conca (vec![     hir_union(
     est]
    fnhss(&[(u{afdf5}la[(      hir_union(
          \0
  eature = "uni]v"(?-u)[[:lower:]     Po //See: https://bugs.chromium.org/p/oss-fuzz/issues/detail?id=63155
s"),hir_bclass(&[(0x80, 0xFF one giasition::new(2)3regression_fuzz_differetce1_thers
    //let/pa( =rr"\W\W|\W[^\v--\W\W\P{S ),
 _ExtensSons:Pau_Cin_Hau}\u10A1A1-\U{3E3E3}--~~~~--~~~~~~~~------~~~~~~--~~~~~~]*"),        let/_ =rtspatl;o //shouldn't/panic   Po     Po //See: https://bugs.chromium.org/p/oss-fuzz/issues/detail?id=63153e giasition::new(2)3regression_fuzz_char_decrement1_thers
    //let/pa( =r"w[w[^w?\rw\rw[^w?\rw[^w?\rw[^w?\rw[^w?\rw[^w?\rw[^w?\r\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0w?\rw[^w?\rw[^w?\rw[^w\0\0\u{1}\0]\0\0-*\0]\0\0\0\0\0\0\u{1}\0]\0\0-*\0]\0\0\0\0\0\u{1}\0]\0\0\0\0\0\0\0\0\0*\0\0\u{1}\0]\0\0-*\0][^w?\rw[^w?\rw[^w?\rw[^w?\rw[^w?\rw[^w?\rw[^w\0\0\u{1}\0]\0\0-*\0]\0\0\0\0\0\0\u{1}\0]\0\0-*\0]\0\0\0\0\0\u{1}\0]\0\0\0\0\0\0\0\0\0x\0\0\u{1}\0]\0\0-*\0]\0\0\0\0\0\0\0\0\0*??\0\u{7f}{2}\u{10}??\0\0\0\0\0\0\0\0\0\u{3}\0\0\0}\0-*\0]\0\0\0\0\0\0\u{1}\0]\0\0-*\0]\0\0\0\0\0\0\u{1}\0]\0\0-*\0]\0\0\0\0\0\u{1}\0]\0\0-*\0]\0\0\0\0\0\0\0\u{1}\0]\0\u{1}\u{1}H-i]-]\0\0\0\0\u{1}\0]\0\0\0\u{1}\0]\0\0-*\0\0\0\0\u{1}9-\u{7f}]\0'|-\u{7f}]\0'|(?i-ux)[-\u{7f}]\0'\u{3}\0\0\0}\0-*\0]<D\0\0\0\0\0\0\u{1}]\0\0\0\0]\0\0-*\0]\0\0 "),        let/_ =rtspatl;o //shouldn't/panic   Po  }
                                                                              