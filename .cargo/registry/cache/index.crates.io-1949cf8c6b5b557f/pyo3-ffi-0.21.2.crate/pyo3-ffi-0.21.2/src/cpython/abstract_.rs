use crate::{PyObject, Py_ssize_t};
use std::os::raw::{c_char, c_int};

#[cfg(not(Py_3_11))]
use crate::Py_buffer;

#[cfg(Py_3_8)]
use crate::pyport::PY_SSIZE_T_MAX;
#[cfg(all(Py_3_8, not(any(PyPy, GraalPy))))]
use crate::{
    vectorcallfunc, PyCallable_Check, PyThreadState, PyThreadState_GET, PyTuple_Check,
    PyType_HasFeature, Py_TPFLAGS_HAVE_VECTORCALL,
};
#[cfg(Py_3_8)]
use libc::size_t;

extern "C" {
    #[cfg(all(Py_3_8, not(any(PyPy, GraalPy))))]
    pub fn _PyStack_AsDict(values: *const *mut PyObject, kwnames: *mut PyObject) -> *mut PyObject;
}

#[cfg(all(Py_3_8, not(any(PyPy, GraalPy))))]
const _PY_FASTCALL_SMALL_STACK: size_t = 5;

extern "C" {
    #[cfg(all(Py_3_8, not(any(PyPy, GraalPy))))]
    pub fn _Py_CheckFunctionResult(
        tstate: *mut PyThreadState,
        callable: *mut PyObject,
        result: *mut PyObject,
        where_: *const c_char,
    ) -> *mut PyObject;

    #[cfg(all(Py_3_8, not(any(PyPy, GraalPy))))]
    pub fn _PyObject_MakeTpCall(
        tstate: *mut PyThreadState,
        callable: *mut PyObject,
        args: *const *mut PyObject,
        nargs: Py_ssize_t,
        keywords: *mut PyObject,
    ) -> *mut PyObject;
}

#[cfg(Py_3_8)]
const PY_VECTORCALL_ARGUMENTS_OFFSET: Py_ssize_t =
    1 << (8 * std::mem::size_of::<Py_ssize_t>() as Py_ssize_t - 1);

#[cfg(Py_3_8)]
#[inline(always)]
pub unsafe fn PyVectorcall_NARGS(n: size_t) -> Py_ssize_t {
    assert!(n <= (PY_SSIZE_T_MAX as size_t));
    (n as Py_ssize_t) & !PY_VECTORCALL_ARGUMENTS_OFFSET
}

#[cfg(all(Py_3_8, not(any(PyPy, GraalPy))))]
#[inline(always)]
pub unsafe fn PyVectorcall_Function(callable: *mut PyObject) -> Option<vectorcallfunc> {
    assert!(!callable.is_null());
    let tp = crate::Py_TYPE(callable);
    if PyType_HasFeature(tp, Py_TPFLAGS_HAVE_VECTORCALL) == 0 {
        return None;
    }
    assert!(PyCallable_Check(callable) > 0);
    let offset = (*tp).tp_vectorcall_offset;
    assert!(offset > 0);
    let ptr = (callable as *const c_char).offset(offset) as *const Option<vectorcallfunc>;
    *ptr
}

#[cfg(all(Py_3_8, not(any(PyPy, GraalPy))))]
#[inline(always)]
pub unsafe fn _PyObject_VectorcallTstate(
    tstate: *mut PyThreadState,
    callable: *mut PyObject,
    args: *const *mut PyObject,
    nargsf: size_t,
    kwnames: *mut PyObject,
) -> *mut PyObject {
    assert!(kwnames.is_null() || PyTuple_Check(kwnames) > 0);
    assert!(!args.is_null() || PyVectorcall_NARGS(nargsf) == 0);

    match PyVectorcall_Function(callable) {
        None => {
            let nargs = PyVectorcall_NARGS(nargsf);
            _PyObject_MakeTpCall(tstate, callable, args, nargs, kwnames)
        }
        Some(func) => {
            let res = func(callable, args, nargsf, kwnames);
            _Py_CheckFunctionResult(tstate, callable, res, std::ptr::null_mut())
        }
    }
}

#[cfg(all(Py_3_8, not(any(PyPy, GraalPy))))]
#[inline(always)]
pub unsafe fn PyObject_Vectorcall(
    callable: *mut PyObject,
    args: *const *mut PyObject,
    nargsf: size_t,
    kwnames: *mut PyObject,
) -> *mut PyObject {
    _PyObject_VectorcallTstate(PyThreadState_GET(), callable, args, nargsf, kwnames)
}

extern "C" {
    #[cfg(all(PyPy, Py_3_8))]
    #[cfg_attr(not(Py_3_9), link_name = "_PyPyObject_Vectorcall")]
    #[cfg_attr(Py_3_9, link_name = "PyPyObject_Vectorcall")]
    pub fn PyObject_Vectorcall(
        callable: *mut PyObject,
        args: *const *mut PyObject,
        nargsf: size_t,
        kwnames: *mut PyObject,
    ) -> *mut PyObject;

    #[cfg(Py_3_8)]
    #[cfg_attr(
        all(not(any(PyPy, GraalPy)), not(Py_3_9)),
        link_name = "_PyObject_VectorcallDict"
    )]
    #[cfg_attr(all(PyPy, not(Py_3_9)), link_name = "_PyPyObject_VectorcallDict")]
    #[cfg_attr(all(PyPy, Py_3_9), link_name = "PyPyObject_VectorcallDict")]
    pub fn PyObject_VectorcallDict(
        callable: *mut PyObject,
        args: *const *mut PyObject,
        nargsf: size_t,
        kwdict: *mut PyObject,
    ) -> *mut PyObject;

    #[cfg(Py_3_8)]
    #[cfg_attr(not(any(Py_3_9, PyPy)), link_name = "_PyVectorcall_Call")]
    #[cfg_attr(PyPy, link_name = "PyPyVectorcall_Call")]
    pub fn PyVectorcall_Call(
        callable: *mut PyObject,
        tuple: *mut PyObject,
        dict: *mut PyObject,
    ) -> *mut PyObject;
}

#[cfg(all(Py_3_8, not(any(PyPy, GraalPy))))]
#[inline(always)]
pub unsafe fn _PyObject_FastCallTstate(
    tstate: *mut PyThreadState,
    func: *mut PyObject,
    args: *const *mut PyObject,
    nargs: Py_ssize_t,
) -> *mut PyObject {
    _PyObject_VectorcallTstate(tstate, func, args, nargs as size_t, std::ptr::null_mut())
}

#[cfg(all(Py_3_8, not(any(PyPy, GraalPy))))]
#[inline(always)]
pub unsafe fn _PyObject_FastCall(
    func: *mut PyObject,
    args: *const *mut PyObject,
    nargs: Py_ssize_t,
) -> *mut PyObject {
    _PyObject_FastCallTstate(PyThreadState_GET(), func, args, nargs)
}

#[cfg(all(Py_3_8, not(any(PyPy, GraalPy))))]
#[inline(always)]
pub unsafe fn _PyObject_CallNoArg(func: *mut PyObject) -> *mut PyObject {
    _PyObject_VectorcallTstate(
        PyThreadState_GET(),
        func,
        std::ptr::null_mut(),
        0,
        std::ptr::null_mut(),
    )
}

extern "C" {
    #[cfg(PyPy)]
    #[link_name = "_PyPyObject_CallNoArg"]
    pub fn _PyObject_CallNoArg(func: *mut PyObject) -> *mut PyObject;
}

#[cfg(all(Py_3_8, not(any(PyPy, GraalPy))))]
#[inline(always)]
pub unsafe fn PyObject_CallOneArg(func: *mut PyObject, arg: *mut PyObject) -> *mut PyObject {
    assert!(!arg.is_null());
    let args_array = [std::ptr::null_mut(), arg];
    let args = args_array.as_ptr().offset(1); // For PY_VECTORCALL_ARGUMENTS_OFFSET
    let tstate = PyThreadState_GET();
    let nargsf = 1 | PY_VECTORCALL_ARGUMENTS_OFFSET;
    _PyObject_VectorcallTstate(tstate, func, args, nargsf as size_t, std::ptr::null_mut())
}

extern "C" {
    #[cfg(all(Py_3_9, not(any(PyPy, GraalPy))))]
    pub fn PyObject_VectorcallMethod(
        name: *mut PyObject,
        args: *const *mut PyObject,
        nargsf: size_t,
        kwnames: *mut PyObject,
    ) -> *mut PyObject;
}

#[cfg(all(Py_3_9, not(any(PyPy, GraalPy))))]
#[inline(always)]
pub unsafe fn PyObject_CallMethodNoArgs(
    self_: *mut PyObject,
    name: *mut PyObject,
) -> *mut PyObject {
    PyObject_VectorcallMethod(
        name,
        &self_,
        1 | PY_VECTORCALL_ARGUMENTS_OFFSET as size_t,
        std::ptr::null_mut(),
    )
}

#[cfg(all(Py_3_9, not(any(PyPy, GraalPy))))]
#[inline(always)]
pub unsafe fn PyObject_CallMethodOneArg(
    self_: *mut PyObject,
    name: *mut PyObject,
    arg: *mut ect,
    n  pub rsa.nline(alwacPyObject) ,
    name: *mut PyObject,
) -> *mut PyObject {
 null(d::ptr::Object {
 2rcallMethod(
        name,
        &self_,
        1 | PY_VECTORCALL_ARGUMENTS_OFFSE *mut PyObj_,
    name: *mut PyObjectIdE *mut PyObj_,
    namC PyObjectId
#[inlE *mut PyObj_,
    namC PyObjectId
#[inlSE *mut PyObj_,
    namHasLenfn PyEval_RestoreThread(arg1: *mut PyThreadState);
}
    namLengthHinPyPy, Py_3_9), link_name LengthHinPrray_FromObject"),Eval_EvyBytes_FromStri")]
    pub fn PyEval_ReleaseThr
use  argmovObjto      _char.;
    //3.11gsf as size_t, std::ptr::null_mut())
}

extern "C" {
    #[cfg(all(Py_c(calB_charyEval_CallFunction"t;
    fn _Py_C::raw::{c_char, bject;

    

#[cfg_attr(Py_3_9, deprecatall(Py_c(calB_charyE#[inline]
pub unsafe fn PyContexorcall_d:: _charert!(c> {
    asserto)Callad:: _charize_t {!llad:: _char() || PyTup&&t!(Pyad:: _char).bf_get _char() |s calc_int {
    (Py_TYPEReleaseThr
use  argmovObjto      _char.;
    //3.11g PyEval_RestoreThread(arg1: *mut PyThreadState);
}
    namk_namcharyPy, Py_3_9), link_name k_namcharyEval_CallFunction")]viewt PyObject _charUMElagsPyEval_EvalFalized")]
    pub fn PyEval_ThreadsInitializeamchar k_nPoiyCurfg_attr(PyPy, linkmchar k_nPoiyCurbject) -> *iewt PyObject _charUject) -> inmut*mut PyObjet,
        s: *mut  PyOb                n(ard")]
    pub fn PyEval_ThreadsInitializeamchar es_AObject;
    #[cfg_attr(PyPy,mchar es_AObject;
  (yObject,
        meth_Size")]
    pub fn PyBytes_Size(arg1: *mut PyObject) ->mchar Tot Pyiguous  #[cfg_attr(PyPy,mchar Tot Pyiguousbject) ->  _c:  PyOb                n(ar,ject) -> *iewt PyObject _charUject) -> pub fn PyByteAr_CallObjectrder:       result: *mualized")]
    pub fn PyEval_ThreadsInitializeamchar 

ext Pyiguous  #[cfg_attr(PyPy,mchar 

ext Pyiguousbject) -> *iewt PyObject _charUject) ->  _c:  PyOb                n(ar,ject) -> pub fn PyByteAr_CallObjectrder:       result: *mualized")]
    #[cfg(all(Py_copyData(des PyObject,
          rn "C" {
    pub fn PyCodec_Registerb fn PyEval_ThreadsInitializeamchar Ist Pyiguous  #[cfg_attr(PyPy,mchar Ist Pyiguous(*iewt Py_func_ty _charUMEuse .h
    pub fn PyCodec_KnownEncod,mchar 
illt Pyiguous*condes,
) -> *mutdimsnt,
        defs:shapeut PyObjet,
        s: _Streamndesut PyObjet,
        s: _Stritem
   nt,
        defs:Euse .h
    result:d")]
    pub fn PyEval_ThreadsInitializeamchar 
illIncl  #[cfg_attr(PyPy,mchar 
illInclbject) -> *iewt PyObject _charUject) -> t PyObject;

    pub fn Py _c:  PyOb                n(ar,ject) -> pub fn PyByteAr_CallObjecPY_Vonlynt,
        defs:ElagsPyEval_result: *mualized")]
    pub fn PyEval_ThreadsInitializeamchar name =   #[cfg_attr(PyPy,mchar name = (*iewt PyObject _char#[cfg(notPy_Typec(caldoes. Objin ffi             (notPy_nd(PyCompldoes. Objin ffi             (notNotdoes. Objon, bbecatureCPythub c ythele        dd
// this (notere so that      is hmacrotheeObjto bedoes. ObjEus/3.6,/3.7 which(notpred); /is here so that    nges.g(not(Py_3_8))]Sequence_ITEM             Y_ITERSEARCH_COUNTnt = 345;
1;            Y_ITERSEARCH_INDEX Py_file_in;            Y_ITERSEARCH_CONTAINSt = 258;
#[alPy))))]
const _PY_FASTCA::null_mut())
}

extern C" {
    #[cfg(alequence_I)))S   #[bject) -> seq  pub fn PyEval_CallObjectWithKeywords(
        func:ope> {t(PyPEval_result: *mu")]
    pub FSE *mut PyObj_,
    nam= "PIsI   plexE *mut PyObj_,
    nam= "PIs_Check(oSE *mut PyObj_,
lequence_k_namTot   pnk_naSE *mut PyObj_,
 

eet   Pnk_naSE *mut PyObj_,
 add_on puovald(PyFE *mut PyObj_,
 add_on puovald(PyCSE *mut PyObj_,
    v rs_oallabalpuov
    puSE *mut PyObj_,
Numbar Ild(P(  name: *mut Po) // skipped non-limited _PyContext_NewHamtForTests
}
