lazy-static.rs
==============

A macro for declaring lazily evaluated statics in Rust.

Using this macro, it is possible to have `static`s that require code to be
executed at runtime in order to be initialized.
This includes anything requiring heap allocations, like vectors or hash maps,
as well as anything that requires non-const function calls to be computed.

[![Rust](https://github.com/rust-lang-nursery/lazy-static.rs/actions/workflows/rust.yml/badge.svg)](https://github.com/rust-lang-nursery/lazy-static.rs/actions/workflows/rust.yml)
[![Latest version](https://img.shields.io/crates/v/lazy_static.svg)](https://crates.io/crates/lazy_static)
[![Documentation](https://docs.rs/lazy_static/badge.svg)](https://docs.rs/lazy_static)
[![License](https://img.shields.io/crates/l/lazy_static.svg)](https://github.com/rust-lang-nursery/lazy-static.rs#license)

## Minimum supported `rustc`

`1.40.0+`

This version is explicitly tested in CI and .apacazy6d8bf    wgew eteors convers.

of anyngcrates to mum supporm## Minihis versl
# w to antrolwithsed in r mforplatechiveticGetcceptS  uocia
[ery/lazy-statifile de availancti://cratesvg)](https://crates.io/crates/lazy_sta.
.
# Itlso recomnishedely lrks tense for geweu musmforpdihis versent,
as wellely rates to geweu m
tryb   as of t://d===td of thiontent of lt leupthe dopy of t5.0/RE,t of lt![Latge,
pubpdihis verm orshouldurpdins, l of ion or  of the followdev-depenyense to y of Caareif[La..d==```rgo.t[dev-dependencites/lazy_stsion = "1.5```

..dork ad.
See [t://svg)](https://docs.rs/lazy_staense hX: Howary u Rus# Ean exa==```ed `
ary .rs/lazy_st::.rs/lazy_st;
ary _no::contrrs/act::Hor Map;
ites/lazy_st!it": {
azy_stshe  HASHMAPNDIor Map<u32, &'azy_sts, d>sio{2004
    l  mmithcksuIor Map::gew(nse004
    m. ag as(n 2"foo"nse004
    m. ag as(1 2"bar"nse004
    m. ag as(2 2"baz"nse004
    me004
};
}

fnonicn()o{2004
// Firgaince ne How`HASHMAP`o be initiavide2004
me "pln!("s:

ocurs any `0`# It\"{}\".S IHASHMAP.-ta(&0).unwrap()nse2004
// 
of 
is, eitnce ne How`HASHMAP`ojou mustis e" as the comp ly ee2004
me "pln!("s:

ocurs any `1`# It\"{}\".S IHASHMAP.-ta(&1).unwrap()nse}5```

#tS  nd rel inrsto

.
# It iwt is possiblefor solely apptt use t.io/c'sonst funcaiabilics in 'tionsnd rel inrstoance w[`_no::entt::OpliLgo.`svg)](https:/.com/rust-ache._no/entt/ conct.OpliLgo..ify )pear. (an examThe abovrshould We auld or writa ion```ed `
ary _no::contrrs/act::Hor Map;
ary _no::entt::OpliLgo.;

fno or map() -> &'azy_stsIor Map<u32, &'azy_sts, d>st": {
azy_stsHASHMAPNDOpliLgo.<Ior Map<u32, &, d>>sioOpliLgo.::gew(nse004
HASHMAP.-ta_or_ be (||o{2004
    l  mmithcksuIor Map::gew(nse004
    m. ag as(n 2"foo"nse004
    m. ag as(1 2"bar"nse004
    m. ag as(2 2"baz"nse004
    me004
})
}

fnonicn()o{2004
// Firgaince ne How`HASHMAP`o be initiavide2004
me "pln!("s:

ocurs any `0`# It\"{}\".S I or map().-ta(&0).unwrap()nse2004
// 
of 
is, eitnce ne How`HASHMAP`ojou mustis e" as the comp ly ee2004
me "pln!("s:

ocurs any `1`# It\"{}\".S I or map().-ta(&1).unwrap()nse}5```

##ache Liceer]

Licensed unND, eities
 * the Apache License, Version, ([5.0/LICENSE-AP](5.0/LICENSE-APacts)g)](httpp://www.apache.org/licenses/LICENSE)
 *  = "ate lice([5.0/LICE = ](5.0/LICE = acts)g)](httpevents, soache.org/licen = a

atwith yoscripRus###aits Contribu-2.0

Unlyss You explicitly state otherws of any Contribution intentionally submi
ted for inclusion in whe Workyss,tion as defided in thR Apache  sublicenice
shalldividl]

Licenell he abose, without
any additional terms or conditio    