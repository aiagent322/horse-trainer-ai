/*!
A DFA that can return spans for matching capturing groups.

This module is the home of a [one-pass DFA](DFA).

This module also contains a [`Builder`] and a [`Config`] for building and
configuring a one-pass DFA.
*/

// A note on naming and credit:
//
// As far as I know, Russ Cox came up with the practical vision and
// implementation of a "one-pass regex engine." He mentions and describes it
// briefly in the third article of his regexp article series:
// https://swtch.com/~rsc/regexp/regexp3.html
//
// Cox's implementation is in RE2, and the implementation below is most
// heavily inspired by RE2's. The key thing they have in common is that
// their transitions are defined over an alphabet of bytes. In contrast,
// Go's regex engine also has a one-pass engine, but its transitions are
// more firmly rooted on Unicode codepoints. The ideas are the same, but the
// implementations are different.
//
// RE2 tends to call this a "one-pass NFA." Here, we call it a "one-pass DFA."
// They're both true in their own ways:
//
// * The "one-pass" criterion is generally a property of the NFA itself. In
// particular, it is said that an NFA is one-pass if, after each byte of input
// during a search, there is at most one "VM thread" remaining to take for the
// next byte of input. That is, there is never any ambiguity as to the path to
// take through the NFA during a search.
//
// * On the other hand, once a one-pass NFA has its representation converted
// to something where a constant number of instructions is used for each byte
// of input, the implementation looks a lot more like a DFA. It's technically
// more powerful than a DFA since it has side effects (storing offsets inside
// of slots activated by a transition), but it is far closer to a DFA than an
// NFA simulation.
//
// Thus, in this crate, we call it a one-pass DFA.

use alloc::{vec, vec::Vec};

use crate::{
    dfa::{remapper::Remapper, DEAD},
    nfa::thompson::{self, NFA},
    util::{
        alphabet::ByteClasses,
        captures::Captures,
        escape::DebugByte,
        int::{Usize, U32, U64, U8},
        look::{Look, LookSet, UnicodeWordBoundaryError},
        primitives::{NonMaxUsize, PatternID, StateID},
        search::{Anchored, Input, Match, MatchError, MatchKind, Span},
        sparse_set::SparseSet,
    },
};

/// The configuration used for building a [one-pass DFA](DFA).
///
/// A one-pass DFA configuration is a simple data object that is typically used
/// with [`Builder::configure`]. It can be cheaply cloned.
///
/// A default configuration can be created either with `Config::new`, or
/// perhaps more conveniently, with [`DFA::config`].
#[derive(Clone, Debug, Default)]
pub struct Config {
    match_kind: Option<MatchKind>,
    starts_for_each_pattern: Option<bool>,
    byte_classes: Option<bool>,
    size_limit: Option<Option<usize>>,
}

impl Config {
    /// Return a new default one-pass DFA configuration.
    pub fn new() -> Config {
        Config::default()
    }

    /// Set the desired match semantics.
    ///
    /// The default is [`MatchKind::LeftmostFirst`], which corresponds to the
    /// match semantics of Perl-like regex engines. That is, when multiple
    /// patterns would match at the same leftmost position, the pattern that
    /// appears first in the concrete syntax is chosen.
    ///
    /// Currently, the only other kind of match semantics supported is
    /// [`MatchKind::All`]. This corresponds to "classical DFA" construction
    /// where all possible matches are visited.
    ///
    /// When it comes to the one-pass DFA, it is rarer for preference order and
    /// "longest match" to actually disagree. Since if they did disagree, then
    /// the regex typically isn't one-pass. For example, searching `Samwise`
    /// for `Sam|Samwise` will report `Sam` for leftmost-first matching and
    /// `Samwise` for "longest match" or "all" matching. However, this regex is
    /// not one-pass if taken literally. The equivalent regex, `Sam(?:|wise)`
    /// is one-pass and `Sam|Samwise` may be optimized to it.
    ///
    /// The other main difference is that "all" match semantics don't support
    /// non-greedy matches. "All" match semantics always try to match as much
    /// as possible.
    pub fn match_kind(mut self, kind: MatchKind) -> Config {
        self.match_kind = Some(kind);
        self
    }

    /// Whether to compile a separate start state for each pattern in the
    /// one-pass DFA.
    ///
    /// When enabled, a separate **anchored** start state is added for each
    /// pattern in the DFA. When this start state is used, then the DFA will
    /// only search for matches for the pattern specified, even if there are
    /// other patterns in the DFA.
    ///
    /// The main downside of this option is that it can potentially increase
    /// the size of the DFA and/or increase the time it takes to build the DFA.
    ///
    /// You might want to enable this option when you want to both search for
    /// anchored matches of any pattern or to search for anchored matches of
    /// one particular pattern while using the same DFA. (Otherwise, you would
    /// need to compile a new DFA for each pattern.)
    ///
    /// By default this is disabled.
    ///
    /// # Example
    ///
    /// This example shows how to build a multi-regex and then search for
    /// matches for a any of the patterns or matches for a specific pattern.
    ///
    /// ```
    /// use regex_automata::{
    ///     dfa::onepass::DFA, Anchored, Input, Match, PatternID,
    /// };
    ///
    /// let re = DFA::builder()
    ///     .configure(DFA::config().starts_for_each_pattern(true))
    ///     .build_many(&["[a-z]+", "[0-9]+"])?;
    /// let (mut cache, mut caps) = (re.create_cache(), re.create_captures());
    /// let haystack = "123abc";
    /// let input = Input::new(haystack).anchored(Anchored::Yes);
    ///
    /// // A normal multi-pattern search will show pattern 1 matches.
    /// re.try_search(&mut cache, &input, &mut caps)?;
    /// assert_eq!(Some(Match::must(1, 0..3)), caps.get_match());
    ///
    /// // If we only want to report pattern 0 matches, then we'll get no
    /// // match here.
    /// let input = input.anchored(Anchored::Pattern(PatternID::must(0)));
    /// re.try_search(&mut cache, &input, &mut caps)?;
    /// assert_eq!(None, caps.get_match());
    ///
    /// # Ok::<(), Box<dyn std::error::Error>>(())
    /// ```
    pub fn starts_for_each_pattern(mut self, yes: bool) -> Config {
        self.starts_for_each_pattern = Some(yes);
        self
    }

    /// Whether to attempt to shrink the size of the DFA's alphabet or not.
    ///
    /// This option is enabled by default and should never be disabled unless
    /// one is debugging a one-pass DFA.
    ///
    /// When enabled, the DFA will use a map from all possible bytes to their
    /// corresponding equivalence class. Each equivalence class represents a
    /// set of bytes that does not discriminate between a match and a non-match
    /// in the DFA. For example, the pattern `[ab]+` has at least two
    /// equivalence classes: a set containing `a` and `b` and a set containing
    /// every byte except for `a` and `b`. `a` and `b` are in the same
    /// equivalence class because they never discriminate between a match and a
    /// non-match.
    ///
    /// The advantage of this map is that the size of the transition table
    /// can be reduced drastically from (approximately) `#states * 256 *
    /// sizeof(StateID)` to `#states * k * sizeof(StateID)` where `k` is the
    /// number of equivalence classes (rounded up to the nearest power of 2).
    /// As a result, total space usage can decrease substantially. Moreover,
    /// since a smaller alphabet is used, DFA compilation becomes faster as
    /// well.
    ///
    /// **WARNING:** This is only useful for debugging DFAs. Disabling this
    /// does not yield any speed advantages. Namely, even when this is
    /// disabled, a byte class map is still used while searching. The only
    /// difference is that every byte will be forced into its own distinct
    /// equivalence class. This is useful for debugging the actual generated
    /// transitions because it lets one see the transitions defined on actual
    /// bytes instead of the equivalence classes.
    pub fn byte_classes(mut self, yes: bool) -> Config {
        self.byte_classes = Some(yes);
        self
    }

    /// Set a size limit on the total heap used by a one-pass DFA.
    ///
    /// This size limit is expressed in bytes and is applied during
    /// construction of a one-pass DFA. If the DFA's heap usage exceeds
    /// this configured limit, then construction is stopped and an error is
    /// returned.
    ///
    /// The default is no limit.
    ///
    /// # Example
    ///
    /// This example shows a one-pass DFA that fails to build because of
    /// a configured size limit. This particular example also serves as a
    /// cautionary tale demonstrating just how big DFAs with large Unicode
    /// character classes can get.
    ///
    /// ```
    /// # if cfg!(miri) { return Ok(()); } // miri takes too long
    /// use regex_automata::{dfa::onepass::DFA, Match};
    ///
    /// // 6MB isn't enough!
    /// DFA::builder()
    ///     .configure(DFA::config().size_limit(Some(6_000_000)))
    ///     .build(r"\w{20}")
    ///     .unwrap_err();
    ///
    /// // ... but 7MB probably is!
    /// // (Note that DFA sizes aren't necessarily stable between releases.)
    /// let re = DFA::builder()
    ///     .configure(DFA::config().size_limit(Some(7_000_000)))
    ///     .build(r"\w{20}")?;
    /// let (mut cache, mut caps) = (re.create_cache(), re.create_captures());
    /// let haystack = "A".repeat(20);
    /// re.captures(&mut cache, &haystack, &mut caps);
    /// assert_eq!(Some(Match::must(0, 0..20)), caps.get_match());
    ///
    /// # Ok::<(), Box<dyn std::error::Error>>(())
    /// ```
    ///
    /// While one needs a little more than 3MB to represent `\w{20}`, it
    /// turns out that you only need a little more than 4KB to represent
    /// `(?-u:\w{20})`. So only use Unicode if you need it!
    pub fn size_limit(mut self, limit: Option<usize>) -> Config {
        self.size_limit = Some(limit);
        self
    }

    /// Returns the match semantics set in this configuration.
    pub fn get_match_kind(&self) -> MatchKind {
        self.match_kind.unwrap_or(MatchKind::LeftmostFirst)
    }

    /// Returns whether this configuration has enabled anchored starting states
    /// for every pattern in the DFA.
    pub fn get_starts_for_each_pattern(&self) -> bool {
        self.starts_for_each_pattern.unwrap_or(false)
    }

    /// Returns whether this configuration has enabled byte classes or not.
    /// This is typically a debugging oriented option, as disabling it confers
    /// no speed benefit.
    pub fn get_byte_classes(&self) -> bool {
        self.byte_classes.unwrap_or(true)
    }

    /// Returns the DFA size limit of this configuration if one was set.
    /// The size limit is total number of bytes on the heap that a DFA is
    /// permitted to use. If the DFA exceeds this limit during construction,
    /// then construction is stopped and an error is returned.
    pub fn get_size_limit(&self) -> Option<usize> {
        self.size_limit.unwrap_or(None)
    }

    /// Overwrite the default configuration such that the options in `o` are
    /// always used. If an option in `o` is not set, then the corresponding
    /// option in `self` is used. If it's not set in `self` either, then it
    /// remains not set.
    pub(crate) fn overwrite(&self, o: Config) -> Config {
        Config {
            match_kind: o.match_kind.or(self.match_kind),
            starts_for_each_pattern: o
                .starts_for_each_pattern
                .or(self.starts_for_each_pattern),
            byte_classes: o.byte_classes.or(self.byte_classes),
            size_limit: o.size_limit.or(self.size_limit),
        }
    }
}

/// A builder for a [one-pass DFA](DFA).
///
/// This builder permits configuring options for the syntax of a pattern, the
/// NFA construction and the DFA construction. This builder is different from a
/// general purpose regex builder in that it permits fine grain configuration
/// of the construction process. The trade off for this is complexity, and
/// the possibility of setting a configuration that might not make sense. For
/// example, there are two different UTF-8 modes:
///
/// * [`syntax::Config::utf8`](crate::util::syntax::Config::utf8) controls
/// whether the pattern itself can contain sub-expressions that match invalid
/// UTF-8.
/// * [`thompson::Config::utf8`] controls whether empty matches that split a
/// Unicode codepoint are reported or not.
///
/// Generally speaking, callers will want to either enable all of these or
/// disable all of these.
///
/// # Example
///
/// This example shows how to disable UTF-8 mode in the syntax and the NFA.
/// This is generally what you want for matching on arbitrary bytes.
///
/// ```
/// # if cfg!(miri) { return Ok(()); } // miri takes too long
/// use regex_automata::{
///     dfa::onepass::DFA,
///     nfa::thompson,
///     util::syntax,
///     Match,
/// };
///
/// let re = DFA::builder()
///     .syntax(syntax::Config::new().utf8(false))
///     .thompson(thompson::Config::new().utf8(false))
///     .build(r"foo(?-u:[^b])ar.*")?;
/// let (mut cache, mut caps) = (re.create_cache(), re.create_captures());
///
/// let haystack = b"foo\xFFarzz\xE2\x98\xFF\n";
/// re.captures(&mut cache, haystack, &mut caps);
/// // Notice that `(?-u:[^b])` matches invalid UTF-8,
/// // but the subsequent `.*` does not! Disabling UTF-8
/// // on the syntax permits this.
/// //
/// // N.B. This example does not show the impact of
/// // disabling UTF-8 mode on a one-pass DFA Config,
/// //  since that only impacts regexes that can
/// // produce matches of length 0.
/// assert_eq!(Some(Match::must(0, 0..8)), caps.get_match());
///
/// # Ok::<(), Box<dyn std::error::Error>>(())
/// ```
#[derive(Clone, Debug)]
pub struct Builder {
    config: Config,
    #[cfg(feature = "syntax")]
    thompson: thompson::Compiler,
}

impl Builder {
    /// Create a new one-pass DFA builder with the default configuration.
    pub fn new() -> Builder {
        Builder {
            config: Config::default(),
            #[cfg(feature = "syntax")]
            thompson: thompson::Compiler::new(),
        }
    }

    /// Build a one-pass DFA from the given pattern.
    ///
    /// If there was a problem parsing or compiling the pattern, then an error
    /// is returned.
    #[cfg(feature = "syntax")]
    pub fn build(&self, pattern: &str) -> Result<DFA, BuildError> {
        self.build_many(&[pattern])
    }

    /// Build a one-pass DFA from the given patterns.
    ///
    /// When matches are returned, the pattern ID corresponds to the index of
    /// the pattern in the slice given.
    #[cfg(feature = "syntax")]
    pub fn build_many<P: AsRef<str>>(
        &self,
        patterns: &[P],
    ) -> Result<DFA, BuildError> {
        let nfa =
            self.thompson.build_many(patterns).map_err(BuildError::nfa)?;
        self.build_from_nfa(nfa)
    }

    /// Build a DFA from the given NFA.
    ///
    /// # Example
    ///
    /// This example shows how to build a DFA if you already have an NFA in
    /// hand.
    ///
    /// ```
    /// use regex_automata::{dfa::onepass::DFA, nfa::thompson::NFA, Match};
    ///
    /// // This shows how to set non-default options for building an NFA.
    /// let nfa = NFA::compiler()
    ///     .configure(NFA::config().shrink(true))
    ///     .build(r"[a-z0-9]+")?;
    /// let re = DFA::builder().build_from_nfa(nfa)?;
    /// let (mut cache, mut caps) = (re.create_cache(), re.create_captures());
    /// re.captures(&mut cache, "foo123bar", &mut caps);
    /// assert_eq!(Some(Match::must(0, 0..9)), caps.get_match());
    ///
    /// # Ok::<(), Box<dyn std::error::Error>>(())
    /// ```
    pub fn build_from_nfa(&self, nfa: NFA) -> Result<DFA, BuildError> {
        // Why take ownership if we're just going to pass a reference to the
        // NFA to our internal builder? Well, the first thing to note is that
        // an NFA uses reference counting internally, so either choice is going
        // to be cheap. So there isn't much cost either way.
        //
        // The real reason is that a one-pass DFA, semantically, shares
        // ownership of an NFA. This is unlike other DFAs that don't share
        // ownership of an NFA at all, primarily because they want to be
        // self-contained in order to support cheap (de)serialization.
        //
        // But then why pass a '&nfa' below if we want to share ownership?
        // Well, it turns out that using a '&NFA' in our internal builder
        // separates its lifetime from the DFA we're building, and this turns
        // out to make code a bit more composable. e.g., We can iterate over
        // things inside the NFA while borrowing the builder as mutable because
        // we know the NFA cannot be mutated. So TL;DR --- this weirdness is
        // "because borrow checker."
        InternalBuilder::new(self.config.clone(), &nfa).build()
    }

    /// Apply the given one-pass DFA configuration options to this builder.
    pub fn configure(&mut self, config: Config) -> &mut Builder {
        self.config = self.config.overwrite(config);
        self
    }

    /// Set the syntax configuration for this builder using
    /// [`syntax::Config`](crate::util::syntax::Config).
    ///
    /// This permits setting things like case insensitivity, Unicode and multi
    /// line mode.
    ///
    /// These settings only apply when constructing a one-pass DFA directly
    /// from a pattern.
    #[cfg(feature = "syntax")]
    pub fn syntax(
        &mut self,
        config: crate::util::syntax::Config,
    ) -> &mut Builder {
        self.thompson.syntax(config);
        self
    }

    /// Set the Thompson NFA configuration for this builder using
    /// [`nfa::thompson::Config`](crate::nfa::thompson::Config).
    ///
    /// This permits setting things like whether additional time should be
    /// spent shrinking the size of the NFA.
    ///
    /// These settings only apply when constructing a DFA directly from a
    /// pattern.
    #[cfg(feature = "syntax")]
    pub fn thompson(&mut self, config: thompson::Config) -> &mut Builder {
        self.thompson.configure(config);
        self
    }
}

/// An internal builder for encapsulating the state necessary to build a
/// one-pass DFA. Typical use is just `InternalBuilder::new(..).build()`.
///
/// There is no separate pass for determining whether the NFA is one-pass or
/// not. We just try to build the DFA. If during construction we discover that
/// it is not one-pass, we bail out. This is likely to lead to some undesirable
/// expense in some cases, so it might make sense to try an identify common
/// patterns in the NFA that make it definitively not one-pass. That way, we
/// can avoid ever trying to build a one-pass DFA in the first place. For
/// example, '\w*\s' is not one-pass, and since '\w' is Unicode-aware by
/// default, it's probably not a trivial cost to try and build a one-pass DFA
/// for it and then fail.
///
/// Note that some (immutable) fields are duplicated here. For example, the
/// 'nfa' and 'classes' fields are both in the 'DFA'. They are the same thing,
/// but we duplicate them because it makes composition easier below. Otherwise,
/// since the borrow checker can't see through method calls, the mutable borrow
/// we use to mutate the DFA winds up preventing borrowing from any other part
/// of the DFA, even though we aren't mutating those parts. We only do this
/// because the duplication is cheap.
#[derive(Debug)]
struct InternalBuilder<'a> {
    /// The DFA we're building.
    dfa: DFA,
    /// An unordered collection of NFA state IDs that we haven't yet tried to
    /// build into a DFA state yet.
    ///
    /// This collection does not ultimately wind up including every NFA state
    /// ID. Instead, each ID represents a "start" state for a sub-graph of the
    /// NFA. The set of NFA states we then use to build a DFA state consists
    /// of that "start" state and all states reachable from it via epsilon
    /// transitions.
    uncompiled_nfa_ids: Vec<StateID>,
    /// A map from NFA state ID to DFA state ID. This is useful for easily
    /// determining whether an NFA state has been used as a "starting" point
    /// to build a DFA state yet. If it hasn't, then it is mapped to DEAD,
    /// and since DEAD is specially added and never corresponds to any NFA
    /// state, it follows that a mapping to DEAD implies the NFA state has
    /// no corresponding DFA state yet.
    nfa_to_dfa_id: Vec<StateID>,
    /// A stack used to traverse the NFA states that make up a single DFA
    /// state. Traversal occurs until the stack is empty, and we only push to
    /// the stack when the state ID isn't in 'seen'. Actually, even more than
    /// that, if we try to push something on to this stack that is already in
    /// 'seen', then we bail out on construction completely, since it implies
    /// that the NFA is not one-pass.
    stack: Vec<(StateID, Epsilons)>,
    /// The set of NFA states that we've visited via 'stack'.
    seen: SparseSet,
    /// Whether a match NFA state has been observed while constructing a
    /// one-pass DFA state. Once a match state is seen, assuming we are using
    /// leftmost-first match semantics, then we don't add any more transitions
    /// to the DFA state we're building.
    matched: bool,
    /// The config passed to the builder.
    ///
    /// This is duplicated in dfa.config.
    config: Config,
    /// The NFA we're building a one-pass DFA from.
    ///
    /// This is duplicated in dfa.nfa.
    nfa: &'a NFA,
    /// The equivalence classes that make up the alphabet for this DFA>
    ///
    /// This is duplicated in dfa.classes.
    classes: ByteClasses,
}

impl<'a> InternalBuilder<'a> {
    /// Create a new builder with an initial empty DFA.
    fn new(config: Config, nfa: &'a NFA) -> InternalBuilder {
        let classes = if !config.get_byte_classes() {
            // A one-pass DFA will always use the equivalence class map, but
            // enabling this option is useful for debugging. Namely, this will
            // cause all transitions to be defined over their actual bytes
            // instead of an opaque equivalence class identifier. The former is
            // much easier to grok as a human.
            ByteClasses::singletons()
        } else {
            nfa.byte_classes().clone()
        };
        // Normally a DFA alphabet includes the EOI symbol, but we don't need
        // that in the one-pass DFA since we handle look-around explicitly
        // without encoding it into the DFA. Thus, we don't need to delay
        // matches by 1 byte. However, we reuse the space that *would* be used
        // by the EOI transition by putting match information there (like which
        // pattern matches and which look-around assertions need to hold). So
        // this means our real alphabet length is 1 fewer than what the byte
        // classes report, since we don't use EOI.
        let alphabet_len = classes.alphabet_len().checked_sub(1).unwrap();
        let stride2 = classes.stride2();
        let dfa = DFA {
            config: config.clone(),
            nfa: nfa.clone(),
            table: vec![],
            starts: vec![],
            // Since one-pass DFAs have a smaller state ID max than
            // StateID::MAX, it follows that StateID::MAX is a valid initial
            // value for min_match_id since no state ID can ever be greater
            // than it. In the case of a one-pass DFA with no match states, the
            // min_match_id will keep this sentinel value.
            min_match_id: StateID::MAX,
            classes: classes.clone(),
            alphabet_len,
            stride2,
            pateps_offset: alphabet_len,
            // OK because PatternID::MAX*2 is guaranteed not to overflow.
            explicit_slot_start: nfa.pattern_len().checked_mul(2).unwrap(),
        };
        InternalBuilder {
            dfa,
            uncompiled_nfa_ids: vec![],
            nfa_to_dfa_id: vec![DEAD; nfa.states().len()],
            stack: vec![],
            seen: SparseSet::new(nfa.states().len()),
            matched: false,
            config,
            nfa,
            classes,
        }
    }

    /// Build the DFA from the NFA given to this builder. If the NFA is not
    /// one-pass, then return an error. An error may also be returned if a
    /// particular limit is exceeded. (Some limits, like the total heap memory
    /// used, are configurable. Others, like the total patterns or slots, are
    /// hard-coded based on representational limitations.)
    fn build(mut self) -> Result<DFA, BuildError> {
        self.nfa.look_set_any().available().map_err(BuildError::word)?;
        for look in self.nfa.look_set_any().iter() {
            // This is a future incompatibility check where if we add any
            // more look-around assertions, then the one-pass DFA either
            // needs to reject them (what we do here) or it needs to have its
            // Transition representation modified to be capable of storing the
            // new assertions.
            if look.as_repr() > Look::WordUnicodeNegate.as_repr() {
                return Err(BuildError::unsupported_look(look));
            }
        }
        if self.nfa.pattern_len().as_u64() > PatternEpsilons::PATTERN_ID_LIMIT
        {
            return Err(BuildError::too_many_patterns(
                PatternEpsilons::PATTERN_ID_LIMIT,
            ));
        }
        if self.nfa.group_info().explicit_slot_len() > Slots::LIMIT {
            return Err(BuildError::not_one_pass(
                "too many explicit capturing groups (max is 16)",
            ));
        }
        assert_eq!(DEAD, self.add_empty_state()?);

        // This is where the explicit slots start. We care about this because
        // we only need to track explicit slots. The implicit slots---two for
        // each pattern---are tracked as part of the search routine itself.
        let explicit_slot_start = self.nfa.pattern_len() * 2;
        self.add_start_state(None, self.nfa.start_anchored())?;
        if self.config.get_starts_for_each_pattern() {
            for pid in self.nfa.patterns() {
                self.add_start_state(
                    Some(pid),
                    self.nfa.start_pattern(pid).unwrap(),
                )?;
            }
        }
        // NOTE: One wonders what the effects of treating 'uncompiled_nfa_ids'
        // as a stack are. It is really an unordered *set* of NFA state IDs.
        // If it, for example, in practice led to discovering whether a regex
        // was or wasn't one-pass later than if we processed NFA state IDs in
        // ascending order, then that would make this routine more costly in
        // the somewhat common case of a regex that isn't one-pass.
        while let Some(nfa_id) = self.uncompiled_nfa_ids.pop() {
            let dfa_id = self.nfa_to_dfa_id[nfa_id];
            // Once we see a match, we keep going, but don't add any new
            // transitions. Normally we'd just stop, but we have to keep
            // going in order to verify that our regex is actually one-pass.
            self.matched = false;
            // The NFA states we've already explored for this DFA state.
            self.seen.clear();
            // The NFA states to explore via epsilon transitions. If we ever
            // try to push an NFA state that we've already seen, then the NFA
            // is not one-pass because it implies there are multiple epsilon
            // transition paths that lead to the same NFA state. In other
            // words, there is ambiguity.
            self.stack_push(nfa_id, Epsilons::empty())?;
            while let Some((id, epsilons)) = self.stack.pop() {
                match *self.nfa.state(id) {
                    thompson::State::ByteRange { ref trans } => {
                        self.compile_transition(dfa_id, trans, epsilons)?;
                    }
                    thompson::State::Sparse(ref sparse) => {
                        for trans in sparse.transitions.iter() {
                            self.compile_transition(dfa_id, trans, epsilons)?;
                        }
                    }
                    thompson::State::Dense(ref dense) => {
                        for trans in dense.iter() {
                            self.compile_transition(dfa_id, &trans, epsilons)?;
                        }
                    }
                    thompson::State::Look { look, next } => {
                        let looks = epsilons.looks().insert(look);
                        self.stack_push(next, epsilons.set_looks(looks))?;
                    }
                    thompson::State::Union { ref alternates } => {
                        for &sid in alternates.iter().rev() {
                            self.stack_push(sid, epsilons)?;
                        }
                    }
                    thompson::State::BinaryUnion { alt1, alt2 } => {
                        self.stack_push(alt2, epsilons)?;
                        self.stack_push(alt1, epsilons)?;
                    }
                    thompson::State::Capture { next, slot, .. } => {
                        let slot = slot.as_usize();
                        let epsilons = if slot < explicit_slot_start {
                            // If this is an implicit slot, we don't care
                            // about it, since we handle implicit slots in
                            // the search routine. We can get away with that
                            // because there are 2 implicit slots for every
                            // pattern.
                            epsilons
                        } else {
                            // Offset our explicit slots so that they start
                            // at index 0.
                            let offset = slot - explicit_slot_start;
                            epsilons.set_slots(epsilons.slots().insert(offset))
                        };
                        self.stack_push(next, epsilons)?;
                    }
                    thompson::State::Fail => {
                        continue;
                    }
                    thompson::State::Match { pattern_id } => {
                        // If we found two different paths to a match state
                        // for the same DFA state, then we have ambiguity.
                        // Thus, it's not one-pass.
                        if self.matched {
                            return Err(BuildError::not_one_pass(
                                "multiple epsilon transitions to match state",
                            ));
                        }
                        self.matched = true;
                        // Shove the matching pattern ID and the 'epsilons'
                        // into the current DFA state's pattern epsilons. The
                        // 'epsilons' includes the slots we need to capture
                        // before reporting the match and also the conditional
                        // epsilon transitions we need to check before we can
                        // report a match.
                        self.dfa.set_pattern_epsilons(
                            dfa_id,
                            PatternEpsilons::empty()
                                .set_pattern_id(pattern_id)
                                .set_epsilons(epsilons),
                        );
                        // N.B. It is tempting to just bail out here when
                        // compiling a leftmost-first DFA, since we will never
                        // compile any more transitions in that case. But we
                        // actually need to keep going in order to verify that
                        // we actually have a one-pass regex. e.g., We might
                        // see more Match states (e.g., for other patterns)
                        // that imply that we don't have a one-pass regex.
                        // So instead, we mark that we've found a match and
                        // continue on. When we go to compile a new DFA state,
                        // we just skip that part. But otherwise check that the
                        // one-pass property is upheld.
                    }
                }
            }
        }
        self.shuffle_states();
        Ok(self.dfa)
    }

    /// Shuffle all match states to the end of the transition table and set
    /// 'min_match_id' to the ID of the first such match state.
    ///
    /// The point of this is to make it extremely cheap to determine whether
    /// a state is a match state or not. We need to check on this on every
    /// transition during a search, so it being cheap is important. This
    /// permits us to check it by simply comparing two state identifiers, as
    /// opposed to looking for the pattern ID in the state's `PatternEpsilons`.
    /// (Which requires a memory load and some light arithmetic.)
    fn shuffle_states(&mut self) {
        let mut remapper = Remapper::new(&self.dfa);
        let mut next_dest = self.dfa.last_state_id();
        for i in (0..self.dfa.state_len()).rev() {
            let id = StateID::must(i);
            let is_match =
                self.dfa.pattern_epsilons(id).pattern_id().is_some();
            if !is_match {
                continue;
            }
            remapper.swap(&mut self.dfa, next_dest, id);
            self.dfa.min_match_id = next_dest;
            next_dest = self.dfa.prev_state_id(next_dest).expect(
                "match states should be a proper subset of all states",
            );
        }
        remapper.remap(&mut self.dfa);
    }

    /// Compile the given NFA transition into the DFA state given.
    ///
    /// 'Epsilons' corresponds to any conditional epsilon transitions that need
    /// to be satisfied to follow this transition, and any slots that need to
    /// be saved if the transition is followed.
    ///
    /// If this transition indicates that the NFA is not one-pass, then
    /// this returns an error. (This occurs, for example, if the DFA state
    /// already has a transition defined for the same input symbols as the
    /// given transition, *and* the result of the old and new transitions is
    /// different.)
    fn compile_transition(
        &mut self,
        dfa_id: StateID,
        trans: &thompson::Transition,
        epsilons: Epsilons,
    ) -> Result<(), BuildError> {
        let next_dfa_id = self.add_dfa_state_for_nfa_state(trans.next)?;
        for byte in self
            .classes
            .representatives(trans.start..=trans.end)
            .filter_map(|r| r.as_u8())
        {
            let oldtrans = self.dfa.transition(dfa_id, byte);
            let newtrans =
                Transition::new(self.matched, next_dfa_id, epsilons);
            // If the old transition points to the DEAD state, then we know
            // 'byte' has not been mapped to any transition for this DFA state
            // yet. So set it unconditionally. Otherwise, we require that the
            // old and new transitions are equivalent. Otherwise, there is
            // ambiguity and thus the regex is not one-pass.
            if oldtrans.state_id() == DEAD {
                self.dfa.set_transition(dfa_id, byte, newtrans);
            } else if oldtrans != newtrans {
                return Err(BuildError::not_one_pass(
                    "conflicting transition",
                ));
            }
        }
        Ok(())
    }

    /// Add a start state to the DFA corresponding to the given NFA starting
    /// state ID.
    ///
    /// If adding a state would blow any limits (configured or hard-coded),
    /// then an error is returned.
    ///
    /// If the starting state is an anchored state for a particular pattern,
    /// then callers must provide the pattern ID for that starting state.
    /// Callers must also ensure that the first starting state added is the
    /// start state for all patterns, and then each anchored starting state for
    /// each pattern (if necessary) added in order. Otherwise, this panics.
    fn add_start_state(
        &mut self,
        pid: Option<PatternID>,
        nfa_id: StateID,
    ) -> Result<StateID, BuildError> {
        match pid {
            // With no pid, this should be the start state for all patterns
            // and thus be the first one.
            None => assert!(self.dfa.starts.is_empty()),
            // With a pid, we want it to be at self.dfa.starts[pid+1].
            Some(pid) => assert!(self.dfa.starts.len() == pid.one_more()),
        }
        let dfa_id = self.add_dfa_state_for_nfa_state(nfa_id)?;
        self.dfa.starts.push(dfa_id);
        Ok(dfa_id)
    }

    /// Add a new DFA state corresponding to the given NFA state. If adding a
    /// state would blow any limits (configured or hard-coded), then an error
    /// is returned. If a DFA state already exists for the given NFA state,
    /// then that DFA state's ID is returned and no new states are added.
    ///
    /// It is not expected that this routine is called for every NFA state.
    /// Instead, an NFA state ID will usually correspond to the "start" state
    /// for a sub-graph of the NFA, where all states in the sub-graph are
    /// reachable via epsilon transitions (conditional or unconditional). That
    /// sub-graph of NFA states is ultimately what produces a single DFA state.
    fn add_dfa_state_for_nfa_state(
        &mut self,
        nfa_id: StateID,
    ) -> Result<StateID, BuildError> {
        // If we've already built a DFA state for the given NFA state, then
        // just return that. We definitely do not want to have more than one
        // DFA state in existence for the same NFA state, since all but one of
        // them will likely become unreachable. And at least some of them are
        // likely to wind up being incomplete.
        let existing_dfa_id = self.nfa_to_dfa_id[nfa_id];
        if existing_dfa_id != DEAD {
            return Ok(existing_dfa_id);
        }
        // If we don't have any DFA state yet, add it and then add the given
        // NFA state to the list of states to explore.
        let dfa_id = self.add_empty_state()?;
        self.nfa_to_dfa_id[nfa_id] = dfa_id;
        self.uncompiled_nfa_ids.push(nfa_id);
        Ok(dfa_id)
    }

    /// Unconditionally add a new empty DFA state. If adding it would exceed
    /// any limits (configured or hard-coded), then an error is returned. The
    /// ID of the new state is returned on success.
    ///
    /// The added state is *not* a match state.
    fn add_empty_state(&mut self) -> Result<StateID, BuildError> {
        let state_limit = Transition::STATE_ID_LIMIT;
        // Note that unlike dense and lazy DFAs, we specifically do NOT
        // premultiply our state IDs here. The reason is that we want to pack
        // our state IDs into 64-bit transitions with other info, so the fewer
        // the bits we use for state IDs the better. If we premultiply, then
        // our state ID space shrinks. We justify this by the assumption that
        // a one-pass DFA is just already doing a fair bit more work than a
        // normal DFA anyway, so an extra multiplication to compute a state
        // transition doesn't seem like a huge deal.
        let next_id = self.dfa.table.len() >> self.dfa.stride2();
        let id = StateID::new(next_id)
            .map_err(|_| BuildError::too_many_states(state_limit))?;
        if id.as_u64() > Transition::STATE_ID_LIMIT {
            return Err(BuildError::too_many_states(state_limit));
        }
        self.dfa
            .table
            .extend(core::iter::repeat(Transition(0)).take(self.dfa.stride()));
        // The default empty value for 'PatternEpsilons' is sadly not all
        // zeroes. Instead, a special sentinel is used to indicate that there
        // is no pattern. So we need to explicitly set the pattern epsilons to
        // the correct "empty" PatternEpsilons.
        self.dfa.set_pattern_epsilons(id, PatternEpsilons::empty());
        if let Some(size_limit) = self.config.get_size_limit() {
            if self.dfa.memory_usage() > size_limit {
                return Err(BuildError::exceeded_size_limit(size_limit));
            }
        }
        Ok(id)
    }

    /// Push the given NFA state ID and its corresponding epsilons (slots and
    /// conditional epsilon transitions) on to a stack for use in a depth first
    /// traversal of a sub-graph of the NFA.
    ///
    /// If the given NFA state ID has already been pushed on to the stack, then
    /// it indicates the regex is not one-pass and this correspondingly returns
    /// an error.
    fn stack_push(
        &mut self,
        nfa_id: StateID,
        epsilons: Epsilons,
    ) -> Result<(), BuildError> {
        // If we already have seen a match and we are compiling a leftmost
        // first DFA, then we shouldn't add any more states to look at. This is
        // effectively how preference order and non-greediness is implemented.
        // if !self.config.get_match_kind().continue_past_first_match()
        // && self.matched
        // {
        // return Ok(());
        // }
        if !self.seen.insert(nfa_id) {
            return Err(BuildError::not_one_pass(
                "multiple epsilon transitions to same state",
            ));
        }
        self.stack.push((nfa_id, epsilons));
        Ok(())
    }
}

/// A one-pass DFA for executing a subset of anchored regex searches while
/// resolving capturing groups.
///
/// A one-pass DFA can be built from an NFA that is one-pass. An NFA is
/// one-pass when there is never any ambiguity about how to continue a search.
/// For example, `a*a` is not one-pass becuase during a search, it's not
/// possible to know whether to continue matching the `a*` or to move on to
/// the single `a`. However, `a*b` is one-pass, because for every byte in the
/// input, it's always clear when to move on from `a*` to `b`.
///
/// # Only anchored searches are supported
///
/// In this crate, especially for DFAs, unanchored searches are implemented by
/// treating the pattern as if it had a `(?s-u:.)*?` prefix. While the prefix
/// is one-pass on its own, adding anything after it, e.g., `(?s-u:.)*?a` will
/// make the overall pattern not one-pass. Why? Because the `(?s-u:.)` matches
/// any byte, and there is therefore ambiguity as to when the prefix should
/// stop matching and something else should start matching.
///
/// Therefore, one-pass DFAs do not support unanchored searches. In addition
/// to many regexes simply not being one-pass, it implies that one-pass DFAs
/// have limited utility. With that said, when a one-pass DFA can be used, it
/// can potentially provide a dramatic speed up over alternatives like the
/// [`BoundedBacktracker`](crate::nfa::thompson::backtrack::BoundedBacktracker)
/// and the [`PikeVM`](crate::nfa::thompson::pikevm::PikeVM). In particular,
/// a one-pass DFA is the only DFA capable of reporting the spans of matching
/// capturing groups.
///
/// To clarify, when we say that unanchored searches are not supported, what
/// that actually means is:
///
/// * The high level routines, [`DFA::is_match`] and [`DFA::captures`], always
/// do anchored searches.
/// * Since iterators are most useful in the context of unanchored searches,
/// there is no `DFA::captures_iter` method.
/// * For lower level routines like [`DFA::try_search`], an error will be
/// returned if the given [`Input`] is configured to do an unanchored search or
/// search for an invalid pattern ID. (Note that an [`Input`] is configured to
/// do an unanchored search by default, so just giving a `Input::new` is
/// guaranteed to return an error.)
///
/// # Other limitations
///
/// In addition to the [configurable heap limit](Config::size_limit) and
/// the requirement that a regex pattern be one-pass, there are some other
/// limitations:
///
/// * There is an internal limit on the total number of explicit capturing
/// groups that appear across all patterns. It is somewhat small and there is
/// no way to configure it. If your pattern(s) exceed this limit, then building
/// a one-pass DFA will fail.
/// * If the number of patterns exceeds an internal unconfigurable limit, then
/// building a one-pass DFA will fail. This limit is quite large and you're
/// unlikely to hit it.
/// * If the total number of states exceeds an internal unconfigurable limit,
/// then building a one-pass DFA will fail. This limit is quite large and
/// you're unlikely to hit it.
///
/// # Other examples of regexes that aren't one-pass
///
/// One particularly unfortunate example is that enabling Unicode can cause
/// regexes that were one-pass to no longer be one-pass. Consider the regex
/// `(?-u)\w*\s` for example. It is one-pass because there is exactly no
/// overlap between the ASCII definitions of `\w` and `\s`. But `\w*\s`
/// (i.e., with Unicode enabled) is *not* one-pass because `\w` and `\s` get
/// translated to UTF-8 automatons. And while the *codepoints* in `\w` and `\s`
/// do not overlap, the underlying UTF-8 encodings do. Indeed, because of the
/// overlap between UTF-8 automata, the use of Unicode character classes will
/// tend to vastly increase the likelihood of a regex not being one-pass.
///
/// # How does one know if a regex is one-pass or not?
///
/// At the time of writing, the only way to know is to try and build a one-pass
/// DFA. The one-pass property is checked while constructing the DFA.
///
/// This does mean that you might potentially waste some CPU cycles and memory
/// by optimistically trying to build a one-pass DFA. But this is currently the
/// only way. In the future, building a one-pass DFA might be able to use some
/// heuristics to detect common violations of the one-pass property and bail
/// more quickly.
///
/// # Resource usage
///
/// Unlike a general DFA, a one-pass DFA has stricter bounds on its resource
/// usage. Namely, construction of a one-pass DFA has a time and space
/// complexity of `O(n)`, where `n ~ nfa.states().len()`. (A general DFA's time
/// and space complexity is `O(2^n)`.) This smaller time bound is achieved
/// because there is at most one DFA state created for each NFA state. If
/// additional DFA states would be required, then the pattern is not one-pass
/// and construction will fail.
///
/// Note though that currently, this DFA uses a fully dense representation.
/// This means that while its space complexity is no worse than an NFA, it may
/// in practice use more memory because of higher constant factors. The reason
/// for this trade off is two-fold. Firstly, a dense representation makes the
/// search faster. Secondly, the bigger an NFA, the more unlikely it is to be
/// one-pass. Therefore, most one-pass DFAs are usually pretty small.
///
/// # Example
///
/// This example shows that the one-pass DFA implements Unicode word boundaries
/// correctly while simultaneously reporting spans for capturing groups that
/// participate in a match. (This is the only DFA that implements full support
/// for Unicode word boundaries.)
///
/// ```
/// # if cfg!(miri) { return Ok(()); } // miri takes too long
/// use regex_automata::{dfa::onepass::DFA, Match, Span};
///
/// let re = DFA::new(r"\b(?P<first>\w+)[[:space:]]+(?P<last>\w+)\b")?;
/// let (mut cache, mut caps) = (re.create_cache(), re.create_captures());
///
/// re.captures(&mut cache, "Шерлок Холмс", &mut caps);
/// assert_eq!(Some(Match::must(0, 0..23)), caps.get_match());
/// assert_eq!(Some(Span::from(0..12)), caps.get_group_by_name("first"));
/// assert_eq!(Some(Span::from(13..23)), caps.get_group_by_name("last"));
/// # Ok::<(), Box<dyn std::error::Error>>(())
/// ```
///
/// # Example: iteration
///
/// Unlike other regex engines in this crate, this one does not provide
/// iterator search functions. This is because a one-pass DFA only supports
/// anchored searches, and so iterator functions are generally not applicable.
///
/// However, if you know that all of your matches are
/// directly adjacent, then an iterator can be used. The
/// [`util::iter::Searcher`](crate::util::iter::Searcher) type can be used for
/// this purpose:
///
/// ```
/// # if cfg!(miri) { return Ok(()); } // miri takes too long
/// use regex_automata::{
///     dfa::onepass::DFA,
///     util::iter::Searcher,
///     Anchored, Input, Span,
/// };
///
/// let re = DFA::new(r"\w(\d)\w")?;
/// let (mut cache, caps) = (re.create_cache(), re.create_captures());
/// let input = Input::new("a1zb2yc3x").anchored(Anchored::Yes);
///
/// let mut it = Searcher::new(input).into_captures_iter(caps, |input, caps| {
///     Ok(re.try_search(&mut cache, input, caps)?)
/// }).infallible();
/// let caps0 = it.next().unwrap();
/// assert_eq!(Some(Span::from(1..2)), caps0.get_group(1));
///
/// # Ok::<(), Box<dyn std::error::Error>>(())
/// ```
#[derive(Clone)]
pub struct DFA {
    /// The configuration provided by the caller.
    config: Config,
    /// The NFA used to build this DFA.
    ///
    /// NOTE: We probably don't need to store the NFA here, but we use enough
    /// bits from it that it's convenient to do so. And there really isn't much
    /// cost to doing so either, since an NFA is reference counted internally.
    nfa: NFA,
    /// The transition table. Given a state ID 's' and a byte of haystack 'b',
    /// the next state is `table[sid + classes[byte]]`.
    ///
    /// The stride of this table (i.e., the number of columns) is always
    /// a power of 2, even if the alphabet length is smaller. This makes
    /// converting between state IDs and state indices very cheap.
    ///
    /// Note that the stride always includes room for one extra "transition"
    /// that isn't actually a transition. It is a 'PatternEpsilons' that is
    /// used for match states only. Because of this, the maximum number of
    /// active columns in the transition table is 257, which means the maximum
    /// stride is 512 (the next power of 2 greater than or equal to 257).
    table: Vec<Transition>,
    /// The DFA state IDs of the starting states.
    ///
    /// `starts[0]` is always present and corresponds to the starting state
    /// when searching for matches of any pattern in the DFA.
    ///
    /// `starts[i]` where i>0 corresponds to the starting state for the pattern
    /// ID 'i-1'. These starting states are optional.
    starts: Vec<StateID>,
    /// Every state ID >= this value corresponds to a match state.
    ///
    /// This is what a search uses to detect whether a state is a match state
    /// or not. It requires only a simple comparison instead of bit-unpacking
    /// the PatternEpsilons from every state.
    min_match_id: StateID,
    /// The alphabet of this DFA, split into equivalence classes. Bytes in the
    /// same equivalence class can never discriminate between a match and a
    /// non-match.
    classes: ByteClasses,
    /// The number of elements in each state in the transition table. This may
    /// be less than the stride, since the stride is always a power of 2 and
    /// the alphabet length can be anything up to and including 256.
    alphabet_len: usize,
    /// The number of columns in the transition table, expressed as a power of
    /// 2.
    stride2: usize,
    /// The offset at which the PatternEpsilons for a match state is stored in
    /// the transition table.
    ///
    /// PERF: One wonders whether it would be better to put this in a separate
    /// allocation, since only match states have a non-empty PatternEpsilons
    /// and the number of match states tends be dwarfed by the number of
    /// non-match states. So this would save '8*len(non_match_states)' for each
    /// DFA. The question is whether moving this to a different allocation will
    /// lead to a perf hit during searches. You might think dealing with match
    /// states is rare, but some regexes spend a lot of time in match states
    /// gobbling up input. But... match state handling is already somewhat
    /// expensive, so maybe this wouldn't do much? Either way, it's worth
    /// experimenting.
    pateps_offset: usize,
    /// The first explicit slot index. This refers to the first slot appearing
    /// immediately after the last implicit slot. It is always 'patterns.len()
    /// * 2'.
    ///
    /// We record this because we only store the explicit slots in our DFA
    /// transition table that need to be saved. Implicit slots are handled
    /// automatically as part of the search.
    explicit_slot_start: usize,
}

impl DFA {
    /// Parse the given regular expression using the default configuration and
    /// return the corresponding one-pass DFA.
    ///
    /// If you want a non-default configuration, then use the [`Builder`] to
    /// set your own configuration.
    ///
    /// # Example
    ///
    /// ```
    /// use regex_automata::{dfa::onepass::DFA, Match};
    ///
    /// let re = DFA::new("foo[0-9]+bar")?;
    /// let (mut cache, mut caps) = (re.create_cache(), re.create_captures());
    ///
    /// re.captures(&mut cache, "foo12345barzzz", &mut caps);
    /// assert_eq!(Some(Match::must(0, 0..11)), caps.get_match());
    /// # Ok::<(), Box<dyn std::error::Error>>(())
    /// ```
    #[cfg(feature = "syntax")]
    #[inline]
    pub fn new(pattern: &str) -> Result<DFA, BuildError> {
        DFA::builder().build(pattern)
    }

    /// Like `new`, but parses multiple patterns into a single "multi regex."
    /// This similarly uses the default regex configuration.
    ///
    /// # Example
    ///
    /// ```
    /// use regex_automata::{dfa::onepass::DFA, Match};
    ///
    /// let re = DFA::new_many(&["[a-z]+", "[0-9]+"])?;
    /// let (mut cache, mut caps) = (re.create_cache(), re.create_captures());
    ///
    /// re.captures(&mut cache, "abc123", &mut caps);
    /// assert_eq!(Some(Match::must(0, 0..3)), caps.get_match());
    ///
    /// re.captures(&mut cache, "123abc", &mut caps);
    /// assert_eq!(Some(Match::must(1, 0..3)), caps.get_match());
    ///
    /// # Ok::<(), Box<dyn std::error::Error>>(())
    /// ```
    #[cfg(feature = "syntax")]
    #[inline]
    pub fn new_many<P: AsRef<str>>(patterns: &[P]) -> Result<DFA, BuildError> {
        DFA::builder().build_many(patterns)
    }

    /// Like `new`, but builds a one-pass DFA directly from an NFA. This is
    /// useful if you already have an NFA, or even if you hand-assembled the
    /// NFA.
    ///
    /// # Example
    ///
    /// This shows how to hand assemble a regular expression via its HIR,
    /// compile an NFA from it and build a one-pass DFA from the NFA.
    ///
    /// ```
    /// use regex_automata::{
    ///     dfa::onepass::DFA,
    ///     nfa::thompson::NFA,
    ///     Match,
    /// };
    /// use regex_syntax::hir::{Hir, Class, ClassBytes, ClassBytesRange};
    ///
    /// let hir = Hir::class(Class::Bytes(ClassBytes::new(vec![
    ///     ClassBytesRange::new(b'0', b'9'),
    ///     ClassBytesRange::new(b'A', b'Z'),
    ///     ClassBytesRange::new(b'_', b'_'),
    ///     ClassBytesRange::new(b'a', b'z'),
    /// ])));
    ///
    /// let config = NFA::config().nfa_size_limit(Some(1_000));
    /// let nfa = NFA::compiler().configure(config).build_from_hir(&hir)?;
    ///
    /// let re = DFA::new_from_nfa(nfa)?;
    /// let (mut cache, mut caps) = (re.create_cache(), re.create_captures());
    /// let expected = Some(Match::must(0, 0..1));
    /// re.captures(&mut cache, "A", &mut caps);
    /// assert_eq!(expected, caps.get_match());
    ///
    /// # Ok::<(), Box<dyn std::error::Error>>(())
    /// ```
    pub fn new_from_nfa(nfa: NFA) -> Result<DFA, BuildError> {
        DFA::builder().build_from_nfa(nfa)
    }

    /// Create a new one-pass DFA that matches every input.
    ///
    /// # Example
    ///
    /// ```
    /// use regex_automata::{dfa::onepass::DFA, Match};
    ///
    /// let dfa = DFA::always_match()?;
    /// let mut cache = dfa.create_cache();
    /// let mut caps = dfa.create_captures();
    ///
    /// let expected = Match::must(0, 0..0);
    /// dfa.captures(&mut cache, "", &mut caps);
    /// assert_eq!(Some(expected), caps.get_match());
    /// dfa.captures(&mut cache, "foo", &mut caps);
    /// assert_eq!(Some(expected), caps.get_match());
    /// # Ok::<(), Box<dyn std::error::Error>>(())
    /// ```
    pub fn always_match() -> Result<DFA, BuildError> {
        let nfa = thompson::NFA::always_match();
        Builder::new().build_from_nfa(nfa)
    }

    /// Create a new one-pass DFA that never matches any input.
    ///
    /// # Example
    ///
    /// ```
    /// use regex_automata::dfa::onepass::DFA;
    ///
    /// let dfa = DFA::never_match()?;
    /// let mut cache = dfa.create_cache();
    /// let mut caps = dfa.create_captures();
    ///
    /// dfa.captures(&mut cache, "", &mut caps);
    /// assert_eq!(None, caps.get_match());
    /// dfa.captures(&mut cache, "foo", &mut caps);
    /// assert_eq!(None, caps.get_match());
    /// # Ok::<(), Box<dyn std::error::Error>>(())
    /// ```
    pub fn never_match() -> Result<DFA, BuildError> {
        let nfa = thompson::NFA::never_match();
        Builder::new().build_from_nfa(nfa)
    }

    /// Return a default configuration for a DFA.
    ///
    /// This is a convenience routine to avoid needing to import the `Config`
    /// type when customizing the construction of a DFA.
    ///
    /// # Example
    ///
    /// This example shows how to change the match semantics of this DFA from
    /// its default "leftmost first" to "all." When using "all," non-greediness
    /// doesn't apply and neither does preference order matching. Instead, the
    /// longest match possible is always returned. (Although, by construction,
    /// it's impossible for a one-pass DFA to have a different answer for
    /// "preference order" vs "longest match.")
    ///
    /// ```
    /// use regex_automata::{dfa::onepass::DFA, Match, MatchKind};
    ///
    /// let re = DFA::builder()
    ///     .configure(DFA::config().match_kind(MatchKind::All))
    ///     .build(r"(abc)+?")?;
    /// let mut cache = re.create_cache();
    /// let mut caps = re.create_captures();
    ///
    /// re.captures(&mut cache, "abcabc", &mut caps);
    /// // Normally, the non-greedy repetition would give us a 0..3 match.
    /// assert_eq!(Some(Match::must(0, 0..6)), caps.get_match());
    /// # Ok::<(), Box<dyn std::error::Error>>(())
    /// ```
    #[inline]
    pub fn config() -> Config {
        Config::new()
    }

    /// Return a builder for configuring the construction of a DFA.
    ///
    /// This is a convenience routine to avoid needing to import the
    /// [`Builder`] type in common cases.
    ///
    /// # Example
    ///
    /// This example shows how to use the builder to disable UTF-8 mode.
    ///
    /// ```
    /// # if cfg!(miri) { return Ok(()); } // miri takes too long
    /// use regex_automata::{
    ///     dfa::onepass::DFA,
    ///     nfa::thompson,
    ///     util::syntax,
    ///     Match,
    /// };
    ///
    /// let re = DFA::builder()
    ///     .syntax(syntax::Config::new().utf8(false))
    ///     .thompson(thompson::Config::new().utf8(false))
    ///     .build(r"foo(?-u:[^b])ar.*")?;
    /// let (mut cache, mut caps) = (re.create_cache(), re.create_captures());
    ///
    /// let haystack = b"foo\xFFarzz\xE2\x98\xFF\n";
    /// let expected = Some(Match::must(0, 0..8));
    /// re.captures(&mut cache, haystack, &mut caps);
    /// assert_eq!(expected, caps.get_match());
    ///
    /// # Ok::<(), Box<dyn std::error::Error>>(())
    /// ```
    #[inline]
    pub fn builder() -> Builder {
        Builder::new()
    }

    /// Create a new empty set of capturing groups that is guaranteed to be
    /// valid for the search APIs on this DFA.
    ///
    /// A `Captures` value created for a specific DFA cannot be used with any
    /// other DFA.
    ///
    /// This is a convenience function for [`Captures::all`]. See the
    /// [`Captures`] documentation for an explanation of its alternative
    /// constructors that permit the DFA to do less work during a search, and
    /// thus might make it faster.
    #[inline]
    pub fn create_captures(&self) -> Captures {
        Captures::all(self.nfa.group_info().clone())
    }

    /// Create a new cache for this DFA.
    ///
    /// The cache returned should only be used for searches for this
    /// DFA. If you want to reuse the cache for another DFA, then you
    /// must call [`Cache::reset`] with that DFA (or, equivalently,
    /// [`DFA::reset_cache`]).
    #[inline]
    pub fn create_cache(&self) -> Cache {
        Cache::new(self)
    }

    /// Reset the given cache such that it can be used for searching with the
    /// this DFA (and only this DFA).
    ///
    /// A cache reset permits reusing memory already allocated in this cache
    /// with a different DFA.
    ///
    /// # Example
    ///
    /// This shows how to re-purpose a cache for use with a different DFA.
    ///
    /// ```
    /// # if cfg!(miri) { return Ok(()); } // miri takes too long
    /// use regex_automata::{dfa::onepass::DFA, Match};
    ///
    /// let re1 = DFA::new(r"\w")?;
    /// let re2 = DFA::new(r"\W")?;
    /// let mut caps1 = re1.create_captures();
    /// let mut caps2 = re2.create_captures();
    ///
    /// let mut cache = re1.create_cache();
    /// assert_eq!(
    ///     Some(Match::must(0, 0..2)),
    ///     { re1.captures(&mut cache, "Δ", &mut caps1); caps1.get_match() },
    /// );
    ///
    /// // Using 'cache' with re2 is not allowed. It may result in panics or
    /// // incorrect results. In order to re-purpose the cache, we must reset
    /// // it with the one-pass DFA we'd like to use it with.
    /// //
    /// // Similarly, after this reset, using the cache with 're1' is also not
    /// // allowed.
    /// re2.reset_cache(&mut cache);
    /// assert_eq!(
    ///     Some(Match::must(0, 0..3)),
    ///     { re2.captures(&mut cache, "☃", &mut caps2); caps2.get_match() },
    /// );
    ///
    /// # Ok::<(), Box<dyn std::error::Error>>(())
    /// ```
    #[inline]
    pub fn reset_cache(&self, cache: &mut Cache) {
        cache.reset(self);
    }

    /// Return the config for this one-pass DFA.
    #[inline]
    pub fn get_config(&self) -> &Config {
        &self.config
    }

    /// Returns a reference to the underlying NFA.
    #[inline]
    pub fn get_nfa(&self) -> &NFA {
        &self.nfa
    }

    /// Returns the total number of patterns compiled into this DFA.
    ///
    /// In the case of a DFA that contains no patterns, this returns `0`.
    #[inline]
    pub fn pattern_len(&self) -> usize {
        self.get_nfa().pattern_len()
    }

    /// Returns the total number of states in this one-pass DFA.
    ///
    /// Note that unlike dense or sparse DFAs, a one-pass DFA does not expose
    /// a low level DFA API. Therefore, this routine has little use other than
    /// being informational.
    #[inline]
    pub fn state_len(&self) -> usize {
        self.table.len() >> self.stride2()
    }

    /// Returns the total number of elements in the alphabet for this DFA.
    ///
    /// That is, this returns the total number of transitions that each
    /// state in this DFA must have. The maximum alphabet size is 256, which
    /// corresponds to each possible byte value.
    ///
    /// The alphabet size may be less than 256 though, and unless
    /// [`Config::byte_classes`] is disabled, it is typically must less than
    /// 256. Namely, bytes are grouped into equivalence classes such that no
    /// two bytes in the same class can distinguish a match from a non-match.
    /// For example, in the regex `^[a-z]+$`, the ASCII bytes `a-z` could
    /// all be in the same equivalence class. This leads to a massive space
    /// savings.
    ///
    /// Note though that the alphabet length does _not_ necessarily equal the
    /// total stride space taken up by a single DFA state in the transition
    /// table. Namely, for performance reasons, the stride is always the
    /// smallest power of two that is greater than or equal to the alphabet
    /// length. For this reason, [`DFA::stride`] or [`DFA::stride2`] are
    /// often more useful. The alphabet length is typically useful only for
    /// informational purposes.
    ///
    /// Note also that unlike dense or sparse DFAs, a one-pass DFA does
    /// not have a special end-of-input (EOI) transition. This is because
    /// a one-pass DFA handles look-around assertions explicitly (like the
    /// [`PikeVM`](crate::nfa::thompson::pikevm::PikeVM)) and does not build
    /// them into the transitions of the DFA.
    #[inline]
    pub fn alphabet_len(&self) -> usize {
        self.alphabet_len
    }

    /// Returns the total stride for every state in this DFA, expressed as the
    /// exponent of a power of 2. The stride is the amount of space each state
    /// takes up in the transition table, expressed as a number of transitions.
    /// (Unused transitions map to dead states.)
    ///
    /// The stride of a DFA is always equivalent to the smallest power of
    /// 2 that is greater than or equal to the DFA's alphabet length. This
    /// definition uses extra space, but possibly permits faster translation
    /// between state identifiers and their corresponding offsets in this DFA's
    /// transition table.
    ///
    /// For example, if the DFA's stride is 16 transitions, then its `stride2`
    /// is `4` since `2^4 = 16`.
    ///
    /// The minimum `stride2` value is `1` (corresponding to a stride of `2`)
    /// while the maximum `stride2` value is `9` (corresponding to a stride
    /// of `512`). The maximum in theory should be `8`, but because of some
    /// implementation quirks that may be relaxed in the future, it is one more
    /// than `8`. (Do note that a maximal stride is incredibly rare, as it
    /// would imply that there is almost no redundant in the regex pattern.)
    ///
    /// Note that unlike dense or sparse DFAs, a one-pass DFA does not expose
    /// a low level DFA API. Therefore, this routine has little use other than
    /// being informational.
    #[inline]
    pub fn stride2(&self) -> usize {
        self.stride2
    }

    /// Returns the total stride for every state in this DFA. This corresponds
    /// to the total number of transitions used by each state in this DFA's
    /// transition table.
    ///
    /// Please see [`DFA::stride2`] for more information. In particular, this
    /// returns the stride as the number of transitions, where as `stride2`
    /// returns it as the exponent of a power of 2.
    ///
    /// Note that unlike dense or sparse DFAs, a one-pass DFA does not expose
    /// a low level DFA API. Therefore, this routine has little use other than
    /// being informational.
    #[inline]
    pub fn stride(&self) -> usize {
        1 << self.stride2()
    }

    /// Returns the memory usage, in bytes, of this DFA.
    ///
    /// The memory usage is computed based on the number of bytes used to
    /// represent this DFA.
    ///
    /// This does **not** include the stack size used up by this DFA. To
    /// compute that, use `std::mem::size_of::<onepass::DFA>()`.
    #[inline]
    pub fn memory_usage(&self) -> usize {
        use core::mem::size_of;

        self.table.len() * size_of::<Transition>()
            + self.starts.len() * size_of::<StateID>()
    }
}

impl DFA {
    /// Executes an anchored leftmost forward search, and returns true if and
    /// only if this one-pass DFA matches the given haystack.
    ///
    /// This routine may short circuit if it knows that scanning future
    /// input will never lead to a different result. In particular, if theuctors tha to do so. An,e(Span::err.11ce `2^4 = 16`.
  )-pass DFA thfactors do NOT
      :s.FA correspoy abine a t addingning fug up inp(ss. Consihow the
    /// thus might m to a diffcs the gi in the rega+`ased on ven haystors do NOaaaaaaaaaaaaaaa`. /// This routass /// sing afteeasess to the fi`a`() },
    8`, vel routines l`/ dd`that need to contifor searchass becau+`This is
    non-grerch by defates.)
    ///
    /// the gian [`Insageostces a fu/ Reske to [`red(Anchored:ssesr, if theuctorthe givlt configuratwne [`red(AnchorNosse( at whi uses the def) DFA.
    ///
    //Pin paack.
    ///
    /// This rout in panirt of the sea-z` cdoes g incomplDFA. Thr thccuy for
    //s to to// asolvirt cm conces:ack.
    ///
    *ll." When thn provian [`Insvlt configuratre2 is not suppongth. the
    //r exampbially pr addinrs not suppos an anTF-8 m    s i cor, the
    /// thccuy-pass wet, us[`red(Anchorpty Pateset`] y abhat enabless
    /// [`Confelf.sttate_ by .set_pat`]* 2'.
    ///
    /d, whethe sea in pa, the cas DFA can to know whetpan::errady exih. the
     or  2'.
    ///
    Us like [`DFA::try_seareven if not want tA haWhensut in panne  an error
    e2` vsison ins DFA.
    ///
    /// # Example
    ///
    /// This shtedicmory u:mple
    ///
    /// ```
    /// use regex_automata::dfa::onepass::DFA;
    ///
    /// let re = DFA::new("foo[0-9]+bar")?;
    /// let mut cache = re.create_cache();
   he);
    /// as!) = FA::is_mures(&mut cache, "foo1234")ache);
    /// as!(! = FA::is_mures(&mut cache, 234")ache);
    /// # Ok::<(), Box<dyn std::error::Error>>(())
    /// ```
    ///
    /// # Exa: /// n exisrrespo the search mple
    ///
    /FA::is_mathat is guaranteed) { retOT
    ass ll ne`FA::captungly returns
    /in a maton. Thys inclufor searcxes that for exante idrcorrespoin and a
    he *codep:h.")
    ///
    /// ```
    /// use regex_automata::{dfa::onepass::Dn [`Iatch};
    ///
    /// let re = DFA::na*+bar")?;
    /// let mut cache = re.create_cache();
   he);
    /// as!)! = FA::is_mures(&mut cact = Input::ne, ").ing from(1.ache);
    /// # Ok::<(), Box<dyn std::error::Error>>(())
    /// ```
    ///
    ///iceeans thaetween UTF-8 es`] is disabled, then abto msly res and a
    n::err/// becauserentas sturatigcontt  // -widg with marcxes tFA, spand a
    he *codeptine ady bling d:h.")
    ///
    /// ```
    /// use regex_automata::{dfa::onepass::D    nfa::thompson::Dn [`Iatch};
    ///
    /// let re = DFA::builder()
    ///     .thompg = NFA::confiw().utf8(false))
    ///     .buna*+bar")?;
    /// let mut cache = re.create_cache();
   he);
    /// as!) = FA::is_mures(&mut cact = Input::ne, ").ing from(1.ache);
    /// # Ok::<(), Box<dyn std::error::Error>>(())
    /// ```
    #[inline]
    pubFA::is_m<'earI:ct to<t = I<'e>rroFA {
        &,e) {
        cache: &mut C,e) {
     up i:ctlons,
    )boolror> {
        let met inpu up inhem nfior  impt(T
  ty());
       ith mar!:new(iself.x").ancho::<red(AnchorNomit() {
         ew(isslf.x").anchored(Anchored::Ye));
        }
        sFA::try_seicit_s(mut cac&he, inphe: &[]ext().unwr FA: of ide2()
    }

    /// Executes an anchored leftmost forward search, and retua `Mis_mathflons
    /// /// only if this one-pass DFA matches the given haystack.
    ///
    /// This rout/// onys incluake the overn::err.ng  DFAb fn accesefers to for
    //di prr eqthe spans by e of capturing g,e to [`d [`DFA::captur.es.)
    ///
    /// the gian [`Insageostces a fu/ Reske to [`red(Anchored:ssesr, if theuctorthe givlt configuratwne [`red(AnchorNosse( at whi uses the def) DFA.
    ///
    //Pin paack.
    ///
    /// This rout in panirt of the sea-z` cdoes g incomplDFA. Thr thccuy for
    //s to to// asolvirt cm conces:ack.
    ///
    *ll." When thn provian [`Insvlt configuratre2 is not suppongth. the
    //r exampbially pr addinrs not suppos an anTF-8 m    s i cor, the
    /// thccuy-pass wet, us[`red(Anchorpty Pateset`] y abhat enabless
    /// [`Confelf.sttate_ by .set_pat`]* 2'.
    ///
    /d, whethe sea in pa, the cas DFA can to know whetpan::errady exih. the
     or  2'.
    ///
    Us like [`DFA::try_seareven if not want tA haWhensut in panne  an error
    e2` vsison ins DFA.
    ///
    /// # Example
    ///
    Lt "leftmost f the match semanti>0 corresponds to the maing with the
    the smallese starting ofhere, bs, wh as t// /he offs`] i crminmentedthe
    // "prapturor  imr br an  bytes in origiatioe a regular expresngth. the
    //r examp`Sam|Samwise)*?a`  the ma`Sam`nts* Samwise)here,  Samwise|Sam`ache
    //`  the ma`Samwise)*ts* Samwise) DFA.
    ///
    Gre generaspeakwriting, ult "leftmost firthe maishows leftmon::backtnabless
    e a regular express
/// tendess tion. Thisype inbac/ costPOSIX-styxample
    e a regular express
/an thie cdult "leftmvs "lon" DFA matable. Nam) },
    8othp`Sam|Samwise)*\w` aSamwise|Sam` the ma`Samwise)*ass wet, u")?;
    // "leftmvs "lonatch semanatch. (TM`](c DFA does  is currenull supp)?;
    // "leftmvs "lonatch semana)mple
    ///
    /// ```
    /// use regex_automata::{dfa::onepass::DFA, Match};
    ///
    /// let re = DFA::new("foo[0c)+?")?;
    /// let mut cache = re.create_cache();
    /// let expected = Match::must(0,8caps);
    /// assert_eq!(Some(expectee =/ ddures(&mut cache, "foo1")/// );
    ///
    ///Ee gi ie thoarthe maishfk-aroung afy al, using ost f ble b(`a`..3)),
       /// lt "leftmost f the match semantdch sdexes tha / ddh as tr  impt3)),
       the maors thhis refor  imr  In tions of any patt up ol grea In t. ///
    /// let re = DFA::nabc|ac)+?")?;
    /// let mut cache = re.create_cache();
    /// let expected = Match::must(0,3caps);
    /// assert_eq!(Some(expectee =/ ddures(&mut cach"abctch());
    ///
    /// # Ok::<(), Box<dyn std::error::Error>>(())
    /// ```
    #[inline]
    pub/ dd<'earI:ct to<t = I<'e>rroFA {
        &,e) {
        cache: &mut C,e) {
     up i:ctlons,
    )Ore op<d = M>ror> {
        let met inpu up inhem nfy());
       ith mar!:new(iself.x").ancho::<red(AnchorNomit() {
         ew(isslf.x").anchored(Anchored::Ye));
        }
           self.get_nfa().pattern_l == 1it() {
            let cit sl= [eq!(Noeq!(];() {
            piect() {
                sFA::try_seicit_s(mut cac&he, inphe: &cit_sext().unwr?;() {
            uld st=&cit_s[0]xt().unwr elfnfy());
            // t=&cit_s[1]xt().unwr elfnfy());
        ) { ret    Some(Mat fn nt saome( { uld s, // t}):Ye));
        }
        ging t=&c   self.get_nfnfa.group_in;   }
        cit_sternt=&ging .ast implicit_sern_l;
            let cit sl= new(veq!(; cit_stern];
            piect     sFA::try_seicit_s(mut cac&he, inphe: &cit_sext().unwr?;() {
        uld st=&cit_s[pie.as_ -> u.len(2]xt().unwr elfnfy());
        // t=&cit_s[pie.as_ -> u.len(2 + 1]xt().unwr elfnfy());
        Some(Mat fn nt saome( { uld s, // t}):e2()
    }

    /// Executes an anchored leftmost forward se*\w`  of cluake the sride
    /// of capturing groups t/// particidpate in a mthem into thn prov the
    /// [`Captureyte vaDFA.no the maiashfk-arbled, tfor [`CapturFA::is_matde2`
    /// is guaranteed) { retOtf8(f`.es.)
    ///
    /// the gian [`Insageostces a fu/ Reske to [`red(Anchored:ssesr, if theuctorthe givlt configuratwne [`red(AnchorNosse( at whi uses the def) DFA.
    ///
    //Pin paack.
    ///
    /// This rout in panirt of the sea-z` cdoes g incomplDFA. Thr thccuy for
    //s to to// asolvirt cm conces:ack.
    ///
    *ll." When thn provian [`Insvlt configuratre2 is not suppongth. the
    //r exampbially pr addinrs not suppos an anTF-8 m    s i cor, the
    /// thccuy-pass wet, us[`red(Anchorpty Pateset`] y abhat enabless
    /// [`Confelf.sttate_ by .set_pat`]* 2'.
    ///
    /d, whethe sea in pa, the cas DFA can to know whetpan::errady exih. the
     or  2'.
    ///
    Us like [`DFA::try_seareven if not want tA haWhensut in panne  an error
    e2` vsison ins DFA.
    ///
    /// # Example
    ///
    /// This shnly a simhis examion of a one-pthe reons thes ectmakes
    /of capturing g the s.h.")
    ///
    /// ```
    /// use regex_automata::{dfa::onepass::DFA, Match, Spah};
    ///
    /// let re = DFA::se))
    ///    ///iceeans thittle the ASs, w. /// Th (correspondfor Unicthe ree))
    ///    / Thaderally ing one-pae))
    /// "r"\b(?P<fi[[:A's apace>\w+)[[:space:]]+(?P<l[[:A's apace>"() },
    /+"])?;
    /// let (mut cache, mut caps) = (re.create_cache(), re.create_captures());
    ///
    /// re.captures(&mut cachBruceeSpaptun ienrzzz", &mut caps);
    /// assert_eq!(Some(Match::must(0, 70..6)), caps.get_match());
    /// assert_eq!(Some(Span::from5..23)), caps.get_g(1tch());
    /// assert_eq!(Some(Span::f60, 70..6)), caps.get_group_by_name("last"));
    ///
    /// # Ok::<(), Box<dyn std::error::Error>>(())
    /// ```
    #[inline]
    pub re.capt<'earI:ct to<t = I<'e>rroFA {
        &,e) {
        cache: &mut C,e) {
     up i:ctlons,
      psache: &mue.captlons,
  or> {
        let met inpu up inhem nfy());
       ith mar!:new(iself.x").ancho::<red(AnchorNomit() {
         ew(isslf.x").anchored(Anchored::Ye));
        }
        sFA::try_se(mut cac&he, inpmut cxt().unwrap2()
    }

    /// Executes an anchored leftmost forward se*\w`  of cluake the sride
    /// of capturing groups t/// particidpate in a mthem into thn prov the
    /// [`Captureyte vaDFA.no the maiashfk-arbled, tfor [`CapturFA::is_matde2`
    /// is guaranteed) { retOtf8(f`.es.)
    ///
    /// o a diffcssaing w[`d [`DFA::capturthat:ack.
    ///
    1ndex. Thid retuan  an eison instead in pk/ beirt of the seaill -pae))
    2. Accepttuan `&n [`Insaon insteadaian to<t = I>`. /// Tset permits reud in
    /// the smet in2`] fes multired search at wh::iy_ all to imonsta error
    l grncypae))
    3. /// This d is n// automatica to change [`red(AnchurtF-8 etch f`Nosonds
    ///`ed:shing. Insteirt[`t = Inpaed(Anchurtlue red(AnchorNoscent, the the
    /an eislways returDFA.
    ///
    ///an eaack.
    ///
    /// This rout/an eanirt of the sea-z` cdoes g incomplDFA. Thr thccuy for
    //s to to// asolvirt cm conces:ack.
    ///
    *ll." When thn provian [`Insvlt configuratre2 is not suppongth. the
    //r exampbially pr addinrs not suppos an anTF-8 m    s i cor, the
    /// thccuy-pass wet, us[`red(Anchorpty Pateset`] y abhat enabless
    /// [`Confelf.sttate_ by .set_pat`]* 2'.
    ///
    /d, whethe seahid retuan  an e, the cas DFA can to know whetpan::er the
    //y exih.  or  2'.
    ///
    /// # Exa: r a speciany pattthe semple
    ///
    /// This example shows howand builfes m-the reons tset permfor searc ///
    sed f a speciany pattabl// Note tha. Thisady somemust llly useher than
    ots ke other regex engther, sinthis one-pass rch by definitine hat no
    ambconplexabouet at whany patthr tn a mattt of transition/ That uit iache
    /, whs impossible  of o a differ of pattetotn a mattt/// the sese stardthe
    / transibled, then fes m-the rewz` cdoes bh the one-p/// and construcs it
    /// wonot hill turDFA.
    ///
    Nll nhenust ,d in thix<dyi// all/// useful if /// ochat abouetith mar ///
    sed a f a speciany patarch, not wait the DFAsly re "no the m", or eve the
    tut s ke otany patt/// wonot hith madof 2.
    ///
    /// Note tis. In orderght mBecause of ence funcalple,less
    /// [`Confelf.sttate_ by .set_pat`]ally mbebhat ellowed.s`] is disa) },
    8ch by defher, siid. It may resulthigwhethhe memory u NFA.
    ///
    /// ```
    /// use regex_automata::{
    ///     dfa::onepass::     Anchored, InpFA, Matpty PattateID,
    Kind};
    ///
    /// let re = DFA::builder()
    ///     .configure(DFA::confielf.sttate_ by .set_pat(T
  tlse))
    ///     .b:new_many(&["[a-z]+", "[0-9]+"])?;
    /// let (mut cache, mut caps) = (re.create_cache(), re.create_captures());
    /// let haystache, "123s());
    /// let input = Input::let haysc3x").anchored(Anchored::Ye );
    ///
    ///Adoe/ No fes m-any pattthe se //`  ple tany patt1 DFA mata ///
    ///(re.try_search(&mut cac&he, inphe: &ut, caaps);
    /// assert_eq!(Some(Match::must(1, 0..3)), caps.get_match());
    ///
       ///use we oyou want ty re any patt0 DFA matbled, twe'`   fn hat no
       the mas, w.());
    /// let inpu ew(isx").anchored(Anchorpty Pat(pty Pattaatch::mu)0..8));
    ///(re.try_search(&mut cac&he, inphe: &ut, caaps);
    /// assert_eq!(None, caps.get_match());
   he);
    /// # Ok::<(), Box<dyn std::error::Error>>(())
    /// ```
    ///
    /// # Exa: f a spy, using bk-artches tthe semple
    ///
    /// This example shows lly pr adding bk-artches tthe sethix<llydu space
    o a different re less tsuld imsub-s impadding ven haystack.
    ///
    /// ```
    /// # if cfg!(miri) { return Ok(()); } // miri takes too long
    /// use regex_automata::{dfa::onepass::D    Anchored, InpFA, M}h());
    ///
       his one-pass enclrenull supdfor Unicw recbk-arariar! ///
    ///Adsnstjoktride ittt ofor Unicawarn the renes l\w+\stre2 is ing one-pae))
       :-( ///
    /// let re = DFA::r"\b", "[{3}\b"]+"])?;
    /// let (mut cache, mut caps) = (re.create_cache(), re.create_captures());
    /// let haystache, "fo234"h());
    ///
       Sr, siwemsub-s imeding ven hays,t of the sea/// does to kaboue3)),
       /// larger forthe nto handumarcxes t`"fonsagesurok-ars usedw re3)),
       bk-arariaro so. ber ouy-e,s to the ma/ transiislway suppos be ernative
       /// to sub-s imedne well 257, which mewem fn `(1, nsaon insteative
       `3.. = 16`.
    /// let expected = Some(Match::must(0,3res());
    /// let input = Input::&ven hays[3.. ]c3x").anchored(Anchored::Ye );
    ///(re.try_search(&mut cac&he, inphe: &ut, caaps);
    /// assert_eq!(expected, caps.get_match());
    ///
       Burcuitwn thn proding bk-artches of the seaespoin urn thethe nor, if theuctor   / idrc ven hays,t ofnt of the sea-s thakclude turok-arsolvihethe s or
    /// /ead cnce crnedto aitwn d vali spenmA, Mather it woulday suppo not
    /// shnl/// va/he offs/ead`ven haysnsaon insteadpermfub-s imea)mple
    /// let expecteeq!(;());
    /// let input = Input::let haysc3ro ch(3.. c3x").anchored(Anchored::Ye );
    ///(re.try_search(&mut cac&he, inphe: &ut, caaps);
    /// assert_eq!(expected, caps.get_match());
    ///
    /// # Ok::<(), Box<dyn std::error::Error>>(())
    /// ```
    #[inline]
    pub(re.try_seaFA {
        &,e) {
        cache: &mut C,e) {
     up i:c&t = I<'_>lons,
      psache: &mue.captlons,
  h() -> Resk::<ome(MuildError> {
        piect     sFA::try_seicit_s(mut cache, inpmut .cit_ste: r>>?;() {
    mut .cps.set_pat(pie:Ye));
    urn Okp2()
    }

    /// Executes an anchored leftmost forward se*\w`  of cluake the sride
    /// of capturing groups t/// particidpate in a mthem into thn prov the
    `cit_s`arch, and returto the mpturany pattID. /// Thethn tions of the
    tit slly, fof patteuse other urto the mpturany pattarn unf a spelloweer of
    // the maiashfk-arbled, t`eq!(`islways retu /// and Thethn tionsan will
    `cit_s`islwunf a spelloDFA.
    ///
    /// Thisnes like [`DFA::try_searhere, in accepttua raw tit sls imethan
    otn insteadaia A `Captures` vtion. This/// usefnvihethe s bs, whhen you
    dodoesyou wh.  ranteedady allodaia A `Captu DFA.
    ///
    /d.s`]leg equalone-p_ew__otal number it sld into this rouaDFA. in the r the
    /ex enr it wouse owise  of cs ttd a lof/ Reseata/// doesfitytes in the
    thn provis imeions, the / Thisd imskipplloweub fe gen 256 thouhat th2`] are
    usuaticathreeis imeabet lesl if hus miyou want///:ack.
    ///
    *lAn new emp imeioful if /// ochat abouet at whany pattith madof 2.
    *lAis imeaespoless
    //a().pattern_l * 2keVM`](craa::{dfa::onepass:::a().pattern) the
    tit sioful if /// ochat abouetake the overn::err.ng ses)' for  the mptu the
    tex pattf 2.
    *lAis imeaespoless
    //cit_sern_lkeVM`](cra    utc [`CapturGng gInfo::cit_sern) tit sio56, which
    set permite rereusi::erring offside for ev/of capturing g tesfor e the
    tex pattf 2.
    ///
    ///an eaack.
    ///
    /// This rout/an eanirt of the sea-z` cdoes g incomplDFA. Thr thccuy for
    //s to to// asolvirt cm conces:ack.
    ///
    *ll." When thn provian [`Insvlt configuratre2 is not suppongth. the
    //r exampbially pr addinrs not suppos an anTF-8 m    s i cor, the
    /// thccuy-pass wet, us[`red(Anchorpty Pateset`] y abhat enabless
    /// [`Confelf.sttate_ by .set_pat`]* 2'.
    ///
    /d, whethe seahid retuan  an e, the cas DFA can to know whetpan::er the
    //y exih.  or  2s.
    ///
    /// # Example
    ///
    /// This example shows how/ ddh as the overn::erring offsetsand a
    nes m-any pattthe se //] y abady all durina A `Captures` vtiIarspectwative
    /ix<l abet y it slrus mised on  haystack.
    ///
    /// ```
    /// use regex_automata::{dfa::onepass::D    Anchored, Inppty Pattaatch};
    ///
    /// let re = DFA::new_manse))
    /// ry(&["A-Z[a-zse))
    /// ry(, "[0-'z'),
    //+?")?;
    /// let mut cache = re.create_cache();
    /// let input = Input::he, "c3x").anchored(Anchored::Ye );
    ///
    ///We /// ochat abouetake the overn::erring offsat t, sotwn juso not
    /// // allod of tit slly,  to eaex patt Eby ead a ite returns tharo not
    /// nd t// /hurto the m.")?;
    /// let cit sl= [eq!(; 4]he();
    /// piect ///(re.try_seicit_s(rch(&mut cac&he, inphe: &cit_seaaps);
    /// assert_eq!(Spty Pattaatch::m0..11pie:Ye));
    ///
    ///Tke the overn::erring offshat ais alwata'piec* 2'/ nd 'piec* 2 + 1'pae))
       `]. 'Gng gInfo'e2`] for mdetll -ised on mapparchas/ betwing gro if and
       tit  //dicet. ///
    /// cit_suld st=&pie.t().unwr as_ -> u.len(2; ///
    /// cit_s// t=&cit_suld st+ 1aps);
    /// assert_eq!(S0.11cit_s[cit_suld s].map(|s| s elfnftch());
    /// assert_eq!(S3.11cit_s[cit_s// ].map(|s| s elfnftch());
    ///
    /// # Ok::<(), Box<dyn std::error::Error>>(())
    /// ```
    #[inline]
    pub(re.try_seicit_s(FA {
        &,e) {
        cache: &mut C,e) {
     up i:c&t = I<'_>lons,
    cit_sache: &[Ore op<eq!MaxU-> u>]lons,
  h() -> ResOre op<pty Patta>:<ome(MuildError> {
        w().new em=&c   self.get_nfhas_new e.le&&&c   self.get_nfis_ ().ufy());
       !w().new em{());
        ) { ret    sFA::try_seicit_s_isd(mut cache, inpcit_seYe));
        }
       `]. vm::Pi`DFA::try_se_tit slly, whytwn d into .r> {
        lint=&c   self.get_nfnfa.group_in.ast implicit_sern_l;
        ier it sable.len= lint{());
        ) { ret    sFA::try_seicit_s_isd(mut cache, inpcit_seYe));
        }
           self.get_nfa().pattern_l == 1it() {
            let ene tho= [eq!(Noeq!(];() {
            gotct     sFA::try_seicit_s_isd(mut cache, inp&let ene thr?;() {
           /// ThisOKr/// becawn  to k`ene th_cit_s`islwtas std onigger() {
           /// thcit_s`aruse owise /// te a specthe ci doesr to adof 2.
ns,
    cit_s.copyuild_fs ime(&ene th[.. it sable.l]fy());
        ) { retOk(got:Ye));
        }
        let ene tho= new(veq!(; lin];
            gotct     sFA::try_seicit_s_isd(mut cache, inp&let ene thr?;() {
       /// ThisOKr/// becawn  to k`ene th_cit_s`islwtas std oniggereher than
       hcit_s`aruse owise /// te a specthe ci doesr to adof 2.
ns,
cit_s.copyuild_fs ime(&ene th[.. it sable.l]fy());
    Ok(got:p2()
    }

    #[in( ll n)line]
pub(re.try_seicit_s_isd(FA {
        &,e) {
        cache: &mut C,e) {
     up i:c&t = I<'_>lons,
    cit_sache: &[Ore op<eq!MaxU-> u>]lons,
  h() -> ResOre op<pty Patta>:<ome(MuildError> {
        w().new em=&c   self.get_nfhas_new e.le&&&c   self.get_nfis_ ().ufy());
    the matc+ sery_seiisd(mut cache, inpcit_se?it() {
        eq!( => ) { retOk(eq!(),() {
        eq!(Spie:    !w().new em=> ) { retOk(eq!(Spie:),() {
        eq!(Spie: =>it() {
               //nsuttit  //dicetshat ais alw/ incorr/// becawn  to kour() {
               'pie're1'/// va/// anusawn  to kugh that tit  //dicetsly,  iache
               hat /// v.ache
            /// cit_suld st=&pie.as_ -> u.l.).unparc_nes(2fy());
            /// cit_s// t=&cit_suld s.).unparc_addm0.;ache
               OKr/// becawn  to kwe not havn a matw`  n  to kour the caache
               thn provis offshat nig ene tho( at whhe, akcluns tabto mve the
) {
           //e the ca d vdoe)able. Namewe're /// oat thass w'w().new e' the
) {
           iturns arch, n." Whea// irns arw/ usion e tit slly,  or e the
               tex pattf 2.
) {
            uld st=&cit_s[cit_suld s].t().unwr elfnfy());
                // t=&cit_s[cit_s// ].t().unwr elfnfy());
               ///our n::err.nl of i he *codepbled, twe DFA can ty re his is
               hs /in a matdto er, sihis one-pass e/// oull supdx").anchs is
               red search e dodoes(re howskip aher lead/ ddh as nhe nthe m.")?;
               Wutass jusotion// it wor aatch")?;
            if uld st== // t&&&! up inhs_char_bk-arary(uld s)it() {
                ) { retOk(eq!()y());
            }());
            Ok(eq!(Spie:)
            }());
    }D>()
    }
}

impl DFA {
fttthe se_isd(FA {
        &,e) {
        cache: &mut C,e) {
     up i:c&t = I<'_>lons,
    cit_sache: &[Ore op<eq!MaxU-> u>]lons,
  h() -> ResOre op<pty Patta>:<ome(MuildError> {
       /ERF: eq!(tateasult rr thumount teamoung afm onyitspec
}

id in e the
       thny /hurtose. the
       the
       1) Tre doreusior mach stshufflatchiRus mito , /// wn d i/ Tsush the
       th:err.11ceponds to t// /hurto /// transition t e also twe DFA d  the
       'if u va>=&c   slin.get_m_ie'rnds to know whetwe're ate in a m the
       ach sth.  or  Burcsomemabouetdoreustut  aatc t unlike deass e if and
       tushatc dInsten a matw` .11cepo it wc [`Capt/les s /// to forw in the
       begi scann/hurto /// transition t. /// twe Dz` cdd i'if u va<= the
       a   slax_e a spe_ie'sage, at whthe ch e  ranteedd itut se a spe the
        tA hcann/hutut sesup. Ose owise,ewem fn ing veppy texh, juso not
       t unlate igle Dhe se12`). Thate rg docutigcontt ha. Thisugh that not
       his one-pass hisnes lyteed tsize uleftm/// of it wc [`Capturing gr not
       ato ait of capturing grohat  in co `2^4 = 16`.hus miy ddhsed // bea and
       texprmizformat the
       the
       2) ss. Consimov/ Usipty PatEpsils. 'thumountrto /// transition t. the
       Ie, it ieralrane used th:err.11cepogh, asuaticaa the s linorplexof the
       ach srohat th:err.11cep API. Therefowe're et, usfor as ex'u64'ta error
       toallesetest the
       the
       3)lt playpos ok-aro it with th:err.11ce  tA hcannato aeeasemisnes 
           //e therethnbabicaa it  red ised on ion t ly,  mthn imple API.
           key
///suratre2ugh that '/ dd.get_m'This routhis igiou wmst ,dbuo not
       .nl ol durit y abinead tm a   #[inon t lce functhis im a uld ser the
       be/ becauserth:err.11ce hus miand ue smet i, sot'/ dd.get_m'TCOULD the
       be the cdtion/eaa it arch, a lce functust caReseatacodept it wobac/h and
       terf. /// Inoramewe Dz` cddetcorrnow whetpan::err.11ce and ue r not
       let in/// andnse a spe> uset y he seahis routted based oat. /// Iao not
       the chmaybe for as exlce functust chisOKhere, ee gi innatherhus mib 
           /oo muerrinaa i grncy hitatdtuse otateatre2uo jusot(re /// .confi not
       he, ows how tdu s and Thstri> useft'/ dd.get_m'hiRE2tine a as sk the
        t thassrcauserth:err tA hcanni doesdq!( aitwn  to kugs nhe nble bof the
       let inhie c(Span::err/oo.<omybe wn adopReseat? the
       the
       /// Tjusothus mib  a as sky the DFAopRrmizt.    }
        up inhs_d).clot{());
        ) { retOk(eq!()y());
        }
       Wn unly,tunA corrnot havbimountbes lkeeppondingd inou/ Reshatcr not
       up. Wn dornot hnou/ Rsedour tht ca/// alhe  /// ofbet y it s. // and
       tIn particulalhe padding tit slre2 t_ neceyalid for the cassrcawi not
        ty re enmA, Matre, q!( untrto  of capturing grod vdoet/// partici the
       leauserth:errre, had a f s tsphabch froprevious Dhe se12`)apt it w the
       be bad. /// Inoramewe Dz` cdavo va/// t// teit  alhe paddaitwn  tew
           //at for eveit  iashais alwa fuv created for evn a maton/ twe  it w the
        to kugsyt it woais alwbe the  of / of d, whethe maishfk-ar.r> {
        ons expl_cit_sternt=&use cocmp::lin(() {
        eit_sa:LIMIT,f 2.
ns,
    cit_s.ble.l.satnfigung_sub:all(sons expl_cit_suld s),() {
    );e) {
        ca/ Rse.try_seaons expl_cit_stern);e) {
    sed fit  //     caons expl_cit_slot{());
        *fit  teeq!(;());
        }
    sed fit  // cit_s.n/erte: r>t{());
        *fit  teeq!(;());
        }
       Wn / Reset ese starttit slly,  or ehany pattsedbchle API/ This  the
       le re.suset yi grncy ady somehere, in avo vsrnotpondingd iit  or e the
       /imsiwemseetpan::err.11ce ( at whcit wouldthny /imsfsetsaby a si
           red senirt of n::err.11ce and ue r  up i).   }
    sed pieciet    self.fof pattr>t{());
        /// lt=&pie.as_ -> u.len(2; ///
  }
        a>=&cit sable.let() {
            bre.k;
            }());
        cit_s[i] teeq!MaxU-> unput:: ew(issse s():Ye));
        }
        let piect eq!(;());
        let nhe _siect n a mthew(iself.x").ancho:et() {
        red(Anchored: =>i  + self.s(),() {
        red(Anchorpty Pat(pie: =>i  + self.s.set_pat(pie:?,() {
        red(AnchorNo =>it() {
               FA. in the rThisyt  + hais alwa   Anchored, twe'ra / de,() {
                or evet of the seaage i .confidteed tsina   Anchh")?;
            if !    self.hs_ais alsuld s.x").ancho:et() {
                ) { retErr(ome(MuildE::s not suppo.x").ancho() {
                    red(AnchorNo,() {
                ))y());
            }());
              + self.s()
            }());
    };());
        red left_ost f t() {
        ith mar!:   &self.cocaps.get_m_k ddu::<ome(MK dda:Led leftFst f);e) {
    sed e tis. ew(issse s().. ew(isendr>t{());
        /// siect nhe _sie;() {
            /// tct     sFA/ transi(st sa ew(islet hays()[at]fy());
        nhe _siect FA/ t. fn stidnfy());
            /psils. ct FA/ t./psils. nfy());
        if u va>=&c   slin.get_m_ieet() {
                   s/ dd.get_m(mut cache, inpmehest satit sio&let pie:et() {
                    up inaps.or  impt()() {
                    || (red left_ost f && FA/ t.get_m_wi. nf)() {
                {() {
                    ) { retOk(pie:Ye));
                }());
            }
            }());
        if u va== DEAD
                || (!/psils. .les s_nfis_new e.le));
                &&&!    self.les .get_muild.ith mar_cps.  #[in(() {
                    /psils. .les s_n,() {
                     ew(islet hays(),() {
                    meh() {
                ))
            {() {
            ) { retOk(pie:Ye));
        }());
        /psils. .cit_slo.apply(at,     caons expl_cit_sloeYe));
        }
       nhe _siec>=&c   slin.get_m_ieet() {
            s/ dd.get_m(() {
            cut C,e) {
             ew(i,e) {
             ew(isendr>,e) {
            nhe _sie,e) {
            tit sie) {
            &let pieie) {
        eYe));
        }
    Ok(pie:p2()
    }

    Andumarc'sie're1'pan::err.11ce /// les s ly, whw whetpan::errcr than
    //day suppoaDFA.sonpmpproprih sthng offshat  of / ofeed'tit s'o if and
    'ith mad_pie're1'/ Reskerto the mpturany pattID.());
    ///
    Ee giass w'sie're1'pan::err.11ceathe'shs impossiote that e maiodoethan
    //day suppoaD/// For exampw." When crespormatio/psils.r of transit ///
    //asponding of n::err.11ce hatdoetsatispellattt/// the gi/ transiisnd in
    /// ven haystack.
#[cfg_ny r(feag fug= "terf   #[in"ache#[in(ais al))line]
pub/ dd.get_m(() {
        &,e) {
        cache: &mut C,e) {
     up i:c&t = I<'_>lons,
    ai:c -> ulons,
    cid: f::<Stalons,
    cit_sache: &[Ore op<eq!MaxU-> u>]lons,
    ith mad_pieache: &Ore op<pty Patta>:ons,
    )boolror> {
    debug_n// as!)siec>=&c   slin.get_m_iefy());
        ticiptct     sa().patt/psils. nsiefy());
        /psils. ct ticipt./psils. nfy());
    if !/psils. .les s_nfis_new e.le));
        &&&!    self.les .get_muild.ith mar_cps.  #[in(() {
            /psils. .les s_n,() {
             ew(islet hays(),() {
            meh() {
        le));
    {());
        ) { rettf8(fYe));
        }
        piect ticipt.a().pattid_uan  ckednfy());
       /// Tcalartifuncthis is alw/ incorr/// becawn  to kour 'pie're1());
       /// va/// anusawn  to kugh that tit  //dicetsly,  i hat /// v.ache
    /// cit_s// t=&pie.as_ -> u.l.).unparc_nes(2f.).unparc_addm0.;ache
       `] that ast impl '// ' tit  lid for the mpturany patatch.ew'sse s'
           rit  iash/ Reh that begi scann/hurto Dhe se1)
        ier it s// t<&cit sable.let() {
        cit_s[cit_s// ] teeq!MaxU-> unput::at)y());
        }
       If //e the ca thn proviene thoroom,  opyWhen theviousedibte reew the
       ons explttit sllch fet y M`](err.ngceding of the ca thn provicit sa   }
       Wn *ote *  ranteed/ Rehny ons explttit slxes that a fuvedne /// bof the
        of anyhding of n::err.11ce.   }
           sons expl_cit_suld st<&cit sable.let() {
           /OTE:2`). '    caons expl_cit_slo'is imeae1'/ Rup h that not
           begi scann/hufor evehe seasu maors the / T is guaranteed) { reta not
           s imea/hubet leways equivalent'tit s[ons expl_cit_suld s..]'.() {
        cit_s[c   sons expl_cit_suld s..]() {
            .copyuild_fs ime(    caons expl_cit_sloeYe));
        /psils. .cit_slo.apply(at, he: &cit_s[c   sons expl_cit_suld s..])y());
        }
    *ith mad_piected = Spie:Ye));
    rns D>()
    }
}

impl DFA {
    /// Returns  an anchould st.11ce sed th:er addingnany pattate in this FA {
ftttse s(age(&self)f::<Stasize {
        self.st[0]e2()
    }

    /// Returns  an anchould st.11ce sed th:er add/// the gi/ny patateer of
    'elf.sttate_ by .set_pat's it
    /a does nn disabled, the. Thid retuan  an eaDFA. in the gi/ny patThis is
    nottate in thisbled, t`Ok(eq!()`islways returDFA.
ftttse s.set_pat(    &, pieacpty Patta  h() -> Resf::<Stal<ome(MuildError> {
    if !    self.cocaps.elf.sttate_ by .set_pat(ot{());
        ) { retErr(ome(MuildE::s not suppo.x").anchored(Anchorpty Pat(() {
            pieie) {
        e))y());
        }
       'elf.st's is alwine han- // ubet le12`). ost f iva evhis is alwhat not
        an anchould startt11ce sed /// fof patt, /// and to// asolviva is  the
       hat opormatio/// an (corresding of  an anchould startt11cesta error
       fof pattea  pie+1ndexugthelf.starts.l-1ti>0 corresponds to the trror
       tal number of pattetrs tooutass ons expllevehe seaf eaDedto ad. It the
       be  // 1)
        Ok(  + self.staelfnpie.oou_ior loe.copiednf.t().un_or(DEAD)de2()
    }

    /// Returns /// transitlch f in the git11ce tas/// ble bofg up inpTin the
    /// transitnys incluake nhe nt11ce ta,ding tit slxes tFhit wouldsavov the
    ch, angncrespormatio/psils.r of transitlxes tlly mbebsatispellais. In oonds
    /// akcluditurnf transi.ine]
pub(r/ transi(    &, cid: f::<Stal ble :c 8  h()f::<Transiror> {
        lof/ Re= cid.as_ -> u.le  1 << self.stridy());
        clne-pt     sclne-etaelfnble r as_ -> u.l;of;

        self.t[lof/ Re+ clne-]e2()
    }

    `] that /// transitlch f in the git11ce tas/// ble bofg up ifers to for
    /// transitthe grDFA.
ftttps.(r/ transi( e: &c  &, cid: f::<Stal ble :c 8,dio:)f::<Transi)ror> {
        lof/ Re= cid.as_ -> u.le  1 << self.stridy());
        clne-pt     sclne-etaelfnble r as_ -> u.l;of;

        self.t[lof/ Re+ clne-]ct Fo;e2()
    }

    /// Reuan n/eratoumber" or sp"r of transitllid for the git11ce ta. ///
    " or sp"rate in tthethe nich mexes tand / Exuved of transitlxes t2`] are
    ays equivalarn ths retu / thisring g,e/// aof transitlxds to DEADit11ce the
    c thegnAnchh")?;
    ///
    /// Ty ddshsed // be/// uselid debug papttwritier, siid's muerrn,e( oonds
    ///display ru spans ys equivaleof transitlxesnthat /// transitly,  or e the
    / tmpossible bes` vtiIarspectix<lla fuceathe'shor ev/in cotly, ru sride
    /// ys equivaleof transitlxopmpphe rDFA.
ftttor sp.(r/ transis(    &, cid: f::<Staself)for spf::<TransiIn,e<'_>ror> {
        uld st=&cid.as_ -> u.le  1 << self.stridy());
        // t=&cld st+  << sA's abe_sern_l;
        for spf::<TransiIn,eit() {
         t:     self.t[uld s..// ].n/ernfiotalerate(),() {
        cur: eq!(,());
    }D>()
    }

    /// Reu of any patt/psils. clid for the git11ce ta. ///
    ///
    /ff in the git11ce tasDFA does  n (corresdingpan::err.11ce ta,dinges in the
    tny patt/psils. cths retu / Thew erDFA.
ftta().patt/psils. n    &, cid: f::<Staself)pty PatEpsils. ror> {
        lof/ Re= cid.as_ -> u.le  1 << self.stridy());
    pty PatEpsils. (    self.t[lof/ Re+     sa()/ps_lof/ R].0)e2()
    }

    `] that any patt/psils. clid for the git11ce ta. ///
ftttps.a().patt/psils. n e: &c  &, cid: f::<Stal a()/ps: pty PatEpsils. )ror> {
        lof/ Re= cid.as_ -> u.le  1 << self.stridy());
        self.t[lof/ Re+     sa()/ps_lof/ R]e= f::<Transi(ticipt.0);e2()
    }

    /// Returns t11ce taspaporlxds to hisrihe grdex. Thid retuNq!( ait if theuctorthe gitasi uses ost f gle D11ce.   }
fttarev_ fn stidn    &, id: f::<Staself)Ore op<f::<Starror> {
    if  va== DEADit() {
        eq!(());
    } elseet() {
           CORRECTNESS: Sr, si'ie're1'oes ses ost f .11ceatsubs ect/ be1
) {
           itu is alw/// v.ache
        eq!(So::<Sta DFA::uan  ckednie.as_ -> u.l.n  cked_sub:1cxt().unwr))
        }e2()
    }

    /// Returns t11ce tas/hurto me(" t11ce ate in this's /// transition t. the
    "me("lrate in tthethe nich mexeo me(" t11ce xopmpphe ratehhe me, i.e.,d in
    /// q!(  it with gre.cr(" ta. ///
fttme("_ fn stidn    &self)f::<Stasize {
       CORRECTNESS: A the Don t itu is alwhan-new empr, siid.ais alwat not
       tee(" thetconte igEADit11ce. Sr, sifor eve11ce  tst/// the sesf.st, not
       wutass jusotg inutecsomemng, unhe " t11ce tas/// wonot hady b if and
       andnseubs ect 1tlch fit.ache
    o::<Sta DFA::uan  ckednache
        (    self.table.len>1 << self.stridl.n  cked_sub:1cxt().unwr,() {
    )e2()
    }

    Mto mhat /// transisllch f'ie1'rnds'ie2'/ nd vimeaor sa* 2'.
    ///
    /ARNING: /// This d is upd1ce xserenta /hurto /// transition t tornot  for
    /// transisrnds'ie1'r to chdrnds'ie2'/ nd vimeaor sa* /// Tlercorrmto sd in
    /// t11cestatehhe me.ine]
   (super)
ftttwun_t11cesn e: &c  &, ie1: f::<Stal ie2: f::<Staseor> {
        l1npu d1.as_ -> u.le  1 << self.stridy());
        o2npu d2.as_ -> u.le  1 << self.stridy());
    lid btate0.. << self.st.let() {
        c   self.tatwun(l1n+ b, o2n+ b)y());
        }
    }

    Map /// t11ce tas ate in this (/// transition t +ould st.11ces>(())
     cncrsponding of clos fugthe grDFA.
   (super)
fttremap( e: &c  &, map:c
}

iFn(f::<Staself)f::<Staseor> {
    ly,  tate0.. << seln stble.let() {
            lof/ Re= ie  1 << self.stridy());
        lid btate0.. << sA's abe_sern_l {() {
                nhe n=     self.t[lof/ Re+ b]. fn stidnfy());
                self.t[lof/ Re+ b]. e"_ fn stidnmap(nhe ):Ye));
        }());
    }r> {
    ly,  tate0.. << selnr sable.let() {
        c   self.st[i] temap(c   self.st[i])y());
        }
    }
}

iuse cofmt::Debug ly, mpl DFA {
fttfmtn    &, fache: &use cofmt::Fe/ Ny Paself)use cofmt:: -> Reeor> {
    ln debug_ fn st(r/ transis(());
        lache: &use cofmt::Fe/ Ny Pa,() {
        a::{ &hisb() {
        cid: f::<Stalons,
    self)use cofmt:: -> Reeor> {
        ly, (i, (uld s, // , /// t))isnd in
) {
        a::.tor sp.(r/ transis(siefiotalerate()
            {() {
                nhe n= FA/ t. fn stidnfy());
                a> 0 {() {
                 of c!(&, -z]+r?;() {
            }());
            if uld st== // t{() {
                 of c!(() {
                    f,() {
                    "{:?} =>it:?}",() {
                    DebugBle (uld s),() {
    ) {
            nhe .as_ -> u.lh() {
                )?;() {
            } elseet() {
                 of c!(() {
                    f,() {
                    "{:?}-{:?} =>it:?}",() {
                    DebugBle (uld s),() {
    ) {
            DebugBle (// ),() {
    ) {
            nhe .as_ -> u.lh() {
                )?;() {
            }());
            if FA/ t.get_m_wi. nf {() {
                 of c!(&, - (MW)+r?;() {
            }());
            if !FA/ t./psils. nffis_new e.l {() {
                 of c!(&, - (t:?})", FA/ t./psils. nfr?;() {
            }());
        }());
        urn Okp2()
  }
    }

     of cln!(&, -fa::onepass:(+r?;() {
    ly,  nd rThte0.. << seln stble.let() {
            siect o::<Sta Dch::m nd rfy());
            ticiptct     sa().patt/psils. nsiefy());
        if u va== DEAD {() {
             of c!(&, -D]+r?;() {
        } elseeif ticipt.a().pattidnffis_ady .l {() {
             of c!(&, -*]+r?;() {
        } elsee{() {
             of c!(&, - ]+r?;() {
        }
             of c!(&, -{:06?}", cid.as_ -> u.lr?;() {
        if !ticipt.is_new e.l {() {
             of c!(&, - (t:?})", ticiptr?;() {
        }
             of c!(&, -:]+r?;() {
        debug_ fn st(r/ transis(&, c  &, cidr?;() {
         of c!(&, -\n+r?;() {
    }  }

     of cln!(&, -+r?;() {
    ly, (i, &sie:  n c   self.st.n/ernfiotalerate()it() {
            a== 0 {() {
             of cln!(&, -START(ALL):it:?}", cid.as_ -> u.lr?;() {
        } elsee{() {
             of cln!(
                    f,() {
                -START(a().pat:it:?}):it:?}",() {
                  - 1,() {
                cid.as_ -> u.l,() {
            r?;() {
        }
        }  }

     of cln!(&, -t11ce bet le:it:?}", c<< seln stble.lr?;() {
     of cln!(&, -any pattbet le:it:?}", c<< sa().pattern_lr?;() {
     of cln!(&, -)+r?;() {
    urn Okp2()
         An n/eratoumbup oing grober od / Exuved ys equivaleof transitletsaby a si
/   ach s.
#[deruve(Debug)]
 const)for spf::<TransiIn,e<'arror> {
 t: use con/er::Etalerate<use cos ime::In,e<'a, f::<Transi>>:ons,
cur: Ore op<( 8,d 8,df::<Transi)>:o  }
}

<'arrI/eratoumly, for spf::<TransiIn,e<'arror> {
typerI/emaps) 8,d 8,df::<Transi);
FA {
fttnhe ( e: &c  &self)Ore op<( 8,d 8,df::<Transi)>e{() {
    while     eq!(S(b, &/// t))it     sit.nhe (let() {
           Froutt// becawn'`   ll nonot hiorcausinrs8::MAXleof transitlet() {
           q!( .11ce.   }
            bit b.as_ 8nfy());
            (arev_ fn s, arev_// , arev_/// t)ct n a mt    scure{() {
            eq!(St: =>ii,e) {
            eq!( => {() {
                    scure= eq!(S(b, b, /// t))Ye));
                thetinue;() {
            }());
        };() {
        if arev_/// ta== /// ta{
                    scure= eq!(S(arev_ fn s, b, arev_/// t));() {
        } elsee{() {
                scure= eq!(S(b, b, /// t))Ye));
            if arev_/// t. fn stidnf != DEAD {() {
                ) { reteq!(S(arev_ fn s, arev_// , arev_/// t));() {
            }());
        }());
        }
           eq!(S(uld s, // , /// t))i=     scur. akc()it() {
           /// t. fn stidnf != DEAD {() {
            ) { reteq!(S(uld s, // , /// t));() {
        }
        }  }

    eq!(());
         A tht careareshn tie: on t e11ce xte thahis one-pike [`] usion es dcaptura
/   ahe se1
/  
/   Fed a the gihis one-pass,dpermTh (correspondtht ca It be tre.crd ei whetvia
/   [`d [`DFre.create_carheoetviatfor   caDFA:`]npTiny c th ys equivaltesfor e     /ay, /xcept and tormca dis d is usion e ons expllev to impondor   c`1
/  
/   A tIn particdor   c`aage iup cdt it with his one-pass lch f at whi  ias
/   tre.crdowed. It  iera tsize u it witat his one-pass. A tht caato aes
/   ady all sitl It be rs ourpoze uviatfor   caDreshtarhege, at whthe chitrcr t    /iera tsize u it wite nhw his one-pass (ato oes ses o woune).
#[deruve(Clq!(NoDebug)]
     const)r   c DFA {
    SM`](err.ngcedize ueed/to e tit sldcaptura Dhe se12Basomatic,thittled in
    /// the ca thn provicit sueed/to e tit sl to of d, whethe mahccuy-. the
    Burcung afhethe mahccuy-,thithus miandtinuewhethe seare, es mmA cor ///
    sai
id ihe e// and n a mat/d, wandtinupadding the sech e  rantady  the
    tlgceding/to e cr did1ce c [`Capthng offs//] y abthe  of padding tit ride
    //g offsbte reew lid for toallbteivalevehennthe m.")?;
ons expl_cit_s: Vec<Ore op<eq!MaxU-> u>>, ///
    /// tal number it slin urn the ca-thn provi' A `Capt'bes` v lid fortive
    /urifferDhe se12`). Thisais alwatatoall'ons expl_cit_sable.l',dbuo not
    nus mib  ust lusinrit,evet of the ca thn provifewericit sueedfill.")?;
ons expl_cit_tern:c -> ulo  }
}

ir   c DFA {
    Cre.crs imhw [`fa::onepass:`]gure)     ca 2'.
    ///
    A tothn iaticaiorcaande giffereis routeedcre.crs itht cahis is
    [`d [`DFre.create_carheaisyt dis d is usion e ote v to impondfortive
    or   c`atype. ///
    ///
    /ff if you want tbecauserths retu or   c`a it wtut s ke othis one-pass,d in
    ///nl if husotg/// for   caDreshtaru it wite desir bases one-pass.ine]
    pubFA::re{ &hisself)r   c DFA {
        let mut cachr   c D
ons expl_cit_s: new(v],
ons expl_cit_tern:c0 };() {
        caresht:re);e) {
        ce2()
    }

    /// Reshas mut casu maors the ass  tsize used for searcu it wapace
    o a differ[`fa::onepass:`]gure)a 2'.
    ///
    A tht care/ Reset permits reuthhe memalre.dy/ // allodrate in tt   ce2()
    /it wa o a differses one-pass.ine]
    ///
    /// # Example
    ///
    /// Tple shows howrs ourpozes itht cased becawit wa o a differses one- ///
    ass.ine]
    ///
    /// ```
    /// # if cfg!(miri) { return Ok(()); } // miri takes too long
    /// use regex_automata::{dfa::onepass::DFA, M}h());
    ///
    /// le1t re = DFA::r"\w"]+"])?;
    /// re2t re = DFA::r"\W"/+?")?;
    /// let mups1ct //1, re.create_captur?")?;
    /// let mups2ct //2, re.create_captur?")?;
   ")?;
    /// let mut cache 1= re.create_cache();
    /// assert_se))
    /// d = Some(Match::must(0,2:),() {
    /// {he 1= te_capturch(&mut cac"Δ"nphe: &ut, 1k((ut, 1caps.get_mat },() {
    :Ye));
    ///
    ///U reut'    c'awit wre2te1'oes  // wrdowed. It may result in pxih.s or
    /// // incorrent re . /// In orderrs ourpozes of tht cachithuallbt/ Rs or
    /// tt it with his one-pass wn'd t unlant//// tt it pae))
       ///
       Srmiticic,tung afhe. Thi/ R, et, us of tht ct it w'e 1're1'pte vnoo not
    /// // wadof 2.
    //2,hi/ Reate_carch(&mut cche();
    /// assert_se))
    /// d = Some(Match::must(0,3:),() {
    /// {he 2= te_capturch(&mut cac"☃"nphe: &ut, 2k((ut, 2caps.get_mat },() {
    :Ye));
    ///
    /// # Ok::<(), Box<dyn std::error::Error>>(())
    /// ```
    pubresht: e: &c  &, re{ &hisse{r> {
        ons expl_cit_ternt=&reself.get_nfnfa.group_in.ons expl_cit_ternidy());
        sons expl_cit_sares> u.ons expl_cit_ternNoeq!(dy());
        sons expl_cit_ternt=&ons expl_cit_tern;e2()
    }

    /// Returns heapthhe memory uhege,ble -,tuse of e    ca 2'.
    ///
    /// This d**noo**tnys incd on  haysri> usize used ye of e    ca Tat no
    g inutectomehe////`dyn shhe::i> u_of# Or   c>()`.ine]
    pubhhe me_ory un    &self) -> usize {
        sons expl_cit_sable.l * use cohhe::i> u_of# OOre op<eq!MaxU-> u>>()e2()
    }

fn
ons expl_cit_s( e: &c  &self)he: &[Ore op<eq!MaxU-> u>]size {
     e: &c  &sons expl_cit_s[.. << sons expl_cit_tern]e2()
    }

fn
/ Rse.try_sea e: &c  &, ons expl_cit_tern:c -> u)size {
        sons expl_cit_ternt=&ons expl_cit_tern;e2()
         Reareshn tiaby a si /// transitnythahis one-pass.i/  
/   /// higw 21vbimsti>0 corresponds to t11ce ta. /// bimoto// asolvi>0 corresp
/   /// to s a spec"t e maiins" flag. /// remaiscann/ a 42vbimsti>0 correspond
    /// /// transit/psils.  257, whthetconteing tit slxes tFhit wouldsavovf d, 
    /// t/// transitnsoto// atu /// and Thespormatio/psils.r of transitlxes 
    ney mbebsatispellais. In oueedfo// aluditurnf transi.i#[deruve(Clq!(NoCopc,tEqnpptr iatEq)]
 const)f::<Transi(u64);
F
}

if::<Transiror> {
 od t STATE_ID_BITS:c 64t=&21aps);
 od t STATE_ID_SHIFT:c 64t=&64t-if::<Transi::STATE_ID_BITSaps);
 od t STATE_ID_LIMIT:c 64t=&1e  1f::<Transi::STATE_ID_BITSaps);
 od t MATCH_WINS_SHIFT:c 64t=&64t-i(f::<Transi::STATE_ID_BITSt+ 1)aps);
 od t INFO_MASK:c 64t=&0x000003FF_FFFFFFFF;   }

    /// Reuaimhw /// transitiof in the git11ce tas it with ghe gi/psils. .FA {
fttnhw(get_m_wi. :)bool, cid: f::<Stal /psils. : Epsils. )rh()f::<Transiror> {
        get_m_wi.  t() {
        / #get_m_wi.  {&1e  1f::<Transi::MATCH_WINS_SHIFT } elsee{c0 };() {
        siect cid.as_ 64.le  1f::<Transi::STATE_ID_SHIFT;() {
    TA/ transi(st  |#get_m_wi.  |i/psils. .0de2()
    }

    /// Returns t/ #/// /ieraif /// t/// transitcodeptlxds to DEADit11ce.FA {
ftths_de.d(c  &self)boolror> {
    c<< seln stidnf == DEAD
        }

    /// Reuwhw whet/// t/// transitine a "t e maiins" prop asy* 2'.
    ///
    /d, whe/// transitine /// tprop asyatherhch mexes t/ #/rth:err tshady  ///
    sk-aro/// and the sea///s red left-ost f .emant px,dinges iatan::er the
    Fhit wouldths retu /mmediA corrotn insteadandtinupaddona 2'.
    ///
    //e "t e maiins" nhe sg iesllch fRE2 257, wh///s ropretty muer for
    /dhn ictiome to ism ly,  mtlimplecann/ed left-ost f .emant px.FA {
fttget_m_wi. n&c  &self)boolror> {
    (c   s0en>1f::<Transi::MATCH_WINS_SHIFT & 1) == 1D>()
    }

    /// Reu of unhe " t11ce tasugh tha/ t/// transitcodeptlxdrDFA.
ftttse stidn    &self)f::<Stasize {
       OKr/// becaa)f::<Transirh shnl/// vaf::<Stasis. tshsep avbimstbt the
        od tonstnsi. /// Te(" ant//> use1'pte v/ incor,  or esir16-bit not
       targemstb// bec,tigcon,twn  to kugs sep avbimstishnl/// vaf::<Sta, not
       wat whthn  ll nothe f/ al//> uson angnnot suppostargem.ache
    o::<Sta DFA::uan  ckednache
        (    s0en>1f::<Transi::STATE_ID_SHIFT).as_ -> u.l,() {
    )e2()
    }

    `] that unhe " t11ce tasate in trnf transi.ine]
pub e"_ fn stidn e: &c  &, cid: f::<Sta)size {
    *  + h=1f::<Transi::nhw(a   slat_m_wi. nfhest sat   sopsils. nfr;D>()
    }

    /// Reu of /psils. cembeddodrate in trnf transi.ine]
pub/psils. n    &self)Epsils. ror> {
    Epsils. (    s0 & f::<Transi::INFO_MASK)   }
    }
}

iuse cofmt::Debug ly, f::<Transiror> {
fttfmtn    &, fache: &use cofmt::Fe/ Ny Paself)use cofmt:: -> Reeor> {
           shs_de.d(ot{());
        ) { ret of c!(&, -0");() {
    }  }

     of c!(&, -{}", c<< seln stidnffas_ -> u.lr?;() {
           sget_m_wi. nf {() {
         of c!(&, --MW+r?;() {
    }  }

    if !    s/psils. nffis_new e.l {() {
         of c!(&, --t:?}", c<< s/psils. nfr?;() {
    }() {
    urn Okp2()
         Aareareshn ifunctofgpan::err.11ce'shsny pattID'ptorcu it w of /psils. ca er    /d, whethe mahccuy-. /  
/   A n::err.11ce nythahis one-passhe/nt unlate iiorca fe gen assheh shexastd t    /ierany pattID. Iftherhad merefoinges in. IigiatioNss wz` cdoes not hady t    /ie one-.i/  
/   /// "/psils. " /// bofe in tth0 correspondssomemiashfk-arlin urn /psils.
    /// transisras/ betwrto /// transitiokenlin urn me(" ble bofg up if/// and
    es mmA c n::err.11ce. /// Tlus minys incdsotponds offshnd/y, Thespormati
    /psils.r of transitlxes tlly mbebsatispellabTheretooutass  ty re rto the m."/  
/   /e tnomatic,tfor eve11ce  tstroom sed /sipty PatEpsils. 'here, in  it ier
    /l nohan-new emsed th:err.11cep.i#[deruve(Clq!(NoCopc)]
 const)pty PatEpsils. (u64);
F
}

ipty PatEpsils. ror> {
 od t PATTERN_ID_BITS:c 64t=&22;r> {
 od t PATTERN_ID_SHIFT:c 64t=&64t-ipty PatEpsils. ::PATTERN_ID_BITSYe));
  lAisplecaelbes` v //dicampondfoat ha. Thisoes   n::err.11ce. We dodoee));
  lbeca0mpr, si0tishnl/// vaany pattID.());
 od t PATTERN_ID_NONE:c 64t=&0x00000000_003FFFFF; ));
 od t PATTERN_ID_LIMIT:c 64t=&pty PatEpsils. ::PATTERN_ID_NONE; ));
 od t PATTERN_ID_MASK:c 64t=&0xFFFFFC00_00000000; ));
 od t EPSILONS_MASK:c 64t=&0x000003FF_FFFFFFFF;   }

    /// Reuaimhw new emany patt/psils. cfoat ine hahsny pattID'pnd ine ha are
    apsils. .2`). Thissuiion t ly, han-th:err.11cep.ine]
pub/ew e.l lf)pty PatEpsils. ror> {
    pty PatEpsils. (() {
        pty PatEpsils. ::PATTERN_ID_NONE() {
              1pty PatEpsils. ::PATTERN_ID_SHIFT,() {
    )e2()
    }

    Whw whet/// tany patt/psils. c/ Thew eth.  or  Ie'shhew et/d, wherhais is
    nohsny pattID'pnd aub/ew ei/psils. .FA {
fttis_new e.c  &self)boolror> {
    c<< sa().pattidnffis_n).clot&&&c   s/psils. nffis_new e.lD>()
    }

    /// Reu of any patttasate in tany patt/psils. c/ftoout//y exrDFA.
ftta().pattid(c  &self)Ore op<pty Patta>ror> {
        piecte    s0en>1pty PatEpsils. ::PATTERN_ID_SHIFT;() {
       p va== pty PatEpsils. ::PATTERN_ID_LIMITit() {
        eq!(());
    } elseet() {
        eq!(Spty PattaatFA::uan  ckednpie.as_ -> u.l))
        }e2()
    }

    /// Returns any patttas//] y abn  ckarcu hw whethe'sho// v. /ff i. Thitive
    /ie cdt/// and therenohsny pattID'ate in t`pty PatEpsils. `bled, the. e2()
    /illsnes lytprodu s an/ // incorrent reth. / tmposy  or eat in pih.s or
    r thhe f/ a  Burcsafe et/illsoes bebviol.crdo 2'.
    ///
    /// T/ T/// usew//nl if  to ka tIn particd.11ce ns   n::err.11ce. eer of
    he'shpan::err.11ceattd, wherlly mnot havany pattID.());
ftta().pattid:uan  ckednc  &self)pty Pattaror> {
        piecte    s0en>1pty PatEpsils. ::PATTERN_ID_SHIFT;() {
    pty PattaatFA::uan  ckednpie.as_ -> u.l)e2()
    }

    /// Reuaimhw any patt/psils. c it with ghe giany pattIDhere, /// the  are
    apsils. . ///
ftttps.a().pattid(c  &, pieacpty Patta  h()pty PatEpsils. ror> {
    pty PatEpsils. (() {
        npie.as_ 64.le  1pty PatEpsils. ::PATTERN_ID_SHIFTle));
            | (    s0 & pty PatEpsils. ::EPSILONS_MASKl,() {
    )e2()
    }

    /// Reu of /psils. c/// bofe in tany patt/psils. .ine]
pub/psils. n   &self)Epsils. ror> {
    Epsils. (    s0 & pty PatEpsils. ::EPSILONS_MASKle2()
    }

    /// Reuaimhw any patt/psils. c it with ghe gi/psils.  2re, /// the  are
    any pattID.());
ftttps./psils. n   &l /psils. : Epsils. )rh()pty PatEpsils. ror> {
    pty PatEpsils. (() {
        n    s0 & pty PatEpsils. ::PATTERN_ID_MASKle));
            | ( 64cofrom(/psils. .0d & pty PatEpsils. ::EPSILONS_MASKl,() {
    )e2()
    }
}

iuse cofmt::Debug ly, pty PatEpsils. ror> {
fttfmtn    &, fache: &use cofmt::Fe/ Ny Paself)use cofmt:: -> Reeor> {
           shs_new e.l {() {
        ) { ret of c!(&, -N/A"eYe));
        }
           eq!(Spie: = c<< sa().pattidnf {() {
         of c!(&, -{}", pid.as_ -> u.lr?;() {
    }  }

    if !    s/psils. nffis_new e.l {() {
               sa().pattidnffis_ady .l {() {
             of c!(&, -/+r?;() {
        }
             of c!(&, -{:?}", c<< s/psils. nfr?;() {
    }() {
    urn Okp2()
         Epsils. cthareshn tia// ofb/// Nss /psils. cfof transitlxes twivaltexopm
/   a a si /// transitnythaa a si gle D11ce. /// If e  e chitr/ierathareshn t
    /// /psils.r of transitlxes tnot htut sk dd ofbhan-and uepondsincdeffcor:
    /i whet//i /// transitusion es /to , us of turiffer/ transii/hurto Dhe se
    inead tsit aroet//i /// transitn tthespormatio/// usion es  of turiffe
    / transitnythat aup iferssatispe // /// asnsitbTheret//i /// transit It be
    /oken.i/  
/   //nsoto/ds  of tumrtifuvcdeffcortofgpanfa.gtofgNle D11ces (a// thencored
/   by /psils.r of transit) down inead ts a si semountbie . While rtosetbie 
/   tss  tyreshn  /// f tmpossiThespormatio/psils.r of transitchitr/ieraset per
/   aco , us.gtead tsdy some the s tal number it s.i/  
/   Epsils. c/ T tyreshn tu / ta 42-bit ineegeraD/// For exampin  itpacked inea
    /// / atr 42vbimstofgpa`f::<Transi`. (Wssrcauserhigw 22vbimsti>etconte 
    `f::<Sta`rch, a s a spec"t e maiins" prop asy*)i#[deruve(Clq!(NoCopc)]
 const)Epsils. (u64);
F
}

iEpsils. ror> {
 od t SLOT_MASK:c 64t=&0x000003FF_FFFFFC00; ));
 od t SLOT_SHIFT:c 64t=&10; ));
 od t LOOK_MASK:c 64t=&0x00000000_000003FF;   }

    Cre.crs imhw /ew ei/psils. .wed.ine hahs offshnd hah/// asnsis/ Iao not
    neidteed tssatispell.ine]
pub/ew e.l lf)Epsils. ror> {
    Epsils. (0de2()
    }

    /// Returns t/ # If e/psils. ci>etcontehahs offshnd hah/// asnsis.FA {
fttis_new e.c  &self)boolror> {
    c<< s0a== 0e2()
    }

    /// Returns tit  /psils.r of transit.());
ftttit_s(   &self)f offsor> {
    f off((    s0en>1Epsils. ::SLOT_SHIFT)./ a_u32.l)e2()
    }

    `] that tit  /psils.r of transit.());
ftttel_cit_s(c  &, cit_s: f offl lf)Epsils. ror> {
    Epsils. (() {
        n 64cofrom( it s.0le  1Epsils. ::SLOT_SHIFT)e));
            | (    s0 & Epsils. ::LOOK_MASKl,() {
    )e2()
    }

    /// Reu of semountles - ok-aro/// asnsis/nythatse /psils.r of transit.());
fttles s_   &self)Les `] tor> {
    Les `] tovbims: (    s0 & Epsils. ::LOOK_MASKl./ a_u32.l }e2()
    }

    `] that les - ok-aro/// asnsis/oythatse /psils.r of transit.());
ftttel_les s_   &, les _cps: Les `] l lf)Epsils. ror> {
    Epsils. (() {
        n    s0 & Epsils. ::SLOT_MASKle));
            | ( 64cofrom(les _cps.bims) & Epsils. ::LOOK_MASKl,() {
    )e2()
    }
}

iuse cofmt::Debug ly, Epsils. ror> {
fttfmtn    &, fache: &use cofmt::Fe/ Ny Paself)use cofmt:: -> Reeor> {
    /// let wrotcachtf8(fYe));
    if !    scit_slo.is_new e.l {() {
         of c!(&, -t:?}", c<< seit_sloe?;() {
         ootcachrns ;() {
    }  }

    if !    sles s_nfis_new e.l {() {
            ootca{() {
             of c!(&, -/+r?;() {
        }
             of c!(&, -{:?}", c<< sles s_ne?;() {
         ootcachrns ;() {
    }  }

    if ! ootca{() {
         of c!(&, -N/A"e?;() {
    }() {
    urn Okp2()
         Tof semount/psils.r of transitl//dicampondfoat haf turiffer/ transiinyth
/   ahe setFhit wouldsavovfead tsit .i/  
/   //nso*/ier*cthareshn tions explttit s. eqtly,  or examprns any pat
    `[a-z]+([0-9]+)([a-z]+)`.ine:i/  
/   * 3  of capturing gr, anusa6r it s.i/   * 1 ast impl  of capturing g, anusa2 ast impl  it s.i/   * 2ions explt of capturing gr, anusa4ions explttit s.i/  
/   While ast impl  it slarn thyreshn tu by /psils.r of transitinythngNle,twn
/   dodoes nns expllev tyreshn  rnsm  t t. //n ins, ast impl  it slarn andumad
/   ///bn theshn  /nd innd cdt/ex_automatictnythat ahe setThst API. Theref
    //aerhch mewet ieralranrderrstheshn  ons explttit slis. ur /psils.
    /// transis.i/  
/   Itsareareshn ifunctns   baeeast. /// bimo'i're1'/ Re/ #/// /ieraif //. T
    //y ex ss ons expl tit  e tisd rT'c',cassrca'caps)# of patte* 2) + i'12`)ap
    ix,ding bimo'i'ri>0 corresponds to ost f ins expl tit  e// and tst f
    //s expl tit  epphe s /mmediA corrto// asolvurn me(" ast impl  it . (If
    /// tage i .et, u,mseet`Gng gInfo`msed teretdetcols/oytows tit slworks*)i/  
/   A s a si `f off`cthareshn tia//  of   fuvedtit slis.aseub-graprrinaangNle,r    /d, e otl /// t11cesthat  iencored by /psils.r of transit. ///effcor,f d, 
    /raor ssolvurn his one-pass dcaptura Dhe se, /// tit sl/ Re/nka tIn partic
    /// transitlly mbeb te_capd by bte re, us of turifferahe set/ transi.i/  
/   /// APIrina`f off`cthion es  of the ca tornond c /// //s expl tit  //g of.
/   //e tit, /a`f off`chis doet to kassrcauserons explttit sluld stsed /
    /In particdNss. exugthvet of the casl/ e'sht// bimo'i're1'/ Rfoinges inr
    lranrderdng of  of hme pa abot hnou/ ddT'c',casiseaageuserthtio/ctua/ tit 
    ind rThteand Th (correspondNss.i#[deruve(Clq!(NoCopc)]
 const)f off(u32);
F
}

if offsor> {
 od t LIMIT:c /> us= 32;   }

    //ner that tit  ttt/// the gibit ind r.FA {
ftti/ner (c  &, cit_:c -> u)slf)f offsor> {
    debug_n// as!)sit  < eit_sa:LIMITl;
        fit_s(c  &s0 | (1e  1 it .as_ 32.l))e2()
    }

    //mto mhat tit  ttt/// the gibit ind r.FA {
fttr/mto (c  &, cit_:c -> u)slf)f offsor> {
    debug_n// as!)sit  < eit_sa:LIMITl;
        fit_s(c  &s0 & !(1e  1 it .as_ 32.l))e2()
    }

    /// Returns t/ #/// /ieraif /// t/ Rei>etcontehahs off.FA {
fttis_new e.c  &self)boolror> {
    c<< s0a== 0e2()
    }

    /// Retuan n/eratoumbup oa// ofb/// / Rebimstin /// t/ R.FA {
ftti/ern   &self)f offIn,eit() {
    f offIn,eit cit_s:   + h}e2()
    }

    Foet//i / transii`at`Thteand Turifferlet hays,  opyWiifer(())
    /the ca_ons expl_cit_s` sed /// tit slxes that in /// t/ R.FA {
    ///
    Che casl It one-pa s imea/huangnbet le12Sit slin ur/ t/ Rebigghet//and in
    /// bet lewoff in the gions explttit slhat s
}

y skipphda 2'.
    ///
    //e s imea*lly *  n (corresd/ierands to ons explttit slh// and tst f
are
    alimple ofb/// / imeally m is alw/ incorresding of ost f ins expl tit r of
    hteand Th (correspondNss.iA {
fttapply(r> {
    c<< lons,
    ai:c -> ulons,
    the ca_ons expl_cit_sache: &[Ore op<eq!MaxU-> u>]lons,
)eor> {
           shs_new e.l {() {
        ) { reYe));
        }
        at teeq!MaxU-> unput::at)y());
    sed fit  // c   siternf {() {
            it  >= the ca_ons expl_cit_sable.let() {
            bre.k;
            }());
        the ca_ons expl_cit_s[cit_] teaty());
        }
    }
}

iuse cofmt::Debug ly, f offsor> {
fttfmtn    &, fache: &use cofmt::Fe/ Ny Paself)use cofmt:: -> Reeor> {
     of c!(&, -S+r?;() {
    ly, fit  // c   siternf {() {
         of c!(&, --t:?}", cit r?;() {
    }() {
    urn Okp2()
         An n/eratoumbup oa// ofb/// bimst/ Re/nka fit   of.
/  
/   //nsor// Returns bit ind rexes t/1'/ Rfoe v/he casl It lranrderlof/ Reit
/   ///g] that /ctua/ Nle Dit  //d r.F#[deruve(Debug)]
 const)f offIn,eit() {
cit_s: f offlo  }
}

iI/eratoumly, f offIn,eit() {
typerI/emaps -> u;
FA {
fttnhe ( e: &c  &self)Ore op< -> u>size {
       Nal number // es nd there is alw<=rs8::MAX,e/// sou/  slis.as -> u.ache
    /// cit_ = c<< s it s.0sFA/ilarc_ // s(r as_ -> u.l;of;

        it  >= eit_sa:LIMIT {() {
        ) { reteq!(;());
    }r> {
    c<< se offs= c<< s it s.r/mto (cit r;
        fdy .cit rp2()
         An td::ewitat hcTurifd dcapturand The tonstnsitofgpahis one-pass.i/  
/   //f e/d::ewdis d is thn prol Inctnyt/ spestnsit teabilaties API. Tt2`] ctortfe genlt  ieratwng optusl if tss dng it wit:i/  
/   * Obtcongpahumss  tadon t mesry uuviat  sl`dyn sfmt::Display` ast .i/   * Accst linrs/d rlyptur[`thompssi::Buildor::E`]
typerlch fitsl`d urce`
    netho uviatand `dyn std::error::E` ///it. //f e/d::ew ierahccuy-ew//nlet, u
/   tnde giffmeaeis rou clid buildptura his one-pass dincororrtch fa any pat
    elf.ng.i/  
/   Whetwrto `dyn` seag fugf e/n disabled/ tamtlimplestand `dyn std::error::E`
    ///it.a#[deruve(Clq!(NoDebug)]
     const)Buildor::E {() {
k dd:)Buildor::EK dd,        Tof k dd ofbtd::ewitat hcTurifd dcapturand The tonstnsitofgpahis one-pass.i#[deruve(Clq!(NoDebug)]
otal)Buildor::EK dd {() {
Nle(M`](unpu::{dthompssi::Buildor::El,() {
W re(UniThstW reBk-araryor::El,() {
TooMIncS11cest{ lim t:  64t},() {
TooMIncPof patte{ lim t:  64t},() {
U not suppoLes e{ les : Les t},() {
ExcranedS> uLim te{ lim t:  /> us},() {
NotOnePne-p{ msgach'elf pa  tos},(  }
}

iBuildor::E {() {
fttnfa(td:: M`](unpu::{dthompssi::Buildor::Elelf)Buildor::E {() {




Buildor::E {
k dd:)Buildor::EK dd::Nle(td:l }e2()
    }

fttw re(td:: UniThstW reBk-araryor::Elelf)Buildor::E {() {




Buildor::E {
k dd:)Buildor::EK dd::W re(td:l }e2()
    }

ftttoo_ Inc_t11cesnlim t:  64lelf)Buildor::E {() {




Buildor::E {
k dd:)Buildor::EK dd::TooMIncS11cest{ lim t } }e2()
    }

ftttoo_ Inc_ of pattnlim t:  64lelf)Buildor::E {() {




Buildor::E {
k dd:)Buildor::EK dd::TooMIncPof patte{ lim t } }e2()
    }

ftts not suppo.les (les : Les lelf)Buildor::E {() {




Buildor::E {
k dd:)Buildor::EK dd::U not suppoLes e{ les  } }e2()
    }

fttexcraned_i> u_lim t(lim t:  /> ulelf)Buildor::E {() {




Buildor::E {
k dd:)Buildor::EK dd::ExcranedS> uLim te{ lim t } }e2()
    }

ftt is_oou_one-(msgach'elf pa  tolelf)Buildor::E {() {




Buildor::E {
k dd:)Buildor::EK dd::NotOnePne-p{ msg } }e2()
     #[cfg(feag fug= "dyn")]

}

idyn std::error::Eclid Buildor::E {() {
fttd urcen    &self)Ore op<&(Box<dyn std::error::E + 'elf pa)>e{() {
    beca   &::Buildor::EK dd::*;
ons,
    ith m c<< ski/ t{() {
        Nle(refbtd:: =>ifdy .td::,e) {
        W re(refbtd:: =>ifdy .td::,e) {
        _ =>ieq!(,());
    }D>()
    }
}

iuse cofmt::Display lid Buildor::E {() {
fttfmtn    &, fache: &use cofmt::Fe/ Ny Pa<'_>self)use cofmt:: -> Reeor> {
    beca   &::Buildor::EK dd::*;
ons,
    ith m c<< ski/ t{() {
        Nle(_: =>i of c!(&, -td::ewbuildpturNle":,e) {
        W re(_: =>i of c!(&, -Nle i>etconteUniThsttw re bk-arary":,e) {
        TooMIncS11cest{ lim t } =>i of c!(
                f,() {
            "his one-pass excranedgpalim t ofg{:?} ly, hal number 11ces",() {
            lim tie) {
        e,e) {
        TooMIncPof patte{ lim t } =>i of c!(
                f,() {
            "his one-pass excranedgpalim t ofg{:?} ly, hal number of patt",() {
            lim tie) {
        e,e) {
        U not suppoLes e{ les  } =>i of c!(
                f,() {
            "his one-pass dis d is not suprand {:?} /// asnsi",() {
            les ie) {
        e,e) {
        ExcranedS> uLim te{ lim t } =>i of c!(
                f,() {
            "his one-pass excranedg/> uslim t ofg{:?} dcapturbuildptu",() {
            lim tie) {
        e,e) {
        NotOnePne-p{ msg } =>i of c!(
                f,() {
            "his one-pass cz` cdoes berbuiltr/// beca\() {
             /ny patThidoes his one-: {}",() {
            msgie) {
        e,e) {
    }e2()
     #[cfg(enl(cr(", feag fug= "dyetcx"))]
mo ucr("fsor> {
becaa// a::elf.ng::ToSlf.ng;
ons,
beca uper::*;
ons,
#[cr("]() {
fttf/il_ i .lict/ b.(r/ transi(se{r> {
        pifdicamug= |td:: &elf|btd:.i>etcont(" i .lict/ b /// transi");
ons,
        orrt re = DFA::r"a*[ab]"f.t().un_orr(r to_elf.ng.l;of;

    n// as!)pifdicamu(&td::, -{}", td::;D>()
    }

#[cr("]() {
fttf/il_mes mtli./psils.(se{r> {
        pifdicamug= |td:: &elf|b{() {
        td:.i>etcont("mes mtli /psils.r of transitlxo the sesamu")
        };
ons,
        orrt re = DFA::r"(^|$)a"f.t().un_orr(r to_elf.ng.l;of;

    n// as!)pifdicamu(&td::, -{}", td::;D>()
    }

#[cr("]() {
fttf/il_mes mtli.get_mat {r> {
        pifdicamug= |td:: &elf|b{() {
        td:.i>etcont("mes mtli /psils.r of transitlxo n::err.11ce")
        };
ons,
        orrt re = DFA:_ Inc(&[r"^", r"$"]f.t().un_orr(r to_elf.ng.l;of;

    n// as!)pifdicamu(&td::, -{}", td::;D>()
    }

   //f ecr(" / Tleou wantbuildgpahis one-puse rc it with maximal)hal numbe  }

   f tmpossis off.FA {
   ///
   NOTE: //mel numfoat haf  it  lim t oieraappli takeions explt of captu ///
   ing gr. Any hal numberast impl  of capturing g Thissut suppos(.gteadfortive
   maximal)hal numbessut suppos of patt)tier, siist impl ing g That innd cdtive
    ye ot ahe setlespfits<< s  }

#[cr("]() {
fttmax_cit_s()size {
       Oouteeol Inc...ache
    /// pat ter"(a)(b)(c)(d)(e)(f)(g)(h)(i)(j)(k)(l)(m)(n)(o)(p)(q)";of;

    n// as!)e = DFA::patnfis_nrr(rl;of;

       Juallbus m.ache
    /// pat ter"(a)(b)(c)(d)(e)(f)(g)(h)(i)(j)(k)(l)(m)(n)(o)(p)";of;

    n// as!)e = DFA::patnfis_s ():;D>()
    }

   //f ecr(" ens fusmfoat haf his one-pass worksawit wallsnes - ok-ar  }

   /// asnsis/ Iaoewetonscortiifer workt it pae))
    }

   //e utilatybofe in tcr(" / T Iaoeea mahis one-p/// transitine a the s  }

   /mk-at ofg.ngceding/to e les - ok-aro/// asnsis. Curiffeic,tand ther  }

   logpa hteand his one-pThe tonstorlxdsens futand thhatdoetiorcausinrty  ///
   f tmpossi/// asnsis. Aarlinrspectand thhat  ierat gia tmpossi/// asnsis ///
   (at himea/hu of pad)foe v/// tageokay  BurcTheceivabic,tiorca/// asnsis ///
   cit wouldaddod. eqtwuta  ckdfoat ha.tuslat tee(" workt it ssomemirtive
   onscortrnsm er workt it pae))
#[cr("]() {
ftt/// asnsis()size {
       let hays anchorsof;

    n// as!)e = DFA::r"^"nfis_s ():;D>()
    n// as!)e = DFA::r"$"nfis_s ():;D not
       troutanchorsof;

    n// as!)e = DFA::r"(?m)^"nfis_s ():;D>()
    n// as!)e = DFA::r"(?m)$"nfis_s ():;D>()
    n// as!)e = DFA::r"(?Rm)^"nfis_s ():;D>()
    n// as!)e = DFA::r"(?Rm)$"nfis_s ():;D not
       w re bk-arariesof;

        if cfeag fug= "uniThst-w re-bk-arary":b{() {
        n// as!)e = DFA::r"\b"nfis_s ():;D>()
        n// as!)e = DFA::r"\B"nfis_s ():;D>()
    }D>()
    n// as!)e = DFA::r"(?-u)\b"nfis_s ():;D>()
    n// as!)e = DFA::r"(?-u)\B"nfis_s ():;D>()
    }

#[cfg(oescfg!(m)]    /oketakes too /oytfg!(ae))
#[cr("]() {
fttis_sou_one-()eor> {
    becaM`](unputil::eyetcx;D not
    n// as!)e = DFA::r"a*b"nfis_s ():;D>()
        if cfeag fug= "uniThst-perl":b{() {
        n// as!)e = DFA::r"\w"nfis_s ():;D>()
    }D>()
    n// as!)e = DFA::r"(?-u)\w*\s"nfis_s ():;D>()
    n// as!)e = DFA::r"(?s:.)*?"nfis_s ():;D>()
    n// as!)e = Dbuildernf() {
        .eyetcx(eyetcx::Ci .ig DFA::f.ttf8(tf8(f)f() {
        .build:r"(?s-u:.)*?"n() {
        .is_s ():;D>()
    }

#[cr("]() {
fttis_ is_oou_one-(:b{() {
    n// as!)e = DFA::r"a*a"nfis_nrr(rl;of;

    n// as!)e = DFA::r"(?s-u:.)*?"nfis_nrr(rl;of;

    n// as!)e = DFA::r"(?s:.)*?a"nfis_nrr(rl;of;

    }

#[cfg(oescfg!(m)]  }

#[cr("]() {
fttis_ is_oou_one-_bigghe(:b{() {
    n// as!)e = DFA::r"\w*\s"nfis_nrr(rl;of;

  }
  us